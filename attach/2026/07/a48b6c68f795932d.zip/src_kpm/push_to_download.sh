#!/usr/bin/env bash
# push_to_download.sh — (run on the PC) adb-push riskhider.kpm to the phone's
# Download folder, ready to load via the APatch Manager GUI.
#
#   ./push_to_download.sh                 # pushes ./riskhider.kpm
#   ./push_to_download.sh <package>       # also prints that app's uid for args=
#
# Then in APatch Manager: KPM -> load /sdcard/Download/riskhider.kpm
#                         args = uid=<the number printed below>
set -u

DEST="/storage/emulated/0/Download"
HERE="$(cd "$(dirname "$0")" && pwd)"
KPM="$HERE/riskhider.kpm"
PKG="${1:-wu.Zygisk.Detector}"

say() { echo "[push] $*"; }

command -v adb >/dev/null 2>&1 || { say "ERROR: adb not found in PATH"; exit 1; }
[ -f "$KPM" ] || { say "ERROR: riskhider.kpm not found next to this script ($KPM)"; exit 1; }

# device online?
state="$(adb get-state 2>/dev/null)"
if [ "$state" != "device" ]; then
    say "ERROR: no device (adb get-state = '${state:-none}'). Plug in + enable USB debugging."
    exit 1
fi

say "device: $(adb shell getprop ro.product.model 2>/dev/null | tr -d '\r')"
say "pushing riskhider.kpm -> $DEST/ ..."
adb shell mkdir -p "$DEST" >/dev/null 2>&1
adb push "$KPM" "$DEST/riskhider.kpm" || { say "ERROR: push failed"; exit 1; }

# verify
if adb shell "ls -l $DEST/riskhider.kpm" 2>/dev/null | grep -q riskhider.kpm; then
    say "ok: $DEST/riskhider.kpm"
else
    say "WARN: could not verify the pushed file"
fi

# best-effort: resolve the target app's uid so you know what to type in args=
UID_VAL="$(adb shell su -c "stat -c %u /data/data/$PKG" 2>/dev/null | tr -d '\r')"
case "$UID_VAL" in
    ''|*[!0-9]*) UID_VAL="" ;;
esac

echo
say "==================== next step (APatch Manager GUI) ===================="
say "  KPM  ->  Load  ->  /sdcard/Download/riskhider.kpm"
if [ -n "$UID_VAL" ]; then
    say "  args =  uid=$UID_VAL pkg=$PKG"
    say "          (pkg= exempts the app's own files so it can't self-crash)"
else
    say "  args =  uid=<APP_UID> pkg=$PKG     (u0_aNNN -> 10000+NNN)"
fi
say "  then check:  adb shell su -c 'dmesg | grep riskhider\\['"
say "======================================================================="
