# riskhider.kpm

An **APatch KernelPatch Module** that hides root / hook / emulator artifacts
from native Android risk-detection SDKs, by hooking syscalls at the **kernel
syscall-table** level.

It is built directly from the reverse-engineering reports of four detectors:

| Detector | Report | Type |
|---|---|---|
| `libriskdetector.so` | `momo/riskdetector_*.md` | native JNI risk SDK (io.liankong) |
| mus_love / Detector | `Detector/docs/analysis/*.md` | MVEL-script detector (ZygiskDetector) |
| Hunter v6.58 | `文档/Hunter分析.md` | `libhunter.so` RASP (com.zhenxi.hunter) |
| GarudaDefender | `文档/GarudaDefender_native_alert_analysis.md` | native RASP |

---

## Why a KPM (the core idea)

Every one of these detectors spends most of its complexity defeating
**userspace** instrumentation:

- `libriskdetector` `fix0` hooks `libbinder` `ioctl` and then issues a **raw
  `syscall(__NR_ioctl,…)`** to bypass any userspace ioctl hook;
  `DetectEvilKernel` uses a `CNTVCT_EL0` timing loop to catch hooks and
  `while(1)`-hangs if tripped.
- **Hunter** builds a `safe_syscall_via_trampoline`: it finds the dynamic
  linker's own `svc #0` instruction and calls through it (X8=nr), then
  NEON-checksums the 48-byte trampoline every call — a libc/PLT/inline hook
  is both bypassed and detected.
- **GarudaDefender** scans `/proc/self/{maps,smaps}` for `rustfrida` / `qbdi`
  memfd & RWX artifacts.
- **mus_love** scans the **parent** process `/proc/<ppid>/{maps,smaps}` for
  `frida`/`zygisk`/`lsposed` and gates on `TracerPid==0` + sensor count.

A **raw `svc #0` still traps into the kernel.** `fp_hook_syscalln()` swaps the
kernel `sys_call_table` entry, so it intercepts the call *after* the trampoline,
no matter how the detector dodged userspace. And because riskhider injects
**nothing** into userspace, all the anti-userspace-hook machinery (CNTVCT
timing, ArtMethod entry checks, fd-`readlink` redirect detection, VM-Daemon
timing-kill, Hunter's checksum) has nothing to find and **passes naturally**.

That is the whole argument: move the bypass below everything the detector can
see.

---

## What it hooks

All hooks are **gated to the target app only** (`should_hide()`), so the rest
of the system is untouched.

| # | Vector | Syscalls | Action |
|---|---|---|---|
| **A** | Path existence | `faccessat`,`faccessat2`,`openat`,`newfstatat`,`statx`,`readlinkat` | return `-ENOENT` for blacklisted paths |
| **B** | Exec of root bins | `execve`,`execveat` | return `-ENOENT` (kills `which su`, exec magisk) |
| **C** | `/proc` text scan | `read`,`pread64` | overwrite hook/frida/root markers in-place (same length) for `/proc/<pid>/{maps,smaps,status,mounts,mountinfo}` |
| **D** | FS-type tamper probe | `statfs`,`fstatfs` | rewrite `f_type` `overlayfs`/`tmpfs` → `ext4` for `/system`,`/vendor`,`/product`,`/system_ext`,`/odm`,… (defeats `checkFileSystemTypeReal`) |

Coverage by detector function:

- **A** defeats `isFileExists` (3198 hits), `DetectAdvanceRoot`, `checkXpFiles`,
  `checkMultiApp`, `hasScrcpyIn`, `CheckThirdPartyRom`, Hunter `checkRiskFile`
  (su/magisk/`/data/adb`/`/debug_ramdisk`/scrcpy/minicap/shizuku/…), Garuda
  file probes, emulator feature files.
- **B** defeats `RunCmd`-style `which su` / exec of magisk/su.
- **C** defeats mus_love `indexOf("frida"|"zygisk"|…)` over maps/smaps, Hunter
  mountinfo/threadname marker scan (`gum-js-loop`,`gmain`), Garuda maps/smaps
  `rustfrida`/`qbdi` scan.

The blacklist itself lives in **`blacklist.h`** (heavily commented, grouped by
category) — edit it there.

---

## Build

This is a standard KernelPatch Module. You need the
[KernelPatch](https://github.com/bmax121/KernelPatch) source and an aarch64
compiler. **A prebuilt `riskhider.kpm` is included in this folder** (already
compiled & validated, see "Status" below).

### Verified build (Android NDK clang) — this is exactly what produced the shipped .kpm

```bash
git clone --depth 1 https://github.com/bmax121/KernelPatch
cp riskhider.c blacklist.h Makefile KernelPatch/kpms/riskhider/   # (mkdir it first)

NDK=$HOME/android-ndk-r29-linux/android-ndk-r29
CLANG=$NDK/toolchains/llvm/prebuilt/linux-x86_64/bin/aarch64-linux-android34-clang
make -C KernelPatch/kpms/riskhider KP_DIR="$PWD/KernelPatch" CC="$CLANG"
# -> riskhider.kpm  (ELF REL aarch64, with .kpm.info metadata section)
```

### Or with a cross gcc

```bash
make KP_DIR=/path/to/KernelPatch TARGET_COMPILE=aarch64-linux-gnu-
```

> The `.kpm` is a relocatable ELF; the KernelPatch loader resolves its
> undefined symbols against **KP's own export table** (NOT arbitrary kernel
> kallsyms) and applies the relocations itself. Two NDK-clang gotchas the
> Makefile already handles — keep them if you change the build:
>
> 1. **`-fno-pic` (no GOT).** KP's relocator (`kernel/patch/module/relo.c`)
>    supports only direct relocations (`ABS64`, `ADR_PREL_PG_HI21`,
>    `ADD_ABS_LO12_NC`, `CALL26`, `LDST*_ABS_LO12_NC`, MOVW). NDK clang
>    defaults to PIC and emits `R_AARCH64_ADR_GOT_PAGE`(311)/`LD64_GOT_LO12_NC`(312),
>    which the loader rejects ("unsupported RELA relocation: 311"). Do **not**
>    add `-fno-plt` — it forces external calls through the GOT too.
> 2. **No KP allocator / `memset`.** This KP build doesn't export
>    `tlsf_malloc`/`kp_rw_mem` or `memset`; the module is heap-free and ships
>    its own `memset/memcpy/memmove` in `compat_mem.c`.
>
> Build against the same KP release you flashed, and confirm `apd -V` matches.

---

## Install & control (APatch)

### How KPM management actually works on this build

The stock `apd` has **no `kpm` subcommand**, and there is **no `kpatch` binary**
on the device. KPM load/unload/control go through the KernelPatch **supercall**
(syscall 45). Per `kernel/patch/common/supercall.c`, those commands require an
**authenticated** caller (`is_authed`) — that means the **real APatch SuperKey**
(or the Manager app's uid). The literal `"su"` only grants "trusted caller",
**not** `is_authed`, so it cannot manage KPMs. That's why the GUI works (Manager
uid) but a plain root shell with `"su"` cannot.

Two ways to drive it:

**A) GUI — no key needed.** APatch Manager → KPM → load `riskhider.kpm`, set
**args** = `uid=10243` (your app's uid). That alone gates it (init parses `uid=`).
Simplest if you don't want to type your SuperKey in a shell.

**B) CLI — bundled `rhctl` + one-tap script (needs your SuperKey).** `rhctl` is a
tiny supercall tool included here (build: `aarch64-linux-android34-clang rhctl.c
-O2 -o rhctl`).

```bash
adb push riskhider.kpm rhctl load_riskhider.sh unload_riskhider.sh /data/local/tmp/
adb shell su -c 'SUPERKEY=YOUR_SUPERKEY sh /data/local/tmp/load_riskhider.sh'
# other app:  SUPERKEY=KEY sh load_riskhider.sh <package> [kpm_path]
```

Manual `rhctl` use:

```bash
R="/data/local/tmp/rhctl YOUR_SUPERKEY"
$R hello                                   # verify key (expects "key valid")
$R load /data/local/tmp/riskhider.kpm "uid=10243"
$R control riskhider "uid=10243"           # gate by app uid (covers child shells)
$R control riskhider "comm="               # clear default comm gate -> uid-only
$R control riskhider "verbose on"          # per-event logs to dmesg
$R control riskhider "status"              # print stats
$R unload riskhider
```

> For the demo app `io.liankong.riskdetector` the default `comm=liankong` gate
> already matches, so even a no-args load gates it — but uid gating is stronger
> (covers the shells it forks).

### Gating: prefer **uid**

`comm` (process name) is truncated to 15 chars and changes to `sh` for the
shell that `RunCmd`/popen forks — so `which su` inside that shell would not be
gated. Setting the app's **uid** covers the app *and* the shells it forks
(they inherit the uid). Find it with:

```bash
stat -c %u /data/data/<the.app.package>
```

Default gate out of the box is `comm=liankong` (the RiskDetector demo app).
Change it to your target before relying on it.

---

## Logging & debugging

Because this is kernel code, it logs every stage so you can diagnose from
`dmesg` alone:

```bash
dmesg | grep riskhider
```

- **Always on** (stage level): `riskhider[init]` (symbol resolution + every
  hook install with name/nr + final summary), `riskhider[ctl]` (command + new
  state), `riskhider[exit]` (every unhook + leak check), `riskhider[mem]` OOM.
- **`verbose on`** (per-event): `riskhider[hide]`/`[exec]` (uid + path turned
  into ENOENT), `riskhider[scrub]` (file + markers scrubbed), `riskhider[fsfake]`
  (path + old f_type → ext4), and `riskhider[mem]` for **every alloc and free**.

**Memory discipline:** all heap use goes through `rh_alloc()`/`rh_free()`, which
count allocations and frees. `status` prints `mem alloc=N free=M (in_use=K)` and
`exit` logs `MEMORY LEAK` if `alloc != free`. Every `kp_malloc` has a matching
`rh_free` on all return paths (the `/proc` scrubber is the only allocator, and
it allocates only after confirming the fd is a sensitive `/proc` file — normal
reads never allocate).

## Companion: `resetprop_companion.sh`

One vector a syscall KPM **cannot** reach is system-property **values**:
`__system_property_get()` reads the mmap'd `/dev/__properties__` region, with
no per-read syscall to hook. Handle those with resetprop (Magisk/APatch module
or `post-fs-data`). The script sets `ro.debuggable=0`, `ro.boot.verifiedbootstate=green`,
deletes `ro.boot.qemu`/`vmprop.*`, etc. — covering `CheckCPGJ1`,
`DetectCloudPhone`, and Hunter's `verifiedbootstate` check.

---

## Limitations (be honest about these)

A kernel syscall hook **cannot** defeat:

1. **In-app integrity / signature hashes** — mus_love `sha256sum classes.dex`
   + package-signature digest; Hunter/Garuda in-memory NEON/CRC checksums of
   `libart`/`libc`/`linker64`/self. These compare bytes already in memory; no
   I/O to fake. (If the app/lib is unmodified, these pass anyway — don't patch
   the target binary and they stay green.)
2. **TEE / verified-boot attestation** — Hunter Keystore `rootOfTrust`
   (`deviceLocked`,`verifiedBootState`) is hardware-backed.
3. **GPU renderer** — `getRealOpenGLRenderer` dlopen's the vendor GL driver and
   calls `glGetString` (emulators show SwiftShader/llvmpipe). Needs a GL shim.
4. **Sensor count** — mus_love `sensors >= 20` (Java `SensorManager`).
5. **`getifaddrs` / netlink interface names** — `tun0`/`docker`/`veth`
   enumeration goes over an `AF_NETLINK` socket; scrubbing it cleanly needs a
   `recvmsg` netlink-response filter (not implemented here — listed as future
   work). Note Hunter's own check uses `strcmp(name,"tun")` and already misses
   `tun0`.
6. **System-property values** — use the resetprop companion (above).

What's left after 1–6 is mostly *self-protection / integrity*, which you avoid
by **not modifying the app or its libraries** and doing the hiding purely in
the kernel — exactly what this module is for.

---

## Files

```
riskhider_kpm/
├── riskhider.c             # the module (hooks A/B/C, gating, control)
├── blacklist.h             # detection-artifact tables (edit me)
├── Makefile                # KernelPatch kpm build
├── resetprop_companion.sh  # property-value vector (separate from KPM)
└── README.md               # this file
```

## Status / testing

- **Compiles**: ✅ verified — builds cleanly against KernelPatch headers with
  NDK r29 `aarch64-linux-android34-clang`, producing a valid `riskhider.kpm`
  (`ELF REL AArch64` + populated `.kpm.info` section). Every undefined symbol
  resolves to a KernelPatch/kernel primitive.
- **On-device**: ⏳ not yet run on a live patched device. Load it on your own
  APatch device and watch `dmesg | grep riskhider`.

The path-hide (A) and exec-block (B) hooks use the well-established KP
`fp_hook_syscalln` pattern. The `/proc` scrubber (C) resolves fd→path via
kallsyms-looked-up `fget`/`file_path` and rewrites the user buffer — the
higher-risk part — so test it on-device with `verbose on` first. If those
symbols don't resolve on your kernel, the module auto-disables C at load
(A/B still work); you can also force it off with `procfilter off`.
```
