#!/system/bin/sh
# resetprop_companion.sh — handles the ONE detection vector riskhider.kpm
# cannot: system-property *values*.
#
# Why this is a separate script and not in the KPM:
#   __system_property_get() reads the mmap'd /dev/__properties__ region
#   directly; there is no per-read syscall to hook. The reliable way to
#   change a property value is resetprop (Magisk/APatch/KernelSU).
#
# Install: APatch/Magisk module -> run from a post-fs-data.sh / service.sh,
# or paste into a "props" module. Requires root (resetprop in PATH).
#
# Covers: CheckCPGJ1 (vendor fingerprint), DetectCloudPhone, Hunter
# verifiedbootstate, mus_love kernel/debug props.

set -e
# find resetprop: PATH, then APatch, then Magisk locations
RP=""
for c in "$(command -v resetprop 2>/dev/null)" /data/adb/ap/bin/resetprop /data/adb/magisk/resetprop /data/adb/modules/*/system/*bin/resetprop; do
    [ -n "$c" ] && [ -x "$c" ] && { RP="$c"; break; }
done
[ -z "$RP" ] && { echo "resetprop_companion: resetprop not found"; exit 1; }
echo "resetprop_companion: using $RP"

setp() { "$RP" -n "$1" "$2" 2>/dev/null || "$RP" "$1" "$2" 2>/dev/null || true; }
delp() { "$RP" --delete "$1" 2>/dev/null || true; }

# --- debuggable / secure / adb ---
setp ro.debuggable 0
setp ro.force.debuggable 0
setp ro.secure 1
setp ro.adb.secure 1

# --- verified boot / bootloader (Hunter ro.boot.verifiedbootstate) ---
setp ro.boot.verifiedbootstate green
setp ro.boot.flash.locked 1
setp ro.boot.veritymode enforcing
setp ro.warranty_bit 0
setp ro.boot.warranty_bit 0
setp sys.oem_unlock_allowed 0
setp ro.boot.vbmeta.device_state locked

# --- SELinux enforcing markers ---
setp ro.build.selinux 1
setp ro.boot.selinux enforcing

# --- emulator / qemu giveaways (delete, don't set) ---
delp ro.boot.qemu
delp ro.kernel.qemu
delp ro.kernel.qemu.gles
delp qemu.hw.mainkeys
delp qemu.sf.lcd_density
delp ro.vmos.simplest.rom
delp vmprop.latitude
delp vmprop.longitude
delp vmprop.local_package
delp ro.boot.container

# --- data-isolation / multi-app props (mus_love / RiskDetector) ---
# leave these matching a normal device:
setp persist.sys.vold_app_data_isolation_enabled true
setp persist.zygote.app_data_isolation true

echo "resetprop_companion: done"
