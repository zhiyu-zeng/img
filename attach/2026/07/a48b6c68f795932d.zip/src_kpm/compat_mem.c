/*
 * compat_mem.c — freestanding mem* primitives for riskhider.kpm
 *
 * The compiler lowers aggregate init / struct copies to external
 * `memset`/`memcpy`/`memmove` libcalls. This KernelPatch build's module
 * loader does NOT export those symbols, so loading riskhider.kpm failed
 * with "unknown symbol: memset". We provide our own here.
 *
 * This file deliberately does NOT include <linux/string.h> (which declares
 * memset/memcpy as `static inline`, causing a redefinition conflict). It is
 * compiled to a separate object and linked into the .kpm; the libcall
 * references in riskhider.o resolve to these definitions.
 *
 * The no_builtin attribute (clang) stops the compiler from recognising the
 * byte loops below as mem* idioms and turning them back into self-calls.
 */

typedef unsigned long rh_size_t;

#ifdef __clang__
__attribute__((no_builtin("memset")))
#endif
void *memset(void *s, int c, rh_size_t n)
{
    unsigned char *p = (unsigned char *)s;
    while (n--)
        *p++ = (unsigned char)c;
    return s;
}

#ifdef __clang__
__attribute__((no_builtin("memcpy")))
#endif
void *memcpy(void *d, const void *s, rh_size_t n)
{
    unsigned char *dp = (unsigned char *)d;
    const unsigned char *sp = (const unsigned char *)s;
    while (n--)
        *dp++ = *sp++;
    return d;
}

#ifdef __clang__
__attribute__((no_builtin("memmove")))
#endif
void *memmove(void *d, const void *s, rh_size_t n)
{
    unsigned char *dp = (unsigned char *)d;
    const unsigned char *sp = (const unsigned char *)s;
    if (dp == sp || n == 0)
        return d;
    if (dp < sp) {
        while (n--)
            *dp++ = *sp++;
    } else {
        dp += n;
        sp += n;
        while (n--)
            *--dp = *--sp;
    }
    return d;
}
