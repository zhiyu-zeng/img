# CHANGELOG — riskhider.kpm

逐阶段记录:每一步**改了什么、修复了什么**。对应 git 提交见括号内 hash。

---

## v1.3.0 — 针对 RiskDetector 补 SELinux file_contexts su_exec 清洗
- **目标**:`io.liankong.riskdetector`(uid 10243,libriskdetector.so,native)。
- **新增**:C(内容清洗)扩展到 SELinux `*_file_contexts` 文件。
  `DetectAdvanceRoot` 不只查 su 路径存在,还**读 `/system_ext|/system|/vendor|...
  /etc/selinux/*_file_contexts` 的内容找 `u:object_r:su_exec:s0` 标签**反查隐藏的 su
  —— A 的路径 ENOENT 挡不住。现在 `proc_mode()` 识别含 "file_contexts" 的路径 → mode 1
  同长度擦除,把 `su_exec` 标记打掉(保文件大小、跨 read 边界安全)。`proc_scrub[]` 加
  `su_exec`。
- **覆盖评估**(native 检测面,`mode=native` = A/B/C/D):root 文件/xposed(A)、
  su_exec 标签(C 新)、fs 类型(D)、/proc mounts(C);模拟器/属性/GPU/容器/VPN/ROM/
  scrcpy 在真机自然过。
- **留待实测**(本版未预改,避免误伤):① `DetectEvilKernel` 用 CNTVCT 给
  `faccessat("/NTR")` 计时反 hook,KPM 的内核 hook 微小延迟**理论上**可能触发;
  ② `/sys/fs/selinux/enforce`(permissive 才需治,enforcing 自然过);
  ③ `ls -1Z /system` 找 "HACKED"(popen 管道输出,fd 非文件路径,当前不清洗)。
  ④ VM-Daemon timing-kill 针对 frida/调试器,**测试别附加 frida**。

## v1.2.9 — KPM 内核层绕过 ZygiskDetector "Su Found" ✅ (`54ccb70`)
- **成果**:ZygiskDetector 的 "Su Found" 被 KPM 在 syscall 层**真正绕过**(实测通过,
  结果降级为黄色 "Unsupported Kernel",su/zygisk 均未检出)。
- **Frida 实证定性**(用 frida-server **16.5.9**,Frida 17 去掉了内置 `Java` 桥;
  脚本 `hook/diag_enoent.js`+`run_diag.py`):
  - `su = (Os.stat("/") != Os.stat("/debug_ramdisk"))` 是 **(st_dev,st_ino) 值比较**,
    不是对象引用(返回带 root dev/ino 的新对象 → `!=` 为 FALSE),**也不比 st_nlink**。
  - 故修法:`/debug_ramdisk` 的 stat **成功返回** dev/ino=`/` 的、`st_nlink=2`。
  - app 脚本**零容错**:stat 抛 ENOENT → `debugdev` 未定义 → 脚本中断 → 永久 Loading
    (这正是 v1.2.7 卡死根因);命令失败 → d 变错误串 → `(d>2)` "uncomparable" → 也崩。
    **所以必须成功返回伪值,绝不能 ENOENT。**
  - `d = parseInt(stat -c %h /debug_ramdisk)`(硬链接数),设备真实 nlink=3 → 需读成 2。
- **修复**:after-hook 在 /debug_ramdisk 上写 dev@0/ino@8(=缓存的"/")+ nlink@20=2
  (statx:dev@0x88/ino@0x20/nlink@0x10)。before-hook 退回纯 A。
- **关键认知**:残留的 "Unsupported Kernel" = `supported1&&supported2==false`(内核<5)。
  **别伪造内核版本**——`zygisk1-4` 的 maps 结构检测正以 supported 为开关,4.14 上休眠;
  伪造成 5.x 会**唤醒**它,得不偿失。黄色警告非 root 检出,留着最稳。

## v1.2.6–1.2.8 — su 伪造的三次失败试探(已被 v1.2.9 取代)
- v1.2.6 只改 st_dev 值 → 无效(还要 ino)。v1.2.7 改 ENOENT → **卡死**(app 无 try/catch)。
- v1.2.8 整结构克隆 → 把 root 的 nlink=27 也克隆了 → `d=27>2` 触发。三次都因当时
  误判 su 的比较语义(对象 vs 值 vs 哪些字段),最终靠 Frida 实测才钉死,见 v1.2.9。

## v1.1.9 — 一行配置 + 自崩双保险 (`58cd9f6`)
- **修复**:每次重载要按顺序敲一堆控制命令、且先设 uid 会把自己崩掉的折腾。
- 新增 `apply_token` 支持 `pathhide=/execblock=/procfilter=/fsfake=/sufake=` 以及
  `mode=java`(A/B/D 关、C/E 开,对付 ZygiskDetector/mus_love)、`mode=native`
  (A/B/C/D 开,对付 RiskDetector/Hunter/Garuda)。**加载 args 一栏一行配好**,
  顺序无关、原子生效、APatch 持久化重放。
- 双保险:`path_blacklisted` 永不 ENOENT `/data/app/*` → 即使忘填 `pkg=`,
  app 也无法把自己的 base.apk 隐藏掉 → 不再自崩。

## v1.1.8 — E:st_dev 伪造,KPM 拿下 ZygiskDetector 的 "Su Found" (`603f93b`)
- **修复**:`su = (rootdev != debugdev)` 检测(`Os.stat("/").st_dev` vs
  `Os.stat("/debug_ramdisk").st_dev`,APatch 的 debug_ramdisk 是独立 tmpfs → 设备号不同)。
- newfstatat(st_dev@0)、statx(dev_major@0x88/minor@0x8C)加 after-hook:缓存
  本 app `stat("/")` 的 st_dev,把 `/debug_ramdisk` 的 st_dev 改成它 → `rootdev==debugdev`
  → su=false。按 syscall 格式分别缓存,免 dev_t 编码转换。开关 `sufake`。
- 纠正了「KPM 是错的层次」的结论:ZygiskDetector 每个输入归根结底都是 syscall,KPM 能拦。

## (doc) COUNTER_ZygiskDetector.md — 检测模型 + 对抗方案 (`d7ac89d`, `adb62c0`)
- 还原 ZygiskDetector 放行门:`injected==0 && hooked==0 && traced==0 && 4 项完整性`。
- 关键发现:它**不查 su/magisk 文件存在**,所以 A 对它没用、还是卡死元凶;只需 C。
- v1.1.7(`adb62c0`):新增 `pathhide`/`execblock` 运行时开关,便于跑「只开 C」最小配置。

## v1.1.6 — pkg= 自我豁免,修「名字含标记的 app 自崩」 (`18baf62`)
- **修复**:`wu.Zygisk.Detector` 包名含 "zygisk" → 它读自己的 apk/so/data 被 A ENOENT
  → 自崩(同 momo 的 vvb2060)。"zygisk" 是核心标记不能删。
- 新增 `pkg=<包名>`:被测 app 自己的文件/maps 行**永不隐藏**;args 支持空格多 token
  (`uid=10238 pkg=wu.Zygisk.Detector` 一次设)。

## v1.1.5 — B 方案:整行删除,打掉结构化 mount 检测 (`5884179`)
- **修复**:同长度字符串擦除挡不住「按挂载结构判断」的检测(momo 的 mountinfo)。
- maps/smaps/mounts/mountinfo/mountstats 改为**整行删除**(含标记的整行删掉、缩短 read
  返回长度),无堆、双游标原地压缩、两遍(扫描→提交)保证不中途损坏缓冲区。
- status/cmdline 仍用同长度擦除。补 `/adb/modules` 标记(此前 `/data/adb` 漏了无前缀的)。

## v1.1.4 — 修 copy_to_user 返回判断 + 解析 copy_from_user (`ad90734`)
- **修复**:误把 `compat_copy_to_user`(返回**已拷贝**长度)当成「剩余字节」→ 成功被
  当失败、日志误报。改为 `==len` 才算成功。
- `copy_from_user` 多名兜底(`_copy_from_user`/`__copy_from_user`/`raw_`/`__arch_`)→
  statfs 伪造从「无脑改」变成「确实是 overlay/tmpfs 才改」,不再刷屏。

## v1.1.3 — 修「名字含作者名的 app 自崩」 (`52344c9`)
- **修复**:黑名单里的裸作者名 token(`vvb2060` 等)误伤 `io.github.vvb2060.mahoshojo`
  自己的文件 → 自崩。删掉裸作者名(已被 magisk/kernelsu/apatch 全名覆盖),换精确全名。

## v1.1.2 — 裸数字当 uid + 修 resetprop 路径 (`f157f81`)
- **修复**:用户填 `10238`(无 `uid=`)被当未知命令、门控没生效。现支持裸数字=uid。
- resetprop 在 APatch 路径 `/data/adb/ap/bin/resetprop` 也能找到。

## push/管理脚本 (`ed583df`, `13a3d70`, `a1b94fa`, `b9e9be1`)
- `push_to_download.sh`:电脑端 adb 把 kpm 推到 `/sdcard/Download` 并自动算目标 uid。
- `rhctl.c`:自带 supercall CLI(syscall 45)。**关键发现**:KPM 的 load/control 需
  **真 SuperKey**(`is_authed`),字面量 "su" 不行(只够非 KPM 调用)——这是设备无 kpatch
  时的管理办法。
- load/unload 脚本(早期基于 apd/kpatch,后转 rhctl)。

## v1.1.1 — 修首次加载失败「unknown symbol」 (`5d1c0ca`, `dd19eef`)
- **修复①**:`unknown symbol: memset/kp_rw_mem/tlsf_*`。该 KP 加载器只链接 KP 自己导出
  的符号表。→ 去掉堆(改栈分块擦除);`memset/memcpy/memmove` 自带在 `compat_mem.c`。
- **修复②**:`unsupported RELA relocation: 311`(GOT 重定位)。NDK clang 默认 PIC 走 GOT,
  KP 重定位器不支持。→ 编译加 `-fno-pic -fno-pie -mcmodel=small`(切勿加 `-fno-plt`)。

## v1.1.0 — statfs 伪造 + 严谨内存/日志 (`620cace`)
- 新增 D(statfs f_type 伪造,对 checkFileSystemTypeReal)、`/debug_ramdisk` 擦除。
- 按「内核模块要严谨」要求:全程分阶段日志(init/hook/ctl/exit 始终打,事件级 verbose),
  内存收支可查。

## v1.0.0 — 初版 KPM (`486c930`)
- 依据 4 份逆向报告(libriskdetector / mus_love / Hunter / GarudaDefender)写的
  APatch KernelPatch Module:A 路径隐藏、B exec 拦截、C /proc 擦除,门控到目标 app。
- 核心思路:内核 sys_call_table 层 hook,截得到检测器的裸 svc;不进用户态,反用户态机制失效。

---

### 经验沉淀(踩过的坑)
1. KP 加载器**只认 KP 导出符号** → undefined 符号须是其子集,其余 `kallsyms_lookup_name` 运行时解析。
2. NDK clang 默认 **PIC→GOT**,KP 不支持 → 必须 `-fno-pic`(且别 `-fno-plt`)。
3. KPM 管理需**真 SuperKey**;"su" 仅非 KPM 调用可用。
4. 门控到 app 后,**凡名字/路径含黑名单标记的自身文件都会被自己隐藏致崩** → `pkg=` 豁免 + `/data/app` 永不隐藏。
5. **分层**:native 检测器→KPM(syscall);Java/脚本检测器→也能 KPM,但要伪造对应 syscall(stat/maps),且别用会干扰子进程的宽 A。

---

## v1.4.x — global 模式自伤治理 + 第一阶段稳定里程碑 (v1.4.1→v1.4.6)

**背景**:切到 `global=1`(对所有 app 生效,省去逐个配 uid)后,丢了 per-app `pkg=`
的"自我保护",导致一连串**自伤**:凡 app 自己的路径/maps 行里含黑名单标记(典型
`wu.Zygisk.Detector` 含 `zygisk`),就把它**自己的文件/内存视图**也藏了 → 卡死、ANR、
检测退化。v1.4.1→v1.4.6 逐个堵:

- **v1.3.5**:`dex2oat`/`/appwidget` marker(Hunter §6.2.4 挂载向量,误报 apex dex2oat32 合法挂载)。
- **v1.3.6**:global gate 覆盖**隔离进程 uid 90000-99999**(Hunter `hunter_server_iso` 借隔离进程绕 app-uid gate)。
- **v1.3.7/1.3.8**:`readlinkat` 按 **target** 拦截 `/proc/<pid>/map_files`(maps 清洗的旁路);init 打印真实版本号(重载可验证)。
- **v1.3.9**:内置可信工具 comm 白名单 + `exempt=<uid>` 运行时豁免(LSPosed/HMA/APatch 管理器误伤)。
- **v1.4.x 核心**:app 私有命名空间**无条件自豁免**(纯路径,不调 get_cmdline 上热路径以免 ANR):
  `/data/data`、`/data/user(_de)`、`/data/misc/profiles`、`Android/data|obb`、
  **`/dalvik-cache`(自己的 .odex)**、`/data/misc/gpu`、`/data/misc/apexdata`。
  A(`is_own_app_path`)与 C(`line_has_marker` 按行)都加,彻底消除自伤。

**关键认知**:
- **ZygiskDetector 已过** —— 黄色 "Unsupported Kernel" **不是检测命中**,是内核 4.14(<5)
  使 `supported1&&supported2==false` 的物理上限;su/zygisk 均未检出。**绝不能伪造 supported
  追绿色**,否则激活 zygisk1-4 结构检测反而真报 Zygisk Found。
- **Hunter**:三层(挂载/TEE/orange)已由 KPM+TrickyStore+VBMeta 拿下;仅剩 `netlink Find
  Permission`(实测真函数 = `sub_E34AC`,非文档 RVA `sub_DDB9C`;开 NETLINK_ROUTE socket
  发 RTM_GETLINK + 查 SDK)—— Info 级,留待专门逆。
- **Momo**:残留是设备上自起的 frida-server(fs17),`pkill -f fs17` 即清,非 KPM 问题。

**第一阶段推荐配置(重启后加载用,实测对 Momo/ZygiskDetector/Hunter 均可接受)**:
```
global=1 verbose=1 pathhide=0 execblock=0 fsfake=0 exempt=10245 exempt=10232
```
= 全局 **C(/proc 清洗)+ E(su 伪造)**,A/B/D 关(A 会卡死脚本检测器且对它们无用;
D 会让 ZygiskDetector 退化)。`exempt` = HMA(10245)+ APatch 管理器(10232)。
