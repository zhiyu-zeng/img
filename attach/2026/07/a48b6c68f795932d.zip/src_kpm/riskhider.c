/*
 * riskhider.kpm — an APatch KernelPatch Module that hides root / hook /
 * emulator artifacts from native risk-detection SDKs by hooking syscalls
 * at the KERNEL syscall-table level.
 *
 * WHY A KPM (and not Frida / a userspace hook):
 *   The analysed detectors (libriskdetector `fix0`, Hunter's
 *   `safe_syscall_via_trampoline`, GarudaDefender) deliberately issue raw
 *   `svc #0` syscalls to bypass any libc / PLT / inline hook. A raw svc
 *   still traps into the kernel, so fp_hook_syscalln() (which swaps the
 *   kernel sys_call_table entry) intercepts it regardless; and because
 *   nothing is hooked in userspace, their anti-userspace-hook machinery
 *   has nothing to find.
 *
 * WHAT IT DOES (gated to the target app only):
 *   A) Path hiding   — faccessat/faccessat2/openat/newfstatat/statx/
 *                      readlinkat on blacklisted paths return -ENOENT.
 *   B) Exec blocking — execve/execveat of blacklisted binaries -> -ENOENT.
 *   C) /proc scrub   — read()/pread64() on /proc/<pid>/{maps,smaps,status,
 *                      mounts,mountinfo} markers overwritten/line-dropped; also
 *                      SELinux *_file_contexts (RiskDetector su_exec lookup).
 *   D) statfs fake   — statfs/fstatfs f_type overlay/tmpfs -> ext4 for the
 *                      system partitions (defeats checkFileSystemTypeReal).
 *   E) su defeat     — newfstatat/statx on the EXACT path /debug_ramdisk report
 *                      "/"'s st_dev+st_ino with st_nlink=2 (stat SUCCEEDS).
 *                      Defeats ZygiskDetector's su=(Os.stat("/")!=Os.stat(
 *                      "/debug_ramdisk")) dev/ino value-compare AND its
 *                      `stat -c %h /debug_ramdisk` hard-link `(d>2)` check at
 *                      once, without ENOENT (which crashes its error-free script).
 *
 * MEMORY: this module uses NO heap. The /proc scrubber processes the user
 *   buffer in fixed stack chunks, so there is nothing to allocate or leak.
 *   (This KP build does not export tlsf_malloc/kp_rw_mem anyway.)
 *
 * LOGGING: stage logs (init / hook install / control / exit) are always on;
 *   per-event logs (hide/exec/scrub/fsfake) need "verbose on". Read with:
 *       dmesg | grep riskhider
 */

#include <compiler.h>
#include <kpmodule.h>
#include <linux/printk.h>
#include <linux/kernel.h>      /* snprintf (kfunc) */
#include <uapi/asm-generic/unistd.h>
#include <syscall.h>
#include <linux/string.h>
#include <kputils.h>           /* compat_copy_to_user, compat_strncpy_from_user, current_uid */
#include <kallsyms.h>          /* kallsyms_lookup_name */
#include <asm/current.h>       /* current */
#include <linux/sched.h>       /* get_task_comm */

#include "blacklist.h"

KPM_NAME("riskhider");
KPM_VERSION("1.4.6");
KPM_LICENSE("GPL v2");
KPM_AUTHOR("RE analysis -> KPM");
KPM_DESCRIPTION("Hide root/hook/emulator artifacts from native risk detectors (riskdetector/Hunter/Garuda/mus_love)");

#ifndef ENOENT
#define ENOENT 2
#endif

#define PATHBUF      256
#define MAX_SCRUB_READ (1 << 20)   /* don't filter reads larger than 1 MiB */
#define SCRUB_CHUNK  1024          /* stack chunk for /proc scrubbing */
#define SCRUB_OVL    32            /* overlap >= longest marker (14) */

/* filesystem magics (statfs f_type) */
#define OVERLAYFS_SUPER_MAGIC 0x794c7630UL
#define TMPFS_MAGIC           0x01021994UL
#define EXT4_SUPER_MAGIC      0x0000EF53UL   /* what we report instead */

/* Freestanding memset/memcpy/memmove live in compat_mem.c — the compiler
 * emits external mem* libcalls that the KP loader does not provide, and we
 * cannot redefine them here because <linux/string.h> already declares them
 * static inline. See compat_mem.c. */

/* ------------------------------------------------------------------ *
 * Logging helpers — consistent "riskhider[<stage>]:" prefix.
 * ------------------------------------------------------------------ */
static int g_verbose = 0;
static int g_diag    = 0;   /* diagnostic: log every interesting path the gated
                               app open/stat/statfs's (find detection mechanisms
                               without frida). Toggle: diag=1 / diag=0. */

#define RH "riskhider"
#define rh_info(stage, fmt, ...) pr_info (RH "[" stage "]: " fmt, ##__VA_ARGS__)
#define rh_warn(stage, fmt, ...) pr_warn (RH "[" stage "]: " fmt, ##__VA_ARGS__)
#define rh_err(stage,  fmt, ...) pr_err  (RH "[" stage "]: " fmt, ##__VA_ARGS__)
#define rh_dbg(stage,  fmt, ...) do { if (g_verbose) pr_info(RH "[" stage "]: " fmt, ##__VA_ARGS__); } while (0)

/* ------------------------------------------------------------------ *
 * Exported kernel symbols resolved at module load via kallsyms.
 * ------------------------------------------------------------------ */
struct file;
typedef struct file *(*fget_t)(unsigned int fd);
typedef void          (*fput_t)(struct file *f);
typedef char         *(*file_path_t)(struct file *f, char *buf, int buflen);
/* copy_from_user-style: returns number of bytes NOT copied (0 == success) */
typedef unsigned long (*cfu_t)(void *to, const void __user *from, unsigned long n);

struct task_struct;
/* get_cmdline(task, buf, len): copies the process's argv (NUL-separated) into
 * buf, returns bytes copied. argv[0] == the app package, and it is PER-PROCESS
 * (shared by every thread) — unlike comm, which each worker thread overwrites
 * (Jit thread pool, Profile Saver, ...). Used to identify a process's own
 * package reliably from any thread. */
typedef int (*get_cmdline_t)(struct task_struct *task, char *buf, int len);

static fget_t        p_fget;
static fput_t        p_fput;
static file_path_t   p_file_path;
static cfu_t         p_cfu;
static get_cmdline_t p_get_cmdline;

/* ------------------------------------------------------------------ *
 * Runtime configuration (set via `apd kpm control riskhider "<cmd>"`)
 * ------------------------------------------------------------------ */
static int   g_enabled    = 1;
static int   g_pathhide   = 1;   /* A: faccessat/openat/... -> ENOENT */
static int   g_execblock  = 1;   /* B: execve/execveat -> ENOENT */
static int   g_procfilter = 1;   /* C: /proc maps/mounts filter */
static int   g_fsfake     = 1;   /* D: statfs f_type fake */
static int   g_sufake     = 1;   /* E: /debug_ramdisk stat dev/ino<-root + nlink=2 (su + d defeat) */

static int   g_global     = 0;   /* GLOBAL gate: act for ALL untrusted apps
                                    (appid 10000-19999), no per-uid config. KPM
                                    becomes a device-wide clean view; LSPosed
                                    handles the binder/Java layer it can't. */
static int   g_target_uid = -1;                 /* -1 = uid gate disabled */
#define MAX_EXEMPT 16
static int   g_exempt_uids[MAX_EXEMPT];          /* trusted tools never hidden from */
static int   g_nexempt = 0;                      /* (e.g. LSPosed parasitic host) */
static char  g_target_comm[24] = "liankong";    /* substring of process name */
static char  g_self_pkg[72] = "";               /* gated app's own package: its
                                                   files/maps are NEVER hidden,
                                                   so an app whose name contains a
                                                   marker (e.g. wu.Zygisk.Detector)
                                                   can still load itself. */

static unsigned long g_hide_path  = 0;
static unsigned long g_hide_exec  = 0;
static unsigned long g_scrub_hit  = 0;
static unsigned long g_fsfake_cnt = 0;
static unsigned long g_sufake_cnt = 0;


/* ------------------------------------------------------------------ *
 * small freestanding string helpers (case-insensitive)
 * ------------------------------------------------------------------ */
static inline char lc(char c)
{
    return (c >= 'A' && c <= 'Z') ? (char)(c + 32) : c;
}

static int ci_index(const char *hay, const char *needle)
{
    int i, j;
    if (!hay || !needle || !needle[0])
        return -1;
    for (i = 0; hay[i]; i++) {
        for (j = 0; needle[j]; j++) {
            if (lc(hay[i + j]) != lc(needle[j]))
                break;
        }
        if (!needle[j])
            return i;
    }
    return -1;
}

static int ci_contains(const char *hay, const char *needle)
{
    return ci_index(hay, needle) >= 0;
}

static int ci_endswith(const char *hay, const char *suf)
{
    int hl = (int)strlen(hay);
    int sl = (int)strlen(suf);
    int i;
    if (sl > hl)
        return 0;
    for (i = 0; i < sl; i++) {
        if (lc(hay[hl - sl + i]) != lc(suf[i]))
            return 0;
    }
    return 1;
}

/* ------------------------------------------------------------------ *
 * gating: only act for the target app
 * ------------------------------------------------------------------ */
static int should_hide(void)
{
    const char *comm = 0;
    int uid, i, candidate = 0;

    if (!g_enabled)
        return 0;

    uid = (int)current_uid();

    /* Step 1 — is this uid even a gate CANDIDATE? (cheap, no get_task_comm, so
       system_server/zygote/shell short-circuit out without touching task_lock on
       every hooked syscall.)
         GLOBAL gate: every normal app + the isolated processes apps spawn —
         detectors (Hunter's hunter_server_iso, uid 90000) fork an isolated proc
         to run their /proc scan precisely to dodge an app-uid gate, so the
         isolated range MUST be covered. appid = uid % AID_USER_OFFSET (multi-user).
           10000-19999  AID_APP_START..  normal apps
           90000-99999  AID_ISOLATED..   isolated_app (app-forked sandboxes) */
    if (g_global) {
        int appid = uid % 100000;
        candidate = (appid >= 10000 && appid <= 19999) ||
                    (appid >= 90000 && appid <= 99999);
    } else if (g_target_uid >= 0 && uid == g_target_uid) {
        candidate = 1;                               /* uid gate (covers forked shells) */
    } else if (g_target_comm[0]) {
        comm = get_task_comm(current);               /* process-name gate */
        candidate = (comm && ci_contains(comm, g_target_comm));
    }
    if (!candidate)
        return 0;

    /* Step 2 — this uid WOULD be hidden; apply the TRUSTED-TOOL exemption so our
       own root/hook tooling (APatch/Magisk/LSPosed managers, HMA, KSU) is never
       hidden from — else global mode breaks them (LSPosed manager can't read
       /data/adb/lspd, LSPlant can't find its own lib, etc.). See blacklist.h
       trusted_comm[] + the runtime exempt=<uid> knob (LSPosed parasitic host). */
    for (i = 0; i < g_nexempt; i++)
        if (uid == g_exempt_uids[i])
            return 0;
    if (!comm)
        comm = get_task_comm(current);
    if (comm)
        for (i = 0; i < ARRSZ(trusted_comm); i++)
            if (ci_contains(comm, trusted_comm[i]))
                return 0;

    return 1;
}

/* diag filter: detection-relevant paths worth logging (skips .so/.dex/.oat and
   the spammy /proc/self/maps). Used only when g_diag is on. */
static const char *const diag_kw[] = {
    "mount", "selinux", "file_contexts", "fstab", "/data/adb", "/data/app",
    "magisk", "apatch", "kernel", "supolicy", "/proc/version", "cpuinfo",
    "/proc/vz", "/proc/xen", "ntr", "package", ".prop", "/sys/fs", "/system/bin",
    "/system/xbin", "busybox", "su",
};
static int diag_interesting(const char *p)
{
    int i;
    if (ci_contains(p, "/maps") || ci_endswith(p, ".so") || ci_endswith(p, ".oat") ||
        ci_endswith(p, ".art") || ci_endswith(p, ".dex") || ci_endswith(p, ".vdex") ||
        ci_endswith(p, ".odex") || ci_endswith(p, ".jar"))
        return 0;
    for (i = 0; i < ARRSZ(diag_kw); i++)
        if (ci_contains(p, diag_kw[i]))
            return 1;
    return 0;
}

/* True if `p` is under an APP-PRIVATE storage root. A must NEVER ENOENT these:
 *
 * Earlier attempts keyed self-exemption off the package (get_task_comm /
 * get_cmdline), but BOTH fail for the processes that actually read these files:
 * the integrity check ZygiskDetector runs is `Runtime.exec("sha256sum
 * <data>/cache/classes.dex")` etc., and worker threads (Profile Saver, Jit
 * pool) — those have comm/argv0 = "sha256sum"/"toybox"/"Profile Saver", NOT the
 * package. So a package match can't cover them, and the app's own integrity
 * inputs kept getting ENOENT'd -> false "Found hook/injection".
 *
 * Resolution: exempt the app-private roots UNCONDITIONALLY. This is safe because
 * cross-app access to another app's /data/data|/data/user|Android/data is
 * already blocked by SELinux app-data isolation (a detector can't read another
 * app's private dir regardless), so KPM ENOENT here only ever hit the caller's
 * OWN files. Root-MANAGER package detection lives at the binder/PackageManager
 * layer (HMA) — see [[rasp-detection-layer-division]] — not here. NB: NOT
 * /data/local/tmp (world-ish, a real frida/agent drop site -> still hidden). */
static int is_own_app_path(const char *p)
{
    /* App-private / per-app runtime namespaces. Any marker matched inside these
       is just the app's own PACKAGE NAME embedded in its own path (e.g. the
       literal "wu.Zygisk.Detector" -> "zygisk"), never a real root artifact, so
       exempt UNCONDITIONALLY. This is keyed off the PATH only — no get_cmdline /
       per-task lookup — because doing that on the syscall hot path (it takes
       mmap_lock + reads user argv) ANRs the app under a detector's probe storm.
       Cross-app access to these is SELinux-blocked anyway, so exempting them can
       only ever reveal the caller's OWN files; real root artifacts live elsewhere
       (/data/adb, /data/local/tmp, system su, mounts) and stay hidden. */
    static const char *const own_roots[] = {
        "/data/data/", "/data/user/", "/data/user_de/",  /* app data */
        "/data/misc/profiles/",                          /* AOT profiles */
        "/Android/data/", "/Android/obb/",               /* external app data */
        "/dalvik-cache/",   /* /data/dalvik-cache + /data/misc/apexdata/.../dalvik-cache (app .odex) */
        "/data/misc/gpu/",  /* per-app GPU shader/config (esx_config_<pkg>.txt) */
        "/data/misc/apexdata/", /* runtime-apex per-app data */
    };
    int i;
    for (i = 0; i < ARRSZ(own_roots); i++)
        if (ci_index(p, own_roots[i]) >= 0)
            return 1;
    return 0;
}

/* ------------------------------------------------------------------ *
 * A/B: path & exec blacklist test
 * ------------------------------------------------------------------ */
static int path_blacklisted(const char *p)
{
    int i, hit = 0;
    /* 1) does the path carry a root/hook/emulator marker at all? (do this FIRST
       so the self-exemption checks — incl. the get_cmdline call — only run on the
       rare marker-bearing path, not on every file access.) */
    for (i = 0; i < ARRSZ(bl_substr); i++)
        if (ci_contains(p, bl_substr[i])) { hit = 1; break; }
    if (!hit)
        for (i = 0; i < ARRSZ(bl_suffix); i++)
            if (ci_endswith(p, bl_suffix[i])) { hit = 1; break; }
    if (!hit)
        return 0;
    /* 2) marker matched — but NEVER hide the caller's OWN files. The match is
       usually just the app's package name embedded in its own path (e.g. the
       literal "wu.Zygisk.Detector" -> "zygisk") across many namespaces:
       /data/data, dalvik-cache (@-encoded), /data/misc/gpu, profiles, ... */
    if (g_self_pkg[0] && ci_contains(p, g_self_pkg))
        return 0;
    if (is_own_app_path(p))
        return 0;
    /* the gated app loads its OWN base.apk/lib from /data/app */
    if (ci_index(p, "/data/app/") >= 0)
        return 0;
    return 1;
}

static int copy_user_path(const char __user *up, char *kbuf, int sz)
{
    long n;
    if (!up)
        return 0;
    n = compat_strncpy_from_user(kbuf, up, sz);
    if (n <= 0)
        return 0;
    kbuf[sz - 1] = 0;
    return 1;
}

/* E (sufake): make /debug_ramdisk's stat report "/"'s st_dev + st_ino but a
 *   forced st_nlink=2, with the stat SUCCEEDING (never ENOENT). Proven with
 *   Frida against ZygiskDetector, this single fake defeats BOTH checks it keys
 *   off /debug_ramdisk:
 *     1. su = (Os.stat("/") != Os.stat("/debug_ramdisk")) -- a VALUE compare on
 *        (st_dev, st_ino) (NOT nlink). dev+ino == "/" -> su=false.
 *     2. d  = parseInt(`stat -c %h /debug_ramdisk`) (hard-link count, child
 *        toybox) with gate `(d>2)||su`. nlink=2 -> d=2 -> d>2 false.
 *   CRITICAL: the app has ZERO error handling. ANY failed stat (-ENOENT) or
 *   non-numeric command output makes `(d>2)` throw "uncomparable" -> uncaught
 *   -> the detection thread dies -> UI stuck on Loading. So we must SUCCEED with
 *   faked values, NEVER ENOENT (that was the v1.2.7 hang). A full-struct clone is
 *   also WRONG: it copies "/"'s nlink (=27 here) -> d>2 -> detected (the v1.2.8
 *   bug). Only dev+ino come from "/"; nlink is forced to 2.
 *   Match EXACTLY (not prefix): only /debug_ramdisk itself; files UNDER it stay
 *   intact (APatch keeps runtime there). */
static const char *const sudev_paths[] = { "/debug_ramdisk" };

/* EXACT match only (also tolerate a single trailing slash). */
static int is_sudev_path(const char *p)
{
    int i;
    for (i = 0; i < ARRSZ(sudev_paths); i++) {
        int n = (int)strlen(sudev_paths[i]);
        if (!strncmp(p, sudev_paths[i], n) && (p[n] == 0 || (p[n] == '/' && p[n + 1] == 0)))
            return 1;
    }
    return 0;
}

/*
 * Generic "hide path -> -ENOENT" before-hook body (A path-hide, gated by GATE).
 * `pidx` is the pathname argument index (arg1 for *at, arg0 for execve).
 */
#define DEFINE_PATH_HOOK(fn, FT, pidx, counter, TAG, GATE)               \
static void fn(FT *args, void *udata)                                    \
{                                                                        \
    char buf[PATHBUF];                                                   \
    const char __user *up;                                               \
    (void)udata;                                                         \
    if (!(GATE))                                                         \
        return;                                                          \
    if (!should_hide())                                                  \
        return;                                                          \
    up = (const char __user *)syscall_argn(args, pidx);                  \
    if (!copy_user_path(up, buf, sizeof(buf)))                           \
        return;                                                          \
    if (g_diag && diag_interesting(buf))                                 \
        rh_info("diag", "uid=%d " TAG " %s", (int)current_uid(), buf);   \
    if (path_blacklisted(buf)) {                                         \
        args->ret = -ENOENT;                                             \
        args->skip_origin = 1;                                           \
        counter++;                                                       \
        rh_dbg(TAG, "uid=%d -> ENOENT %s", (int)current_uid(), buf);     \
    }                                                                    \
}

DEFINE_PATH_HOOK(bf_faccessat,   hook_fargs3_t, 1, g_hide_path, "hide", g_pathhide)
DEFINE_PATH_HOOK(bf_faccessat2,  hook_fargs4_t, 1, g_hide_path, "hide", g_pathhide)
DEFINE_PATH_HOOK(bf_openat,      hook_fargs4_t, 1, g_hide_path, "hide", g_pathhide)
DEFINE_PATH_HOOK(bf_readlinkat,  hook_fargs4_t, 1, g_hide_path, "hide", g_pathhide)
DEFINE_PATH_HOOK(bf_execve,      hook_fargs3_t, 0, g_hide_exec, "exec", g_execblock)
DEFINE_PATH_HOOK(bf_execveat,    hook_fargs5_t, 1, g_hide_exec, "exec", g_execblock)

/* newfstatat/statx before-hook = A (blacklist path-hide) only. E is an
 * AFTER-hook (below): the stat must SUCCEED, so it can't live in the before. */
DEFINE_PATH_HOOK(bf_newfstatat,  hook_fargs4_t, 1, g_hide_path, "hide", g_pathhide)
DEFINE_PATH_HOOK(bf_statx,       hook_fargs5_t, 1, g_hide_path, "hide", g_pathhide)

/* E after-hooks: on /debug_ramdisk, set st_dev+st_ino to the cached "/" values
 * (defeats su's dev/ino value-compare) and force st_nlink=2 (defeats the
 * `stat -c %h` hard-link `d` check). stat already SUCCEEDED -> no hang.
 * struct stat (arm64): st_dev@0(8) st_ino@8(8) st_mode@16(4) st_nlink@20(4).
 * struct statx: stx_nlink@0x10(4) stx_ino@0x20(8) stx_dev_major@0x88 minor@0x8C. */
static uint64_t g_root_devino[2] = { 0, 0 };  static int g_root_set = 0;       /* [0]=dev [1]=ino (newfstatat) */
static uint32_t g_rx_dev[2] = { 0, 0 }; static uint64_t g_rx_ino = 0; static int g_rx_set = 0; /* statx */

static void af_newfstatat(hook_fargs4_t *args, void *udata)
{
    char path[PATHBUF];
    char __user *sb;
    uint32_t nlink = 2;
    (void)udata;
    if (!g_enabled || g_sufake != 1 || !p_cfu || !should_hide())
        return;
    if ((long)args->ret != 0)                              /* stat failed: leave it */
        return;
    if (!copy_user_path((const char __user *)syscall_argn(args, 1), path, sizeof(path)))
        return;
    sb = (char __user *)syscall_argn(args, 2);
    if (!sb)
        return;
    if (path[0] == '/' && path[1] == 0) {                 /* "/" -> cache dev+ino (16B @0) */
        if (!p_cfu(g_root_devino, sb, 16)) g_root_set = 1;
        return;
    }
    if (is_sudev_path(path)) {                            /* /debug_ramdisk fake */
        int ok = 1;
        if (compat_copy_to_user(sb + 20, &nlink, 4) != 4) ok = 0;        /* nlink -> 2 (d) */
        if (g_root_set &&                                                /* dev+ino -> "/" (su) */
            compat_copy_to_user(sb, g_root_devino, 16) != 16) ok = 0;
        if (ok) {
            g_sufake_cnt++;
            rh_dbg("sufake", "uid=%d %s newfstatat dev/ino<-root nlink=2 (su+d defeat)",
                   (int)current_uid(), path);
        }
    }
}

static void af_statx(hook_fargs5_t *args, void *udata)
{
    char path[PATHBUF];
    char __user *sb;
    uint32_t nlink = 2;
    (void)udata;
    if (!g_enabled || g_sufake != 1 || !p_cfu || !should_hide())
        return;
    if ((long)args->ret != 0)
        return;
    if (!copy_user_path((const char __user *)syscall_argn(args, 1), path, sizeof(path)))
        return;
    sb = (char __user *)syscall_argn(args, 4);
    if (!sb)
        return;
    if (path[0] == '/' && path[1] == 0) {                 /* "/" -> cache dev major/minor + ino */
        if (!p_cfu(g_rx_dev, sb + 0x88, 8) && !p_cfu(&g_rx_ino, sb + 0x20, 8))
            g_rx_set = 1;
        return;
    }
    if (is_sudev_path(path)) {
        int ok = 1;
        if (compat_copy_to_user(sb + 0x10, &nlink, 4) != 4) ok = 0;      /* stx_nlink -> 2 */
        if (g_rx_set) {
            if (compat_copy_to_user(sb + 0x88, g_rx_dev, 8) != 8) ok = 0;/* dev major/minor */
            if (compat_copy_to_user(sb + 0x20, &g_rx_ino, 8) != 8) ok = 0;/* stx_ino */
        }
        if (ok) {
            g_sufake_cnt++;
            rh_dbg("sufake", "uid=%d %s statx dev/ino<-root nlink=2 (su+d defeat)",
                   (int)current_uid(), path);
        }
    }
}

/* ------------------------------------------------------------------ *
 * C: /proc content filter (after-hook on read / pread64), heap-free.
 *   mode 2 (maps/smaps/mounts/mountinfo/mountstats): LINE-DROP — any line
 *     containing a marker is removed and the read count shortened, so even
 *     structural detection (a bind-mount over /apex, a /debug_ramdisk mount,
 *     an injected map region) disappears, not just the literal string.
 *   mode 1 (status/cmdline): SAME-LENGTH SCRUB — blank the marker in place,
 *     keep the line (dropping a status line could confuse parsers).
 * ------------------------------------------------------------------ */
#define LINEMAX 1024               /* longest /proc line we will process */
#define RDCHUNK 256                /* stack read granularity */

static int proc_mode(const char *path)
{
    /* SELinux *_file_contexts (plat/system_ext/vendor/product/odm): RiskDetector
       DetectAdvanceRoot greps these for the `u:object_r:su_exec:s0` label to
       reverse-find a hidden su. Same-length scrub of the "su_exec" marker
       (mode 1) keeps the file size and is safe across read() boundaries.
       NOT under /proc, so checked before the /proc gate. */
    if (ci_contains(path, "file_contexts"))
        return 1;
    if (ci_index(path, "/proc/") < 0)
        return 0;
    if (ci_contains(path, "/mountinfo") || ci_contains(path, "/mountstats") ||
        ci_contains(path, "/mounts")    || ci_contains(path, "/maps")       ||
        ci_contains(path, "/smaps"))
        return 2;
    if (ci_contains(path, "/status") || ci_contains(path, "/cmdline"))
        return 1;
    return 0;
}

/* read n bytes of user mem into dst; returns #valid bytes (<=0 on failure) */
static long rd_user(char *dst, const char __user *src, long n)
{
    if (p_cfu) {
        unsigned long nc = p_cfu(dst, src, n);
        return (long)(n - nc);                  /* nc = bytes NOT copied */
    }
    return compat_strncpy_from_user(dst, src, n); /* text fallback (no NUL) */
}

/* case-insensitive bounded substring: is `nd` inside line[0..len)? */
static int line_has(const char *line, int len, const char *nd)
{
    int nl = (int)strlen(nd), j, k;
    if (nl == 0 || nl > len)
        return 0;
    for (j = 0; j + nl <= len; j++) {
        for (k = 0; k < nl && lc(line[j + k]) == lc(nd[k]); k++)
            ;
        if (k == nl)
            return 1;
    }
    return 0;
}

static int line_has_marker(const char *line, int len)
{
    /* app-private / per-app runtime paths: a marker here is just the app's own
       package name embedded in its own map/smaps line (e.g. its base.apk or
       dalvik-cache .odex) — KEEP the line, or we corrupt the app's view of its
       OWN address space (ZygiskDetector's mainpage maps-block then mis-parses ->
       "Unsupported Kernel", version not shown). Real injected libs live under
       /data/adb (not these roots) and are still dropped. Mirrors A's
       is_own_app_path(). */
    static const char *const own_roots[] = {
        "/data/app/", "/data/data/", "/data/user/", "/data/user_de/",
        "/data/misc/profiles/", "/Android/data/", "/Android/obb/",
        "/dalvik-cache/", "/data/misc/gpu/", "/data/misc/apexdata/",
    };
    int i, j, nl;
    const char *nd;
    for (i = 0; i < ARRSZ(own_roots); i++)
        if (line_has(line, len, own_roots[i]))
            return 0;
    /* keep any line that belongs to the gated app itself (explicit pkg=) */
    if (g_self_pkg[0] && line_has(line, len, g_self_pkg))
        return 0;
    for (i = 0; i < ARRSZ(proc_scrub); i++) {
        nd = proc_scrub[i];
        nl = (int)strlen(nd);
        if (nl == 0 || nl > len)
            continue;
        for (j = 0; j + nl <= len; j++) {
            int k = 0;
            while (k < nl && lc(line[j + k]) == lc(nd[k]))
                k++;
            if (k == nl)
                return 1;
        }
    }
    return 0;
}

/*
 * Line-drop pass over the user buffer. Two-phase via `commit`:
 *   commit=0 : scan only (no writes) -> returns planned new length, or
 *              -1 if unsafe (read failure or a line longer than LINEMAX).
 *   commit=1 : actually compact (write kept lines back), returns new length.
 * Compaction is in-place: write cursor (wpos) never exceeds the read cursor,
 * so we never clobber bytes we have not consumed yet.
 */
static long linedrop(char __user *ubuf, long ret, int commit)
{
    long rpos = 0, wpos = 0;
    int  ll = 0;
    char chunk[RDCHUNK];
    char line[LINEMAX];

    while (rpos < ret) {
        long want = ret - rpos;
        long got, k;
        if (want > RDCHUNK)
            want = RDCHUNK;
        got = rd_user(chunk, ubuf + rpos, want);
        if (got <= 0)
            return -1;                          /* unreadable -> leave buffer */
        for (k = 0; k < got; k++) {
            char c = chunk[k];
            if (ll >= LINEMAX - 1)
                return -1;                       /* overlong line -> bail safely */
            line[ll++] = c;
            if (c == '\n') {
                if (!line_has_marker(line, ll)) {
                    if (commit &&
                        compat_copy_to_user(ubuf + wpos, line, ll) != ll)
                        return -1;
                    wpos += ll;
                }
                ll = 0;
            }
        }
        rpos += got;
        if (got < want)
            break;
    }
    if (ll > 0) {                                /* trailing line, no newline */
        if (!line_has_marker(line, ll)) {
            if (commit && compat_copy_to_user(ubuf + wpos, line, ll) != ll)
                return -1;
            wpos += ll;
        }
    }
    return wpos;
}

/* same-length scrub (mode 1) — chunked with overlap */
static int scrub_marker(char *buf, int len, const char *needle)
{
    int nl = (int)strlen(needle);
    int hits = 0, i, j;
    if (nl == 0 || nl > len)
        return 0;
    for (i = 0; i + nl <= len; i++) {
        for (j = 0; j < nl; j++) {
            if (lc(buf[i + j]) != lc(needle[j]))
                break;
        }
        if (j == nl) {
            for (j = 0; j < nl; j++)
                buf[i + j] = 'x';
            hits++;
            i += nl - 1;
        }
    }
    return hits;
}

static void af_read(hook_fargs4_t *args, void *udata)
{
    long ret, off, n;
    int fd, i, cerr, seg, hits, mode;
    unsigned long total_hits = 0;
    char __user *ubuf;
    char pbuf[PATHBUF];
    char *resolved;
    struct file *f;
    char sb[SCRUB_CHUNK + 1];

    (void)udata;
    if (!g_enabled || !g_procfilter || !p_fget || !p_fput || !p_file_path)
        return;
    if (!should_hide())
        return;

    ret = (long)args->ret;                 /* bytes actually read */
    if (ret <= 0 || ret > MAX_SCRUB_READ)
        return;

    fd   = (int)syscall_argn(args, 0);
    ubuf = (char __user *)syscall_argn(args, 1);
    if (!ubuf)
        return;

    /* resolve fd -> path; bail unless it's a sensitive /proc file or a
       SELinux *_file_contexts (RiskDetector su_exec reverse-lookup) */
    f = p_fget(fd);
    if (!f)
        return;
    resolved = p_file_path(f, pbuf, sizeof(pbuf));
    p_fput(f);
    if (!resolved || (unsigned long)resolved >= (unsigned long)(-4095L))
        return;
    mode = proc_mode(resolved);
    if (!mode)
        return;

    /* ---- mode 2: drop whole offending lines, shorten read ---- */
    if (mode == 2) {
        long planned = linedrop(ubuf, ret, 0);   /* scan (no writes) */
        if (planned < 0 || planned == ret)
            return;                               /* unsafe, or nothing to drop */
        if (linedrop(ubuf, ret, 1) == planned) {  /* commit */
            args->ret = planned;
            g_scrub_hit++;
            rh_dbg("scrub", "uid=%d %s: line-drop %ld -> %ld bytes",
                   (int)current_uid(), resolved, ret, planned);
        }
        return;
    }

    /* ---- mode 1: same-length scrub in chunks with overlap ---- */
    off = 0;
    while (off < ret) {
        long want = ret - off;
        if (want > SCRUB_CHUNK)
            want = SCRUB_CHUNK;

        n = compat_strncpy_from_user(sb, ubuf + off, want);
        if (n <= 0)
            break;
        seg = (int)n;

        hits = 0;
        for (i = 0; i < ARRSZ(proc_scrub); i++)
            hits += scrub_marker(sb, seg, proc_scrub[i]);

        if (hits) {
            cerr = compat_copy_to_user(ubuf + off, sb, seg);  /* returns copied len */
            if (cerr != seg)
                rh_warn("scrub", "short write %d/%d (%s)", cerr, seg, resolved);
            total_hits += hits;
        }

        if (n < want)
            break;
        if (want < SCRUB_CHUNK)
            break;
        off += (SCRUB_CHUNK - SCRUB_OVL);
    }

    if (total_hits) {
        g_scrub_hit += total_hits;
        rh_dbg("scrub", "uid=%d %s: scrubbed %lu marker(s)",
               (int)current_uid(), resolved, total_hits);
    }
}

/* ------------------------------------------------------------------ *
 * D: statfs / fstatfs f_type faking (defeats checkFileSystemTypeReal:
 *    a magisk/KSU overlay on /system shows up as overlayfs/tmpfs; we
 *    report ext4 instead so the partition looks untampered).
 * ------------------------------------------------------------------ */
static int fs_path_sensitive(const char *p)
{
    int i, n;
    for (i = 0; i < ARRSZ(fs_paths); i++) {
        n = (int)strlen(fs_paths[i]);
        if (!strncmp(p, fs_paths[i], n))
            return 1;
    }
    return 0;
}

/* f_type is the first field of struct statfs (8 bytes on arm64/LP64). */
static void do_fs_fake(void __user *statbuf, const char *path)
{
    uint64_t ftype = 0, fake = EXT4_SUPER_MAGIC;
    int cerr;

    if (p_cfu) {
        if (p_cfu(&ftype, statbuf, sizeof(ftype))) {
            rh_dbg("fsfake", "%s: cannot read f_type, skip", path);
            return;                              /* read failed */
        }
        if (ftype != OVERLAYFS_SUPER_MAGIC && ftype != TMPFS_MAGIC) {
            rh_dbg("fsfake", "%s: genuine f_type=0x%llx, leave",
                   path, (unsigned long long)ftype);
            return;                              /* genuine fs, leave it */
        }
    }
    /* compat_copy_to_user returns COPIED length (==8 on success) */
    cerr = compat_copy_to_user(statbuf, &fake, sizeof(fake));
    if (cerr != (int)sizeof(fake)) {
        rh_warn("fsfake", "%s: short write %d/8", path, cerr);
        return;
    }
    g_fsfake_cnt++;
    rh_dbg("fsfake", "uid=%d %s: f_type 0x%llx -> ext4",
           (int)current_uid(), path, (unsigned long long)ftype);
}

static void af_statfs(hook_fargs2_t *args, void *udata)
{
    char path[PATHBUF];
    void __user *statbuf;
    (void)udata;
    if (!g_enabled || !g_fsfake || !should_hide())
        return;
    if ((long)args->ret != 0)                    /* statfs failed */
        return;
    if (!copy_user_path((const char __user *)syscall_argn(args, 0), path, sizeof(path)))
        return;
    if (g_diag && diag_interesting(path))
        rh_info("diag", "uid=%d statfs %s", (int)current_uid(), path);
    if (!fs_path_sensitive(path))
        return;
    statbuf = (void __user *)syscall_argn(args, 1);
    if (statbuf)
        do_fs_fake(statbuf, path);
}

static void af_fstatfs(hook_fargs2_t *args, void *udata)
{
    int fd;
    struct file *f;
    char pbuf[PATHBUF];
    char *resolved;
    void __user *statbuf;
    (void)udata;
    if (!g_enabled || !g_fsfake || !should_hide())
        return;
    if ((long)args->ret != 0)
        return;
    if (!p_fget || !p_fput || !p_file_path)      /* need fd -> path */
        return;
    fd = (int)syscall_argn(args, 0);
    f = p_fget(fd);
    if (!f)
        return;
    resolved = p_file_path(f, pbuf, sizeof(pbuf));
    p_fput(f);
    if (!resolved || (unsigned long)resolved >= (unsigned long)(-4095L))
        return;
    if (!fs_path_sensitive(resolved))
        return;
    statbuf = (void __user *)syscall_argn(args, 1);
    if (statbuf)
        do_fs_fake(statbuf, resolved);
}

/* E = stat hooks (above): mode1 after-hook clones "/" onto /debug_ramdisk (stat
 * succeeds); mode2 before-hook returns ENOENT for /debug_ramdisk. */

/* A' (map_files): readlinkat AFTER-hook. /proc/<pid>/map_files/<addr-range> are
 * symlinks whose TARGET is the mapped file's path. A detector enumerating the
 * zygote's map_files (getdents64) + readlink() sees injected libs
 * (/data/adb/.../libzygisk.so, frida-gadget, ...) — a path that NEVER goes
 * through read() on /proc/<pid>/maps, so the C scrub can't touch it, and the
 * before-hook can't either (it only matches the INPUT path, which is the
 * marker-free /proc/.../map_files/<range>). Here we run the syscall, inspect the
 * RESOLVED target, and -ENOENT the link if the target is blacklisted, so the
 * injected mapping vanishes from a map_files walk. (ZygiskDetector's
 * hooked/injected scan, KSU/Magisk-style map_files enumeration, etc.)
 * The app's own libs live under /data/app/ which path_blacklisted() exempts, so
 * a process reading its OWN map_files is unaffected. */
static void af_readlinkat(hook_fargs4_t *args, void *udata)
{
    char tgt[PATHBUF];
    char __user *ubuf;
    long ret;
    int n;
    (void)udata;
    if (!g_enabled || !g_pathhide || !p_cfu || !should_hide())
        return;
    ret = (long)args->ret;
    if (ret <= 0)                                   /* error / empty -> nothing to hide */
        return;
    /* NB: we DON'T gate on the input pathname — `ls -l` on /proc/<pid>/map_files
       calls readlinkat(dirfd, "<addr-range>", ...) AT-relative, so the pathname
       arg is the bare entry name with no "/map_files/" in it. Instead inspect the
       RESOLVED TARGET: if the symlink resolves to a blacklisted path
       (/data/adb/.../libzygisk.so, frida-gadget, ...) -ENOENT it. Covers
       map_files walks, full-path readlinks, and /proc/self/fd symlinks alike.
       The app's own libs are /data/app/ (exempted in path_blacklisted) so a
       process reading its OWN map_files/fd is unaffected. */
    n = (ret < (long)sizeof(tgt) - 1) ? (int)ret : (int)sizeof(tgt) - 1;
    ubuf = (char __user *)syscall_argn(args, 2);    /* readlinkat buf (not NUL-terminated) */
    if (!ubuf || p_cfu(tgt, ubuf, n))               /* p_cfu: 0 == fully copied */
        return;
    tgt[n] = 0;
    if (path_blacklisted(tgt)) {
        args->ret = -ENOENT;
        g_hide_path++;
        rh_dbg("hide", "uid=%d readlink-target ENOENT -> %s", (int)current_uid(), tgt);
    }
}

/* ------------------------------------------------------------------ *
 * hook registration table
 * ------------------------------------------------------------------ */
struct hookrec {
    const char *name;
    int   nr;
    int   narg;
    void *before;
    void *after;
};

static struct hookrec hooks[] = {
    { "faccessat",  __NR_faccessat,   3, (void *)bf_faccessat,  0 },
#ifdef __NR_faccessat2
    { "faccessat2", __NR_faccessat2,  4, (void *)bf_faccessat2, 0 },
#endif
    { "openat",     __NR_openat,      4, (void *)bf_openat,     0 },
    /* before = E mode2(/debug_ramdisk->ENOENT) + A(blacklist hide);
     * after  = E mode1(/debug_ramdisk stat := clone of "/") */
    { "newfstatat", __NR3264_fstatat, 4, (void *)bf_newfstatat, (void *)af_newfstatat },
#ifdef __NR_statx
    { "statx",      __NR_statx,       5, (void *)bf_statx,      (void *)af_statx },
#endif
    { "readlinkat", __NR_readlinkat,  4, (void *)bf_readlinkat, (void *)af_readlinkat },
    { "execve",     __NR_execve,      3, (void *)bf_execve,     0 },
#ifdef __NR_execveat
    { "execveat",   __NR_execveat,    5, (void *)bf_execveat,   0 },
#endif
    /* C: content scrub uses an AFTER hook on read/pread64 */
    { "read",       __NR_read,        3, 0, (void *)af_read },
#ifdef __NR_pread64
    { "pread64",    __NR_pread64,     4, 0, (void *)af_read },
#endif
    /* D: statfs f_type faking */
    { "statfs",     __NR3264_statfs,  2, 0, (void *)af_statfs },
    { "fstatfs",    __NR3264_fstatfs, 2, 0, (void *)af_fstatfs },
};

#define NHOOKS ARRSZ(hooks)
static int g_installed[NHOOKS];

static void uninstall_all(void)
{
    int i;
    for (i = 0; i < NHOOKS; i++) {
        if (g_installed[i]) {
            fp_unhook_syscalln(hooks[i].nr, hooks[i].before, hooks[i].after);
            g_installed[i] = 0;
            rh_info("exit", "unhook %s (nr=%d)", hooks[i].name, hooks[i].nr);
        }
    }
}

/* ------------------------------------------------------------------ *
 * control parsing helpers
 * ------------------------------------------------------------------ */
static long parse_long(const char *s)
{
    long v = 0;
    int neg = 0;
    while (*s == ' ')
        s++;
    if (*s == '-') { neg = 1; s++; }
    while (*s >= '0' && *s <= '9')
        v = v * 10 + (*s++ - '0');
    return neg ? -v : v;
}

static const char *starts(const char *args, const char *tok)
{
    int n = (int)strlen(tok);
    if (!strncmp(args, tok, n))
        return args + n;
    return 0;
}

/* whole string is an integer (optionally leading '-')? -> treat as a uid,
   so users can pass "10238" as well as "uid=10238". */
static int is_num(const char *s)
{
    int i = 0;
    if (!s || !s[0])
        return 0;
    if (s[0] == '-')
        i = 1;
    if (!s[i])
        return 0;
    for (; s[i]; i++)
        if (s[i] < '0' || s[i] > '9')
            return 0;
    return 1;
}

static void set_comm(const char *p)
{
    int j = 0;
    while (p[j] && p[j] != ' ' && j < (int)sizeof(g_target_comm) - 1) {
        g_target_comm[j] = p[j];
        j++;
    }
    g_target_comm[j] = 0;
}

static void set_pkg(const char *p)
{
    int j = 0;
    while (p[j] && p[j] != ' ' && j < (int)sizeof(g_self_pkg) - 1) {
        g_self_pkg[j] = p[j];
        j++;
    }
    g_self_pkg[j] = 0;
}

/* exempt=<uid> adds a trusted-tool uid (never hidden from); exempt=clear or
 * exempt=0 wipes the list. For the LSPosed parasitic-manager host etc. */
static void add_exempt(const char *p)
{
    int u, i;
    if (!strcmp(p, "clear") || !strcmp(p, "0")) { g_nexempt = 0; return; }
    if (!is_num(p)) return;
    u = (int)parse_long(p);
    if (u <= 0) return;
    for (i = 0; i < g_nexempt; i++)
        if (g_exempt_uids[i] == u) return;          /* dedup */
    if (g_nexempt < MAX_EXEMPT)
        g_exempt_uids[g_nexempt++] = u;
}

/* apply one whitespace-delimited token. Supports a full one-line config:
 *   uid=10236 pkg=wu.Zygisk.Detector pathhide=0 execblock=0 fsfake=0
 * plus convenience profiles: mode=java (Java/script detectors: A/B/D off,
 * C/E on) and mode=native (A/B/C/D on for native SDKs). Order within the
 * line does not matter — all tokens apply atomically before any syscall. */
static void apply_token(const char *t)
{
    const char *p;
    if      ((p = starts(t, "uid=")))        g_target_uid = (int)parse_long(p);
    else if ((p = starts(t, "comm=")))       set_comm(p);
    else if ((p = starts(t, "pkg=")))        set_pkg(p);
    else if ((p = starts(t, "pathhide=")))   g_pathhide  = (p[0] == '1');
    else if ((p = starts(t, "execblock=")))  g_execblock = (p[0] == '1');
    else if ((p = starts(t, "procfilter="))) g_procfilter = (p[0] == '1');
    else if ((p = starts(t, "fsfake=")))     g_fsfake    = (p[0] == '1');
    else if ((p = starts(t, "sufake=")))     g_sufake    = (p[0] >= '0' && p[0] <= '2') ? (p[0] - '0') : 1;
    else if ((p = starts(t, "verbose=")))    g_verbose   = (p[0] == '1');
    else if ((p = starts(t, "global=")))     g_global    = (p[0] == '1');
    else if ((p = starts(t, "diag=")))       g_diag      = (p[0] == '1');
    else if ((p = starts(t, "enable=")))     g_enabled   = (p[0] == '1');
    else if ((p = starts(t, "exempt=")))     add_exempt(p);
    else if (!strcmp(t, "mode=java")) {      /* ZygiskDetector/mus_love */
        g_pathhide = 0; g_execblock = 0; g_fsfake = 0; g_procfilter = 1; g_sufake = 1;
    } else if (!strcmp(t, "mode=native")) {  /* RiskDetector/Hunter/Garuda */
        g_pathhide = 1; g_execblock = 1; g_fsfake = 1; g_procfilter = 1; g_sufake = 0;
    } else if (is_num(t))                    g_target_uid = (int)parse_long(t);
}

/* apply a space-separated list of tokens, e.g. "uid=10238 pkg=wu.Zygisk.Detector" */
static void apply_args(const char *args)
{
    char tok[80];
    int j = 0;
    for (;; args++) {
        char c = *args;
        if (c == ' ' || c == 0) {
            if (j) { tok[j] = 0; apply_token(tok); j = 0; }
            if (!c) break;
        } else if (j < (int)sizeof(tok) - 1) {
            tok[j++] = c;
        }
    }
}

/* ------------------------------------------------------------------ *
 * KPM entry points
 * ------------------------------------------------------------------ */
static long riskhider_init(const char *args, const char *event, void *__user reserved)
{
    int i, ok = 0, fail = 0;
    const char *p;
    (void)event; (void)reserved;

    rh_info("init", "begin, version 1.4.6 (C scrub keeps app-own lines too), args=\"%s\"", args ? args : "");

    /* --- stage 1: resolve kernel symbols --- */
    p_fget      = (fget_t)kallsyms_lookup_name("fget");
    p_fput      = (fput_t)kallsyms_lookup_name("fput");
    p_file_path = (file_path_t)kallsyms_lookup_name("file_path");
    p_get_cmdline = (get_cmdline_t)kallsyms_lookup_name("get_cmdline");
    rh_info("init", "resolve get_cmdline=%llx (self-pkg exemption %s)",
            (unsigned long long)(uintptr_t)p_get_cmdline,
            p_get_cmdline ? "thread-safe" : "comm-only fallback");
    rh_info("init", "resolve fget=%llx fput=%llx file_path=%llx",
            (unsigned long long)(uintptr_t)p_fget,
            (unsigned long long)(uintptr_t)p_fput,
            (unsigned long long)(uintptr_t)p_file_path);
    if (!p_fget || !p_fput || !p_file_path) {
        g_procfilter = 0;
        rh_warn("init", "fget/fput/file_path missing -> /proc scrub (C) DISABLED");
    }

    /* try several names across kernel versions for reading 8 binary bytes */
    p_cfu = (cfu_t)kallsyms_lookup_name("_copy_from_user");
    if (!p_cfu) p_cfu = (cfu_t)kallsyms_lookup_name("copy_from_user");
    if (!p_cfu) p_cfu = (cfu_t)kallsyms_lookup_name("__copy_from_user");
    if (!p_cfu) p_cfu = (cfu_t)kallsyms_lookup_name("raw_copy_from_user");
    if (!p_cfu) p_cfu = (cfu_t)kallsyms_lookup_name("__arch_copy_from_user");
    rh_info("init", "resolve copy_from_user=%llx%s",
            (unsigned long long)(uintptr_t)p_cfu,
            p_cfu ? "" : " (statfs fake will rewrite unconditionally)");

    /* --- stage 2: apply load-time args, e.g. "uid=10238 pkg=wu.Zygisk.Detector" --- */
    if (args && args[0])
        apply_args(args);
    (void)p;
    rh_info("init", "gate uid=%d comm=\"%s\" self_pkg=\"%s\"",
            g_target_uid, g_target_comm, g_self_pkg);

    /* --- stage 3: install hooks --- */
    for (i = 0; i < NHOOKS; i++) {
        hook_err_t err = fp_hook_syscalln(hooks[i].nr, hooks[i].narg,
                                          hooks[i].before, hooks[i].after, 0);
        if (err == HOOK_NO_ERR) {
            g_installed[i] = 1;
            ok++;
            rh_info("init", "hook +%-10s nr=%-3d narg=%d %s",
                    hooks[i].name, hooks[i].nr, hooks[i].narg,
                    hooks[i].before ? "(before)" : "(after)");
        } else {
            fail++;
            rh_err("init", "hook +%s nr=%d FAILED err=%d",
                   hooks[i].name, hooks[i].nr, err);
        }
    }

    rh_info("init", "done: %d/%d hooks, enabled=%d pathhide=%d execblock=%d procfilter=%d fsfake=%d",
            ok, NHOOKS, g_enabled, g_pathhide, g_execblock, g_procfilter, g_fsfake);
    return 0;
}

static long riskhider_control0(const char *args, char *__user out_msg, int outlen)
{
    char msg[448];
    int n, cerr;
    const char *p;

    rh_info("ctl", "recv \"%s\"", args ? args : "");

    if (args && args[0]) {
        if      (!strcmp(args, "enable"))         g_enabled = 1;
        else if (!strcmp(args, "disable"))        g_enabled = 0;
        else if (!strcmp(args, "verbose on"))     g_verbose = 1;
        else if (!strcmp(args, "verbose off"))    g_verbose = 0;
        else if (!strcmp(args, "procfilter on"))  g_procfilter = (p_fget && p_fput && p_file_path);
        else if (!strcmp(args, "procfilter off")) g_procfilter = 0;
        else if (!strcmp(args, "fsfake on"))      g_fsfake = 1;
        else if (!strcmp(args, "fsfake off"))     g_fsfake = 0;
        else if (!strcmp(args, "pathhide on"))    g_pathhide = 1;
        else if (!strcmp(args, "pathhide off"))   g_pathhide = 0;
        else if (!strcmp(args, "execblock on"))   g_execblock = 1;
        else if (!strcmp(args, "execblock off"))  g_execblock = 0;
        else if (!strcmp(args, "sufake on"))      g_sufake = 1;
        else if (!strcmp(args, "sufake off"))     g_sufake = 0;
        else if (!strcmp(args, "status"))         { /* report below */ }
        else                                      apply_args(args); /* uid=/comm=/pkg=/num (space-sep) */
    }
    (void)p;

    n = snprintf(msg, sizeof(msg),
        "riskhider: enabled=%d pathhide=%d execblock=%d procfilter=%d fsfake=%d sufake=%d verbose=%d\n"
        "  uid=%d comm=\"%s\" pkg=\"%s\"\n"
        "  hidden_paths=%lu blocked_execs=%lu scrubbed_markers=%lu fs_faked=%lu su_enoent=%lu\n",
        g_enabled, g_pathhide, g_execblock, g_procfilter, g_fsfake, g_sufake, g_verbose,
        g_target_uid, g_target_comm, g_self_pkg,
        g_hide_path, g_hide_exec, g_scrub_hit, g_fsfake_cnt, g_sufake_cnt);

    rh_info("ctl", "state en=%d glob=%d A=%d B=%d C=%d D=%d E=%d uid=%d exempt=%d pkg=\"%s\" | hide=%lu exec=%lu scrub=%lu fs=%lu su=%lu",
            g_enabled, g_global, g_pathhide, g_execblock, g_procfilter, g_fsfake, g_sufake,
            g_target_uid, g_nexempt, g_self_pkg,
            g_hide_path, g_hide_exec, g_scrub_hit, g_fsfake_cnt, g_sufake_cnt);

    if (out_msg && outlen > 0) {
        if (n >= outlen)
            n = outlen - 1;
        cerr = compat_copy_to_user(out_msg, msg, n + 1);
        if (cerr)
            rh_warn("ctl", "copy_to_user left %d bytes", cerr);
    }
    return 0;
}

static long riskhider_exit(void *__user reserved)
{
    (void)reserved;
    rh_info("exit", "begin");
    uninstall_all();
    rh_info("exit", "done: hide=%lu exec=%lu scrub=%lu fs=%lu",
            g_hide_path, g_hide_exec, g_scrub_hit, g_fsfake_cnt);
    return 0;
}

KPM_INIT(riskhider_init);
KPM_CTL0(riskhider_control0);
KPM_EXIT(riskhider_exit);
