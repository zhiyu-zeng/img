#!/system/bin/sh
# load_riskhider.sh — one-tap load + gate riskhider.kpm to a target app,
# using the bundled rhctl supercall tool (no kpatch/apd-kpm needed).
#
# KPM supercalls require an AUTHENTICATED caller -> you MUST supply your real
# APatch SuperKey (the literal "su" does NOT work for KPM). Find/Set it in the
# APatch Manager (Settings -> SuperKey).
#
# Push everything, then run as root with your key:
#   adb push riskhider.kpm rhctl load_riskhider.sh unload_riskhider.sh /data/local/tmp/
#   adb shell su -c 'SUPERKEY=YOUR_KEY sh /data/local/tmp/load_riskhider.sh'
#
# Override package / kpm path:
#   SUPERKEY=KEY sh load_riskhider.sh <package> [/path/to/riskhider.kpm]

PKG="${1:-io.liankong.riskdetector}"
KPM="${2:-/data/local/tmp/riskhider.kpm}"
KEY="${SUPERKEY:-}"
NAME="riskhider"
DIR="$(dirname "$0")"

say() { echo "[riskhider] $*"; }

[ "$(id -u)" = "0" ] || { say "ERROR: run as root (su)"; exit 1; }
if [ -z "$KEY" ]; then
    say "ERROR: SuperKey required. Run:  SUPERKEY=<your_apatch_superkey> sh $0"
    exit 1
fi

# --- locate rhctl (the supercall tool) ---
RHCTL=""
for c in /data/local/tmp/rhctl "$DIR/rhctl" ./rhctl "$(command -v rhctl 2>/dev/null)"; do
    [ -n "$c" ] && [ -f "$c" ] && { RHCTL="$c"; break; }
done
[ -z "$RHCTL" ] && { say "ERROR: rhctl not found (push it to /data/local/tmp/)"; exit 1; }
chmod 0755 "$RHCTL" 2>/dev/null
rh() { "$RHCTL" "$KEY" "$@"; }

say "rhctl   = $RHCTL"
say "package = $PKG"
say "kpm     = $KPM"
[ -f "$KPM" ] || { say "ERROR: kpm not found: $KPM"; exit 1; }

# --- verify the SuperKey works before anything else ---
if ! rh hello | grep -q "key valid"; then
    say "ERROR: SuperKey rejected (rhctl hello failed). Check the key in APatch Manager."
    exit 1
fi

# --- resolve the app uid ---
UID_VAL="$(stat -c %u "/data/data/$PKG" 2>/dev/null)"
[ -z "$UID_VAL" ] && UID_VAL="$(stat -c %u "/data/user/0/$PKG" 2>/dev/null)"
if [ -z "$UID_VAL" ]; then
    UID_VAL="$(pm list packages -U 2>/dev/null | tr ' ' '\n' \
               | awk -F: -v p="$PKG" '/^package:/{cur=$2} /^uid:/{if(cur==p)print $2}')"
fi
[ -z "$UID_VAL" ] && { say "ERROR: could not resolve uid for $PKG (installed?)"; exit 1; }
say "resolved uid = $UID_VAL"

# --- (re)load ---
say "unloading any existing instance ..."
rh unload "$NAME" >/dev/null 2>&1
say "loading with uid=$UID_VAL ..."
rh load "$KPM" "uid=$UID_VAL"

# --- gate at runtime (belt & suspenders) ---
rh control "$NAME" "uid=$UID_VAL" >/dev/null 2>&1
rh control "$NAME" "comm="        >/dev/null 2>&1   # drop default comm gate -> uid-only
rh control "$NAME" "verbose on"   >/dev/null 2>&1

# --- report ---
say "----- status -----"
rh control "$NAME" "status"
say "----- recent kernel log -----"
dmesg | grep 'riskhider\[' | tail -n 25
say "done. Launch $PKG, then:  dmesg | grep 'riskhider\\['"
