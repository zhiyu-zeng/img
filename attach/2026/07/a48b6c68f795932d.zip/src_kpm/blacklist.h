/*
 * blacklist.h — detection-artifact tables for riskhider.kpm
 *
 * Data distilled from the reverse-engineering reports of FOUR detectors:
 *   - libriskdetector.so   (momo/riskdetector_*.md)            native JNI risk SDK
 *   - mus_love / Detector  (Detector docs/analysis .md set)     MVEL-script detector
 *   - Hunter v6.58         (文档/Hunter分析.md)                 libhunter.so RASP
 *   - GarudaDefender       (文档/GarudaDefender_*.md)           native RASP
 *
 * Matching is CASE-INSENSITIVE substring unless the table says suffix.
 * All matching is gated to the target app (see riskhider.c should_hide()),
 * so even broad tokens cannot affect unrelated processes.
 */
#ifndef RISKHIDER_BLACKLIST_H
#define RISKHIDER_BLACKLIST_H

/* ------------------------------------------------------------------ *
 * 1. PATH-EXISTENCE blacklist.
 *    If a gated process stat/access/open/readlink/exec's a path that
 *    matches any token here, the syscall returns -ENOENT.
 *    Covers: isFileExists(3198), DetectAdvanceRoot, checkXpFiles,
 *            Hunter checkRiskFile, Garuda file probes, emulator files.
 * ------------------------------------------------------------------ */

/* substring tokens (case-insensitive) */
static const char *const bl_substr[] = {
    /* --- su / magisk / busybox / generic root --- */
    "magisk",            /* magisk, magiskpolicy, .magisk, magisk.rc, MagiskManager ... */
    "supersu",
    "superuser",         /* Superuser.apk, com.thirdparty.superuser */
    "busybox",
    "/data/adb",         /* magisk/KSU/APatch data root (modules, ap, kpatch, lspd, su_path) */
    "/debug_ramdisk",    /* Hunter: /debug_ramdisk(/su) */
    "kpatch",
    "/su/bin",

    /* --- KernelSU / APatch / SukiSU family --- */
    "kernelsu",          /* kernelsu, kernelSu (ci) */
    "apatch",            /* apatch, Apatch, APatch (ci) */
    "sukisu",
    "neozygisk",

    /* --- Xposed / LSPosed / hook frameworks --- */
    "xposed",            /* xposed, edxposed, LSPosed dirs (ci) */
    "lsposed",
    "riru",              /* /riru, riru- */
    "/edxp",
    "zygisk",            /* zygisk, neozygisk, zygisk_lsposed */
    "shamiko",
    "dreamland",
    "substrate",
    "sandhook",
    "whale",
    "dexposed",
    "revanced",

    /* --- frida / instrumentation --- */
    "frida",             /* frida-server, frida-agent, re.frida.server, /memfd:frida */
    "gum-js",
    "linjector",
    "gadget",
    "qbdi",
    "rustfrida",

    /* --- screen-cast / automation / cloud-test tooling (Hunter/RiskDetector) --- */
    "scrcpy",
    "minicap",
    "minitouch",
    "vysor",
    "uiautomator",
    "mobileagent",
    "mobileanjian",
    "cloudtesting",
    "cloudtestig",       /* typo present in Hunter rule */
    "cloudscreen",
    "touchserver",
    "touchservice",
    "maxpresent",
    "screen-shread",
    "yijianwan",
    "juejinazykb",
    "libagent.so",       /* Garuda: /data/local/tmp/libagent.so */
    "mobile_info.properties",
    "shizuku",
    "mainputjar",        /* Hunter §15: /data/local/tmp/tc/mainputjar7 (按键精灵) */
    "yijianwanservice",  /* Hunter §15: /data/local/tmp/yijianwanservice.apk */
    "/data/local/tmp/tc/",  /* Hunter §15: tc/ 触动自动化目录 */

    /* --- shizuku / virtual-location / hide-tools / misc managers (pkg dirs) --- */
    "rootcloak",
    "hideroot",
    "hidemyapplist",
    "privacyspace",
    ".anywhere",         /* com.txy.anywhere */
    "xprivacy",
    "pdroid",
    "anylocation",
    "doubee.ig",
    "apk008",
    /* root-manager packages — use DISTINCTIVE full fragments, NOT bare author
       names. (A bare author like "vvb2060" also matches that author's *other*
       apps, e.g. io.github.vvb2060.mahoshojo, and would ENOENT the gated app's
       OWN files -> it can't load itself -> crash. magisk/kernelsu/apatch/xposed/
       supersu/dreamland already cover the managers from those authors.) */
    "ksunext",           /* com.rifsxd.ksunext */
    "weishu.exp",        /* me.weishu.exp (Xposed Installer) */
    "zako.zako",         /* zako.zako.zako (KSU manager) */

    /* --- third-party ROM markers --- */
    "lineage",
    "aospa",
    "paranoid",

    /* --- emulator / cloud-phone specific files --- */
    "noxspeedup",
    "nox-prop",
    "enable_nox",
    "shellnox",
    "microvirt",
    "droid4x",
    "bluestacks",
    "genymotion",
    "windroy",           /* windroyed, libGLESv2_windroye */
    "tiantianvm",
    "tiantian.sh",
    "xiaopivm",
    "xxzs_prop",
    "vmos",
    "vbox",              /* vboxguest, vboxuser, vboxsf, init.vbox2345 */
    "ldplayer",
    "x8.prop",
    "51.prop",
    "adreno_config.txt", /* RiskDetector emulator GPU cfg probe */
    "/docker",           /* Hunter getZhenxiInfoK cloud/container marker */
    "/lxc",              /* Hunter getZhenxiInfoK cloud/container marker */
};

/* suffix tokens (case-insensitive, path must END with this) */
static const char *const bl_suffix[] = {
    "/su",               /* /system/bin/su, /apex/.../su, /sbin/su ... */
    "/magisk",
    "/magiskpolicy",
    "/daemonsu",
    "/.has_su_daemon",
};

/* ------------------------------------------------------------------ *
 * 2. /proc CONTENT scrub markers.
 *    When a gated process read()s /proc/<pid>/{maps,smaps,status,
 *    mounts,mountinfo} or /proc/<pid>/task/<tid>/{status,maps}, any
 *    occurrence of these tokens in the returned buffer is overwritten
 *    in place with same-length filler so indexOf()/strstr() miss it.
 *
 *    Same-length overwrite keeps byte offsets & read counts stable
 *    (important: mus_love/Hunter rely on indexOf position, and some
 *    readers re-read/seek). We deliberately do NOT touch permission
 *    fields (rwxp) or generic legit tokens (dex2oat, /lib/arm64/).
 *
 *    NOTE: with a pure-kernel hide (no userspace agent injected) most
 *    of these never appear in the target's maps to begin with — this
 *    is defense-in-depth for leakage from KSU/APatch mounts.
 * ------------------------------------------------------------------ */
static const char *const proc_scrub[] = {
    "magisk",
    "zygisk",
    "neozygisk",
    "frida",
    "rustfrida",
    "gadget",            /* RiskEngine nativeCheckHooks maps scan: maps:gadget (frida-gadget) */
    "xposed",            /* RiskEngine/Launch maps scan: maps:xposed (EdXposed/Xposed) */
    "lsposed",
    "riru",
    "edxp",
    "apatch",
    "kernelsu",
    "sukisu",
    "shamiko",
    "revanced",
    "zloader",
    "toybox",
    "substrate",
    "linjector",
    "gum-js-loop",
    "gmain",
    "qbdi",
    "/data/adb",
    "/adb/modules",      /* mountinfo root field shows /adb/modules (no /data prefix) */
    "/debug_ramdisk",    /* Hunter mountinfo/AVC marker; APatch tmpfs */
    "dex2oat",           /* Hunter §6.2.4 mount marker (18-marker vector) */
    "/appwidget",        /* Hunter §6.2.4 mount marker */
    "signkiller",
    "su_exec",           /* RiskDetector DetectAdvanceRoot: reverse-looks-up su via the
                            `u:object_r:su_exec:s0` label in SELinux *_file_contexts.
                            Scrubbed there (see proc_mode -> file_contexts). Harmless in /proc. */
};

/* ------------------------------------------------------------------ *
 * 3. statfs faking targets.
 *    If a gated process statfs()/fstatfs()'s a path under one of these
 *    mounts and the filesystem type comes back as overlayfs / tmpfs
 *    (the signature of a magisk/KSU overlay), riskhider rewrites f_type
 *    to a normal read-only fs (ext4) so checkFileSystemTypeReal-style
 *    "is /system tampered?" tests see a clean mount.
 *    Matched as a path PREFIX.
 * ------------------------------------------------------------------ */
static const char *const fs_paths[] = {
    "/system",
    "/system_ext",
    "/vendor",
    "/product",
    "/odm",
    "/prism",
    "/optics",
};

/* sensitive /proc basenames that trigger content scrubbing.
   matched as substrings of the resolved fd path. */
static const char *const proc_paths[] = {
    "/maps",
    "/smaps",
    "/status",
    "/mounts",
    "/mountinfo",
    "/mountstats",
    "/cmdline",
};

/* ------------------------------------------------------------------ *
 * 6. TRUSTED-TOOL whitelist (global mode only).
 *    In `global=1` the gate fires for EVERY app uid (10000-19999 / 90000-99999),
 *    which also catches the user's OWN root/hook tooling — and hiding /data/adb
 *    + scrubbing maps/map_files from THEM breaks them (LSPosed manager can't read
 *    /data/adb/lspd, LSPlant can't find its own injected lib, HMA/APatch manager
 *    lose their config). These are NOT detectors, so should_hide() returns 0 when
 *    the process comm matches any token here. Matched as case-insensitive
 *    substring of get_task_comm() (the app process name, truncated to 15 chars).
 *    NB: detector packages never contain these tool names, so this can't
 *    accidentally un-hide a detector. The LSPosed PARASITIC manager runs in a
 *    host process with an arbitrary comm -> not catchable by name; use the
 *    runtime `exempt=<uid>` knob for that host. */
static const char *const trusted_comm[] = {
    "bmax.apatch",       /* me.bmax.apatch (APatch manager) -> comm "me.bmax.apatch" */
    "topjohnwu.magis",   /* com.topjohnwu.magisk (Magisk manager) */
    "tsng.hidemy",       /* com.tsng.hidemyapplist (HMA) -> comm "com.tsng.hidemy" */
    "lsposed",           /* org.lsposed.manager / lsposed daemon host */
    "rifsxd.ksunext",    /* KernelSU Next manager */
    "sukisu",            /* SukiSU manager */
};

#define ARRSZ(a) (int)(sizeof(a) / sizeof((a)[0]))

#endif /* RISKHIDER_BLACKLIST_H */
