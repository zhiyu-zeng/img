#!/system/bin/sh
# unload_riskhider.sh — dump final stats then unload, via rhctl.
#   adb shell su -c 'SUPERKEY=YOUR_KEY sh /data/local/tmp/unload_riskhider.sh'
NAME="riskhider"
KEY="${SUPERKEY:-}"
DIR="$(dirname "$0")"

[ -z "$KEY" ] && { echo "[riskhider] ERROR: SUPERKEY=<your_apatch_superkey> required"; exit 1; }

RHCTL=""
for c in /data/local/tmp/rhctl "$DIR/rhctl" ./rhctl "$(command -v rhctl 2>/dev/null)"; do
    [ -n "$c" ] && [ -f "$c" ] && { RHCTL="$c"; break; }
done
[ -z "$RHCTL" ] && { echo "[riskhider] rhctl not found"; exit 1; }
chmod 0755 "$RHCTL" 2>/dev/null
rh() { "$RHCTL" "$KEY" "$@"; }

echo "[riskhider] final status before unload:"
rh control "$NAME" "status" 2>/dev/null
rh unload "$NAME"
echo "[riskhider] unloaded; exit log:"
dmesg | grep 'riskhider\[exit\]' | tail -n 8
