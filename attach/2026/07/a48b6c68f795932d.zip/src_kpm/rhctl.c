/*
 * rhctl.c — minimal KernelPatch supercall CLI for managing riskhider.kpm.
 *
 * Why this exists: this APatch build ships no `kpatch` binary, and `apd` has
 * no `kpm` subcommand. KPM management goes through the KernelPatch supercall
 * (syscall 45) directly. KPM commands require an AUTHENTICATED caller, i.e.
 * the REAL SuperKey (the literal "su" only works for non-KPM calls). So you
 * must pass your APatch SuperKey as <key>.
 *
 * Build (host, NDK):
 *   aarch64-linux-android34-clang rhctl.c -O2 -o rhctl
 *
 * Usage (on device, as root):
 *   rhctl <superkey> hello                      # verify key (expects HELLO magic)
 *   rhctl <superkey> num                        # number of loaded KPMs
 *   rhctl <superkey> load   <path.kpm> [args]   # e.g. args = "uid=10243"
 *   rhctl <superkey> unload <name>
 *   rhctl <superkey> control <name> "<ctlargs>" # e.g. "status", "verbose on"
 */
#include <stdio.h>
#include <string.h>
#include <unistd.h>
#include <sys/syscall.h>

#define NR_SUPERCALL      45          /* KP repurposes syscall 45 (truncate) */
#define SC_HELLO          0x1000
#define SC_KPM_LOAD       0x1020
#define SC_KPM_UNLOAD     0x1021
#define SC_KPM_CONTROL    0x1022
#define SC_KPM_NUMS       0x1030
#define HELLO_MAGIC       0x11581158L

/* low 16 bits = cmd; upper bits (version / 0x1158 tag) are not enforced by the
 * kernel dispatcher, but we replicate the 0x1158 marker for forward-compat. */
static long vcmd(long cmd)
{
    return ((long)0x1158 << 16) | (cmd & 0xFFFF);
}

static void usage(void)
{
    fprintf(stderr,
        "usage: rhctl <superkey> <cmd> ...\n"
        "  hello\n"
        "  num\n"
        "  load   <path.kpm> [args]\n"
        "  unload <name>\n"
        "  control <name> \"<ctlargs>\"\n");
}

int main(int argc, char **argv)
{
    if (argc < 3) { usage(); return 2; }
    const char *key = argv[1];
    const char *cmd = argv[2];

    if (!strcmp(cmd, "hello")) {
        long r = syscall(NR_SUPERCALL, key, vcmd(SC_HELLO));
        printf("hello=0x%lx %s\n", r,
               r == HELLO_MAGIC ? "(OK: key valid)" : "(BAD key, or KP not installed)");
        return r == HELLO_MAGIC ? 0 : 1;
    }
    if (!strcmp(cmd, "num")) {
        long r = syscall(NR_SUPERCALL, key, vcmd(SC_KPM_NUMS));
        printf("num=%ld\n", r);
        return r < 0 ? 1 : 0;
    }
    if (!strcmp(cmd, "load")) {
        if (argc < 4) { usage(); return 2; }
        const char *path = argv[3];
        const char *args = (argc > 4) ? argv[4] : "";
        long r = syscall(NR_SUPERCALL, key, vcmd(SC_KPM_LOAD), path, args, (void *)0);
        printf("load=%ld%s\n", r, r == 0 ? " (ok)" : " (fail; -13=EPERM bad key, see dmesg)");
        return r == 0 ? 0 : 1;
    }
    if (!strcmp(cmd, "unload")) {
        if (argc < 4) { usage(); return 2; }
        long r = syscall(NR_SUPERCALL, key, vcmd(SC_KPM_UNLOAD), argv[3], (void *)0);
        printf("unload=%ld%s\n", r, r == 0 ? " (ok)" : "");
        return r == 0 ? 0 : 1;
    }
    if (!strcmp(cmd, "control")) {
        if (argc < 5) { usage(); return 2; }
        char out[2048];
        out[0] = 0;
        long r = syscall(NR_SUPERCALL, key, vcmd(SC_KPM_CONTROL),
                         argv[3], argv[4], out, (long)sizeof(out));
        if (out[0])
            fputs(out, stdout);
        printf("control=%ld%s\n", r, r == 0 ? "" : " (fail)");
        return r == 0 ? 0 : 1;
    }

    usage();
    return 2;
}
