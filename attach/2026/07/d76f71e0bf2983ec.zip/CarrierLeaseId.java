package com.github.unidbg.thread.runtime;

/** Immutable backend-driving lease identity for one exact invocation. */
public final class CarrierLeaseId {

    private final RuntimeInvocationId invocationId;
    private final long serial;

    CarrierLeaseId(RuntimeInvocationId invocationId, long serial) {
        if (invocationId == null) {
            throw new NullPointerException("invocationId");
        }
        if (serial <= 0L) {
            throw new IllegalArgumentException("carrier lease serial must be positive");
        }
        this.invocationId = invocationId;
        this.serial = serial;
    }

    public RuntimeInvocationId getInvocationId() {
        return invocationId;
    }

    public long getSerial() {
        return serial;
    }

    @Override
    public boolean equals(Object other) {
        if (!(other instanceof CarrierLeaseId)) {
            return false;
        }
        CarrierLeaseId that = (CarrierLeaseId) other;
        return serial == that.serial && invocationId.equals(that.invocationId);
    }

    @Override
    public int hashCode() {
        return 31 * invocationId.hashCode() + (int) (serial ^ (serial >>> 32));
    }
}
