package com.github.unidbg.thread.runtime;

public final class TaskThreadBinding {

    private final String taskIdentity;
    private final long taskGeneration;
    private final ThreadIncarnationId threadId;
    private final ThreadBirthRecord birthRecord;
    private final TaskBindingKind kind;
    private final long bindingEpoch;
    private long unbindEpoch;
    private boolean bound = true;

    TaskThreadBinding(String taskIdentity, long taskGeneration, ThreadIncarnationId threadId,
                      ThreadBirthRecord birthRecord, long bindingEpoch) {
        if (taskIdentity == null || taskIdentity.trim().isEmpty()) {
            throw new IllegalArgumentException("task identity is required");
        }
        if (taskGeneration <= 0L) {
            throw new IllegalArgumentException("task generation must be positive");
        }
        if (threadId == null) {
            throw new NullPointerException("threadId");
        }
        if (birthRecord == null) {
            throw new NullPointerException("birthRecord");
        }
        if (bindingEpoch <= 0L) {
            throw new IllegalArgumentException("binding epoch must be positive");
        }
        if (!threadId.getRunId().equals(birthRecord.getRunId())) {
            throw new IllegalArgumentException("binding birth belongs to another run");
        }
        this.taskIdentity = taskIdentity.trim();
        this.taskGeneration = taskGeneration;
        this.threadId = threadId;
        this.birthRecord = birthRecord;
        this.kind = birthRecord.getSource() == ThreadBirthSource.SYNTHETIC_CARRIER
                ? TaskBindingKind.SYNTHETIC_CARRIER : TaskBindingKind.NATIVE_THREAD;
        this.bindingEpoch = bindingEpoch;
    }

    public String getTaskIdentity() {
        return taskIdentity;
    }

    public long getTaskGeneration() {
        return taskGeneration;
    }

    public ThreadIncarnationId getThreadId() {
        return threadId;
    }

    public ThreadBirthRecord getBirthRecord() {
        return birthRecord;
    }

    public TaskBindingKind getKind() {
        return kind;
    }

    public long getBindingEpoch() {
        return bindingEpoch;
    }

    public synchronized boolean isBound() {
        return bound;
    }

    public synchronized long getUnbindEpoch() {
        return unbindEpoch;
    }

    synchronized void markUnbound(long sequence) {
        if (!bound || sequence <= bindingEpoch) {
            throw new IllegalStateException("invalid task binding unbind sequence");
        }
        bound = false;
        unbindEpoch = sequence;
    }
}
