# 核心架构代码附件

这组 Java 文件是 Guest Thread Runtime 的脱敏阅读切片，服务于文章中的对象模型和生命周期说明。

## 阅读顺序

1. `RunContext.java`：Run 级组合根，以及 authority、生命周期和失效边界。
2. `GuestThreadIncarnation.java`、`TaskThreadBinding.java`、`ThreadIdentityProvider.java`：GuestThread 身份、线程 incarnation 和 Task 绑定。
3. `RuntimeInvocation.java`、`InvocationContinuation.java`：一次调用、重入和 continuation。
4. `StackRegion.java`、`CarrierLeaseId.java`、`CarrierLease.java`：物理 stack、carrier lease 和 backend 驾驶权。
5. `AdmissionReceipt.java`、`CarrierRetirementReceipt.java`：入场与退役的不可变证据。
6. `RunWaitGraph.java`、`TerminalEvidenceLedger.java`：等待关系和退役后的终态证据。

## 脱敏与范围

- 本目录只保留通用运行时概念，不包含具体应用、命令编号、网络目标、密钥、签名参数或业务数据。
- readiness authority、角色标签和 callback 标签已改为通用名称；这也是为什么部分类型名与工程源码不同。
- 这些文件刻意作为阅读切片提供，不保证脱离 unidbg 工程依赖后独立编译。它们的重点是 owner、identity、receipt、epoch 和 cleanup 的关系。
- 附件中的 `BoundaryReadinessAuthority` 是对原工程 readiness authority 的脱敏命名，不代表另一个独立实现。
