package com.github.unidbg.thread.runtime;

/**
 * Thread-owned stack address range. The low boundary carries the canary; the
 * backend context itself remains physically owned by the bound bound carrier task.
 */
public final class StackRegion {

    private final long lowerBound;
    private final long top;
    private final long canary;
    private long highWaterMark;
    private boolean faulted;

    StackRegion(long lowerBound, long top, long canary) {
        if (lowerBound <= 0L || top <= lowerBound) {
            throw new IllegalArgumentException("invalid stack range");
        }
        if (canary == 0L) {
            throw new IllegalArgumentException("stack canary must be non-zero");
        }
        this.lowerBound = lowerBound;
        this.top = top;
        this.canary = canary;
        this.highWaterMark = top;
    }

    public long getLowerBound() {
        return lowerBound;
    }

    public long getTop() {
        return top;
    }

    public long getCanary() {
        return canary;
    }

    public synchronized long getHighWaterMark() {
        return highWaterMark;
    }

    public synchronized boolean isFaulted() {
        return faulted;
    }

    public boolean contains(long stackPointer) {
        return stackPointer > lowerBound && stackPointer <= top;
    }

    public boolean overlaps(StackRegion other) {
        if (other == null) {
            return false;
        }
        return lowerBound < other.top && other.lowerBound < top;
    }

    synchronized boolean recordStackPointer(long stackPointer) {
        if (faulted || !contains(stackPointer)) {
            faulted = true;
            return false;
        }
        if (stackPointer < highWaterMark) {
            highWaterMark = stackPointer;
        }
        return true;
    }

    synchronized boolean verifyCanary(long observedCanary) {
        if (faulted || observedCanary != canary) {
            faulted = true;
            return false;
        }
        return true;
    }

    synchronized void markFaulted() {
        faulted = true;
    }

    boolean matches(long lower, long stackTop, long expectedCanary) {
        return lowerBound == lower && top == stackTop && canary == expectedCanary;
    }
}
