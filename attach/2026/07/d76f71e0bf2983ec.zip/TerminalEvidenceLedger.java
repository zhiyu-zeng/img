package com.github.unidbg.thread.runtime;

import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * Run-owned immutable terminal evidence ledger. Survives carrier retirement so
 * readiness actual evidence remains available at quiescent (liveAdmissionCount==0)
 * moments. Ordinary callers cannot forge entries without exact AdmissionReceipt +
 * CarrierRetirementReceipt identities.
 *
 * <p>Does not reverse-depend on application-specific/test packages; production graph producers and
 * synthetic contracts both call the typed publish APIs.
 */
public final class TerminalEvidenceLedger {

    private final RunContext run;
    private final Map<String, NativeTerminalEvidence> nativeByExactKey = new LinkedHashMap<>();
    private final Map<String, ScenarioNodeId> nativeNodeByReceiptIdentity = new LinkedHashMap<>();
    private final Map<ScenarioNodeId, List<NativeTerminalEvidence>> nativeByNode = new LinkedHashMap<>();
    private final Map<String, HostStateEvidence> hostByExactKey = new LinkedHashMap<>();
    private final Map<ScenarioNodeId, List<HostStateEvidence>> hostByNode = new LinkedHashMap<>();
    private long nextHostProducerSequence = 1L;

    TerminalEvidenceLedger(RunContext run) {
        if (run == null) {
            throw new NullPointerException("run");
        }
        this.run = run;
    }

    /**
     * Publishes exact native terminal evidence for one ScenarioNodeId. Requires a
     * final AdmissionReceipt and a matching dispatcher retirement receipt. Duplicate
     * exact keys fail closed; distinct ScenarioNodeIds with the same command remain
     * independent.
     */
    public synchronized NativeTerminalEvidence publishNativeTerminal(ScenarioNodeId nodeId,
                                                                     AdmissionReceipt admission,
                                                                     CarrierRetirementReceipt retirement) {
        if (nodeId == null || admission == null || retirement == null) {
            throw new NullPointerException("native terminal publish");
        }
        if (run.getStateSnapshot() != RunState.ACTIVE
                && run.getStateSnapshot() != RunState.QUIESCING) {
            throw new ThreadRuntimeIntegrityException(
                    "terminal evidence publish requires ACTIVE or QUIESCING run");
        }
        if (!run.getId().equals(admission.getRunId())) {
            throw new ThreadRuntimeIntegrityException("terminal evidence admission foreign run");
        }
        // Authority-issued retirement must match carrier/invocation/lease.
        CarrierRetirementReceipt issued =
                run.getCarrierLeaseRegistry().getRetirementReceipt(admission.getCarrier());
        if (issued == null) {
            throw new ThreadRuntimeIntegrityException(
                    "native terminal publish requires dispatcher CarrierRetirementReceipt");
        }
        if (issued.getDispatcherSequence() != retirement.getDispatcherSequence()
                || !issued.getLeaseId().equals(retirement.getLeaseId())
                || !issued.getInvocationId().equals(retirement.getInvocationId())
                || issued.getCarrier() != admission.getCarrier()) {
            throw new ThreadRuntimeIntegrityException(
                    "native terminal publish retirement is not the authority-issued receipt");
        }
        if (!issued.getInvocationId().equals(admission.getInvocationId())
                || admission.getLeaseId() == null
                || !admission.getLeaseId().equals(issued.getLeaseId())) {
            throw new ThreadRuntimeIntegrityException(
                    "native terminal publish admission/retirement identity mismatch");
        }
        // Prefer authority final (live or retired) identity for generation/sequence.
        AdmissionReceipt authorityFinal =
                run.getCarrierAdmissionAuthority().findRetiredFinalReceipt(admission.getCarrier());
        if (authorityFinal == null) {
            authorityFinal =
                    run.getCarrierAdmissionAuthority().findLiveFinalReceipt(admission.getCarrier());
        }
        if (authorityFinal == null) {
            throw new ThreadRuntimeIntegrityException(
                    "native terminal publish requires authority final AdmissionReceipt");
        }
        if (authorityFinal.getAdmissionSequence() != admission.getAdmissionSequence()
                || authorityFinal.getRecordGeneration() != admission.getRecordGeneration()
                || !authorityFinal.getInvocationId().equals(admission.getInvocationId())) {
            throw new ThreadRuntimeIntegrityException(
                    "native terminal publish admission is not the authority final receipt");
        }
        NativeTerminalEvidence evidence = new NativeTerminalEvidence(
                nodeId, run.getId(), run.getGeneration(), authorityFinal, issued);
        String key = evidence.exactKey();
        String receiptIdentity = evidence.receiptIdentityKey();
        ScenarioNodeId receiptOwner = nativeNodeByReceiptIdentity.get(receiptIdentity);
        if (receiptOwner != null) {
            throw new ThreadRuntimeIntegrityException(
                    "native terminal receipt already belongs to ScenarioNodeId "
                            + receiptOwner.getValue() + ": " + receiptIdentity);
        }
        if (nativeByExactKey.containsKey(key)) {
            throw new ThreadRuntimeIntegrityException(
                    "native terminal evidence already published for exact key: " + key);
        }
        // Same nodeId + same exact identity is the only duplicate form; different nodeId
        // with same command/admission is allowed only if exactKey differs (nodeId is in key).
        nativeByExactKey.put(key, evidence);
        nativeNodeByReceiptIdentity.put(receiptIdentity, nodeId);
        List<NativeTerminalEvidence> list = nativeByNode.get(nodeId);
        if (list == null) {
            list = new ArrayList<>();
            nativeByNode.put(nodeId, list);
        }
        list.add(evidence);
        return evidence;
    }

    /**
     * Publishes host-state transformation evidence under HOST_STATE kind. Cannot be
     * used to fill NATIVE slots.
     */
    public synchronized HostStateEvidence publishHostState(ScenarioNodeId nodeId,
                                                           long producerGeneration,
                                                           String typedIdentity) {
        if (nodeId == null || typedIdentity == null || typedIdentity.trim().isEmpty()) {
            throw new NullPointerException("host state publish");
        }
        if (producerGeneration <= 0L) {
            throw new IllegalArgumentException("host state producer generation");
        }
        if (run.getStateSnapshot() != RunState.ACTIVE
                && run.getStateSnapshot() != RunState.QUIESCING) {
            throw new ThreadRuntimeIntegrityException(
                    "host state evidence publish requires ACTIVE or QUIESCING run");
        }
        long sequence = nextHostProducerSequence++;
        HostStateEvidence evidence = new HostStateEvidence(
                nodeId, run.getId(), run.getGeneration(), sequence, producerGeneration, typedIdentity);
        String key = evidence.exactKey();
        if (hostByExactKey.containsKey(key)) {
            throw new ThreadRuntimeIntegrityException(
                    "host state evidence already published for exact key: " + key);
        }
        hostByExactKey.put(key, evidence);
        List<HostStateEvidence> list = hostByNode.get(nodeId);
        if (list == null) {
            list = new ArrayList<>();
            hostByNode.put(nodeId, list);
        }
        list.add(evidence);
        return evidence;
    }

    public synchronized List<NativeTerminalEvidence> snapshotNativeTerminals() {
        return Collections.unmodifiableList(new ArrayList<>(nativeByExactKey.values()));
    }

    public synchronized List<NativeTerminalEvidence> snapshotNativeForNode(ScenarioNodeId nodeId) {
        List<NativeTerminalEvidence> list = nativeByNode.get(nodeId);
        if (list == null || list.isEmpty()) {
            return Collections.emptyList();
        }
        return Collections.unmodifiableList(new ArrayList<>(list));
    }

    public synchronized List<HostStateEvidence> snapshotHostStates() {
        return Collections.unmodifiableList(new ArrayList<>(hostByExactKey.values()));
    }

    public synchronized List<HostStateEvidence> snapshotHostForNode(ScenarioNodeId nodeId) {
        List<HostStateEvidence> list = hostByNode.get(nodeId);
        if (list == null || list.isEmpty()) {
            return Collections.emptyList();
        }
        return Collections.unmodifiableList(new ArrayList<>(list));
    }

    public synchronized int nativeCount() {
        return nativeByExactKey.size();
    }

    public synchronized int hostCount() {
        return hostByExactKey.size();
    }
}
