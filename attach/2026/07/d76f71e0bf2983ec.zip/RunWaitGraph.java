package com.github.unidbg.thread.runtime;

import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * Run-owned multi-edge wait-for graph.
 *
 * <p>runtime wait-graph: one waiter may depend on many required invocations (multi-edge).
 * Cycles fail closed. Transitive failure and waiter cleanup are first-class.
 * No role/command lookup exists — only exact RuntimeInvocationId edges.
 */
public final class RunWaitGraph {

    private final RunContext run;
    /** waiter -> set of required dependencies (multi-edge). */
    private final Map<RuntimeInvocationId, Set<RuntimeInvocationId>> dependencies = new LinkedHashMap<>();

    RunWaitGraph(RunContext run) {
        if (run == null) {
            throw new NullPointerException("run");
        }
        this.run = run;
    }

    public void addDependency(RuntimeInvocationId waiter, RuntimeInvocationId required,
                              ReentryMode mode) {
        mutate("wait_edge_publish", () -> {
            addDependenciesLocked(waiter, Collections.singletonList(required), mode);
            return null;
        });
    }

    /**
     * Publishes a complete multi-edge dependency set or none of it. Every
     * endpoint must resolve to an exact live invocation before structural
     * mutation begins; if a later edge cycles, all earlier edges from this
     * request are rolled back.
     */
    public void addDependencies(RuntimeInvocationId waiter,
                                List<RuntimeInvocationId> requiredDependencies,
                                ReentryMode mode) {
        mutate("wait_edge_publish", () -> {
            addDependenciesLocked(waiter, requiredDependencies, mode);
            return null;
        });
    }

    private synchronized void addDependenciesLocked(RuntimeInvocationId waiter,
                                                     List<RuntimeInvocationId> requiredDependencies,
                                                     ReentryMode mode) {
        if (requiredDependencies == null || requiredDependencies.isEmpty()) {
            throw new IllegalArgumentException("required dependency set is empty");
        }
        if (mode == null) {
            throw new NullPointerException("mode");
        }
        for (RuntimeInvocationId required : requiredDependencies) {
            requireSameRun(waiter, required);
            run.getInvocationRegistry().requireDependencyEligible(waiter, required);
            if (waiter.equals(required)) {
                throw cycle("invocation cannot wait for itself");
            }
            if (waiter.getThreadId().equals(required.getThreadId())
                    && mode != ReentryMode.SAME_THREAD_SYNCHRONOUS) {
                throw cycle("same-thread synchronous wait would place work behind its parent");
            }
        }

        Set<RuntimeInvocationId> requiredSet = dependencies.get(waiter);
        boolean created = false;
        if (requiredSet == null) {
            requiredSet = new LinkedHashSet<>();
            dependencies.put(waiter, requiredSet);
            created = true;
        }
        Set<RuntimeInvocationId> added = new LinkedHashSet<>();
        try {
            for (RuntimeInvocationId required : requiredDependencies) {
                if (!requiredSet.add(required)) {
                    continue; // idempotent multi-edge
                }
                added.add(required);
                if (reaches(required, waiter)) {
                    throw new InvocationDependencyCycleException("wait-for dependency cycle");
                }
            }
        } catch (RuntimeException e) {
            requiredSet.removeAll(added);
            if (created && requiredSet.isEmpty()) {
                dependencies.remove(waiter);
            }
            if (e instanceof InvocationDependencyCycleException) {
                throw cycle(e.getMessage());
            }
            throw e;
        }
    }

    /**
     * Freezes the dependent set while graph edges are still intact. Once a root
     * fault quarantines the run, no new edge may be admitted, so this snapshot is
     * the complete propagation frontier for that fault.
     */
    public synchronized FailureDependents snapshotFailureDependents(RuntimeInvocationId failed) {
        run.getInvocationRegistry().requireRegistered(failed);
        List<RuntimeInvocationId> direct = getDirectWaiters(failed);
        List<RuntimeInvocationId> transitive = collectTransitiveWaiters(failed);
        return new FailureDependents(direct, transitive);
    }

    public static final class FailureDependents {
        private final List<RuntimeInvocationId> direct;
        private final List<RuntimeInvocationId> transitive;

        private FailureDependents(List<RuntimeInvocationId> direct,
                                  List<RuntimeInvocationId> transitive) {
            this.direct = Collections.unmodifiableList(new ArrayList<>(direct));
            this.transitive = Collections.unmodifiableList(new ArrayList<>(transitive));
        }

        public List<RuntimeInvocationId> getDirect() {
            return direct;
        }

        /** Includes direct waiters plus every deeper dependent exactly once. */
        public List<RuntimeInvocationId> getAll() {
            return transitive;
        }
    }

    public void removeDependency(RuntimeInvocationId waiter, RuntimeInvocationId required) {
        mutate("wait_edge_remove", () -> {
            removeDependencyLocked(waiter, required);
            return null;
        });
    }

    private synchronized void removeDependencyLocked(RuntimeInvocationId waiter, RuntimeInvocationId required) {
        if (waiter == null || required == null) {
            return;
        }
        Set<RuntimeInvocationId> requiredSet = dependencies.get(waiter);
        if (requiredSet == null) {
            return;
        }
        requiredSet.remove(required);
        if (requiredSet.isEmpty()) {
            dependencies.remove(waiter);
        }
    }

    public synchronized boolean hasDependency(RuntimeInvocationId waiter, RuntimeInvocationId required) {
        if (waiter == null || required == null) {
            return false;
        }
        Set<RuntimeInvocationId> requiredSet = dependencies.get(waiter);
        return requiredSet != null && requiredSet.contains(required);
    }

    /** All direct required dependencies of one waiter (multi-edge snapshot). */
    public synchronized List<RuntimeInvocationId> getDirectDependencies(RuntimeInvocationId waiter) {
        if (waiter == null || !run.getId().equals(waiter.getThreadId().getRunId())) {
            throw new IllegalArgumentException("waiter belongs to another run");
        }
        Set<RuntimeInvocationId> requiredSet = dependencies.get(waiter);
        if (requiredSet == null || requiredSet.isEmpty()) {
            return Collections.emptyList();
        }
        return Collections.unmodifiableList(new ArrayList<>(requiredSet));
    }

    /** Returns only direct waiters of one exact invocation; no role or command lookup exists. */
    public synchronized List<RuntimeInvocationId> getDirectWaiters(RuntimeInvocationId required) {
        if (required == null || !run.getId().equals(required.getThreadId().getRunId())) {
            throw new IllegalArgumentException("required invocation belongs to another run");
        }
        List<RuntimeInvocationId> waiters = new ArrayList<>();
        for (Map.Entry<RuntimeInvocationId, Set<RuntimeInvocationId>> entry : dependencies.entrySet()) {
            if (entry.getValue().contains(required)) {
                waiters.add(entry.getKey());
            }
        }
        return waiters;
    }

    /**
     * Removes every edge that references the given invocation (as waiter or required).
     * Used on terminal / cancel / disposal so waiters do not retain stale edges.
     */
    public void cleanupInvocation(RuntimeInvocationId invocation) {
        mutate("wait_edge_cleanup", () -> {
            cleanupInvocationLocked(invocation);
            return null;
        });
    }

    private synchronized void cleanupInvocationLocked(RuntimeInvocationId invocation) {
        if (invocation == null) {
            return;
        }
        dependencies.remove(invocation);
        for (Map.Entry<RuntimeInvocationId, Set<RuntimeInvocationId>> entry
                : new ArrayList<>(dependencies.entrySet())) {
            entry.getValue().remove(invocation);
            if (entry.getValue().isEmpty()) {
                dependencies.remove(entry.getKey());
            }
        }
    }

    /**
     * True if any transitive required dependency of {@code waiter} equals {@code failed}.
     * Used to mark DEPENDENCY_FAILED when a required producer faults.
     */
    public synchronized boolean transitivelyDependsOn(RuntimeInvocationId waiter,
                                                      RuntimeInvocationId failed) {
        if (waiter == null || failed == null) {
            return false;
        }
        return reaches(waiter, failed);
    }

    /** Collects every waiter that transitively depends on a failed producer. */
    public synchronized List<RuntimeInvocationId> collectTransitiveWaiters(
            RuntimeInvocationId failed) {
        if (failed == null) {
            return Collections.emptyList();
        }
        List<RuntimeInvocationId> result = new ArrayList<>();
        for (RuntimeInvocationId waiter : dependencies.keySet()) {
            if (reaches(waiter, failed)) {
                result.add(waiter);
            }
        }
        return result;
    }

    /** True when the wait graph has no edges (required for R4.9 readiness). */
    public synchronized boolean isEmpty() {
        return dependencies.isEmpty();
    }

    public synchronized int edgeCount() {
        int n = 0;
        for (Set<RuntimeInvocationId> deps : dependencies.values()) {
            n += deps.size();
        }
        return n;
    }

    private boolean reaches(RuntimeInvocationId start, RuntimeInvocationId target) {
        // BFS over multi-edge graph
        Set<RuntimeInvocationId> seen = new LinkedHashSet<>();
        List<RuntimeInvocationId> queue = new ArrayList<>();
        queue.add(start);
        while (!queue.isEmpty()) {
            RuntimeInvocationId current = queue.remove(0);
            if (!seen.add(current)) {
                continue;
            }
            Set<RuntimeInvocationId> next = dependencies.get(current);
            if (next == null) {
                continue;
            }
            for (RuntimeInvocationId dep : next) {
                if (dep.equals(target)) {
                    return true;
                }
                queue.add(dep);
            }
        }
        return false;
    }

    private interface Mutation<T> {
        T apply();
    }

    /** Acquire the Run authority before the wait-graph monitor. */
    private <T> T mutate(String source, Mutation<T> mutation) {
        BoundaryReadinessAuthority authority = run.getBoundaryReadinessAuthority();
        if (authority.isMutationPermitHeldByCurrentThread()
                || run.getStateSnapshot() != RunState.ACTIVE) {
            return mutation.apply();
        }
        try (BoundaryReadinessAuthority.MutationPermit permit = run.beginReadinessMutation(source)) {
            T result = mutation.apply();
            permit.commit();
            return result;
        }
    }

    private void requireSameRun(RuntimeInvocationId waiter, RuntimeInvocationId required) {
        if (waiter == null || required == null) {
            throw new NullPointerException("wait-for invocation");
        }
        if (!run.getId().equals(waiter.getThreadId().getRunId())
                || !run.getId().equals(required.getThreadId().getRunId())) {
            run.quarantine();
            throw new InvocationDependencyCycleException("cross-run wait-for dependency");
        }
        if (run.getStateSnapshot() != RunState.ACTIVE) {
            throw new IllegalStateException("run does not accept wait-for dependencies");
        }
    }

    private InvocationDependencyCycleException cycle(String message) {
        run.quarantine();
        return new InvocationDependencyCycleException(message);
    }
}
