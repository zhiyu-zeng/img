package com.github.unidbg.thread.runtime;

import java.util.Collections;
import java.util.LinkedHashSet;
import java.util.Set;

/**
 * Run-owned descriptor for one proven guest thread incarnation. It deliberately
 * does not own a carrier, backend context, TLS allocation, stack region, or JNI
 * frame in G0; those scopes are added only by their dedicated gates.
 */
public final class GuestThreadIncarnation {

    private final RunContext run;
    private final ThreadIncarnationId id;
    private final ThreadBirthRecord birthRecord;
    private final ThreadIdentityEvidence evidence;
    private final GuestJniAttachment jniAttachment;
    private final GuestThreadExecutionState executionState;
    private final GuestInvocationStack invocationStack;
    private final Set<TaskThreadBinding> taskBindings = new LinkedHashSet<>();
    private GuestThreadLifecycleState lifecycleState = GuestThreadLifecycleState.ACTIVE;
    /** Guest pthread/prctl name when observed; not host Thread.getName(). */
    private String guestThreadName;

    GuestThreadIncarnation(RunContext run, ThreadIncarnationId id, ThreadBirthRecord birthRecord,
                           ThreadIdentityEvidence evidence) {
        if (run == null) {
            throw new NullPointerException("run");
        }
        if (id == null) {
            throw new NullPointerException("id");
        }
        if (birthRecord == null) {
            throw new NullPointerException("birthRecord");
        }
        if (evidence == null || evidence.getRuntimeValidity() != ThreadRuntimeValidity.VALIDATED) {
            throw new IllegalArgumentException("guest thread requires validated runtime evidence");
        }
        if (!run.getId().equals(id.getRunId()) || !id.getRunId().equals(evidence.getRunId())
                || !id.getRunId().equals(birthRecord.getRunId())) {
            throw new IllegalArgumentException("thread identity belongs to another run");
        }
        birthRecord.validateGuestTid(evidence.requireGuestTid());
        this.run = run;
        this.id = id;
        this.birthRecord = birthRecord;
        this.evidence = evidence;
        this.jniAttachment = run.getJniScope().attach(id);
        this.executionState = new GuestThreadExecutionState(run, id, birthRecord);
        this.invocationStack = new GuestInvocationStack(run, id, executionState);
    }

    public ThreadIncarnationId getId() {
        return id;
    }

    public ThreadIdentityEvidence getEvidence() {
        return evidence;
    }

    public ThreadBirthRecord getBirthRecord() {
        return birthRecord;
    }

    public synchronized String getGuestThreadName() {
        return guestThreadName;
    }

    /**
     * Records the guest-visible thread name (prctl PR_SET_NAME / pthread_setname_np).
     * Exact match is required for the background-role bootstrap.
     */
    synchronized void recordGuestThreadName(String name) {
        if (name == null || name.trim().isEmpty()) {
            throw new IllegalArgumentException("guest thread name is required");
        }
        if (!isActive()) {
            throw new ThreadRuntimeIntegrityException("cannot name a non-active incarnation");
        }
        String trimmed = name.trim();
        if (guestThreadName != null && !guestThreadName.equals(trimmed)) {
            throw new ThreadRuntimeIntegrityException(
                    "guest thread name changed within one incarnation: " + guestThreadName + " -> " + trimmed);
        }
        guestThreadName = trimmed;
    }

    /** The stable JNI attachment owned by this guest thread incarnation. */
    public GuestJniAttachment getJniAttachment() {
        return jniAttachment;
    }

    public GuestThreadExecutionState getExecutionState() {
        return executionState;
    }

    public GuestInvocationStack getInvocationStack() {
        return invocationStack;
    }

    synchronized void recordTaskBinding(TaskThreadBinding binding) {
        if (binding == null || !id.equals(binding.getThreadId())) {
            throw new IllegalArgumentException("binding belongs to another thread");
        }
        taskBindings.add(binding);
    }

    public synchronized Set<TaskThreadBinding> getTaskBindings() {
        return Collections.unmodifiableSet(new LinkedHashSet<>(taskBindings));
    }

    public int getNumericGuestTid() {
        return evidence.requireGuestTid();
    }

    public synchronized GuestThreadLifecycleState getLifecycleState() {
        return lifecycleState;
    }

    synchronized boolean isActive() {
        return lifecycleState == GuestThreadLifecycleState.ACTIVE;
    }

    synchronized void retire(TaskThreadBinding binding) {
        if (!isActive()) {
            throw new ThreadRuntimeIntegrityException("guest thread incarnation is not active");
        }
        // binding must already be unbound by GuestThreadRegistry.retireTask
        if (binding == null || !taskBindings.contains(binding) || binding.isBound()) {
            throw new ThreadRuntimeIntegrityException("guest thread retirement has no exact unbound task binding");
        }
        if (!executionState.canRetireAfterUnbind() || !invocationStack.canRetireThread()) {
            run.quarantine();
            throw new ThreadRuntimeIntegrityException("guest thread has live invocation or continuation during retirement");
        }
        for (TaskThreadBinding candidate : taskBindings) {
            if (candidate.isBound()) {
                run.quarantine();
                throw new ThreadRuntimeIntegrityException("guest thread still has a live task binding");
            }
        }
        executionState.retireAfterUnbind();
        run.getJniScope().detach(id);
        lifecycleState = GuestThreadLifecycleState.DEAD;
    }

    synchronized void markDead() {
        if (!isActive()) {
            throw new ThreadRuntimeIntegrityException("guest thread incarnation is not active");
        }
        if (!executionState.canRetireAfterUnbind() || !invocationStack.canRetireThread()) {
            throw new ThreadRuntimeIntegrityException(
                    "guest thread has live execution state during ordered run disposal");
        }
        executionState.retireAfterUnbind();
        run.getJniScope().detach(id);
        lifecycleState = GuestThreadLifecycleState.DEAD;
    }
}
