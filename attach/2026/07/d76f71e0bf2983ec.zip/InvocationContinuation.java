package com.github.unidbg.thread.runtime;

public final class InvocationContinuation {

    private final InvocationFrame frame;
    private final ExecutionStateSnapshotToken snapshotToken;

    private InvocationContinuation(InvocationFrame frame, ExecutionStateSnapshotToken snapshotToken) {
        if (frame == null) {
            throw new NullPointerException("frame");
        }
        if (snapshotToken == null) {
            throw new NullPointerException("snapshotToken");
        }
        if (!frame.getThreadId().equals(snapshotToken.getThreadId())) {
            throw new IllegalArgumentException("continuation frame and snapshot belong to different threads");
        }
        this.frame = frame;
        this.snapshotToken = snapshotToken;
    }

    public static InvocationContinuation create(InvocationFrame frame,
                                                ExecutionStateSnapshotToken snapshotToken) {
        return new InvocationContinuation(frame, snapshotToken);
    }

    public InvocationFrame getFrame() {
        return frame;
    }

    public ExecutionStateSnapshotToken getSnapshotToken() {
        return snapshotToken;
    }
}
