package com.github.unidbg.thread.runtime;

import com.github.unidbg.thread.CommandInvocationRecord;
import com.github.unidbg.thread.Task;

/**
 * Immutable evidence that one scheduled carrier was accepted by the dispatcher
 * after an atomic pre-submit reservation: carrier identity, per-carrier
 * {@link TaskThreadBinding}, command record, and lease registration all
 * succeeded and the exact carrier entered the dispatcher queue. It is never
 * reconstructed from a role singleton or from a still-pending
 * {@link CarrierAdmissionReservation}.
 */
public final class AdmissionReceipt {

    private final RunId runId;
    private final ObservedCommandRole role;
    private final ThreadIncarnationId incarnationId;
    private final Task carrier;
    private final TaskThreadBinding binding;
    private final long bindingEpoch;
    private final long taskGeneration;
    private final CommandInvocationRecord record;
    private final long recordGeneration;
    private final CarrierLeaseId leaseId;
    private final RuntimeInvocationId invocationId;
    private final long admissionSequence;
    private final ScenarioNodeId scenarioNodeId;

    AdmissionReceipt(RunId runId,
                     ObservedCommandRole role,
                     ThreadIncarnationId incarnationId,
                     Task carrier,
                     TaskThreadBinding binding,
                     CommandInvocationRecord record,
                     CarrierLeaseId leaseId,
                     RuntimeInvocationId invocationId,
                     long admissionSequence) {
        if (runId == null || role == null || incarnationId == null || carrier == null
                || binding == null || record == null || leaseId == null || invocationId == null) {
            throw new NullPointerException("admission receipt identity");
        }
        if (!runId.equals(incarnationId.getRunId()) || !runId.equals(binding.getThreadId().getRunId())) {
            throw new ThreadRuntimeIntegrityException("admission receipt crosses runs");
        }
        if (!binding.isBound() || carrier.getTaskThreadBinding() != binding) {
            throw new ThreadRuntimeIntegrityException("admission receipt requires exact live per-carrier binding");
        }
        if (record.getCarrier() != carrier) {
            throw new ThreadRuntimeIntegrityException("admission receipt carrier/record mismatch");
        }
        if (admissionSequence <= 0L) {
            throw new IllegalArgumentException("admission sequence must be positive");
        }
        this.runId = runId;
        this.role = role;
        this.incarnationId = incarnationId;
        this.carrier = carrier;
        this.binding = binding;
        this.bindingEpoch = binding.getBindingEpoch();
        this.taskGeneration = binding.getTaskGeneration();
        this.record = record;
        this.recordGeneration = record.getGeneration();
        this.leaseId = leaseId;
        this.invocationId = invocationId;
        this.admissionSequence = admissionSequence;
        this.scenarioNodeId = record.getScenarioNodeId();
    }

    public RunId getRunId() {
        return runId;
    }

    public ObservedCommandRole getRole() {
        return role;
    }

    public ThreadIncarnationId getIncarnationId() {
        return incarnationId;
    }

    public Task getCarrier() {
        return carrier;
    }

    public TaskThreadBinding getBinding() {
        return binding;
    }

    public long getBindingEpoch() {
        return bindingEpoch;
    }

    public long getTaskGeneration() {
        return taskGeneration;
    }

    public CommandInvocationRecord getRecord() {
        return record;
    }

    public long getRecordGeneration() {
        return recordGeneration;
    }

    public CarrierLeaseId getLeaseId() {
        return leaseId;
    }

    public RuntimeInvocationId getInvocationId() {
        return invocationId;
    }

    public long getAdmissionSequence() {
        return admissionSequence;
    }

    public ScenarioNodeId getScenarioNodeId() {
        return scenarioNodeId;
    }

    /**
     * True only when this receipt still describes the exact live carrier/binding/record
     * triple observed at admission. Retired or replaced bindings fail closed.
     */
    public boolean matchesLive(Task task, CommandInvocationRecord liveRecord) {
        if (task != carrier || liveRecord != record) {
            return false;
        }
        TaskThreadBinding actual = task.getTaskThreadBinding();
        return actual == binding
                && actual.isBound()
                && actual.getBindingEpoch() == bindingEpoch
                && actual.getTaskGeneration() == taskGeneration
                && liveRecord.getCarrier() == carrier
                && liveRecord.getGeneration() == recordGeneration;
    }
}
