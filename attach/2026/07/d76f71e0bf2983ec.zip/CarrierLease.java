package com.github.unidbg.thread.runtime;

import com.github.unidbg.thread.Task;

/**
 * Non-owning evidence that one Task currently drives a specific invocation.
 * Dispatcher safe points and task retirement update this lease; it never creates,
 * modifies, or releases the referenced guest thread identity.
 */
public final class CarrierLease {

    private final CarrierLeaseId id;
    private final Task carrier;
    private final TaskThreadBinding binding;
    /** True while the carrier is not currently holding backend ownership (including never-acquired). */
    private boolean backendReleased = true;
    /** Set only after dispatcher evidence proves every runnable ownership surface is gone. */
    private boolean dispatcherRemovalProven;
    private boolean carrierRetired;

    CarrierLease(RuntimeInvocationId invocationId, Task carrier, TaskThreadBinding binding, long serial) {
        if (carrier == null || binding == null) {
            throw new NullPointerException("carrier lease identity");
        }
        if (!binding.isBound() || carrier.getTaskThreadBinding() != binding
                || !invocationId.getThreadId().equals(binding.getThreadId())) {
            throw new ThreadRuntimeIntegrityException("carrier lease has no exact live task binding");
        }
        this.id = new CarrierLeaseId(invocationId, serial);
        this.carrier = carrier;
        this.binding = binding;
    }

    public CarrierLeaseId getId() {
        return id;
    }

    public TaskThreadBinding getBinding() {
        return binding;
    }

    Task getCarrier() {
        return carrier;
    }

    public boolean ownsThreadIdentity() {
        return false;
    }

    /** Called only after the dispatcher has released backend ownership at a safe point. */
    public synchronized void recordBackendAcquired() {
        if (carrierRetired) {
            throw new ThreadRuntimeIntegrityException("retired carrier cannot reacquire backend ownership");
        }
        backendReleased = false;
    }

    public synchronized void recordBackendReleasedAtSafePoint() {
        backendReleased = true;
    }

    /** Does not retire a binding; it records the dispatcher proof required before retirement. */
    synchronized void recordDispatcherRemovalProven() {
        if (!backendReleased || carrierRetired) {
            throw new ThreadRuntimeIntegrityException(
                    "dispatcher removal proof has no released live carrier lease");
        }
        dispatcherRemovalProven = true;
    }

    /** Called by the external task-retirement path after it proves the task cannot run again. */
    public synchronized void recordCarrierRetired(Task retiredCarrier) {
        if (retiredCarrier != carrier || !backendReleased || carrierRetired) {
            throw new ThreadRuntimeIntegrityException("carrier retirement has no exact released lease");
        }
        if (!hasExactLiveBinding() || isCarrierDispatchable() || carrier.getWaiter() != null) {
            throw new ThreadRuntimeIntegrityException("carrier is still dispatchable or retains a waiter");
        }
        carrierRetired = true;
    }

    public synchronized boolean isBackendReleased() {
        return backendReleased;
    }

    public synchronized boolean isCarrierRetired() {
        return carrierRetired;
    }

    synchronized boolean belongsTo(RuntimeInvocation invocation) {
        return invocation != null && id.getInvocationId().equals(invocation.getId());
    }

    synchronized boolean hasExactLiveBinding() {
        return binding.isBound() && carrier.getTaskThreadBinding() == binding;
    }

    synchronized boolean isCarrierDispatchable() {
        return !dispatcherRemovalProven && carrier.canDispatch();
    }

    synchronized boolean hasAttachedWaiter() {
        return carrier.getWaiter() != null;
    }
}
