package com.github.unidbg.thread.runtime;

/**
 * G0 runtime boundary. It owns the run identity, observed-thread registry, lease
 * registry, and fault/wait authorities. Emulator, VM, and command routing remain
 * intentionally unwired until their later gates.
 *
 * <p>runtime design: {@link #close()} enters {@link RunState#QUIESCING} and retires
 * live invocations item-by-item. It never blindly markDead/clears; incomplete
 * disposal publishes {@code ABORTED_BY_RUN_DISPOSAL} or quarantines.
 *
 * <p>runtime lock-order 锁序：{@link #quarantine()}/{@link #close()} 不得在持有 RunContext
 * 锁时回调 StateStore/Registry；跨层读 RunState 使用 {@link #getStateSnapshot()}。
 */
public final class RunContext implements AutoCloseable {

    private final RunId id;
    /** A RunContext is never reused; this explicit generation closes stale receipt identity. */
    private final long generation = 1L;
    private final RuntimeJniScope jniScope;
    private final RuntimeCommandStateStore commandStateStore;
    private final RuntimeTimeDomains timeDomains;
    private final GuestThreadRegistry threadRegistry;
    private final CarrierLeaseRegistry carrierLeaseRegistry;
    private final CarrierAdmissionAuthority carrierAdmissionAuthority;
    private final HostCallbackBridge hostCallbackBridge;
    private final ProductionRoleObservationAuthority roleObservationAuthority;
    private final DeviceRoleLineageIntegration roleLineageIntegration;
    private final BoundaryReadinessAuthority boundaryReadinessAuthority;
    private final RoleLaneBindPublicationGate roleLaneBindPublicationGate;
    private final TerminalEvidenceLedger terminalEvidenceLedger;
    private final RuntimeInvocationRegistry invocationRegistry;
    private final RunWaitGraph waitGraph;
    private final RunFaultController faultController;
    private RunState state = RunState.NEW;
    /** 无锁快照，供 StateStore 等下层在不回调 L1 锁的情况下读取 RunState。 */
    private volatile RunState stateSnapshot = RunState.NEW;
    private long readinessLifecycleEpoch = 1L;
    private volatile long readinessLifecycleEpochSnapshot = 1L;
    private volatile boolean readinessLifecycleOpen;
    private volatile Runnable postLifecycleInvalidationBeforeStatePublishForTesting;

    private RunContext(RunId id) {
        this.id = id;
        this.jniScope = new RuntimeJniScope(this);
        this.commandStateStore = new RuntimeCommandStateStore(this);
        this.timeDomains = new RuntimeTimeDomains(this);
        this.threadRegistry = new GuestThreadRegistry(this);
        this.carrierLeaseRegistry = new CarrierLeaseRegistry(this);
        this.carrierAdmissionAuthority = new CarrierAdmissionAuthority(this);
        this.hostCallbackBridge = new HostCallbackBridge(this);
        this.roleObservationAuthority = new ProductionRoleObservationAuthority(this);
        this.roleLineageIntegration = new DeviceRoleLineageIntegration(this);
        this.boundaryReadinessAuthority = new BoundaryReadinessAuthority(this);
        this.roleLaneBindPublicationGate = new RoleLaneBindPublicationGate();
        this.terminalEvidenceLedger = new TerminalEvidenceLedger(this);
        this.invocationRegistry = new RuntimeInvocationRegistry(this);
        this.waitGraph = new RunWaitGraph(this);
        this.faultController = new RunFaultController(this);
    }

    public static RunContext createActive() {
        RunContext context = new RunContext(RunId.create());
        context.activate();
        return context;
    }

    public RunId getId() {
        return id;
    }

    public long getGeneration() {
        return generation;
    }

    public synchronized RunState getState() {
        return state;
    }

    /**
     * 无锁 RunState 快照。StateStore 等下层必须用此方法，禁止在持有自身锁时
     * 调用 {@link #getState()}（会触发 L3→L1 锁序违规）。
     */
    public RunState getStateSnapshot() {
        return stateSnapshot;
    }

    public GuestThreadRegistry getThreadRegistry() {
        return threadRegistry;
    }

    public CarrierLeaseRegistry getCarrierLeaseRegistry() {
        return carrierLeaseRegistry;
    }

    /**
     * Run-owned atomic admission authority. Role resolution names only an
     * incarnation; each scheduled carrier receives a fresh binding + receipt.
     */
    public CarrierAdmissionAuthority getCarrierAdmissionAuthority() {
        return carrierAdmissionAuthority;
    }

    /** Run-owned bridge from an observed host callback to the StateStore. */
    public HostCallbackBridge getHostCallbackBridge() {
        return hostCallbackBridge;
    }

    /** Structural role observation and bootstrap receipts, separate from lineage proof. */
    public ProductionRoleObservationAuthority getRoleObservationAuthority() {
        return roleObservationAuthority;
    }

    /**
     * Post-bootstrap primary/background lineage milestones. Consumes bootstrap receipts and
     * live admissions; never reverse-issues bootstrap PROVEN.
     */
    public DeviceRoleLineageIntegration getRoleLineageIntegration() {
        return roleLineageIntegration;
    }

    /** The sole issuer/consumer of readiness evidence and the run mutation epoch. */
    public BoundaryReadinessAuthority getBoundaryReadinessAuthority() {
        return boundaryReadinessAuthority;
    }

    /** Shared P0-1 gate: role-lane bind owners are invisible until the final marker. */
    public RoleLaneBindPublicationGate getRoleLaneBindPublicationGate() {
        return roleLaneBindPublicationGate;
    }

    /**
     * P0-1 linearized publication marker. Run close/quarantine share this L1 lock,
     * so ACTIVE/authority checks and the final visibility commit cannot be split by
     * another lifecycle transition.
     */
    public synchronized void commitRoleLaneBindPublication(
            RoleLaneBindPublicationGate.Publication publication,
            BootstrapRoleReceipt bootstrap,
            ScenarioConfig config,
            long graphGeneration) {
        if (publication == null || bootstrap == null || config == null) {
            throw new NullPointerException("role-lane publication commit");
        }
        if (state != RunState.ACTIVE) {
            throw new IllegalStateException("role-lane publication marker lost active run");
        }
        if (!id.equals(publication.getRunId()) || publication.getRunGeneration() != generation) {
            throw new ThreadRuntimeIntegrityException(
                    "role-lane publication marker belongs to a foreign run");
        }
        if (!id.equals(bootstrap.getRunId())
                || bootstrap.getAuthorityEpoch() != roleObservationAuthority.getAuthorityEpoch()) {
            throw new ThreadRuntimeIntegrityException(
                    "role-lane publication marker has stale bootstrap authority");
        }
        if (publication.getBootstrap() != bootstrap
                || publication.getScenarioConfig() != config
                || publication.getGraphGeneration() != graphGeneration) {
            throw new ThreadRuntimeIntegrityException(
                    "role-lane publication marker authority mismatch");
        }
        roleLaneBindPublicationGate.commit(publication, bootstrap, config, graphGeneration);
    }

    /**
     * Run-owned immutable terminal/host evidence ledger. Readiness actual native evidence
     * is produced from this ledger after retirement, not from live admission maps alone.
     */
    public TerminalEvidenceLedger getTerminalEvidenceLedger() {
        return terminalEvidenceLedger;
    }

    public long getRuntimeMutationEpoch() {
        return boundaryReadinessAuthority.getRuntimeMutationEpoch();
    }

    /** Acquire before changing any readiness-affecting owner state. */
    public BoundaryReadinessAuthority.MutationPermit beginReadinessMutation(String source) {
        return boundaryReadinessAuthority.beginMutation(source);
    }

    /** Exact live-invocation identity source for wait dependencies and fault propagation. */
    public RuntimeInvocationRegistry getInvocationRegistry() {
        return invocationRegistry;
    }

    /** Run-scoped JNI globals and per-incarnation attachment registry. */
    public RuntimeJniScope getJniScope() {
        return jniScope;
    }

    public RuntimeCommandStateStore getCommandStateStore() {
        return commandStateStore;
    }

    public RuntimeTimeDomains getTimeDomains() {
        return timeDomains;
    }

    public RunWaitGraph getWaitGraph() {
        return waitGraph;
    }

    /**
     * Run-owned fault and cancellation authority. It deliberately has no carrier
     * or backend ownership: those belong to later execution integration gates.
     */
    public RunFaultController getFaultController() {
        return faultController;
    }

    public synchronized void activate() {
        if (state != RunState.NEW) {
            throw new IllegalStateException("run cannot activate from " + state);
        }
        readinessLifecycleOpen = true;
        publishState(RunState.ACTIVE);
    }

    /**
     * 检疫：先在 L1 锁内只改状态，再在锁外丢弃 StateStore。
     * 禁止 L1 持锁回调 L3。
     */
    public void quarantine() {
        boolean invalidated = beginLifecycleInvalidation(true);
        if (invalidated) {
            boundaryReadinessAuthority.invalidate("run_quarantine");
            roleObservationAuthority.invalidateEpoch("run_quarantine");
            roleLineageIntegration.invalidateLastVerified("run_quarantine");
            runPostLifecycleInvalidationBeforeStatePublishForTesting();
        }
        synchronized (this) {
            if (state != RunState.DISPOSED && state != RunState.QUARANTINED) {
                publishState(RunState.QUARANTINED);
            }
        }
        // 锁外调用 L3
        commandStateStore.discardRunState();
    }

    synchronized boolean acceptsThreadBindings() {
        return state == RunState.ACTIVE;
    }

    synchronized boolean acceptsInvocationAdmissions() {
        return state == RunState.ACTIVE && boundaryReadinessAuthority.acceptsNormalAdmissions();
    }

    /**
     * Enters QUIESCING, attempts ordered retirement of live leased invocations, then
     * either disposes cleanly or aborts/quarantines. Never markDead-clears first.
     * 状态变更在 L1 锁内完成；Registry/StateStore 调用一律在锁外。
     */
    @Override
    public void close() {
        boolean invalidated = beginLifecycleInvalidation(false);
        if (invalidated) {
            boundaryReadinessAuthority.invalidate("run_close");
            roleObservationAuthority.invalidateEpoch("run_close");
            roleLineageIntegration.invalidateLastVerified("run_close");
            runPostLifecycleInvalidationBeforeStatePublishForTesting();
        }
        synchronized (this) {
            if (state == RunState.DISPOSED) {
                return;
            }
            if (state == RunState.ACTIVE || state == RunState.NEW) {
                publishState(RunState.QUIESCING);
            }
        }

        boolean clean = true;
        try {
            for (java.util.Map.Entry<com.github.unidbg.thread.Task, RuntimeInvocation> entry
                    : carrierLeaseRegistry.snapshotLiveLeases().entrySet()) {
                RuntimeInvocation invocation = entry.getValue();
                RuntimeInvocationState invState = invocation.getState();
                if (invState == RuntimeInvocationState.TERMINAL
                        || invState == RuntimeInvocationState.FAULTED
                        || invState == RuntimeInvocationState.CANCELLED
                        || invState == RuntimeInvocationState.DEPENDENCY_FAILED
                        || invState == RuntimeInvocationState.ABORTED_BY_RUN_DISPOSAL) {
                    continue;
                }
                try {
                    faultController.abortByRunDisposal(invocation);
                } catch (RuntimeException e) {
                    clean = false;
                    quarantine();
                    break;
                }
            }
            if (clean && hasNoPreCloseRuntimeOwners()) {
                try {
                    threadRegistry.closeOrdered();
                } catch (RuntimeException e) {
                    clean = false;
                    quarantine();
                }
            } else if (clean) {
                clean = false;
                quarantine();
            }
        } finally {
            // 锁外丢弃 store。只有所有 runtime owner 已有序归零时才能发布 DISPOSED；
            // 中途失败必须保持 QUARANTINED，不能把未清理的 carrier/stack/JNI 伪装为释放。
            commandStateStore.discardRunState();
            if (clean && hasNoLiveRuntimeOwners()) {
                synchronized (this) {
                    publishState(RunState.DISPOSED);
                }
            } else if (getStateSnapshot() != RunState.QUARANTINED) {
                quarantine();
            }
        }
    }

    private boolean hasNoPreCloseRuntimeOwners() {
        return carrierLeaseRegistry.hasNoLiveLeases()
                && invocationRegistry.liveInvocationCount() == 0
                && threadRegistry.hasNoPendingInvocations()
                && waitGraph.isEmpty();
    }

    private boolean hasNoLiveRuntimeOwners() {
        return hasNoPreCloseRuntimeOwners() && jniScope.hasNoAttachments();
    }

    private void publishState(RunState next) {
        state = next;
        stateSnapshot = next;
    }

    long getReadinessLifecycleEpochSnapshot() {
        return readinessLifecycleEpochSnapshot;
    }

    boolean acceptsReadinessMutation(long expectedEpoch) {
        return readinessLifecycleOpen
                && readinessLifecycleEpochSnapshot == expectedEpoch
                && stateSnapshot == RunState.ACTIVE;
    }

    boolean isReadinessEvidenceVisible() {
        return readinessLifecycleOpen && stateSnapshot == RunState.ACTIVE;
    }

    private synchronized boolean beginLifecycleInvalidation(boolean rejectDisposed) {
        if (state == RunState.DISPOSED) {
            if (rejectDisposed) {
                throw new IllegalStateException("disposed run cannot be quarantined");
            }
            return false;
        }
        if (!readinessLifecycleOpen) {
            return false;
        }
        readinessLifecycleOpen = false;
        readinessLifecycleEpoch++;
        readinessLifecycleEpochSnapshot = readinessLifecycleEpoch;
        return true;
    }

    /**
     * Test-only deterministic barrier: permanent lifecycle concurrency contracts use this
     * to stop after invalidation has cleared authorities but before RunState is published.
     */
    void setPostLifecycleInvalidationBeforeStatePublishForTesting(Runnable hook) {
        postLifecycleInvalidationBeforeStatePublishForTesting = hook;
    }

    private void runPostLifecycleInvalidationBeforeStatePublishForTesting() {
        Runnable hook = postLifecycleInvalidationBeforeStatePublishForTesting;
        if (hook != null) {
            hook.run();
        }
    }
}
