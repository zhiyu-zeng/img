package com.github.unidbg.thread.runtime;

import com.github.unidbg.Emulator;
import com.github.unidbg.thread.Task;

import java.util.EnumMap;
import java.util.IdentityHashMap;
import java.util.Map;

/**
 * Run-owned source of guest identity. A current task must carry an explicit
 * TaskThreadBinding; this class never derives identity from a host thread,
 * command role, active command, or an arbitrary process-id fallback.
 */
public final class ThreadIdentityProvider implements AutoCloseable {

    private static final String EMULATOR_KEY = ThreadIdentityProvider.class.getName();

    private final RunContext run;
    private final int processId;
    private final GuestThreadIncarnation processLeader;
    private final long processLeaderPthreadSelf;
    private final long processLeaderTpidr;
    private final long processLeaderErrnoAddress;
    private final EnumMap<ThreadIdentityCapability, GuestThreadCapabilityState> capabilities;
    private final Map<TaskThreadBinding, GuestThreadIdentitySnapshot> identities = new IdentityHashMap<>();
    private final Map<TaskThreadBinding, GuestThreadExecutionState> executionStates = new IdentityHashMap<>();
    private final Map<TaskThreadBinding, RuntimeInvocation> runtimeInvocations = new IdentityHashMap<>();
    private long nextBirthEpoch = 2L;
    private long nextTaskGeneration = 1L;
    private long nextTaskSerial = 1L;
    private boolean closed;

    private ThreadIdentityProvider(int processId, long pthreadSelf, long tpidr,
                                   long errnoAddress, String provenance) {
        if (processId <= 0) {
            throw new IllegalArgumentException("process id must be positive");
        }
        requirePointer(pthreadSelf, "process leader pthread_self");
        requirePointer(tpidr, "process leader TPIDR");
        requirePointer(errnoAddress, "process leader errno address");
        if (provenance == null || provenance.trim().isEmpty()) {
            throw new IllegalArgumentException("process leader provenance is required");
        }
        this.run = RunContext.createActive();
        this.processId = processId;
        this.processLeaderPthreadSelf = pthreadSelf;
        this.processLeaderTpidr = tpidr;
        this.processLeaderErrnoAddress = errnoAddress;
        ThreadBirthRecord birth = ThreadBirthRecord.processLeader(run.getId(), processId, 1L,
                provenance.trim());
        ThreadIdentityEvidence evidence = evidence(run.getId(), processId, pthreadSelf, tpidr,
                pthreadSelf, provenance + ":leader");
        this.processLeader = run.getThreadRegistry().registerIncarnation(birth, evidence);
        this.capabilities = new EnumMap<>(ThreadIdentityCapability.class);
        capabilities.put(ThreadIdentityCapability.GETTID, GuestThreadCapabilityState.IMPLEMENTED);
        capabilities.put(ThreadIdentityCapability.PTHREAD_SELF, GuestThreadCapabilityState.IMPLEMENTED);
        capabilities.put(ThreadIdentityCapability.TPIDR, GuestThreadCapabilityState.IMPLEMENTED);
        capabilities.put(ThreadIdentityCapability.ERRNO_ADDRESS, GuestThreadCapabilityState.IMPLEMENTED);
        capabilities.put(ThreadIdentityCapability.FUTEX_OWNER_TID, GuestThreadCapabilityState.IMPLEMENTED);
        capabilities.put(ThreadIdentityCapability.SIGNAL_STATE,
                GuestThreadCapabilityState.NOT_OBSERVED);
        capabilities.put(ThreadIdentityCapability.ROBUST_LIST,
                GuestThreadCapabilityState.UNSUPPORTED_FAIL_CLOSED);
        capabilities.put(ThreadIdentityCapability.CLEAR_CHILD_TID,
                GuestThreadCapabilityState.NOT_OBSERVED);
        capabilities.put(ThreadIdentityCapability.JNI_ATTACHMENT,
                GuestThreadCapabilityState.NOT_OBSERVED);
    }

    public static ThreadIdentityProvider installProcessLeader(Emulator<?> emulator, int processId,
                                                               long pthreadSelf, long tpidr,
                                                               long errnoAddress, String provenance) {
        if (emulator == null) {
            throw new NullPointerException("emulator");
        }
        ThreadIdentityProvider existing = emulator.get(EMULATOR_KEY);
        if (existing != null) {
            existing.requireMatchingProcessLeader(processId, pthreadSelf, tpidr, errnoAddress);
            return existing;
        }
        ThreadIdentityProvider provider = new ThreadIdentityProvider(processId, pthreadSelf, tpidr,
                errnoAddress, provenance);
        emulator.set(EMULATOR_KEY, provider);
        return provider;
    }

    public static ThreadIdentityProvider find(Emulator<?> emulator) {
        return emulator == null ? null : emulator.get(EMULATOR_KEY);
    }

    public static ThreadIdentityProvider require(Emulator<?> emulator) {
        ThreadIdentityProvider provider = find(emulator);
        if (provider == null) {
            throw new ThreadIdentityUnavailableException("guest thread runtime is not installed");
        }
        return provider;
    }

    public synchronized GuestThreadCapabilityState getCapability(ThreadIdentityCapability capability) {
        if (capability == null) {
            throw new NullPointerException("capability");
        }
        return capabilities.get(capability);
    }

    /** Exposes the run-owned model only for audited runtime integration. */
    public synchronized RunContext getRunContext() {
        return run;
    }

    /** Process-leader incarnation registered at TLS install (primary-role-like bootstrap role structure). */
    public synchronized GuestThreadIncarnation getProcessLeaderIncarnation() {
        requireOpen();
        return processLeader;
    }

    /**
     * Observe current guest task against a structural role descriptor.
     */
    public synchronized RoleObservationReceipt observeCurrentRole(Emulator<?> emulator,
                                                                  RoleEvidenceDescriptor descriptor) {
        requireOpen();
        final Emulator<?> emu = emulator;
        ProductionRoleObservationAuthority.EmulatorTaskAccess access =
                new ProductionRoleObservationAuthority.EmulatorTaskAccess() {
                    @Override
                    public TaskThreadBinding requireCurrentBinding(RunContext expectedRun) {
                        if (expectedRun != run) {
                            throw new IllegalArgumentException("role observation run mismatch");
                        }
                        return requireCurrent(emu).getTaskBinding();
                    }
                };
        return run.getRoleObservationAuthority().observeCurrent(descriptor, access);
    }

    /**
     * Observe the process-leader incarnation (no current carrier required).
     */
    public synchronized RoleObservationReceipt observeProcessLeaderRole(
            RoleEvidenceDescriptor descriptor) {
        requireOpen();
        return run.getRoleObservationAuthority().observeIncarnation(descriptor, processLeader);
    }

    /**
     * Records guest-visible thread name on the current task's incarnation
     * (prctl PR_SET_NAME / pthread_setname_np). Silently ignores when the current
     * task has no guest binding yet (early libc/zygote names).
     */
    public synchronized void recordCurrentGuestThreadName(Emulator<?> emulator, String name) {
        requireOpen();
        if (name == null || name.trim().isEmpty() || emulator == null) {
            return;
        }
        try {
            GuestThreadIdentitySnapshot snapshot = requireCurrent(emulator);
            GuestThreadIncarnation incarnation = run.getThreadRegistry()
                    .getIncarnation(snapshot.getIncarnationId());
            run.getRoleObservationAuthority().noteGuestThreadName(incarnation, name.trim());
        } catch (ThreadIdentityUnavailableException ignored) {
            // Name capture is opportunistic; bootstrap role stays fail-closed without the name.
        }
    }

    public synchronized GuestThreadIdentitySnapshot bindProcessLeaderTask(Task task) {
        requireOpen();
        if (task == null || !task.isProcessLeaderTask() || task.getId() != processId) {
            throw new ThreadIdentityUnavailableException("task is not the explicit process leader");
        }
        return bind(task, processLeader, processLeaderPthreadSelf, processLeaderTpidr,
                processLeaderErrnoAddress, processId, "process-leader-task");
    }

    public synchronized GuestThreadIdentitySnapshot registerNativeClone(Task task, int guestTid,
                                                                          long pthreadSelf, long tpidr,
                                                                          long errnoAddress,
                                                                          String provenance) {
        requireOpen();
        if (task == null) {
            throw new NullPointerException("task");
        }
        if (task.isProcessLeaderTask()) {
            throw new IllegalArgumentException("native clone cannot use process leader task");
        }
        if (guestTid <= 0 || guestTid == processId) {
            throw new ThreadIdentityUnavailableException(
                    "non-leader native clone cannot use process pid");
        }
        requirePointer(pthreadSelf, "native clone pthread_self");
        requirePointer(tpidr, "native clone TPIDR");
        requirePointer(errnoAddress, "native clone errno address");
        if (provenance == null || provenance.trim().isEmpty()) {
            throw new IllegalArgumentException("native clone provenance is required");
        }
        TaskThreadBinding existing = task.getTaskThreadBinding();
        if (existing != null) {
            GuestThreadIdentitySnapshot snapshot = identities.get(existing);
            if (snapshot != null) {
                return snapshot;
            }
            throw new ThreadIdentityUnavailableException("task has a foreign thread binding");
        }
        String taskIdentity = "native-clone-task-" + nextTaskSerial++;
        ThreadBirthRecord birth = ThreadBirthRecord.nativeCloneCreatedTask(run.getId(), processId,
                taskIdentity, nextBirthEpoch++, provenance.trim());
        ThreadIdentityEvidence evidence = evidence(run.getId(), guestTid, pthreadSelf, tpidr,
                pthreadSelf, provenance + ":clone");
        GuestThreadIncarnation incarnation = run.getThreadRegistry().registerIncarnation(birth, evidence);
        return bind(task, incarnation, pthreadSelf, tpidr, errnoAddress, guestTid, taskIdentity);
    }

    public synchronized GuestThreadIdentitySnapshot requireCurrent(Emulator<?> emulator) {
        if (emulator == null) {
            throw new NullPointerException("emulator");
        }
        Task task = emulator.get(Task.TASK_KEY);
        if (task == null) {
            throw new ThreadIdentityUnavailableException("current execution has no guest task binding");
        }
        TaskThreadBinding binding = task.getTaskThreadBinding();
        if (binding == null && task.isProcessLeaderTask()) {
            return bindProcessLeaderTask(task);
        }
        return requireTask(task);
    }

    public synchronized GuestThreadIdentitySnapshot requireTask(Task task) {
        requireOpen();
        if (task == null) {
            throw new ThreadIdentityUnavailableException("guest task is missing");
        }
        TaskThreadBinding binding = task.getTaskThreadBinding();
        if (binding == null || !binding.isBound()) {
            throw new ThreadIdentityUnavailableException("guest task has no active thread binding");
        }
        GuestThreadIdentitySnapshot snapshot = identities.get(binding);
        if (snapshot == null) {
            throw new ThreadIdentityUnavailableException("task binding is not owned by this run");
        }
        return snapshot;
    }

    public synchronized boolean isBound(Task task) {
        if (closed || task == null) {
            return false;
        }
        TaskThreadBinding binding = task.getTaskThreadBinding();
        return binding != null && binding.isBound() && identities.containsKey(binding);
    }

    /**
     * Retires one exact task binding. Numeric TID reuse is possible only after
     * this transition reaches DEAD and removes all provider-owned references.
     */
    public synchronized void retireTask(Task task) {
        if (closed) {
            throw new ThreadIdentityUnavailableException("guest thread runtime is closed");
        }
        if (task == null) {
            throw new NullPointerException("task");
        }
        TaskThreadBinding binding = task.getTaskThreadBinding();
        if (binding == null || !binding.isBound()) {
            throw new ThreadIdentityUnavailableException("task has no live binding to retire");
        }
        GuestThreadIdentitySnapshot snapshot = identities.get(binding);
        if (snapshot == null) {
            throw new ThreadIdentityUnavailableException("task binding is not owned by this runtime");
        }
        GuestThreadIncarnation incarnation = run.getThreadRegistry().getIncarnation(binding.getThreadId());
        if (!snapshot.getIncarnationId().equals(incarnation.getId())) {
            throw new ThreadRuntimeIntegrityException("task identity snapshot does not match incarnation");
        }
        RuntimeInvocation invocation = runtimeInvocations.get(binding);
        if (invocation != null) {
            if (!isRuntimeTerminal(invocation.getState())) {
                run.quarantine();
                throw new ThreadRuntimeIntegrityException("task exits before its exact invocation terminal");
            }
            if (!invocation.getJniLocalFrames().isReleased()) {
                run.quarantine();
                throw new ThreadRuntimeIntegrityException(
                        "task exits before its carrier releases invocation JNI local frames");
            }
        }
        run.getThreadRegistry().retireTask(incarnation, task, binding);
        identities.remove(binding);
        executionStates.remove(binding);
        runtimeInvocations.remove(binding);
        // runtime JNI: notify optional VM-side exact-thread cleanup hook if registered.
        Runnable jniCleanup = jniExactThreadCleanup;
        if (jniCleanup != null) {
            // Hook is registered by DalvikVM64; it captures the incarnation id itself.
            // For retirement we pass via ThreadLocal-style holder.
            retiringThreadId = incarnation.getId();
            try {
                jniCleanup.run();
            } finally {
                retiringThreadId = null;
            }
        }
    }

    private volatile Runnable jniExactThreadCleanup;
    private volatile ThreadIncarnationId retiringThreadId;

    /**
     * Optional VM-side hook for exact-thread JNIEnv/pending-exception cleanup on
     * task retirement. Only DalvikVM64 should register this.
     */
    public synchronized void setJniExactThreadCleanup(Runnable cleanup) {
        this.jniExactThreadCleanup = cleanup;
    }

    public ThreadIncarnationId getRetiringThreadId() {
        return retiringThreadId;
    }

    /** Returns only the execution state owned by the explicit binding on this task. */
    public synchronized GuestThreadExecutionState requireExecutionState(Task task) {
        GuestThreadIdentitySnapshot identity = requireTask(task);
        GuestThreadExecutionState state = executionStates.get(identity.getTaskBinding());
        if (state == null || !identity.getIncarnationId().equals(state.getThreadId())) {
            throw new ThreadIdentityUnavailableException("task has no owned guest execution state");
        }
        return state;
    }

    /**
     * runtime JNI: exact-task JNI frame stack lookup. Returns null when the task
     * has no admitted runtime invocation (legacy unbound path).
     */
    public synchronized InvocationJniLocalFrameStack findInvocationJniFrames(Task task) {
        if (task == null) {
            return null;
        }
        TaskThreadBinding binding = task.getTaskThreadBinding();
        if (binding == null || !binding.isBound()) {
            return null;
        }
        RuntimeInvocation invocation = runtimeInvocations.get(binding);
        return invocation == null ? null : invocation.getJniLocalFrames();
    }

    /**
     * runtime JNI: exact-thread JNI cleanup on task retirement — clear only this
     * incarnation's pending exception attachment surface. Called by BaseVM/Dalvik
     * detach paths; never sweeps other threads.
     */
    public synchronized ThreadIncarnationId requireBoundIncarnationId(Task task) {
        return requireTask(task).getIncarnationId();
    }

    /**
     * Registers a physical task allocation as the StackRegion of its already-bound
     * incarnation. This never creates an identity for a carrier or host thread.
     */
    public synchronized StackRegion registerTaskStackRegion(Task task, long lowerBound,
                                                             long top, long canary) {
        return requireExecutionState(task).installStackRegion(lowerBound, top, canary);
    }

    /**
     * Imports a prepared pre-submit reservation into the emulator-owned task
     * lifecycle. This is an identity transfer only; it is not final admission.
     */
    public synchronized GuestThreadIdentitySnapshot adoptReservedCarrier(
            CarrierAdmissionReservation reservation) {
        requireOpen();
        if (reservation == null || !run.getId().equals(reservation.getRunId())) {
            throw new ThreadIdentityUnavailableException("admission reservation belongs to another run");
        }
        Task carrier = reservation.getCarrier();
        TaskThreadBinding binding = reservation.getBinding();
        if (!reservation.matchesLive(carrier, reservation.getRecord())
                || carrier.getTaskThreadBinding() != binding) {
            throw new ThreadRuntimeIntegrityException("adopted carrier reservation is no longer live");
        }
        return putProviderProjection(reservation.getIncarnationId(), binding, reservation.getInvocationId());
    }

    /**
     * Imports a final dispatcher-accepted admission into the emulator-owned task
     * lifecycle. This is an identity transfer, never a role/task-id lookup.
     */
    public synchronized GuestThreadIdentitySnapshot adoptAdmittedCarrier(AdmissionReceipt receipt) {
        requireOpen();
        if (receipt == null || !run.getId().equals(receipt.getRunId())) {
            throw new ThreadIdentityUnavailableException("admission receipt belongs to another run");
        }
        Task carrier = receipt.getCarrier();
        TaskThreadBinding binding = receipt.getBinding();
        if (!receipt.matchesLive(carrier, receipt.getRecord())
                || carrier.getTaskThreadBinding() != binding) {
            throw new ThreadRuntimeIntegrityException("adopted carrier admission is no longer live");
        }
        return putProviderProjection(receipt.getIncarnationId(), binding, receipt.getInvocationId());
    }

    private GuestThreadIdentitySnapshot putProviderProjection(ThreadIncarnationId incarnationId,
                                                            TaskThreadBinding binding,
                                                            RuntimeInvocationId invocationId) {
        GuestThreadIdentitySnapshot existing = identities.get(binding);
        if (existing != null) {
            RuntimeInvocation existingInvocation = runtimeInvocations.get(binding);
            if (!existing.getIncarnationId().equals(incarnationId)
                    || existingInvocation == null
                    || !existingInvocation.getId().equals(invocationId)) {
                throw new ThreadRuntimeIntegrityException("carrier admission conflicts with provider identity");
            }
            return existing;
        }
        GuestThreadIncarnation incarnation = run.getThreadRegistry().getIncarnation(incarnationId);
        if (!incarnation.isActive()) {
            throw new ThreadRuntimeIntegrityException("admitted carrier incarnation is not live");
        }
        RuntimeInvocation invocation = run.getInvocationRegistry().requireRegistered(invocationId);
        if (!incarnationId.equals(invocation.getId().getThreadId())) {
            throw new ThreadRuntimeIntegrityException("admitted invocation belongs to another incarnation");
        }
        ThreadIdentityEvidence evidence = incarnation.getEvidence();
        GuestThreadIdentitySnapshot snapshot = new GuestThreadIdentitySnapshot(
                incarnation.getId(), binding, evidence.requireGuestTid(), evidence.requirePthreadSelf(),
                evidence.requireTpidr(), evidence.requireTcb(), evidence.requireGuestTid());
        identities.put(binding, snapshot);
        executionStates.put(binding, incarnation.getExecutionState());
        runtimeInvocations.put(binding, invocation);
        return snapshot;
    }

    /** Removes only a provider projection for a carrier rejected before dispatcher accept. */
    public synchronized void forgetPreSubmitReservation(CarrierAdmissionReservation reservation) {
        if (reservation == null || !run.getId().equals(reservation.getRunId())) {
            throw new ThreadIdentityUnavailableException("pre-submit reservation belongs to another run");
        }
        forgetProviderProjection(reservation.getBinding(), reservation.getInvocationId());
    }

    /** @deprecated Prefer {@link #forgetPreSubmitReservation(CarrierAdmissionReservation)}. */
    @Deprecated
    public synchronized void forgetPreSubmitAdmission(AdmissionReceipt receipt) {
        if (receipt == null || !run.getId().equals(receipt.getRunId())) {
            throw new ThreadIdentityUnavailableException("pre-submit admission belongs to another run");
        }
        forgetProviderProjection(receipt.getBinding(), receipt.getInvocationId());
    }

    private void forgetProviderProjection(TaskThreadBinding binding, RuntimeInvocationId invocationId) {
        RuntimeInvocation invocation = runtimeInvocations.get(binding);
        if (invocation != null && !invocation.getId().equals(invocationId)) {
            throw new ThreadRuntimeIntegrityException("pre-submit provider invocation mismatch");
        }
        identities.remove(binding);
        executionStates.remove(binding);
        runtimeInvocations.remove(binding);
    }

    /**
     * Admits an invocation only for an already-bound task with a registered
     * thread stack. It never infers identity from command, role, or host thread.
     */
    public synchronized RuntimeInvocation admitTaskInvocation(Task task, GuestCpuSnapshot entry) {
        requireOpen();
        if (entry == null) {
            throw new NullPointerException("entry");
        }
        GuestThreadIdentitySnapshot identity = requireTask(task);
        TaskThreadBinding binding = identity.getTaskBinding();
        RuntimeInvocation existing = runtimeInvocations.get(binding);
        if (existing != null) {
            return existing;
        }
        GuestThreadIncarnation incarnation = run.getThreadRegistry().getIncarnation(
                identity.getIncarnationId());
        RuntimeInvocation invocation = incarnation.getInvocationStack().startFresh(
                binding.getTaskGeneration(), entry);
        incarnation.getInvocationStack().attachCarrierLease(invocation, task, binding,
                binding.getTaskGeneration());
        runtimeInvocations.put(binding, invocation);
        return invocation;
    }

    /** Publishes an exact normal terminal before the bound carrier is destroyed. */
    public synchronized void completeTaskInvocation(Task task) {
        GuestThreadIdentitySnapshot identity = requireTask(task);
        RuntimeInvocation invocation = runtimeInvocations.get(identity.getTaskBinding());
        if (invocation == null || invocation.getState() == RuntimeInvocationState.TERMINAL) {
            return;
        }
        if (invocation.getState() != RuntimeInvocationState.RUNNING) {
            throw new ThreadRuntimeIntegrityException("task invocation is not running at normal completion");
        }
        GuestThreadIncarnation incarnation = run.getThreadRegistry().getIncarnation(
                identity.getIncarnationId());
        incarnation.getInvocationStack().complete(invocation);
    }

    /** Attributes an unhandled task fault to its exact bound invocation and carrier lease. */
    public synchronized boolean faultTaskInvocation(Task task, RuntimeException cause) {
        requireOpen();
        if (cause == null) {
            throw new NullPointerException("cause");
        }
        GuestThreadIdentitySnapshot identity = requireTask(task);
        RuntimeInvocation invocation = runtimeInvocations.get(identity.getTaskBinding());
        if (invocation == null) {
            return false;
        }
        if (invocation.getState() != RuntimeInvocationState.RUNNING) {
            throw new ThreadRuntimeIntegrityException("task fault has no running exact invocation");
        }
        run.getFaultController().propagateRootFault(invocation, cause);
        return true;
    }

    /** Validates a task-owned physical stack against its thread-owned logical region. */
    public synchronized void validateTaskStack(Task task, long stackPointer, long observedCanary) {
        requireExecutionState(task).validateTaskStack(stackPointer, observedCanary);
    }

    private GuestThreadIdentitySnapshot bind(Task task, GuestThreadIncarnation incarnation,
                                             long pthreadSelf, long tpidr, long errnoAddress,
                                             int futexOwnerTid, String taskIdentity) {
        TaskThreadBinding existing = task.getTaskThreadBinding();
        if (existing != null) {
            GuestThreadIdentitySnapshot snapshot = identities.get(existing);
            if (snapshot != null) {
                return snapshot;
            }
            throw new ThreadIdentityUnavailableException("task already has a foreign thread binding");
        }
        TaskThreadBinding binding = run.getThreadRegistry().bindTask(incarnation, task,
                taskIdentity, nextTaskGeneration++);
        GuestThreadIdentitySnapshot snapshot = new GuestThreadIdentitySnapshot(incarnation.getId(), binding,
                incarnation.getNumericGuestTid(), pthreadSelf, tpidr, errnoAddress, futexOwnerTid);
        identities.put(binding, snapshot);
        executionStates.put(binding, incarnation.getExecutionState());
        return snapshot;
    }

    private void requireMatchingProcessLeader(int pid, long pthreadSelf, long tpidr,
                                               long errnoAddress) {
        requireOpen();
        if (processId != pid || processLeaderPthreadSelf != pthreadSelf || processLeaderTpidr != tpidr
                || processLeaderErrnoAddress != errnoAddress) {
            throw new IllegalStateException("process leader identity changed within one run");
        }
    }

    private void requireOpen() {
        if (closed || run.getState() != RunState.ACTIVE) {
            throw new ThreadIdentityUnavailableException("guest thread runtime is not active");
        }
    }

    private static ThreadIdentityEvidence evidence(RunId runId, int guestTid, long pthreadSelf,
                                                   long tpidr, long tcb, String provenance) {
        return ThreadIdentityEvidence.builder(runId)
                .recordGuestTid(guestTid, provenance + ":gettid")
                .recordPthreadSelf(pthreadSelf, provenance + ":pthread_self")
                .recordTpidr(tpidr, provenance + ":tpidr")
                .recordTcb(tcb, provenance + ":tcb")
                .recordLifecycle(provenance + ":lifecycle")
                .build();
    }

    private static void requirePointer(long value, String field) {
        if (value == 0L) {
            throw new IllegalArgumentException(field + " must be non-zero");
        }
    }

    private static boolean isRuntimeTerminal(RuntimeInvocationState state) {
        return state == RuntimeInvocationState.TERMINAL || state == RuntimeInvocationState.FAULTED
                || state == RuntimeInvocationState.CANCELLED
                || state == RuntimeInvocationState.DEPENDENCY_FAILED
                || state == RuntimeInvocationState.ABORTED_BY_RUN_DISPOSAL;
    }

    @Override
    public synchronized void close() {
        if (closed) {
            return;
        }
        closed = true;
        identities.clear();
        executionStates.clear();
        runtimeInvocations.clear();
        run.close();
    }
}
