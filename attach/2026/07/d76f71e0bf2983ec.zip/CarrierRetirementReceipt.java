package com.github.unidbg.thread.runtime;

import com.github.unidbg.thread.Task;

/**
 * Immutable evidence that the dispatcher has fully removed one carrier from every
 * ownership surface before logical retirement may proceed. It is never synthesized
 * from Task.destroy(); only the dispatcher (or an exact synthetic contract that
 * presents the same removal predicates) may issue it.
 */
public final class CarrierRetirementReceipt {

    private final Task carrier;
    private final TaskThreadBinding binding;
    private final long bindingEpoch;
    private final long taskGeneration;
    private final RuntimeInvocationId invocationId;
    private final CarrierLeaseId leaseId;
    private final long dispatcherSequence;
    private final boolean removedFromRunningSlot;
    private final boolean removedFromTaskList;
    private final boolean removedFromEagerQueue;
    private final boolean removedFromExternalQueue;
    private final boolean waiterDetached;
    private final boolean backendOwnershipReleased;

    CarrierRetirementReceipt(Task carrier,
                             TaskThreadBinding binding,
                             RuntimeInvocationId invocationId,
                             CarrierLeaseId leaseId,
                             long dispatcherSequence,
                             boolean removedFromRunningSlot,
                             boolean removedFromTaskList,
                             boolean removedFromEagerQueue,
                             boolean removedFromExternalQueue,
                             boolean waiterDetached,
                             boolean backendOwnershipReleased) {
        if (carrier == null || binding == null || invocationId == null || leaseId == null) {
            throw new NullPointerException("carrier retirement receipt identity");
        }
        if (!binding.isBound() || carrier.getTaskThreadBinding() != binding) {
            throw new ThreadRuntimeIntegrityException("retirement receipt requires exact live binding");
        }
        if (dispatcherSequence <= 0L) {
            throw new IllegalArgumentException("dispatcher sequence must be positive");
        }
        if (!removedFromRunningSlot || !removedFromTaskList || !removedFromEagerQueue
                || !removedFromExternalQueue || !waiterDetached || !backendOwnershipReleased) {
            throw new ThreadRuntimeIntegrityException(
                    "retirement receipt requires full dispatcher removal evidence");
        }
        this.carrier = carrier;
        this.binding = binding;
        this.bindingEpoch = binding.getBindingEpoch();
        this.taskGeneration = binding.getTaskGeneration();
        this.invocationId = invocationId;
        this.leaseId = leaseId;
        this.dispatcherSequence = dispatcherSequence;
        this.removedFromRunningSlot = true;
        this.removedFromTaskList = true;
        this.removedFromEagerQueue = true;
        this.removedFromExternalQueue = true;
        this.waiterDetached = true;
        this.backendOwnershipReleased = true;
    }

    public Task getCarrier() {
        return carrier;
    }

    public TaskThreadBinding getBinding() {
        return binding;
    }

    public long getBindingEpoch() {
        return bindingEpoch;
    }

    public long getTaskGeneration() {
        return taskGeneration;
    }

    public RuntimeInvocationId getInvocationId() {
        return invocationId;
    }

    public CarrierLeaseId getLeaseId() {
        return leaseId;
    }

    public long getDispatcherSequence() {
        return dispatcherSequence;
    }

    public boolean isRemovedFromRunningSlot() {
        return removedFromRunningSlot;
    }

    public boolean isRemovedFromTaskList() {
        return removedFromTaskList;
    }

    public boolean isRemovedFromEagerQueue() {
        return removedFromEagerQueue;
    }

    public boolean isRemovedFromExternalQueue() {
        return removedFromExternalQueue;
    }

    public boolean isWaiterDetached() {
        return waiterDetached;
    }

    public boolean isBackendOwnershipReleased() {
        return backendOwnershipReleased;
    }

    boolean matches(Task task, CarrierLease lease, RuntimeInvocation invocation) {
        return task == carrier
                && lease != null
                && lease.getId().equals(leaseId)
                && invocation != null
                && invocation.getId().equals(invocationId)
                && binding == lease.getBinding()
                && bindingEpoch == binding.getBindingEpoch()
                && taskGeneration == binding.getTaskGeneration();
    }
}
