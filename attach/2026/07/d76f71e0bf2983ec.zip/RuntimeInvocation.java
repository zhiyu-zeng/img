package com.github.unidbg.thread.runtime;

import com.github.unidbg.thread.Task;

/** Invocation-owned metadata. It neither owns a thread identity nor backend context. */
public final class RuntimeInvocation {

    private final RuntimeInvocationId id;
    private final InvocationFrame frame;
    private final ReentryMode reentryMode;
    private final RuntimeInvocation parent;
    private final CallbackReturnBoundary callbackReturnBoundary;
    private final InvocationLocalFrame localFrame;
    private final InvocationJniLocalFrameStack jniLocalFrames;
    private RuntimeInvocationState state;
    private CarrierLease carrierLease;

    RuntimeInvocation(RuntimeInvocationId id, InvocationFrame frame, ReentryMode reentryMode,
                      RuntimeInvocation parent, CallbackReturnBoundary callbackReturnBoundary,
                      RuntimeInvocationState initialState) {
        if (id == null || frame == null || reentryMode == null || initialState == null) {
            throw new NullPointerException("runtime invocation identity");
        }
        if (!id.getThreadId().equals(frame.getThreadId())) {
            throw new IllegalArgumentException("invocation id and frame belong to different threads");
        }
        this.id = id;
        this.frame = frame;
        this.reentryMode = reentryMode;
        this.parent = parent;
        this.callbackReturnBoundary = callbackReturnBoundary;
        this.localFrame = new InvocationLocalFrame(id);
        this.jniLocalFrames = new InvocationJniLocalFrameStack(id);
        this.state = initialState;
    }

    public RuntimeInvocationId getId() {
        return id;
    }

    public InvocationFrame getFrame() {
        return frame;
    }

    public ReentryMode getReentryMode() {
        return reentryMode;
    }

    public RuntimeInvocation getParent() {
        return parent;
    }

    public CallbackReturnBoundary getCallbackReturnBoundary() {
        return callbackReturnBoundary;
    }

    public InvocationLocalFrame getLocalFrame() {
        return localFrame;
    }

    /** Concrete JNI local-frame stack; distinct from the G3 local ownership token. */
    public InvocationJniLocalFrameStack getJniLocalFrames() {
        return jniLocalFrames;
    }

    /** Binds one externally-created, non-owning carrier lease to this invocation. */
    synchronized CarrierLease attachCarrierLease(Task carrier, TaskThreadBinding binding,
                                                 long leaseSerial) {
        if (isTerminalState(state)) {
            throw new ThreadRuntimeIntegrityException("terminal invocation cannot acquire a carrier lease");
        }
        if (carrierLease != null) {
            throw new ThreadRuntimeIntegrityException("invocation already has a carrier lease");
        }
        carrierLease = new CarrierLease(id, carrier, binding, leaseSerial);
        return carrierLease;
    }

    public synchronized CarrierLease getCarrierLease() {
        return carrierLease;
    }

    public synchronized RuntimeInvocationState getState() {
        return state;
    }

    synchronized void transitionTo(RuntimeInvocationState next) {
        state = next;
    }

    private static boolean isTerminalState(RuntimeInvocationState value) {
        return value == RuntimeInvocationState.TERMINAL || value == RuntimeInvocationState.FAULTED
                || value == RuntimeInvocationState.CANCELLED
                || value == RuntimeInvocationState.DEPENDENCY_FAILED
                || value == RuntimeInvocationState.ABORTED_BY_RUN_DISPOSAL;
    }
}
