#!/usr/bin/env python3
"""
TARA libil2cpp.so 解密解压工具
自动从 SO 中提取资源表 + 两层 AES 解密 + LZMA 解压
用法: python decrypt_tara.py [输入SO] [输出SO]
"""
import struct, os, sys, subprocess

try:
    from Crypto.Cipher import AES
except ImportError:
    print("[!] pip install pycryptodome"); sys.exit(1)

# key/iv: 通过 hook aes_cbc_decrypt_wrapper 获取
# sub_55F6C派生的结果无法静态计算
LAYER2_KEY = bytes.fromhex("7F454C460201010000000000000000000300B7000100000000C0980500000000")
LAYER2_IV  = bytes(16)


def find_resource_entry(data, name=b"libil2cpp.so"):
    """从 SO 文件中搜索资源 entry"""
    idx = 0x300000
    while True:
        pos = data.find(name, idx)
        if pos < 0:
            return None
        iv_off = pos + 0x18
        key_off = pos + 0x2A
        off_off = pos + 0x60
        sz_off = pos + 0x68
        if sz_off + 8 <= len(data):
            off_val = struct.unpack_from("<Q", data, off_off)[0]
            sz_val = struct.unpack_from("<Q", data, sz_off)[0]
            if 0 < sz_val < 200000000 and off_val < len(data):
                return {
                    "offset": off_val,
                    "size": sz_val,
                    "key": data[key_off:key_off+32],
                    "iv": data[iv_off:iv_off+16],
                }
        idx = pos + 1


def main():
    so_in = sys.argv[1] if len(sys.argv) > 1 else r"C:\Users\ChxRe\Desktop\libgedenedo.so"
    so_out = sys.argv[2] if len(sys.argv) > 2 else os.path.join(os.path.dirname(os.path.abspath(__file__)), "libil2cpp_dec.so")
    work = os.path.dirname(os.path.abspath(__file__))

    print(f"输入: {so_in}")
    print(f"输出: {so_out}\n")

    with open(so_in, "rb") as f:
        data = f.read()
    print(f"[1] 读取 {len(data):,} 字节")

    # 搜索资源表
    print("[2] 搜索资源表...")
    entry = find_resource_entry(data)
    if entry is None:
        print("[!] 找不到资源 entry"); sys.exit(1)
    print(f"    offset=0x{entry['offset']:X} size=0x{entry['size']:X}")

    # Layer1 解密
    raw = data[entry["offset"]:entry["offset"]+entry["size"]]
    print(f"[3] Layer1 AES-CBC 解密 ({len(raw):,} bytes)...")
    dec1 = AES.new(entry["key"], AES.MODE_CBC, entry["iv"]).decrypt(raw)
    magic = struct.pack("<I", struct.unpack_from("<I", dec1, 0)[0]).decode()
    field = struct.unpack_from("<I", dec1, 0x0C)[0]
    enc_sz = struct.unpack_from("<I", dec1, 0x10)[0]
    props = dec1[0x18:0x1D]
    print(f"    {magic} enc={enc_sz:,} props={props.hex(' ')}")

    # Layer2 解密 (hook 捕获的 key)
    payload = dec1[0x20+field : 0x20+field+enc_sz]
    pad = (16 - len(payload) % 16) % 16
    print(f"[4] Layer2 AES-CBC 解密 ({len(payload):,} bytes)...")
    dec2 = AES.new(LAYER2_KEY, AES.MODE_CBC, LAYER2_IV).decrypt(payload + b'\x00' * pad)[:enc_sz]

    # LZMA 解压
    comp_path = os.path.join(work, "libil2cpp_compressed.bin")
    props_path = os.path.join(work, "libil2cpp_props.bin")
    with open(comp_path, "wb") as f: f.write(dec2)
    with open(props_path, "wb") as f: f.write(props)

    exe = os.path.join(work, "unpack.exe")
    if not os.path.exists(exe):
        print(f"[!] 找不到 {exe}"); sys.exit(1)

    print(f"[5] LZMA 解压...")
    r = subprocess.run([exe], capture_output=True, text=True, cwd=work, timeout=300)
    for line in r.stdout.strip().split("\n"):
        if "ret=" in line or "Saved" in line:
            print(f"    {line.strip()}")

    dec_path = os.path.join(work, "libil2cpp_dec.so")
    if not os.path.exists(dec_path):
        print("[!] 解压失败"); sys.exit(1)

    if so_out != dec_path:
        import shutil
        shutil.copy2(dec_path, so_out)

    sz = os.path.getsize(so_out)
    with open(so_out, "rb") as f:
        hdr = f.read(4)
    print(f"\n[OK] {so_out} ({sz/1024/1024:.2f} MB) {hdr}")

    for p in [comp_path, props_path]:
        os.remove(p)


if __name__ == "__main__":
    main()