function my_hook_dlopen() {
    Interceptor.attach(Module.getGlobalExportByName("android_dlopen_ext"), {
        onEnter: function (args) {
            var pathptr = args[0];
            if (pathptr !== undefined && pathptr != null) {
                var path = ptr(pathptr).readCString();
                // console.log(path)
                if (path.indexOf("libbaiduprotect.so") > -1) {
                    this.hook = true
                }
            }
        },
        onLeave: function (retval) {
            if (this.hook) {
                console.log("开始hook")
                onCreate()
            }
        }
    });
}


function onCreate() {
    var module = Process.getModuleByName("libbaiduprotect.so").base
    Interceptor.attach(module.add(0x5CEEC), {
        onEnter: function (args) {
            console.log(Java.cast(args[1], Java.use("java.lang.Object")))
            console.log(args[3].readCString())
        },
        onLeave: function (retval) {

        }
    })
    // Interceptor.attach(module.add(0x4CD54), {
    //     onEnter: function (args) {
    //         console.log(hexdump(this.context.x26, {
    //             length: 500
    //         }));
    //     },
    //     onLeave: function (retval) {
    //
    //     }
    // })
    // Interceptor.attach(module.add(0x120C0), {
    //     onEnter: function (args) {
    //         var obj = args[1]
    //         obj = Java.cast(obj, Java.use("java.lang.Object"));
    //         var methodId = args[2]
    //         console.log(`obj:${obj}, methodId:${methodId.add(0x10).toUInt32()}`)
    //     },
    //     onLeave: function (retval) {
    //
    //     }
    // })
    //   Interceptor.attach(module.add(0x4CC20), {
    //     onEnter: function (args) {
    //         console.log(hexdump(args[2]))
    //     },
    //     onLeave: function (retval) {
    //
    //     }
    // })
    // string pool
    // Interceptor.attach(module.add(0x12058),{
    //     onEnter:function (args){
    //
    //     },
    //     onLeave:function (retval){
    //         var result = Java.cast(retval, Java.use("java.lang.Object"));
    //         console.log(`retval:${result}`)
    //     }
    // })
    // Interceptor.attach(module.add(0x4CD00),{
    //     onEnter:function (args){
    //         // console.log(hexdump(this.context.x26,{
    //         //     length:400
    //         // }))
    //     },
    //     onLeave:function (retval){
    //
    //     }
    // })
    //  Interceptor.attach(module.add(0x5DF14),{
    //     onEnter:function (args){
    //         console.log(Java.cast(args[1], Java.use("java.lang.Object")))
    //         console.log(args[2].readCString())
    //         console.log(args[3].readCString())
    //         console.log("--------------------")
    //     },
    //     onLeave:function (retval){
    //
    //     }
    // })
    // Interceptor.attach(module.add(0x5CF78), {
    //     onEnter: function (args) {
    //         console.log(args[2])
    //     },
    //     onLeave: function (retval) {
    //         console.log(Java.cast(retval, Java.use("java.lang.Object")))
    //     }
    // })
    //  Interceptor.attach(module.add(0x5436c),{
    //     onEnter:function (args){
    //         console.log(args[2])
    //         console.log(this.context.x9)
    //         Thread.sleep(40)
    //     },
    //     onLeave:function (retval){
    //
    //     }
    // })
}

setImmediate(my_hook_dlopen, 200)

