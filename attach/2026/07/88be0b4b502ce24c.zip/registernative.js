function getModuleInfoByPtr(fnPtr) {
    var modules = Process.enumerateModules();
    var modname = null,
        base = null;
    modules.forEach(function (mod) {
        if (mod.base <= fnPtr && fnPtr.toInt32() <= mod.base.toInt32() + mod.size) {
            modname = mod.name;
            base = mod.base;
            return false;
        }
    });
    return [modname, base];
}
function hook_registNatives() {
    var env = Java.vm.getEnv();
    var handlePointer = env.handle.readPointer();
    console.log("handle: " + handlePointer);
    var nativePointer = handlePointer.add(215 * Process.pointerSize).readPointer();
    console.log("register: " + nativePointer);
    /**
     typedef struct {
        const char* name;
        const char* signature;
        void* fnPtr;
     } JNINativeMethod;
     jint RegisterNatives(JNIEnv* env, jclass clazz, const JNINativeMethod* methods, jint nMethods)
     */

    Interceptor.attach(nativePointer, {
        onEnter: function onEnter(args) {
            var env = Java.vm.getEnv();
            var p_size = Process.pointerSize;
            var methods = args[2];
            var methodcount = args[3].toInt32();
            var name = env.getClassName(args[1]);
            console.log("==== class: " + name + " ====");
            console.log("==== methods: " + methods + " nMethods: " + methodcount + " ====");

            for (var i = 0; i < methodcount; i++) {
                var idx = i * p_size * 3;
                var fnPtr = methods.add(idx + p_size * 2).readPointer();
                var infoArr = getModuleInfoByPtr(fnPtr);
                var modulename = infoArr[0];
                var modulebase = infoArr[1];
                var logstr = "name: " + methods.add(idx).readPointer().readCString() + ", signature: " + methods.add(idx + p_size).readPointer().readCString() + ", fnPtr: " + fnPtr + ", modulename: " + modulename + " -> base: " + modulebase;

                if (null != modulebase) {
                    logstr += ", offset: " + fnPtr.sub(modulebase);
                }

                console.log(logstr);
            }
        }
    });
}
hook_registNatives()