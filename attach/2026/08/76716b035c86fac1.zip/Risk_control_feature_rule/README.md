# 风控特征关联平台

把 `风控信息.xmind` 的字段树转成可检索、可关联、可追溯到规则的网页平台。

信息链路：**字段 → 关联 → 风险解释 → 规则**

## 打开

直接双击 `web/index.html`（无需起服务，data.js 以 `window.RC_DATA` 挂载）。

## 目录

```
rc-platform/
├── tools/build.py            # 构建器：xmind + 知识层 → web/data.js
├── data/
│   ├── knowledge/            # 知识层（手工维护，唯一需要编辑的地方）
│   │   ├── 00-risks.json     # 风险主题词典（12 个主题）
│   │   ├── 01-automation.json
│   │   ├── 02-network.json
│   │   ├── 03-emulator.json
│   │   ├── 04-integrity.json
│   │   ├── 05-identity.json
│   │   ├── 06-hook-debug.json
│   │   ├── 07-sensor.json
│   │   ├── 08-qemu-detail.json    # QEMU 属性细化维度
│   │   └── 09-rom-integrity.json  # ROM 一致性扩展维度
│   └── graph.json            # 构建产物（带缩进，便于 diff）
└── web/
    ├── index.html
    ├── style.css
    ├── app.js
    └── data.js               # 构建产物，勿手改
```

## 重新构建

```bash
python tools/build.py
```

输出示例：

```
字段 826 / 分类 9 / 规则 69 / 已写风险解释 458 (55%)
关联边 124
```

构建器会校验知识层路径是否命中字段树，未命中或歧义会打印告警——这样知识层不会静默地与字段脱节。

## 补充知识

编辑对应分类的 json，按路径挂到字段上：

```json
{
  "fields": [
    {
      "path": "自动化 / 群控检测 > 触控数据 > 点击坐标",
      "signals": ["automation", "farm"],
      "risk": "为什么采这个字段、它揭示什么风险",
      "detect": "采集方式与 API",
      "spoof": "对抗手法（可选）",
      "anomaly": "异常判据",
      "links": [
        { "to": "自动化 / 群控检测 > 自动点击器", "type": "证据来源", "note": "补充说明" }
      ]
    }
  ],
  "rules": [
    {
      "id": "R-XXX-001",
      "name": "规则名",
      "level": "high",
      "action": "处置动作",
      "signals": ["automation"],
      "logic": "自然语言表述的判定条件",
      "expr": "可执行的表达式草案",
      "note": "误伤控制说明",
      "fields": ["字段路径1", "字段路径2"]
    }
  ]
}
```

## 三个视图

- **字段探索** — 左树右详情，详情按四步链路展开；关联字段与规则字段可点击跳转
- **规则库** — 75 条规则按风险等级排序，每条列出判定逻辑、表达式与引用字段
- **风险矩阵** — 按 12 个风险主题反向索引字段与规则，用于评估每个主题被多少条独立证据链覆盖

顶部风险条可按主题过滤；`/` 聚焦搜索，`Esc` 清空。搜索覆盖字段名、风险解释、采集方式、异常判据与规则内容。
