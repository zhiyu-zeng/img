# -*- coding: utf-8 -*-
"""
风控特征关联平台 - 登录口令哈希生成器

用途：为 web/auth.js 的 USERS 表生成口令哈希，避免明文口令进仓库。

用法：
  python tools/passwd.py <账号> <口令>
  python tools/passwd.py python anda123MN

把输出那行粘进 web/auth.js 的 USERS 即可。SALT 需与 auth.js 保持一致。

注意：这是纯前端校验，哈希对访问者可见，只能挡住误入者，
      不构成访问控制。详见 web/auth.js 顶部的安全边界说明。
"""
import hashlib
import io
import sys

SALT = "rc-fp-2026"  # 必须与 web/auth.js 中的 SALT 一致


def hash_pass(plain):
    return hashlib.sha256((SALT + ":" + plain).encode("utf-8")).hexdigest()


def main():
    if len(sys.argv) != 3:
        sys.stdout.write(__doc__)
        raise SystemExit(1)
    user, plain = sys.argv[1], sys.argv[2]
    sys.stdout.write('    %s: "%s"\n' % (user, hash_pass(plain)))


if __name__ == "__main__":
    sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8")
    main()
