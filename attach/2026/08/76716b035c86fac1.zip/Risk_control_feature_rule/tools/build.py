# -*- coding: utf-8 -*-
"""
风控特征关联平台 - 数据构建器

职责（单一职责）：
  1. 解析 xmind 得到字段树（唯一事实来源：风控信息.xmind）
  2. 合并 data/knowledge/*.json 中的知识层（关联 / 风险解释 / 规则）
  3. 校验知识层路径是否命中字段树，输出未命中告警
  4. 产出 web/data.js（挂 window.RC_DATA，使前端可 file:// 直接打开）

用法：
  python tools/build.py
"""
import io
import json
import os
import sys
import zipfile
from collections import OrderedDict

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))

# xmind 查找顺序：项目根优先，其次仓库上一级（历史存放位置）
XMIND_CANDIDATES = [
    os.path.join(ROOT, "风控信息.xmind"),
    os.path.join(os.path.dirname(ROOT), "风控信息.xmind"),
]
XMIND = next((p for p in XMIND_CANDIDATES if os.path.exists(p)), XMIND_CANDIDATES[0])

KNOWLEDGE_DIR = os.path.join(ROOT, "data", "knowledge")
OUT_JS = os.path.join(ROOT, "web", "data.js")
OUT_JSON = os.path.join(ROOT, "data", "graph.json")

SEP = " > "  # 知识层路径分隔符（字段标题本身含 "/"，不能用 "/"）


# ---------------------------------------------------------------- xmind 解析

def norm_title(t):
    """标题规范化：多行标题压成单行，去除首尾空白与反引号。"""
    t = (t or "").replace("\r", "\n").replace("`", "")  # 反引号为 Markdown 装饰，统一剥离
    parts = [p.strip() for p in t.split("\n") if p.strip()]
    return " | ".join(parts).strip()


def load_xmind(path):
    """读取 xmind 的 content.json（XMind Zen/2020+ 格式）。"""
    with zipfile.ZipFile(path) as z:
        names = z.namelist()
        if "content.json" not in names:
            raise SystemExit("不支持的 xmind：未找到 content.json，实际内容 %s" % names)
        raw = z.read("content.json").decode("utf-8")
    return json.loads(raw)


def flatten(sheet):
    """字段树扁平化为节点数组，保留 path / parent / children / depth / category。"""
    nodes = []
    index = {}  # path -> node

    def walk(topic, parent_id, path, depth, category):
        title = norm_title(topic.get("title"))
        nid = "f%d" % len(nodes)
        full = path + [title]
        node = OrderedDict()
        node["id"] = nid
        node["title"] = title
        node["path"] = full
        node["depth"] = depth
        node["parent"] = parent_id
        node["category"] = category
        node["children"] = []
        nodes.append(node)
        index[SEP.join(full)] = node

        for child in (topic.get("children") or {}).get("attached") or []:
            cid = walk(child, nid, full, depth + 1, category if depth >= 1 else norm_title(child.get("title")))
            node["children"].append(cid)
        return nid

    root = sheet["rootTopic"]
    # 根节点不进入节点表，直接从一级分类开始，保持路径以分类打头
    for cat in (root.get("children") or {}).get("attached") or []:
        walk(cat, None, [], 1, norm_title(cat.get("title")))
    return nodes, index


# ------------------------------------------------------------- 知识层合并

def load_knowledge():
    """读取 data/knowledge/*.json 并按文件名排序合并。"""
    merged = {"risks": OrderedDict(), "fields": [], "rules": []}
    if not os.path.isdir(KNOWLEDGE_DIR):
        return merged
    for fn in sorted(os.listdir(KNOWLEDGE_DIR)):
        if not fn.endswith(".json"):
            continue
        with io.open(os.path.join(KNOWLEDGE_DIR, fn), encoding="utf-8") as f:
            try:
                doc = json.load(f)
            except ValueError as e:
                raise SystemExit("知识文件 %s JSON 解析失败：%s" % (fn, e))
        for rid, r in (doc.get("risks") or {}).items():
            merged["risks"][rid] = r
        for item in doc.get("fields") or []:
            item["_src"] = fn
            merged["fields"].append(item)
        for rule in doc.get("rules") or []:
            rule["_src"] = fn
            merged["rules"].append(rule)
    return merged


def resolve(path_expr, index, nodes):
    """把知识层路径解析为节点。支持全路径与唯一后缀路径。"""
    # 按 SEP 拆分而非裸 ">"：字段标题本身可能含 ">"（如 "注册->登录"）
    key = SEP.join([s.strip() for s in path_expr.replace("`", "").split(SEP)])
    if key in index:
        return index[key]
    segs = key.split(SEP)
    hits = [n for n in nodes if n["path"][-len(segs):] == segs]
    if len(hits) == 1:
        return hits[0]
    if len(hits) > 1:
        return ("AMBIGUOUS", [SEP.join(h["path"]) for h in hits])
    return None


def build():
    if not os.path.exists(XMIND):
        raise SystemExit("未找到 xmind，已在以下位置查找：\n  %s" % "\n  ".join(XMIND_CANDIDATES))

    sheets = load_xmind(XMIND)
    nodes, index = flatten(sheets[0])
    kb = load_knowledge()

    warnings = []

    # 1) 字段知识挂载
    for item in kb["fields"]:
        target = resolve(item["path"], index, nodes)
        if target is None:
            warnings.append("[未命中字段] %s (%s)" % (item["path"], item.get("_src")))
            continue
        if isinstance(target, tuple):
            warnings.append("[路径歧义] %s -> %s" % (item["path"], target[1]))
            continue
        for k in ("risk", "detect", "spoof", "anomaly", "collect"):
            if item.get(k):
                target[k] = item[k]
        if item.get("signals"):
            target["signals"] = item["signals"]
        if item.get("aliases"):
            target["aliases"] = item["aliases"]
        target.setdefault("links", [])
        for ln in item.get("links") or []:
            peer = resolve(ln["to"], index, nodes)
            if peer is None:
                warnings.append("[关联目标未命中] %s -> %s" % (item["path"], ln["to"]))
                continue
            if isinstance(peer, tuple):
                warnings.append("[关联目标歧义] %s -> %s" % (ln["to"], peer[1]))
                continue
            target["links"].append({"to": peer["id"], "type": ln["type"], "note": ln.get("note", "")})
            # 自动补反向边，保证任一端都能看到关联（避免知识重复录入，DRY）
            peer.setdefault("links", [])
            peer["links"].append({"to": target["id"], "type": ln["type"], "note": ln.get("note", ""), "back": True})

    # 关联按目标节点合并：同一对节点只出现一次，类型取并集、备注取并集
    for n in nodes:
        if not n.get("links"):
            continue
        merged = OrderedDict()
        for ln in n["links"]:
            if ln["to"] == n["id"]:
                continue  # 剔除自关联
            cur = merged.get(ln["to"])
            if cur is None:
                merged[ln["to"]] = {"to": ln["to"], "types": [ln["type"]],
                                    "notes": [ln["note"]] if ln.get("note") else []}
                continue
            if ln["type"] not in cur["types"]:
                cur["types"].append(ln["type"])
            if ln.get("note") and ln["note"] not in cur["notes"]:
                cur["notes"].append(ln["note"])
        n["links"] = [{"to": v["to"], "type": " / ".join(v["types"]),
                       "note": "；".join(v["notes"])} for v in merged.values()]

    # 2) 规则字段引用解析
    rules = []
    for rule in kb["rules"]:
        refs = []
        for p in rule.get("fields") or []:
            t = resolve(p, index, nodes)
            if t is None:
                warnings.append("[规则字段未命中] %s -> %s" % (rule["id"], p))
                continue
            if isinstance(t, tuple):
                warnings.append("[规则字段歧义] %s -> %s" % (p, t[1]))
                continue
            refs.append(t["id"])
            t.setdefault("rules", []).append(rule["id"])
        out = OrderedDict()
        for k in ("id", "name", "level", "action", "signals", "expr", "logic", "note"):
            if rule.get(k):
                out[k] = rule[k]
        out["fields"] = refs
        rules.append(out)

    # 3) 信号（风险主题）倒排：signal -> 字段
    for n in nodes:
        n.setdefault("signals", [])
        n.setdefault("links", [])
        n.setdefault("rules", [])

    graph = OrderedDict()
    graph["meta"] = {
        "source": os.path.basename(XMIND),
        "fields": len(nodes),
        "categories": len([n for n in nodes if n["depth"] == 1]),
        "rules": len(rules),
        "covered": len([n for n in nodes if n.get("risk")]),
    }
    graph["risks"] = kb["risks"]
    graph["nodes"] = nodes
    graph["rules"] = rules

    for d in (os.path.dirname(OUT_JSON), os.path.dirname(OUT_JS)):
        if not os.path.isdir(d):
            os.makedirs(d)

    with io.open(OUT_JSON, "w", encoding="utf-8") as f:
        f.write(json.dumps(graph, ensure_ascii=False, indent=1))
    with io.open(OUT_JS, "w", encoding="utf-8") as f:
        f.write("// 自动生成，请勿手改；改 data/knowledge/*.json 后重跑 python tools/build.py\n")
        f.write("window.RC_DATA = ")
        f.write(json.dumps(graph, ensure_ascii=False))
        f.write(";\n")

    out = sys.stdout
    out.write("字段 %d / 分类 %d / 规则 %d / 已写风险解释 %d (%.0f%%)\n" % (
        graph["meta"]["fields"], graph["meta"]["categories"], graph["meta"]["rules"],
        graph["meta"]["covered"], 100.0 * graph["meta"]["covered"] / max(1, graph["meta"]["fields"])))
    link_cnt = sum(len(n["links"]) for n in nodes) // 2
    out.write("关联边 %d\n" % link_cnt)
    if warnings:
        out.write("\n告警 %d 条：\n" % len(warnings))
        for w in warnings:
            out.write("  " + w + "\n")
    out.write("\n输出：%s\n" % OUT_JS)


if __name__ == "__main__":
    sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8")
    build()
