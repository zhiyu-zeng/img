/* Admin user management: PHP/MySQL API. */
(function () {
  "use strict";

  var $ = function (id) { return document.getElementById(id); };
  var currentUsers = [];

  function esc(s) {
    return String(s == null ? "" : s).replace(/[&<>"]/g, function (c) {
      return { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" }[c];
    });
  }

  function showMsg(id, msg, ok) {
    var el = $(id);
    el.textContent = msg || "";
    el.classList.toggle("ok", !!ok);
  }

  function statusText(u) {
    if (String(u.is_expired) === "1") return "\u5df2\u8fc7\u671f";
    if (String(u.is_active) !== "1") return "\u7981\u7528";
    return "\u542f\u7528";
  }

  function expiresText(u) {
    return u.expires_at_text ? "\u8fc7\u671f " + u.expires_at_text : "\u6c38\u4e0d\u8fc7\u671f";
  }

  function renderUsers(users) {
    currentUsers = users || [];
    $("usersBox").innerHTML = currentUsers.length ? currentUsers.map(function (u) {
      return '<div class="admin-user" data-user="' + esc(u.username) + '">' +
        '<span class="admin-name">' + esc(u.username) + '</span>' +
        '<span class="admin-role ' + esc(u.role) + '">' + (u.role === "admin" ? "\u7ba1\u7406\u5458" : "\u666e\u901a\u7528\u6237") + '</span>' +
        '<span class="admin-time">' + esc(statusText(u)) + ' \u00b7 ' + esc(expiresText(u)) + ' \u00b7 ' + esc(u.created_at_text || "") + '</span>' +
        '<span class="admin-row-actions"><button class="admin-mini" data-action="edit" data-user="' + esc(u.username) + '" type="button">\u7f16\u8f91</button>' +
        '<button class="admin-mini danger" data-action="delete" data-user="' + esc(u.username) + '" type="button">\u5220\u9664</button></span></div>';
    }).join("") : '<p class="sec-d">\u6682\u65e0\u7528\u6237</p>';
  }

  function loadUsers() {
    window.RC_AUTH.listUsers().then(renderUsers).catch(function (e) {
      $("usersBox").innerHTML = '<p class="login-err">' + esc(e.message) + '</p>';
    });
  }

  function findUser(username) {
    for (var i = 0; i < currentUsers.length; i++) {
      if (currentUsers[i].username === username) return currentUsers[i];
    }
    return null;
  }

  function openEdit(username) {
    var u = findUser(username);
    if (!u) return;
    $("editUser").value = u.username;
    $("editPass").value = "";
    $("editRole").value = u.role === "admin" ? "admin" : "user";
    $("editActive").value = String(u.is_active) === "1" ? "1" : "0";
    $("editExpires").value = u.expires_at || "";
    showMsg("editMsg", "");
    $("editCard").hidden = false;
    $("editUser").scrollIntoView({ block: "center", behavior: "smooth" });
  }

  function closeEdit() {
    $("editCard").hidden = true;
    $("editForm").reset();
    showMsg("editMsg", "");
  }

  function init() {
    var sess = window.RC_AUTH.session();
    if (sess) $("username").textContent = sess.user;

    $("userForm").addEventListener("submit", function (e) {
      e.preventDefault();
      var username = $("newUser").value.trim();
      var password = $("newPass").value;
      var role = $("newRole").value;
      var expiresAt = $("newExpires").value;
      if (!username || !password) { showMsg("adminMsg", "\u8bf7\u586b\u5199\u7528\u6237\u540d\u548c\u521d\u59cb\u53e3\u4ee4"); return; }
      $("addUserBtn").disabled = true;
      showMsg("adminMsg", "\u63d0\u4ea4\u4e2d\u2026");
      window.RC_AUTH.addUser(username, password, role, expiresAt).then(function () {
        $("newUser").value = "";
        $("newPass").value = "";
        $("newRole").value = "user";
        $("newExpires").value = "";
        showMsg("adminMsg", "\u7528\u6237\u5df2\u5199\u5165 MySQL", true);
        loadUsers();
      }).catch(function (err) {
        showMsg("adminMsg", err.message || "\u6dfb\u52a0\u5931\u8d25");
      }).finally(function () {
        $("addUserBtn").disabled = false;
      });
    });

    $("editForm").addEventListener("submit", function (e) {
      e.preventDefault();
      $("saveEditBtn").disabled = true;
      showMsg("editMsg", "\u4fdd\u5b58\u4e2d\u2026");
      window.RC_AUTH.updateUser({
        username: $("editUser").value,
        password: $("editPass").value,
        role: $("editRole").value,
        is_active: $("editActive").value === "1",
        expires_at: $("editExpires").value
      }).then(function () {
        showMsg("editMsg", "\u5df2\u4fdd\u5b58", true);
        loadUsers();
      }).catch(function (err) {
        showMsg("editMsg", err.message || "\u4fdd\u5b58\u5931\u8d25");
      }).finally(function () {
        $("saveEditBtn").disabled = false;
      });
    });

    $("cancelEditBtn").addEventListener("click", closeEdit);

    $("usersBox").addEventListener("click", function (e) {
      var btn = e.target.closest("button[data-action]");
      if (!btn) return;
      var username = btn.getAttribute("data-user");
      if (btn.getAttribute("data-action") === "edit") {
        openEdit(username);
        return;
      }
      if (!confirm("\u786e\u5b9a\u5220\u9664\u7528\u6237 " + username + " \u5417\uff1f")) return;
      btn.disabled = true;
      window.RC_AUTH.deleteUser(username).then(function () {
        if ($("editUser").value === username) closeEdit();
        loadUsers();
      }).catch(function (err) {
        alert(err.message || "\u5220\u9664\u5931\u8d25");
      }).finally(function () {
        btn.disabled = false;
      });
    });

    $("logout").addEventListener("click", function () { window.RC_AUTH.logout(); });
    loadUsers();
  }

  window.RC_AUTH.requireAuth(true).then(function (ok) {
    if (ok) init();
  });
})();
