(function () {
  "use strict";
  var $ = function (id) { return document.getElementById(id); };
  var form = $("setupForm"), btn = $("setupBtn"), msg = $("setupMsg");
  function show(text, ok) {
    msg.textContent = text || "";
    msg.classList.toggle("ok", !!ok);
  }
  form.addEventListener("submit", function (e) {
    e.preventDefault();
    btn.disabled = true;
    show("\u521d\u59cb\u5316\u4e2d\u2026");
    fetch("api/install.php", {
      method: "POST",
      credentials: "same-origin",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        token: $("token").value,
        username: $("user").value.trim(),
        password: $("pass").value
      })
    }).then(function (res) {
      return res.json().catch(function () { return {}; }).then(function (data) {
        if (!res.ok || !data.ok) throw new Error(data.error || "\u521d\u59cb\u5316\u5931\u8d25");
        show("\u521d\u59cb\u5316\u6210\u529f\uff0c\u8bf7\u8fd4\u56de\u767b\u5f55\u9875\u3002", true);
      });
    }).catch(function (err) {
      show(err.message || "\u521d\u59cb\u5316\u5931\u8d25");
    }).finally(function () {
      btn.disabled = false;
    });
  });
})();
