/* 登录页交互：提交校验、错误提示、失败节流、口令可见切换
 * 校验逻辑全在 auth.js，本文件只管 DOM（单一职责） */
(function () {
  "use strict";

  var $ = function (id) { return document.getElementById(id); };

  var form = $("loginForm"), user = $("user"), pass = $("pass");
  var btn = $("loginBtn"), err = $("loginErr");

  var fails = 0, lockUntil = 0, ticking = null;

  function showErr(msg) {
    err.textContent = msg;
    form.classList.toggle("shake", !!msg);
    if (msg) setTimeout(function () { form.classList.remove("shake"); }, 420);
  }

  /* 连续失败后短暂锁定，抬高逐个试口令的成本（前端能做的仅此而已） */
  function lockSeconds() {
    if (fails < 3) return 0;
    return Math.min(30, (fails - 2) * 5);
  }

  function refreshLock() {
    var left = Math.ceil((lockUntil - Date.now()) / 1000);
    if (left <= 0) {
      clearInterval(ticking); ticking = null;
      btn.disabled = false;
      btn.textContent = "登 录";
      showErr("");
      return;
    }
    btn.disabled = true;
    btn.textContent = "请等待 " + left + " 秒";
  }

  function startLock(sec) {
    lockUntil = Date.now() + sec * 1000;
    refreshLock();
    if (!ticking) ticking = setInterval(refreshLock, 250);
  }

  form.addEventListener("submit", function (e) {
    e.preventDefault();
    if (btn.disabled) return;

    var u = user.value.trim(), p = pass.value;
    if (!u || !p) { showErr("请填写账号与口令"); (u ? pass : user).focus(); return; }

    btn.disabled = true;
    btn.textContent = "校验中…";
    showErr("");

    window.RC_AUTH.login(u, p).then(function (ok) {
      if (ok) {
        btn.textContent = "登录成功";
        location.replace("index.html");
        return;
      }
      fails++;
      pass.value = "";
      pass.focus();
      // 账号与口令的错误不分开提示，避免泄露哪个账号存在
      showErr("账号或口令不正确");
      var sec = lockSeconds();
      if (sec) startLock(sec);
      else { btn.disabled = false; btn.textContent = "登 录"; }
    }).catch(function () {
      btn.disabled = false;
      btn.textContent = "登 录";
      showErr("校验失败，请重试");
    });
  });

  [user, pass].forEach(function (el) {
    el.addEventListener("input", function () { if (err.textContent && !btn.disabled) showErr(""); });
  });

  $("togglePass").addEventListener("click", function () {
    var show = pass.type === "password";
    pass.type = show ? "text" : "password";
    this.classList.toggle("on", show);
    this.setAttribute("aria-pressed", show ? "true" : "false");
    this.title = show ? "隐藏口令" : "显示口令";
    this.setAttribute("aria-label", this.title);
    pass.focus();
  });
})();
