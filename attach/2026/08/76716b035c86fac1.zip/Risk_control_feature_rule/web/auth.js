/* Auth module: PHP/MySQL server-side validation. */
(function () {
  "use strict";

  var sessionCache = null;
  var readyPromise = null;

  function api(path, opts) {
    return fetch(path, Object.assign({ credentials: "same-origin" }, opts || {})).then(function (res) {
      return res.json().catch(function () { return {}; }).then(function (data) {
        if (!res.ok || !data.ok) throw new Error(data.error || "\u8bf7\u6c42\u5931\u8d25");
        return data;
      });
    });
  }

  function fetchSession() {
    return api("api/session.php").then(function (data) {
      sessionCache = data.user ? { user: data.user, role: data.role || "user" } : null;
      return sessionCache;
    }).catch(function () {
      sessionCache = null;
      return null;
    });
  }

  function ready() {
    if (!readyPromise) readyPromise = fetchSession();
    return readyPromise;
  }

  function session() {
    return sessionCache;
  }

  function login(user, pass) {
    return api("api/login.php", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ username: String(user || "").trim(), password: String(pass || "") })
    }).then(function (data) {
      sessionCache = { user: data.user, role: data.role || "user" };
      readyPromise = Promise.resolve(sessionCache);
      return true;
    }).catch(function () {
      sessionCache = null;
      readyPromise = null;
      return false;
    });
  }

  function requireAuth(admin) {
    return fetchSession().then(function (sess) {
      if (!sess) {
        location.replace("login.html");
        return false;
      }
      if (admin && sess.role !== "admin") {
        location.replace("index.html");
        return false;
      }
      return true;
    });
  }

  function logout() {
    sessionCache = null;
    readyPromise = null;
    api("api/logout.php", { method: "POST" }).finally(function () {
      location.replace("login.html");
    });
  }

  function listUsers() {
    return api("api/users.php").then(function (data) { return data.users || []; });
  }

  function addUser(username, password, role, expiresAt) {
    return api("api/users.php", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ username: username, password: password, role: role, expires_at: expiresAt || "" })
    });
  }

  function updateUser(payload) {
    payload = Object.assign({ action: "update" }, payload || {});
    return api("api/users.php", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(payload)
    });
  }

  function deleteUser(username) {
    return api("api/users.php", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ action: "delete", username: username })
    });
  }

  window.RC_AUTH = {
    login: login,
    logout: logout,
    requireAuth: requireAuth,
    ready: ready,
    session: session,
    listUsers: listUsers,
    addUser: addUser,
    updateUser: updateUser,
    deleteUser: deleteUser
  };
})();
