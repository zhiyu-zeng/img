/* 主题模块：明暗切换 + 持久化 + #themeToggle 按钮接线
 *
 * 必须在 <head> 里同步加载：主题要在首帧前落地，否则刷新会闪一下另一套配色。
 * 登录页与首页共用本模块，避免两处重复实现（DRY）。
 */
(function () {
  "use strict";

  var KEY = "rc-theme";

  function stored() {
    try { return localStorage.getItem(KEY); } catch (e) { return null; }   // 隐私模式下不可用
  }

  function prefers() {
    return window.matchMedia && window.matchMedia("(prefers-color-scheme: light)").matches ? "light" : "dark";
  }

  function current() {
    return document.documentElement.getAttribute("data-theme") === "light" ? "light" : "dark";
  }

  /* 按钮文案随主题走：显示的是"点下去会变成什么" */
  function syncButton() {
    var btn = document.getElementById("themeToggle");
    if (!btn) return;
    btn.title = current() === "light" ? "切换到暗色主题" : "切换到亮色主题";
    btn.setAttribute("aria-label", btn.title);
  }

  function apply(t) {
    t = t === "light" ? "light" : "dark";
    document.documentElement.setAttribute("data-theme", t);
    try { localStorage.setItem(KEY, t); } catch (e) { /* 存不下就只在本次会话生效 */ }
    syncButton();
  }

  function toggle() { apply(current() === "light" ? "dark" : "light"); }

  // 立即落地：无记录时跟随系统偏好
  var init = stored();
  document.documentElement.setAttribute("data-theme",
    init === "light" || init === "dark" ? init : prefers());

  // 按钮在 body 内，此刻尚未解析，等 DOM 就绪再接线
  document.addEventListener("DOMContentLoaded", function () {
    syncButton();
    var btn = document.getElementById("themeToggle");
    if (btn) btn.addEventListener("click", toggle);
  });

  window.RC_THEME = { apply: apply, toggle: toggle, current: current };
})();
