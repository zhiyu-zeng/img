<?php
return [
    'db' => [
        'host' => '127.0.0.1',
        'port' => 3306,
        'name' => 'risk',
        'user' => 'risk',
        'password' => '',
        'charset' => 'utf8mb4',
    ],
    'session_cookie' => 'rc_auth',
    'session_ttl' => 43200,
    'install_token' => '',
];
