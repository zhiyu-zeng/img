<?php
require __DIR__ . '/bootstrap.php';
rc_require_method('POST');
$data = rc_body();
$cfg = rc_config();
$token = (string)($data['token'] ?? '');
if (($cfg['install_token'] ?? '') === '' || !hash_equals((string)$cfg['install_token'], $token)) {
    rc_json(403, ['ok' => false, 'error' => 'Invalid install token']);
}

rc_create_schema();
$count = (int)rc_pdo()->query('SELECT COUNT(*) FROM rc_users')->fetchColumn();
if ($count > 0) {
    rc_json(409, ['ok' => false, 'error' => 'Users already initialized']);
}

$username = trim((string)($data['username'] ?? 'admin'));
$password = (string)($data['password'] ?? '');
if (!rc_validate_username($username)) {
    rc_json(400, ['ok' => false, 'error' => 'Invalid username']);
}
if (strlen($password) < 8) {
    rc_json(400, ['ok' => false, 'error' => 'Password must be at least 8 chars']);
}
$stmt = rc_pdo()->prepare("INSERT INTO rc_users (username, password_hash, role) VALUES (?, ?, 'admin')");
$stmt->execute([$username, password_hash($password, PASSWORD_DEFAULT)]);
rc_json(200, ['ok' => true]);
