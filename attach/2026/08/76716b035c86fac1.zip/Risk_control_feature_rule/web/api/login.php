<?php
require __DIR__ . '/bootstrap.php';
rc_require_method('POST');
rc_create_schema();
$data = rc_body();
$username = trim((string)($data['username'] ?? ''));
$password = (string)($data['password'] ?? '');

$stmt = rc_pdo()->prepare('SELECT id, username, password_hash, role, is_active FROM rc_users WHERE username = ? LIMIT 1');
$stmt->execute([$username]);
$user = $stmt->fetch();

if (!$user || (int)$user['is_active'] !== 1 || !password_verify($password, $user['password_hash'])) {
    usleep(250000);
    rc_json(401, ['ok' => false, 'error' => 'Invalid username or password']);
}

rc_create_session((int)$user['id']);

rc_json(200, [
    'ok' => true,
    'user' => $user['username'],
    'role' => $user['role'],
]);
