<?php
require __DIR__ . '/bootstrap.php';
rc_require_method('POST');
rc_destroy_session();
rc_json(200, ['ok' => true]);
