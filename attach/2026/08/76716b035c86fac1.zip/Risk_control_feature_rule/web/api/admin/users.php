<?php
require __DIR__ . '/../bootstrap.php';
rc_start_session();
$method = $_SERVER['REQUEST_METHOD'] ?? 'GET';

if ($method === 'GET') {
    rc_require_admin();
    $stmt = rc_pdo()->query("SELECT username, role, is_active, DATE_FORMAT(created_at, '%Y-%m-%d %H:%i:%s') AS created_at_text FROM rc_users ORDER BY username ASC");
    rc_json(200, ['ok' => true, 'users' => $stmt->fetchAll()]);
}

if ($method === 'POST') {
    rc_require_admin();
    $data = rc_body();
    $username = trim((string)($data['username'] ?? ''));
    $password = (string)($data['password'] ?? '');
    $role = (string)($data['role'] ?? 'user');

    if (!rc_validate_username($username)) {
        rc_json(400, ['ok' => false, 'error' => 'Username must be 3-32 chars: letters, numbers, dot, underscore or hyphen']);
    }
    if (strlen($password) < 8) {
        rc_json(400, ['ok' => false, 'error' => 'Password must be at least 8 chars']);
    }
    if (!in_array($role, ['admin', 'user'], true)) {
        rc_json(400, ['ok' => false, 'error' => 'Invalid role']);
    }

    try {
        $stmt = rc_pdo()->prepare('INSERT INTO rc_users (username, password_hash, role) VALUES (?, ?, ?)');
        $stmt->execute([$username, password_hash($password, PASSWORD_DEFAULT), $role]);
    } catch (PDOException $e) {
        if ($e->getCode() === '23000') {
            rc_json(409, ['ok' => false, 'error' => 'Username already exists']);
        }
        throw $e;
    }
    rc_json(200, ['ok' => true]);
}

rc_json(405, ['ok' => false, 'error' => 'Method not allowed']);
