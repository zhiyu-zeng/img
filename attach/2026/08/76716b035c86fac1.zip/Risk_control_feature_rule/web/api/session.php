<?php
require __DIR__ . '/bootstrap.php';
$user = rc_current_user();
if (!$user) {
    rc_json(200, ['ok' => true, 'user' => null]);
}
rc_json(200, [
    'ok' => true,
    'user' => $user['username'],
    'role' => $user['role'],
]);
