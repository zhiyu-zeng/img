<?php
require __DIR__ . '/bootstrap.php';
$method = $_SERVER['REQUEST_METHOD'] ?? 'GET';

function rc_parse_expires_at($value): ?string
{
    $value = trim((string)$value);
    if ($value === '') {
        return null;
    }
    $value = str_replace('T', ' ', $value);
    if (preg_match('/^\d{4}-\d{2}-\d{2}$/', $value)) {
        $value .= ' 23:59:59';
    } elseif (preg_match('/^\d{4}-\d{2}-\d{2} \d{2}:\d{2}$/', $value)) {
        $value .= ':00';
    }
    $dt = DateTime::createFromFormat('Y-m-d H:i:s', $value);
    if (!$dt || $dt->format('Y-m-d H:i:s') !== $value) {
        rc_json(400, ['ok' => false, 'error' => 'Invalid expires_at']);
    }
    return $value;
}

function rc_find_user(string $username): ?array
{
    $stmt = rc_pdo()->prepare('SELECT id, username, role, is_active, expires_at FROM rc_users WHERE username = ? LIMIT 1');
    $stmt->execute([$username]);
    $user = $stmt->fetch();
    return $user ?: null;
}

function rc_assert_not_last_admin(string $username): void
{
    $stmt = rc_pdo()->prepare("SELECT COUNT(*) FROM rc_users WHERE username = ? AND role = 'admin' AND is_active = 1 AND (expires_at IS NULL OR expires_at > NOW())");
    $stmt->execute([$username]);
    if ((int)$stmt->fetchColumn() === 0) {
        return;
    }
    $stmt = rc_pdo()->prepare("SELECT COUNT(*) FROM rc_users WHERE role = 'admin' AND is_active = 1 AND username <> ? AND (expires_at IS NULL OR expires_at > NOW())");
    $stmt->execute([$username]);
    if ((int)$stmt->fetchColumn() === 0) {
        rc_json(400, ['ok' => false, 'error' => 'Cannot remove or disable the last active admin']);
    }
}

if ($method === 'GET') {
    rc_require_admin();
    $stmt = rc_pdo()->query(<<<'SQL'
SELECT
  username,
  role,
  is_active,
  DATE_FORMAT(expires_at, '%Y-%m-%dT%H:%i') AS expires_at,
  DATE_FORMAT(expires_at, '%Y-%m-%d %H:%i:%s') AS expires_at_text,
  DATE_FORMAT(created_at, '%Y-%m-%d %H:%i:%s') AS created_at_text,
  CASE WHEN expires_at IS NOT NULL AND expires_at <= NOW() THEN 1 ELSE 0 END AS is_expired
FROM rc_users
ORDER BY username ASC
SQL);
    rc_json(200, ['ok' => true, 'users' => $stmt->fetchAll()]);
}

if ($method === 'POST') {
    rc_require_admin();
    $data = rc_body();
    $action = (string)($data['action'] ?? 'create');
    $username = trim((string)($data['username'] ?? ''));

    if ($action === 'delete') {
        if (!rc_validate_username($username)) {
            rc_json(400, ['ok' => false, 'error' => 'Invalid username']);
        }
        if (!rc_find_user($username)) {
            rc_json(404, ['ok' => false, 'error' => 'User not found']);
        }
        rc_assert_not_last_admin($username);
        $stmt = rc_pdo()->prepare('DELETE FROM rc_users WHERE username = ?');
        $stmt->execute([$username]);
        rc_json(200, ['ok' => true]);
    }

    if ($action === 'update') {
        $password = (string)($data['password'] ?? '');
        $role = (string)($data['role'] ?? 'user');
        $isActive = !empty($data['is_active']) ? 1 : 0;
        $expiresAt = rc_parse_expires_at($data['expires_at'] ?? '');

        if (!rc_validate_username($username)) {
            rc_json(400, ['ok' => false, 'error' => 'Invalid username']);
        }
        if (!rc_find_user($username)) {
            rc_json(404, ['ok' => false, 'error' => 'User not found']);
        }
        if (!in_array($role, ['admin', 'user'], true)) {
            rc_json(400, ['ok' => false, 'error' => 'Invalid role']);
        }
        if ($password !== '' && strlen($password) < 8) {
            rc_json(400, ['ok' => false, 'error' => 'Password must be at least 8 chars']);
        }
        if ($role !== 'admin' || $isActive !== 1 || ($expiresAt !== null && strtotime($expiresAt) <= time())) {
            rc_assert_not_last_admin($username);
        }

        if ($password === '') {
            $stmt = rc_pdo()->prepare('UPDATE rc_users SET role = ?, is_active = ?, expires_at = ? WHERE username = ?');
            $stmt->execute([$role, $isActive, $expiresAt, $username]);
        } else {
            $stmt = rc_pdo()->prepare('UPDATE rc_users SET password_hash = ?, role = ?, is_active = ?, expires_at = ? WHERE username = ?');
            $stmt->execute([password_hash($password, PASSWORD_DEFAULT), $role, $isActive, $expiresAt, $username]);
        }
        if ($isActive !== 1 || ($expiresAt !== null && strtotime($expiresAt) <= time())) {
            $user = rc_find_user($username);
            if ($user) {
                $stmt = rc_pdo()->prepare('DELETE FROM rc_sessions WHERE user_id = ?');
                $stmt->execute([(int)$user['id']]);
            }
        }
        rc_json(200, ['ok' => true]);
    }

    if ($action !== 'create') {
        rc_json(400, ['ok' => false, 'error' => 'Invalid action']);
    }

    $password = (string)($data['password'] ?? '');
    $role = (string)($data['role'] ?? 'user');
    $expiresAt = rc_parse_expires_at($data['expires_at'] ?? '');

    if (!rc_validate_username($username)) {
        rc_json(400, ['ok' => false, 'error' => 'Username must be 3-32 chars: letters, numbers, dot, underscore or hyphen']);
    }
    if (strlen($password) < 8) {
        rc_json(400, ['ok' => false, 'error' => 'Password must be at least 8 chars']);
    }
    if (!in_array($role, ['admin', 'user'], true)) {
        rc_json(400, ['ok' => false, 'error' => 'Invalid role']);
    }

    try {
        $stmt = rc_pdo()->prepare('INSERT INTO rc_users (username, password_hash, role, expires_at) VALUES (?, ?, ?, ?)');
        $stmt->execute([$username, password_hash($password, PASSWORD_DEFAULT), $role, $expiresAt]);
    } catch (PDOException $e) {
        if ($e->getCode() === '23000') {
            rc_json(409, ['ok' => false, 'error' => 'Username already exists']);
        }
        throw $e;
    }
    rc_json(200, ['ok' => true]);
}

if ($method === 'PUT') {
    rc_require_admin();
    $data = rc_body();
    $username = trim((string)($data['username'] ?? ''));
    $password = (string)($data['password'] ?? '');
    $role = (string)($data['role'] ?? 'user');
    $isActive = !empty($data['is_active']) ? 1 : 0;
    $expiresAt = rc_parse_expires_at($data['expires_at'] ?? '');

    if (!rc_validate_username($username)) {
        rc_json(400, ['ok' => false, 'error' => 'Invalid username']);
    }
    if (!rc_find_user($username)) {
        rc_json(404, ['ok' => false, 'error' => 'User not found']);
    }
    if (!in_array($role, ['admin', 'user'], true)) {
        rc_json(400, ['ok' => false, 'error' => 'Invalid role']);
    }
    if ($password !== '' && strlen($password) < 8) {
        rc_json(400, ['ok' => false, 'error' => 'Password must be at least 8 chars']);
    }
    if ($role !== 'admin' || $isActive !== 1 || ($expiresAt !== null && strtotime($expiresAt) <= time())) {
        rc_assert_not_last_admin($username);
    }

    if ($password === '') {
        $stmt = rc_pdo()->prepare('UPDATE rc_users SET role = ?, is_active = ?, expires_at = ? WHERE username = ?');
        $stmt->execute([$role, $isActive, $expiresAt, $username]);
    } else {
        $stmt = rc_pdo()->prepare('UPDATE rc_users SET password_hash = ?, role = ?, is_active = ?, expires_at = ? WHERE username = ?');
        $stmt->execute([password_hash($password, PASSWORD_DEFAULT), $role, $isActive, $expiresAt, $username]);
    }
    if ($isActive !== 1 || ($expiresAt !== null && strtotime($expiresAt) <= time())) {
        $user = rc_find_user($username);
        if ($user) {
            $stmt = rc_pdo()->prepare('DELETE FROM rc_sessions WHERE user_id = ?');
            $stmt->execute([(int)$user['id']]);
        }
    }
    rc_json(200, ['ok' => true]);
}

if ($method === 'DELETE') {
    rc_require_admin();
    $data = rc_body();
    $username = trim((string)($data['username'] ?? ($_GET['username'] ?? '')));
    if (!rc_validate_username($username)) {
        rc_json(400, ['ok' => false, 'error' => 'Invalid username']);
    }
    if (!rc_find_user($username)) {
        rc_json(404, ['ok' => false, 'error' => 'User not found']);
    }
    rc_assert_not_last_admin($username);
    $stmt = rc_pdo()->prepare('DELETE FROM rc_users WHERE username = ?');
    $stmt->execute([$username]);
    rc_json(200, ['ok' => true]);
}

rc_json(405, ['ok' => false, 'error' => 'Method not allowed']);
