<?php
$config = require __DIR__ . '/config.php';
$local = __DIR__ . '/config.local.php';
if (is_file($local)) {
    $override = require $local;
    if (is_array($override)) {
        $config = array_replace_recursive($config, $override);
    }
}

function rc_config(): array
{
    global $config;
    return $config;
}

function rc_pdo(): PDO
{
    static $pdo = null;
    if ($pdo instanceof PDO) {
        return $pdo;
    }
    $db = rc_config()['db'];
    $dsn = sprintf('mysql:host=%s;port=%d;dbname=%s;charset=%s', $db['host'], $db['port'], $db['name'], $db['charset']);
    $pdo = new PDO($dsn, $db['user'], $db['password'], [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        PDO::ATTR_EMULATE_PREPARES => false,
    ]);
    return $pdo;
}

function rc_json(int $status, array $payload): void
{
    http_response_code($status);
    header('Content-Type: application/json; charset=utf-8');
    header('Cache-Control: no-store');
    echo json_encode($payload, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    exit;
}

function rc_body(): array
{
    $raw = file_get_contents('php://input');
    $data = json_decode($raw ?: '{}', true);
    if (!is_array($data)) {
        rc_json(400, ['ok' => false, 'error' => 'Invalid JSON body']);
    }
    return $data;
}

function rc_require_method(string $method): void
{
    if (($_SERVER['REQUEST_METHOD'] ?? 'GET') !== $method) {
        rc_json(405, ['ok' => false, 'error' => 'Method not allowed']);
    }
}

function rc_cookie_name(): string
{
    return (string)(rc_config()['session_cookie'] ?? 'rc_auth');
}

function rc_cookie_secure(): bool
{
    return (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') || (($_SERVER['HTTP_X_FORWARDED_PROTO'] ?? '') === 'https');
}

function rc_set_auth_cookie(string $token, int $expiresAt): void
{
    setcookie(rc_cookie_name(), $token, [
        'expires' => $expiresAt,
        'path' => '/',
        'secure' => rc_cookie_secure(),
        'httponly' => true,
        'samesite' => 'Lax',
    ]);
}

function rc_clear_auth_cookie(): void
{
    setcookie(rc_cookie_name(), '', [
        'expires' => time() - 3600,
        'path' => '/',
        'secure' => rc_cookie_secure(),
        'httponly' => true,
        'samesite' => 'Lax',
    ]);
}

function rc_token_hash(string $token): string
{
    return hash('sha256', $token);
}

function rc_create_session(int $userId): array
{
    rc_create_schema();
    $ttl = (int)(rc_config()['session_ttl'] ?? 43200);
    $expiresAt = time() + $ttl;
    $token = bin2hex(random_bytes(32));
    $stmt = rc_pdo()->prepare('INSERT INTO rc_sessions (token_hash, user_id, expires_at, ip, user_agent) VALUES (?, ?, FROM_UNIXTIME(?), ?, ?)');
    $stmt->execute([
        rc_token_hash($token),
        $userId,
        $expiresAt,
        substr((string)($_SERVER['REMOTE_ADDR'] ?? ''), 0, 45),
        substr((string)($_SERVER['HTTP_USER_AGENT'] ?? ''), 0, 255),
    ]);
    rc_set_auth_cookie($token, $expiresAt);
    return ['token' => $token, 'expires_at' => $expiresAt];
}

function rc_destroy_session(): void
{
    $token = (string)($_COOKIE[rc_cookie_name()] ?? '');
    if ($token !== '') {
        $stmt = rc_pdo()->prepare('DELETE FROM rc_sessions WHERE token_hash = ?');
        $stmt->execute([rc_token_hash($token)]);
    }
    rc_clear_auth_cookie();
}

function rc_current_user(): ?array
{
    rc_create_schema();
    $token = (string)($_COOKIE[rc_cookie_name()] ?? '');
    if ($token === '') {
        return null;
    }
    rc_pdo()->exec('DELETE FROM rc_sessions WHERE expires_at < NOW()');
    $stmt = rc_pdo()->prepare(<<<'SQL'
SELECT u.id, u.username, u.role, u.is_active, u.expires_at
FROM rc_sessions s
JOIN rc_users u ON u.id = s.user_id
WHERE s.token_hash = ? AND s.expires_at >= NOW() AND (u.expires_at IS NULL OR u.expires_at > NOW())
LIMIT 1
SQL);
    $stmt->execute([rc_token_hash($token)]);
    $user = $stmt->fetch();
    if (!$user || (int)$user['is_active'] !== 1) {
        rc_destroy_session();
        return null;
    }
    return $user;
}

function rc_require_user(): array
{
    $user = rc_current_user();
    if (!$user) {
        rc_json(401, ['ok' => false, 'error' => 'Unauthenticated']);
    }
    return $user;
}

function rc_require_admin(): array
{
    $user = rc_require_user();
    if (($user['role'] ?? '') !== 'admin') {
        rc_json(403, ['ok' => false, 'error' => 'Admin required']);
    }
    return $user;
}

function rc_validate_username(string $username): bool
{
    return (bool)preg_match('/^[A-Za-z0-9._-]{3,32}$/', $username);
}

function rc_create_schema(): void
{
    static $done = false;
    if ($done) {
        return;
    }
    rc_pdo()->exec(<<<'SQL'
CREATE TABLE IF NOT EXISTS rc_users (
  id INT UNSIGNED NOT NULL AUTO_INCREMENT,
  username VARCHAR(32) NOT NULL,
  password_hash VARCHAR(255) NOT NULL,
  role ENUM('admin','user') NOT NULL DEFAULT 'user',
  is_active TINYINT(1) NOT NULL DEFAULT 1,
  expires_at DATETIME NULL DEFAULT NULL,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  UNIQUE KEY uk_rc_users_username (username)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
SQL);
    $stmt = rc_pdo()->prepare(
        "SELECT COUNT(*) FROM information_schema.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'rc_users' AND COLUMN_NAME = 'expires_at'"
    );
    $stmt->execute();
    if ((int)$stmt->fetchColumn() === 0) {
        rc_pdo()->exec('ALTER TABLE rc_users ADD COLUMN expires_at DATETIME NULL DEFAULT NULL AFTER is_active');
    }

    rc_pdo()->exec(<<<'SQL'
CREATE TABLE IF NOT EXISTS rc_sessions (
  id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  token_hash CHAR(64) NOT NULL,
  user_id INT UNSIGNED NOT NULL,
  expires_at DATETIME NOT NULL,
  ip VARCHAR(45) NOT NULL DEFAULT '',
  user_agent VARCHAR(255) NOT NULL DEFAULT '',
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  UNIQUE KEY uk_rc_sessions_token_hash (token_hash),
  KEY idx_rc_sessions_user_id (user_id),
  KEY idx_rc_sessions_expires_at (expires_at),
  CONSTRAINT fk_rc_sessions_user_id FOREIGN KEY (user_id) REFERENCES rc_users(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
SQL);
    $done = true;
}
