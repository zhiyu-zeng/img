<?php
return [
    'db' => [
        'host' => '127.0.0.1',
        'port' => 3306,
        'name' => 'risk',
        'user' => 'risk',
        'password' => '72krFAeHfY4X4i7F',
        'charset' => 'utf8mb4',
    ],
    'session_name' => 'rc_session',
    'session_ttl' => 43200,
    'install_token' => 'vDz0XM2KPdkG2VRgVtcImqTVAQdu5J8NuNhOMw4iyr0',
];
