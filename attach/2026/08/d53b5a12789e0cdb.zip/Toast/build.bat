@echo off
setlocal

REM ============================================================================
REM  Build script for the ToastCatcher suite
REM
REM  Outputs (all placed into .\bin):
REM    - ToastCatcherDll.dll   toast-blocking DLL   (ToastCatcherDll project, Release x64)
REM    - CatchToast.exe        sample toast popup   (CatchToast project, Release x64)
REM    - ToastInjector.exe     svchost.exe injector (share\ToastInjector.cpp)
REM    - ToastUnhook.exe       unhook tool          (share\ToastUnhook.cpp, admin)
REM ============================================================================

set "ROOT=%~dp0"
set "BIN=%ROOT%bin"
cd /d "%ROOT%"

REM --- 1. Locate Visual Studio 2022 (with C++ x64 tools) ---
set "VSWHERE=%ProgramFiles(x86)%\Microsoft Visual Studio\Installer\vswhere.exe"
set "VSPATH="
if exist "%VSWHERE%" (
    for /f "usebackq tokens=*" %%i in (`"%VSWHERE%" -latest -products * -requires Microsoft.VisualStudio.Component.VC.Tools.x86.x64 -property installationPath`) do set "VSPATH=%%i"
)
if not defined VSPATH (
    echo [ERROR] Visual Studio with C++ tools not found.
    exit /b 1
)
echo [INFO] Visual Studio: %VSPATH%

REM --- 2. Load the x64 native toolchain ---
set "VCVARS=%VSPATH%\VC\Auxiliary\Build\vcvars64.bat"
if not exist "%VCVARS%" (
    echo [ERROR] vcvars64.bat not found.
    exit /b 1
)
call "%VCVARS%" >nul
if errorlevel 1 (
    echo [ERROR] Failed to load the x64 build environment.
    exit /b 1
)

REM --- 3. Create the output folder ---
if not exist "%BIN%" mkdir "%BIN%"

REM --- 4. Build ToastCatcherDll.dll ---
echo.
echo [1/4] Building ToastCatcherDll.dll (Release ^| x64)...
set "MSBUILD=%VSPATH%\MSBuild\Current\Bin\MSBuild.exe"
"%MSBUILD%" "%ROOT%ToastCatcherDll\ToastCatcherDll\ToastCatcherDll.vcxproj" /p:Configuration=Release /p:Platform=x64 /p:OutDir="%BIN%\" /m /v:minimal /nologo
if errorlevel 1 (
    echo [ERROR] ToastCatcherDll.vcxproj build failed.
    exit /b 1
)

REM --- 5. Build CatchToast.exe ---
echo.
echo [2/4] Building CatchToast.exe (Release ^| x64)...
"%MSBUILD%" "%ROOT%CatchToast\CatchToast\CatchToast.vcxproj" /p:Configuration=Release /p:Platform=x64 /p:OutDir="%BIN%\" /m /v:minimal /nologo
if errorlevel 1 (
    echo [ERROR] CatchToast.vcxproj build failed.
    exit /b 1
)

REM --- 6. Build ToastInjector.exe ---
echo.
echo [3/4] Building ToastInjector.exe...
cl /nologo /EHsc /O2 /W3 /utf-8 "%ROOT%share\ToastInjector.cpp" /Fe:"%BIN%\ToastInjector.exe" /link /SUBSYSTEM:CONSOLE /MANIFEST:EMBED /MANIFESTINPUT:"%ROOT%share\require_admin.manifest"
if errorlevel 1 (
    echo [ERROR] ToastInjector.cpp build failed.
    exit /b 1
)

REM --- 7. Build ToastUnhook.exe ---
echo.
echo [4/4] Building ToastUnhook.exe...
cl /nologo /EHsc /O2 /W3 /utf-8 "%ROOT%share\ToastUnhook.cpp" /Fe:"%BIN%\ToastUnhook.exe" /link /SUBSYSTEM:CONSOLE /MANIFEST:EMBED /MANIFESTINPUT:"%ROOT%share\require_admin.manifest"
if errorlevel 1 (
    echo [ERROR] ToastUnhook.cpp build failed.
    exit /b 1
)

REM --- 8. Remove stray object files left in the root by cl ---
if exist "%ROOT%ToastInjector.obj" del /q "%ROOT%ToastInjector.obj"
if exist "%ROOT%ToastUnhook.obj" del /q "%ROOT%ToastUnhook.obj"

echo.
echo [DONE] Build complete. Outputs:
dir /b "%BIN%"

endlocal
