﻿#include "pch.h"

#include <rpc.h>
#include <rpcdce.h>
#include <rpcdcep.h>
#include <rpcndr.h>
#include <objidl.h>
#include <stdio.h>
#include <tlhelp32.h>

#include "detours.h"

#pragma comment(lib, "rpcrt4.lib")
#pragma comment(lib, "ole32.lib")


#define BLOCKED_PROCESS_NAME  L"Toast.exe"   
#define ENABLE_DEBUG_PRINT    1                 


typedef ULONG(WINAPI* GetAppId_Type)      (PVOID pThis, LPWSTR*);
typedef ULONG(WINAPI* GetType_Type)       (PVOID pThis, LPWSTR*);
typedef ULONG(WINAPI* GetPayloadType_Type)(PVOID pThis, LPWSTR*);
typedef ULONG(WINAPI* GetPayloadData_Type)(PVOID pThis, IStream**);

struct INotificationHandlerProxyVtbl
{
    PUCHAR               pfnQueryInterface;    // 0x00
    PUCHAR               pfnAddref;            // 0x08
    PUCHAR               pfnRelease;           // 0x10
    PUCHAR               pfnUnkown1;           // 0x18
    GetAppId_Type        pfnGetAppId;          // 0x20
    GetType_Type         pfnGetType;           // 0x28
    GetPayloadData_Type  pfnGetPayloadData;    // 0x30
    PUCHAR               pfnUnkown5;           // 0x38
    PUCHAR               pfnUnkown6;           // 0x40
    PUCHAR               pfnUnkown7;           // 0x48
    PUCHAR               pfnUnkown8;           // 0x50
    PUCHAR               pfnUnkown9;           // 0x58
    PUCHAR               pfnUnkown10;          // 0x60
    PUCHAR               pfnUnkown11;          // 0x68
    PUCHAR               pfnUnkown12;          // 0x70
    GetPayloadType_Type  pfnGetPayloadType;    // 0x78
};

struct INotificationHandlerProxy
{
    INotificationHandlerProxyVtbl* VTable;
};


typedef void (__RPC_STUB* PRPC_STUB_FUNCTION)(
    IRpcStubBuffer* This, IRpcChannelBuffer* pChannel,
    PRPC_MESSAGE pRpcMsg, DWORD* pdwStubPhase);

struct CInterfaceStubHeader
{
    const IID* piid;
    const MIDL_SERVER_INFO* pServerInfo;
    ULONG                     DispatchTableCount;
    const PRPC_STUB_FUNCTION* pDispatchTable;
};

struct CInterfaceStubVtbl
{
    CInterfaceStubHeader header;
    PVOID                 Vtbl;
};


typedef LONG(WINAPI* NdrStubCall3_Type)(
    PVOID pThis, PVOID pChannel, PRPC_MESSAGE pRpcMsg, ULONG* pdwStubPhase);


typedef ULONG(WINAPI* PostNotification3_Type)(
    PVOID pThis,
    INotificationHandlerProxy* NotificationHandlerProxy,
    PVOID TransientNotificationDetails,
    unsigned int nType,
    PVOID IWpnToastFeedback,
    PVOID Unknown);


static const GUID IID_IWpnAppEndpoint3 =
{ 0x926516E8, 0xD891, 0x45BC, { 0x9D, 0xE5, 0x69, 0x59, 0xFB, 0x8E, 0xCA, 0xC5 } };
#define POSTNOTIFICATION3_PROCNUM  0x29


static NdrStubCall3_Type       g_OriginalNdrStubCall3 = nullptr;
static PostNotification3_Type  g_OriginalPostNotif3 = nullptr;
static BOOL                    g_bPostNotif3Hooked = FALSE;



static BOOL DetourAttachFunc(PVOID* ppOriginal, PVOID pDetour)
{
    DetourTransactionBegin();
    DetourUpdateThread(GetCurrentThread());
    DetourAttach(ppOriginal, pDetour);
    LONG error = DetourTransactionCommit();
    return error == NO_ERROR;
}


#if ENABLE_DEBUG_PRINT
static void DbgPrint(const WCHAR* fmt, ...)
{
    WCHAR buf[1024];
    va_list args;
    va_start(args, fmt);
    _vsnwprintf_s(buf, _countof(buf), _TRUNCATE, fmt, args);
    va_end(args);
    OutputDebugStringW(buf);
}
#else
#define DbgPrint(...) ((void)0)
#endif

static BOOL GetProcessNameByPid(DWORD dwPid, WCHAR* outName, DWORD cchMax)
{
    HANDLE hSnap = CreateToolhelp32Snapshot(TH32CS_SNAPPROCESS, 0);
    if (hSnap == INVALID_HANDLE_VALUE) return FALSE;

    PROCESSENTRY32W pe = { sizeof(pe) };
    BOOL bFound = FALSE;
    if (Process32FirstW(hSnap, &pe))
    {
        do {
            if (pe.th32ProcessID == dwPid)
            {
                wcscpy_s(outName, cchMax, pe.szExeFile);
                bFound = TRUE;
                break;
            }
        } while (Process32NextW(hSnap, &pe));
    }
    CloseHandle(hSnap);
    return bFound;
}

static DWORD GetRpcClientPid()
{
    RPC_CALL_ATTRIBUTES_V2_W attr = {};
    attr.Version = 2;
    attr.Flags = 0x80;  // RPC_QUERY_CLIENT_PID
    if (RpcServerInqCallAttributesW(NULL, &attr) == RPC_S_OK)
        return (DWORD)(ULONG_PTR)attr.ClientPID;
    return 0;
}

static HRESULT SafeCallVTable(PVOID pThis, PUCHAR pfn, PVOID arg)
{
    if (!pThis || !pfn) return E_POINTER;
    return ((HRESULT(WINAPI*)(PVOID, PVOID))pfn)(pThis, arg);
}


static __declspec(thread) DWORD g_tlsClientPid = 0;

static ULONG WINAPI PostNotification3_Proxy(
    PVOID                       pThis,
    INotificationHandlerProxy* pProxy,
    PVOID                       TransientNotificationDetails,
    unsigned int                nType,
    PVOID                       IWpnToastFeedback,
    PVOID                       Unknown)
{
    INotificationHandlerProxyVtbl* vtb = nullptr;
    DWORD  dwClientPid = 0;
    WCHAR  szProcName[MAX_PATH] = L"<unknown>";
    LPWSTR lpAppId = nullptr;
    BOOL bBlocked = FALSE;
    
    if (!pProxy || IsBadReadPtr(pProxy, sizeof(PVOID) * 20))
        goto ALLOW;

    vtb = pProxy->VTable;
    if (!vtb || IsBadReadPtr(vtb, sizeof(INotificationHandlerProxyVtbl)))
        goto ALLOW;

    
    dwClientPid = g_tlsClientPid;
    if (dwClientPid)
        GetProcessNameByPid(dwClientPid, szProcName, MAX_PATH);

    
    if (FAILED(SafeCallVTable(pProxy, (PUCHAR)vtb->pfnGetAppId, (PVOID)&lpAppId)) || !lpAppId)
        goto ALLOW;

    
    DbgPrint(L"[ToastBlocker] Process=%s(PID:%lu)  AppId=%s\n",
        szProcName, dwClientPid, lpAppId);

    
    if (dwClientPid && _wcsicmp(szProcName, BLOCKED_PROCESS_NAME) == 0)
    {
        bBlocked = TRUE;
    }
    else if (!dwClientPid)
    {
        if (wcsstr(lpAppId, L"none.wintoast.test.10"))
            bBlocked = TRUE;
    }

    if (bBlocked)
    {
        DbgPrint(L"[ToastBlocker] BLOCKED toast (Proc=%s, AppId=%s)!\n", szProcName, lpAppId);
        CoTaskMemFree(lpAppId);
        return 0;   
    }

    CoTaskMemFree(lpAppId);

ALLOW:
    return g_OriginalPostNotif3(pThis, pProxy,
        TransientNotificationDetails, nType, IWpnToastFeedback, Unknown);
}


static volatile LONG g_nNdrStubCall3Count = 0;
static volatile LONG g_bHookAttempted = 0;

static LONG WINAPI NdrStubCall3_Proxy(
    PVOID        pThis,
    PVOID        pChannel,
    PRPC_MESSAGE pRpcMsg,
    ULONG* pdwStubPhase)
{
    
    if (!g_bPostNotif3Hooked && pRpcMsg && pRpcMsg->RpcInterfaceInformation)
    {
        PRPC_SERVER_INTERFACE pIf = (PRPC_SERVER_INTERFACE)pRpcMsg->RpcInterfaceInformation;

        LONG nCount = InterlockedIncrement(&g_nNdrStubCall3Count);
        if ((nCount % 200) == 1)
        {
            DbgPrint(L"[ToastBlocker] NdrStubCall3 call #%d: ProcNum=%lu, GUID={%08X-%04X-%04X-%02X%02X-%02X%02X%02X%02X%02X%02X}\n",
                nCount, pRpcMsg->ProcNum,
                pIf->InterfaceId.SyntaxGUID.Data1,
                pIf->InterfaceId.SyntaxGUID.Data2,
                pIf->InterfaceId.SyntaxGUID.Data3,
                pIf->InterfaceId.SyntaxGUID.Data4[0],
                pIf->InterfaceId.SyntaxGUID.Data4[1],
                pIf->InterfaceId.SyntaxGUID.Data4[2],
                pIf->InterfaceId.SyntaxGUID.Data4[3],
                pIf->InterfaceId.SyntaxGUID.Data4[4],
                pIf->InterfaceId.SyntaxGUID.Data4[5],
                pIf->InterfaceId.SyntaxGUID.Data4[6],
                pIf->InterfaceId.SyntaxGUID.Data4[7]);
        }

        if (IsEqualGUID(pIf->InterfaceId.SyntaxGUID, IID_IWpnAppEndpoint3)
            && pRpcMsg->ProcNum == POSTNOTIFICATION3_PROCNUM)
        {
            if (InterlockedCompareExchange(&g_bHookAttempted, 1, 0) != 0)
                goto CALL_ORIGINAL;

            DbgPrint(L"[ToastBlocker] Matched IWpnAppEndpoint3 ProcNum=%lu, extracting via COM vtable...\n",
                pRpcMsg->ProcNum);

            if (!pThis || IsBadReadPtr(pThis, 0x20))
            {
                DbgPrint(L"[ToastBlocker] pThis is unreadable.\n");
                goto CALL_ORIGINAL;
            }

            IUnknown* pServer = *(IUnknown**)((BYTE*)pThis + 0x10);
            DbgPrint(L"[ToastBlocker] pvServerObject=%p\n", pServer);

            if (!pServer || IsBadReadPtr(pServer, sizeof(PVOID)))
            {
                DbgPrint(L"[ToastBlocker] pvServerObject is NULL or unreadable.\n");
                goto CALL_ORIGINAL;
            }

            PVOID* vtable = *(PVOID**)pServer;
            DbgPrint(L"[ToastBlocker] COM vtable=%p\n", vtable);

            if (!vtable || IsBadReadPtr(vtable, sizeof(PVOID) * (POSTNOTIFICATION3_PROCNUM + 1)))
            {
                DbgPrint(L"[ToastBlocker] COM vtable is NULL or too small.\n");
                goto CALL_ORIGINAL;
            }

            DbgPrint(L"[ToastBlocker] vtable[0]=%p  vtable[1]=%p  vtable[2]=%p  vtable[3]=%p\n",
                vtable[0], vtable[1], vtable[2], vtable[3]);

            g_OriginalPostNotif3 = (PostNotification3_Type)vtable[POSTNOTIFICATION3_PROCNUM];
            DbgPrint(L"[ToastBlocker] vtable[%lu] (PostNotification3) = %p\n",
                POSTNOTIFICATION3_PROCNUM, g_OriginalPostNotif3);

            if (!g_OriginalPostNotif3 || IsBadReadPtr((PVOID)g_OriginalPostNotif3, 16))
            {
                DbgPrint(L"[ToastBlocker] vtable[%lu] is invalid or unreadable.\n", POSTNOTIFICATION3_PROCNUM);
                goto CALL_ORIGINAL;
            }

            DbgPrint(L"[ToastBlocker] PostNotification3 looks valid, hooking...\n");
            if (DetourAttachFunc((PVOID*)&g_OriginalPostNotif3, PostNotification3_Proxy))
            {
                g_bPostNotif3Hooked = TRUE;
                DbgPrint(L"[ToastBlocker] PostNotification3 hooked successfully via COM vtable!\n");
            }
            else
            {
                DbgPrint(L"[ToastBlocker] DetourAttachFunc failed.\n");
            }
        }
    }

CALL_ORIGINAL:
    g_tlsClientPid = GetRpcClientPid();
    return g_OriginalNdrStubCall3(pThis, pChannel, pRpcMsg, pdwStubPhase);
}


static BOOL InitializeHook()
{
    HMODULE hRpcrt4 = GetModuleHandleW(L"rpcrt4.dll");
    if (!hRpcrt4) return FALSE;

    PVOID pNdrStubCall3 = GetProcAddress(hRpcrt4, "NdrStubCall3");
    if (!pNdrStubCall3)
    {
        DbgPrint(L"[ToastBlocker] NdrStubCall3 not found in rpcrt4.dll\n");
        return FALSE;
    }

    DbgPrint(L"[ToastBlocker] rpcrt4!NdrStubCall3 at %p\n", pNdrStubCall3);

    g_OriginalNdrStubCall3 = (NdrStubCall3_Type)pNdrStubCall3;
    if (!DetourAttachFunc((PVOID*)&g_OriginalNdrStubCall3, NdrStubCall3_Proxy))
    {
        DbgPrint(L"[ToastBlocker] Failed to hook NdrStubCall3\n");
        return FALSE;
    }

    DbgPrint(L"[ToastBlocker] NdrStubCall3 hooked. Waiting for toast calls...\n");
    return TRUE;
}


BOOL APIENTRY DllMain(HMODULE hModule, DWORD ul_reason_for_call, LPVOID lpReserved)
{
    switch (ul_reason_for_call)
    {
    case DLL_PROCESS_ATTACH:
        DisableThreadLibraryCalls(hModule);
        InitializeHook();
        break;

    case DLL_PROCESS_DETACH:
        break;
    }
    return TRUE;
}
