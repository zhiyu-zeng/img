//=============================================================================
//  ToastInjector.cpp -- Remote Thread Injector
//
//  Injects ToastBlocker.dll into WpnUserService (svchost.exe) via CreateRemoteThread
//  Build: cl /EHsc /O2 ToastInjector.cpp /Fe:ToastInjector.exe
//
//  Usage: ToastInjector.exe [dll_path]
//    If no argument, auto-locates ToastBlocker.dll in the same directory
//=============================================================================

#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <winternl.h>
#include <tlhelp32.h>
#include <stdio.h>
#include <wtsapi32.h>

#pragma comment(lib, "wtsapi32.lib")
#pragma comment(lib, "advapi32.lib")

// ── NtQueryInformationProcess function pointer (resolved at runtime) ──
typedef NTSTATUS (NTAPI* _NtQueryInformationProcess)(
    HANDLE, PROCESSINFOCLASS, PVOID, ULONG, PULONG);

static _NtQueryInformationProcess GetNtQueryInformationProcess()
{
    static _NtQueryInformationProcess pfn = NULL;
    if (!pfn)
    {
        HMODULE hNtdll = GetModuleHandleW(L"ntdll.dll");
        if (hNtdll)
            pfn = (_NtQueryInformationProcess)GetProcAddress(hNtdll, "NtQueryInformationProcess");
    }
    return pfn;
}

//=============================================================================
//  Find WpnUserService svchost.exe PID
//  Method: enumerate all svchost.exe, read command line via PEB, match "WpnUserService"
//=============================================================================
static DWORD FindWpnUserServicePid()
{
    DWORD dwPid = 0;
    _NtQueryInformationProcess pfnNtQIP = GetNtQueryInformationProcess();
    if (!pfnNtQIP)
    {
        printf("[!] Failed to resolve NtQueryInformationProcess\n");
        return 0;
    }

    HANDLE hSnap = CreateToolhelp32Snapshot(TH32CS_SNAPPROCESS, 0);
    if (hSnap == INVALID_HANDLE_VALUE)
    {
        printf("[!] CreateToolhelp32Snapshot failed: %lu\n", GetLastError());
        return 0;
    }

    PROCESSENTRY32W pe = { sizeof(pe) };
    if (Process32FirstW(hSnap, &pe))
    {
        do
        {
            if (_wcsicmp(pe.szExeFile, L"svchost.exe") != 0)
                continue;

            HANDLE hProc = OpenProcess(
                PROCESS_QUERY_INFORMATION | PROCESS_VM_READ,
                FALSE, pe.th32ProcessID);
            if (!hProc)
                continue;

            // ── 1) Get PEB address via NtQueryInformationProcess ──
            PROCESS_BASIC_INFORMATION pbi = { 0 };
            NTSTATUS status = pfnNtQIP(hProc, ProcessBasicInformation,
                                        &pbi, sizeof(pbi), NULL);
            if (!NT_SUCCESS(status) || !pbi.PebBaseAddress)
            {
                CloseHandle(hProc);
                continue;
            }

            // ── 2) Read PEB -> ProcessParameters ──
            PEB peb = { 0 };
            SIZE_T cbRead = 0;
            if (!ReadProcessMemory(hProc, pbi.PebBaseAddress, &peb, sizeof(peb), &cbRead))
            {
                CloseHandle(hProc);
                continue;
            }

            // ── 3) Read RTL_USER_PROCESS_PARAMETERS header ──
            //     Need CommandLine.Length and CommandLine.Buffer
            //     CommandLine is at offset 0x70 in RTL_USER_PROCESS_PARAMETERS (Win10/11 x64)
            BYTE paramsBuf[1024] = { 0 };
            if (!ReadProcessMemory(hProc, peb.ProcessParameters, paramsBuf,
                                    sizeof(paramsBuf), &cbRead))
            {
                CloseHandle(hProc);
                continue;
            }

            // CommandLine is field 14 of RTL_USER_PROCESS_PARAMETERS
            // x64 offset: CommandLine at 0x70
            UNICODE_STRING* pCmdLine = (UNICODE_STRING*)(paramsBuf + 0x70);
            if (pCmdLine->Length == 0 || pCmdLine->Length > 1024 || !pCmdLine->Buffer)
            {
                CloseHandle(hProc);
                continue;
            }

            // ── 4) Read command-line string ──
            WCHAR cmdLine[512] = { 0 };
            SIZE_T cbCmd = min((SIZE_T)pCmdLine->Length, sizeof(cmdLine) - sizeof(WCHAR));
            if (!ReadProcessMemory(hProc, pCmdLine->Buffer, cmdLine, cbCmd, &cbRead))
            {
                CloseHandle(hProc);
                continue;
            }

            // ── 5) Check if command line contains WpnUserService ──
            if (wcsstr(cmdLine, L"WpnUserService") ||
                wcsstr(cmdLine, L"WpnUserService_"))
            {
                dwPid = pe.th32ProcessID;
                printf("[*] Found WpnUserService svchost (PID=%lu): %ls\n",
                       dwPid, cmdLine);
                CloseHandle(hProc);
                // Found it, exit loop
                break;
            }

            CloseHandle(hProc);

        } while (Process32NextW(hSnap, &pe));
    }

    CloseHandle(hSnap);

    if (dwPid == 0)
        printf("[!] WpnUserService svchost not found via command-line scan\n");

    return dwPid;
}

// ── Get WpnUserService PID via Service Control Manager ──
static DWORD GetServicePid(const WCHAR* szServiceName)
{
    DWORD dwPid = 0;
    SC_HANDLE hSCM = OpenSCManagerW(NULL, NULL, SC_MANAGER_CONNECT);
    if (!hSCM) return 0;

    SC_HANDLE hSvc = OpenServiceW(hSCM, szServiceName, SERVICE_QUERY_STATUS);
    if (hSvc)
    {
        SERVICE_STATUS_PROCESS ssp = {};
        DWORD cbNeeded = 0;
        if (QueryServiceStatusEx(hSvc, SC_STATUS_PROCESS_INFO,
            (LPBYTE)&ssp, sizeof(ssp), &cbNeeded))
        {
            dwPid = ssp.dwProcessId;
        }
        CloseServiceHandle(hSvc);
    }
    CloseServiceHandle(hSCM);
    return dwPid;
}

//=============================================================================
//  Remote thread injection: make target process call LoadLibraryW
//=============================================================================
static BOOL RemoteThreadInject(DWORD dwTargetPid, const WCHAR* szDllPath)
{
    BOOL bRet = FALSE;
    HANDLE hProcess = NULL;
    PVOID pRemoteMem = NULL;
    HANDLE hThread = NULL;

    // 1. Open target process
    hProcess = OpenProcess(
        PROCESS_CREATE_THREAD | PROCESS_VM_OPERATION |
        PROCESS_VM_WRITE | PROCESS_QUERY_INFORMATION,
        FALSE, dwTargetPid);
    if (!hProcess)
    {
        printf("[!] OpenProcess(%lu) failed: %lu\n", dwTargetPid, GetLastError());
        printf("[!] Please run as administrator.\n");
        return FALSE;
    }
    printf("[+] Opened target process PID=%lu\n", dwTargetPid);

    // 2. Allocate memory in target, write DLL path
    SIZE_T cbPath = (wcslen(szDllPath) + 1) * sizeof(WCHAR);
    pRemoteMem = VirtualAllocEx(hProcess, NULL, cbPath,
                                 MEM_COMMIT | MEM_RESERVE, PAGE_READWRITE);
    if (!pRemoteMem)
    {
        printf("[!] VirtualAllocEx failed: %lu\n", GetLastError());
        goto cleanup;
    }

    if (!WriteProcessMemory(hProcess, pRemoteMem, szDllPath, cbPath, NULL))
    {
        printf("[!] WriteProcessMemory failed: %lu\n", GetLastError());
        goto cleanup;
    }
    printf("[+] DLL path written to target process memory @ %p\n", pRemoteMem);

    // 3. Get kernel32!LoadLibraryW address
    //    Note: kernel32 base is same across processes (system DLL base is fixed under ASLR)
    LPTHREAD_START_ROUTINE pLoadLibraryW =
        (LPTHREAD_START_ROUTINE)GetProcAddress(
            GetModuleHandleW(L"kernel32.dll"), "LoadLibraryW");
    if (!pLoadLibraryW)
        goto cleanup;

    // 4. Create remote thread, entry = LoadLibraryW, param = dll path
    hThread = CreateRemoteThread(hProcess, NULL, 0,
                                  pLoadLibraryW, pRemoteMem, 0, NULL);
    if (!hThread)
    {
        printf("[!] CreateRemoteThread failed: %lu\n", GetLastError());
        goto cleanup;
    }
    printf("[+] Remote thread created, waiting for LoadLibrary to complete...\n");

    // 5. Wait for thread to finish (LoadLibrary returns = DLL init complete)
    WaitForSingleObject(hThread, 5000);

    DWORD dwExitCode = 0;
    GetExitCodeThread(hThread, &dwExitCode);
    if (dwExitCode)
        printf("[+] Injection successful! DLL entry executed (LoadLibrary returned %p)\n", (PVOID)(ULONG_PTR)dwExitCode);
    else
        printf("[-] LoadLibrary returned NULL, DLL may have failed to load.\n");

    bRet = TRUE;

cleanup:
    if (hThread)     CloseHandle(hThread);
    if (pRemoteMem)  VirtualFreeEx(hProcess, pRemoteMem, 0, MEM_RELEASE);
    if (hProcess)    CloseHandle(hProcess);
    return bRet;
}

//=============================================================================
//  Entry point
//=============================================================================
int wmain(int argc, WCHAR* argv[])
{
    printf("=== Toast Notification Interceptor - Remote Thread Injector ===\n\n");

    // ── 1. Determine DLL path ──
    WCHAR szDllPath[MAX_PATH];
    if (argc >= 2)
    {
        wcscpy_s(szDllPath, argv[1]);
    }
    else
    {
        // Default: ToastCatcher.dll in same directory
        GetModuleFileNameW(NULL, szDllPath, MAX_PATH);
        WCHAR* pLastSlash = wcsrchr(szDllPath, L'\\');
        if (pLastSlash) *(pLastSlash + 1) = L'\0';
        wcscat_s(szDllPath, L"ToastCatcherDll.dll");
    }

    // Verify DLL exists
    if (GetFileAttributesW(szDllPath) == INVALID_FILE_ATTRIBUTES)
    {
        printf("[!] DLL not found: %ls\n", szDllPath);
        return 1;
    }

    // Get full path
    WCHAR szFullPath[MAX_PATH];
    GetFullPathNameW(szDllPath, MAX_PATH, szFullPath, NULL);
    printf("[*] DLL path: %ls\n\n", szFullPath);

    // ── 2. Locate target process ──
    DWORD dwPid = GetServicePid(L"WpnUserService");
    if (dwPid == 0)
    {
        // Fallback: scan svchost.exe command lines
        printf("[*] SC Manager lookup failed, falling back to command-line scan...\n");
        dwPid = FindWpnUserServicePid();
    }
    if (dwPid == 0)
    {
        printf("[!] WpnUserService not found. Please verify:\n");
        printf("    1. Service is running (services.msc -> Windows Push Notifications User Service)\n");
        printf("    2. You have administrator privileges\n");
        return 1;
    }
    printf("[*] WpnUserService PID = %lu\n", dwPid);

    // ── 3. Perform injection ──
    printf("\n[*] Starting remote thread injection...\n");
    if (RemoteThreadInject(dwPid, szFullPath))
    {
        printf("\n[+] Done. Toasts from BLOCKED_PROCESS_NAME will now be intercepted.\n");
        printf("    Use DebugView to monitor interception logs.\n");
    }
    else
    {
        printf("\n[-] Injection failed.\n");
        return 1;
    }

    return 0;
}
