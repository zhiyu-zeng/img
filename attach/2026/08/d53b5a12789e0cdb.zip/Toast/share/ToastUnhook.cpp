// unhook.cpp
//
// 命令行程序：从外部进程绕过 ToastCatcherDll 的拦截。
// 不需要注入 DLL —— 通过 OpenProcess + WriteProcessMemory 直接改写
// svchost.exe 的内存，将 Detours 的 JMP 补丁还原为磁盘上的原始字节。
//
// 原理：
//   1. 枚举进程找到 WpnUserService 所在的 svchost.exe
//   2. OpenProcess 获取 PROCESS_VM_READ | WRITE | OPERATION 权限
//   3. 读取远程进程中 rpcrt4.dll 的 NdrStubCall3 当前字节
//   4. 若检测到 Detours 特征码，从磁盘 rpcrt4.dll 取原始字节写回
//   5. 对 wpncore.dll .text 段远程扫描 Detours 补丁，同样从磁盘恢复
//
// Detours 4.x x64 Hook 原理（见 detours.cpp:1732-1733）：
//   目标函数开头被覆盖为  E9 XX XX XX XX  (5字节 JMP rel32)
//   跳转到 trampoline，trampoline 内是 FF 25 [rip+disp32] 再跳到代理函数。
//   所以检测方式不是匹配特征码，而是将远程内存与磁盘原始字节对比。
//
// 编译命令 (VS Developer PowerShell, x64, 以管理员身份运行):
//   cl /EHsc /O2 /utf-8 unhook.cpp /link /OUT:unhook.exe

#define UNICODE
#define _UNICODE

#include <windows.h>
#include <winternl.h>
#include <tlhelp32.h>
#include <stdio.h>
#include <stdlib.h>

#pragma comment(lib, "advapi32.lib")

// ── NtQueryInformationProcess function pointer (resolved at runtime) ──
typedef NTSTATUS (NTAPI* _NtQueryInformationProcess)(
    HANDLE, PROCESSINFOCLASS, PVOID, ULONG, PULONG);

static _NtQueryInformationProcess GetNtQueryInformationProcess()
{
    static _NtQueryInformationProcess pfn = NULL;
    if (!pfn)
    {
        HMODULE hNtdll = GetModuleHandleW(L"ntdll.dll");
        if (hNtdll)
            pfn = (_NtQueryInformationProcess)GetProcAddress(hNtdll, "NtQueryInformationProcess");
    }
    return pfn;
}

// ============================================================================
// 控制台输出
// ============================================================================
static void Log(const WCHAR* fmt, ...)
{
    WCHAR buf[1024];
    va_list args;
    va_start(args, fmt);
    _vsnwprintf_s(buf, _countof(buf), _TRUNCATE, fmt, args);
    va_end(args);
    wprintf(L"%s\n", buf);
}

// ============================================================================
// 启用 SeDebugPrivilege
// ============================================================================
static BOOL EnableDebugPrivilege()
{
    HANDLE hToken = NULL;
    if (!OpenProcessToken(GetCurrentProcess(), TOKEN_ADJUST_PRIVILEGES | TOKEN_QUERY, &hToken))
    {
        Log(L"[!] OpenProcessToken failed (err=%lu). Run as Administrator.", GetLastError());
        return FALSE;
    }

    LUID luid;
    if (!LookupPrivilegeValueW(NULL, SE_DEBUG_NAME, &luid))
    {
        Log(L"[!] LookupPrivilegeValue failed (err=%lu)", GetLastError());
        CloseHandle(hToken);
        return FALSE;
    }

    TOKEN_PRIVILEGES tp = {};
    tp.PrivilegeCount = 1;
    tp.Privileges[0].Luid = luid;
    tp.Privileges[0].Attributes = SE_PRIVILEGE_ENABLED;

    BOOL ok = AdjustTokenPrivileges(hToken, FALSE, &tp, sizeof(tp), NULL, NULL);
    CloseHandle(hToken);

    if (!ok || GetLastError() == ERROR_NOT_ALL_ASSIGNED)
    {
        Log(L"[!] AdjustTokenPrivileges failed. Run as Administrator.");
        return FALSE;
    }

    Log(L"[+] SeDebugPrivilege enabled");
    return TRUE;
}

// ============================================================================
// 直接通过 SCM 查询服务 PID（与 ToastInjector.cpp 一致）
// ============================================================================
static DWORD GetServicePid(const WCHAR* szServiceName)
{
    DWORD dwPid = 0;
    SC_HANDLE hSCM = OpenSCManagerW(NULL, NULL, SC_MANAGER_CONNECT);
    if (!hSCM) return 0;

    SC_HANDLE hSvc = OpenServiceW(hSCM, szServiceName, SERVICE_QUERY_STATUS);
    if (hSvc)
    {
        SERVICE_STATUS_PROCESS ssp = {};
        DWORD cbNeeded = 0;
        if (QueryServiceStatusEx(hSvc, SC_STATUS_PROCESS_INFO,
            (LPBYTE)&ssp, sizeof(ssp), &cbNeeded))
        {
            dwPid = ssp.dwProcessId;
        }
        CloseServiceHandle(hSvc);
    }
    CloseServiceHandle(hSCM);
    return dwPid;
}

// ============================================================================
// 找到 WpnUserService 所在的 svchost.exe 进程 PID
//
// 策略（与 ToastInjector.cpp 一致）:
//   1. 先通过 SCM 直接查询 WpnUserService 的 PID
//   2. 若失败，枚举所有 svchost.exe，通过 PEB 读取命令行匹配 "WpnUserService"
// ============================================================================
static DWORD FindWpnUserServicePid()
{
    // ── 方法 1: SCM 直接查询 ──
    DWORD dwPid = GetServicePid(L"WpnUserService");
    if (dwPid != 0)
    {
        Log(L"[+] Found WpnUserService via SCM, PID = %lu", dwPid);
        return dwPid;
    }
    Log(L"[*] SCM lookup failed, falling back to command-line scan...");

    // ── 方法 2: PEB 命令行扫描 ──
    _NtQueryInformationProcess pfnNtQIP = GetNtQueryInformationProcess();
    if (!pfnNtQIP)
    {
        Log(L"[!] Failed to resolve NtQueryInformationProcess");
        return 0;
    }

    HANDLE hSnap = CreateToolhelp32Snapshot(TH32CS_SNAPPROCESS, 0);
    if (hSnap == INVALID_HANDLE_VALUE)
    {
        Log(L"[!] CreateToolhelp32Snapshot failed: %lu", GetLastError());
        return 0;
    }

    PROCESSENTRY32W pe = { sizeof(pe) };
    if (Process32FirstW(hSnap, &pe))
    {
        do
        {
            if (_wcsicmp(pe.szExeFile, L"svchost.exe") != 0)
                continue;

            HANDLE hProc = OpenProcess(
                PROCESS_QUERY_INFORMATION | PROCESS_VM_READ,
                FALSE, pe.th32ProcessID);
            if (!hProc) continue;

            // 1) 获取 PEB 地址
            PROCESS_BASIC_INFORMATION pbi = { 0 };
            NTSTATUS status = pfnNtQIP(hProc, ProcessBasicInformation,
                                        &pbi, sizeof(pbi), NULL);
            if (!NT_SUCCESS(status) || !pbi.PebBaseAddress)
            {
                CloseHandle(hProc);
                continue;
            }

            // 2) 读取 PEB
            PEB peb = { 0 };
            SIZE_T cbRead = 0;
            if (!ReadProcessMemory(hProc, pbi.PebBaseAddress, &peb, sizeof(peb), &cbRead))
            {
                CloseHandle(hProc);
                continue;
            }

            // 3) 读取 RTL_USER_PROCESS_PARAMETERS
            //    CommandLine 在 x64 下偏移为 0x70
            BYTE paramsBuf[1024] = { 0 };
            if (!ReadProcessMemory(hProc, peb.ProcessParameters, paramsBuf,
                                    sizeof(paramsBuf), &cbRead))
            {
                CloseHandle(hProc);
                continue;
            }

            UNICODE_STRING* pCmdLine = (UNICODE_STRING*)(paramsBuf + 0x70);
            if (pCmdLine->Length == 0 || pCmdLine->Length > 1024 || !pCmdLine->Buffer)
            {
                CloseHandle(hProc);
                continue;
            }

            // 4) 读取命令行字符串
            WCHAR cmdLine[512] = { 0 };
            SIZE_T cbCmd = min((SIZE_T)pCmdLine->Length, sizeof(cmdLine) - sizeof(WCHAR));
            if (!ReadProcessMemory(hProc, pCmdLine->Buffer, cmdLine, cbCmd, &cbRead))
            {
                CloseHandle(hProc);
                continue;
            }

            // 5) 检查是否包含 WpnUserService
            if (wcsstr(cmdLine, L"WpnUserService") ||
                wcsstr(cmdLine, L"WpnUserService_"))
            {
                dwPid = pe.th32ProcessID;
                Log(L"[+] Found WpnUserService svchost (PID=%lu): %ls", dwPid, cmdLine);
                CloseHandle(hProc);
                break;
            }

            CloseHandle(hProc);

        } while (Process32NextW(hSnap, &pe));
    }

    CloseHandle(hSnap);

    if (dwPid == 0)
        Log(L"[!] WpnUserService not found. Is the service running?");

    return dwPid;
}

// ============================================================================
// 获取远程进程中某模块的基址 (通过 CreateToolhelp32Snapshot)
// ============================================================================
static DWORD_PTR GetRemoteModuleBase(HANDLE hProcess, const WCHAR* moduleName)
{
    HANDLE hSnap = CreateToolhelp32Snapshot(TH32CS_SNAPMODULE | TH32CS_SNAPMODULE32,
        GetProcessId(hProcess));
    if (hSnap == INVALID_HANDLE_VALUE) return 0;

    MODULEENTRY32W me = { sizeof(me) };
    DWORD_PTR base = 0;

    if (Module32FirstW(hSnap, &me))
    {
        do {
            if (_wcsicmp(me.szModule, moduleName) == 0)
            {
                base = (DWORD_PTR)me.modBaseAddr;
                break;
            }
        } while (Module32NextW(hSnap, &me));
    }
    CloseHandle(hSnap);

    if (base)
        Log(L"[+] Remote %s base = 0x%p", moduleName, (void*)base);
    else
        Log(L"[!] %s not found in remote process", moduleName);

    return base;
}

// ============================================================================
// PE 解析: RVA -> 文件偏移
// ============================================================================
static DWORD RvaToFileOffset(BYTE* pFileBase, DWORD rva)
{
    PIMAGE_DOS_HEADER pDos = (PIMAGE_DOS_HEADER)pFileBase;
    PIMAGE_NT_HEADERS pNt = (PIMAGE_NT_HEADERS)(pFileBase + pDos->e_lfanew);

    WORD nSections = pNt->FileHeader.NumberOfSections;
    PIMAGE_SECTION_HEADER pSec = IMAGE_FIRST_SECTION(pNt);

    for (WORD i = 0; i < nSections; i++, pSec++)
    {
        DWORD secStart = pSec->VirtualAddress;
        DWORD secEnd = secStart + pSec->Misc.VirtualSize;
        if (rva >= secStart && rva < secEnd)
            return (rva - secStart) + pSec->PointerToRawData;
    }
    return 0;
}

// ============================================================================
// 从磁盘读取整个文件到堆内存
// ============================================================================
static BYTE* ReadFileToBuffer(LPCWSTR filePath, DWORD* pOutSize)
{
    HANDLE hFile = CreateFileW(filePath, GENERIC_READ,
        FILE_SHARE_READ | FILE_SHARE_WRITE | FILE_SHARE_DELETE,
        NULL, OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, NULL);

    if (hFile == INVALID_HANDLE_VALUE)
    {
        Log(L"[!] Cannot open %s (err=%lu)", filePath, GetLastError());
        return NULL;
    }

    DWORD fileSize = GetFileSize(hFile, NULL);
    if (fileSize == INVALID_FILE_SIZE || fileSize < sizeof(IMAGE_DOS_HEADER))
    {
        CloseHandle(hFile);
        return NULL;
    }

    BYTE* buffer = (BYTE*)malloc(fileSize);
    if (!buffer) { CloseHandle(hFile); return NULL; }

    DWORD bytesRead = 0;
    BOOL ok = ReadFile(hFile, buffer, fileSize, &bytesRead, NULL);
    CloseHandle(hFile);

    if (!ok || bytesRead != fileSize) { free(buffer); return NULL; }
    *pOutSize = fileSize;
    return buffer;
}

// ============================================================================
// 从已加载的文件缓冲区中读取指定 RVA 处的原始字节
// ============================================================================
static BOOL GetOriginalBytesAtRva(BYTE* pFileBase, DWORD fileSize, DWORD rva,
                                   BYTE* out, DWORD count)
{
    DWORD fileOffset = RvaToFileOffset(pFileBase, rva);
    if (!fileOffset || fileOffset + count > fileSize) return FALSE;
    memcpy(out, pFileBase + fileOffset, count);
    return TRUE;
}

// ============================================================================
// Step 1: 恢复远程进程中 rpcrt4!NdrStubCall3 的原始字节
//
// 策略: 本地 GetProcAddress 获取 NdrStubCall3 地址 → 计算相对本进程
//       rpcrt4.dll 基址的偏移 → 加上远程 rpcrt4.dll 基址得远程地址。
// ============================================================================
#define RESTORE_BYTE_COUNT 16

static BOOL RestoreNdrStubCall3(HANDLE hProcess, DWORD_PTR rpcrt4RemoteBase)
{
    // 1. 本地获取 NdrStubCall3 地址，计算偏移
    HMODULE hRpcrt4Local = GetModuleHandleW(L"rpcrt4.dll");
    if (!hRpcrt4Local) hRpcrt4Local = LoadLibraryW(L"rpcrt4.dll");
    if (!hRpcrt4Local)
    {
        Log(L"[!] Cannot load rpcrt4.dll locally");
        return FALSE;
    }

    PVOID pNdrStubCall3Local = GetProcAddress(hRpcrt4Local, "NdrStubCall3");
    if (!pNdrStubCall3Local)
    {
        Log(L"[!] NdrStubCall3 not found in local rpcrt4.dll");
        return FALSE;
    }

    DWORD_PTR offset = (DWORD_PTR)pNdrStubCall3Local - (DWORD_PTR)hRpcrt4Local;
    DWORD_PTR remoteAddr = rpcrt4RemoteBase + offset;
    Log(L"[*] NdrStubCall3 remote address = %p", (void*)remoteAddr);

    // 2. 读取远程进程当前字节
    BYTE currentBytes[RESTORE_BYTE_COUNT] = {};
    SIZE_T bytesRead = 0;
    if (!ReadProcessMemory(hProcess, (LPCVOID)remoteAddr, currentBytes,
                           RESTORE_BYTE_COUNT, &bytesRead) ||
        bytesRead != RESTORE_BYTE_COUNT)
    {
        Log(L"[!] ReadProcessMemory failed (err=%lu)", GetLastError());
        return FALSE;
    }

    Log(L"[*] Remote bytes: %02X %02X %02X %02X %02X %02X %02X %02X "
        L"%02X %02X %02X %02X %02X %02X %02X %02X",
        currentBytes[0], currentBytes[1], currentBytes[2], currentBytes[3],
        currentBytes[4], currentBytes[5], currentBytes[6], currentBytes[7],
        currentBytes[8], currentBytes[9], currentBytes[10], currentBytes[11],
        currentBytes[12], currentBytes[13], currentBytes[14], currentBytes[15]);

    // 3. 从磁盘 rpcrt4.dll 对应 RVA 处读取原始字节
    WCHAR diskPath[MAX_PATH];
    HMODULE hMod = GetModuleHandleW(L"rpcrt4.dll");
    if (!GetModuleFileNameW(hMod, diskPath, MAX_PATH))
    {
        Log(L"[!] Cannot get rpcrt4.dll path");
        return FALSE;
    }
    Log(L"[*] rpcrt4.dll disk: %s", diskPath);

    DWORD fileSize = 0;
    BYTE* pFileBase = ReadFileToBuffer(diskPath, &fileSize);
    if (!pFileBase) return FALSE;

    BYTE originalBytes[RESTORE_BYTE_COUNT] = {};
    if (!GetOriginalBytesAtRva(pFileBase, fileSize, (DWORD)offset, originalBytes, RESTORE_BYTE_COUNT))
    {
        Log(L"[!] Cannot resolve RVA to file offset");
        free(pFileBase);
        return FALSE;
    }

    Log(L"[*] Disk bytes:   %02X %02X %02X %02X %02X %02X %02X %02X "
        L"%02X %02X %02X %02X %02X %02X %02X %02X",
        originalBytes[0], originalBytes[1], originalBytes[2], originalBytes[3],
        originalBytes[4], originalBytes[5], originalBytes[6], originalBytes[7],
        originalBytes[8], originalBytes[9], originalBytes[10], originalBytes[11],
        originalBytes[12], originalBytes[13], originalBytes[14], originalBytes[15]);

    // 4. 逐字节对比远程内存与磁盘原始文件
    //    Detours 4.x 在 x64 上写入 E9 rel32 (5 字节 JMP)，
    //    而非 48 B8 ... FF E0，所以不能靠特征码，必须对比磁盘。
    BOOL isPatched = (memcmp(currentBytes, originalBytes, RESTORE_BYTE_COUNT) != 0);

    if (!isPatched)
    {
        Log(L"[-] NdrStubCall3 matches disk. NOT patched.");
        free(pFileBase);
        return TRUE;
    }

    Log(L"[!] NdrStubCall3 bytes differ from disk -- IS patched! Restoring...");

    // 5. VirtualProtectEx + WriteProcessMemory
    DWORD oldProtect = 0;
    if (!VirtualProtectEx(hProcess, (LPVOID)remoteAddr, RESTORE_BYTE_COUNT,
                          PAGE_EXECUTE_READWRITE, &oldProtect))
    {
        Log(L"[!] VirtualProtectEx failed (err=%lu)", GetLastError());
        return FALSE;
    }

    SIZE_T written = 0;
    BOOL ok = WriteProcessMemory(hProcess, (LPVOID)remoteAddr, originalBytes,
                                 RESTORE_BYTE_COUNT, &written);

    DWORD dummy = 0;
    VirtualProtectEx(hProcess, (LPVOID)remoteAddr, RESTORE_BYTE_COUNT, oldProtect, &dummy);

    if (!ok || written != RESTORE_BYTE_COUNT)
    {
        Log(L"[!] WriteProcessMemory failed (err=%lu)", GetLastError());
        return FALSE;
    }

    // 6. 验证
    BYTE verify[RESTORE_BYTE_COUNT] = {};
    ReadProcessMemory(hProcess, (LPCVOID)remoteAddr, verify, RESTORE_BYTE_COUNT, &bytesRead);
    if (memcmp(verify, originalBytes, RESTORE_BYTE_COUNT) == 0)
        Log(L"[+] NdrStubCall3 SUCCESSFULLY RESTORED!");
    else
        Log(L"[!] VERIFICATION FAILED!");

    return TRUE;
}

// ============================================================================
// Step 2: 远程扫描 wpncore.dll .text 段并恢复 Detours 补丁
//
// PostNotification3 是 C++ 成员函数，不在导出表中。
// 因此对 wpncore.dll 的 .text 段做远程特征码扫描。
// ============================================================================
static DWORD ScanAndRestoreWpnCore(HANDLE hProcess, DWORD_PTR wpncoreRemoteBase)
{
    // 1. 读取磁盘上的 wpncore.dll（用于获取原始字节）
    WCHAR diskPath[MAX_PATH];
    HMODULE hWpnCoreLocal = GetModuleHandleW(L"wpncore.dll");
    if (!hWpnCoreLocal) hWpnCoreLocal = LoadLibraryW(L"wpncore.dll");
    if (!hWpnCoreLocal)
    {
        Log(L"[!] Cannot load wpncore.dll locally");
        return 0;
    }
    GetModuleFileNameW(hWpnCoreLocal, diskPath, MAX_PATH);
    Log(L"[*] wpncore.dll disk: %s", diskPath);

    DWORD fileSize = 0;
    BYTE* pFileBase = ReadFileToBuffer(diskPath, &fileSize);
    if (!pFileBase) return 0;

    // 2. 读取远程 wpncore.dll 的 PE 头，定位 .text 节
    BYTE remoteHeaders[4096] = {};
    SIZE_T bytesRead = 0;
    if (!ReadProcessMemory(hProcess, (LPCVOID)wpncoreRemoteBase, remoteHeaders,
                           sizeof(remoteHeaders), &bytesRead))
    {
        Log(L"[!] Cannot read remote wpncore PE headers");
        free(pFileBase);
        return 0;
    }

    PIMAGE_DOS_HEADER pDos = (PIMAGE_DOS_HEADER)remoteHeaders;
    PIMAGE_NT_HEADERS pNt = (PIMAGE_NT_HEADERS)(remoteHeaders + pDos->e_lfanew);

    PIMAGE_SECTION_HEADER pSec = IMAGE_FIRST_SECTION(pNt);
    PIMAGE_SECTION_HEADER pTextSec = NULL;
    for (WORD i = 0; i < pNt->FileHeader.NumberOfSections; i++, pSec++)
    {
        if (memcmp(pSec->Name, ".text", 5) == 0) { pTextSec = pSec; break; }
    }

    if (!pTextSec)
    {
        Log(L"[!] .text section not found in remote wpncore.dll");
        free(pFileBase);
        return 0;
    }

    DWORD_PTR textStart = wpncoreRemoteBase + pTextSec->VirtualAddress;
    DWORD textSize = pTextSec->Misc.VirtualSize;
    Log(L"[*] Remote wpncore .text: start=%p size=0x%lX", (void*)textStart, textSize);

    // 3. 分块读取并扫描
    //    Detours 4.x x64 补丁形式：
    //      E9 XX XX XX XX       (5 字节，JMP rel32 到 trampoline)
    //    trampoline 内还有:
    //      FF 25 XX XX XX XX    (6 字节，JMP [rip+disp32] 到代理函数)
    //    所以扫描 .text 段时检测 E9 和 FF 25，对比磁盘来确认是否被修改。
    const DWORD CHUNK_SIZE = 4096;
    BYTE* chunk = (BYTE*)malloc(CHUNK_SIZE);
    if (!chunk) { free(pFileBase); return 0; }

    DWORD patchCount = 0;

    for (DWORD offset = 0; offset < textSize; offset += CHUNK_SIZE - 12)
    {
        DWORD readSize = min(CHUNK_SIZE, textSize - offset);
        DWORD_PTR readAddr = textStart + offset;

        if (!ReadProcessMemory(hProcess, (LPCVOID)readAddr, chunk, readSize, &bytesRead))
            continue;

        DWORD scanLimit = (bytesRead >= 6) ? bytesRead - 5 : 0;
        for (DWORD i = 0; i < scanLimit; i++)
        {
            BYTE* p = chunk + i;
            DWORD patchLen = 0;

            // 检测 Detours 4.x x64 补丁：E9 rel32 (5 字节 JMP)
            if (p[0] == 0xE9)
                patchLen = 5;
            // 也检测 FF 25 [rip+disp32] (6 字节间接 JMP，trampoline 内使用)
            else if (p[0] == 0xFF && p[1] == 0x25)
                patchLen = 6;
            else
                continue;

            DWORD_PTR candidateAddr = readAddr + i;
            DWORD rva = (DWORD)(candidateAddr - wpncoreRemoteBase);

            // 从磁盘获取此 RVA 处的原始字节
            BYTE original[6] = {};
            if (!GetOriginalBytesAtRva(pFileBase, fileSize, rva, original, patchLen))
                continue;

            // 对比磁盘：如果相同则未被修改，跳过
            if (memcmp(p, original, patchLen) == 0)
                continue;

            Log(L"[*] Patched @ %p (RVA=0x%lX, len=%lu), restoring...",
                (void*)candidateAddr, rva, patchLen);

            DWORD oldProtect = 0;
            if (!VirtualProtectEx(hProcess, (LPVOID)candidateAddr, patchLen,
                                  PAGE_EXECUTE_READWRITE, &oldProtect))
            {
                Log(L"    VirtualProtectEx failed (err=%lu)", GetLastError());
                continue;
            }

            SIZE_T written = 0;
            WriteProcessMemory(hProcess, (LPVOID)candidateAddr, original, patchLen, &written);
            DWORD dummy = 0;
            VirtualProtectEx(hProcess, (LPVOID)candidateAddr, patchLen, oldProtect, &dummy);

            if (written == patchLen)
            {
                Log(L"    [+] RESTORED (%lu bytes)", patchLen);
                patchCount++;
            }
            else
            {
                Log(L"    [!] Write failed (err=%lu)", GetLastError());
            }
        }
    }

    free(chunk);
    free(pFileBase);
    Log(L"[*] wpncore.dll: restored %lu Detours patch(es)", patchCount);
    return patchCount;
}

// ============================================================================
// 入口
// ============================================================================
int wmain(int argc, WCHAR* argv[])
{
    Log(L"=== ToastCatcherDll Unhook (Remote Process) ===\n");

    // 1. 提权
    if (!EnableDebugPrivilege())
    {
        Log(L"\n[!] Run this tool as Administrator.");
        return 1;
    }

    // 2. 找目标进程
    DWORD pid = FindWpnUserServicePid();
    if (!pid)
        return 1;

    // 3. 打开目标进程
    HANDLE hProcess = OpenProcess(
        PROCESS_VM_READ | PROCESS_VM_WRITE | PROCESS_VM_OPERATION |
        PROCESS_QUERY_INFORMATION,
        FALSE, pid);

    if (!hProcess)
    {
        Log(L"[!] OpenProcess(PID=%lu) failed (err=%lu). Run as Administrator.", pid, GetLastError());
        return 1;
    }
    Log(L"[+] Opened PID %lu\n", pid);

    // 4. 找远程模块基址
    DWORD_PTR rpcrt4Base  = GetRemoteModuleBase(hProcess, L"rpcrt4.dll");
    DWORD_PTR wpncoreBase = GetRemoteModuleBase(hProcess, L"wpncore.dll");

    if (!rpcrt4Base && !wpncoreBase)
    {
        Log(L"[!] Neither rpcrt4.dll nor wpncore.dll found in target.");
        CloseHandle(hProcess);
        return 1;
    }

    // 5. 恢复 NdrStubCall3
    if (rpcrt4Base)
    {
        Log(L"\n--- Step 1: Restore rpcrt4!NdrStubCall3 ---");
        RestoreNdrStubCall3(hProcess, rpcrt4Base);
    }

    // 6. 扫描恢复 wpncore.dll
    if (wpncoreBase)
    {
        Log(L"\n--- Step 2: Scan & restore wpncore.dll ---");
        ScanAndRestoreWpnCore(hProcess, wpncoreBase);
    }

    Log(L"\n=== Done ===");
    CloseHandle(hProcess);
    return 0;
}
