﻿#include <iostream>
#include <windows.h>
#include "wintoastlib.h"

using namespace WinToastLib;

class MYWinToastHandler : public IWinToastHandler
{
public:
    void toastActivated() const override {
        std::wcout << L"Active!" << std::endl;
    }
    void toastActivated(int actionIndex) const override {
        std::wcout << L"Active with index: " << actionIndex << std::endl;
    }
    
    void toastActivated(std::wstring argument) const override {
        std::wcout << L"Activated with argument: " << argument << std::endl;
    }
    void toastDismissed(WinToastDismissalReason state) const override {
        std::wcout << L"Dismissed!" << std::endl;
    }
    void toastFailed() const override {
        std::wcout << L"Failed!" << std::endl;
    }
};
int main()
{
    WinToast::WinToastError error;
    if (!WinToast::isCompatible())
        std::wcout << L"Error, your system in not supported!" << std::endl;

    WinToast::instance()->setAppName(L"Test");
    const auto aumi = WinToast::configureAUMI(L"none", L"wintoast", L"test", L"10");
    WinToast::instance()->setAppUserModelId(aumi);

    if (!WinToast::instance()->initialize(&error))
        std::wcout << L"Error, could not initialize the lib!" << std::endl;

    MYWinToastHandler* handler = new MYWinToastHandler();
    WinToastTemplate templ = WinToastTemplate(WinToastTemplate::ImageAndText02);
    templ.setImagePath(L"E:/Pic/icon.jpg");
    templ.setTextField(L"title", WinToastTemplate::FirstLine);
    templ.setTextField(L"subtitle", WinToastTemplate::SecondLine);

    if (WinToast::instance()->showToast(templ, handler) < 0)
        std::wcout << L"Could not launch your toast notification!";

    std::cin.get();

    
    delete handler;
    return 0;
}