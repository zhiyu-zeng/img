'use strict';

/*
 * Discovery phase: enumerate app-owned RegisterNatives entries without
 * assuming a class, method name, signature, or native function address.
 *
 * Run in spawn mode:
 *   frida -U -f com.flass.myapplication -l trace_360_registered_methods.js
 */

const CONFIG = {
    packagePrefix: 'com.flass.myapplication',
};

let registerNativesHook = null;

function status(message) {
    console.log('[360-method-discovery] ' + message);
}

function classNameFor(clazz) {
    try {
        const env = Java.vm.tryGetEnv();
        if (env !== null && typeof env.getClassName === 'function') {
            return env.getClassName(clazz);
        }
    } catch (_) {}
    return '?';
}

function rangeFor(address) {
    try {
        const range = Process.findRangeByAddress(address);
        if (range === null) return 'range=?';
        const file = range.file === undefined || range.file === null
            ? ''
            : ' file=' + range.file.path;
        return 'range=' + range.base + '+0x' + range.size.toString(16) +
            ' prot=' + range.protection + file;
    } catch (_) {
        return 'range=?';
    }
}

function locationFor(address) {
    try {
        const module = Process.findModuleByAddress(address);
        if (module === null) return 'module=?';
        return module.name + '+' + address.sub(module.base);
    } catch (_) {
        return 'module=?';
    }
}

function installRegisterNativesHook() {
    if (registerNativesHook !== null || !Java.available) return;

    try {
        Java.performNow(function () {
            const env = Java.vm.getEnv();
            const table = env.handle.readPointer();
            const registerNatives = table
                .add(215 * Process.pointerSize)
                .readPointer();

            registerNativesHook = Interceptor.attach(registerNatives, {
                onEnter: function (args) {
                    const className = classNameFor(args[1]);
                    const methods = args[2];
                    const count = args[3].toInt32();

                    if (className.indexOf(CONFIG.packagePrefix) !== 0) return;
                    if (count < 0 || count > 10000) {
                        status('[REGISTER-ERROR] class=' + className +
                            ' invalid-count=' + count);
                        return;
                    }

                    status('[REGISTER] class=' + className +
                        ' return-site=' + locationFor(this.returnAddress) +
                        ' return=' + this.returnAddress +
                        ' methods=' + methods + ' count=' + count);

                    for (let i = 0; i < count; i++) {
                        try {
                            const item = methods.add(
                                i * Process.pointerSize * 3);
                            const namePtr = item.readPointer();
                            const signaturePtr = item
                                .add(Process.pointerSize)
                                .readPointer();
                            const name = namePtr.readCString();
                            const signature = signaturePtr.readCString();
                            const fn = item
                                .add(Process.pointerSize * 2)
                                .readPointer();

                            status('[REGISTERED-METHOD] class=' + className +
                                ' index=' + i +
                                ' entry=' + item +
                                ' name=' + name +
                                ' name-ptr=' + namePtr +
                                ' signature=' + signature +
                                ' signature-ptr=' + signaturePtr +
                                ' fn=' + fn + ' ' + rangeFor(fn));
                        } catch (e) {
                            status('[METHOD-ERROR] class=' + className +
                                ' index=' + i + ' error=' + e);
                        }
                    }
                },
            });

            status('hooked JNIEnv->RegisterNatives at ' + registerNatives);
        });
    } catch (_) {}
}

setInterval(installRegisterNativesHook, 20);
setImmediate(function () {
    status('agent started pid=' + Process.id + '; use -f spawn mode');
    installRegisterNativesHook();
});
