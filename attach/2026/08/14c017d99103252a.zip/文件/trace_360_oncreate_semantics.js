'use strict';

/*
 * Evidence-only trace for the real 360 DexVMP MainActivity.onCreate body.
 *
 * This script does not replace or attach to the generated trampoline, does not
 * call the dispatcher a second time, and does not dump a runtime Dex. It
 * observes the original execution and records:
 *
 *   - the closure -> linker dispatcher -> method-record mapping;
 *   - every Dex string resolved by linker+0x57A74;
 *   - the virtual opcode returned by linker+0x7CD4C;
 *   - the raw arguments entering the invoke handler at linker+0x7DE68;
 *   - the real JNIEnv calls after undoing the linker's shuffled JNI table.
 *
 * Run in spawn mode:
 *   frida -U -f com.flass.myapplication -l trace_360_oncreate_semantics.js
 */

const CONFIG = {
    packageName: 'com.flass.myapplication',
    className: 'com.flass.myapplication.MainActivity',
    methodName: 'onCreate',
    signature: '(Landroid/os/Bundle;)V',
    outputPath: '/data/data/com.flass.myapplication/files/360_oncreate_semantics.log',
    dispatcherOffset: 0x53b24,
    methodRecordReadyOffset: 0x53ba4,
    methodReturnOffset: 0x55618,
    dexStringOffset: 0x57a74,
    opcodeFetchOffset: 0x7cd4c,
    operandFetchOffset: 0x8a0d4,
    packedOperandFetchOffset: 0x89bc8,
    invokeHandlerOffset: 0x7de68,
};

// Proven by following linker+0x61F0C's dispatch tree to each handler and
// correlating the handler with its real JNIEnv operation.  The VM changes the
// low opcode byte but preserves the Dalvik instruction's high operand byte and
// following 16-bit code units.
const DALVIK_OPCODES = {
    0x13: { opcode: 0x6f, name: 'invoke-super', width: 3 },
    0x8d: { opcode: 0x6e, name: 'invoke-virtual', width: 3 },
    0x0e: { opcode: 0x0c, name: 'move-result-object', width: 1 },
    0x3f: { opcode: 0x60, name: 'sget', width: 2 },
    0x94: { opcode: 0x12, name: 'const/4', width: 1 },
    0x88: { opcode: 0x1f, name: 'check-cast', width: 2 },
    0x60: { opcode: 0x62, name: 'sget-object', width: 2 },
    0xbc: { opcode: 0x71, name: 'invoke-static', width: 3 },
    0x9d: { opcode: 0x0a, name: 'move-result', width: 1 },
    0x87: { opcode: 0x24, name: 'filled-new-array', width: 3 },
    0x4a: { opcode: 0x1a, name: 'const-string', width: 2 },
    0x19: { opcode: 0x0e, name: 'return-void', width: 1 },
};

let output = null;
let installed = false;
let registerNativesHook = null;
let linkerBase = NULL;
let nativeFunction = NULL;
let dispatcher = NULL;
let closureIdentity = NULL;
const hooks = [];
const activeDepth = new Map();
const classNames = new Map();
const methodIds = new Map();
const fieldIds = new Map();
const stringValues = new Map();
const arrayValues = new Map();
const hookedJniAddresses = new Map();
const currentVmInstructions = new Map();

function status(message) {
    console.log('[360-oncreate-semantics] ' + message);
}

function openOutput() {
    if (output !== null) return;
    output = new File(CONFIG.outputPath, 'w');
    output.write('# 360 MainActivity.onCreate semantic execution trace\n');
    output.write('# No replacement, no replay, no runtime-Dex reconstruction.\n');
    output.flush();
}

function emit(line, echo) {
    if (output !== null) {
        output.write(line + '\n');
        output.flush();
    }
    if (echo === true) status(line);
}

function tid() {
    return Process.getCurrentThreadId();
}

function isActive() {
    return (activeDepth.get(tid()) || 0) > 0;
}

function enterActive() {
    const id = tid();
    activeDepth.set(id, (activeDepth.get(id) || 0) + 1);
}

function leaveActive() {
    const id = tid();
    const depth = activeDepth.get(id) || 0;
    if (depth <= 1) activeDepth.delete(id);
    else activeDepth.set(id, depth - 1);
}

function key(value) {
    try { return ptr(value).toString(); } catch (_) { return String(value); }
}

function linkerName(value) {
    const p = ptr(value);
    if (!linkerBase.isNull()) {
        const off = p.sub(linkerBase);
        if (off.compare(ptr(0)) >= 0 && off.compare(ptr(0x19c000)) < 0) {
            return 'linker+0x' + off.toString(16);
        }
    }
    try {
        const module = Process.findModuleByAddress(p);
        if (module !== null) return module.name + '+0x' + p.sub(module.base).toString(16);
    } catch (_) {}
    return p.toString();
}

function isLinkerAddress(value) {
    if (linkerBase.isNull()) return false;
    try {
        const off = ptr(value).sub(linkerBase);
        return off.compare(ptr(0)) >= 0 && off.compare(ptr(0x19c000)) < 0;
    } catch (_) {
        return false;
    }
}

function readCStringSafe(value) {
    try {
        const p = ptr(value);
        if (p.isNull()) return 'null';
        return p.readCString();
    } catch (e) {
        return '<unreadable:' + e + '>';
    }
}

function quote(value) {
    return JSON.stringify(String(value));
}

function bytesSafe(value, size) {
    try {
        const p = ptr(value);
        if (p.isNull()) return 'null';
        const data = p.readByteArray(size);
        if (data === null) return 'null';
        return Array.prototype.map.call(new Uint8Array(data), function (b) {
            return ('0' + b.toString(16)).slice(-2);
        }).join('');
    } catch (e) {
        return '<unreadable:' + e + '>';
    }
}

function refName(value) {
    const k = key(value);
    if (stringValues.has(k)) return k + '<string=' + quote(stringValues.get(k)) + '>';
    if (arrayValues.has(k)) {
        const array = arrayValues.get(k);
        return k + '<' + array.type + '=' + JSON.stringify(array.values) + '>';
    }
    if (classNames.has(k)) return k + '<' + classNames.get(k) + '>';
    return k;
}

function methodName(value) {
    const k = key(value);
    const meta = methodIds.get(k);
    if (meta === undefined) return k + '<unresolved-method>';
    return k + '<' + meta.owner + '->' + meta.name + meta.signature + '>';
}

function fieldName(value) {
    const k = key(value);
    const meta = fieldIds.get(k);
    if (meta === undefined) return k + '<unresolved-field>';
    return k + '<' + meta.owner + '->' + meta.name + ':' + meta.signature + '>';
}

function classNameForRegistration(clazz) {
    try {
        const env = Java.vm.tryGetEnv();
        if (env !== null && typeof env.getClassName === 'function') {
            return env.getClassName(clazz);
        }
    } catch (_) {}
    return '?';
}

function parseParameterTypes(signature) {
    const result = [];
    if (signature.length === 0 || signature[0] !== '(') return result;
    let i = 1;
    while (i < signature.length && signature[i] !== ')') {
        const start = i;
        while (signature[i] === '[') i++;
        if (signature[i] === 'L') {
            const end = signature.indexOf(';', i);
            if (end === -1) break;
            i = end + 1;
        } else {
            i++;
        }
        result.push(signature.slice(start, i));
    }
    return result;
}

function readJValue(slot, type) {
    try {
        const baseType = type[0] === '[' ? 'L' : type[0];
        switch (baseType) {
        case 'Z': return slot.readU8() === 0 ? 'false' : 'true';
        case 'B': return String(slot.readS8());
        case 'C': return '0x' + slot.readU16().toString(16);
        case 'S': return String(slot.readS16());
        case 'I': return String(slot.readS32());
        case 'J': return slot.readS64().toString();
        case 'F': return String(slot.readFloat());
        case 'D': return String(slot.readDouble());
        case 'L': return refName(slot.readPointer());
        default: return 'raw=0x' + bytesSafe(slot, 8);
        }
    } catch (e) {
        return '<unreadable:' + e + '>';
    }
}

function readJValues(pointer, signature) {
    const p = ptr(pointer);
    if (p.isNull()) return 'null';
    const types = parseParameterTypes(signature);
    if (types.length === 0) return '[]';
    const values = [];
    for (let i = 0; i < types.length; i++) {
        values.push(types[i] + '=' + readJValue(p.add(i * 8), types[i]));
    }
    return '[' + values.join(', ') + ']';
}

function classLabel(clazz) {
    return classNames.get(key(clazz)) || ('class@' + key(clazz));
}

function propagateRef(result, source) {
    const src = key(source);
    const dst = key(result);
    clearRef(result);
    if (classNames.has(src)) classNames.set(dst, classNames.get(src));
    if (stringValues.has(src)) stringValues.set(dst, stringValues.get(src));
    if (arrayValues.has(src)) arrayValues.set(dst, arrayValues.get(src));
}

function clearRef(value) {
    const k = key(value);
    classNames.delete(k);
    stringValues.delete(k);
    arrayValues.delete(k);
}

function finalizeVmInstruction(threadId) {
    const instruction = currentVmInstructions.get(threadId);
    if (instruction === undefined) return;
    const mapping = DALVIK_OPCODES[instruction.vmOpcode];
    const restoredFirst = mapping === undefined ? instruction.key :
        ((instruction.key & 0xff00) | mapping.opcode);
    const indexes = Array.from(instruction.units.keys()).sort(function (a, b) { return a - b; });
    const units = ['0x' + restoredFirst.toString(16).padStart(4, '0')];
    indexes.forEach(function (index) {
        if (index === 0) return;
        units.push('0x' + instruction.units.get(index).toString(16).padStart(4, '0'));
    });
    emit('[VM-INSTRUCTION] vm-opcode=0x' + instruction.vmOpcode.toString(16) +
        ' dalvik=' + (mapping === undefined ? '?' : mapping.name) +
        ' offset=' + (instruction.offset === undefined ? '?' : instruction.offset) +
        ' pc=' + (instruction.pc === undefined ? '?' : instruction.pc) +
        ' raw-first=0x' + instruction.key.toString(16).padStart(4, '0') +
        ' restored-units=' + units.join(',') +
        ' next-offset=' + (instruction.nextOffset === undefined ? '?' : instruction.nextOffset) +
        ' width-check=' + (mapping === undefined || instruction.nextOffset === undefined ||
            instruction.offset === undefined ? '?' :
            (instruction.nextOffset - instruction.offset === mapping.width ? 'ok' : 'mismatch')), true);
    currentVmInstructions.delete(threadId);
}

function attachJni(index, name, callbacks) {
    let env;
    try { env = Java.vm.getEnv(); } catch (_) { return; }
    const table = env.handle.readPointer();
    const address = table.add(index * Process.pointerSize).readPointer();
    const addressKey = address.toString();
    if (hookedJniAddresses.has(addressKey)) {
        const aliases = hookedJniAddresses.get(addressKey);
        aliases.push(name);
        return;
    }
    hookedJniAddresses.set(addressKey, [name]);
    const hook = Interceptor.attach(address, {
        onEnter: function (args) {
            // Framework calls made recursively by inflate/setContentView run
            // on the same thread.  Only calls issued by linker.so itself are
            // VM semantic events; everything else is nested Android noise.
            this.enabled = isActive() && isLinkerAddress(this.returnAddress);
            if (!this.enabled) return;
            this.args = [];
            for (let i = 0; i < 8; i++) this.args.push(args[i]);
            this.returnAddressCopy = this.returnAddress;
            if (callbacks.onEnter !== undefined) callbacks.onEnter.call(this, args);
        },
        onLeave: function (retval) {
            if (!this.enabled) return;
            if (callbacks.onLeave !== undefined) callbacks.onLeave.call(this, retval);
        },
    });
    hooks.push(hook);
}

function installCoreJniHooks() {
    attachJni(6, 'FindClass', {
        onEnter: function (args) { this.name = readCStringSafe(args[1]); },
        onLeave: function (retval) {
            clearRef(retval);
            classNames.set(key(retval), 'L' + this.name + ';');
            emit('[JNI] FindClass name=' + quote(this.name) + ' -> ' + refName(retval), true);
        },
    });

    attachJni(31, 'GetObjectClass', {
        onEnter: function (args) { this.object = args[1]; },
        onLeave: function (retval) {
            clearRef(retval);
            classNames.set(key(retval), 'class-of(' + refName(this.object) + ')');
            emit('[JNI] GetObjectClass object=' + refName(this.object) + ' -> ' + refName(retval), false);
        },
    });

    attachJni(11, 'IsAssignableFrom', {
        onEnter: function (args) { this.left = args[1]; this.right = args[2]; },
        onLeave: function (retval) {
            emit('[JNI] IsAssignableFrom left=' + refName(this.left) +
                ' right=' + refName(this.right) + ' -> ' + retval.toInt32(), false);
        },
    });

    attachJni(32, 'IsInstanceOf', {
        onEnter: function (args) { this.object = args[1]; this.clazz = args[2]; },
        onLeave: function (retval) {
            const result = retval.toInt32();
            if (result !== 0 && classNames.has(key(this.clazz))) {
                const type = classNames.get(key(this.clazz));
                clearRef(this.object);
                classNames.set(key(this.object), type);
            }
            emit('[JNI] IsInstanceOf object=' + refName(this.object) +
                ' class=' + refName(this.clazz) + ' -> ' + result, false);
        },
    });

    [
        [21, 'NewGlobalRef'],
        [25, 'NewLocalRef'],
    ].forEach(function (entry) {
        attachJni(entry[0], entry[1], {
            onEnter: function (args) { this.source = args[1]; },
            onLeave: function (retval) {
                propagateRef(retval, this.source);
                emit('[JNI] ' + entry[1] + ' source=' + refName(this.source) +
                    ' -> ' + refName(retval), false);
            },
        });
    });

    [
        [22, 'DeleteGlobalRef'],
        [23, 'DeleteLocalRef'],
    ].forEach(function (entry) {
        attachJni(entry[0], entry[1], {
            onEnter: function (args) {
                this.reference = args[1];
                emit('[JNI] ' + entry[1] + ' ref=' + refName(this.reference), false);
            },
            onLeave: function () {
                clearRef(this.reference);
            },
        });
    });

    attachJni(19, 'PushLocalFrame', {
        onEnter: function (args) { this.capacity = args[1].toInt32(); },
        onLeave: function (retval) {
            emit('[JNI] PushLocalFrame capacity=' + this.capacity + ' -> ' + retval.toInt32(), false);
        },
    });
    attachJni(20, 'PopLocalFrame', {
        onEnter: function (args) { this.result = args[1]; },
        onLeave: function (retval) {
            emit('[JNI] PopLocalFrame result=' + refName(this.result) + ' -> ' + refName(retval), false);
        },
    });

    attachJni(13, 'Throw', {
        onEnter: function (args) { emit('[JNI] Throw throwable=' + refName(args[1]), true); },
    });
    attachJni(14, 'ThrowNew', {
        onEnter: function (args) {
            emit('[JNI] ThrowNew class=' + refName(args[1]) +
                ' message=' + quote(readCStringSafe(args[2])), true);
        },
    });
    attachJni(15, 'ExceptionOccurred', {
        onLeave: function (retval) { emit('[JNI] ExceptionOccurred -> ' + refName(retval), false); },
    });
    attachJni(17, 'ExceptionClear', {
        onEnter: function () { emit('[JNI] ExceptionClear', false); },
    });
    attachJni(228, 'ExceptionCheck', {
        onLeave: function (retval) { emit('[JNI] ExceptionCheck -> ' + retval.toInt32(), false); },
    });

    installIdHooks();
    installCallHooks();
    installFieldHooks();
    installStringHooks();
    installArrayHooks();
}

function installIdHooks() {
    [
        [33, 'GetMethodID', false],
        [113, 'GetStaticMethodID', true],
    ].forEach(function (entry) {
        attachJni(entry[0], entry[1], {
            onEnter: function (args) {
                this.owner = classLabel(args[1]);
                this.name = readCStringSafe(args[2]);
                this.signature = readCStringSafe(args[3]);
            },
            onLeave: function (retval) {
                methodIds.set(key(retval), {
                    owner: this.owner,
                    name: this.name,
                    signature: this.signature,
                    isStatic: entry[2],
                });
                emit('[JNI] ' + entry[1] + ' owner=' + this.owner +
                    ' name=' + quote(this.name) + ' signature=' + quote(this.signature) +
                    ' -> ' + methodName(retval), true);
            },
        });
    });

}

function installOneCall(index, name, family, mode, returnType) {
    attachJni(index, name, {
        onEnter: function (args) {
            let receiver;
            let clazz = NULL;
            let method;
            let values;
            if (family === 'nonvirtual') {
                receiver = args[1];
                clazz = args[2];
                method = args[3];
                values = args[4];
            } else {
                receiver = args[1];
                method = args[2];
                values = args[3];
            }
            const meta = methodIds.get(key(method));
            const signature = meta === undefined ? '?' : meta.signature;
            let decoded;
            if (mode === 'A' && signature !== '?') decoded = readJValues(values, signature);
            else if (mode === 'A') decoded = 'jvalues@' + key(values) + ' raw=0x' + bytesSafe(values, 0x30);
            else if (mode === 'V') decoded = 'va_list@' + key(values) + ' raw=0x' + bytesSafe(values, 0x40);
            else decoded = 'varargs x3=' + key(this.args[3]) + ' x4=' + key(this.args[4]) +
                ' x5=' + key(this.args[5]) + ' x6=' + key(this.args[6]) + ' x7=' + key(this.args[7]);
            this.callMeta = {
                receiver: receiver,
                clazz: clazz,
                method: method,
                signature: signature,
                decoded: decoded,
            };
            let line = '[JNI-CALL] ' + name + ' receiver=' + refName(receiver);
            if (family === 'nonvirtual') line += ' dispatch-class=' + refName(clazz);
            line += ' method=' + methodName(method) + ' args=' + decoded;
            emit(line, true);
        },
        onLeave: function (retval) {
            if (returnType === 'V') {
                emit('[JNI-RETURN] ' + name + ' -> void', false);
                return;
            }
            let value = retval.toString();
            if (returnType === 'L') {
                clearRef(retval);
                const meta = methodIds.get(key(this.callMeta.method));
                if (meta !== undefined) {
                    const end = meta.signature.lastIndexOf(')');
                    const returnDescriptor = end === -1 ? 'Ljava/lang/Object;' : meta.signature.slice(end + 1);
                    classNames.set(key(retval), returnDescriptor + '<return-of ' +
                        meta.owner + '->' + meta.name + '>');
                }
                value = refName(retval);
            }
            emit('[JNI-RETURN] ' + name + ' -> ' + value, false);
        },
    });
}

function installCallHooks() {
    // The VM normalizes Java invokes to the A (jvalue[]) JNI family.  Hook all
    // result widths but not the variadic/V families, which the observed VM
    // execution never uses.
    const types = [
        ['Object', 'L'], ['Boolean', 'Z'], ['Byte', 'B'], ['Char', 'C'],
        ['Short', 'S'], ['Int', 'I'], ['Long', 'J'], ['Float', 'F'],
        ['Double', 'D'], ['Void', 'V'],
    ];
    types.forEach(function (type, i) {
        installOneCall(36 + i * 3, 'Call' + type[0] + 'MethodA', 'instance', 'A', type[1]);
        installOneCall(66 + i * 3, 'CallNonvirtual' + type[0] + 'MethodA', 'nonvirtual', 'A', type[1]);
        installOneCall(116 + i * 3, 'CallStatic' + type[0] + 'MethodA', 'static', 'A', type[1]);
    });
}

function installFieldHooks() {
    // This access is part of the linker's reference bookkeeping.  It is kept
    // in the evidence log so it cannot be mistaken for a Java source field.
    attachJni(107, 'SetCharField', {
        onEnter: function (args) {
            emit('[JNI-FIELD] SetCharField object=' + refName(args[1]) +
                ' field=' + fieldName(args[2]) + ' value=' + args[3].toString(), false);
        },
    });
}

function installStringHooks() {
    attachJni(167, 'NewStringUTF', {
        onEnter: function (args) { this.value = readCStringSafe(args[1]); },
        onLeave: function (retval) {
            clearRef(retval);
            stringValues.set(key(retval), this.value);
            emit('[JNI] NewStringUTF value=' + quote(this.value) + ' -> ' + refName(retval), true);
        },
    });
    attachJni(169, 'GetStringUTFChars', {
        onEnter: function (args) { this.string = args[1]; },
        onLeave: function (retval) {
            emit('[JNI] GetStringUTFChars string=' + refName(this.string) +
                ' -> ' + key(retval) + ' value=' + quote(readCStringSafe(retval)), false);
        },
    });
    attachJni(170, 'ReleaseStringUTFChars', {
        onEnter: function (args) {
            emit('[JNI] ReleaseStringUTFChars string=' + refName(args[1]) +
                ' chars=' + key(args[2]), false);
        },
    });
}

function installArrayHooks() {
    attachJni(171, 'GetArrayLength', {
        onEnter: function (args) { this.array = args[1]; },
        onLeave: function (retval) {
            emit('[JNI-ARRAY] GetArrayLength array=' + refName(this.array) +
                ' -> ' + retval.toInt32(), false);
        },
    });
    attachJni(172, 'NewObjectArray', {
        onEnter: function (args) {
            this.length = args[1].toInt32();
            this.elementClass = args[2];
            this.initial = args[3];
        },
        onLeave: function (retval) {
            clearRef(retval);
            const initial = refName(this.initial);
            const values = [];
            for (let i = 0; i < this.length; i++) values.push(initial);
            arrayValues.set(key(retval), {
                type: '[' + classLabel(this.elementClass),
                values: values,
            });
            emit('[JNI-ARRAY] NewObjectArray length=' + this.length +
                ' element-class=' + refName(this.elementClass) +
                ' initial=' + initial + ' -> ' + refName(retval), true);
        },
    });
    attachJni(173, 'GetObjectArrayElement', {
        onEnter: function (args) { this.array = args[1]; this.index = args[2].toInt32(); },
        onLeave: function (retval) {
            emit('[JNI-ARRAY] GetObjectArrayElement array=' + refName(this.array) +
                ' index=' + this.index + ' -> ' + refName(retval), false);
        },
    });
    attachJni(174, 'SetObjectArrayElement', {
        onEnter: function (args) {
            const array = args[1];
            const index = args[2].toInt32();
            const value = refName(args[3]);
            const state = arrayValues.get(key(array));
            if (state !== undefined && index >= 0 && index < state.values.length) {
                state.values[index] = value;
            }
            emit('[JNI-ARRAY] SetObjectArrayElement array=' + refName(array) +
                ' index=' + index + ' value=' + value, true);
        },
    });
}

function installLinkerHooks() {
    hooks.push(Interceptor.attach(linkerBase.add(CONFIG.methodRecordReadyOffset), {
        onEnter: function () {
            if (!this.context.x24.equals(closureIdentity)) return;
            enterActive();
            const record = this.context.x20;
            const dexFile = this.context.x23;
            emit('[METHOD-ENTER] tid=' + tid() +
                ' method=' + CONFIG.className + '->' + CONFIG.methodName + CONFIG.signature +
                ' env=' + this.context.x21 + ' closure=' + this.context.x24 +
                ' trampoline=' + nativeFunction + ' dispatcher=' + linkerName(dispatcher), true);
            emit('[METHOD-RECORD] dex=' + dexFile + ' record=' + record +
                ' closure=' + this.context.x24 + ' env=' + this.context.x21, true);
            emit('[METHOD-RECORD-RAW] record=' + bytesSafe(record, 0x80), false);
            emit('[DEXFILE-RAW] dex=' + bytesSafe(dexFile, 0x60), false);
            try {
                const dexBase = dexFile.readPointer();
                const codeOffset = record.add(Process.pointerSize).readU32();
                const codeItem = dexBase.add(codeOffset);
                const registersSize = codeItem.readU16();
                const insSize = codeItem.add(2).readU16();
                const outsSize = codeItem.add(4).readU16();
                const triesSize = codeItem.add(6).readU16();
                const debugInfoOffset = codeItem.add(8).readU32();
                const insnsSize = codeItem.add(12).readU32();
                const insns = codeItem.add(16);
                emit('[CODE-ITEM] dex-base=' + dexBase +
                    ' code-off=0x' + codeOffset.toString(16) + ' code-item=' + codeItem +
                    ' registers=' + registersSize + ' ins=' + insSize +
                    ' outs=' + outsSize + ' tries=' + triesSize +
                    ' debug-info-off=0x' + debugInfoOffset.toString(16) +
                    ' insns-size=0x' + insnsSize.toString(16) +
                    ' insns=' + insns, true);
                emit('[CODE-ITEM-HEADER] ' + bytesSafe(codeItem, 16), false);
                emit('[CODE-ITEM-ENCRYPTED-INSNS] ' + bytesSafe(insns, insnsSize * 2), false);
                emit('[DEBUG-INFO-RAW] address=' + dexBase.add(debugInfoOffset) +
                    ' bytes=' + bytesSafe(dexBase.add(debugInfoOffset), 0x100), false);
            } catch (e) {
                emit('[CODE-ITEM-ERROR] ' + e, true);
            }
        },
    }));

    hooks.push(Interceptor.attach(linkerBase.add(CONFIG.methodReturnOffset), {
        onEnter: function () {
            if (!isActive()) return;
            finalizeVmInstruction(tid());
            emit('[METHOD-EXIT] tid=' + tid() + ' retval=' + this.context.x0, true);
            leaveActive();
        },
    }));

    hooks.push(Interceptor.attach(linkerBase.add(CONFIG.dexStringOffset), {
        onEnter: function (args) {
            this.enabled = isActive();
            if (!this.enabled) return;
            this.dex = args[0];
            this.stringId = args[1];
            try { this.dataOffset = args[1].readU32(); } catch (_) { this.dataOffset = 0; }
            this.caller = this.returnAddress;
        },
        onLeave: function (retval) {
            if (!this.enabled) return;
            emit('[DEX-STRING] caller=' + linkerName(this.caller) +
                ' dex=' + this.dex + ' string-id=' + this.stringId +
                ' data-off=0x' + this.dataOffset.toString(16) +
                ' value=' + quote(readCStringSafe(retval)), true);
        },
    }));

    hooks.push(Interceptor.attach(linkerBase.add(CONFIG.opcodeFetchOffset), {
        onEnter: function (args) {
            this.enabled = isActive();
            if (!this.enabled) return;
            this.state = args[0];
            this.keyValue = args[1];
            this.lane = args[2];
            this.caller = this.returnAddress;
            const threadId = tid();
            const cursor = args[0];
            const pc = cursor.readPointer();
            const start = this.context.x28;
            const offset = pc.sub(start).toInt32() / 2;
            const previous = currentVmInstructions.get(threadId);
            if (previous !== undefined) previous.nextOffset = offset;
            this.location = { pc: pc, start: start, offset: offset };
            if (offset === 0) {
                emit('[VM-CODE-START] start=' + start + ' cursor=' + cursor +
                    ' cursor-raw=' + bytesSafe(cursor, 0x60) +
                    ' around-start=' + bytesSafe(start.sub(0x30), 0xb0), true);
            }
            emit('[VM-PC] start=' + start + ' pc=' + pc + ' offset=' + offset +
                ' encoded-first=0x' + pc.readU16().toString(16).padStart(4, '0'), false);
        },
        onLeave: function (retval) {
            if (!this.enabled) return;
            const threadId = tid();
            finalizeVmInstruction(threadId);
            const vmOpcode = retval.toUInt32();
            const location = this.location;
            currentVmInstructions.set(threadId, {
                key: this.keyValue.toUInt32() & 0xffff,
                vmOpcode: vmOpcode,
                units: new Map([[0, this.keyValue.toUInt32() & 0xffff]]),
                pc: location === undefined ? undefined : location.pc,
                start: location === undefined ? undefined : location.start,
                offset: location === undefined ? undefined : location.offset,
            });
            emit('[VM-OPCODE] caller=' + linkerName(this.caller) +
                ' state=' + this.state + ' key=' + this.keyValue +
                ' lane=' + this.lane + ' opcode=0x' +
                vmOpcode.toString(16), true);
        },
    }));

    hooks.push(Interceptor.attach(linkerBase.add(CONFIG.operandFetchOffset), {
        onEnter: function (args) {
            this.enabled = isActive();
            if (!this.enabled) return;
            this.index = args[1].toUInt32();
        },
        onLeave: function (retval) {
            if (!this.enabled) return;
            const instruction = currentVmInstructions.get(tid());
            if (instruction === undefined) return;
            const word = retval.toUInt32() & 0xffff;
            if (!instruction.units.has(this.index)) instruction.units.set(this.index, word);
            emit('[VM-CODE-UNIT] vm-opcode=0x' + instruction.vmOpcode.toString(16) +
                ' index=' + this.index + ' value=0x' + word.toString(16).padStart(4, '0'), false);
        },
    }));

    // invoke-*/filled-new-array read their third 35c code unit through this
    // separate accessor. IDA shows linker+0x7DE68 and linker+0x7CF3C calling
    // it as fetch(state, 2, 0); observing the return value preserves the
    // original VM execution while exposing the C/D/E/F/G register nibbles.
    hooks.push(Interceptor.attach(linkerBase.add(CONFIG.packedOperandFetchOffset), {
        onEnter: function (args) {
            this.enabled = isActive();
            if (!this.enabled) return;
            this.index = args[1].toUInt32();
        },
        onLeave: function (retval) {
            if (!this.enabled) return;
            const instruction = currentVmInstructions.get(tid());
            if (instruction === undefined) return;
            const word = retval.toUInt32() & 0xffff;
            if (!instruction.units.has(this.index)) instruction.units.set(this.index, word);
            emit('[VM-CODE-UNIT] source=packed vm-opcode=0x' +
                instruction.vmOpcode.toString(16) + ' index=' + this.index +
                ' value=0x' + word.toString(16).padStart(4, '0'), false);
        },
    }));

    hooks.push(Interceptor.attach(linkerBase.add(CONFIG.invokeHandlerOffset), {
        onEnter: function (args) {
            if (!isActive()) return;
            emit('[VM-INVOKE-ENTER] kind=' + args[0].toUInt32() +
                ' result-slot=' + args[1].toUInt32() +
                ' env-state=' + args[2] + ' dex=' + args[3] +
                ' method-record=' + args[4] + ' value-state=' + args[5] +
                ' aux=0x' + args[6].toUInt32().toString(16) +
                ' execution-state=' + args[7], true);
        },
    }));
}

function installForNative(fn) {
    if (installed) return;
    nativeFunction = fn;
    closureIdentity = fn.add(0x6c);
    dispatcher = fn.add(0x80).readPointer();
    linkerBase = dispatcher.sub(CONFIG.dispatcherOffset);
    openOutput();
    installCoreJniHooks();
    installLinkerHooks();

    installed = true;
    status('installed without trampoline hook/replacement/replay; trampoline=' + nativeFunction +
        ' dispatcher=' + dispatcher + ' linker=' + linkerBase +
        ' output=' + CONFIG.outputPath);
}

function installRegisterNativesHook() {
    if (registerNativesHook !== null || !Java.available) return;
    try {
        Java.performNow(function () {
            const env = Java.vm.getEnv();
            const table = env.handle.readPointer();
            const registerNatives = table.add(215 * Process.pointerSize).readPointer();
            registerNativesHook = Interceptor.attach(registerNatives, {
                onEnter: function (args) {
                    const clazz = args[1];
                    const registeredClass = classNameForRegistration(clazz);
                    if (registeredClass.indexOf(CONFIG.packageName) !== 0) return;
                    const methods = args[2];
                    const count = args[3].toInt32();
                    for (let i = 0; i < count; i++) {
                        const item = methods.add(i * Process.pointerSize * 3);
                        const name = item.readPointer().readCString();
                        const signature = item.add(Process.pointerSize).readPointer().readCString();
                        const fn = item.add(Process.pointerSize * 2).readPointer();
                        status('[REGISTERED-METHOD] class=' + registeredClass +
                            ' name=' + name + ' signature=' + signature + ' fn=' + fn);
                        if (registeredClass !== CONFIG.className) continue;
                        if (name !== CONFIG.methodName || signature !== CONFIG.signature) continue;
                        try { installForNative(fn); }
                        catch (e) { status('install failed: ' + e.stack); }
                    }
                },
            });
            status('hooked JNIEnv->RegisterNatives at ' + registerNatives);
        });
    } catch (_) {}
}

setInterval(installRegisterNativesHook, 20);
setImmediate(function () {
    status('agent started pid=' + Process.id + '; use -f spawn mode');
    installRegisterNativesHook();
});
