'use strict';

const crypto = require('crypto');
const fs = require('fs');
const path = require('path');

const baseDir = __dirname;
const inputPath = path.resolve(process.argv[2] ||
    path.join(baseDir, '360_oncreate_codeitem_run7_full.log'));
const outputDir = path.resolve(process.argv[3] ||
    path.join(baseDir, 'recovered_smali', 'com', 'flass', 'myapplication'));
const text = fs.readFileSync(inputPath, 'utf8');

function requiredMatch(pattern, label) {
    const match = text.match(pattern);
    if (match === null) throw new Error('missing ' + label + ' in ' + inputPath);
    return match;
}

function fromHex(value) {
    if ((value.length & 1) !== 0) throw new Error('odd hex length');
    return Buffer.from(value, 'hex');
}

function sha256(buffer) {
    return crypto.createHash('sha256').update(buffer).digest('hex');
}

function readUleb(bytes, state) {
    let value = 0;
    let shift = 0;
    let current;
    do {
        if (state.offset >= bytes.length) throw new Error('truncated ULEB128');
        current = bytes[state.offset++];
        value |= (current & 0x7f) << shift;
        shift += 7;
    } while ((current & 0x80) !== 0);
    return value >>> 0;
}

function readSleb(bytes, state) {
    let value = 0;
    let shift = 0;
    let current;
    do {
        if (state.offset >= bytes.length) throw new Error('truncated SLEB128');
        current = bytes[state.offset++];
        value |= (current & 0x7f) << shift;
        shift += 7;
    } while ((current & 0x80) !== 0);
    if (shift < 32 && (current & 0x40) !== 0) value |= (-1 << shift);
    return value;
}

function parseDebugInfo(bytes) {
    const state = { offset: 0 };
    const lineStart = readUleb(bytes, state);
    const parameterCount = readUleb(bytes, state);
    const parameterNameIndexesP1 = [];
    for (let i = 0; i < parameterCount; i++) {
        parameterNameIndexesP1.push(readUleb(bytes, state));
    }

    let address = 0;
    let line = lineStart;
    const events = [];
    for (;;) {
        if (state.offset >= bytes.length) throw new Error('debug stream has no END_SEQUENCE');
        const opcode = bytes[state.offset++];
        if (opcode === 0) break;
        if (opcode === 1) {
            const delta = readUleb(bytes, state);
            address += delta;
            events.push({ kind: 'advance-pc', delta, address });
        } else if (opcode === 2) {
            const delta = readSleb(bytes, state);
            line += delta;
            events.push({ kind: 'advance-line', delta, line });
        } else if (opcode === 3 || opcode === 4) {
            const event = {
                kind: opcode === 3 ? 'start-local' : 'start-local-extended',
                register: readUleb(bytes, state),
                nameIndexP1: readUleb(bytes, state),
                typeIndexP1: readUleb(bytes, state),
            };
            if (opcode === 4) event.signatureIndexP1 = readUleb(bytes, state);
            events.push(event);
        } else if (opcode === 5 || opcode === 6) {
            events.push({
                kind: opcode === 5 ? 'end-local' : 'restart-local',
                register: readUleb(bytes, state),
            });
        } else if (opcode === 7 || opcode === 8) {
            events.push({ kind: opcode === 7 ? 'prologue-end' : 'epilogue-begin' });
        } else if (opcode === 9) {
            events.push({ kind: 'set-file', nameIndexP1: readUleb(bytes, state) });
        } else {
            const adjusted = opcode - 10;
            address += Math.floor(adjusted / 15);
            line += -4 + (adjusted % 15);
            events.push({ kind: 'position', address, line, opcode });
        }
    }

    return {
        byteLength: state.offset,
        lineStart,
        parameterCount,
        parameterNameIndexesP1,
        events,
    };
}

const codeItemMatch = requiredMatch(
    /^\[CODE-ITEM\].*code-off=(0x[0-9a-f]+).*registers=(\d+) ins=(\d+) outs=(\d+) tries=(\d+) debug-info-off=(0x[0-9a-f]+) insns-size=(0x[0-9a-f]+)/m,
    'CODE-ITEM');
const header = fromHex(requiredMatch(/^\[CODE-ITEM-HEADER\] ([0-9a-f]+)$/m,
    'CODE-ITEM-HEADER')[1]);
if (header.length !== 16) throw new Error('CodeItem header must be 16 bytes');

const metadata = {
    codeOffset: Number.parseInt(codeItemMatch[1], 16),
    registersSize: Number.parseInt(codeItemMatch[2], 10),
    insSize: Number.parseInt(codeItemMatch[3], 10),
    outsSize: Number.parseInt(codeItemMatch[4], 10),
    triesSize: Number.parseInt(codeItemMatch[5], 10),
    debugInfoOffset: Number.parseInt(codeItemMatch[6], 16),
    insnsSize: Number.parseInt(codeItemMatch[7], 16),
};

if (header.readUInt16LE(0) !== metadata.registersSize ||
    header.readUInt16LE(2) !== metadata.insSize ||
    header.readUInt16LE(4) !== metadata.outsSize ||
    header.readUInt16LE(6) !== metadata.triesSize ||
    header.readUInt32LE(8) !== metadata.debugInfoOffset ||
    header.readUInt32LE(12) !== metadata.insnsSize) {
    throw new Error('logged CodeItem fields do not match its raw header');
}

const instructionPattern = /^\[VM-INSTRUCTION\] vm-opcode=(0x[0-9a-f]+) dalvik=([^\s]+) offset=(\d+).*restored-units=([^\s]+) next-offset=([^\s]+) width-check=([^\s]+)$/gm;
const instructions = [];
let instructionMatch;
while ((instructionMatch = instructionPattern.exec(text)) !== null) {
    instructions.push({
        vmOpcode: Number.parseInt(instructionMatch[1], 16),
        mnemonic: instructionMatch[2],
        offset: Number.parseInt(instructionMatch[3], 10),
        units: instructionMatch[4].split(',').map(value => Number.parseInt(value, 16)),
        nextOffset: instructionMatch[5] === '?' ? null : Number.parseInt(instructionMatch[5], 10),
        widthCheck: instructionMatch[6],
    });
}
instructions.sort((left, right) => left.offset - right.offset);

let expectedOffset = 0;
const restoredUnits = [];
for (const instruction of instructions) {
    if (instruction.offset !== expectedOffset) {
        throw new Error('instruction gap/overlap at code-unit ' + expectedOffset);
    }
    if (instruction.nextOffset !== null &&
        instruction.nextOffset !== instruction.offset + instruction.units.length) {
        throw new Error('next-offset mismatch at code-unit ' + instruction.offset);
    }
    restoredUnits.push(...instruction.units);
    expectedOffset += instruction.units.length;
}
if (expectedOffset !== metadata.insnsSize) {
    throw new Error('restored ' + expectedOffset + ' code units, expected ' + metadata.insnsSize);
}

const restoredInsns = Buffer.alloc(restoredUnits.length * 2);
restoredUnits.forEach((unit, index) => restoredInsns.writeUInt16LE(unit, index * 2));
const restoredCodeItem = Buffer.concat([header, restoredInsns]);

const encryptedInsns = fromHex(requiredMatch(
    /^\[CODE-ITEM-ENCRYPTED-INSNS\] ([0-9a-f]+)$/m,
    'CODE-ITEM-ENCRYPTED-INSNS')[1]);
if (encryptedInsns.length !== restoredInsns.length) {
    throw new Error('encrypted/restored instruction lengths differ');
}

const debugRaw = fromHex(requiredMatch(
    /^\[DEBUG-INFO-RAW\].*bytes=([0-9a-f]+)$/m,
    'DEBUG-INFO-RAW')[1]);
const debugInfo = parseDebugInfo(debugRaw);
const exactDebugBytes = debugRaw.subarray(0, debugInfo.byteLength);

fs.mkdirSync(outputDir, { recursive: true });
const prefix = path.join(outputDir, 'MainActivity_onCreate');
fs.writeFileSync(prefix + '.restored.insns.bin', restoredInsns);
fs.writeFileSync(prefix + '.restored.code_item.bin', restoredCodeItem);
fs.writeFileSync(prefix + '.encrypted.insns.bin', encryptedInsns);
fs.writeFileSync(prefix + '.debug_info.bin', exactDebugBytes);

const report = {
    sourceLog: inputPath,
    metadata,
    instructionCount: instructions.length,
    restoredCodeUnits: restoredUnits.length,
    completeCoverage: restoredUnits.length === metadata.insnsSize,
    headerHex: header.toString('hex'),
    restoredInsnsHex: restoredInsns.toString('hex'),
    encryptedInsnsHex: encryptedInsns.toString('hex'),
    debugInfo: {
        ...debugInfo,
        bytesHex: exactDebugBytes.toString('hex'),
    },
    instructions,
    sha256: {
        restoredInsns: sha256(restoredInsns),
        restoredCodeItem: sha256(restoredCodeItem),
        encryptedInsns: sha256(encryptedInsns),
        debugInfo: sha256(exactDebugBytes),
    },
};
fs.writeFileSync(prefix + '.restored.json', JSON.stringify(report, null, 2) + '\n');

console.log('restored ' + instructions.length + ' instructions / ' +
    restoredUnits.length + ' code units');
console.log('code_item=' + prefix + '.restored.code_item.bin');
console.log('sha256=' + report.sha256.restoredCodeItem);
