"""Resolve the 360 linker VM's two-way opcode dispatch tree in IDA.

This sample-specific helper was written for the analysis documented in this
workspace.  It is not part of IDA, IDAMCP, AndroidPrybar, or the 360 shell.

Run from ida-pro-mcp py_eval with:
    exec(open(os.path.join(os.path.dirname(ida_nalt.get_input_file_path()),
        'ida_resolve_360_opcodes.py'), encoding='utf-8').read())

The IDB contains pointer values captured at the original runtime base.  This
script normalizes those values back to linker-relative addresses and follows
the CMP/CSET/two-entry-table/BR nodes until it reaches a handler leaf.
"""

import json

import ida_bytes
import idc


OLD_RUNTIME_BASE = 0x6C011F0000
LINKER_SIZE = 0x19C000
DISPATCH_ROOT = 0x61F0C

OBSERVED_OPCODES = [
    0x13,
    0x8D,
    0x0E,
    0x3F,
    0x94,
    0x88,
    0x60,
    0xBC,
    0x9D,
    0x87,
    0x4A,
    0x19,
]

VERBOSE = False


def normalize_pointer(value):
    if OLD_RUNTIME_BASE <= value < OLD_RUNTIME_BASE + LINKER_SIZE:
        return value - OLD_RUNTIME_BASE
    if 0 <= value < LINKER_SIZE:
        return value
    raise ValueError("pointer outside linker: 0x%x" % value)


def condition_true(condition, left, right):
    condition = condition.upper()
    if condition in ("EQ",):
        return left == right
    if condition in ("NE",):
        return left != right
    if condition in ("LT", "LO", "CC"):
        return left < right
    if condition in ("LE", "LS"):
        return left <= right
    if condition in ("GT", "HI"):
        return left > right
    if condition in ("GE", "HS", "CS"):
        return left >= right
    raise ValueError("unsupported condition %s" % condition)


def decode_node(ea, opcode):
    if idc.print_insn_mnem(ea).upper() != "CMP":
        return None
    if idc.print_operand(ea, 0).upper() not in ("W0", "X0"):
        return None

    immediate = idc.get_operand_value(ea, 1)
    adrp_ea = None
    cset_ea = None
    add_ea = None
    br_ea = None
    for candidate in range(ea + 4, ea + 0x24, 4):
        mnemonic = idc.print_insn_mnem(candidate).upper()
        if mnemonic == "ADRP" and adrp_ea is None:
            adrp_ea = candidate
        elif mnemonic == "CSET" and cset_ea is None:
            cset_ea = candidate
        elif mnemonic == "ADD" and add_ea is None:
            add_ea = candidate
        elif mnemonic == "BR":
            br_ea = candidate
            break

    if None in (adrp_ea, cset_ea, add_ea, br_ea):
        return None

    page = idc.get_operand_value(adrp_ea, 1)
    page_offset = idc.get_operand_value(add_ea, 2)
    table = page + page_offset
    condition = idc.print_operand(cset_ea, 1)
    index = 1 if condition_true(condition, opcode, immediate) else 0
    raw_target = ida_bytes.get_qword(table + index * 8)
    target = normalize_pointer(raw_target)
    return {
        "node": ea,
        "compare": immediate,
        "condition": condition.upper(),
        "index": index,
        "table": table,
        "raw_target": raw_target,
        "target": target,
    }


def follow_thunks(ea):
    thunks = []
    current = ea
    for _ in range(16):
        if idc.print_insn_mnem(current).upper() != "ADRP":
            break
        if idc.print_insn_mnem(current + 4).upper() != "LDR":
            break
        if idc.print_insn_mnem(current + 8).upper() != "BR":
            break
        page = idc.get_operand_value(current, 1)
        page_offset = idc.get_operand_value(current + 4, 1)
        pointer_address = page + page_offset
        raw_target = ida_bytes.get_qword(pointer_address)
        target = normalize_pointer(raw_target)
        thunks.append({
            "thunk": current,
            "pointer_address": pointer_address,
            "raw_target": raw_target,
            "target": target,
        })
        current = target
    return current, thunks


def resolve_opcode(opcode):
    path = []
    current = DISPATCH_ROOT
    seen = set()
    for _ in range(128):
        if current in seen:
            raise RuntimeError("dispatch loop at 0x%x" % current)
        seen.add(current)
        node = decode_node(current, opcode)
        if node is None:
            handler, thunks = follow_thunks(current)
            return {
                "opcode": opcode,
                "dispatch_leaf": current,
                "handler": handler,
                "handler_disasm": idc.generate_disasm_line(handler, 0),
                "thunks": thunks,
                "path": path,
            }
        path.append(node)
        current = node["target"]
    raise RuntimeError("dispatch depth exceeded for opcode 0x%x" % opcode)


RESULTS = [resolve_opcode(opcode) for opcode in OBSERVED_OPCODES]
if VERBOSE:
    print(json.dumps(RESULTS, indent=2))
else:
    print(json.dumps([
        {
            "opcode": "0x%x" % item["opcode"],
            "dispatch_leaf": "0x%x" % item["dispatch_leaf"],
            "handler": "0x%x" % item["handler"],
            "handler_disasm": item["handler_disasm"],
        }
        for item in RESULTS
    ], indent=2))
