'use strict';

/*
 * Phase 1 of the Smali trace reconstruction.
 *
 * This does not use the native declarations in the shell Dex. It records the
 * real packed-method pointer passed by linker.so to the three libjiagu
 * interpreter bridges and correlates registered Java methods with linker.so
 * function pointers.
 */

const CONFIG = {
    packageName: 'com.flass.myapplication',
    outputPath: '/data/data/com.flass.myapplication/files/360_method_map.log',
    blockTracePath: '/data/data/com.flass.myapplication/files/360_oncreate_blocks.log',
    enableStalker: false,
    jiaguNames: ['libjiagu_64.so', 'libjiagu.so'],
    bridgeOffsets: {
        int64: 0x165d4,
        float: 0x166b0,
        double: 0x1674c,
    },
    decoderOffset: 0x14688,

    // Static anchors recovered from linker_fixed.so JNI_OnLoad.
    linkerJniPackedOffset: 0x14a338,
    linkerJniPackedSize: 0x1c40,
    linkerJniMetadataOffset: 0x190160,
};

let output = null;
let blockOutput = null;
let jiaguModule = null;
let linkerBase = null;
let bridgesInstalled = false;
let registerNativesInstalled = false;
const seenPacked = Object.create(null);
const seenDecode = Object.create(null);
const bridgeHooks = [];
let registerNativesHook = null;
const nativeMethodHooks = [];
const activeJavaMethods = new Map();
const closureTargets = Object.create(null);
const nativeTraceStates = new Map();

function openOutput() {
    if (output !== null) return;
    try {
        output = new File(CONFIG.outputPath, 'w');
        output.write('# 360 linker method map\n');
        output.flush();
        blockOutput = new File(CONFIG.blockTracePath, 'w');
        blockOutput.write('# MainActivity native block trace\n');
        blockOutput.flush();
    } catch (e) {
        console.log('[360-method-map][!] open output failed: ' + e);
    }
}

function formatCodeAddress(address) {
    const p = ptr(address);
    if (linkerBase !== null) {
        const off = p.sub(linkerBase);
        if (off.compare(ptr(0)) >= 0 && off.compare(ptr(0x19c000)) < 0) {
            return 'linker+0x' + off.toString(16);
        }
    }
    if (jiaguModule !== null && p.compare(jiaguModule.base) >= 0 &&
        p.compare(jiaguModule.base.add(jiaguModule.size)) < 0) {
        return 'libjiagu+0x' + p.sub(jiaguModule.base).toString(16);
    }
    try {
        const m = Process.findModuleByAddress(p);
        if (m !== null) return m.name + '+0x' + p.sub(m.base).toString(16);
    } catch (_) {}
    return p.toString();
}

function startNativeTrace(label) {
    if (!CONFIG.enableStalker) return;
    const tid = Process.getCurrentThreadId();
    if (nativeTraceStates.has(tid)) return;
    const state = { label: label, count: 0, last: '', capped: false };
    nativeTraceStates.set(tid, state);
    if (blockOutput !== null) blockOutput.write('[TRACE-ENTER] tid=' + tid + ' method=' + label + '\n');
    Stalker.follow(tid, {
        events: { call: false, ret: false, exec: false, block: true, compile: false },
        onReceive: function (events) {
            const parsed = Stalker.parse(events, { annotate: false, stringify: false });
            parsed.forEach(function (event) {
                if (state.count >= 20000) {
                    state.capped = true;
                    return;
                }
                const name = formatCodeAddress(event[1]);
                if (name === state.last) return;
                state.last = name;
                state.count++;
                if (blockOutput !== null) blockOutput.write('[BLOCK] seq=' + state.count + ' ' + name + '\n');
            });
            if (blockOutput !== null) blockOutput.flush();
        },
    });
}

function stopNativeTrace() {
    if (!CONFIG.enableStalker) return;
    const tid = Process.getCurrentThreadId();
    const state = nativeTraceStates.get(tid);
    if (state === undefined) return;
    Stalker.unfollow(tid);
    Stalker.flush();
    if (blockOutput !== null) {
        blockOutput.write('[TRACE-EXIT] tid=' + tid + ' method=' + state.label +
            ' blocks=' + state.count + ' capped=' + state.capped + '\n');
        blockOutput.flush();
    }
    nativeTraceStates.delete(tid);
    setTimeout(function () { Stalker.garbageCollect(); }, 100);
}

function log(line) {
    console.log('[360-method-map] ' + line);
    if (output !== null) {
        try {
            output.write(line + '\n');
            output.flush();
        } catch (_) {}
    }
}

function findJiagu() {
    for (let i = 0; i < CONFIG.jiaguNames.length; i++) {
        const m = Process.findModuleByName(CONFIG.jiaguNames[i]);
        if (m !== null) return m;
    }
    return null;
}

function rangeText(p) {
    try {
        const r = Process.findRangeByAddress(p);
        if (r === null) return 'range=?';
        const file = r.file === undefined || r.file === null ? '' : (' file=' + r.file.path);
        return 'range=' + r.base + '+0x' + r.size.toString(16) +
            ' prot=' + r.protection + file;
    } catch (_) {
        return 'range=?';
    }
}

function linkerOffset(p) {
    if (linkerBase === null) return '?';
    try {
        return '0x' + p.sub(linkerBase).toString(16);
    } catch (_) {
        return '?';
    }
}

function pushJavaMethod(label) {
    const tid = Process.getCurrentThreadId();
    let stack = activeJavaMethods.get(tid);
    if (stack === undefined) {
        stack = [];
        activeJavaMethods.set(tid, stack);
    }
    stack.push(label);
}

function popJavaMethod() {
    const tid = Process.getCurrentThreadId();
    const stack = activeJavaMethods.get(tid);
    if (stack === undefined || stack.length === 0) return;
    stack.pop();
    if (stack.length === 0) activeJavaMethods.delete(tid);
}

function currentJavaMethod() {
    const stack = activeJavaMethods.get(Process.getCurrentThreadId());
    if (stack === undefined || stack.length === 0) return '?';
    return stack[stack.length - 1];
}

function dumpTrampoline(label, fn) {
    let pc = fn;
    const lines = [];
    for (let i = 0; i < 80; i++) {
        try {
            const insn = Instruction.parse(pc);
            lines.push(insn.address + ':' + insn.mnemonic + ' ' + insn.opStr);
            pc = insn.next;
            if (insn.mnemonic === 'ret' || insn.mnemonic === 'br' || insn.mnemonic === 'b') break;
        } catch (e) {
            lines.push('decode-error=' + e);
            break;
        }
    }
    log('[TRAMPOLINE] method=' + label + ' code=' + lines.join(' | '));
    try {
        const target = fn.add(0x80).readPointer();
        log('[TRAMPOLINE-TARGET] method=' + label +
            ' literal=' + fn.add(0x80) +
            ' target=' + target + ' ' + rangeText(target));
        hookClosureTarget(target);
    } catch (e) {
        log('[TRAMPOLINE-TARGET-ERROR] method=' + label + ' error=' + e);
    }
}

function hookClosureTarget(target) {
    const key = target.toString();
    if (closureTargets[key]) return;
    closureTargets[key] = true;
    try {
        const hook = Interceptor.attach(target, {
            onEnter: function (args) {
                log('[CLOSURE-ENTER] tid=' + Process.getCurrentThreadId() +
                    ' java=' + currentJavaMethod() +
                    ' target=' + target +
                    ' closure=' + args[0] +
                    ' env=' + args[1] +
                    ' va_list=' + args[2] +
                    ' a3=' + args[3] +
                    ' return=' + this.returnAddress);
            },
            onLeave: function (retval) {
                log('[CLOSURE-EXIT] tid=' + Process.getCurrentThreadId() +
                    ' java=' + currentJavaMethod() +
                    ' target=' + target + ' retval=' + retval);
            },
        });
        nativeMethodHooks.push(hook);
    } catch (e) {
        log('[CLOSURE-HOOK-ERROR] target=' + target + ' error=' + e);
    }
}

function hookRegisteredMethod(className, methodName, signature, fn) {
    if (className.indexOf(CONFIG.packageName) !== 0) return;
    const label = className + '-\u003e' + methodName + signature;
    try {
        dumpTrampoline(label, fn);
        const hook = Interceptor.attach(fn, {
            onEnter: function (args) {
                pushJavaMethod(label);
                startNativeTrace(label);
                log('[JAVA-ENTER] tid=' + Process.getCurrentThreadId() +
                    ' method=' + label + ' fn=' + fn +
                    ' a0=' + args[0] + ' a1=' + args[1] +
                    ' a2=' + args[2] + ' a3=' + args[3]);
            },
            onLeave: function (retval) {
                log('[JAVA-EXIT] tid=' + Process.getCurrentThreadId() +
                    ' method=' + label + ' retval=' + retval);
                stopNativeTrace();
                popJavaMethod();
            },
        });
        nativeMethodHooks.push(hook);
        log('[JAVA-HOOK] method=' + label + ' fn=' + fn);
    } catch (e) {
        log('[JAVA-HOOK-ERROR] method=' + label + ' fn=' + fn + ' error=' + e);
    }
}

function tryCalibrateLinkerBase(packed, packedSize, metadata) {
    if (linkerBase !== null) return;
    if (packedSize !== CONFIG.linkerJniPackedSize) {
        try {
            const range = Process.findRangeByAddress(packed);
            if (range !== null && range.protection.indexOf('x') !== -1 && range.size >= 0x17b528) {
                linkerBase = range.base;
                log('[LINKER-BASE] base=' + linkerBase + ' source=packed-executable-range');
            }
        } catch (_) {}
        return;
    }
    const candidate = packed.sub(CONFIG.linkerJniPackedOffset);
    try {
        if (metadata.sub(candidate).toUInt32() !== CONFIG.linkerJniMetadataOffset) return;
        linkerBase = candidate;
        log('[LINKER-BASE] base=' + linkerBase +
            ' packed=+0x' + CONFIG.linkerJniPackedOffset.toString(16) +
            ' metadata=+0x' + CONFIG.linkerJniMetadataOffset.toString(16));
    } catch (_) {}
}

function installBridge(name, offset) {
    const address = jiaguModule.base.add(offset);
    const hook = Interceptor.attach(address, {
        onEnter: function (args) {
            const packed = args[0];
            const packedSize = args[1].toUInt32();
            const metadata = args[2];
            const vaList = args[3];
            tryCalibrateLinkerBase(packed, packedSize, metadata);

            const key = packed.toString() + ':' + packedSize + ':' + metadata.toString();
            if (seenPacked[key]) return;
            seenPacked[key] = true;
            log('[PACKED] kind=' + name +
                ' tid=' + Process.getCurrentThreadId() +
                ' java=' + currentJavaMethod() +
                ' packed=' + packed +
                ' packed_off=' + linkerOffset(packed) +
                ' size=0x' + packedSize.toString(16) +
                ' metadata=' + metadata +
                ' metadata_off=' + linkerOffset(metadata) +
                ' va_list=' + vaList +
                ' return=' + this.returnAddress +
                ' ' + rangeText(packed));
        },
    });
    bridgeHooks.push(hook);
    log('hooked ' + name + ' bridge at ' + address +
        ' (libjiagu+0x' + offset.toString(16) + ')');
}

function installDecoderHook() {
    const address = jiaguModule.base.add(CONFIG.decoderOffset);
    const hook = Interceptor.attach(address, {
        onEnter: function (args) {
            const packed = args[1];
            const packedSize = args[2].toUInt32();
            const metadata = args[3];
            tryCalibrateLinkerBase(packed, packedSize, metadata);
            const decodeKey = Process.getCurrentThreadId() + ':' +
                currentJavaMethod() + ':' + packed + ':' + packedSize + ':' + metadata;
            if (seenDecode[decodeKey]) return;
            seenDecode[decodeKey] = true;
            log('[DECODE] tid=' + Process.getCurrentThreadId() +
                ' java=' + currentJavaMethod() +
                ' result=' + args[0] +
                ' packed=' + packed +
                ' packed_off=' + linkerOffset(packed) +
                ' size=0x' + packedSize.toString(16) +
                ' metadata=' + metadata +
                ' metadata_off=' + linkerOffset(metadata) +
                ' args=' + args[4]);
        },
    });
    bridgeHooks.push(hook);
    log('hooked packed decoder at ' + address +
        ' (libjiagu+0x' + CONFIG.decoderOffset.toString(16) + ')');
}

function installBridges() {
    if (bridgesInstalled) return;
    jiaguModule = findJiagu();
    if (jiaguModule === null) return;
    Object.keys(CONFIG.bridgeOffsets).forEach(function (name) {
        installBridge(name, CONFIG.bridgeOffsets[name]);
    });
    installDecoderHook();
    bridgesInstalled = true;
}

function classNameFor(clazz) {
    try {
        const env = Java.vm.tryGetEnv();
        if (env !== null && typeof env.getClassName === 'function') {
            return env.getClassName(clazz);
        }
    } catch (_) {}
    return '?';
}

function installRegisterNatives() {
    if (registerNativesInstalled || !Java.available) return;
    try {
        Java.performNow(function () {
            const env = Java.vm.getEnv();
            const table = env.handle.readPointer();
            const registerNatives = table.add(215 * Process.pointerSize).readPointer();
            registerNativesHook = Interceptor.attach(registerNatives, {
                onEnter: function (args) {
                    const clazz = args[1];
                    const methods = args[2];
                    const count = args[3].toInt32();
                    const className = classNameFor(clazz);
                    log('[REGISTER] class=' + className + ' count=' + count);
                    if (count < 0 || count > 10000) return;
                    for (let i = 0; i < count; i++) {
                        try {
                            const item = methods.add(i * Process.pointerSize * 3);
                            const methodName = item.readPointer().readCString();
                            const signature = item.add(Process.pointerSize).readPointer().readCString();
                            const fn = item.add(Process.pointerSize * 2).readPointer();
                            log('[METHOD] class=' + className +
                                ' name=' + methodName +
                                ' sig=' + signature +
                                ' fn=' + fn +
                                ' fn_off=' + linkerOffset(fn) +
                                ' ' + rangeText(fn));
                            hookRegisteredMethod(className, methodName, signature, fn);
                        } catch (e) {
                            log('[METHOD-ERROR] class=' + className + ' index=' + i + ' error=' + e);
                        }
                    }
                },
            });
            registerNativesInstalled = true;
            log('hooked JNIEnv->RegisterNatives at ' + registerNatives);
        });
    } catch (_) {}
}

openOutput();
setInterval(function () {
    installRegisterNatives();
    installBridges();
}, 50);

setImmediate(function () {
    log('agent started pid=' + Process.id);
    installRegisterNatives();
    installBridges();
});
