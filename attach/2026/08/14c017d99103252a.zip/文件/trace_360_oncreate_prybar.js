'use strict';

/*
 * AndroidPrybar trace for the real 360-generated MainActivity.onCreate body.
 *
 * The native address registered for onCreate is only a generated 0x88-byte
 * closure. Its literal at +0x80 points to linker.so's common dispatcher
 * (this build: linker+0x53B24). We trace that dispatcher only when x0 equals
 * the onCreate closure identity at trampoline+0x6c.
 */

const CONFIG = {
    packageName: 'com.flass.myapplication',
    className: 'com.flass.myapplication.MainActivity',
    methodName: 'onCreate',
    signature: '(Landroid/os/Bundle;)V',
    libtracePath: '/data/local/tmp/libtrace.so',
    tracePath: '/data/data/com.flass.myapplication/files/360_MainActivity_onCreate_native_trace.log',
};

let traceModule = null;
let vcMakeHandle = null;
let vcHookAdd = null;
let vcRegRead = null;
let vmContext = NULL;
let codeCallback = null;
let jumpCallback = null;
let registerHook = null;
let callSiteHook = null;
let skipCallCallback = null;
let replacementCallback = null;
let wrapperFunction = null;
let originalFunction = null;
let originalAddress = NULL;
let dispatcherAddress = NULL;
let closureIdentity = NULL;
let linkerBase = NULL;
let relocatedStub = NULL;
let installed = false;
let output = null;
let pending = [];
let instructionCount = 0;
const traceDepth = new Map();

const VC_HOOK_CODE = 1 << 2;
const VC_HOOK_EXTERNAL_JUMP = 1 << 21;

function status(message) {
    console.log('[360-oncreate-prybar] ' + message);
}

function classNameFor(clazz) {
    try {
        const env = Java.vm.tryGetEnv();
        if (env !== null && typeof env.getClassName === 'function') {
            return env.getClassName(clazz);
        }
    } catch (_) {}
    return '?';
}

function openOutput() {
    output = new File(CONFIG.tracePath, 'w');
    output.write('# AndroidPrybar MainActivity.onCreate trace\n');
    output.flush();
}

function emit(line) {
    pending.push(line);
    if (pending.length < 64) return;
    output.write(pending.join('\n') + '\n');
    output.flush();
    pending = [];
}

function readRegister(ctx, reg) {
    const slot = Memory.alloc(8);
    slot.writeU64(uint64(0));
    if (vcRegRead(ctx, reg, slot) !== 0) return NULL;
    return slot.readPointer();
}

function addressName(address) {
    const p = ptr(address);
    if (!linkerBase.isNull()) {
        const off = p.sub(linkerBase);
        if (off.compare(ptr(0x19c000)) < 0) return 'linker+0x' + off.toString(16);
    }
    try {
        const m = Process.findModuleByAddress(p);
        if (m !== null) return m.name + '+0x' + p.sub(m.base).toString(16);
    } catch (_) {}
    return p.toString();
}

function installVmHooks() {
    codeCallback = new NativeCallback(function (ctx, address, size, userData) {
        if (instructionCount >= 300000) return;
        instructionCount++;
        let text;
        try {
            const insn = Instruction.parse(address);
            text = addressName(address) + ' ' + insn.mnemonic + ' ' + insn.opStr;
            if (insn.mnemonic[0] === 'b' || insn.mnemonic === 'ret') {
                text += ' x0=' + readRegister(ctx, 0) +
                    ' x1=' + readRegister(ctx, 1) +
                    ' x2=' + readRegister(ctx, 2) +
                    ' x8=' + readRegister(ctx, 8) +
                    ' x19=' + readRegister(ctx, 19) +
                    ' x20=' + readRegister(ctx, 20) +
                    ' x21=' + readRegister(ctx, 21) +
                    ' x22=' + readRegister(ctx, 22) +
                    ' x23=' + readRegister(ctx, 23) +
                    ' x24=' + readRegister(ctx, 24);
            }
        } catch (e) {
            text = addressName(address) + ' size=' + size + ' decode-error=' + e;
        }
        emit('[CODE] seq=' + instructionCount + ' ' + text);
    }, 'void', ['pointer', 'pointer', 'uint32', 'pointer']);

    jumpCallback = new NativeCallback(function (ctx, address, symbolName, action, userData) {
        let symbol = '?';
        try { if (!symbolName.isNull()) symbol = symbolName.readCString(); } catch (_) {}
        emit('[JUMP] target=' + addressName(address) +
            ' symbol=' + symbol +
            ' x0=' + readRegister(ctx, 0) +
            ' x1=' + readRegister(ctx, 1) +
            ' x2=' + readRegister(ctx, 2) +
            ' x3=' + readRegister(ctx, 3));
    }, 'void', ['pointer', 'pointer', 'pointer', 'pointer', 'pointer']);

    const codeHandle = Memory.alloc(Process.pointerSize);
    const jumpHandle = Memory.alloc(Process.pointerSize);
    codeHandle.writePointer(NULL);
    jumpHandle.writePointer(NULL);
    let err = vcHookAdd(vmContext, codeHandle, VC_HOOK_CODE, codeCallback, NULL, NULL, NULL);
    if (err !== 0) throw new Error('vc_hook_add(CODE) failed: ' + err);
    err = vcHookAdd(vmContext, jumpHandle, VC_HOOK_EXTERNAL_JUMP, jumpCallback, NULL, NULL, NULL);
    if (err !== 0) throw new Error('vc_hook_add(EXTERNAL_JUMP) failed: ' + err);
}

function resolveTrace() {
    if (vcMakeHandle !== null) return;
    traceModule = Module.load(CONFIG.libtracePath);
    const make = traceModule.findExportByName('_Z14vc_make_handlePvPP10vm_context');
    const hook = traceModule.findExportByName('_Z11vc_hook_addP10vm_contextPmiPvS2_mm');
    const reg = traceModule.findExportByName('_Z11vc_reg_readP10vm_context6vc_regPv');
    if (make === null || hook === null || reg === null) throw new Error('required libtrace exports missing');
    vcMakeHandle = new NativeFunction(make, 'pointer', ['pointer', 'pointer']);
    vcHookAdd = new NativeFunction(hook, 'int',
        ['pointer', 'pointer', 'int', 'pointer', 'pointer', 'pointer', 'pointer']);
    vcRegRead = new NativeFunction(reg, 'int', ['pointer', 'int', 'pointer']);
    status('loaded ' + CONFIG.libtracePath + ' @ ' + traceModule.base);
}

function installDispatcherTrace(nativeFn) {
    if (installed) return;
    resolveTrace();

    closureIdentity = nativeFn.add(0x6c);
    dispatcherAddress = nativeFn.add(0x80).readPointer();
    linkerBase = dispatcherAddress.sub(0x53b24);
    const firstInsn = Instruction.parse(dispatcherAddress);
    if (firstInsn.mnemonic !== 'stp') {
        throw new Error('unexpected dispatcher prologue at ' + dispatcherAddress + ': ' + firstInsn);
    }

    openOutput();
    const contextOut = Memory.alloc(Process.pointerSize);
    contextOut.writePointer(NULL);
    const wrapperAddress = vcMakeHandle(dispatcherAddress, contextOut);
    vmContext = contextOut.readPointer();
    if (wrapperAddress.isNull() || vmContext.isNull()) {
        throw new Error('AndroidPrybar vc_make_handle() failed');
    }
    wrapperFunction = new NativeFunction(wrapperAddress, 'uint64',
        ['pointer', 'pointer', 'pointer', 'pointer']);
    installVmHooks();

    const callSite = nativeFn.add(0x6c);
    skipCallCallback = new NativeCallback(function () {
        return uint64(0);
    }, 'uint64', ['pointer', 'pointer', 'pointer', 'pointer']);
    callSiteHook = Interceptor.attach(callSite, {
        onEnter: function () {
            const tid = Process.getCurrentThreadId();
            if ((traceDepth.get(tid) || 0) !== 0) return;
            traceDepth.set(tid, 1);
            status('tracing onCreate callsite=' + callSite +
                ' dispatcher=' + dispatcherAddress + ' tid=' + tid);
            try {
                wrapperFunction(this.context.x0, this.context.x1,
                    this.context.x2, this.context.x3);
                // Let the original BLR execute, but redirect it to a one-shot
                // return callback so the dispatcher is not executed twice.
                this.context.x28 = skipCallCallback;
            } finally {
                traceDepth.delete(tid);
                if (pending.length !== 0 && output !== null) {
                    output.write(pending.join('\n') + '\n');
                    output.flush();
                    pending = [];
                }
            }
        },
    });
    installed = true;

    status('installed for ' + CONFIG.className + '-\u003e' +
        CONFIG.methodName + CONFIG.signature);
    status('native trampoline=' + nativeFn +
        ' callsite=' + callSite +
        ' closure=' + closureIdentity +
        ' dispatcher=' + dispatcherAddress +
        ' trace=' + CONFIG.tracePath);
}

function installRegisterNativesHook() {
    if (registerHook !== null || !Java.available) return;
    try {
        Java.performNow(function () {
            const env = Java.vm.getEnv();
            const table = env.handle.readPointer();
            const registerNatives = table.add(215 * Process.pointerSize).readPointer();
            registerHook = Interceptor.attach(registerNatives, {
                onEnter: function (args) {
                    if (installed) return;
                    const className = classNameFor(args[1]);
                    if (className !== CONFIG.className) return;

                    const methods = args[2];
                    const count = args[3].toInt32();
                    for (let i = 0; i < count; i++) {
                        const item = methods.add(i * Process.pointerSize * 3);
                        const name = item.readPointer().readCString();
                        const sig = item.add(Process.pointerSize).readPointer().readCString();
                        if (name !== CONFIG.methodName || sig !== CONFIG.signature) continue;
                        const fn = item.add(Process.pointerSize * 2).readPointer();
                        try {
                            installDispatcherTrace(fn);
                        } catch (e) {
                            status('install failed: ' + e.stack);
                        }
                        break;
                    }
                },
            });
            status('hooked JNIEnv->RegisterNatives at ' + registerNatives);
        });
    } catch (_) {}
}

setInterval(installRegisterNativesHook, 20);
setImmediate(function () {
    status('agent started pid=' + Process.id);
    installRegisterNativesHook();
});
