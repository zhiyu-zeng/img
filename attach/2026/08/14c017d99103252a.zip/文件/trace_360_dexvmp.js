'use strict';

/*
 * 360 DexVMP LLVM/SSA IR tracer for this libjiagu_64.so build.
 *
 * Static offsets recovered from libjiagu_a64.so:
 *   +0x14688  packed method/argument decoder
 *   +0x0D6F8  IR executor
 *   +0x0D7D0  exact virtual dispatch fetch
 *   +0x0D90C  common executor exit
 *
 * The protected Dex code is lowered to an LLVM-like IR before execution. This
 * tracer therefore prints the closest recoverable representation (IR opcode,
 * virtual word-PC and raw operands), not a byte-for-byte copy of the old Dex
 * code_item. ret/br/switch/call/load/store/etc. can be mapped back to Smali;
 * phi/alloca/gep are lowering artifacts and have no one-to-one Smali opcode.
 */

const CONFIG = {
    targetModules: ['libjiagu_64.so', 'libjiagu.so'],
    libtracePath: '/data/local/tmp/libtrace.so',
    outputPath: '/data/data/com.flass.myapplication/files/360_dexvmp_ir_trace.log',

    executeOffset: 0x0d6f8,
    dispatchOffset: 0x0d7d0,
    exitOffset: 0x0d90c,

    // Signature guards for this exact build. Refuse to patch a different SO.
    executeInsn: 0xd104c3ff,   // sub sp, sp, #0x130
    dispatchInsn: 0xb8765b80,  // ldr w0, [x28, w22, uxtw #2]

    dumpWords: 16,
    flushEvery: 64,
    maxLines: 300000,

    // Optional runtime filters. Keep null/0 to trace all outer VMP calls.
    onlyCodePointer: null, // Example: '0x7abc123400'
    onlyWordCount: 0,
    maxOuterCalls: 0,

    // AndroidPrybar cannot nest its VM. Nested protected calls are routed to
    // the original native executor, preventing a deadlock.
    bypassNestedPrybar: true,
};

const OFF = {
    X0: 0,
    X1: 1,
    X2: 2,
    X3: 3,
    X4: 4,
    X5: 5,
    X19: 19,
    X20: 20,
    X21: 21,
    X22: 22,
    X28: 28,
};

const VC_HOOK_CODE = 1 << 2;

const PRIMARY = {
    2: 'cast',
    3: 'binop',
    10: 'ret',
    11: 'br',
    12: 'switch',
    16: 'phi',
    19: 'alloca',
    20: 'load',
    28: 'icmp',
    29: 'select',
    34: 'call',
    43: 'getelementptr',
    44: 'store',
};

const CAST = [
    'trunc', 'zext', 'sext', 'fptoui', 'fptosi', 'uitofp', 'sitofp',
    'fptrunc', 'fpext', 'ptrtoint', 'inttoptr', 'bitcast', 'addrspacecast',
];

const BINOP = [
    'add', 'sub', 'mul', 'udiv', 'sdiv', 'urem', 'srem',
    'shl', 'lshr', 'ashr', 'and', 'or', 'xor',
];

const ICMP = {
    32: 'eq',
    33: 'ne',
    34: 'ugt',
    35: 'uge',
    36: 'ult',
    37: 'ule',
    38: 'sgt',
    39: 'sge',
    40: 'slt',
    41: 'sle',
};

let targetModule = null;
let traceModule = null;
let executeAddress = null;
let dispatchAddress = null;
let exitAddress = null;
let vmContext = NULL;
let wrapperAddress = NULL;
let originalAddress = NULL;
let wrapperFunction = null;
let originalFunction = null;
let replacementCallback = null;
let codeCallback = null;
let vcMakeHandle = null;
let vcHookAdd = null;
let vcHookDel = null;
let vcRegRead = null;
let vcFree = null;
let installed = false;
let stopped = false;

const hookHandles = [];
const activeMethods = new Map();
const nativeDepth = new Map();
const regScratch = new Map();
let nextMethodId = 1;
let outerCallCount = 0;
let emittedLines = 0;
let droppedLines = 0;
let pendingLines = [];
let outputFile = null;

function logStatus(message) {
    console.log('[360-dexvmp] ' + message);
}

function openOutput() {
    try {
        outputFile = new File(CONFIG.outputPath, 'w');
        outputFile.write('# 360 DexVMP LLVM/SSA IR trace\n');
        outputFile.write('# dispatcher: libjiagu+0x' + CONFIG.dispatchOffset.toString(16) + '\n');
        outputFile.flush();
    } catch (e) {
        outputFile = null;
        logStatus('cannot open output file: ' + e);
    }
}

function flushOutput() {
    if (pendingLines.length === 0) return;
    const text = pendingLines.join('\n') + '\n';
    pendingLines = [];
    if (outputFile !== null) {
        try {
            outputFile.write(text);
            outputFile.flush();
            return;
        } catch (e) {
            logStatus('file write failed, falling back to console: ' + e);
            outputFile = null;
        }
    }
    console.log(text.trimEnd());
}

function emit(line) {
    if (emittedLines >= CONFIG.maxLines) {
        droppedLines++;
        return;
    }
    emittedLines++;
    pendingLines.push(line);
    if (pendingLines.length >= CONFIG.flushEvery) flushOutput();
}

function threadId() {
    return Process.getCurrentThreadId();
}

function scratchFor(reg) {
    let slot = regScratch.get(reg);
    if (slot === undefined) {
        slot = Memory.alloc(8);
        regScratch.set(reg, slot);
    }
    return slot;
}

function readX(ctx, reg) {
    const slot = scratchFor(reg);
    slot.writeU64(uint64(0));
    const err = vcRegRead(ctx, reg, slot);
    if (err !== 0) throw new Error('vc_reg_read(X' + reg + ') failed: ' + err);
    return slot.readPointer();
}

function readW(ctx, reg) {
    const slot = scratchFor(reg);
    slot.writeU64(uint64(0));
    const err = vcRegRead(ctx, reg, slot);
    if (err !== 0) throw new Error('vc_reg_read(W' + reg + ') failed: ' + err);
    return slot.readU32();
}

function safeReadWords(code, pc, totalWords, count) {
    const result = [];
    if (code.isNull()) return result;
    let available = count;
    if (totalWords > 0) {
        if (pc >= totalWords) return result;
        available = Math.min(available, totalWords - pc);
    }
    for (let i = 0; i < available; i++) {
        try {
            result.push(code.add((pc + i) * 4).readU32());
        } catch (_) {
            break;
        }
    }
    return result;
}

function classify(words) {
    if (words.length === 0) return 'unreadable';
    const opcode = words[0];
    let name = PRIMARY[opcode] || ('unknown_' + opcode);
    if (opcode === 2 && words.length > 1) {
        name += '.' + (CAST[words[1]] || ('cast_' + words[1]));
    } else if (opcode === 3 && words.length > 1) {
        name += '.' + (BINOP[words[1]] || ('bin_' + words[1]));
    } else if (opcode === 28 && words.length > 5) {
        name += '.' + (ICMP[words[5]] || ('pred_' + words[5]));
    }
    return name;
}

function rawWords(words) {
    return words.map(function (v) {
        return '0x' + ('00000000' + v.toString(16)).slice(-8);
    }).join(' ');
}

function matchesConfiguredFilter(code, wordCount) {
    if (CONFIG.onlyCodePointer !== null &&
        code.toString().toLowerCase() !== CONFIG.onlyCodePointer.toLowerCase()) {
        return false;
    }
    if (CONFIG.onlyWordCount !== 0 && wordCount !== CONFIG.onlyWordCount) {
        return false;
    }
    if (CONFIG.maxOuterCalls !== 0 && outerCallCount >= CONFIG.maxOuterCalls) {
        return false;
    }
    return true;
}

function onVmCode(ctx, address) {
    try {
        const tid = threadId();

        if (address.equals(executeAddress)) {
            const result = readX(ctx, OFF.X0);
            const values = readX(ctx, OFF.X1);
            const pool = readX(ctx, OFF.X2);
            const wordCount = readW(ctx, OFF.X3);
            const code = readX(ctx, OFF.X4);
            const branches = readX(ctx, OFF.X5);
            const state = {
                id: nextMethodId++,
                result: result,
                values: values,
                pool: pool,
                wordCount: wordCount,
                code: code,
                branches: branches,
                dispatches: 0,
                lastPc: -1,
            };
            activeMethods.set(tid, state);
            emit('[ENTER] tid=' + tid +
                ' method=' + state.id +
                ' code=' + code +
                ' words=' + wordCount +
                ' values=' + values +
                ' pool=' + pool +
                ' branches=' + branches);
            return;
        }

        if (address.equals(dispatchAddress)) {
            let state = activeMethods.get(tid);
            const pc = readW(ctx, OFF.X22);
            const code = readX(ctx, OFF.X28);
            const values = readX(ctx, OFF.X19);
            const pool = readX(ctx, OFF.X21);

            if (state === undefined) {
                state = {
                    id: nextMethodId++,
                    result: NULL,
                    values: values,
                    pool: pool,
                    wordCount: 0,
                    code: code,
                    branches: NULL,
                    dispatches: 0,
                    lastPc: -1,
                };
                activeMethods.set(tid, state);
                emit('[ATTACH-MID] tid=' + tid + ' method=' + state.id + ' code=' + code);
            }

            state.code = code;
            state.values = values;
            state.pool = pool;
            state.dispatches++;

            const words = safeReadWords(code, pc, state.wordCount, CONFIG.dumpWords);
            const name = classify(words);
            const flow = state.lastPc >= 0 ? (' prev_pc=' + state.lastPc) : '';
            emit('[IR] tid=' + tid +
                ' method=' + state.id +
                ' seq=' + state.dispatches +
                ' pc=' + pc +
                flow +
                ' op=' + name +
                ' raw=' + rawWords(words));
            state.lastPc = pc;
            return;
        }

        if (address.equals(exitAddress)) {
            const state = activeMethods.get(tid);
            const status = readW(ctx, OFF.X20);
            if (state !== undefined) {
                emit('[EXIT] tid=' + tid +
                    ' method=' + state.id +
                    ' dispatches=' + state.dispatches +
                    ' status=' + status);
                activeMethods.delete(tid);
            } else {
                emit('[EXIT] tid=' + tid + ' method=? status=' + status);
            }
        }
    } catch (e) {
        emit('[ERROR] code callback: ' + e.stack);
    }
}

function addCodeHook(address) {
    const handle = Memory.alloc(Process.pointerSize);
    handle.writePointer(NULL);
    const err = vcHookAdd(
        vmContext,
        handle,
        VC_HOOK_CODE,
        codeCallback,
        NULL,
        address,
        address.add(4)
    );
    if (err !== 0) throw new Error('vc_hook_add(' + address + ') failed: ' + err);
    hookHandles.push(handle.readPointer());
}

function resolveTraceApi() {
    traceModule = Module.load(CONFIG.libtracePath);
    const exp = function (name) {
        const p = traceModule.findExportByName(name);
        if (p === null) throw new Error('missing libtrace export: ' + name);
        return p;
    };

    vcMakeHandle = new NativeFunction(
        exp('_Z14vc_make_handlePvPP10vm_context'),
        'pointer', ['pointer', 'pointer']
    );
    vcHookAdd = new NativeFunction(
        exp('_Z11vc_hook_addP10vm_contextPmiPvS2_mm'),
        'int', ['pointer', 'pointer', 'int', 'pointer', 'pointer', 'pointer', 'pointer']
    );
    vcHookDel = new NativeFunction(
        exp('_Z11vc_hook_delP10vm_contextm'),
        'int', ['pointer', 'pointer']
    );
    vcRegRead = new NativeFunction(
        exp('_Z11vc_reg_readP10vm_context6vc_regPv'),
        'int', ['pointer', 'int', 'pointer']
    );
    vcFree = new NativeFunction(
        exp('_Z7vc_freeP10vm_context'),
        'void', ['pointer']
    );
}

function installFor(module) {
    targetModule = module;
    executeAddress = module.base.add(CONFIG.executeOffset);
    dispatchAddress = module.base.add(CONFIG.dispatchOffset);
    exitAddress = module.base.add(CONFIG.exitOffset);

    const executeWord = executeAddress.readU32();
    const dispatchWord = dispatchAddress.readU32();
    if (executeWord !== CONFIG.executeInsn || dispatchWord !== CONFIG.dispatchInsn) {
        throw new Error(
            'libjiagu signature mismatch: execute=0x' + executeWord.toString(16) +
            ', dispatch=0x' + dispatchWord.toString(16)
        );
    }

    resolveTraceApi();
    openOutput();

    const contextOut = Memory.alloc(Process.pointerSize);
    contextOut.writePointer(NULL);
    wrapperAddress = vcMakeHandle(executeAddress, contextOut);
    vmContext = contextOut.readPointer();
    if (wrapperAddress.isNull() || vmContext.isNull()) {
        throw new Error('vc_make_handle failed');
    }

    codeCallback = new NativeCallback(
        function (ctx, address, size, userData) {
            onVmCode(ctx, address);
        },
        'void', ['pointer', 'pointer', 'uint32', 'pointer']
    );

    addCodeHook(executeAddress);
    addCodeHook(dispatchAddress);
    addCodeHook(exitAddress);

    const signature = ['pointer', 'pointer', 'pointer', 'uint32', 'pointer', 'pointer'];
    wrapperFunction = new NativeFunction(wrapperAddress, 'int', signature);

    replacementCallback = new NativeCallback(
        function (a0, a1, a2, a3, a4, a5) {
            const tid = threadId();
            const depth = nativeDepth.get(tid) || 0;

            if (depth > 0 && CONFIG.bypassNestedPrybar) {
                return originalFunction(a0, a1, a2, a3, a4, a5);
            }
            if (!matchesConfiguredFilter(a4, a3)) {
                return originalFunction(a0, a1, a2, a3, a4, a5);
            }

            outerCallCount++;
            nativeDepth.set(tid, depth + 1);
            try {
                return wrapperFunction(a0, a1, a2, a3, a4, a5);
            } finally {
                const next = (nativeDepth.get(tid) || 1) - 1;
                if (next <= 0) nativeDepth.delete(tid);
                else nativeDepth.set(tid, next);
            }
        },
        'int', signature
    );

    if (typeof Interceptor.replaceFast !== 'function') {
        throw new Error('Frida build has no Interceptor.replaceFast; nested VM-safe routing is unavailable');
    }
    originalAddress = Interceptor.replaceFast(executeAddress, replacementCallback);
    originalFunction = new NativeFunction(originalAddress, 'int', signature);
    Interceptor.flush();

    installed = true;
    logStatus('installed on ' + module.name + ' @ ' + module.base);
    logStatus('execute=' + executeAddress +
        ' dispatch=' + dispatchAddress +
        ' wrapper=' + wrapperAddress);
    logStatus('IR output: ' + CONFIG.outputPath);
}

function findTargetModule() {
    for (let i = 0; i < CONFIG.targetModules.length; i++) {
        const m = Process.findModuleByName(CONFIG.targetModules[i]);
        if (m !== null) return m;
    }
    return null;
}

function tryInstall() {
    if (installed || stopped) return;
    const module = findTargetModule();
    if (module === null) return;
    try {
        installFor(module);
    } catch (e) {
        stopped = true;
        logStatus('install failed: ' + e.stack);
        flushOutput();
    }
}

function stopTracer() {
    if (stopped) return;
    stopped = true;
    try {
        if (installed && executeAddress !== null) {
            Interceptor.revert(executeAddress);
            Interceptor.flush();
        }
    } catch (e) {
        logStatus('revert failed: ' + e);
    }
    try {
        if (!vmContext.isNull() && vcHookDel !== null) {
            hookHandles.forEach(function (h) {
                try { vcHookDel(vmContext, h); } catch (_) {}
            });
        }
        if (!vmContext.isNull() && vcFree !== null) vcFree(vmContext);
    } catch (e) {
        logStatus('Prybar cleanup failed: ' + e);
    }
    flushOutput();
    if (outputFile !== null) {
        try { outputFile.close(); } catch (_) {}
        outputFile = null;
    }
    logStatus('stopped; emitted=' + emittedLines + ' dropped=' + droppedLines);
}

rpc.exports = {
    status: function () {
        return {
            installed: installed,
            stopped: stopped,
            module: targetModule === null ? null : targetModule.name,
            base: targetModule === null ? null : targetModule.base.toString(),
            execute: executeAddress === null ? null : executeAddress.toString(),
            dispatch: dispatchAddress === null ? null : dispatchAddress.toString(),
            outerCalls: outerCallCount,
            emittedLines: emittedLines,
            droppedLines: droppedLines,
            output: CONFIG.outputPath,
        };
    },
    flush: function () {
        flushOutput();
        return true;
    },
    stop: function () {
        stopTracer();
        return true;
    },
};

setInterval(function () {
    tryInstall();
    flushOutput();
}, 500);

setImmediate(function () {
    logStatus('agent started in pid=' + Process.id + '; waiting for libjiagu');
    tryInstall();
});

