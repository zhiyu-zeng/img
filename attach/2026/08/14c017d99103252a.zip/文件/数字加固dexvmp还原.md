数字加固dexvmp的复现

开始标语：3年前刚刚了解安卓逆向的时候就遇到了dexvmp加固的典型例子，就像一个刚刚接触游戏的新手没出新手村就遇到了满级boss的无力感，今天小编带大家研究下数字加固的dexvmp还原流程,讲的不对的地方还请大佬指正

---

## 1. 什么是 DexVMP，什么是 trace

### 1.1 普通 Dex 指令与 DexVMP

普通 Android 方法的 `CodeItem.insns[]` 是 Dalvik 16-bit code units。反汇编器根据低 8 位 opcode、指令格式和 DEX 中的 string/type/field/method/proto 表，将字节转换为 Smali。这里补充下数字加固和其他厂商的加固都是非标准的opcode，详细项目可以参考下开源的nmmp

DexVMP 会改变这条路径。被保护方法进入壳或私有解释器，由解释器读取加密指令、解出虚拟 opcode 和操作数，再调用 JNI 或内部 handler 完成原方法行为。壳 Dex 中常见的只是一条 `native` 声明，甚至找不到原类的方法体。

### 1.2 本文所说的 trace

trace 是“按时间顺序记录程序真实执行状态”的过程。根据记录的对象和内容不同，可以分为：

| trace 类型 | 能看到什么 | 能否直接恢复原 Smali |
| --- | --- | --- |
| Java/JNI trace | 类、方法、参数、返回值 | 不能，只能证明行为 |
| Native block trace | 执行过的基本块和寄存器 | 不能，但可定位 dispatcher/handler |
| Native instruction trace | 每条 ARM64 指令和寄存器变化 | 可定位解码算法，但信息量很大 |
| VM opcode trace | VM PC、虚拟 opcode、handler | 缺少完整操作数时仍不能 |
| CodeItem trace | CodeItem header、每个 PC、全部 code units、引用索引 | 完整覆盖后可以机械恢复 |

本文先使用 AndroidPrybar 进行 ARM64 指令级 trace，找出 dispatcher、opcode decoder、operand accessor 和退出点；然后改用 Frida `Interceptor` 在原始执行上记录 CodeItem 级证据。

这里要特别强调：AndroidPrybar 的 `vc_make_handle` 会把 native 函数放进 Unicorn 环境执行。它很适合侦察控制流，但最终证明原始 CodeItem 时，本文没有把 Unicorn replay 当作唯一依据，而是回到 App 的原始 dispatcher 执行上采集。

---

## 2. 实验环境与工具

### 2.1 主机与设备

| 项目 | 本次环境 |
| --- | --- |
| 主机 | Windows，系统构建号 `10.0.26200` |
| 设备 | 安卓12 |
| 目标架构 | ARM64 / `arm64-v8a` |
| Root | 需要，用于 frida-server、App 私有目录和日志拉取 |
| Frida | `16.1.5`，主机与设备端版本必须一致 |
| ADB | `1.0.41`，platform-tools `36.0.0-13206524` |
| Node.js | `24.11.1` |
| Python | `3.11` |
| Java | `21.0.2` |
| MT 管理器 | 查看加固状态、Dex 文件和 360 加固的 SO 文件 |
| IDA Pro | 9.2                                                          |
| SoFixer | `SoFixer-Windows-64.exe` |

---

## 3. 整体恢复链路

```text
APK/壳 Dex
  | 确认 StubApp、目标 Activity、加固资产（asstes目录下出现libjiagu.so）
  v
libjiagu_a64.so
  | 卡在私有 linker 完成装载、目标 JNI_OnLoad 尚未执行的时刻（这里有差异化，老版本会在so的外层套个魔改upx）
  v
内存 linker.so + private soinfo
  | 合成 ELF header，回填 private dynamic table，SoFixer 修复
  v
linker_fixed.so / IDA
  | RegisterNatives -> trampoline -> dispatcher
  | method record -> CodeItem
  | opcode decoder -> dispatch tree -> handlers -> operand accessors
  v
AndroidPrybar ARM64 trace
  | 确认真实执行顺序与稳定 hook RVA
  v
Frida 原始执行 trace
  | CodeItem header + VM PC + opcode + 全部 code units + DEX/JNI 符号
  v
重建器
  | 连续覆盖验证、CodeItem/DebugInfo 输出、SHA-256
  v
可验证 Smali
```

内存 dump 和 trace 的作用不同：dump linker 是为了静态分析 VM；trace 是为了观察 VM 在每个 PC 解出的 opcode 和操作数。最终 Smali 的 opcode 证据来自 trace，不是根据 linker 伪代码手写，也不是 runtime Dex dump。

---

## 样本

> - ![图01 Manifest 与 StubApp](forum_images/01_manifest_stubapp.png)

本文样本制作于 2026 年 5 月。后文结论只针对这份样本及其对应壳版本；其他版本的抽取策略、结构和 RVA 需要重新确认。

![图02 壳 Dex 中没有原始 MainActivity 方法体](forum_images/02_shell_dex_no_mainactivity.png)

---

## 5. 第二步：在正确时机 dump 私有 linker.so

本文先处理运行时私有加载的 `linker.so`。外层 `libjiagu` 经过变形压缩，修复后放入 IDA 可以看到私有加载 linker 的调用链；后续 dispatcher、decoder 和 handler 的静态 RVA 都来自这份运行时 linker，因此必须先把 dump 时机定准。

### 5.1 在 IDA 中找精确装载窗口

```asm
0xA760  BL   sub_8B38        ; 私有加载，返回 private soinfo
0xA764  ADRP X22, #0x291000
0xA768  STR  X0, [X22,#0xB08]
0xA76C  CBZ  X0, loc_A7C4
0xA770  BL   sub_8C70        ; patch makekey
0xA774  LDR  X0, [X22,#0xB08]
0xA778  BL   sub_8DB4        ; patch __armeabi_unwind_02
0xA77C  BL   sub_9708        ; patch getSoName
0xA780  BL   sub_9AAC        ; patch getSoName2
0xA784  LDR  X0, [X22,#0xB08]
0xA788  BL   sub_8FA0        ; patch interpreter wrapper slots
0xA78C  LDR  X0, [X22,#0xB08] ; 最佳 dump 点
0xA798  BL   sub_537C        ; 解析目标 JNI_OnLoad
0xA7AC  BLR  X8              ; 调用目标 JNI_OnLoad
```

精确时机：

```text
libjiagu+0xA788 已返回
libjiagu+0xA78C 即将读取 private soinfo
libjiagu+0xA798 尚未解析目标 JNI_OnLoad
libjiagu+0xA7AC 尚未调用目标 JNI_OnLoad
```

### 5.2 dump 脚本配置

```javascript
const CONFIG = {
    jiaguNames: ['libjiagu_a64.so'],
    manualLoadFunctionOffset: 0x5240,
    exactDumpOffset: 0xA78C,
    handleGlobalOffset: 0x291B08,

    soinfoLoadStartOffset: 0xE0,
    soinfoPhdrOffset: 0xE8,
    soinfoLoadSizeOffset: 0xF0,
    soinfoPhnumOffset: 0xF8,
    soinfoDynamicOffset: 0x100,
    soinfoLoadBiasOffset: 0x1B0,
    soinfoNameOffset: 0x58,
};
```

`handleGlobalOffset=0x291B08` 正是 `ADRP X22,#0x291000` 与 `[X22,#0xB08]` 的组合。

### 5.3 为什么第一次 handle 为 null

早期输出：

```text
[360-linker-dump] private linker returned soinfo=... (captured; waiting for exact dump point)
[360-linker-dump][!] exact point reached but the private soinfo handle is null
```

hook 地址本身是 `LDR X0,[X22,#imm]`。Frida 进入 `onEnter` 时，被 hook 指令尚未执行，所以不能直接读 X0。应在安装 hook 前解码原指令，回调中手工读取 `X22+imm`：

```javascript
const decodedHandleOffset = decodeHandleOffsetAtDumpPoint(hookAddress);

Interceptor.attach(hookAddress, {
    onEnter: function () {
        const handleAddress = this.context.x22.add(decodedHandleOffset);
        const handle = handleAddress.readPointer();
        dumpPrivateSoinfo(handle, 'libjiagu pre-target-JNI_OnLoad');
    }
});
```

从固定全局 `libjiagu+0x291B08` 读取，以及使用 `libjiagu+0x5240` 私有加载函数的已缓存返回值。

### 5.4 没有 ELF header 时如何恢复

从 private `soinfo` 读取：

```text
load_start
load_size
load_bias
phdr
phnum
dynamic
name
```

如果找不到 `7F 45 4C 46`，执行：

1. 根据 `phdr/phnum` 解析 `Elf64_Phdr[]`。
2. 计算所有 `PT_LOAD` 的 image span。
3. 合成 `Elf64_Ehdr`，架构 `EM_AARCH64`、类型 `ET_DYN`。
4. 把 private `soinfo+0x100` 保存的 `Elf64_Dyn[]` 覆盖回 `PT_DYNAMIC`。
5. 检查 `DT_STRTAB`、`DT_SYMTAB`、`DT_STRSZ`、`DT_SYMENT` 与 hash table。
6. 按页写出映射，不可读页才填零并计数。

本次元数据：

```json
{
  "reason": "libjiagu pre-target-JNI_OnLoad",
  "jiaguTiming": "after libjiagu+0xA788 returns, before target JNI_OnLoad lookup/call",
  "targetName": "linker.so",
  "loadStart": "0x6c011f0000",
  "loadBias": "0x6c011f0000",
  "phnum": 6,
  "syntheticHeader": true,
  "dumpSize": 1687552,
  "readableBytes": 1687552,
  "zeroFilledBytes": 0,
  "dynamic": {
    "hasStrtab": true,
    "hasSymtab": true,
    "hasStrsz": true,
    "hasSyment": true,
    "hasHash": true,
    "symbolCount": 676
  }
}
```

`zeroFilledBytes=0` 说明预期映射全部可读；`syntheticHeader=true` 说明 ELF 头是根据 private soinfo 恢复的。

```javascript
writeMetadata(output.path, metadata);
```

脚本随后创建 `<dump.so>.json`：

```javascript
function writeMetadata(path, metadata) {
    const file = new File(path + '.json', 'wb');
    file.write(JSON.stringify(metadata, null, 2));
    file.flush();
    file.close();
}
```

各字段来自下面这些运行时数据：

| JSON 字段 | 来源 |
| --- | --- |
| `reason` | 精确 hook 点调用 `dumpPrivateSoinfo()` 时传入的原因字符串 |
| `jiaguTiming` | 根据 IDA 中 `0xA788..0xA7AC` 调用顺序写入的时机说明 |
| `targetName/loadStart/loadBias/phnum` | Frida 在目标进程中读取 private `soinfo` 对应字段 |
| `syntheticHeader` | 脚本是否在映射中找到 ELF magic；未找到时根据 `phdr` 合成 header |
| `dumpSize` | private `soinfo.load_size` 与 ELF/PT_LOAD 范围计算结果 |
| `readableBytes/zeroFilledBytes` | 脚本逐页读取映射时实际成功读取和补零的字节数 |
| `hasStrtab/hasSymtab/...` | 解析 private `Elf64_Dyn[]` 后是否找到相应 `DT_*` 项 |
| `symbolCount` | 从 SysV `DT_HASH` 表的 `nchain` 字段读取，本次为 676 |

### 5.5 SoFixer 修复和验证

```powershell
.\SoFixer-Windows-64.exe -s .\linker\linker.so_pid32599_0x6c011f0000.so -o .\linker\linker_fixed.so

readelf -h .\linker\linker_fixed.so
readelf -l .\linker\linker_fixed.so
readelf -d .\linker\linker_fixed.so
readelf -sW .\linker\linker_fixed.so
```

关键结果：

```text
Class:   ELF64
Type:    DYN
Machine: AArch64
phnum:   6

DT_HASH   = 0x190
DT_STRTAB = 0x53B0
DT_SYMTAB = 0x1450
DT_STRSZ  = 12865
DT_SYMENT = 24

Symbol table '.dynsym' contains 676 entries
```

可见符号包括 `interpreter_wrap_int64_t`、`interpreter_wrap_float`、`interpreter_wrap_double`、`JNI_OnLoad`、`getSoName2`、`makekey`。

SoFixer 输出的 `.rela.plt` section 类型/`sh_entsize` 会让 MinGW `readelf` 给出 warning，但 dynamic table、dynsym 和本文使用的 LOAD 段可用。也是把linker so还原了接下来就可以进行下一步的分析了

> ![图03 SoFixer 后的动态表和符号](forum_images/03_sofixer_symbols_exports.png)
>

### 5.6 完整 `dump_linker.js`

```javascript
'use strict';
const CONFIG = {
    outputDir: null,
    jiaguNames: [
        'libjiagu_a64.so'
    ],
    manualLoadFunctionOffset: 0x5240,
    exactDumpOffset: 0xA78C,
    handleGlobalOffset: 0x291B08,
    soinfoLoadStartOffset: 0xE0,
    soinfoPhdrOffset: 0xE8,
    soinfoLoadSizeOffset: 0xF0,
    soinfoPhnumOffset: 0xF8,
    soinfoDynamicOffset: 0x100,
    soinfoLoadBiasOffset: 0x1B0,
    soinfoNameOffset: 0x58,

    maxDumpSize: 512 * 1024 * 1024,
    dumpIfAlreadyLoaded: true
};

const ELF_MAGIC = 0x464c457f;
const PT_LOAD = 1;
const PT_DYNAMIC = 2;

let installed = false;
let dumping = false;
let dumped = false;
let lastManualHandle = null;
let installTimer = null;

function log(message) {
    console.log('[360-linker-dump] ' + message);
}

function warn(message) {
    console.log('[360-linker-dump][!] ' + message);
}

function u64ToNumber(value, what) {
    const n = Number(value.toString());
    if (!Number.isSafeInteger(n) || n < 0) {
        throw new Error((what || 'u64') + ' is outside the safe JS integer range: ' + value);
    }
    return n;
}

function pointerDelta(high, low) {
    return Number(high.sub(low).toString());
}

function alignDown(value, alignment) {
    return Math.floor(value / alignment) * alignment;
}

function alignUp(value, alignment) {
    return Math.ceil(value / alignment) * alignment;
}

function isElf(address) {
    try {
        return !address.isNull() && address.readU32() === ELF_MAGIC;
    } catch (_) {
        return false;
    }
}

function readCStringSafe(address, maxLength) {
    try {
        if (address.isNull()) return '';
        return address.readCString(maxLength || 256) || '';
    } catch (_) {
        return '';
    }
}

function readInlineAscii(address, maxLength) {
    let result = '';
    try {
        for (let i = 0; i < maxLength; i++) {
            const value = address.add(i).readU8();
            if (value === 0) break;
            if (value < 0x20 || value > 0x7E) break;
            result += String.fromCharCode(value);
        }
    } catch (_) {
    }
    return result;
}

function sanitizeName(name) {
    const clean = (name || 'linker').replace(/[^A-Za-z0-9._-]/g, '_');
    return clean.length > 0 ? clean : 'linker';
}

function getProcessName() {
    try {
        const file = new File('/proc/self/cmdline', 'rb');
        const data = file.readBytes(512);
        file.close();
        const bytes = new Uint8Array(data);
        let result = '';
        for (let i = 0; i < bytes.length && bytes[i] !== 0; i++) {
            result += String.fromCharCode(bytes[i]);
        }
        return result;
    } catch (e) {
        warn('cannot read /proc/self/cmdline: ' + e);
        return '';
    }
}

function packageNameFromProcess() {
    const processName = getProcessName();
    const colon = processName.indexOf(':');
    return colon >= 0 ? processName.substring(0, colon) : processName;
}

function outputDirectories() {
    if (CONFIG.outputDir !== null) return [CONFIG.outputDir];

    const pkg = packageNameFromProcess();
    if (pkg.length === 0) return [];
    return [
        '/data/user/0/' + pkg + '/files',
        '/data/data/' + pkg + '/files',
        '/data/user/0/' + pkg + '/cache',
        '/data/data/' + pkg + '/cache'
    ];
}

function openOutputFile(fileName) {
    const dirs = outputDirectories();
    let lastError = null;
    for (let i = 0; i < dirs.length; i++) {
        const path = dirs[i] + '/' + fileName;
        try {
            return { file: new File(path, 'wb'), path: path };
        } catch (e) {
            lastError = e;
        }
    }
    throw new Error('cannot open output file; set CONFIG.outputDir. Last error: ' + lastError);
}

function findJiaguModule() {
    const modules = Process.enumerateModules();
    for (let i = 0; i < modules.length; i++) {
        const module = modules[i];
        for (let j = 0; j < CONFIG.jiaguNames.length; j++) {
            if (module.name === CONFIG.jiaguNames[j]) return module;
        }
        if (module.name.indexOf('jiagu') !== -1 && module.name.endsWith('.so')) {
            return module;
        }
    }
    return null;
}

function checkManualLoaderSignature(module) {
    try {
        const p = module.base.add(CONFIG.manualLoadFunctionOffset);
        const expected = [
            0xD10103FF, // sub sp, sp, #0x40
            0xF9000BF6,
            0xA90253F5,
            0xA9037BF3
        ];
        for (let i = 0; i < expected.length; i++) {
            if (p.add(i * 4).readU32() !== expected[i]) return false;
        }
        return true;
    } catch (_) {
        return false;
    }
}

function locateExactDumpPoint(module) {
    const fixed = module.base.add(CONFIG.exactDumpOffset);
    try {
        if (((fixed.readU32() & 0xFFC003FF) >>> 0) === 0xF94002C0) {
            return fixed;
        }
    } catch (_) {
    }
    const scanSize = Math.min(module.size, 0x30000);
    const pattern = 'c0 86 45 f9 ?? ?? ?? 97 c0 86 45 f9 61 00 00 d0';
    const matches = Memory.scanSync(module.base, scanSize, pattern);
    if (matches.length === 1) {
        return matches[0].address.add(8);
    }
    if (matches.length > 1) {
        warn('dump-point signature is not unique; refusing an ambiguous hook');
    }
    return null;
}

function decodeHandleOffsetAtDumpPoint(hookAddress) {
    try {
        const instruction = hookAddress.readU32();
        if (((instruction & 0xFFC003FF) >>> 0) !== 0xF94002C0) return null;
        const imm12 = (instruction >>> 10) & 0xFFF;
        return imm12 * 8;
    } catch (_) {
        return null;
    }
}

function getSoinfo(handle) {
    if (handle === null || handle.isNull()) throw new Error('null private soinfo');

    const loadStart = handle.add(CONFIG.soinfoLoadStartOffset).readPointer();
    const phdr = handle.add(CONFIG.soinfoPhdrOffset).readPointer();
    const loadSize = u64ToNumber(
        handle.add(CONFIG.soinfoLoadSizeOffset).readU64(),
        'private soinfo load_size'
    );
    const phnum = u64ToNumber(
        handle.add(CONFIG.soinfoPhnumOffset).readU64(),
        'private soinfo phnum'
    );
    const dynamic = handle.add(CONFIG.soinfoDynamicOffset).readPointer();
    const loadBias = handle.add(CONFIG.soinfoLoadBiasOffset).readPointer();
    let name = readInlineAscii(handle.add(CONFIG.soinfoNameOffset), 128);
    if (name === '*.so' || name.length === 0) name = 'linker.so';

    if (loadStart.isNull()) throw new Error('private soinfo load_start is null');
    if (phdr.isNull()) throw new Error('private soinfo phdr is null');
    if (dynamic.isNull()) throw new Error('private soinfo dynamic is null');
    if (loadSize <= 0 || loadSize > CONFIG.maxDumpSize) {
        throw new Error('invalid private soinfo load_size: 0x' + loadSize.toString(16));
    }
    if (phnum <= 0 || phnum > 2048) {
        throw new Error('invalid private soinfo phnum: ' + phnum);
    }

    return {
        handle: handle,
        loadStart: loadStart,
        phdr: phdr,
        loadSize: loadSize,
        phnum: phnum,
        dynamic: dynamic,
        loadBias: loadBias,
        name: name
    };
}

function searchElfHeader(soinfo) {
    const candidates = [soinfo.loadStart, soinfo.loadBias];
    for (let i = 0; i < candidates.length; i++) {
        if (isElf(candidates[i])) return candidates[i];
    }

    const pageSize = Process.pageSize || 4096;
    const searchSize = Math.min(soinfo.loadSize, 32 * 1024 * 1024);
    for (let offset = 0; offset < searchSize; offset += pageSize) {
        const candidate = soinfo.loadStart.add(offset);
        if (isElf(candidate)) return candidate;
    }
    return null;
}

function parseProgramHeaders(phdr, phentsize, phnum) {
    if (phentsize < 56 || phnum === 0 || phnum > 2048) {
        throw new Error('invalid program header table: entsize=' + phentsize + ', num=' + phnum);
    }

    let minVaddr = Number.MAX_SAFE_INTEGER;
    let maxVaddr = 0;
    let dynamicVaddr = null;
    let dynamicMemsz = 0;
    let loadCount = 0;
    const pageSize = Process.pageSize || 4096;

    for (let i = 0; i < phnum; i++) {
        const ph = phdr.add(i * phentsize);
        const type = ph.readU32();
        const vaddr = u64ToNumber(ph.add(0x10).readU64(), 'p_vaddr');
        const memsz = u64ToNumber(ph.add(0x28).readU64(), 'p_memsz');
        if (type === PT_LOAD) {
            loadCount++;
            minVaddr = Math.min(minVaddr, alignDown(vaddr, pageSize));
            maxVaddr = Math.max(maxVaddr, alignUp(vaddr + memsz, pageSize));
        } else if (type === PT_DYNAMIC) {
            dynamicVaddr = vaddr;
            dynamicMemsz = memsz;
        }
    }

    if (loadCount === 0 || minVaddr === Number.MAX_SAFE_INTEGER || maxVaddr <= minVaddr) {
        throw new Error('no valid PT_LOAD span');
    }

    return {
        phentsize: phentsize,
        phnum: phnum,
        loadCount: loadCount,
        minVaddr: minVaddr,
        maxVaddr: maxVaddr,
        imageSpan: maxVaddr - minVaddr,
        dynamicVaddr: dynamicVaddr,
        dynamicMemsz: dynamicMemsz
    };
}

function parseElf64(elfBase) {
    if (!isElf(elfBase)) throw new Error('ELF magic is missing at ' + elfBase);
    if (elfBase.add(4).readU8() !== 2) throw new Error('target is not ELF64');
    if (elfBase.add(5).readU8() !== 1) throw new Error('target is not little-endian');

    const phoff = u64ToNumber(elfBase.add(0x20).readU64(), 'e_phoff');
    const phentsize = elfBase.add(0x36).readU16();
    const phnum = elfBase.add(0x38).readU16();
    const result = parseProgramHeaders(elfBase.add(phoff), phentsize, phnum);
    result.phoff = phoff;
    return result;
}

function pointerInside(address, start, size) {
    return address.compare(start) >= 0 && address.compare(start.add(size)) < 0;
}

function resolveDynamicPointer(rawPointer, soinfo) {
    if (pointerInside(rawPointer, soinfo.loadStart, soinfo.loadSize)) return rawPointer;
    const rawNumber = Number(rawPointer.toString());
    if (Number.isSafeInteger(rawNumber) && rawNumber >= 0 && rawNumber < soinfo.loadSize * 4) {
        return soinfo.loadBias.add(rawNumber);
    }
    return rawPointer;
}

function inspectDynamicTable(soinfo, elf) {
    const result = {
        hasStrtab: false,
        hasSymtab: false,
        hasStrsz: false,
        hasSyment: false,
        hasHash: false,
        hasGnuHash: false,
        symbolCount: null,
        entryCount: 0,
        byteSize: 0
    };
    if (elf.dynamicVaddr === null || elf.dynamicMemsz < 16) return result;

    const dynamicAddress = soinfo.dynamic;
    const maxEntries = Math.min(Math.floor(elf.dynamicMemsz / 16), 65536);
    let sysvHash = null;

    for (let i = 0; i < maxEntries; i++) {
        const entry = dynamicAddress.add(i * 16);
        const tag = u64ToNumber(entry.readU64(), 'dynamic tag');
        result.entryCount = i + 1;
        if (tag === 0) break;
        if (tag === 4) {
            result.hasHash = true;
            sysvHash = entry.add(8).readPointer();
        } else if (tag === 5) {
            result.hasStrtab = true;
        } else if (tag === 6) {
            result.hasSymtab = true;
        } else if (tag === 10) {
            result.hasStrsz = true;
        } else if (tag === 11) {
            result.hasSyment = true;
        } else if (tag === 0x6ffffef5) {
            result.hasGnuHash = true;
        }
    }
    result.byteSize = result.entryCount * 16;

    if (sysvHash !== null) {
        try {
            const hashAddress = resolveDynamicPointer(sysvHash, soinfo);
            if (pointerInside(hashAddress, soinfo.loadStart, soinfo.loadSize)) {
                result.symbolCount = hashAddress.add(4).readU32();
            }
        } catch (_) {
        }
    }
    return result;
}

function buildDynamicOverlay(soinfo, elf, dynamic) {
    if (dynamic.byteSize < 16) throw new Error('private dynamic table has no DT_NULL terminator');
    const offset = elf.dynamicVaddr - elf.minVaddr;
    if (offset < 0 || offset + dynamic.byteSize > soinfo.loadSize) {
        throw new Error('private dynamic table does not fit the PT_LOAD image span');
    }
    const data = soinfo.dynamic.readByteArray(dynamic.byteSize);
    if (data === null) throw new Error('cannot read private dynamic table');
    return {
        name: 'PT_DYNAMIC',
        offset: offset,
        bytes: new Uint8Array(data)
    };
}

function applyOverlay(chunk, chunkOffset, overlay) {
    const chunkEnd = chunkOffset + chunk.length;
    const overlayEnd = overlay.offset + overlay.bytes.length;
    const start = Math.max(chunkOffset, overlay.offset);
    const end = Math.min(chunkEnd, overlayEnd);
    if (start >= end) return;
    const sourceOffset = start - overlay.offset;
    const targetOffset = start - chunkOffset;
    chunk.set(overlay.bytes.subarray(sourceOffset, sourceOffset + (end - start)), targetOffset);
}

function setU64(view, offset, value) {
    const low = value >>> 0;
    const high = Math.floor(value / 0x100000000) >>> 0;
    view.setUint32(offset, low, true);
    view.setUint32(offset + 4, high, true);
}

function synthesizeElf64Header(buffer, soinfo, elf) {
    const bytes = new Uint8Array(buffer);
    const view = new DataView(buffer);
    const phentsize = 56;
    const phoff = 64;
    const phdrSize = soinfo.phnum * phentsize;
    const required = phoff + phdrSize;
    if (required > bytes.length) {
        throw new Error('synthetic ELF header buffer is too small');
    }

    bytes.fill(0, 0, required);
    bytes[0] = 0x7F;
    bytes[1] = 0x45;
    bytes[2] = 0x4C;
    bytes[3] = 0x46;
    bytes[4] = 2; // ELFCLASS64
    bytes[5] = 1; // ELFDATA2LSB
    bytes[6] = 1; // EV_CURRENT
    bytes[7] = 0; // System V ABI

    view.setUint16(0x10, 3, true);   // ET_DYN
    view.setUint16(0x12, 183, true); // EM_AARCH64
    view.setUint32(0x14, 1, true);   // EV_CURRENT
    setU64(view, 0x18, 0);           // e_entry
    setU64(view, 0x20, phoff);       // e_phoff
    setU64(view, 0x28, 0);           // e_shoff
    view.setUint32(0x30, 0, true);   // e_flags
    view.setUint16(0x34, 64, true);  // e_ehsize
    view.setUint16(0x36, phentsize, true);
    view.setUint16(0x38, soinfo.phnum, true);
    view.setUint16(0x3A, 64, true);  // Elf64_Shdr size
    view.setUint16(0x3C, 0, true);
    view.setUint16(0x3E, 0, true);

    const phdrBytes = soinfo.phdr.readByteArray(phdrSize);
    if (phdrBytes === null) throw new Error('cannot read private program header table');
    bytes.set(new Uint8Array(phdrBytes), phoff);

    elf.phoff = phoff;
    elf.phentsize = phentsize;
    elf.syntheticHeaderSize = required;
}

function writeZeroFilledMemory(start, size, file, synthetic, overlays) {
    const pageSize = Process.pageSize || 4096;
    let readableBytes = 0;
    let zeroBytes = 0;
    let firstOffset = 0;
    const patchList = overlays || [];

    if (synthetic !== null) {
        const required = 64 + synthetic.soinfo.phnum * 56;
        const prefixSize = alignUp(Math.max(pageSize, required), pageSize);
        if (prefixSize > size) throw new Error('mapping is too small for a synthetic ELF header');

        const prefix = new Uint8Array(prefixSize);
        for (let offset = 0; offset < prefixSize; offset += pageSize) {
            const length = Math.min(pageSize, prefixSize - offset);
            let data = null;
            try {
                data = start.add(offset).readByteArray(length);
            } catch (_) {
                data = null;
            }
            if (data !== null) {
                prefix.set(new Uint8Array(data), offset);
                readableBytes += length;
            } else {
                zeroBytes += length;
            }
        }

        synthesizeElf64Header(prefix.buffer, synthetic.soinfo, synthetic.elf);
        for (let i = 0; i < patchList.length; i++) {
            applyOverlay(prefix, 0, patchList[i]);
        }
        file.write(prefix.buffer);
        firstOffset = prefixSize;
    }

    for (let offset = firstOffset; offset < size; offset += pageSize) {
        const length = Math.min(pageSize, size - offset);
        let data = null;
        try {
            data = start.add(offset).readByteArray(length);
        } catch (_) {
            data = null;
        }

        let chunk = null;
        if (data !== null) {
            chunk = new Uint8Array(data);
            readableBytes += length;
        } else {
            chunk = new Uint8Array(length);
            zeroBytes += length;
        }
        for (let i = 0; i < patchList.length; i++) {
            applyOverlay(chunk, offset, patchList[i]);
        }
        file.write(chunk.buffer);
    }
    return { readableBytes: readableBytes, zeroBytes: zeroBytes };
}

function writeMetadata(path, metadata) {
    try {
        const file = new File(path + '.json', 'wb');
        file.write(JSON.stringify(metadata, null, 2));
        file.flush();
        file.close();
    } catch (e) {
        warn('metadata write failed: ' + e);
    }
}

function dumpPrivateSoinfo(handle, reason) {
    if (dumped || dumping) return;
    dumping = true;

    try {
        const soinfo = getSoinfo(handle);
        log('candidate private soinfo=' + handle +
            ', name="' + soinfo.name + '"' +
            ', load_start=' + soinfo.loadStart +
            ', load_bias=' + soinfo.loadBias +
            ', load_size=0x' + soinfo.loadSize.toString(16) +
            ', phdr=' + soinfo.phdr +
            ', phnum=' + soinfo.phnum +
            ', dynamic=' + soinfo.dynamic);
        let elfBase = searchElfHeader(soinfo);
        let syntheticHeader = false;
        let elf = null;
        if (elfBase === null) {
        
            syntheticHeader = true;
            elfBase = soinfo.loadStart;
            elf = parseProgramHeaders(soinfo.phdr, 56, soinfo.phnum);
            elf.phoff = 64;
            warn('ELF header is intentionally absent; rebuilding it from private soinfo phdr=' +
                soinfo.phdr + ', phnum=' + soinfo.phnum);
        } else {
            elf = parseElf64(elfBase);
        }

        const headerOffset = pointerDelta(elfBase, soinfo.loadStart);
        if (headerOffset < 0 || headerOffset >= soinfo.loadSize) {
            throw new Error('ELF header is outside the private load span');
        }

        let dumpSize = soinfo.loadSize - headerOffset;
        if (elf.imageSpan > dumpSize) {
            throw new Error(
                'PT_LOAD span 0x' + elf.imageSpan.toString(16) +
                ' exceeds soinfo span 0x' + dumpSize.toString(16)
            );
        }

        const dynamic = inspectDynamicTable(soinfo, elf);
        if (!dynamic.hasStrtab || !dynamic.hasSymtab || !dynamic.hasStrsz || !dynamic.hasSyment) {
            throw new Error('dynamic symbol metadata is incomplete at the selected dump point');
        }
        if (!dynamic.hasHash && !dynamic.hasGnuHash) {
            throw new Error('both DT_HASH and DT_GNU_HASH are missing');
        }
        const dynamicOverlay = buildDynamicOverlay(soinfo, elf, dynamic);

        const targetName = sanitizeName(soinfo.name || 'linker.so');
        const baseText = elfBase.toString().replace('0x', '');
        const fileName = targetName + '_pid' + Process.id + '_0x' + baseText + '.so';
        const output = openOutputFile(fileName);

        log('exact dump point reached: ' + reason);
        log('private soinfo=' + handle +
            ', load_start=' + soinfo.loadStart +
            ', load_bias=' + soinfo.loadBias +
            ', size=0x' + soinfo.loadSize.toString(16));
        log('ELF=' + elfBase +
            ', synthetic_header=' + syntheticHeader +
            ', PT_LOAD=' + elf.loadCount +
            ', span=0x' + elf.imageSpan.toString(16) +
            ', phnum=' + elf.phnum);
        log('dynamic tables: SYMTAB=' + dynamic.hasSymtab +
            ', STRTAB=' + dynamic.hasStrtab +
            ', HASH=' + dynamic.hasHash +
            ', GNU_HASH=' + dynamic.hasGnuHash +
            ', entries=' + dynamic.entryCount +
            ', symbols=' + (dynamic.symbolCount === null ? 'unknown' : dynamic.symbolCount));

        const stats = writeZeroFilledMemory(
            elfBase,
            dumpSize,
            output.file,
            syntheticHeader ? { soinfo: soinfo, elf: elf } : null,
            [dynamicOverlay]
        );
        output.file.flush();
        output.file.close();

        const metadata = {
            reason: reason,
            jiaguTiming: 'after libjiagu+0xA788 returns, before target JNI_OnLoad lookup/call',
            privateSoinfo: handle.toString(),
            targetName: soinfo.name,
            loadStart: soinfo.loadStart.toString(),
            loadBias: soinfo.loadBias.toString(),
            phdr: soinfo.phdr.toString(),
            phnum: soinfo.phnum,
            privateDynamic: soinfo.dynamic.toString(),
            elfBase: elfBase.toString(),
            syntheticHeader: syntheticHeader,
            dynamicOverlayOffset: dynamicOverlay.offset,
            dynamicOverlaySize: dynamicOverlay.bytes.length,
            dumpSize: dumpSize,
            readableBytes: stats.readableBytes,
            zeroFilledBytes: stats.zeroBytes,
            elf: elf,
            dynamic: dynamic
        };
        writeMetadata(output.path, metadata);

        dumped = true;
        log('dump complete: ' + output.path);
        log('host repair: SoFixer-Windows-64.exe -s <dump.so> -o <fixed.so>');
    } catch (e) {
        warn('dump failed: ' + e.stack);
    } finally {
        dumping = false;
    }
}

function hookManualLoader(module) {
    if (!checkManualLoaderSignature(module)) {
        warn('manual-loader signature mismatch at +0x' +
            CONFIG.manualLoadFunctionOffset.toString(16) + '; handle capture disabled');
        return;
    }

    Interceptor.attach(module.base.add(CONFIG.manualLoadFunctionOffset), {
        onLeave: function (retval) {
            if (!retval.isNull()) {
                lastManualHandle = ptr(retval.toString());
                log('private linker returned soinfo=' + lastManualHandle +
                    ' (captured; waiting for exact dump point)');
            }
        }
    });
}

function hookExactDumpPoint(module) {
    const hookAddress = locateExactDumpPoint(module);
    if (hookAddress === null) {
        throw new Error('cannot locate the pre-JNI_OnLoad dump point');
    }

  
    const decodedHandleOffset = decodeHandleOffsetAtDumpPoint(hookAddress);
    const fixedHandleAddress = module.base.add(CONFIG.handleGlobalOffset);

    log('installing exact pre-JNI_OnLoad hook at ' + hookAddress +
        ' (libjiagu+' + hookAddress.sub(module.base) + ')');
    if (decodedHandleOffset !== null) {
        log('pre-decoded private handle operand: X22+0x' + decodedHandleOffset.toString(16));
    }

    Interceptor.attach(hookAddress, {
        onEnter: function () {
            if (dumped || dumping) return;

            let handle = null;
            if (decodedHandleOffset !== null) {
                try {
                    const handleAddress = this.context.x22.add(decodedHandleOffset);
                    handle = handleAddress.readPointer();
                    log('decoded private handle global ' + handleAddress + ' -> ' + handle);
                } catch (_) {
                    handle = null;
                }
            }

           
            if (handle === null || handle.isNull()) {
                try {
                    handle = fixedHandleAddress.readPointer();
                    log('fixed private handle global ' + fixedHandleAddress + ' -> ' + handle);
                } catch (_) {
                    handle = null;
                }
            }

            if ((handle === null || handle.isNull()) && lastManualHandle !== null) {
                handle = ptr(lastManualHandle.toString());
                log('using captured private soinfo -> ' + handle);
            }
            if (handle === null || handle.isNull()) {
                warn('exact point reached but the private soinfo handle is null');
                return;
            }

            dumpPrivateSoinfo(handle, 'libjiagu pre-target-JNI_OnLoad');
        }
    });
}

function tryLateDump(module) {
    if (!CONFIG.dumpIfAlreadyLoaded || dumped || dumping) return;
    try {
        const handle = module.base.add(CONFIG.handleGlobalOffset).readPointer();
        if (!handle.isNull()) {
            const soinfo = getSoinfo(handle);
            if (searchElfHeader(soinfo) !== null) {
                warn('target was already loaded before the hook; dumping immediately, but spawn mode is safer');
                dumpPrivateSoinfo(handle, 'late attach fallback');
            }
        }
    } catch (_) {
    }
}

function installForModule(module) {
    if (installed) return;
    installed = true;
    if (installTimer !== null) {
        clearInterval(installTimer);
        installTimer = null;
    }

    log('using ' + module.name + ' @ ' + module.base + ', size=0x' + module.size.toString(16));
    try {
        hookManualLoader(module);
        hookExactDumpPoint(module);
        tryLateDump(module);
    } catch (e) {
        installed = false;
        warn('hook installation failed: ' + e.stack);
    }
}

function tryInstall() {
    if (installed) return;
    const module = findJiaguModule();
    if (module !== null) installForModule(module);
}

function findGlobalExport(name) {
    try {
        if (typeof Module.findGlobalExportByName === 'function') {
            const p = Module.findGlobalExportByName(name);
            if (p !== null) return p;
        }
    } catch (_) {
    }

    try {
        if (typeof Module.findExportByName === 'function') {
            const p = Module.findExportByName(null, name);
            if (p !== null) return p;
        }
    } catch (_) {
    }

    const modules = Process.enumerateModules();
    for (let i = 0; i < modules.length; i++) {
        try {
            const p = modules[i].findExportByName(name);
            if (p !== null) return p;
        } catch (_) {
        }
    }
    return null;
}

function hookSystemLoader() {
    const names = [
        'android_dlopen_ext',
        '__loader_android_dlopen_ext',
        'dlopen',
        '__loader_dlopen'
    ];
    const hooked = {};
    for (let i = 0; i < names.length; i++) {
        const address = findGlobalExport(names[i]);
        if (address === null || hooked[address.toString()]) continue;
        hooked[address.toString()] = true;
        Interceptor.attach(address, {
            onLeave: function () {
                tryInstall();
            }
        });
    }
}

function main() {
    if (Process.arch !== 'arm64') {
        warn('this script and recovered offsets are ARM64-only; current arch=' + Process.arch);
        return;
    }

    log('agent started in pid=' + Process.id + '; use -f/spawn mode for the exact timing');
    hookSystemLoader();
    tryInstall();
    if (!installed) installTimer = setInterval(tryInstall, 20);
}

setImmediate(main,3000);

```

---

## 6. 第三步：从动态注册找到真实 dispatcher

### 6.1 从 `RegisterNatives` 枚举全部候选方法

壳 Dex 中已经看不到原方法体，凭什么知道本次被抽取的方法是 `onCreate`？

答案不是“`MainActivity` 通常都有 `onCreate`”，而是从 Manifest 只能得到包名和启动 Activity 类名 `com.flass.myapplication.MainActivity`，它只能缩小观察范围，不能证明被抽取的是哪个方法。真正的方法名、签名和 native 入口来自壳运行时提交给 ART 的 `RegisterNatives` 方法表。

完整的发现顺序如下：

```text
Manifest
  只得到包名和启动 Activity 类名
        │
        ▼
spawn 模式 hook RegisterNatives
  枚举业务类实际注册的全部 native 方法，不按 onCreate 过滤
        │
        ▼
为每一项保存 class + name + signature + fnPtr
  得到精确方法描述符和当次运行入口
        │
        ▼
检查 fnPtr 对应的 trampoline、closure 和 dispatcher
  排除普通 JNI native 方法，确认它进入 360 VMP
        │
        ▼
在 dispatcher 中取得 method record、DexFile 和 CodeItem
  再由 Dex 字符串解析结果反查 class/name，闭合方法身份
```

也就是说，`RegisterNatives` 负责“发现候选方法”，后面的 closure、dispatcher、method record 和 Dex 字符串负责“证明这个候选确实是本文正在 trace 的被抽取方法”。只看到一个名为 `onCreate` 的注册项，还不能直接宣布找到了它的 CodeItem。

壳不会保证业务 native 地址出现在静态导出表中，但无论它怎样隐藏导出符号，最终都要向 ART 提交类似下面的数组。每一项同时给出方法名、JNI 签名和运行时函数地址：

```c
struct JNINativeMethod {
    const char *name;
    const char *signature;
    void *fnPtr;
};
```

下面就是本节实际使用的完整 Frida 侦察脚本，它只 attach 标准的 `JNIEnv->RegisterNatives` 来读取注册表，不 attach、replace 或主动调用表中的 `fnPtr`/动态 trampoline。本文为了减少 Android 框架和第三方库日志，使用 Manifest 包名 `com.flass.myapplication` 作为类名前缀过滤条件；这个条件只负责降噪，不负责选择 `MainActivity` 或 `onCreate`。循环仍会把该包下每个类、每个方法名、每种签名和对应 `fnPtr` 全部打印出来。

```javascript
'use strict';
const CONFIG = {
    packagePrefix: 'com.flass.myapplication',
};

let registerNativesHook = null;

function status(message) {
    console.log('[360-method-discovery] ' + message);
}

function classNameFor(clazz) {
    try {
        const env = Java.vm.tryGetEnv();
        if (env !== null && typeof env.getClassName === 'function') {
            return env.getClassName(clazz);
        }
    } catch (_) {}
    return '?';
}

function rangeFor(address) {
    try {
        const range = Process.findRangeByAddress(address);
        if (range === null) return 'range=?';
        const file = range.file === undefined || range.file === null
            ? ''
            : ' file=' + range.file.path;
        return 'range=' + range.base + '+0x' + range.size.toString(16) +
            ' prot=' + range.protection + file;
    } catch (_) {
        return 'range=?';
    }
}

function locationFor(address) {
    try {
        const module = Process.findModuleByAddress(address);
        if (module === null) return 'module=?';
        return module.name + '+' + address.sub(module.base);
    } catch (_) {
        return 'module=?';
    }
}

function installRegisterNativesHook() {
    if (registerNativesHook !== null || !Java.available) return;

    try {
        Java.performNow(function () {
            const env = Java.vm.getEnv();
            const table = env.handle.readPointer();
            const registerNatives = table
                .add(215 * Process.pointerSize)
                .readPointer();

            registerNativesHook = Interceptor.attach(registerNatives, {
                onEnter: function (args) {
                    const className = classNameFor(args[1]);
                    const methods = args[2];
                    const count = args[3].toInt32();

                    if (className.indexOf(CONFIG.packagePrefix) !== 0) return;
                    if (count < 0 || count > 10000) {
                        status('[REGISTER-ERROR] class=' + className +
                            ' invalid-count=' + count);
                        return;
                    }

                    status('[REGISTER] class=' + className +
                        ' return-site=' + locationFor(this.returnAddress) +
                        ' return=' + this.returnAddress +
                        ' methods=' + methods + ' count=' + count);

                    for (let i = 0; i < count; i++) {
                        try {
                            const item = methods.add(
                                i * Process.pointerSize * 3);
                            const namePtr = item.readPointer();
                            const signaturePtr = item
                                .add(Process.pointerSize)
                                .readPointer();
                            const name = namePtr.readCString();
                            const signature = signaturePtr.readCString();
                            const fn = item
                                .add(Process.pointerSize * 2)
                                .readPointer();

                            status('[REGISTERED-METHOD] class=' + className +
                                ' index=' + i +
                                ' entry=' + item +
                                ' name=' + name +
                                ' name-ptr=' + namePtr +
                                ' signature=' + signature +
                                ' signature-ptr=' + signaturePtr +
                                ' fn=' + fn + ' ' + rangeFor(fn));
                        } catch (e) {
                            status('[METHOD-ERROR] class=' + className +
                                ' index=' + i + ' error=' + e);
                        }
                    }
                },
            });

            status('hooked JNIEnv->RegisterNatives at ' + registerNatives);
        });
    } catch (_) {}
}
setInterval(installRegisterNativesHook, 20);
setImmediate(function () {
    status('agent started pid=' + Process.id + '; use -f spawn mode');
    installRegisterNativesHook();
});
```

这里还要说明过滤范围：Java 类不一定都位于 APK 的 applicationId 包名前缀下。如果目标 APK 的业务类分散在其他包，或者目标是清点全部被保护方法，应当扩大 `packagePrefix`、改成多个前缀，或临时取消此前缀过滤，再根据 `jclass`、`fnPtr` 所在内存和后续 dispatcher 关系筛选。本文的 `com.flass.myapplication` 只适用于当前样本，不能当成通用的“全部业务类”判断规则。

如果注册表里出现多个 `onCreate`，不能按名字选第一个，也不能用一个 `fnPtr` 覆盖另一个。DEX 方法的基本身份是“类描述符 + 方法名 + 完整签名”，例如下面三项是三个不同的方法：

```text
Lcom/flass/myapplication/MainActivity;->onCreate(Landroid/os/Bundle;)V
Lcom/flass/myapplication/MainActivity;->onCreate(Landroid/os/Bundle;Landroid/os/PersistableBundle;)V
Lcom/flass/myapplication/PayActivity;->onCreate(Landroid/os/Bundle;)V
```

处理多项时按下面的规则执行：

| 实际情况 | 如何区分 | 如何继续 trace |
| --- | --- | --- |
| 不同 Activity 都注册了 `onCreate(Bundle)` | 类名不同；保留各自的 `class+name+signature+fnPtr` | 分别启动或导航到对应 Activity，每个方法单独采集 |
| 同一 Activity 重载了两个 `onCreate` | JNI 签名不同，不能只比较方法名 | 按完整签名分别建目标；由 Android 实际生命周期调用确认本轮执行了哪个重载 |
| 多个方法进入同一个公共 dispatcher | dispatcher 地址相同并不代表方法相同 | 使用各自 trampoline/closure、线程和 method record 区分 |
| 同一描述符在不同时间被重复注册 | 不能静默去重或只保留最后一次 | 同时记录注册时的 `jclass`、`fnPtr`、return-site 和调用顺序，再与实际进入时的 closure 对应 |

在当前样本中，用 MT 管理器搜索壳 Dex 的 `onCreate` 相关项时只看到一个候选。但“只搜到一个”既不能证明所有 360 版本都采用相同抽取策略，也不能单独证明后面的 CodeItem 就属于它。本文最终锁定该方法，是因为下面四层证据能够对应到同一个方法：

1. Manifest 表明 `MainActivity` 是启动 Activity，只把它列为优先观察候选。
2. `RegisterNatives` 实际读出 `class=MainActivity`、`name=onCreate`、`signature=(Landroid/os/Bundle;)V` 和对应 `fnPtr`。
3. 该 `fnPtr` 的动态 trampoline 给出本方法 closure，并指向 `linker+0x53B24` 公共 dispatcher。
4. 同一次真实调用中，method record 指向 `code_off=0xB94`，Dex 字符串再次解析为 `MainActivity` 和 `onCreate`。

若目标是恢复样本中的全部被抽取方法，就不能只启动首页一次：侦察阶段保存全部注册项，随后逐个触发对应 Activity、回调或业务路径，并按完整方法描述符分别 trace。某个方法没有实际执行，只能说明当前测试路径没有覆盖它，不能据此把它从候选列表删除。

下面再落实到脚本：要在壳交表时拦住 `RegisterNatives`，首先必须取得它本轮进程中的真实地址。`JNIEnv` 内部保存了一张 JNI 函数地址表，可以把它理解成一排按标准顺序摆放的函数指针。`RegisterNatives` 在这张表中的索引是 `215`。这里的“索引 215”从 `0` 开始计数，换成人数是第 216 个元素，并不是“第 215 个元素”。arm64 中一个地址占 `8` bytes，因此从函数表开头走到这个槽位需要：

```text
RegisterNatives 槽位偏移 = 215 * 8 = 1720 = 0x6B8

JNIEnv* env
    │
    └── env.handle.readPointer()  -> JNI 函数表起点
                                      │
                                      └── 表起点 + 0x6B8
                                              │
                                              └── 读取 8 bytes -> RegisterNatives 的真实运行地址
```

所以 `0x6B8` 不是从本样本日志里猜出的偏移，也不是 `linker_fixed.so` 内的函数 RVA；它来自 Android NDK `jni.h` 对 `JNINativeInterface_` 的固定定义。脚本先取得 JNI 函数表起点，再从标准槽位中读出 `RegisterNatives` 的地址：

```javascript
const table = env.handle.readPointer();
const registerNatives = table.add(215 * Process.pointerSize).readPointer();
```

Frida attach 到这个地址以后，只要进程调用 `RegisterNatives`，就能在函数入口读取这一次注册的四个参数。arm64 传递函数参数时，前几个参数优先放入寄存器；对这个函数来说，对应关系如下：

```text
RegisterNatives(env, clazz, methods, count)
                 │      │        │       │
                X0     X1       X2      W3

X0 = 当前 JNIEnv
X1 = 正在注册 native 方法的 Java 类
X2 = JNINativeMethod 数组的首地址
W3 = 数组中一共有多少项
```

Frida 回调中的 `args[0]`、`args[1]`、`args[2]`、`args[3]` 正好对应这四个值。拿到 `X2` 和 `W3` 后，脚本便能逐项读取方法表。arm64 下每项由三个 8-byte 指针组成，总长度是 `0x18` bytes：

```text
methods + 0x00  -> name 指针       -> "onCreate"
methods + 0x08  -> signature 指针  -> "(Landroid/os/Bundle;)V"
methods + 0x10  -> fnPtr            -> 运行时入口地址
methods + 0x18  -> 下一项 JNINativeMethod
```

类名由 `X1` 中的 `jclass` 解析。脚本先用包名前缀 `com.flass.myapplication` 排除无关类；类名命中后，再无差别遍历该类 `methods[]` 中的全部项目，不按方法名和签名提前筛选。因此日志中同时出现下面四个字段时，才能确认本次样本实际注册的方法是 `MainActivity.onCreate`，而不是作者提前把它写进筛选条件所得出的结果：

```text
[REGISTERED-METHOD] class=com.flass.myapplication.MainActivity name=onCreate signature=(Landroid/os/Bundle;)V fn=0x6fbbe64000
```

其中 `fn` 是该次进程中的动态地址，会随 ASLR 和重新启动而变化；`class/name/signature` 才是用来确定目标 Java 方法的完整描述。编译器也可能通过 wrapper 或拆分后的地址计算调用 `RegisterNatives`，所以不应把“在 IDA 文本搜索中必须出现 `#0x6B8`”当成本样本成立的前提。

当前版本的发现脚本还会打印 `return-site/methods/entry/name-ptr/signature-ptr`，这些字段适合继续追查“哪条壳代码调用了 `RegisterNatives`”，但不是确认目标方法身份的必要条件。本文保存的 run7 早于这些字段加入，因此不围绕一组并不存在的历史地址设计 IDA debugger 截图，也不把预期输出写成已经取得的证据。

需要补采这些辅助字段时，重新运行完整发现脚本即可：

```powershell
frida -U -f com.flass.myapplication -l .\AndroidPrybar-main\frida\trace_360_registered_methods.js
```

本文保留的 run7 控制台日志中，真正出现的是：

```text
[360-oncreate-semantics] hooked JNIEnv->RegisterNatives at 0x6c874c3470
Spawned `com.flass.myapplication`. Resuming main thread!
[360-oncreate-semantics] [REGISTERED-METHOD] class=com.flass.myapplication.MainActivity name=onCreate signature=(Landroid/os/Bundle;)V fn=0x6fbbe64000
```

这条日志先于最终 hook 安装和 `[METHOD-ENTER]` 出现。它不是从 `CONFIG.methodName` 拼出的文本：脚本先逐项读取 `JNINativeMethod[]` 并打印，再在打印之后才比较是否匹配最终目标。

### 6.2 把注册三元组写成完整方法描述符

对应的原始控制台记录位于 [360_oncreate_codeitem_run7_stdout.log](AndroidPrybar-main/frida/360_oncreate_codeitem_run7_stdout.log) 第 2 至 6 行：

```text
[360-oncreate-semantics] hooked JNIEnv->RegisterNatives at 0x6c874c3470
Spawned `com.flass.myapplication`. Resuming main thread!
[360-oncreate-semantics] [REGISTERED-METHOD] class=com.flass.myapplication.MainActivity name=onCreate signature=(Landroid/os/Bundle;)V fn=0x6fbbe64000
[360-oncreate-semantics] installed without trampoline hook/replacement/replay; trampoline=0x6fbbe64000 dispatcher=0x6bfe04cb24 linker=0x6bfdff9000 output=/data/data/com.flass.myapplication/files/360_oncreate_semantics.log
[360-oncreate-semantics] [METHOD-ENTER] tid=4818 method=com.flass.myapplication.MainActivity->onCreate(Landroid/os/Bundle;)V env=0xb400006d4ecca630 closure=0x6fbbe6406c trampoline=0x6fbbe64000 dispatcher=linker+0x53b24
```

其中 `[REGISTERED-METHOD]` 同时给出 `class/name/signature/fn`。同一轮文件 trace 在 [360_oncreate_codeitem_run7_full.log](AndroidPrybar-main/frida/360_oncreate_codeitem_run7_full.log) 第 12 至 13 行再次从 Dex 上下文解析出类名和方法名：

```text
[DEX-STRING] caller=linker+0x53c50 dex=0xb400006d5eccda50 string-id=0x6fb98000c0 data-off=0x5d7 value="Lcom/flass/myapplication/MainActivity;"
[DEX-STRING] caller=linker+0x53c78 dex=0xb400006d5eccda50 string-id=0x6fb9800178 data-off=0x926 value="onCreate"
```

现在逐项解释日志，避免直接抛出一串不清楚的字符：

| 日志字段 | 运行时来源 | 含义 |
| --- | --- | --- |
| `class=com.flass.myapplication.MainActivity` | `RegisterNatives` 的 `jclass` 参数，经 ART 解析类名 | 壳正在给这个 Java 类注册 native 方法 |
| `name=onCreate` | `JNINativeMethod.name` | 被注册的方法名 |
| `signature=(Landroid/os/Bundle;)V` | `JNINativeMethod.signature` | 括号内有一个 `android.os.Bundle` 参数；括号后的 `V` 表示返回 `void` |
| `fn=0x6fbbe64000` | `JNINativeMethod.fnPtr` | 当次进程分配的动态入口；受 ASLR 影响，不是固定 RVA |

DEX/JNI 描述符中，`Landroid/os/Bundle;` 表示对象类型 `android.os.Bundle`：`L` 开始、包名用 `/` 分隔、`;` 结束。`(Landroid/os/Bundle;)V` 因而表示“接收一个 Bundle，返回 void”。

使用更加贴合mt管理器反编译后的写法就是：

```text
com.flass.myapplication.MainActivity->onCreate(Landroid/os/Bundle;)V
```

只是把 `class + name + signature` 三个运行时字段合并成一行，便于和 Smali/DEX 工具的显示方式对应；`->` 不是日志中额外读出的字段。到这一步，`onCreate` 才从“按生命周期猜测的可能方法”变成由动态注册表证明的精确方法。

如果同一业务包注册了多个方法，应全部保留，再根据研究目标分别建立映射，不能因为某个名字像入口就丢掉其他项。本文这次恢复选择该条记录，是因为它同时满足：注册类与 Manifest 的启动 Activity 一致，方法名和签名由 ART 注册表直接给出，随后还能与同一 `fn` 的 closure 和 method record 对上。

### 6.3 将发现结果填入最终 trace 配置

最终脚本 [trace_360_oncreate_semantics.js](AndroidPrybar-main/frida/trace_360_oncreate_semantics.js) 中的三个字段来自上一步日志，不是分析开始前凭经验填写：

```javascript
const CONFIG = {
    packageName: 'com.flass.myapplication',
    className: 'com.flass.myapplication.MainActivity',
    methodName: 'onCreate',
    signature: '(Landroid/os/Bundle;)V',
};
```

`RegisterNatives` hook 仍会先打印每一项，然后才用精确三元组选择对应 `fn`：

```javascript
status('[REGISTERED-METHOD] class=' + registeredClass +
    ' name=' + name + ' signature=' + signature + ' fn=' + fn);

if (registeredClass !== CONFIG.className) continue;
if (name !== CONFIG.methodName || signature !== CONFIG.signature) continue;
installForNative(fn);
```

这个顺序很重要：打印行是原始注册表证据，比较语句只是使用证据选择目标。

### 6.4 从 `fnPtr` 取得 closure 和公共 dispatcher

这组地址关系保存在 [360_oncreate_codeitem_run7_stdout.log](AndroidPrybar-main/frida/360_oncreate_codeitem_run7_stdout.log) 第 4 至 8 行：

```text
[360-oncreate-semantics] [REGISTERED-METHOD] class=com.flass.myapplication.MainActivity name=onCreate signature=(Landroid/os/Bundle;)V fn=0x6fbbe64000
[360-oncreate-semantics] installed without trampoline hook/replacement/replay; trampoline=0x6fbbe64000 dispatcher=0x6bfe04cb24 linker=0x6bfdff9000 output=/data/data/com.flass.myapplication/files/360_oncreate_semantics.log
[360-oncreate-semantics] [METHOD-ENTER] tid=4818 method=com.flass.myapplication.MainActivity->onCreate(Landroid/os/Bundle;)V env=0xb400006d4ecca630 closure=0x6fbbe6406c trampoline=0x6fbbe64000 dispatcher=linker+0x53b24
[360-oncreate-semantics] [METHOD-RECORD] dex=0xb400006d5eccda50 record=0xb400006cfece00e0 closure=0x6fbbe6406c env=0xb400006d4ecca630
[360-oncreate-semantics] [CODE-ITEM] dex-base=0x6fb9800000 code-off=0xb94 code-item=0x6fb9800b94 registers=5 ins=2 outs=3 tries=0 debug-info-off=0xa99 insns-size=0x31 insns=0x6fb9800ba4
```

由日志可直接核算 `fn+0x6C=closure` 和 `dispatcher-linker=0x53B24`。`fn+0x80` 的指针读取发生在脚本中，日志保存了读取结果，但没有保存该地址处的 8-byte 原始 Hexdump，因此这里只引用实际输出的指针值。

动态 `fn` 是约 `0x88` 字节的 trampoline：

```text
closure_identity = fn + 0x6C
dispatcher       = *(fn + 0x80)
linker_base      = dispatcher - 0x53B24
```

本次值：

```text
trampoline = 0x6fbbe64000
closure    = 0x6fbbe6406c
dispatcher = 0x6bfe04cb24
linker     = 0x6bfdff9000
```

closure identity 用于区分多个动态注册方法。公共 dispatcher 处理多个方法，不能只按 dispatcher 地址过滤。

本次地址关系可以直接核算：

```text
0x6fbbe64000 + 0x6c = 0x6fbbe6406c
*(0x6fbbe64000 + 0x80) = 0x6bfe04cb24
0x6bfe04cb24 - 0x53b24 = 0x6bfdff9000
```

因此 `fnPtr`、closure、dispatcher 和 linker base 已经连在同一条运行时关系上。

### 6.5 用 closure、method record 和 Dex 字符串闭合身份链

仅看到 `[REGISTERED-METHOD]` 还只能证明 ART 把该 Java 方法绑定到了 `fnPtr`。还要证明后续 trace 的 CodeItem 确实由这个 `fnPtr` 对应的方法进入，而不是公共 dispatcher 中另一个方法的状态。

从 run7 控制台连续输出中按身份链摘出下面这些原始行；这里只省略两行之间与身份判断无关的 opcode/JNI 日志，不改动保留下来的字段：

```text
[360-oncreate-semantics] [REGISTERED-METHOD] class=com.flass.myapplication.MainActivity name=onCreate signature=(Landroid/os/Bundle;)V fn=0x6fbbe64000
[360-oncreate-semantics] installed without trampoline hook/replacement/replay; trampoline=0x6fbbe64000 dispatcher=0x6bfe04cb24 linker=0x6bfdff9000 output=/data/data/com.flass.myapplication/files/360_oncreate_semantics.log
[360-oncreate-semantics] [METHOD-ENTER] tid=4818 method=com.flass.myapplication.MainActivity->onCreate(Landroid/os/Bundle;)V env=0xb400006d4ecca630 closure=0x6fbbe6406c trampoline=0x6fbbe64000 dispatcher=linker+0x53b24
[360-oncreate-semantics] [METHOD-RECORD] dex=0xb400006d5eccda50 record=0xb400006cfece00e0 closure=0x6fbbe6406c env=0xb400006d4ecca630
[360-oncreate-semantics] [CODE-ITEM] dex-base=0x6fb9800000 code-off=0xb94 code-item=0x6fb9800b94 registers=5 ins=2 outs=3 tries=0 debug-info-off=0xa99 insns-size=0x31 insns=0x6fb9800ba4
[360-oncreate-semantics] [DEX-STRING] caller=linker+0x53c50 dex=0xb400006d5eccda50 string-id=0x6fb98000c0 data-off=0x5d7 value="Lcom/flass/myapplication/MainActivity;"
[360-oncreate-semantics] [DEX-STRING] caller=linker+0x53c78 dex=0xb400006d5eccda50 string-id=0x6fb9800178 data-off=0x926 value="onCreate"
```

这里的校验顺序是：

1. `RegisterNatives` 给出精确三元组和 `fn=0x6fbbe64000`。
2. `fn+0x6C=0x6fbbe6406c`；dispatcher 到 `0x53BA4` 时，寄存器 `X24` 也等于该 closure，脚本才开启活跃 trace 区间。
3. 同一活跃区间中的 `X20` 是 method record，`X23` 是 DexFile；`record+8` 给出 `code_off=0xB94`。
4. linker 紧接着从该 Dex 上下文解析出类描述符 `Lcom/flass/myapplication/MainActivity;` 和方法名 `onCreate`，与动态注册表再次吻合。
5. `ins_size=2` 与实例方法的 `this + Bundle` 两个入参寄存器相容，但它只作结构交叉检查，不单独用于判断方法身份。

`[METHOD-ENTER] method=...` 是脚本在匹配注册三元组后写入的可读标签，不能拿这行标签自己证明自己。真正的闭环是：

```text
RegisterNatives(class/name/signature/fn)
  -> fn+0x6C closure
  -> X24 命中同一 closure
  -> X20 method record / X23 DexFile
  -> Dex class/name 再次解析为 MainActivity/onCreate
  -> code_off=0xB94 的 CodeItem
```

至此才能准确说：后文恢复的 49 个 code units 属于 `com.flass.myapplication.MainActivity->onCreate(Landroid/os/Bundle;)V`，而不是“因为它看起来像 Activity 初始化逻辑”。

第 6.5 节的连续 run7 代码块就是这一部分的直接证据：它依次给出注册三元组和 `fnPtr`、trampoline、dispatcher、closure、method record、CodeItem 以及从同一 Dex 上下文解析出的类名和方法名。论坛正文保留该代码块即可，不再单独制作“动态注册表、trampoline 与 dispatcher”截图。

### 6.6 不要直接 hook trampoline

早期直接 `Interceptor.attach(fn)` 后进入：

```text
linker+0x53EBC
"ARM No matching method"
JNIEnv->FatalError
SIGSEGV
```

该 trampoline 依赖调用点、寄存器、TLS、栈和一次性状态。最终脚本只读取其中的 closure/dispatcher，不 attach、不 replace、不主动调用 trampoline。

![图04 ARM No matching method 错误路径](forum_images/04_arm_no_matching_method.png)

---

## 7. 第四步：用 AndroidPrybar 找稳定 VM 内部点

第一次trace脚本[trace_360_oncreate_prybar.js](AndroidPrybar-main/frida/trace_360_oncreate_prybar.js)。

### 7.1 AndroidPrybar 解决什么问题

AndroidPrybar（发财trace）开源地址：[github.com](https://github.com/GitKittys/AndroidPrybar)

`libtrace.so` 是 AndroidPrybar 的设备端执行引擎，封装了 Unicorn 和 `vc_make_handle/vc_hook_add/vc_reg_read` 等接口。它不是 360 的 `linker.so`，也不包含恢复后的 Smali。本文只用它把 dispatcher 放进可逐指令观察的环境，找出 `0x53BA4`、`0x7CD4C`、`0x61F0C` 和 `0x55618` 等稳定位置。不使用发财trace也可以的，但是unidbg补环境太过麻烦

linker 大量使用：

```asm
CMP
CSET
ADRP/ADD
LDR [table,index]
BR Xn
```

控制流由双入口表和间接跳转拼成，单看 F5 很难判断哪条路径属于 `onCreate`。AndroidPrybar 把 dispatcher 放进 Unicorn，逐条输出实际经过的 ARM64 指令与关键寄存器。

必须再次区分证据边界：AndroidPrybar/`libtrace.so` 得到的 wrapper trace 用于侦察控制流；最终 24 条 Dalvik 指令来自第 9 节 Frida 对 App 原始 dispatcher 执行的观察，不是 `libtrace.so` 直接“解密出 Smali”。

### 7.2 创建 dispatcher wrapper

```javascript
traceModule = Module.load('/data/local/tmp/libtrace.so');

const make = traceModule.findExportByName('_Z14vc_make_handlePvPP10vm_context');
const hook = traceModule.findExportByName('_Z11vc_hook_addP10vm_contextPmiPvS2_mm');
const reg  = traceModule.findExportByName('_Z11vc_reg_readP10vm_context6vc_regPv');

vcMakeHandle = new NativeFunction(make, 'pointer', ['pointer', 'pointer']);
vcHookAdd = new NativeFunction(hook, 'int',
    ['pointer', 'pointer', 'int', 'pointer', 'pointer', 'pointer', 'pointer']);
vcRegRead = new NativeFunction(reg, 'int', ['pointer', 'int', 'pointer']);

const contextOut = Memory.alloc(Process.pointerSize);
const wrapperAddress = vcMakeHandle(dispatcherAddress, contextOut);
vmContext = contextOut.readPointer();
```

wrapper 的执行结果保存在 [360_MainActivity_onCreate_callsite.log](AndroidPrybar-main/frida/360_MainActivity_onCreate_callsite.log)。第 2、13 至 19 行记录 dispatcher 起点、参数寄存器保存和第一次外部跳转：

```text
[CODE] seq=1 linker+0x53b24 stp x28, x27, [sp, #-0x60]!
...
[CODE] seq=12 linker+0x53b50 mov x22, x2
[CODE] seq=13 linker+0x53b54 mov x21, x1
[CODE] seq=14 linker+0x53b58 mov x24, x0
[CODE] seq=15 linker+0x53b5c stur x8, [x29, #-0x58]
[CODE] seq=16 linker+0x53b60 adrp x8, #0x6c02f0a000
[CODE] seq=17 linker+0x53b64 ldr x8, [x8, #0x3d8]
[CODE] seq=18 linker+0x53b68 br x8 x0=0x6fbbf2306c x1=0xb400006d4ecca630 x2=0x7fe9f1f6c0 x8=0x6c02dcf62c x19=0x1 x20=0x7fe9f1e1e0 x21=0xb400006d4ecca630 x22=0x7fe9f1f6c0 x23=0x0 x24=0x6fbbf2306c
```

第 74、1954 至 1955 行把 method record 就绪点、decoder 调用点和 decoder 入口连在同一条真实控制流上：

```text
[CODE] seq=73 linker+0x53ba4 mov x0, x19
...
[CODE] seq=1949 linker+0x61f08 bl #0x6c02df6d4c x0=0xb400006caed178e0 x1=0x20f3 x2=0x1 x8=0x1f1f x19=0xb400006cfecf8740 x20=0x6fa9fe7d30 x21=0xb400006d5ecd15d0 x22=0xb400006caed178e0 x23=0xb400006d5ecd15d0 x24=0x6c02f14000
[CODE] seq=1950 linker+0x7cd4c str x20, [sp, #-0x20]!
```

日志最后一行证明 wrapper 正常走到 dispatcher 返回点：

```text
[CODE] seq=6331 linker+0x55618 ret  x0=0x0 x1=0x0 x2=0x1 x8=0x5607a9194a1e8bf8 x19=0x1 x20=0x7fe9f1e1e0 x21=0x8 x22=0x6c7000e868 x23=0x0 x24=0x20
```

当前日志只保存 wrapper 执行产生的 `[CODE]/[JUMP]`，没有保存 `wrapperAddress` 和 `vmContext` 的数值。这两个地址只能在重新运行 `trace_360_oncreate_prybar.js` 时从 Frida 控制台获取，不能从现有日志反推。

注册 `VC_HOOK_CODE` 与 `VC_HOOK_EXTERNAL_JUMP`，输出每条指令和分支处的 `X0/X1/X2/X8/X19..X24`。

### 7.3 第一次 trace 的执行结果

本次记录 `6331` 条 ARM64 指令。开头：

```text
[CODE] seq=1 linker+0x53b24 stp x28, x27, [sp, #-0x60]!
[CODE] seq=2 linker+0x53b28 stp x26, x25, [sp, #0x10]
...
[CODE] seq=14 linker+0x53b58 mov x24, x0
```

结尾：

```text
[CODE] seq=6324 linker+0x555fc sub sp, x29, #0x50
[CODE] seq=6325 linker+0x55600 ldp x29, x30, [sp, #0x50]
...
[CODE] seq=6331 linker+0x55618 ret
```

decoder 调用、返回和进入分发表的结论不是根据 IDA 猜出的。下面是 [360_MainActivity_onCreate_callsite.log](AndroidPrybar-main/frida/360_MainActivity_onCreate_callsite.log) 第 1951 至 1991 行中的原始 AndroidPrybar 执行 trace。为避免一段代码框过长，正文只摘录“调用入口”和“返回后分发”两个连续区间；中间省略的是同一文件中 `0x7CD5C..0x7CDA0` 的 decoder 内部指令，没有改写保留下来的任何日志字段。

调用点与 decoder 入口：

```text
[CODE] seq=1946 linker+0x61efc mov w25, w0
[CODE] seq=1947 linker+0x61f00 mov x0, x22
[CODE] seq=1948 linker+0x61f04 mov w1, w25
[CODE] seq=1949 linker+0x61f08 bl #0x6c02df6d4c x0=0xb400006caed178e0 x1=0x20f3 x2=0x1 x8=0x1f1f x19=0xb400006cfecf8740 x20=0x6fa9fe7d30 x21=0xb400006d5ecd15d0 x22=0xb400006caed178e0 x23=0xb400006d5ecd15d0 x24=0x6c02f14000
[CODE] seq=1950 linker+0x7cd4c str x20, [sp, #-0x20]!
[CODE] seq=1951 linker+0x7cd50 stp x19, x30, [sp, #0x10]
[CODE] seq=1952 linker+0x7cd54 mov w19, w1
[CODE] seq=1953 linker+0x7cd58 mov x20, x0
```

decoder 生成 `0x13`，返回后立即进入分发表：

```text
[CODE] seq=1973 linker+0x7cda0 lsl w9, w9, #8
[CODE] seq=1974 linker+0x7cda4 bfxil x9, x19, #0, #8 x0=0xb400006d0ecee650 x1=0x20f3 x2=0x1 x8=0xb400006e6ecebf60 x19=0x20f3 x20=0xb400006caed178e0 x21=0xb400006d5ecd15d0 x22=0xb400006caed178e0 x23=0xb400006d5ecd15d0 x24=0x6c02f14000
[CODE] seq=1975 linker+0x7cda8 ldrb w19, [x8, x9]
[CODE] seq=1976 linker+0x7cdac b #0x6c02df6db0 x0=0xb400006d0ecee650 x1=0x20f3 x2=0x1 x8=0xb400006e6ecebf60 x19=0x13 x20=0xb400006caed178e0 x21=0xb400006d5ecd15d0 x22=0xb400006caed178e0 x23=0xb400006d5ecd15d0 x24=0x6c02f14000
[CODE] seq=1977 linker+0x7cdb0 and w0, w19, #0xff
[CODE] seq=1978 linker+0x7cdb4 ldp x19, x30, [sp, #0x10]
[CODE] seq=1979 linker+0x7cdb8 ldr x20, [sp], #0x20
[CODE] seq=1980 linker+0x7cdbc ret  x0=0x13 x1=0x20f3 x2=0x1 x8=0xb400006e6ecebf60 x19=0xb400006cfecf8740 x20=0x6fa9fe7d30 x21=0xb400006d5ecd15d0 x22=0xb400006caed178e0 x23=0xb400006d5ecd15d0 x24=0x6c02f14000
[CODE] seq=1981 linker+0x61f0c cmp w0, #0x81
[CODE] seq=1982 linker+0x61f10 adrp x9, #0x6c02f0b000
[CODE] seq=1983 linker+0x61f14 cset w8, lt
[CODE] seq=1984 linker+0x61f18 add x9, x9, #0x600
[CODE] seq=1985 linker+0x61f1c ldr x8, [x9, w8, uxtw #3]
[CODE] seq=1986 linker+0x61f20 br x8 x0=0x13 x1=0x20f3 x2=0x1 x8=0x6c02ddc094 x19=0xb400006cfecf8740 x20=0x6fa9fe7d30 x21=0xb400006d5ecd15d0 x22=0xb400006caed178e0 x23=0xb400006d5ecd15d0 x24=0x6c02f14000
```

日志的时间顺序给出四个直接事实：`0x61F08` 的实际目标是 `0x7CD4C`，decoder 末尾把查表结果收窄到 `W0`，本次返回值为 `0x13`，下一条实际执行指令是 `0x61F0C` 的比较节点。至于 `VM opcode 0x13` 为什么对应 Dalvik `invoke-super`，还必须继续跟随第 8.5 节的 handler 分发路径并核对 operand 读取，不能只凭这段 trace 命名。

由此确定：

- `0x53B24`：dispatcher 入口。
- `0x53BA4`：method record 稳定点。
- `0x7CD4C`：虚拟 opcode decoder。
- `0x61F0C`：handler 分发表根。
- `0x55618`：dispatcher 正常 RET。

上面的两段 AndroidPrybar 原始日志已经按时间顺序给出 decoder 调用、返回值和进入分发表的全过程，本节不再额外制作 IDA 对照图。

### 7.4 为什么它不直接作为最终 CodeItem

第一次trace用 `vc_make_handle` 执行 dispatcher，并把原调用点暂时改到 one-shot 返回 callback，避免执行两次，更准确的名称是“第一次 AndroidPrybar/Unicorn 侦察 trace”：它确实按时间记录了 6331 条 ARM64 指令和寄存器状态，因此不是纯静态分析。

但这第一次 trace 的执行载体是 `vc_make_handle` 创建的 wrapper，dispatcher 在 Unicorn 环境中 replay，原调用点随后被导向 one-shot callback。它回答的是“真实路径经过哪些 linker RVA、哪些位置适合下 hook”，不能单独证明 App 原始执行时每个 Dex PC 恢复出了什么 code units。

第 9、10 节的 Frida trace 才是第二阶段的“最终恢复 trace”：不调用 wrapper、不重放 dispatcher、不改变 trampoline 目标，只观察 App 原始 dispatcher 从 method record 就绪到正常返回的执行。后文恢复 Smali 使用的是第二阶段日志；第一次 trace 只负责把 `0x53BA4/0x7CD4C/0x61F0C/0x55618` 等位置找准。

最终取证脚本因此：

- 不调用 AndroidPrybar wrapper。
- 不修改 trampoline/dispatcher 执行目标。
- 不主动重放方法。
- 只在已由 AndroidPrybar/IDA 确认的内部 helper 上观察。

AndroidPrybar 负责“找准位置”，Frida 原始 trace 负责“记录最终证据”。

把后续流程按工具拆开就是：

| 阶段 | 工具 | 分析对象 | 得到什么 |
| --- | --- | --- | --- |
| 静态分析 | IDA | SoFixer 后的 `linker_fixed.so` | dispatcher、decoder、分发表和 operand accessor 的候选 RVA |
| 动态侦察 | AndroidPrybar + Unicorn | App 运行时的 linker dispatcher | 6331 条 ARM64 执行轨迹，用于确认真实路径和稳定 hook 点 |
| 最终取证 | Frida `trace_360_oncreate_semantics.js` | App 原始 dispatcher 执行 | 每个 VM PC、VM opcode、operand code units 和引用解析 |
| 手工恢复 | Dalvik 格式表 + IDA handler 结论 | 最终 Frida trace | 逐条恢复原始 Dalvik code units 和 Smali |
| 辅助校验 | Node.js | 已恢复 trace/CodeItem | 检查连续覆盖并输出可复核文件 |

所以答案是：Unicorn 确实追踪了运行时 linker 的 ARM64 控制流，但它只用于定位；后续 24 条 opcode 的最终恢复使用的是 Frida 原始执行 trace，再结合 IDA handler 映射手工完成。

---

## 8. 第五步：由执行 trace 定位，在 IDA 中确认 dispatcher、decoder 与 handler

这里不是先打开 IDA 凭静态代码“还原出整个 VM”。实际顺序是：AndroidPrybar 执行 trace 先证明目标方法真实经过哪些 linker RVA，再回到 IDA 沿这些 RVA 阅读寄存器数据流、DEX 结构访问和 handler 分支；最后由 Frida 对 App 原始 dispatcher 的执行 trace 认证 CodeItem、VM PC 和操作数字节。IDA 提供结构解释，trace 提供本次运行确实走过该路径的证据。

### 8.1 dispatcher 入口 `linker+0x53B24`

```asm
0x53B24 STP X28, X27, [SP,#-0x60]!
0x53B28 STP X26, X25, [SP,#0x10]
0x53B2C STP X24, X23, [SP,#0x20]
0x53B30 STP X22, X21, [SP,#0x30]
0x53B34 STP X20, X19, [SP,#0x40]
0x53B38 STP X29, X30, [SP,#0x50]
...
0x53B50 MOV X22, X2
0x53B54 MOV X21, X1
0x53B58 MOV X24, X0
```

结合动态寄存器：

```text
X24 = closure identity
X21 = JNIEnv*
X22 = va_list/argument state
```

![图05 dispatcher 入口](forum_images/05_dispatcher_53b24.png)

### 8.2 method record 稳定点 `linker+0x53BA4`

AndroidPrybar trace 到这里时：

```text
X20 = method record
X23 = DexFile-like object
X24 = closure identity
X21 = JNIEnv*
```

IDA 中的静态代码：

```asm
0x53B88 CMP  X1,#0
0x53B8C ADRP X9,#unk_190408@PAGE
0x53B90 CSET W8,EQ
0x53B94 ADD  X9,X9,#unk_190408@PAGEOFF
0x53B98 LDR  X8,[X9,W8,UXTW#3]
0x53B9C MOV  X20,X1
0x53BA0 BR   X8
0x53BA4 MOV  X0,X19
0x53BA8 MOV  X1,X21
0x53BAC BL   sub_558A8
0x53BB0 LDR  X8,[X23,#0x28]
0x53BB4 LDR  X9,[X23]
0x53BB8 LDR  W11,[X20]
0x53BBC MOV  X0,X23
0x53BC0 LDR  W10,[X8,#0x5C]
0x53BC4 LDR  W12,[X8,#0x4C]
0x53BC8 LDR  W8,[X8,#0x3C]
0x53BCC ADD  X10,X9,X10
0x53BD0 ADD  X24,X10,X11,LSL#3
0x53BD4 LDRH W10,[X24,#2]
0x53BD8 MOV  W11,#0xC
0x53BDC ADD  X12,X9,X12
0x53BE0 ADD  X8,X9,X8
0x53BE4 MUL  X10,X10,X11
0x53BE8 LDR  W10,[X12,X10]
0x53BEC ADD  X1,X8,X10,LSL#2
0x53BF0 BL   sub_57A74
0x53BF4 STUR X0,[X29,#-0x98]
```

dispatcher 入口时 method record 尚未稳定；到 `0x53BA4` 时可以可靠读取目标方法的 Dex 和 CodeItem，所以它是最终 trace 起点。

| RVA | 解析 |
| --- | --- |
| `0x53B88` | `检查 X1 是否为有效 method record；本次 trace 中 X1 != 0` |
| `0x53B90` | `W8 = (method_record == NULL)，作为双入口表下标` |
| `0x53B98` | `从 unk_190408 双入口表选择下一基本块` |
| `0x53B9C` | `X20 = method record（AndroidPrybar 与最终 Frida trace 共同确认）` |
| `0x53BA0` | `间接跳转；本次 trace 的 X8 = linker+0x53BA4` |
| `0x53BA4` | `最终 Frida trace 起点：X20=record，X23=DexFile-like，X24=本方法 closure` |
| `0x53BA8` | `X1 = JNIEnv*；来自 dispatcher 保存的 X21` |
| `0x53BAC` | `调用内部状态准备 helper；具体语义未作为 CodeItem 证据` |
| `0x53BB0` | `X8 = *(X23+0x28)，取得 DexHeader/索引表描述指针` |
| `0x53BB4` | `X9 = *(X23+0x00) = dexBase` |
| `0x53BB8` | `W11 = *(uint32_t*)X20 = method_idx；run7 中为 0x0C` |
| `0x53BBC` | `X0 = DexFile-like，作为 resolve_dex_string 的第 1 参数` |
| `0x53BC0` | `W10 = DexHeader.method_ids_off（header+0x5C）` |
| `0x53BC4` | `W12 = DexHeader.proto_ids_off（header+0x4C）` |
| `0x53BC8` | `W8 = DexHeader.string_ids_off（header+0x3C）` |
| `0x53BCC` | `X10 = dexBase + method_ids_off = method_ids[] 起点` |
| `0x53BD0` | `X24 = &method_ids[method_idx]；从这里起 X24 已改作 method_id_item*，不再是 closure` |
| `0x53BD4` | `W10 = method_id_item.proto_idx（item+2）` |
| `0x53BD8` | `W11 = 0x0C = sizeof(proto_id_item)` |
| `0x53BDC` | `X12 = dexBase + proto_ids_off = proto_ids[] 起点` |
| `0x53BE0` | `X8 = dexBase + string_ids_off = string_ids[] 起点` |
| `0x53BE4` | `X10 = proto_idx * 0x0C` |
| `0x53BE8` | `W10 = proto_id_item.shorty_idx` |
| `0x53BEC` | `X1 = &string_ids[shorty_idx]，作为 resolve_dex_string 的第 2 参数` |
| `0x53BF0` | `解析本方法 shorty 字符串；run7 trace 返回“VL”` |
| `0x53BF4` | `保存 shorty 字符串指针；Frida 在该返回点记录 DEX-STRING value=“VL”` |

```text
sub_53BA4   -> dexvmp_method_record_ready
sub_57A74   -> resolve_dex_string_id
unk_190408  -> method_record_path_table
```

其中 `0x53BF0` 解析的是 proto 的 shorty 字符串，不是类名或方法名。最终 Frida 原始执行 trace 给出了对应返回值：

```text
[DEX-STRING] caller=linker+0x53bf4 dex=0xb400006d5eccda50 string-id=0x6fb9800120 data-off=0x805 value="VL"
```

`V` 表示返回 `void`，`L` 表示唯一参数是对象引用；完整参数类型仍要从 proto/type 表或已注册的 JNI 签名取得，不能仅凭 shorty `VL` 猜成 `Bundle`。

> **[配图 06：method record ready]**
>
> - IDA 跳 `0x53BA4`，范围包含 `0x53B88..0x53BF4`。
> - 注释 `X20=method record`、`X23=DexFile-like`；注明 `X24` 在 `0x53BA4` 是 closure，但在 `0x53BD0` 被覆盖为 `method_id_item*`。
> - 标出 `0x53BB8` 读取 `method_idx`、`0x53BD4` 读取 `proto_idx`、`0x53BE8` 读取 `shorty_idx`，以及 `0x53BF0` 调用 Dex string resolver。
> - 地址命名建议：`dexvmp_method_record_ready`。
> - 建议文件名：`forum_images/06_method_record_ready_53ba4.png`。

![图06 method record ready](forum_images/06_method_record_ready_53ba4.png)

### 8.3 CodeItem 的来源：Frida 原始执行 trace 认证

Frida 对 App 原始 dispatcher 执行的 trace，不是 AndroidPrybar wrapper replay，也不是在 IDA 中根据结构偏移猜出的地址。原始日志先把方法 identity、method record 和 CodeItem 连在同一个活跃区间：

```text
[METHOD-ENTER] tid=4818 method=com.flass.myapplication.MainActivity->onCreate(Landroid/os/Bundle;)V env=0xb400006d4ecca630 closure=0x6fbbe6406c trampoline=0x6fbbe64000 dispatcher=linker+0x53b24
[METHOD-RECORD] dex=0xb400006d5eccda50 record=0xb400006cfece00e0 closure=0x6fbbe6406c env=0xb400006d4ecca630
[METHOD-RECORD-RAW] record=0c00000000000000940b0000000000000000000000000000000000000000000000000000000000000a00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000101000000ac08000000000000000000
[CODE-ITEM] dex-base=0x6fb9800000 code-off=0xb94 code-item=0x6fb9800b94 registers=5 ins=2 outs=3 tries=0 debug-info-off=0xa99 insns-size=0x31 insns=0x6fb9800ba4
[CODE-ITEM-HEADER] 0500020003000000990a000031000000
```

脚本在 `0x53BA4` 命中同一 closure 后，按 IDA 已确认的数据关系执行下面的只读计算：

```javascript
const record = this.context.x20;
const dexFile = this.context.x23;

const dexBase = dexFile.readPointer();
const codeOffset = record.add(Process.pointerSize).readU32();
const codeItem = dexBase.add(codeOffset);
```

其中 `dexFile.readPointer()` 对应 IDA 的 `LDR X9,[X23]`，`record+8` 中的 `0xB94` 是该 method record 保存的 `code_off`。计算结果必须与同一轮 `[CODE-ITEM]` 日志完全一致，才算通过 trace 认证。

本次值：

```text
dexBase    = 0x6fb9800000
record     = 0xb400006cfece00e0
codeOffset = 0xB94
codeItem   = 0x6fb9800B94
insns      = 0x6fb9800BA4
```

DEX `code_item` 头：

```c
struct code_item {
    uint16_t registers_size;
    uint16_t ins_size;
    uint16_t outs_size;
    uint16_t tries_size;
    uint32_t debug_info_off;
    uint32_t insns_size;
    uint16_t insns[insns_size];
};
```

原始 header：

```text
0500020003000000990a000031000000
```

小端拆分：

```text
05 00             registers_size = 5
02 00             ins_size       = 2
03 00             outs_size      = 3
00 00             tries_size     = 0
99 0A 00 00       debug_info_off = 0xA99
31 00 00 00       insns_size     = 0x31
```

#### 在 IDA Hex View 中找到这段十六进制

但这里必须先分清文件偏移、Dex 相对偏移和运行时绝对地址。本次 run7 的关系是：

```text
dex-base + code_off = code-item
0x6fb9800000 + 0xB94 = 0x6fb9800B94

code-item + sizeof(code_item header) = insns
0x6fb9800B94 + 0x10 = 0x6fb9800BA4
```

`0xB94` 是 `code_off` 相对运行时 Dex base 的偏移，不是 `linker_fixed.so` 的 RVA，也不是文件偏移。因此不能在静态 IDA 中打开 `linker_fixed.so` 后按 `G` 输入 `0xB94`。正确截图方法如下：

1. 用第 10 节命令启动 trace，等日志出现 `[CODE-ITEM]`；记录这一轮的 `dex-base/code-off/code-item/insns`，不要套用另一轮的绝对地址。
2. IDA debugger 连接同一个 PID 后打开 `Hex View`，按 `G` 跳到当轮 `code-item`。run7 的示例地址是 `0x6fb9800B94`，换一次启动通常就不同。
3. 从该地址框选前 `0x10` bytes，应该看到 header：`05 00 02 00 03 00 00 00 99 0A 00 00 31 00 00 00`。
4. 紧接着的 `insns_size * 2 = 0x31 * 2 = 98` bytes 是当时仍处于 360 表示形式的指令数据；run7 的前 16 bytes 是 `2D F7 EB EC 0A CC C8 0C E3 EC CD CC 53 1B A3 17`。这部分不能直接按普通 Dalvik opcode 反汇编。
5. 如果不知道绝对地址，也可以在该次进程的 Dex 映射中用 `Search -> Sequence of bytes...`（`Alt+B`）搜索完整 16-byte header；命中后仍要检查“地址等于 `dex-base+code_off`”且后续密文字节一致，避免短 header 偶然重复。

trace 已经把用于 IDA Hex View 核对的原始内容写入同一份日志：

```text
[CODE-ITEM] dex-base=0x6fb9800000 code-off=0xb94 code-item=0x6fb9800b94 registers=5 ins=2 outs=3 tries=0 debug-info-off=0xa99 insns-size=0x31 insns=0x6fb9800ba4
[CODE-ITEM-HEADER] 0500020003000000990a000031000000
[CODE-ITEM-ENCRYPTED-INSNS] 2df7ebec0accc80ce3eccdcc531ba317...
```

本文后续采用“trace -> code units -> Smali”的手工复核路线，本步骤直接使用 `[CODE-ITEM-HEADER]`、每条 `[VM-INSTRUCTION] restored-units=...` 和引用解析结果，不要求先生成 CodeItem 二进制。需要写回 Dex、做字节对比或交付完整 CodeItem 文件时，再由第 14 节的重建器根据同一份 trace 生成对应输出。

### 8.4 虚拟 opcode decoder `linker+0x7CD4C`

```asm
0x7CD4C STR  X20,[SP,#-0x20]!
0x7CD54 MOV  W19,W1        ; 解密后的第一 code unit/key
0x7CD58 MOV  X20,X0        ; VM cursor/state
0x7CD5C BL   sub_5EC74
...
0x7CD78 AND  X9,X19,#0xFF
0x7CD7C LDR  X8,[X8,#0x150]
0x7CD80 LDRB W19,[X8,X9]
...
0x7CDA4 BFXIL X9,X19,#0,#8
0x7CDA8 LDRB W19,[X8,X9]
0x7CDB0 AND  W0,W19,#0xFF
0x7CDBC RET
```

它根据 key、lane/模式和运行时表返回虚拟 opcode。对第一条指令：

```text
内存加密 word      = 0xF72D
前级解密后的 key   = 0x20F3
decoder 返回 VM op = 0x13
```

三者不是同一个值。把 `pc.readU16()` 直接当 opcode 会从第一步就错。

decode_virtual_opcode

![图07 virtual opcode decoder](forum_images/07_decode_virtual_opcode_7cd4c.png)

### 8.5 handler 二叉分发表 `linker+0x61F0C`

```asm
0x61EFC MOV W25,W0
0x61F00 MOV X0,X22
0x61F04 MOV W1,W25
0x61F08 BL  0x7CD4C
0x61F0C CMP W0,#0x81
0x61F10 ADRP X9,#0x191000
0x61F14 CSET W8,LT
0x61F18 ADD X9,X9,#0x600
0x61F1C LDR X8,[X9,W8,UXTW#3]
0x61F20 BR  X8
```

后面由多个 `CMP/CSET/LDR/BR` 构成二叉决策树。为避免手工点几十层，使用 [ida_resolve_360_opcodes.py](linker/ida_resolve_360_opcodes.py)。这个脚本是本文针对当前 `linker_fixed.so` 编写的 IDAPython 辅助脚本，不是 IDA、IDAMCP、AndroidPrybar 或 360 壳自带文件。

py脚本如下ida里面执行即可，或者让ai执行

```python
import json
import ida_bytes
import idc
OLD_RUNTIME_BASE = 0x6C011F0000
LINKER_SIZE = 0x19C000
DISPATCH_ROOT = 0x61F0C
OBSERVED_OPCODES = [
    0x13,
    0x8D,
    0x0E,
    0x3F,
    0x94,
    0x88,
    0x60,
    0xBC,
    0x9D,
    0x87,
    0x4A,
    0x19,
]

VERBOSE = False


def normalize_pointer(value):
    if OLD_RUNTIME_BASE <= value < OLD_RUNTIME_BASE + LINKER_SIZE:
        return value - OLD_RUNTIME_BASE
    if 0 <= value < LINKER_SIZE:
        return value
    raise ValueError("pointer outside linker: 0x%x" % value)


def condition_true(condition, left, right):
    condition = condition.upper()
    if condition in ("EQ",):
        return left == right
    if condition in ("NE",):
        return left != right
    if condition in ("LT", "LO", "CC"):
        return left < right
    if condition in ("LE", "LS"):
        return left <= right
    if condition in ("GT", "HI"):
        return left > right
    if condition in ("GE", "HS", "CS"):
        return left >= right
    raise ValueError("unsupported condition %s" % condition)


def decode_node(ea, opcode):
    if idc.print_insn_mnem(ea).upper() != "CMP":
        return None
    if idc.print_operand(ea, 0).upper() not in ("W0", "X0"):
        return None

    immediate = idc.get_operand_value(ea, 1)
    adrp_ea = None
    cset_ea = None
    add_ea = None
    br_ea = None
    for candidate in range(ea + 4, ea + 0x24, 4):
        mnemonic = idc.print_insn_mnem(candidate).upper()
        if mnemonic == "ADRP" and adrp_ea is None:
            adrp_ea = candidate
        elif mnemonic == "CSET" and cset_ea is None:
            cset_ea = candidate
        elif mnemonic == "ADD" and add_ea is None:
            add_ea = candidate
        elif mnemonic == "BR":
            br_ea = candidate
            break

    if None in (adrp_ea, cset_ea, add_ea, br_ea):
        return None

    page = idc.get_operand_value(adrp_ea, 1)
    page_offset = idc.get_operand_value(add_ea, 2)
    table = page + page_offset
    condition = idc.print_operand(cset_ea, 1)
    index = 1 if condition_true(condition, opcode, immediate) else 0
    raw_target = ida_bytes.get_qword(table + index * 8)
    target = normalize_pointer(raw_target)
    return {
        "node": ea,
        "compare": immediate,
        "condition": condition.upper(),
        "index": index,
        "table": table,
        "raw_target": raw_target,
        "target": target,
    }


def follow_thunks(ea):
    thunks = []
    current = ea
    for _ in range(16):
        if idc.print_insn_mnem(current).upper() != "ADRP":
            break
        if idc.print_insn_mnem(current + 4).upper() != "LDR":
            break
        if idc.print_insn_mnem(current + 8).upper() != "BR":
            break
        page = idc.get_operand_value(current, 1)
        page_offset = idc.get_operand_value(current + 4, 1)
        pointer_address = page + page_offset
        raw_target = ida_bytes.get_qword(pointer_address)
        target = normalize_pointer(raw_target)
        thunks.append({
            "thunk": current,
            "pointer_address": pointer_address,
            "raw_target": raw_target,
            "target": target,
        })
        current = target
    return current, thunks


def resolve_opcode(opcode):
    path = []
    current = DISPATCH_ROOT
    seen = set()
    for _ in range(128):
        if current in seen:
            raise RuntimeError("dispatch loop at 0x%x" % current)
        seen.add(current)
        node = decode_node(current, opcode)
        if node is None:
            handler, thunks = follow_thunks(current)
            return {
                "opcode": opcode,
                "dispatch_leaf": current,
                "handler": handler,
                "handler_disasm": idc.generate_disasm_line(handler, 0),
                "thunks": thunks,
                "path": path,
            }
        path.append(node)
        current = node["target"]
    raise RuntimeError("dispatch depth exceeded for opcode 0x%x" % opcode)


RESULTS = [resolve_opcode(opcode) for opcode in OBSERVED_OPCODES]
if VERBOSE:
    print(json.dumps(RESULTS, indent=2))
else:
    print(json.dumps([
        {
            "opcode": "0x%x" % item["opcode"],
            "dispatch_leaf": "0x%x" % item["dispatch_leaf"],
            "handler": "0x%x" % item["handler"],
            "handler_disasm": item["handler_disasm"],
        }
        for item in RESULTS
    ], indent=2))

```

脚本从 `0x61F0C` 解析比较节点，根据目标 VM opcode 计算 CSET 与两项表的下标，归一化运行时绝对指针并跟随 thunk 到 handler leaf。它只自动完成“沿分发树找到 handler”这一机械过程，不会自动判断 Dalvik opcode、指令格式或 Smali；最终映射仍需结合 handler 反汇编、operand 读取方式和真实 trace 证明。脚本中的 `OLD_RUNTIME_BASE/LINKER_SIZE/DISPATCH_ROOT` 只对应本文样本，换版本必须重新校准。

该辅助脚本是针对本文样本编写的，但当前附件中没有保存当时 IDAPython console 打印的 JSON 日志，因此正文不能补写一份“历史输出”。制作右侧配图时，需要在本机 IDA 中实际运行上述命令，并保留本轮真实打印的 `opcode`、`dispatch_leaf`、`handler` 和 `handler_disasm`。如果没有运行结果，右图就留空，不能拿预期字段或其他样本输出代替。

```python
def decode_node(ea, opcode):
    immediate = idc.get_operand_value(ea, 1)
    condition = idc.print_operand(cset_ea, 1)
    index = 1 if condition_true(condition, opcode, immediate) else 0
    raw_target = ida_bytes.get_qword(table + index * 8)
    return normalize_pointer(raw_target)
```

脚本执行后的结果，太多了只节选部分

```json

[
  {
    "opcode": "0x13",
    "dispatch_leaf": "0x67894",
    "handler": "0x67894",
    "handler_disasm": "MOV             W0, #3"
  },
  {
    "opcode": "0x8d",
    "dispatch_leaf": "0x64d4c",
    "handler": "0x64d4c",
    "handler_disasm": "MOV             W0, #2"
  },
  {
    "opcode": "0xe",
    "dispatch_leaf": "0x62cbc",
    "handler": "0x62ce8",
    "handler_disasm": "LDR             X2, [X27,#8]"
  },
  {
    "opcode": "0x3f",
    "dispatch_leaf": "0x66144",
    "handler": "0x7b79c",
    "handler_disasm": "MOV             W0, #1"
  },
  {
    "opcode": "0x94",
    "dispatch_leaf": "0x67828",
    "handler": "0x67848",
    "handler_disasm": "AND             W8, W25, #0xFFFF"
  },
  {
    "opcode": "0x88",
    "dispatch_leaf": "0x67bd8",
    "handler": "0x780a0",
    "handler_disasm": "MOV             W1, #1"
  },
  {
    "opcode": "0x60",
    "dispatch_leaf": "0x67d10",
    "handler": "0x7b7e8",
    "handler_disasm": "MOV             W0, #1"
  },
  {
    "opcode": "0xbc",
    "dispatch_leaf": "0x670c4",
    "handler": "0x7be74",
    "handler_disasm": "MOV             W0, WZR"
  },
  {
    "opcode": "0x9d",
    "dispatch_leaf": "0x64928",
    "handler": "0x64934",
    "handler_disasm": "LDR             W8, [X27,#8]"
  },
  {
    "opcode": "0x87",
    "dispatch_leaf": "0x63630",
    "handler": "0x63630",
    "handler_disasm": "MOV             W0, WZR"
  },
  {
    "opcode": "0x4a",
    "dispatch_leaf": "0x66b4c",
    "handler": "0x66b74",
    "handler_disasm": "MOV             W1, #1"
  },
  {
    "opcode": "0x19",
    "dispatch_leaf": "0x7cb4c",
    "handler": "0x7cb4c",
    "handler_disasm": "ADRP            X8, #off_199DD0@PAGE"
  }
]
```

### 8.6 操作数读取器

| RVA | 作用 |
| --- | --- |
| `0x8A0D4` | 常规第 N 个 16-bit code unit，本文主要得到 index 1 |
| `0x89BC8` | 35c packed registers 后续 code unit，本文主要得到 index 2 |

以 `206f 0001 0043` 为例：

- `206f`：opcode + 参数个数 A + 第五寄存器 G。
- `0001`：method index BBBB。
- `0043`：C/D/E/F 四个寄存器 nibble。

只 hook `0x8A0D4` 会拿到 method index，却丢掉寄存器列表，无法恢复完整 35c code units。

第一次 AndroidPrybar 侦察已经记录到两条 accessor 的真实调用与返回。下面四行来自 [360_MainActivity_onCreate_callsite.log](AndroidPrybar-main/frida/360_MainActivity_onCreate_callsite.log) 第 2075、2076、2715、2716 行；中间省略的是 `0x8A0D4..0x8A38C` 函数内部连续指令：

```text
[CODE] seq=2070 linker+0x7decc bl #0x6c02e040d4 x0=0xb400006caed178e0 x1=0x1 x2=0x6fa9fe7d30 x8=0x0 x19=0x6fa9fe7d30 x20=0x6fa9fe7d30 x21=0x0 x22=0xb400006caed178e0 x23=0xb400006d5ecd15d0 x24=0xb400006cfecf8740
[CODE] seq=2071 linker+0x8a0d4 sub sp, sp, #0xa0
......
[CODE] seq=2708 linker+0x8a38c ret  x0=0x1 x1=0x6fa9fe78a8 x2=0x1 x8=0x1f1f x19=0x6fa9fe7d30 x20=0x6fa9fe7d30 x21=0x0 x22=0xb400006caed178e0 x23=0xb400006d5ecd15d0 x24=0xb400006cfecf8740
[CODE] seq=2709 linker+0x7ded0 ldr x8, [x25, #0x28]
```

`0x7DECC` 调用 `0x8A0D4` 时 `X1=1`，返回 `X0=1`，正好得到第一条 35c 指令的第二个 code unit `0x0001`。紧接着的 packed 路径来自同一文件第 2764、2765、3385、3386 行；中间省略的是 `0x89BC8..0x8A0CC` 内部连续指令：

```text
[CODE] seq=2757 linker+0x7df60 bl #0x6c02e03bc8 x0=0xb400006caed178e0 x1=0x2 x2=0x0 x8=0x1 x19=0x6fa9fe7d30 x20=0x6fb98007ff x21=0x0 x22=0xb400006caed178e0 x23=0x6fb98002fe x24=0xb400006cfecf8740
[CODE] seq=2758 linker+0x89bc8 sub sp, sp, #0xe0
... ...
[CODE] seq=3376 linker+0x8a0cc ret  x0=0xffff0043 x1=0x6fa9fe7898 x2=0x1 x8=0x1f1f x19=0x6fa9fe7d30 x20=0x6fb98007ff x21=0x0 x22=0xb400006caed178e0 x23=0x6fb98002fe x24=0xb400006cfecf8740
[CODE] seq=3377 linker+0x7df64 and w8, w0, #0xf
```

这里 `X1=2` 表示读取 index 2，返回值低 16 位是 `0x0043`；高位的 `0xFFFF` 是 accessor 返回寄存器中的扩展结果，不属于最终 code unit。后面的 Frida 最终 trace 将它规范化记录为 `value=0x0043`。

这两类返回值已经记录在 [360_oncreate_codeitem_run7_full.log](AndroidPrybar-main/frida/360_oncreate_codeitem_run7_full.log)。第一条 `invoke-super` 的原始日志位于第 17、18、20、23、39 行：

```text
[VM-PC] start=0x6fb9800ba4 pc=0x6fb9800ba4 offset=0 encoded-first=0xf72d
[VM-OPCODE] caller=linker+0x61f0c state=0xb400006caed18540 key=0x20f3 lane=0x0 opcode=0x13
[VM-CODE-UNIT] vm-opcode=0x13 index=1 value=0x0001
[VM-CODE-UNIT] source=packed vm-opcode=0x13 index=2 value=0x0043
[VM-INSTRUCTION] vm-opcode=0x13 dalvik=invoke-super offset=0 pc=0x6fb9800ba4 raw-first=0x20f3 restored-units=0x206f,0x0001,0x0043 next-offset=3 width-check=ok
```

`index=1 value=0x0001` 对应普通 accessor，`source=packed index=2 value=0x0043` 对应 packed accessor；最后一行证明二者被组装进同一条 35c 指令。`invoke-static` 和 `filled-new-array` 也出现了相同的两阶段读取：

```text
[VM-OPCODE] caller=linker+0x61f0c state=0xb400006caed18540 key=0xd1 lane=0x0 opcode=0xbc
[VM-CODE-UNIT] vm-opcode=0xbc index=1 value=0x0005
[VM-CODE-UNIT] source=packed vm-opcode=0xbc index=2 value=0x0000
[VM-INSTRUCTION] vm-opcode=0xbc dalvik=invoke-static offset=21 pc=0x6fb9800bce raw-first=0x00d1 restored-units=0x0071,0x0005,0x0000 next-offset=24 width-check=ok

[VM-OPCODE] caller=linker+0x61f0c state=0xb400006caed18540 key=0x30a6 lane=0x0 opcode=0x87
[VM-CODE-UNIT] vm-opcode=0x87 index=1 value=0x001c
[VM-CODE-UNIT] source=packed vm-opcode=0x87 index=2 value=0x0210
[VM-INSTRUCTION] vm-opcode=0x87 dalvik=filled-new-array offset=35 pc=0x6fb9800bea raw-first=0x30a6 restored-units=0x3024,0x001c,0x0210 next-offset=38 width-check=ok
```

这两组 AndroidPrybar 调用/返回日志与 run7 的 `[VM-CODE-UNIT]`、`[VM-INSTRUCTION]` 已经直接证明普通 accessor 和 packed accessor 各自提供了哪个 code unit，本节不再制作 accessor 配图。`0x7CF3C` 只保留为 IDA 静态交叉引用，不把它写成已经命中的执行 trace。

### 8.7 已证明的 opcode 映射

映射由 `0x61F0C` 分发路径、handler 读取方式、operand index 和 JNI/DEX 引用共同确定。指令宽度由已经证明的 Dalvik 格式和 trace 捕获到的 code units 确定；本方法是顺序控制流，所以相邻 PC 距离还能作为交叉检查，但不是宽度的唯一依据。

这里的“宽度”不是 CPU 位数、地址长度，也不是 opcode 本身占多少 bit。DEX 的 `insns[]` 是 `uint16_t` 数组，每个元素称为一个 **code unit**：

```text
1 code unit = 16 bits = 2 bytes（2 字节）
指令宽度  = 该条指令从 opcode 到全部操作数字段合计占用多少个 code units
```

例如 `invoke-super` 的格式是 `35c`，恢复结果为 `206f 0001 0043`，一共有 3 个 16-bit code units，所以宽度为 3、实际占 6 字节。`const/4` 的 `0112` 只有 1 个 code unit，所以宽度为 1、占 2 字节。

| VM opcode | Dalvik opcode | 指令 | Dalvik 格式 | 占用 code units | 占用字节 |
| --- | --- | --- | --- | ---: | ---: |
| `0x13` | `0x6F` | `invoke-super` | `35c` | 3 | 6 |
| `0x8D` | `0x6E` | `invoke-virtual` | `35c` | 3 | 6 |
| `0x0E` | `0x0C` | `move-result-object` | `11x` | 1 | 2 |
| `0x3F` | `0x60` | `sget` | `21c` | 2 | 4 |
| `0x94` | `0x12` | `const/4` | `11n` | 1 | 2 |
| `0x88` | `0x1F` | `check-cast` | `21c` | 2 | 4 |
| `0x60` | `0x62` | `sget-object` | `21c` | 2 | 4 |
| `0xBC` | `0x71` | `invoke-static` | `35c` | 3 | 6 |
| `0x9D` | `0x0A` | `move-result` | `11x` | 1 | 2 |
| `0x87` | `0x24` | `filled-new-array` | `35c` | 3 | 6 |
| `0x4A` | `0x1A` | `const-string` | `21c` | 2 | 4 |
| `0x19` | `0x0E` | `return-void` | `10x` | 1 | 2 |

trace 中的 `offset` 也是 code-unit 下标，不是字节偏移。对本次顺序执行的方法，当前指令的结束位置可以写成：

```text
结束 offset = 当前 offset + 指令宽度
内存地址增量 = 指令宽度 * 2 bytes
```

因此 offset 0 的 `invoke-super` 宽度为 3，下一条从 offset 3 开始；运行时 PC 从 `0x6fb9800ba4` 移到 `0x6fb9800baa`，地址正好增加 6 字节。有分支时，下一条实际执行的 PC 可能是跳转目标，此时不能用两个 PC 的差值反推宽度，仍应以 Dalvik 格式、handler 和捕获的 code units 为准。

本样本恢复规则：

```javascript
restoredFirst = (decodedFirst & 0xFF00) | dalvikOpcode;
```

遇到表外 VM opcode 必须回到 IDA 分析，不能按上下文猜。

---

## 9. 第六步：编写不替换、不重放的最终 trace

完整脚本：[trace_360_oncreate_semantics.js](AndroidPrybar-main/frida/trace_360_oncreate_semantics.js)。

### 9.1 配置

这里的 `className/methodName/signature` 来自第 6.1、6.2 节实际捕获的 `RegisterNatives` 三元组；其余 linker RVA 来自第 7、8 节的 AndroidPrybar 动态侦察与 IDA 静态确认。配置表是前面分析结果的汇总，不是分析起点。

```javascript
const CONFIG = {
    packageName: 'com.flass.myapplication',
    className: 'com.flass.myapplication.MainActivity',
    methodName: 'onCreate',
    signature: '(Landroid/os/Bundle;)V',

    dispatcherOffset: 0x53b24,
    methodRecordReadyOffset: 0x53ba4,
    methodReturnOffset: 0x55618,
    dexStringOffset: 0x57a74,
    opcodeFetchOffset: 0x7cd4c,
    operandFetchOffset: 0x8a0d4,
    packedOperandFetchOffset: 0x89bc8,
    invokeHandlerOffset: 0x7de68,
};
```

### 9.2 活跃区间过滤

只有执行到 `0x53BA4` 且 `X24==closureIdentity` 才进入记录：

```javascript
Interceptor.attach(linkerBase.add(0x53ba4), {
    onEnter: function () {
        if (!this.context.x24.equals(closureIdentity)) return;
        enterActive();
        // 记录 method record 和 CodeItem
    }
});

Interceptor.attach(linkerBase.add(0x55618), {
    onEnter: function () {
        if (!isActive()) return;
        finalizeVmInstruction(tid());
        leaveActive();
    }
});
```

`activeDepth` 以 thread id 为 key，避免多线程互相污染。

### 9.3 记录 CodeItem

```javascript
const record = this.context.x20;
const dexFile = this.context.x23;
const dexBase = dexFile.readPointer();
const codeOffset = record.add(Process.pointerSize).readU32();
const codeItem = dexBase.add(codeOffset);

const registersSize = codeItem.readU16();
const insSize = codeItem.add(2).readU16();
const outsSize = codeItem.add(4).readU16();
const triesSize = codeItem.add(6).readU16();
const debugInfoOffset = codeItem.add(8).readU32();
const insnsSize = codeItem.add(12).readU32();
const insns = codeItem.add(16);

emit('[CODE-ITEM-HEADER] ' + bytesSafe(codeItem, 16));
emit('[CODE-ITEM-ENCRYPTED-INSNS] ' + bytesSafe(insns, insnsSize * 2));
emit('[DEBUG-INFO-RAW] ...');
```

保存加密 insns 是为固定输入长度并证明恢复前后字节不同，不是直接反汇编密文。

### 9.4 decoder 上得到 PC 和 VM opcode

```javascript
Interceptor.attach(linkerBase.add(0x7cd4c), {
    onEnter: function (args) {
        this.enabled = isActive();
        if (!this.enabled) return;

        this.keyValue = args[1];
        const cursor = args[0];
        const pc = cursor.readPointer();
        const start = this.context.x28;
        const offset = pc.sub(start).toInt32() / 2;
        this.location = { pc, start, offset };
    },

    onLeave: function (retval) {
        if (!this.enabled) return;
        currentVmInstructions.set(tid(), {
            key: this.keyValue.toUInt32() & 0xffff,
            vmOpcode: retval.toUInt32(),
            units: new Map([[0, this.keyValue.toUInt32() & 0xffff]]),
            pc: this.location.pc,
            start: this.location.start,
            offset: this.location.offset,
        });
    }
});
```

PC offset：

```text
offset = (current_pc - insns_start) / 2
```

这里的 `PC` 是 Program Counter，即“当前执行到哪里”。但它不是电脑端 Windows 进程的 PC，也不是 ARM64 CPU 正在执行 `linker.so` 汇编时的硬件 PC；它是目标 Android App 进程中，360 VM cursor 保存的“当前 Dex 指令地址”。

三个值应这样理解：

| 值 | 所在位置 | 含义 |
| --- | --- | --- |
| `current_pc` | Android 目标进程内存 | VM 当前正在解释的 Dex code unit 地址 |
| `insns_start` | Android 目标进程内存 | 当前方法 `CodeItem.insns[]` 的起始地址 |
| `offset` | trace 日志中的稳定编号 | 当前指令相对 `insns[]` 开头的 code-unit 下标 |

例如第一次进入 decoder：

```text
insns_start = 0x6fb9800ba4
current_pc  = 0x6fb9800ba4
offset      = (0x6fb9800ba4 - 0x6fb9800ba4) / 2 = 0
```

执行完宽度为 3 个 code units 的 `invoke-super` 后，下一条地址增加 `3 * 2 = 6` bytes：

```text
current_pc  = 0x6fb9800baa
offset      = (0x6fb9800baa - 0x6fb9800ba4) / 2 = 3
```

之所以除以 2，是因为一个 Dex code unit 固定为 16 bit，也就是 2 bytes。绝对地址会随 ASLR 和每次启动变化，但相减后的 offset `0、3、6...` 对同一个 CodeItem 保持稳定，因此后面用 offset 判断是否覆盖了整个方法。

### 9.5 记录后续 code units

```javascript
function hookOperand(rva) {
    Interceptor.attach(linkerBase.add(rva), {
        onEnter: function (args) {
            this.enabled = isActive();
            this.index = args[1].toUInt32();
        },
        onLeave: function (retval) {
            if (!this.enabled) return;
            const insn = currentVmInstructions.get(tid());
            insn.units.set(this.index, retval.toUInt32() & 0xffff);
        }
    });
}

hookOperand(0x8a0d4);
hookOperand(0x89bc8);
```

### 9.6 组装一条指令

```javascript
const mapping = DALVIK_OPCODES[instruction.vmOpcode];
const restoredFirst = (instruction.key & 0xff00) | mapping.opcode;

emit(
    '[VM-INSTRUCTION] ' +
    'vm-opcode=0x' + instruction.vmOpcode.toString(16) + ' ' +
    'dalvik=' + mapping.name + ' ' +
    'offset=' + instruction.offset + ' ' +
    'restored-units=' + units.join(',')
);
```

### 9.7 JNI 只用于符号解析

脚本 hook 标准 JNIEnv 表中的 `FindClass`、`GetMethodID`、`GetStaticMethodID`、`Call*MethodA`、`NewStringUTF` 和数组 API。每个 hook 都过滤：

```javascript
this.enabled = isActive() && isLinkerAddress(this.returnAddress);
```

`inflate()`、`setContentView()` 会在同一线程递归进入 Framework JNI。只按线程过滤会混入噪声，还必须确认 caller 位于 linker。

JNI trace 用于回答 `method@0014`、`field@0001`、`string@0000` 指向什么，不用于看到一次调用后猜 opcode。

---

## 10. 第七步：运行最终 trace

### 10.1 启动

```powershell
frida -U -f com.flass.myapplication -l .\AndroidPrybar-main\frida\trace_360_oncreate_semantics.js
```

必须用 `-f`，attach 到运行中进程可能错过 `RegisterNatives` 和第一次 `onCreate`。

成功输出：

```text
[360-oncreate-semantics] agent started pid=4818; use -f spawn mode
[360-oncreate-semantics] hooked JNIEnv->RegisterNatives at 0x6c874c3470
[REGISTERED-METHOD] class=com.flass.myapplication.MainActivity
name=onCreate signature=(Landroid/os/Bundle;)V fn=0x6fbbe64000
[360-oncreate-semantics] installed without trampoline hook/replacement/replay;
trampoline=0x6fbbe64000 dispatcher=0x6bfe04cb24 linker=0x6bfdff9000
```

`installed without trampoline hook/replacement/replay` 是最终证据链与早期 AndroidPrybar 侦察的边界。

另一轮真实运行即使恢复出相同 code units，也可能因为 PID、ASLR 地址或日志时间内容不同而得到不同的“日志 SHA-256”；这不代表恢复失败。真正要求稳定的是同一 PC 的恢复 code units、完整覆盖结果和最终 CodeItem SHA-256。

最终 trace 的 CodeItem 与方法身份记录位于 [360_oncreate_codeitem_run7_full.log](AndroidPrybar-main/frida/360_oncreate_codeitem_run7_full.log) 第 3 至 13 行。下面按证据链摘出原始行；第 10 行的大段 DebugInfo 和第 11 行与方法身份无关的 `value="VL"` 用 `...` 明确省略。论坛中直接使用 Markdown 代码框展示，不再制作终端截图：

```text
[METHOD-ENTER] tid=4818 method=com.flass.myapplication.MainActivity->onCreate(Landroid/os/Bundle;)V env=0xb400006d4ecca630 closure=0x6fbbe6406c trampoline=0x6fbbe64000 dispatcher=linker+0x53b24
[METHOD-RECORD] dex=0xb400006d5eccda50 record=0xb400006cfece00e0 closure=0x6fbbe6406c env=0xb400006d4ecca630
[METHOD-RECORD-RAW] record=0c00000000000000940b0000000000000000000000000000000000000000000000000000000000000a00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000101000000ac08000000000000000000
[DEXFILE-RAW] dex=000080b96f000000000080b96f000000d054cc9e6c0000b4d854cc9e6c0000b4000000000000000010e3cdfe6c0000b4000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000
[CODE-ITEM] dex-base=0x6fb9800000 code-off=0xb94 code-item=0x6fb9800b94 registers=5 ins=2 outs=3 tries=0 debug-info-off=0xa99 insns-size=0x31 insns=0x6fb9800ba4
[CODE-ITEM-HEADER] 0500020003000000990a000031000000
[CODE-ITEM-ENCRYPTED-INSNS] 2df7ebec0accc80ce3eccdcc531ba317eaeca118c8eceeecc8cb531b951be4ecc8f7dfec0accf817ebec4b17e7ecccccc4184b0cf8eccbcc5318a319ecec4b0cf8eccecc53197decf0ecdcce5317be18ecec4bf7faeccbcc5317c8f7edecc8cc5117
...
[DEX-STRING] caller=linker+0x53c50 dex=0xb400006d5eccda50 string-id=0x6fb98000c0 data-off=0x5d7 value="Lcom/flass/myapplication/MainActivity;"
[DEX-STRING] caller=linker+0x53c78 dex=0xb400006d5eccda50 string-id=0x6fb9800178 data-off=0x926 value="onCreate"
```

上述 run7 日志已经直接保存 CodeItem 运行时地址、16-byte header 和完整加密 `insns[]`，因此无需重新启动进程并用 IDA Hex View 重做同一份证据。

---

## 11. 从一条 trace 恢复一条 Dalvik 指令

第一条指令的原始记录位于 [360_oncreate_codeitem_run7_full.log](AndroidPrybar-main/frida/360_oncreate_codeitem_run7_full.log) 第 17、18、20、23、39 行：

```text
[VM-PC] start=0x6fb9800ba4 pc=0x6fb9800ba4 offset=0 encoded-first=0xf72d
[VM-OPCODE] caller=linker+0x61f0c state=0xb400006caed18540 key=0x20f3 lane=0x0 opcode=0x13
[VM-CODE-UNIT] vm-opcode=0x13 index=1 value=0x0001
[VM-CODE-UNIT] source=packed vm-opcode=0x13 index=2 value=0x0043
[VM-INSTRUCTION] vm-opcode=0x13 dalvik=invoke-super offset=0 pc=0x6fb9800ba4 raw-first=0x20f3 restored-units=0x206f,0x0001,0x0043 next-offset=3 width-check=ok
```

### 11.1 位置

```text
(0x6fb9800ba4 - 0x6fb9800ba4) / 2 = 0
```

所以是 code-unit offset 0。

### 11.2 密文与 key

```text
encoded-first = 0xF72D
decoded key   = 0x20F3
```

`0xF72D` 是内存密文，`0x20F3` 是前级解码后的第一 code unit。恢复时使用后者的高 8 位操作数字段。

### 11.3 VM opcode 映射

静态 handler 证明：

```text
VM 0x13 -> Dalvik 0x6F invoke-super
```

```text
(0x20F3 & 0xFF00) | 0x6F = 0x206F
```

### 11.4 拼接操作数

```text
index 0 = 0x206F
index 1 = 0x0001
index 2 = 0x0043
```

得到 `206f 0001 0043`。`35c` 是 Dalvik 对非 range 调用类指令使用的三 code-unit 格式，可写成：

```text
35c: A|G|op  BBBB  F|E|D|C
```

其中 `A` 是实际参数寄存器数量，`C/D/E/F/G` 最多容纳五个寄存器编号，`BBBB` 是 method/type 索引。只取前 `A` 个寄存器；本例 `A=2`，所以只有 C、D 有效，E、F、G 中的零不是额外参数。

按字段逐项拆开：

| code unit | 35c 字段 | 本例数值 | 解码结果 |
| --- | --- | --- | --- |
| `0x206F` | `A|G|op` | `A=2, G=0, op=0x6F` | 两个参数寄存器，Dalvik opcode 为 `invoke-super` |
| `0x0001` | `BBBB` | `method@0001` | 被调用方法的 DEX method_id 索引 |
| `0x0043` | `F|E|D|C` | `F=0, E=0, D=4, C=3` | 取前 A=2 个：`{v3,v4}` |

DEX 按小端保存这三个 16-bit code units，所以 Hex View 中真正看到的 6 bytes 是：

```text
内存低地址                                                   内存高地址
┌────────────── code unit 0 ──────────────┬──── code unit 1 ────┬──── code unit 2 ────┐
│ 6F              │ 20                    │ 01 00                │ 43 00                │
│ opcode = 0x6F   │ A = 2  /  G = 0       │ BBBB = method@0001   │ C=3 D=4 E=0 F=0      │
└─────────────────┴───────────────────────┴──────────────────────┴──────────────────────┘
                  0x206F                           0x0001                  0x0043
```

也可以从 bit 位方向检查，避免把小端字节顺序与字段顺序混在一起：

```text
code unit 0 = 0x206F
bits 15..12: A = 2
bits 11..8 : G = 0
bits  7..0 : opcode = 0x6F

code unit 2 = 0x0043
bits  3..0 : C = 3
bits  7..4 : D = 4
bits 11..8 : E = 0
bits 15..12: F = 0
```

同源符号解析 `method@0001` 后：

```smali
invoke-super {v3, v4}, Landroid/app/Activity;->onCreate(Landroid/os/Bundle;)V
```

这不是按 `onCreate` 常见写法补出来的，三个 code units 都来自原始 trace。

上面的五行 run7 原始日志、`(20F3 & FF00) | 6F = 206F` 计算和 35c 字段拆解已经完整给出恢复过程，不再把同一组数值重新绘制成图片。

---

## 12. 24 条指令的完整 PC 覆盖

| offset | VM | Dalvik | 恢复 code units | 下一 offset |
| ---: | ---: | --- | --- | ---: |
| 0 | `13` | invoke-super | `206f 0001 0043` | 3 |
| 3 | `8d` | invoke-virtual | `106e 0009 0003` | 6 |
| 6 | `0e` | move-result-object | `040c` | 7 |
| 7 | `3f` | sget | `0060 0006` | 9 |
| 9 | `94` | const/4 | `0112` | 10 |
| 10 | `8d` | invoke-virtual | `306e 0002 0104` | 13 |
| 13 | `0e` | move-result-object | `040c` | 14 |
| 14 | `88` | check-cast | `041f 0008` | 16 |
| 16 | `8d` | invoke-virtual | `206e 000d 0043` | 19 |
| 19 | `60` | sget-object | `0062 0001` | 21 |
| 21 | `bc` | invoke-static | `0071 0005 0000` | 24 |
| 24 | `9d` | move-result | `010a` | 25 |
| 25 | `bc` | invoke-static | `1071 0014 0001` | 28 |
| 28 | `0e` | move-result-object | `010c` | 29 |
| 29 | `3f` | sget | `0260 0000` | 31 |
| 31 | `bc` | invoke-static | `1071 0014 0002` | 34 |
| 34 | `0e` | move-result-object | `020c` | 35 |
| 35 | `87` | filled-new-array | `3024 001c 0210` | 38 |
| 38 | `0e` | move-result-object | `000c` | 39 |
| 39 | `4a` | const-string | `011a 0000` | 41 |
| 41 | `bc` | invoke-static | `2071 0016 0001` | 44 |
| 44 | `0e` | move-result-object | `000c` | 45 |
| 45 | `8d` | invoke-virtual | `206e 0003 0004` | 48 |
| 48 | `19` | return-void | `000e` | 49/结束 |

覆盖验证从 0 开始逐条加宽度：

```text
0 + 3 = 3
3 + 3 = 6
6 + 1 = 7
7 + 2 = 9
...
45 + 3 = 48
48 + 1 = 49
```

最终 `49 == insns_size`，中间每个起点等于上一条终点，故 `insns[]` 连续完整。

本方法是顺序控制流，没有 if/switch/异常分支，一次真实执行恰好覆盖全部指令。其他方法不能照搬：有分支时一次 trace 只能证明当前路径，需要多输入合并；相同 PC 的 code units 必须一致，直到完整覆盖 `insns_size`。

分支的下一执行 PC 可能跳转，不能把 `nextOffset-currentOffset` 无条件当宽度。宽度应由 Dalvik 格式、handler 和捕获到的 code units 证明。

配图要表达的覆盖关系可以直接由 run7 的 24 条 `[VM-INSTRUCTION]` 证明。下面按日志中的原始执行顺序完整列出，不改写字段：

```text
[VM-INSTRUCTION] vm-opcode=0x13 dalvik=invoke-super offset=0 pc=0x6fb9800ba4 raw-first=0x20f3 restored-units=0x206f,0x0001,0x0043 next-offset=3 width-check=ok
[VM-INSTRUCTION] vm-opcode=0x8d dalvik=invoke-virtual offset=3 pc=0x6fb9800baa raw-first=0x1054 restored-units=0x106e,0x0009,0x0003 next-offset=6 width-check=ok
[VM-INSTRUCTION] vm-opcode=0xe dalvik=move-result-object offset=6 pc=0x6fb9800bb0 raw-first=0x04cc restored-units=0x040c next-offset=7 width-check=ok
[VM-INSTRUCTION] vm-opcode=0x3f dalvik=sget offset=7 pc=0x6fb9800bb2 raw-first=0x0079 restored-units=0x0060,0x0006 next-offset=9 width-check=ok
[VM-INSTRUCTION] vm-opcode=0x94 dalvik=const/4 offset=9 pc=0x6fb9800bb6 raw-first=0x017f restored-units=0x0112 next-offset=10 width-check=ok
[VM-INSTRUCTION] vm-opcode=0x8d dalvik=invoke-virtual offset=10 pc=0x6fb9800bb8 raw-first=0x3054 restored-units=0x306e,0x0002,0x0104 next-offset=13 width-check=ok
[VM-INSTRUCTION] vm-opcode=0xe dalvik=move-result-object offset=13 pc=0x6fb9800bbe raw-first=0x04cc restored-units=0x040c next-offset=14 width-check=ok
[VM-INSTRUCTION] vm-opcode=0x88 dalvik=check-cast offset=14 pc=0x6fb9800bc0 raw-first=0x048e restored-units=0x041f,0x0008 next-offset=16 width-check=ok
[VM-INSTRUCTION] vm-opcode=0x8d dalvik=invoke-virtual offset=16 pc=0x6fb9800bc4 raw-first=0x2054 restored-units=0x206e,0x000d,0x0043 next-offset=19 width-check=ok
[VM-INSTRUCTION] vm-opcode=0x60 dalvik=sget-object offset=19 pc=0x6fb9800bca raw-first=0x0021 restored-units=0x0062,0x0001 next-offset=21 width-check=ok
[VM-INSTRUCTION] vm-opcode=0xbc dalvik=invoke-static offset=21 pc=0x6fb9800bce raw-first=0x00d1 restored-units=0x0071,0x0005,0x0000 next-offset=24 width-check=ok
[VM-INSTRUCTION] vm-opcode=0x9d dalvik=move-result offset=24 pc=0x6fb9800bd4 raw-first=0x0158 restored-units=0x010a next-offset=25 width-check=ok
[VM-INSTRUCTION] vm-opcode=0xbc dalvik=invoke-static offset=25 pc=0x6fb9800bd6 raw-first=0x10d1 restored-units=0x1071,0x0014,0x0001 next-offset=28 width-check=ok
[VM-INSTRUCTION] vm-opcode=0xe dalvik=move-result-object offset=28 pc=0x6fb9800bdc raw-first=0x01cc restored-units=0x010c next-offset=29 width-check=ok
[VM-INSTRUCTION] vm-opcode=0x3f dalvik=sget offset=29 pc=0x6fb9800bde raw-first=0x0279 restored-units=0x0260,0x0000 next-offset=31 width-check=ok
[VM-INSTRUCTION] vm-opcode=0xbc dalvik=invoke-static offset=31 pc=0x6fb9800be2 raw-first=0x10d1 restored-units=0x1071,0x0014,0x0002 next-offset=34 width-check=ok
[VM-INSTRUCTION] vm-opcode=0xe dalvik=move-result-object offset=34 pc=0x6fb9800be8 raw-first=0x02cc restored-units=0x020c next-offset=35 width-check=ok
[VM-INSTRUCTION] vm-opcode=0x87 dalvik=filled-new-array offset=35 pc=0x6fb9800bea raw-first=0x30a6 restored-units=0x3024,0x001c,0x0210 next-offset=38 width-check=ok
[VM-INSTRUCTION] vm-opcode=0xe dalvik=move-result-object offset=38 pc=0x6fb9800bf0 raw-first=0x00cc restored-units=0x000c next-offset=39 width-check=ok
[VM-INSTRUCTION] vm-opcode=0x4a dalvik=const-string offset=39 pc=0x6fb9800bf2 raw-first=0x0167 restored-units=0x011a,0x0000 next-offset=41 width-check=ok
[VM-INSTRUCTION] vm-opcode=0xbc dalvik=invoke-static offset=41 pc=0x6fb9800bf6 raw-first=0x20d1 restored-units=0x2071,0x0016,0x0001 next-offset=44 width-check=ok
[VM-INSTRUCTION] vm-opcode=0xe dalvik=move-result-object offset=44 pc=0x6fb9800bfc raw-first=0x00cc restored-units=0x000c next-offset=45 width-check=ok
[VM-INSTRUCTION] vm-opcode=0x8d dalvik=invoke-virtual offset=45 pc=0x6fb9800bfe raw-first=0x2054 restored-units=0x206e,0x0003,0x0004 next-offset=48 width-check=ok
[VM-INSTRUCTION] vm-opcode=0x19 dalvik=return-void offset=48 pc=0x6fb9800c04 raw-first=0x00ca restored-units=0x000e next-offset=? width-check=?
```

重建器按每条 `restored-units` 的实际数量推进终点，并在 `MainActivity_onCreate.restored.json` 中写出：

```json
{
  "instructionCount": 24,
  "restoredCodeUnits": 49,
  "completeCoverage": true,
  "metadata": {
    "insnsSize": 49
  }
}
```

前 23 条日志的 `next-offset` 都与下一条 `offset` 相等。最后一条没有后继 PC，所以原始日志如实保留 `next-offset=?`；其 `restored-units=0x000e` 已证明是宽度为 1 的 `return-void`，因此区间由 `[48,49)` 闭合，并与 `insnsSize=49` 相等。以上日志和 JSON 已完整替代原配图 08。

---

## 13. `Integer.valueOf` 不是手工添加

Java 源码写 varargs 时可能没有显式 `Integer.valueOf`，但 D8/R8 需要把 `int` 装箱成 `Object`，Dex 中会产生真实 `invoke-static`。

offset 25：

```text
restored-units=0x1071,0x0014,0x0001
```

即：

```text
invoke-static {v1}, method@0014
```

同次执行又记录：

```text
[DEX-STRING] value="Ljava/lang/Integer;"
[JNI] GetStaticMethodID
owner=Ljava/lang/Integer;
name="valueOf"
signature="(I)Ljava/lang/Integer;"

[JNI-CALL] CallStaticObjectMethodA
method=Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;
args=[I=3100000]
```

offset 31 再次出现 `method@0014`，参数为 `v2`。因此：

```smali
invoke-static {v1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;
invoke-static {v2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;
```

判断依据是 code units 的 `method@0014` 与同源符号解析，而不是 Java 源码有没有显式写装箱。

---

## 14. 第八步：手工校验并重建 CodeItem

完整脚本：[rebuild_360_oncreate_codeitem.js](AndroidPrybar-main/frida/rebuild_360_oncreate_codeitem.js)。

本文先手工完成第 11、12 节的逐条还原表，再用 Node.js 做第二次机械复核。发帖时可以准确表述为：

```text
VM opcode 映射、每条 Dalvik 指令和操作数由 linker 静态分析与真实 trace 手工确认；
Node.js 仅用于检查 PC/code-unit 连续性，并把确认后的字节写成 CodeItem。
```

Node.js使用

```text
读取 trace
  -> 解析 CodeItem header
  -> 按 offset 收集每条 restored-units
  -> 拒绝未知 opcode、缺口、重叠和冲突
  -> 按小端序写出 insns/CodeItem
  -> 解析 DebugInfo
  -> 输出 JSON 覆盖报告和 SHA-256
```

这套检查当然也可以用 Python/C++ 实现；本文选择 Node.js，是因为 Frida 日志和恢复脚本本身都是 JavaScript，处理 `Buffer` 和 JSON 较直接。Node.js 是重建器的运行环境，不是恢复证据的来源。

### 14.1 运行

```powershell
node .\AndroidPrybar-main\frida\rebuild_360_oncreate_codeitem.js `
  .\AndroidPrybar-main\frida\360_oncreate_codeitem_run7_full.log `
  .\AndroidPrybar-main\frida\recovered_smali\com\flass\myapplication
```

输出：

```text
restored 24 instructions / 49 code units
code_item=D:\xxx\dexvm\AndroidPrybar-main\frida\recovered_smali\com\flass\myapplication\MainActivity_onCreate.restored.code_item.bin
```

### 14.2 必须做的校验

校验 raw header：

```javascript
if (header.readUInt16LE(0) !== metadata.registersSize ||
    header.readUInt16LE(2) !== metadata.insSize ||
    header.readUInt16LE(4) !== metadata.outsSize ||
    header.readUInt16LE(6) !== metadata.triesSize ||
    header.readUInt32LE(8) !== metadata.debugInfoOffset ||
    header.readUInt32LE(12) !== metadata.insnsSize) {
    throw new Error('logged CodeItem fields do not match its raw header');
}
```

拒绝 PC 缺口/重叠：

```javascript
let expectedOffset = 0;
const restoredUnits = [];

for (const instruction of instructions) {
    if (instruction.offset !== expectedOffset) {
        throw new Error('instruction gap/overlap at code-unit ' + expectedOffset);
    }
    restoredUnits.push(...instruction.units);
    expectedOffset += instruction.units.length;
}

if (expectedOffset !== metadata.insnsSize) {
    throw new Error('restored ' + expectedOffset +
        ' code units, expected ' + metadata.insnsSize);
}
```

小端写回：

```javascript
const restoredInsns = Buffer.alloc(restoredUnits.length * 2);
restoredUnits.forEach((unit, index) => {
    restoredInsns.writeUInt16LE(unit, index * 2);
});

const restoredCodeItem = Buffer.concat([header, restoredInsns]);
```

本样本 `tries_size=0`，CodeItem 是 header + insns。若 `tries_size!=0`，还必须恢复奇数 insns padding、`try_item[]` 和 `encoded_catch_handler_list`，否则只能称为 insns 恢复。

### 14.3 输出文件：哪些是必要的

下面这些文件都不是从设备直接 dump 出来的，而是 Node.js 根据最终 trace 在电脑端生成的派生产物。只要原始日志和重建脚本还在，就可以重新生成它们。

| 输出文件 | 长度 | 作用 |
| --- | ---: | --- |
| `MainActivity_onCreate.restored.insns.bin` | 98 bytes | 49 个恢复后的 16-bit Dalvik code units，只包含 `insns[]` |
| `MainActivity_onCreate.restored.code_item.bin` | 114 bytes | 16-byte CodeItem header + 98-byte `insns[]`；需要证明完整 CodeItem 或写回 Dex 时使用 |
| `MainActivity_onCreate.encrypted.insns.bin` | 98 bytes | trace 开始时内存中的加密指令快照，用于和恢复结果对照 |
| `MainActivity_onCreate.debug_info.bin` | 11 bytes | 独立的 DebugInfo 流，决定 `.line` 等调试信息 |
| `MainActivity_onCreate.restored.json` | 文本 | header、24 条指令、覆盖状态、DebugInfo 解析和各文件哈希的审计报告 |

其中真正不可替代的输入证据是原始 trace、已验证的 opcode 映射和 DEX 引用解析结果；`.bin` 是把这些证据按 DEX 格式固化后的输出。只阅读恢复 Smali 时，它不是必需附件；要声称“完整 CodeItem 恢复”、做字节比较或写回 Dex 时，则应当生成并保留。

直接回答“能不能不用”：**可以**。不使用 `restored.code_item.bin` 不影响 Frida trace、24 条指令的手工解码、引用索引解析或论坛中展示最终 Smali。区别只在结论和附件形式：

- 不提供 `.bin`：仍可展示完整的 trace、49 个 code units 和可读 Smali，但不要写成“本文交付了一个可直接复核的 114-byte CodeItem 文件”。
- 提供 `.bin`：可以额外给出 114-byte 长度、SHA-256、十六进制对比和写回 Dex 的机械验证，更适合声称“完整 CodeItem 文件已恢复”。

因此它是验证层的可选输出，不是恢复流程必须读取的输入。即使重建脚本自动生成了该文件，正文也可以不依赖它讲解每条 Smali。

`restored.code_item.bin` 不是运行时 dump，也不是 `.so` 或完整 `.dex`，不能单独交给 JADX/baksmali 打开。它只是一个方法的 DEX `code_item` 数据块。本样本 `tries_size=0`，所以正好是：

```text
16-byte header + 49 * 2-byte insns = 114 bytes
```

它有三种实际用途：

1. 作为字节级恢复证据，用十六进制工具复核 header 和全部指令。
2. 作为补丁数据，写回与本次 trace 同源的完整 DEX 的对应 `code_off`，再修复 DEX SHA-1 signature 与 Adler32 checksum。
3. 作为回归基准；以后脚本再次恢复出同一方法时，比较 SHA-256 是否仍为 `D9CA...F265`。

只有放回带有 string/type/field/method 等索引表的匹配 DEX 后，标准反汇编器才能把 `method@0014` 等索引显示成完整 Smali 符号。

重建器生成的 `MainActivity_onCreate.restored.json` 中，与覆盖和完整性直接相关的字段如下。这里省略的是 24 项 `instructions[]` 明细，字段值未改写：

```json
{
  "metadata": {
    "codeOffset": 2964,
    "registersSize": 5,
    "insSize": 2,
    "outsSize": 3,
    "triesSize": 0,
    "debugInfoOffset": 2713,
    "insnsSize": 49
  },
  "instructionCount": 24,
  "restoredCodeUnits": 49,
  "completeCoverage": true,
  "headerHex": "0500020003000000990a000031000000",
  "sha256": {
    "restoredInsns": "eb33fe226f3d2812d32952312a46f69e4450850a3e0f8a0b06ca9ecb11694740",
    "restoredCodeItem": "d9caae7c9df4f8db82c1e39a80f2e373717f4be0d3dc29a05ae6a762df92f265",
    "encryptedInsns": "144872aa8b0658b0461d603c494be714795bf00287bd93015c20f4585d63ccbb",
    "debugInfo": "ccebec3ef9020603fe8de6205a8ddbe98413ab0659d636a513eb9bd66028df34"
  }
}
```

再对重建器刚刚写出的四个文件读取实际长度并重新计算 SHA-256，结果为：

```text
MainActivity_onCreate.restored.insns.bin length=98 sha256=eb33fe226f3d2812d32952312a46f69e4450850a3e0f8a0b06ca9ecb11694740
MainActivity_onCreate.restored.code_item.bin length=114 sha256=d9caae7c9df4f8db82c1e39a80f2e373717f4be0d3dc29a05ae6a762df92f265
MainActivity_onCreate.encrypted.insns.bin length=98 sha256=144872aa8b0658b0461d603c494be714795bf00287bd93015c20f4585d63ccbb
MainActivity_onCreate.debug_info.bin length=11 sha256=ccebec3ef9020603fe8de6205a8ddbe98413ab0659d636a513eb9bd66028df34
headerHex=0500020003000000990a000031000000
insnsHex=6f20010043006e10090003000c046000060012016e30020004010c041f0408006e200d004300620001007100050000000a017110140001000c01600200007110140002000c0224301c0010020c001a0100007120160001000c006e20030004000e00
```

`headerHex` 正好是前 16 bytes，`insnsHex` 是其后的 98 bytes；二者拼接后就是 114-byte `restored.code_item.bin`。以上文本记录已经覆盖原配图 09 要展示的控制台、JSON、文件长度、十六进制分界和 SHA-256，因此不再制作对应图片。

---

## 15. DebugInfo 恢复

`debug_info_off=0xA99` 指向独立 `debug_info_item`，它不在 114-byte CodeItem 内，但决定 `.line` 与局部变量信息。

原始流精确到 `DBG_END_SEQUENCE`：

```text
0b 01 00 0e 3c d2 3c 6b 69 82 00
```

```text
line_start      = 11
parameters_size = 1
parameter_name  = NO_INDEX
```

解析位置：

```text
code-unit 0  -> line 11
code-unit 3  -> line 12
code-unit 16 -> line 13
code-unit 19 -> line 14
code-unit 25 -> line 17
code-unit 31 -> line 18
code-unit 39 -> line 14
```

因此 `.line` 来自原始 DebugInfo，不是根据 Java 源码视觉位置随意插入。

---

## 16. 最终恢复的 Smali

恢复文件：[MainActivity.smali](AndroidPrybar-main/frida/recovered_smali/com/flass/myapplication/MainActivity.smali)。下面的方法体不是根据 UI 效果补写，也不是把 JNI 调用翻译成“功能相同”的伪代码；每条指令前的注释都是已经恢复的 16-bit code units。

最终 Smali 是恢复后 code units 的人类可读文本表示；`restored.code_item.bin` 只是同一批字节的可选二进制封装。来源可以逐层追溯：

| Smali 内容 | 证据来源 |
| --- | --- |
| `.registers 5` | CodeItem header 的 `registers_size=5` |
| `invoke-super/invoke-virtual/...` | IDA 已证明的 `VM opcode -> Dalvik opcode/格式` 映射 |
| `{v3,v4}`、`v0` 等寄存器 | 第一 code unit 高 8 位和 operand accessor 返回的后续 code units |
| `method@0014`、`field@0001` 等索引 | 恢复后的原始 code units |
| `Integer.valueOf` 等完整符号 | 同源 DEX 索引解析与对应 JNI/DEX string trace |
| `.line 11/.line 12/...` | `debug_info_off=0xA99` 指向的 11-byte DebugInfo |

因此流程不是“Node 看懂 Java 逻辑后写 Smali”，而是：

```text
trace 恢复 code units
  -> Node 机械重建/校验 CodeItem
  -> 按 Dalvik 指令格式解码 code units
  -> 用同源 DEX 表解析引用索引
  -> 输出可读 Smali
```

Node 重建器本身只输出 `.bin` 和 `.json`，不会猜测或生成方法语义。下面把最终日志 [360_oncreate_codeitem_run7_full.log](AndroidPrybar-main/frida/360_oncreate_codeitem_run7_full.log) 与 Smali 直接合并展示，让每条指令都能追溯到具体的 `[VM-INSTRUCTION]`。

注释中的 `L39`、`L66` 等表示该条记录在 run7 日志中的行号。绝对 `pc` 只对这一次运行和 ASLR 基址有效，真正用于跨运行排序的是 `offset`。各字段与 Smali 的关系如下：

| trace 字段 | 含义 | 怎样参与恢复 |
| --- | --- | --- |
| `vm-opcode` | decoder 当次返回的 360 VM opcode | 通过第 8.7 节已证明的映射确定 Dalvik opcode 和指令格式 |
| `offset` | 当前指令在 `insns[]` 中的 code-unit 下标 | 决定该条指令在方法中的位置 |
| `pc` | run7 当次执行时的绝对内存地址 | 用来核对实际执行顺序；换一次运行通常会因 ASLR 改变 |
| `raw-first` | 解密后的第一 code unit，即日志中的 decoder key | 保留高 8 位的寄存器/参数字段，再替换低 8 位 opcode |
| `restored-units` | 已恢复的全部 16-bit code units | 按 Dalvik 格式直接解码成寄存器、引用索引和操作数 |
| `next-offset` | 这次顺序执行观察到的下一指令下标 | 仅作连续性校验；有分支时不能拿它反推宽度 |

在下面拆成两行 `# trace` 注释，字段值没有改动。紧随其后的 `# dex` 注释是对 `restored-units` 的字段解码，下一行才是符号化后的 Smali。

```smali
.class public Lcom/flass/myapplication/MainActivity;
.super Landroid/app/Activity;

.method protected onCreate(Landroid/os/Bundle;)V
    .registers 5

    .line 11
    # trace L39 [VM-INSTRUCTION] vm-opcode=0x13 dalvik=invoke-super offset=0 pc=0x6fb9800ba4
    # trace     raw-first=0x20f3 restored-units=0x206f,0x0001,0x0043 next-offset=3 width-check=ok
    # dex       206f 0001 0043: {v3, v4}, method@0001
    invoke-super {v3, v4}, Landroid/app/Activity;->onCreate(Landroid/os/Bundle;)V

    .line 12
    # trace L66 [VM-INSTRUCTION] vm-opcode=0x8d dalvik=invoke-virtual offset=3 pc=0x6fb9800baa
    # trace     raw-first=0x1054 restored-units=0x106e,0x0009,0x0003 next-offset=6 width-check=ok
    # dex       106e 0009 0003: {v3}, method@0009
    invoke-virtual {v3}, Lcom/flass/myapplication/MainActivity;->getLayoutInflater()Landroid/view/LayoutInflater;

    # trace L69 [VM-INSTRUCTION] vm-opcode=0xe dalvik=move-result-object offset=6 pc=0x6fb9800bb0
    # trace     raw-first=0x04cc restored-units=0x040c next-offset=7 width-check=ok
    # dex       040c
    move-result-object v4

    # trace L99 [VM-INSTRUCTION] vm-opcode=0x3f dalvik=sget offset=7 pc=0x6fb9800bb2
    # trace     raw-first=0x0079 restored-units=0x0060,0x0006 next-offset=9 width-check=ok
    # dex       0060 0006: v0, field@0006
    sget v0, Lcom/flass/myapplication/R$layout;->activity_main:I

    # trace L102 [VM-INSTRUCTION] vm-opcode=0x94 dalvik=const/4 offset=9 pc=0x6fb9800bb6
    # trace      raw-first=0x017f restored-units=0x0112 next-offset=10 width-check=ok
    # dex        0112
    const/4 v1, 0x0

    # trace L129 [VM-INSTRUCTION] vm-opcode=0x8d dalvik=invoke-virtual offset=10 pc=0x6fb9800bb8
    # trace      raw-first=0x3054 restored-units=0x306e,0x0002,0x0104 next-offset=13 width-check=ok
    # dex        306e 0002 0104: {v4, v0, v1}, method@0002
    invoke-virtual {v4, v0, v1}, Landroid/view/LayoutInflater;->inflate(ILandroid/view/ViewGroup;)Landroid/view/View;

    # trace L133 [VM-INSTRUCTION] vm-opcode=0xe dalvik=move-result-object offset=13 pc=0x6fb9800bbe
    # trace      raw-first=0x04cc restored-units=0x040c next-offset=14 width-check=ok
    # dex        040c
    move-result-object v4

    # trace L143 [VM-INSTRUCTION] vm-opcode=0x88 dalvik=check-cast offset=14 pc=0x6fb9800bc0
    # trace      raw-first=0x048e restored-units=0x041f,0x0008 next-offset=16 width-check=ok
    # dex        041f 0008: v4, type@0008
    check-cast v4, Landroid/widget/TextView;

    .line 13
    # trace L167 [VM-INSTRUCTION] vm-opcode=0x8d dalvik=invoke-virtual offset=16 pc=0x6fb9800bc4
    # trace      raw-first=0x2054 restored-units=0x206e,0x000d,0x0043 next-offset=19 width-check=ok
    # dex        206e 000d 0043: {v3, v4}, method@000d
    invoke-virtual {v3, v4}, Lcom/flass/myapplication/MainActivity;->setContentView(Landroid/view/View;)V

    .line 14
    # trace L197 [VM-INSTRUCTION] vm-opcode=0x60 dalvik=sget-object offset=19 pc=0x6fb9800bca
    # trace      raw-first=0x0021 restored-units=0x0062,0x0001 next-offset=21 width-check=ok
    # dex        0062 0001: v0, field@0001
    sget-object v0, Landroid/os/Build$VERSION;->RELEASE:Ljava/lang/String;

    # trace L219 [VM-INSTRUCTION] vm-opcode=0xbc dalvik=invoke-static offset=21 pc=0x6fb9800bce
    # trace      raw-first=0x00d1 restored-units=0x0071,0x0005,0x0000 next-offset=24 width-check=ok
    # dex        0071 0005 0000: {}, method@0005
    invoke-static {}, Lcom/flass/myapplication/MainActivity$$ExternalSyntheticBackportWithForwarding0;->m()I

    # trace L222 [VM-INSTRUCTION] vm-opcode=0x9d dalvik=move-result offset=24 pc=0x6fb9800bd4
    # trace      raw-first=0x0158 restored-units=0x010a next-offset=25 width-check=ok
    # dex        010a
    move-result v1

    .line 17
    # trace L245 [VM-INSTRUCTION] vm-opcode=0xbc dalvik=invoke-static offset=25 pc=0x6fb9800bd6
    # trace      raw-first=0x10d1 restored-units=0x1071,0x0014,0x0001 next-offset=28 width-check=ok
    # dex        1071 0014 0001: {v1}, method@0014
    invoke-static {v1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    # trace L248 [VM-INSTRUCTION] vm-opcode=0xe dalvik=move-result-object offset=28 pc=0x6fb9800bdc
    # trace      raw-first=0x01cc restored-units=0x010c next-offset=29 width-check=ok
    # dex        010c
    move-result-object v1

    # trace L276 [VM-INSTRUCTION] vm-opcode=0x3f dalvik=sget offset=29 pc=0x6fb9800bde
    # trace      raw-first=0x0279 restored-units=0x0260,0x0000 next-offset=31 width-check=ok
    # dex        0260 0000: v2, field@0000
    sget v2, Landroid/os/Build$VERSION;->PREVIEW_SDK_INT:I

    .line 18
    # trace L295 [VM-INSTRUCTION] vm-opcode=0xbc dalvik=invoke-static offset=31 pc=0x6fb9800be2
    # trace      raw-first=0x10d1 restored-units=0x1071,0x0014,0x0002 next-offset=34 width-check=ok
    # dex        1071 0014 0002: {v2}, method@0014
    invoke-static {v2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    # trace L298 [VM-INSTRUCTION] vm-opcode=0xe dalvik=move-result-object offset=34 pc=0x6fb9800be8
    # trace      raw-first=0x02cc restored-units=0x020c next-offset=35 width-check=ok
    # dex        020c
    move-result-object v2

    # trace L313 [VM-INSTRUCTION] vm-opcode=0x87 dalvik=filled-new-array offset=35 pc=0x6fb9800bea
    # trace      raw-first=0x30a6 restored-units=0x3024,0x001c,0x0210 next-offset=38 width-check=ok
    # dex        3024 001c 0210: {v0, v1, v2}, type@001c
    filled-new-array {v0, v1, v2}, [Ljava/lang/Object;

    # trace L317 [VM-INSTRUCTION] vm-opcode=0xe dalvik=move-result-object offset=38 pc=0x6fb9800bf0
    # trace      raw-first=0x00cc restored-units=0x000c next-offset=39 width-check=ok
    # dex        000c
    move-result-object v0

    .line 14
    # trace L327 [VM-INSTRUCTION] vm-opcode=0x4a dalvik=const-string offset=39 pc=0x6fb9800bf2
    # trace      raw-first=0x0167 restored-units=0x011a,0x0000 next-offset=41 width-check=ok
    # dex        011a 0000: v1, string@0000
    const-string v1, "%s (%s) (%s)"

    # trace L350 [VM-INSTRUCTION] vm-opcode=0xbc dalvik=invoke-static offset=41 pc=0x6fb9800bf6
    # trace      raw-first=0x20d1 restored-units=0x2071,0x0016,0x0001 next-offset=44 width-check=ok
    # dex        2071 0016 0001: {v1, v0}, method@0016
    invoke-static {v1, v0}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    # trace L354 [VM-INSTRUCTION] vm-opcode=0xe dalvik=move-result-object offset=44 pc=0x6fb9800bfc
    # trace      raw-first=0x00cc restored-units=0x000c next-offset=45 width-check=ok
    # dex        000c
    move-result-object v0

    # trace L378 [VM-INSTRUCTION] vm-opcode=0x8d dalvik=invoke-virtual offset=45 pc=0x6fb9800bfe
    # trace      raw-first=0x2054 restored-units=0x206e,0x0003,0x0004 next-offset=48 width-check=ok
    # dex        206e 0003 0004: {v4, v0}, method@0003
    invoke-virtual {v4, v0}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    # trace L382 [VM-INSTRUCTION] vm-opcode=0x19 dalvik=return-void offset=48 pc=0x6fb9800c04
    # trace      raw-first=0x00ca restored-units=0x000e next-offset=? width-check=?
    # dex        000e; format=10x, width=1, offset 48 + 1 = insns_size 49
    return-void
.end method
```

最后一条日志中的 `next-offset=?` 和 `width-check=?` 不是证据缺失，而是 `return-void` 后没有下一条 VM PC 可供在线比较。它的 Dalvik `10x` 格式固定占 1 个 code unit，trace 已捕获 `restored-units=0x000e`，并且 `48 + 1` 恰好到达 CodeItem header 给出的 `insns_size=49`，所以终点仍然闭合。



![图08 恢复 Smali 与 code units](forum_images/08_restored_smali_codeunits.png)

结语：经过这一顿分析下来可以看到，数字加固即便是普通版本的话想要还原出他的被native 化的java方法里的smali代码还是非常困难的，后续版本的话和帖子里说的思路是差不多的，如果换成其他 Android 版本或其他数字加固版本，首先应重新找 RVA，不能复制本文偏移后直接 hook
