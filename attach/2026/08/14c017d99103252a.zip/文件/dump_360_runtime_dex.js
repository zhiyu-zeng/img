'use strict';

/*
 * Dump every valid standard Dex image that becomes readable after 360 starts
 * the real application. This deliberately dumps code_item bytes instead of
 * translating the DexVMP IR back into approximate Smali.
 *
 * Usage:
 *   frida -U -f com.flass.myapplication -l .\frida\dump_360_runtime_dex.js
 */

const CONFIG = {
    packageName: 'com.flass.myapplication',
    outputDir: '/data/data/com.flass.myapplication/files',
    initialDelayMs: 3000,
    rescanDelayMs: 8000,
    maxDexSize: 128 * 1024 * 1024,
};

const dumped = Object.create(null);

function u32(p) {
    return p.readU32() >>> 0;
}

function isDexVersionByte(v) {
    return v >= 0x30 && v <= 0x39;
}

function validateDex(base, containingRange) {
    try {
        if (base.compare(containingRange.base) < 0) return null;
        const available = containingRange.base.add(containingRange.size).sub(base).toUInt32();
        if (available < 0x70) return null;

        if (base.readU8() !== 0x64 || base.add(1).readU8() !== 0x65 ||
            base.add(2).readU8() !== 0x78 || base.add(3).readU8() !== 0x0a ||
            !isDexVersionByte(base.add(4).readU8()) ||
            !isDexVersionByte(base.add(5).readU8()) ||
            !isDexVersionByte(base.add(6).readU8()) || base.add(7).readU8() !== 0) {
            return null;
        }

        const fileSize = u32(base.add(0x20));
        const headerSize = u32(base.add(0x24));
        const endianTag = u32(base.add(0x28));
        if (headerSize !== 0x70 || endianTag !== 0x12345678 ||
            fileSize < 0x70 || fileSize > CONFIG.maxDexSize) {
            return null;
        }

        return {
            fileSize: fileSize,
            version: base.add(4).readCString(4),
        };
    } catch (e) {
        return null;
    }
}

function safeName(address, size) {
    return 'runtime_' + address.toString().replace('0x', '') + '_' + size.toString(16) + '.dex';
}

function dumpDex(base, info, source) {
    const key = base.toString() + ':' + info.fileSize;
    if (dumped[key]) return;

    try {
        const bytes = base.readByteArray(info.fileSize);
        const path = CONFIG.outputDir + '/' + safeName(base, info.fileSize);
        const f = new File(path, 'wb');
        f.write(bytes);
        f.flush();
        f.close();
        dumped[key] = path;
        console.log('[360-dex-dump] dex' + info.version + ' base=' + base +
            ' size=0x' + info.fileSize.toString(16) + ' source=' + source +
            ' -> ' + path);
    } catch (e) {
        console.log('[360-dex-dump][!] failed base=' + base + ' size=0x' +
            info.fileSize.toString(16) + ': ' + e);
    }
}

function scanProtection(protection) {
    const ranges = Process.enumerateRanges({ protection: protection, coalesce: false });
    const pattern = '64 65 78 0a ?? ?? ?? 00';

    ranges.forEach(function (range) {
        if (range.size < 0x70) return;
        let matches;
        try {
            matches = Memory.scanSync(range.base, range.size, pattern);
        } catch (e) {
            return;
        }

        matches.forEach(function (match) {
            const info = validateDex(match.address, range);
            if (info !== null) dumpDex(match.address, info, protection);
        });
    });
}

function enumerateTargetClasses() {
    if (!Java.available) return;
    Java.perform(function () {
        let count = 0;
        Java.enumerateLoadedClasses({
            onMatch: function (name) {
                if (name.indexOf(CONFIG.packageName) === 0) {
                    count++;
                    console.log('[360-dex-dump] loaded class: ' + name);
                }
            },
            onComplete: function () {
                console.log('[360-dex-dump] target class count=' + count);
            },
        });
    });
}

function scanAll(reason) {
    console.log('[360-dex-dump] scanning readable mappings: ' + reason);
    ['r--', 'rw-', 'r-x'].forEach(scanProtection);
    enumerateTargetClasses();
}

setTimeout(function () {
    scanAll('initial');
    setTimeout(function () {
        scanAll('rescan');
    }, CONFIG.rescanDelayMs);
}, CONFIG.initialDelayMs);
