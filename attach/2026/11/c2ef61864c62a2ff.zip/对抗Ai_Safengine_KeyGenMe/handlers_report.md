# Safengine 2.x VM 架构分析（基于 60 个 handler 的去混淆汇编）

样本：`Safengine授权对抗Ai.exe` · 表 `0x82C279`（256 槽 / 60 个不同 handler）· disp `0x82BA1E ret 0x64`

handler 命名对照 `disptree\zvm_vm_db.asm`（zhouqing，zvm/zvrop 系）的约定重写。

---

## 一、结论先行

**栈式虚拟机（stack machine），指令集是 CISC 语义、RISC 实现。**

| 判据 | 观察 | 结论 |
|---|---|---|
| 操作数在哪 | 所有算术/逻辑 handler 都从 `[ebp+k]` 取操作数、把结果写回 `[ebp+k]`，并把 `ebp` 按宽度（2/4/6/8/12）推进 | **栈机**：无通用寄存器堆 |
| 有没有栈界限 | `lea eax,[edi+0x50]; cmp ebp,eax; ja 分派` 出现在 57 个 handler 的收尾 | VM 栈有上界（`[edi+0x50]`），越界走 `0x82BFBA` |
| 寄存器角色 | `esi`=字节码指针（只有 `dec/lea esi,-n`，向后走）、`ebp`=VM 栈顶、`edi`=客户机内存基址、`bl`=滚动密钥 | 三个指针 + 一个密钥，没有"数据寄存器" |
| 指令长度 | 行内立即数 1/2/4 字节（`[esi-1]`/`[esi-2]`/`[esi-4]`，`esi` 相应 -1/-2/-4），且**加密** | **CISC**：变长指令 + 加密立即数 |
| 数据宽度 | byte/word/dword 三套齐全（add/shl/shr/and/mul/div 都有 8/16/32 位版本，还有 shld/shrd 64 位跨字） | **CISC**：多宽度 |
| 内存操作数 | LOAD/STORE 家族一条 guest 指令就完成"弹地址 + 弹值 + 访问客户机内存" | **CISC**：内建内存操作数 |
| 每条 handler 的工作量 | 去掉共享分派后只有 4~15 条宿主指令，只做一件事 | **RISC 式实现**：单操作、显式栈 |

一句话：**Safengine 2.x 是一个"变长、加密立即数、栈式求值"的 CISC 字节码 VM，用 threaded-code（每 handler 尾部自带下一指令解码）实现。**

### 两个关键机制（不是架构属性，但影响读代码）

1. **滚动密钥解码**：`bl` 是滚动 key。取 opcode：`mov al,[esi-1]; dec esi; add al,bl` → `ror al,7; xor al,0xb8; not al; add bl,al` → `movzx eax,al` → 查表 `[eax*4+0x82C279]`。取地址/立即数走同形状但**另一组常量**的链（如 `sub al,bl / add al,0xa / rol al,7 / neg al` 后再 `sub bl,al`）。所以同一个字节在不同 handler 家族里解出不同的值 —— 这也是为什么 256 个槽只有 60 个 handler：多个槽是同一条指令的"别名编码"。
2. **共享分派循环**：57 个 handler 最终汇入 `0x829FB7 → 0x82C88C → 0x82ACBF → 0x82B8D4 → 0x829D8F(查表) → 0x82BD0D(bswap) → 0x829E59/0x82BA0B(组栈帧) → ret 0x64`。另有 3 个 handler 走自己的 `ret 0x30 / ret 0x34` 尾（VM 出口 / 回调宿主）。

---

## 二、命名法（对照 `zvm_vm_db.asm`）

zvm/zvrop 的约定是 `v<op><width>`，宽度用数字后缀表示：

| 后缀 | 宽度 | 例 |
|---|---|---|
| `1` | byte | `vAdd1`、`vShl1`、`vPushImm1` |
| `2` | word | `vAdd2`、`vMul2`、`vPushImmSx2` |
| `4` | dword | `vAdd4`、`vDiv4`、`vReadMemDs4` |
| `8` | qword | `vReadMemDs8`（本样本没有） |

派生规则：

- **读/写内存带段前缀**：`vReadMem<Seg><w>` / `vWriteMem<Seg><w>`，`Seg` ∈ `Ds / Ss / Es / Fs / Gs / Cs`。
- **`Sx` = 符号扩展**：`vPushImmSx1` 是"1 字节立即数符号扩展到 4 字节再压栈"。
- **`vPushVEsp / vPushVSp`** 压 VM 栈指针（32 位 / 低 16 位），**`vPopVEsp / vPopVSp`** 是反向。
- **德摩根形态**：`NOT,NOT,OR` 记 `vNand<w>`（`~a\|~b = ~(a&b)`），`NOT,(NOT),AND` 记 `vNor<w>`（`~a&~b = ~(a\|b)`）。
- **变体标签**：本样本同一指令有多种编码，用后缀区分 —— `abs`（地址从栈上弹，绝对寻址）、`idx`（地址 = 加密字节码里的偏移 + `edi`）、`mem`（就地操作内存而非寄存器）、`restore/val`（两种出口形态）、`rel/rel2`（两种跳转入口）。
- 库里没有的形状按同一法则扩展，并在小节里标注 **(扩展名)**。

覆盖情况：256 个槽 → **60 个 handler / 52 个不同名字**，其中 48 个与库同名同形、10 个是同名的另一种编码、2 个为扩展。

---

## 三、逐 handler 报告

### 栈 / 取址 / 立即数 / 跳转（12 个）

**vPushVSp · 0x82C228 · slots 2,44,49,65,74,107 —— 压 VM 栈指针（低 16 位）**
```
mov eax,ebp ; sub ebp,2 ; mov [ebp],ax
```
压入**旧 ebp 的低 16 位**。对应 x86 的 `push sp`，给"取局部变量地址"这类代码用。栈：-2。

**vPushVEsp · 0x82A879 · slots 130 —— 压 VM 栈指针（32 位）**
```
mov eax,ebp ; sub ebp,4 ; mov [ebp],eax
```
压入**旧 ebp 的 32 位值**。栈：-4。

**vPopVEsp · 0x82A66B · slots 17,26,71,99,163,213 —— 弹栈顶到 VM 栈指针**
```
ja ... ; mov ebp,[ebp]
```
从栈顶弹出一个值**当作新的 ebp**（`pop sp` / `leave` 语义），用于调用返回、局部变量回收。栈：不可静态定（由栈上值决定）。

**vPopVSp · 0x82B5E0 · slots 27,67,149,194,201,218,231 —— 弹栈顶低 16 位到 bp**
```
mov bp,word ptr [ebp]
```
只改 ebp 低 16 位（VM 栈在 64K 窗口内时的"短跳"形式）。

**vPushAddrVSp · 0x82A6ED · slots 111,173,181,196,238,241 —— 压栈顶值及其地址 (扩展名)**
```
push dword ptr [ebp] ; push esp ; add ebp,4
```
把 `[ebp]` 的值再压一份，并把它的宿主栈地址一起压上 —— 典型 `lea reg,[stack_slot]`（VM 的 `push @sp`）。栈：净 0（弹 4 压 4 + 地址）。

**vPushImm1 · 0x82BF8E · slots 14,79,91,124,252 —— 1 字节立即数入栈**
```
mov al,[esi-1] ; add al,bl ; inc al ; rol al,5 ; dec esi ; neg al ; add bl,al
sub ebp,2 ; mov [ebp],ax
```
从字节码取 1 字节、用 `bl` 解密后**零扩展成 16 位**压栈。栈：-2。

**vPushImm2 · 0x82AF52 · slots 97,191 —— 2 字节立即数入栈**
```
mov ax,[esi-2] ; xchg al,ah ; xor ax,bx ; neg ax ; sub ax,0xadde ; not ax ; xor bx,ax
lea esi,[esi-2] ; sub ebp,2 ; mov [ebp],ax
```
行内 16 位立即数（`xchg al,ah` = 字节序翻转，所以字节码里是大端存放），经 `bx` 密钥解密。栈：-2。

**vPushImmSx2 · 0x82B5AD · slots 105,125,128,199,228 —— 2 字节立即数符号扩展入栈**
```
movzx ax,[esi-2] ; xchg al,ah ; xor ax,bx ; neg ax ; sub ax,0xadde ; not ax ; xor bx,ax
cwde ; sub ebp,4 ; mov [ebp],eax
```
同上，最后 `cwde` 把 16 位**符号扩展成 32 位**再压栈。栈：-4。

**vPushImmSx1 · 0x82A15F · slots 140,210,254 —— 1 字节立即数符号扩展入栈**
```
movzx eax,[esi-1] ; add al,bl ; inc al ; rol al,5 ; neg al ; add bl,al
cbw ; cwde ; sub ebp,4 ; mov [ebp],eax
```
1 字节立即数 → `cbw;cwde` 两级符号扩展 → 32 位压栈。栈：-4。

**vPushImm4 · 0x82B30D · slots 4,146 —— 4 字节立即数入栈**
```
mov eax,[esi-4] ; bswap eax ; lea esi,[esi-4] ; sub eax,ebx ; inc eax ; neg eax
sub eax,0x6028c171 ; sub ebx,eax ; sub ebp,4 ; mov [ebp],eax
```
行内 **32 位**立即数，`bswap` + `ebx` 密钥解密。这条同时说明**指令长度可变**（有 4 字节立即数形态）。栈：-4。

**vJmp · 0x82BF44 · slots 106 —— VM 内跳转**
```
mov esi,[ebp] ; add ebp,4 ; mov ebx,esi ; add esi,[ebp] ; mov al,[esi-1] ; dec esi ; add al,bl
```
从栈上取一个新地址写进 `esi`（并 `ebx=esi` 重置密钥），接着弹第二个值加到 `esi` 上 → **跳进另一段字节码**。这是 VM 内部 `jmp`/`call` handler。栈：-8。

**vJmp · 0x82B4D1 · slots 137,153,193,209 —— VM 内跳转（变体）**
与上面同形，只是入口先经 `0x82C7A8`（`mov esi,[ebp]` 的另一份拷贝）。栈：-8。

### 加载 LOAD（10 个）

**vReadMemDs1 · 0x82C79B · slots 11,223 —— 读 1 字节（绝对地址）**
```
mov edx,[ebp] ; add ebp,2 ; mov al,[edx] ; mov [ebp],ax
```
栈顶 4 字节地址 → 读 1 字节 → 用 2 字节槽存回。**原地替换**（先 `add ebp,2` 再写 `[ebp]`，正好落在旧地址槽的低半）。栈：净 +2（4 字节地址被 2 字节值覆盖）。

**vReadMemDs1 · 0x82A1B3 · slots 109,185,219 —— 读 1 字节（索引寻址）**
```
... 解密链 ... ; mov al,[eax+edi] ; sub ebp,2 ; mov [ebp],ax
```
地址不是从栈上取，而是**字节码里的加密偏移**（解密后 `eax`）加上 `edi`（VM 内存基址）。栈：-4。

**vReadMemSs1 · 0x82C9D3 · slots 24,46,56 —— 读 1 字节（`ss:` 变体）**
```
mov edx,[ebp] ; add ebp,2 ; mov al,ss:[edx] ; mov [ebp],ax
```
同族另一份拷贝，段前缀显式写成 `ss:`。

**vReadMemDs2 · 0x82A6DC · slots 22,39,58,68,89,205,212 —— 读 2 字节（绝对地址）**
```
mov eax,[ebp] ; add ebp,2 ; mov ax,[eax] ; mov [ebp],ax
```

**vReadMemDs2 · 0x82BABD · slots 9,64,113,118,242 —— 读 2 字节（索引寻址）**
```
... 解密链 ... ; mov ax,[eax+edi] ; sub ebp,2 ; mov [ebp],ax
```

**vReadMemSs2 · 0x82B950 · slots 101,120,155,235,247 —— 读 2 字节（`ss:` 变体）**
```
mov eax,[ebp] ; add ebp,2 ; mov ax,ss:[eax] ; mov [ebp],ax
```

**vReadMemDs4 · 0x82BCB6 · slots 59,225,243 —— 读 4 字节（绝对地址）**
```
mov eax,[ebp] ; mov eax,[eax] ; mov [ebp],eax
```
栈顶地址 → 读 4 字节 → 原位写回。栈：0。

**vReadMemDs4 · 0x82A203 · slots 77,94,115,171,216 —— 读 4 字节（索引寻址）**
```
... 解密链 ... ; mov edx,[eax+edi] ; sub ebp,4 ; mov [ebp],edx
```

**vReadMemSs4 · 0x82CAEA · slots 102,121,211 —— 读 4 字节（`ss:` 变体）**
```
mov eax,[ebp] ; mov eax,ss:[eax] ; mov [ebp],eax
```

**vReadMemFs4 · 0x82BD38 · slots 15,54,122,160,207,224 —— 读 FS:[addr]（TEB / SEH 链）**
```
mov eax,[ebp] ; mov eax,fs:[eax] ; mov [ebp],eax
```
读 TEB 内偏移 —— 典型 `fs:[0x30]`(PEB)、`fs:[0]`(SEH) 访问。栈：0。

### 存储 STORE（11 个）—— 注意 `add ebp,N` 在写回**之前**，说明"弹地址+弹值、结果不回写"

**vWriteMemDs1 · 0x82A612 · slots 0,38,206,233,234 —— 写 1 字节**
```
mov eax,[ebp]     ; 地址 dword
mov dl,[ebp+4]    ; 值 byte（占 2 字节槽）
add ebp,6         ; 弹出 6 字节
mov [eax],dl
```

**vWriteMemDs1 · 0x82BC37 · slots 23,78,110,168,169,184,253 —— 写 1 字节（索引寻址）**
```
解密链 → mov dx,[ebp] ; add ebp,2 ; mov [eax+edi],dl
```

**vWriteMemSs1 · 0x82A63D · slots 10,83,249 —— 写 1 字节（`ss:` 变体）**
指令序列不同（入口走 `0x82B346`），语义同上，写 `ss:[eax]`。

**vWriteMemDs2 · 0x82C08A · slots 198,232,250 —— 写 2 字节**
```
mov eax,[ebp] ; mov dx,[ebp+4] ; add ebp,6 ; mov [eax],dx
```

**vWriteMemDs2 · 0x82C15E · slots 61,165 —— 写 2 字节（索引寻址）**
```
解密链 → mov dx,[ebp] ; add ebp,2 ; mov [eax+edi],dx
```

**vWriteMemSs2 · 0x82A190 · slots 32,96,135,178,192,204 —— 写 2 字节（`ss:` 变体）**
```
mov eax,[ebp] ; mov dx,[ebp+4] ; add ebp,6 ; mov ss:[eax],dx
```

**vWriteMemDs4 · 0x82B54A · slots 136,154,167,226 —— 写 4 字节**
```
mov eax,[ebp] ; mov edx,[ebp+4] ; add ebp,8 ; mov [eax],edx
```

**vWriteMemDs4 · 0x82AB04 · slots 31,48,116,147,176 —— 写 4 字节（索引寻址）**
```
解密链 → mov edx,[ebp] ; add ebp,4 ; mov [eax+edi],edx
```

**vWriteMemSs4 · 0x82A9E8 · slots 28,45,158 —— 写 4 字节（`ss:` 变体）**
```
mov eax,[ebp] ; mov edx,[ebp+4] ; add ebp,8 ; mov ss:[eax],edx
```

**vWriteMemEs4 · 0x82BEC5 · slots 40,81,98,200,220 —— 写 4 字节（`es:` 变体）**
```
mov eax,[ebp] ; mov edx,[ebp+4] ; add ebp,8 ; mov es:[eax],edx
```

**vWriteMemFs4 · 0x82C0E7 · slots 103,162 —— 写 FS:[addr]（装 SEH / 改 TEB）**
```
mov eax,[ebp] ; mov edx,[ebp+4] ; add ebp,8 ; mov fs:[eax],edx
```
和 `vReadMemFs4` 配对：VM 里执行的"设置异常处理器 / 改 PEB 字段"。

### 算术 ADD（3 个）—— "就地累加"：结果直接写回第二个操作数槽

**vAdd2 · 0x82AE53 · slots 69,188,255 —— 2 字节加**
```
mov ax,[ebp] ; sub ebp,2 ; add word ptr [ebp+4],ax ; pop [ebp]
```
`[ebp] + [ebp+2] → [ebp+2]`，然后弹 2 字节。栈：-2。

**vAdd4 · 0x82A55A · slots 82,84 —— 4 字节加**
```
mov eax,[ebp] ; add dword ptr [ebp+4],eax ; pop [ebp]
```

**vAdd1 · 0x82A286 · slots 114,161 —— 1 字节加**
```
mov al,[ebp] ; sub ebp,2 ; add byte ptr [ebp+4],al ; pop [ebp]
```
8 位加法**只改低字节**（高位保留），是典型的"窄宽度 = 就地按位宽累加"。

### 逻辑 NOR（3 个）—— 用 `NOT / NOT / AND` 实现（德摩根）

zvm 把 `~a&~b` 记作 `vNor`（而不是 `vAnd`）：真值是 `~(a|b)`，看指令形状才能定名，静态无法只凭"AND"这个助记符下结论。

**vNor4 · 0x82BDF2 · slots 34,47 —— 4 字节**
```
mov eax,[ebp] ; mov edx,[ebp+4] ; not eax ; not edx ; and eax,edx ; mov [ebp+4],eax ; pop [ebp]
```
`~a & ~b = ~(a|b)`。**VM 语义层自己也被混淆**：源码里的 `and`/`or` 都可能落成这个形状，要靠后续消费者才能判定原意。

**vNor2 · 0x82B2A4 · slots 3,12,35,88,92,126,166,172,186,189,244 —— 2 字节（内存式）**
```
not dword ptr [ebp] ; mov ax,[ebp] ; sub ebp,2 ; and word ptr [ebp+4],ax ; pop [ebp]
```
先把栈顶 dword 就地取反，再截低 16 位与下一个操作数相与 —— 与库里 `vNor2` 第一条变体（`NOT DWORD PTR [vESP]; AND WORD PTR [vESP+4],Reg2`）完全同形。

**vNor1 · 0x82A082 · slots 52,60,152,190,197,202,248 —— 1 字节**
```
mov ax,[ebp] ; mov dx,[ebp+2] ; not al ; not dl ; and al,dl ; mov [ebp+4],ax
```
只处理低字节，高位从 `[ebp]` 原样带过来。

### 移位 SHL / SHR / SHLD / SHRD（8 个）

统一形态：`操作数=[ebp]`、`移位量=[ebp+n]`（1 字节）→ `sub ebp,2` → 移位 → 结果写 `[ebp+4]`（覆盖第一个操作数槽）。

**vShl2 · 0x82AD3E · slots 1,8,21,123,131,139,187 —— `shl ax,cl`**
```
mov ax,[ebp] ; mov cl,[ebp+2] ; sub ebp,2 ; shl ax,cl ; mov [ebp+4],ax
```
栈：读 4 字节（2+2），回写 2 字节，净 -2。

**vShl4 · 0x82BCF0 · slots 43,51,151,214,246 —— `shl eax,cl`**
```
mov eax,[ebp] ; mov cl,[ebp+4] ; sub ebp,2 ; shl eax,cl ; mov [ebp+4],eax
```

**vShl1 · 0x82B128 · slots 70 —— `shl al,cl`**
```
mov al,[ebp] ; mov cl,[ebp+2] ; sub ebp,2 ; shl al,cl ; mov [ebp+4],ax
```
只移低字节，高字节从 `[ebp]` 原样带过来（`mov [ebp+4],ax` 搬的是整个 16 位）。

**vShr2 · 0x82C019 · slots 36,66,72,87,180,227 —— `shr ax,cl`**
```
mov ax,[ebp] ; mov cl,[ebp+2] ; sub ebp,2 ; shr ax,cl ; mov [ebp+4],ax
```

**vShr4 · 0x82A301 · slots 143,144,222 —— `shr eax,cl`**
```
mov eax,[ebp] ; mov cl,[ebp+4] ; sub ebp,2 ; shr eax,cl ; mov [ebp+4],eax
```

**vShr1 · 0x82A776 · slots 62,138,148,221 —— `shr al,cl`**
```
mov al,[ebp] ; mov cl,[ebp+2] ; sub ebp,2 ; shr al,cl ; mov [ebp+4],ax
```

**vShld · 0x82C903 · slots 7,63,119,150,217,239 —— 64 位左移取高位**
```
mov eax,[ebp] ; mov edx,[ebp+4] ; mov cl,[ebp+8] ; add ebp,2 ; shld eax,edx,cl ; mov [ebp+4],eax
```
三操作数：`[ebp]`/`[ebp+4]` 组成 64 位值，`[ebp+8]` 是移位量 → 结果只留高位部分（低 32 位被丢弃），说明 VM 的 64 位值是"两个 32 位槽"拼的。

**vShrd · 0x82B37B · slots 37,55,117,141 —— 64 位右移取低位**
```
mov eax,[ebp] ; mov edx,[ebp+4] ; mov cl,[ebp+8] ; add ebp,2 ; shrd eax,edx,cl ; mov [ebp+4],eax
```

### 乘除 MUL / IMUL / DIV / IDIV（7 个）

**vMul2 · 0x82C6E8 · slots 42,100,159 —— `mul dx`**，结果 `dx:ax` 分别写 `[ebp+4]`/`[ebp+6]`（**双结果**），栈 -4。

**vMul4 · 0x82AE7C · slots 108,132,145,237 —— `mul edx`**，`edx:eax` 写 `[ebp+4]`/`[ebp+8]`，栈 -4。

**vImul2 · 0x829FA1 · slots 80,177 —— `imul dx`**（16 位有符号乘，双结果）。

**vImul4 · 0x82A88B · slots 18,53,73,75,90,95,215,230 —— `imul edx`**。

**vDiv2 · 0x82BC81 · slots 25,41,76,170,179 —— `div cx`**，商 `ax`→`[ebp+6]`、余 `dx`→`[ebp+4]`。

**vDiv4 · 0x82A9A9 · slots 13,93,129,134,142,164,195,208 —— `div dword ptr [ebp+8]`**，商/余双写。

**vIdiv4 · 0x82A569 · slots 33 —— `idiv dword ptr [ebp+8]`**。

除法的三操作数布局（被除数 `[ebp]`/`[ebp+4]`、除数 `[ebp+8]`）说明 VM 栈槽是**定宽 4 字节对齐 + 按类型取 2/4 字节**。

### 系统与校验（3 个）—— 反调试 / 反虚拟机

**vCpuid · 0x82BB66 · slots 30,50,112,133 —— CPUID**
```
cpuid ; ebp-=0xc ; [ebp+0xc]=eax(旧) ; [ebp+8]=ebx ; [ebp+4]=ecx ; [ebp]=edx
```
把 `cpuid` 的四个寄存器压栈（`eax` 是 leaf 输入，在执行前保存）。栈：-12。

**vRdtsc · 0x82AE70 · slots 19,127,157,175,240,251 —— RDTSC**
```
rdtsc ; sub ebp,8 ; mov [ebp],edx ; mov [ebp+4],eax
```
时间戳高低 32 位压栈。栈：-8。

**vCheck · 0x82AE17 · slots 57,104,156,203,229,236 —— 内存校验循环（唯一带内层循环的 handler）**
```
mov edx,[ebp] ; add ebp,4 ; xor eax,eax
loop: mov ecx,eax ; shl eax,7 ; shr ecx,0x19 ; or eax,ecx ; xor al,[edx] ; ... dec [ebp] ; jne loop
mov [ebp],eax
```
对 `[edx]` 指向的缓冲做"滚动异或/位混合"直到计数到 0 —— 字符串/校验和/解密循环（`rep` 类语义的软件实现）。

### 控制流出口（3 个）

**vRet · 0x82B4D6 · slots 5,16,85,183 —— VM 出口（恢复 8 个寄存器）**
```
mov esp,ebp ; pop ebx ; pop ebx ; pop ebx ; pop edi ; pop esi ; pop edx ; pop ebp ; pop ecx
... ret 0x30
```
把 `ebp` 直接当 esp 用，连续弹出 8 个寄存器后 `ret 0x30` —— **VM 退出 / 恢复宿主上下文**。走的是另一个分派尾（`0x82A5D7 ret 0x30`）。

**vRet · 0x82A5A8 · slots 29,174,245 —— VM 出口（带 eax 返回值）**
```
mov al,[esi-1] ; ... 解密链 ... ; movzx ecx,al ; mov [ebp-4],ecx ; or ecx,ecx ; je ...
xchg dword ptr [ebp],eax ; ret 0x30
```
先解一个立即数写到 `[ebp-4]`（栈下方的暂存槽），`or ecx,ecx; je` 的两条路最后都汇到 `xchg [ebp],eax; ret 0x30` —— 所以那个 jcc 是**假分支（opaque predicate）**，真正语义是"弹栈顶到 eax，从 `0x82AA51 ret 0x30` 尾回宿主"。

**vRetHost · 0x82B90B · slots 6,20,86,182 —— 返回/回调宿主地址 (扩展名)**
```
mov edx,[ebp] ; add ebp,4 ; ... mov [esp+0x24],edx ; ... ret 0x34
```
把弹出的 dword 写进返回地址槽，`ret 0x34` 直接返回到**宿主代码**（目标由 VM 栈给出）—— 这是 guest 的 `ret` / call-out，和上面两个"整段退出"不是一回事，所以按命名法扩展成 `vRetHost`。

---

## 四、按功能分组的统计

| 族 | 数量 | handler（名字 · 地址） |
|---|---|---|
| STORE | 11 | vWriteMemDs1·82A612、vWriteMemDs1(idx)·82BC37、vWriteMemSs1·82A63D、vWriteMemDs2·82C08A、vWriteMemDs2(idx)·82C15E、vWriteMemSs2·82A190、vWriteMemDs4·82B54A、vWriteMemDs4(idx)·82AB04、vWriteMemSs4·82A9E8、vWriteMemEs4·82BEC5、vWriteMemFs4·82C0E7 |
| LOAD | 10 | vReadMemDs1·82C79B、vReadMemDs1(idx)·82A1B3、vReadMemSs1·82C9D3、vReadMemDs2·82A6DC、vReadMemDs2(idx)·82BABD、vReadMemSs2·82B950、vReadMemDs4·82BCB6、vReadMemDs4(idx)·82A203、vReadMemSs4·82CAEA、vReadMemFs4·82BD38 |
| 栈/取址/立即数/跳转 | 12 | vPushVSp·82C228、vPushVEsp·82A879、vPopVEsp·82A66B、vPopVSp·82B5E0、vPushAddrVSp·82A6ED、vPushImm1·82BF8E、vPushImm2·82AF52、vPushImmSx2·82B5AD、vPushImmSx1·82A15F、vPushImm4·82B30D、vJmp·82BF44、vJmp·82B4D1 |
| 移位 | 8 | vShl1/2/4、vShr1/2/4、vShld、vShrd |
| 乘除 | 7 | vMul2·82C6E8、vMul4·82AE7C、vImul2·829FA1、vImul4·82A88B、vDiv2·82BC81、vDiv4·82A9A9、vIdiv4·82A569 |
| 算术 ADD | 3 | vAdd1·82A286、vAdd2·82AE53、vAdd4·82A55A |
| 逻辑 NOR | 3 | vNor1·82A082、vNor2·82B2A4、vNor4·82BDF2 |
| 系统/校验 | 3 | vCpuid·82BB66、vRdtsc·82AE70、vCheck·82AE17 |
| 控制流出口 | 3 | vRet·82B4D6、vRet·82A5A8、vRetHost·82B90B |

合计 11+10+12+8+7+3+3+3+3 = 60。

### 由此还原的 VM 指令集形态

- **宽度分级**：byte / word / dword 三档，`add/shl/shr/nor` 都有三档；`mul/div` 有 word/dword；`shld/shrd` 处理 64 位跨双字。
- **寻址方式两种**：
  1. **栈寻址**（地址来自 `[ebp]`）—— 大多数 LOAD/STORE，名字不带后缀；
  2. **字节码内嵌偏移**（加密在 bytecode 里，解密后 `+edi` 得到地址）—— 标 `(idx)`，共 6 个 handler。
- **段前缀是"语法糖"**：`ss:/es:/fs:` 各有独立实现，但只有 `fs:` 是真正的功能性访问（TEB/SEH），`ss:/es:` 只是同一语义的不同编码。
- **没有寄存器文件**：所有数据都在 `[ebp±k]` 的栈槽里，槽宽按类型 2/4 字节。
- **每条 guest 指令 = 一个 handler**，handler 尾部自带下一 opcode 的解密 + 查表（threaded code），因此 256 个槽 → 60 个实现是"编码别名"，不是漏分析。
