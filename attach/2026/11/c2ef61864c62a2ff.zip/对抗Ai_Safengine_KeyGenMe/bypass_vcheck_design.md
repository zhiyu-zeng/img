# Bypass Safengine 2.x vCheck —— DLL 注入 + Handler Hook 设计（第二版）

目标样本：`Safengine授权对抗Ai.exe`（x86，基址固定 `0x400000`，`RELOCS_STRIPPED`，无 ASLR，`SizeOfImage` = 0x42E000 ≈ 4.2 MB）
被绕对象：VM 指令 `vCheck` = handler `0x82AE17`（表 `0x82C279` 的槽 57/104/156/203/229/236）
交付物：注入器 + 被注入的 `bypass_checker.dll`

> **部署方式已定（v3）**：不再用独立注入器 / `LoadLibrary` / 远程线程，改成
> **插件在 `CB_CREATEPROCESS` 里手工映射**（manual map）：把 DLL 在本地拉伸好、
> 修好重定位与导入表，`VirtualAllocEx` + 整块写入目标，然后把导出地址写进
> `0x82AE17` 的 5 字节 `E9`。实现见 `vmpdump/vmp_mapdll.h`（算法注释在文件头）。
> 本文 §3、§4 里"launcher + LoadLibrary"的时序描述已被这一步取代，其余
> （契约、hook 点、影子快照、BypassChecker、验证）不变。
>
> **实际落地再进一步（v4，已实现）**：`bypass_checker.dll` 也不需要了。插件
> （`vmpdump/safengine2.x_bypassvchk.cpp`，菜单 `Safengine2.x -> BypassVChecker`）在**点菜单时**
> 现场生成一段 135 字节的 x86 桩写进目标，桩自己完成"影子快照重算 h → 写回
> `[ebp+4]` → `ebp += 4` → 跳 `0x829FB7`"，全程不占用线程、不打断目标：
>
> - 快照的**代码节取磁盘文件的原始字节**（点菜单时目标早就在跑，当时内存里可能
>   已经有用户下的 `0xCC`；文件里的才是"原本长什么样"），**数据节取运行期内存**
>   （那些是运行期填的，拿文件反而算错）。§6.1 "注入瞬间整镜像拷贝"的前提在这里
>   不成立，用这条替代；
> - 桩把 `hits` / `last{ptr,len,h}` / 最近 16 条 ring 记在配置页里，再点一次菜单
>   就把它们打出来 —— §8 要的"每次命中一行日志"用它实现，不需要轮询；
> - 桩的机器码在安装前会先在本进程里用同一份字节跑一遍自检（影子字节 / 模块外读
>   实时 / 寄存器与栈 / 不写被校验区），不过就拒绝安装；
> - 卸载（插件 `plugstop`）会把 5 字节还原；若确认不了目标已不再指向桩，则**故意
>   泄漏**那块内存而不是留一条跳向已释放页的 `E9`。
>
> **v5（改快照口径）**：上面"代码节取磁盘文件"那条在真机上被推翻了一半。实测代码节与
> 运行期有 55 处不同，集中在 `模块+0x23B000`，值形如 `文件=0x00239A7E` / `内存=0x754AE840`
> —— 那是 **IAT 被 loader 填过**（文件里是 hint/name 的 RVA，运行期是真实函数地址），
> 不是代码被改写。拿文件值当"真相"，一旦校验区间扫到这类地址就会算错。
> 现在改成：**运行期内存为准，只回退两类补丁** —— 调试器的 `0xCC`（live==CC 且 file!=CC）
> 和我们自己打在 handler 上的 `E9`（5 字节还原为 `66 01 D1 D2 E5`）。
> 同时桩会一次命中算两个值：`h_shadow`（返回给 VM 的）和 `h_live`（同一算法读实时内存），
> 插件再用 Unicorn 把原 handler 真跑一遍得 `h_real`，三者写进
> `<exe 目录>\safechk_vcheck.log`（后台线程每 150ms 追加），用来判定"值到底对不对"。

> **v6（真机多轮日志后的定型，当前实现）**：v5 那条"运行期镜像 + 回退 0xCC"又踩了两个坑，
> 现已改成**回退表**（不再是镜像副本）：
>
> 1. **hook 点自身会污染校验区间**：实测 `#8 ptr=0082A7E0 len=8980` 覆盖到 `0x82AE17`，
>    桩读实时内存会把我们的 `E9 + rel32` 算进哈希（`h_shadow=A0B24ABD`），而 Unicorn
>    跑原 handler 得到 `20C32751` —— 这就是 `File corrupted` 的直接来源。
>    现在桩按地址范围认出自身 5 字节补丁并取回退表里的 `66 01 D1 D2 E5`，
>    修完实测 `h_shadow = h_real = 20C32751`。
> 2. **解密后的代码里本来就有合法的 `0xCC`**：旧规则"live==0xCC 就回退"会把它们
>    换成安装时的旧值，产生 `#33 / #35` 的 `★不一致`。现在回退表**默认填 `0xCC`
>    （= 不回退）**，只登记两类补丁：安装时确认的调试器 INT3（`live==CC && file!=CC`，
>    填文件原始字节）和自身 E9 的 5 字节（填原始指令）。其余一律读实时内存 ——
>    IAT、重定位、自修改、边解密边校验的区间全部由此覆盖。
>
> 桩 188 字节；目标侧 ring 扩到 1024 条只作传输缓冲，插件侧**逐条落盘、不截断**，
> 轮询 20ms；`h_real` 的 Unicorn 仿真改为 `count=0`（无指令上限）+ 3 秒超时兜底，
> 模块外采样不全时明确报错而不是给出误导性的 `00000000`。
> 校准版 `C:\tmp\safechk\stub_v4.py`（Unicorn 8 用例全过）与 C++ 生成字节
> 经 `cmp_v4.py` 逐字节比对 IDENTICAL。
>
> **真机验证通过（v6）**：一次启动 63 次命中，模块内全部
> `h_shadow == h_live == h_real`（含此前的 `#8` / `#33` / `#35`），
> **不再出现 `File corrupted`**。仅剩 5 条 `h_real=模拟失败` 属参考值侧限制：
> 4 条模块外区间在事后采样时已不可读（日志明确 `got=0/N`）、1 条 `len≈1.9MB`
> 的超大区间仿真超时；这些条目 `h_shadow == h_live` 已证明返回值正确。

---

## 0. 一句话方案

注入器 `CreateProcess(SUSPENDED)` 拉起目标，远程 `LoadLibrary` 送进 `bypass_checker.dll`；DLL 在目标**第一条指令执行之前**完成两件事：

1. 把整个主模块镜像（4.2 MB）快照到自己的内存；
2. 在 `0x82AE17` 写 5 字节 `E9 rel32`。

此后每次进入 `vCheck`，钩子用**快照字节**重算校验值（不管区间里被谁改成了什么），写回 VM 栈槽，直接跳回分派头 `0x829FB7`。原 handler 一行不执行，断点随便下。

---

## 1. 被绕对象的契约（全部实测）

| 项 | 值 | 依据 |
|---|---|---|
| handler 入口 | `0x0082AE17`（绝对 VA；RVA `0x42AE17` = 0x82AE17 − 0x400000） | 表项 dump + CFG |
哪来的0x42AE17，0x82AE17就是绝对地址
0082AE17       | 66:01D1                        | add cx,dx                                                          | vCheck
0082AE1A       | D2E5                           | shl ch,cl                                                          |
0082AE1C       | 0FBDD3                         | bsr edx,ebx                                                        | edx:EntryPoint
0082AE1F       | 8B55 00                        | mov edx,dword ptr ss:[ebp]                                         | edx:EntryPoint
0082AE22       | 8D0CED 1A296217                | lea ecx,dword ptr ds:[ebp*8+1762291A]                              | ecx:EntryPoint
0082AE29       | 8D8C24 FFA5F627                | lea ecx,dword ptr ss:[esp+27F6A5FF]                                | ecx:EntryPoint
| 所在节 | `.vmp1`，文件偏移 `0x1F2417`，**文件里就是明文** `66 01 D1 D2 E5` | PE 节表 + 静态反汇编与运行期逐字节一致 |
| 参数 1 | `[ebp]` = 缓冲区 VA（dword） | Unicorn 喂参验证 |
| 参数 2 | `[ebp+4]` = 字节数（dword） | 同上 |
| 算法 | `h = XOR(i=0..n-1) rol32(b[i], 7*(n-1-i))` | 7 组向量全中（n=1/3/5/16/32/64/256） |
| 中间状态 | `eax` 每轮 `rol 7`，`xor al,[edx]`，`edx` 每轮 +1 | 反汇编 + 单步 |
| 结果位置 | `ebp += 4` 后写 `[ebp]`（即原 `[ebp+4]` 槽） | `0x82AEC9 mov [ebp],eax` |
| 出口 | `0x829FB7`（共享分派头） | 所有 handler 的收敛点 |
| 宿主栈 | 净变化 0 | 去混淆时把 `esp` 当观察点校验过 |
| 边界 | `n = 0` → `dec` 得 `0xFFFFFFFF` → 约 42.9 亿次循环（挂死） | 反汇编 + 局部仿真 |

两点直接影响设计的事实：

- **`0x82AE17` 不需要等解密**：它在 `.vmp1` 里已是明文，静态字节与运行期逐字节一致。所以"镜像一映射就能打补丁"，不必做"等内容匹配再装"的闸门。
- **`vCheck` 在整段 trace 里 0 命中**：它不是热路径指令，而是延迟/条件触发（授权校验、定时自检那一类）。`(ptr, len)` 只有运行期才知道，所以 hook 必须按参数自适应。

---

## 2. 为什么唯一位置是 handler 入口

- 改字节（INT3）本身就是它要抓的东西：`h` 覆盖 `[ptr, ptr+n)`，插一个 `0xCC` 结果就变。
- guest 侧的比较点定位不了：要知道比较在哪，先得知道这次 `ptr/len`，而它可能几分钟后才第一次跑。
- 只有 handler 入口是"参数已就位、结果未产生"的唯一收敛点：进门前两个参数压在 VM 栈上，出门后结果写回固定槽位。接管这里，既不需要知道校验目标，也不需要知道比较逻辑。

---

## 3. 组件架构

```
launcher.exe
  ├─ CreateProcess(target, CREATE_SUSPENDED)
  ├─ 远程 LoadLibraryW("bypass_checker.dll")
  ├─ WaitForSingleObject(g_hReady)      // 快照 + hook 都已完成
  └─ ResumeThread                        // 此刻才允许目标执行第一条指令

bypass_checker.dll
  ├─ DllMain        只 CreateThread(init) 后返回（不碰 loader lock 重活）
  ├─ init           取模块基址 → 快照镜像 → 写 5 字节 hook → SetEvent(g_hReady)
  ├─ Snapshot       注入瞬间的整模块镜像副本（唯一"真相"来源）
  ├─ HookEngine     0x82AE17: E9 rel32 → trampoline（自有可执行页）
  └─ BypassChecker  命中时：读参 → 快照重算 → 写回 → 跳 0x829FB7
```

四块职责边界清楚：`Snapshot` 负责"原始值是什么"，`HookEngine` 负责"控制流能不能进来"，`BypassChecker` 负责"答案算得对不对"，`init` 负责"顺序"。

---

## 4. 时序：一个事件就够，不需要轮询

### 4.1 为什么"注入即生效"成立

`CreateProcess(CREATE_SUSPENDED)` 返回时，Windows 已经完成：映射 exe 镜像、映射 ntdll、建立初始线程——但初始线程停在 `LdrInitializeThunk` **之前**，`main`、TLS 回调、Safengine 的 VM 都还没跑。

而 `0x82AE17` 所在 `.vmp1` 在文件里就是明文（§1），映射后立即可读写。于是：

```
注入 (LoadLibrary)  →  镜像已映射、字节已就位  →  init 线程快照 + patch  →  SetEvent  →  ResumeThread
```

`ResumeThread` 之后目标才开始执行；第一次 `vCheck` 必然看到 `E9`。**保证来自"目标还没开始跑"，而不是"我们抢在它前面跑得快"。**

### 4.2 一次性自检（不是闸门）

`init` 在 patch 前读 5 字节，与 `66 01 D1 D2 E5` 比对：

- 相等 → 正常安装；
- 不等 → 说明该变体的 `.vmp1` 确实加密过（本样本不是），此时才降级为"每 2 ms 轮询、匹配即装"的慢路径，并记日志。

也就是说：主路径是**直装**，慢路径只为兼容别的 Safengine 构建，不参与本样本的时序保证。

### 4.3 并发

`vCheck` 可能在任意线程执行，而 5 字节写入不是原子的。安装时枚举其他线程 `SuspendThread` → 写 → `ResumeThread`；`ResumeThread` 之前目标本来就没在跑，所以这一步只是对"慢路径重装"兜底。

BypassChecker 自身只读 VM 栈、只写一个 dword，天然可重入，不需要锁。

### 4.4 ASLR

本样本 `RELOCS_STRIPPED=1` + `DYNAMICBASE=0`，基址恒 `0x400000`；代码里仍按 RVA `0x42AE17` + `GetModuleHandleW(NULL)` 计算，兼容开启 ASLR 的变体。

---

## 5. Hook 引擎：这个点刚好 5 字节

| 地址 | 字节 | 指令 | 长度 |
|---|---|---|---|
| `0x82AE17` | `66 01 D1` | `add cx, dx` | 3 |
| `0x82AE1A` | `D2 E5` | `shl ch, cl` | 2 |

两条合计正好 5 字节，一条 `E9 rel32` 整覆盖，不需要拆分指令：

- 原地写 `E9 rel32`（`rel32 = hook - 0x82AE17 - 5`）；
- trampoline 拷这两条，然后 `jmp 0x82AE1C`（`bsr edx, ebx`），保证"绕开 hook 走原逻辑"也能跑；
- 这两条只碰 `cx`/标志，而 handler 后面 `xor eax,eax` 会重设标志、`mov ecx,eax` 会重设 `ecx`，即使不执行也无副作用——但仍照抄，保持最小惊讶。

实现要点：

- `.vmp1` 属性通常是 `PAGE_EXECUTE_READ`：`VirtualProtect(RWX)` → 写 → 改回；
- x86 无指令缓存一致性问题，`FlushInstructionCache` 可选；
- trampoline 放在自有可执行页，**不落在主模块里**（它不属于镜像、也不该被任何快照覆盖）；
- 被覆盖的 5 个原始字节不需要单独登记 —— 全镜像快照里本来就有（§6）。

---

## 6. 影子 = 注入瞬间的全镜像快照

### 6.1 数据结构

```
snap_base : 主模块基址（如 0x400000）
snap_size : SizeOfImage（0x42E000）
snap      : void*  // VirtualAlloc(snap_size)，memcpy(模块基址, snap_size)
```

`init` 在 patch **之前**做这次拷贝。此后 `snap` 就是"这个模块原本长什么样"的唯一真相。

### 6.2 查询与哈希

```
shadow_byte(addr):
    if snap_base <= addr < snap_base + snap_size:
        return snap[addr - snap_base]        // 镜像内：一律用原始字节
    return *(BYTE*)addr                      // 镜像外（堆/栈/别的模块）：读实时内存

shadow_hash(ptr, n):
    h = 0
    for i in 0..n-1:
        h = rol32(h, 7) ^ shadow_byte(ptr + i)
    return h
```

这就是"认所有改动"的全部实现——**没有登记表，没有 `MarkBreakpoint`**。因为不看"谁改了什么"，只看"这个地址在镜像里本来是什么"：

| 改动来源 | 处理 |
|---|---|
| 我们的 5 字节 `E9` | 镜像内 → 用快照里的 `66 01 D1 D2 E5` |
| 调试器的 `0xCC`（任意数量、任意工具） | 同上，自动还原成原字节 |
| 其它插件的补丁 / 内存断点 / hook | 同上 |
| 堆、栈、非主模块 | 直接读实时内存（这些本来就不是"镜像里的东西"） |

所以连"`0x82AE17` 自己就在被校验区间里"这种最坏情况都自动成立：钩子进入时区间里有 `E9`，快照把 5 字节还原成原值，`h` 与未 hook 时完全相同。

### 6.3 正确性前提（已对本样本验证）

快照法的正确性依赖一句：**被校验区间在运行期不再被程序自己改写**。

本样本满足：`.vmp1` 里的 code 静态字节 == 运行期字节（60 个 handler 的首指令逐一比对一致，`0x82AE17` 本身也一致）。若将来遇到"边解密边校验"的变体，把该区间从快照里挖掉（`MarkLiveRange`）即可，其余逻辑不变。

---

## 7. BypassChecker：命中之后做什么

```c
// 进入时：ebp 指向 VM 栈顶，[ebp]=ptr，[ebp+4]=len
static void on_vcheck(void)
{
    uint32_t ebp = get_reg(REG_EBP);
    uint32_t ptr = read32(ebp);          // 校验区间
    uint32_t len = read32(ebp + 4);      // 字节数

    uint32_t h = shadow_hash(ptr, len);  // 快照重算，天然忽略一切补丁

    write32(ebp + 4, h);                 // 与 0x82AEC9 的写点一致
    set_reg(REG_EBP, ebp + 4);           // 与 handler 的 add ebp,4 一致
    set_reg(REG_EIP, 0x829FB7);          // 回分派头，跳过整个 handler
}
```

三处必须精确对齐：写 `[ebp+4]`（不是 `[ebp]`）、`ebp` 加 4、跳 `0x829FB7`。这三件事做完，VM 看到的状态与"原 handler 正常执行完"逐字节相同。

边界与细节：

- `len == 0`：原始 handler 会 `dec` 成 `0xFFFFFFFF`（42.9 亿次循环、挂死）。钩子按"0 次迭代 → `h = 0`"返回并记日志。
- 标志位：钩子用 `pushfd/popf` 包裹，不改变调用者标志。跳过 handler 后 `EFLAGS` 停在钩子状态，与"执行过 handler"不同；从分派链看这不构成风险（每个 handler 入口都会重新解码并重设标志，链中另有成对 `pushfd/popfd`）——这一条是推断，验证时把 `EFLAGS` 一并纳入日志对比。
- 钩子内不做任何内存分配、不加锁、不调 CRT：`vCheck` 可能在任意线程、任意时机进来。

---

## 8. 日志与验证

每次命中打一行：`ptr`、`len`、`h`、线程 ID。前 20 行就够回答"Safengine 到底在校验哪一段"。

三步验证：

1. **基线**：不打任何断点跑一遍，记 `(ptr, len, h)` 序列；
2. **带断点**：在日志给出的 `ptr ~ ptr+len` 里下几个 INT3，再跑一遍，`h` 序列必须**完全一致**（直接证明 bypass 成立）；
3. **边界**：构造 `len == 0`，确认不挂死且有日志。

因为快照法不看补丁来源，第 2 步可以随便换工具打点（x64dbg / 别的插件 / 手工写 `0xCC`），结果都应一致——这也是"认所有改动"最容易验收的地方。

---

## 9. 实测数据

算法命中情况（Unicorn 在真实地址跑整段链，`[ebp]=buf, [ebp+4]=n`）：

| n | 实测 `eax` / `[ebp+4]` | 模型 `h` |
|---|---|---|
| 1 | `00000041` | `00000041` |
| 3 (`"abc"`) | `00187163` | `00187163` |
| 5 (`01..05`) | `1040C205` | `1040C205` |
| 32 (`00..1F`) | `D79D2862` | `D79D2862` |
| 256 (`00..FF`) | `00000000` | `00000000` |

对 XOR 线性：`h(01 02 03 04)=00208184`、`h(10 20 30 40)=02081840`、`h(11 22 33 44)=022899C4`，且 `h(a)^h(b) == h(a^b)`。快照法用不到这条，但它解释了"为什么单点补偿也能修"（`rol(orig^0xCC, 7*(n-1-i))`，16 字节 + 3 个断点实测吻合）。

一个必须知道的历史坑：**去混淆产物 `asm\0x82AE17.asm` 里看不到 `inc edx`**（真实位置 `0x82B191`），它被活跃性分析误判为死代码删掉了，因为回边没建模。写 hook 以原始字节为准，别拿去混淆 asm 当完整指令表。

---

## 10. ScyllaHide / SharpOD 是怎么做的

| | ScyllaHide | SharpOD |
|---|---|---|
| 形态 | 调试器插件（x64dbg / OllyDbg）+ 独立注入器 | OllyDbg 插件 |
| 住哪 | 调试器进程里 | 调试器进程里 |
| 改目标的途径 | 调试 API / `WriteProcessMemory` 从外部改；无调试器时用自带注入器（suspended + `LoadLibrary`） | 同左 |
| 打什么 | anti-debug 的 **API 层**：`NtQueryInformationProcess`、`PEB.BeingDebugged`、DR 寄存器、时间检查等 | 同左，kernel32/ntdll inline hook |

结论：

1. 它们改的是 API，不是 VM 指令。`vCheck` 是字节码里的一条校验指令，不经过任何 ntdll/kernel32 调用，那套 API hook 对它无效。
2. 它们的注入部分和本方案同构（suspended → 注入 → 恢复），只是"注入之后干什么"换成了 hook VM handler。
3. 它们的时序思路值得抄：不靠"等程序跑到"，靠"进程还没开始跑就把钩子装好"。本方案再做实一层——因为 `.vmp1` 是明文，连内容匹配都不需要。

---

## 11. 前提与边界

- **32 位限定**：5 字节相对跳转是 x86 的便利；x64 需要 12~14 字节绝对跳转或 `push imm32; ret`。
- **快照时机是唯一硬约束**：必须在"目标执行第一条指令之前"完成拷贝（suspended 注入天然满足）。若在目标跑起来后再注入，快照可能已包含它自己的运行时改写，那时才需要逐区间处理。
- **只覆盖 `vCheck`**：同一套 VM 还有 `vCpuid`(0x82BB66)、`vRdtsc`(0x82AE70)、`vReadMemFs4`(0x82BD38) 这些反调试/反虚拟机抓手，它们不走校验值，需要各自实现（例如让 `vCpuid` 返回物理机的干净结果）。
