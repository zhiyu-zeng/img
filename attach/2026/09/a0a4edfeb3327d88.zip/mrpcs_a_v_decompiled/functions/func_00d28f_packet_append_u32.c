uint64_t packet_append_u32(void* arg0, uint64_t arg1, uint64_t arg2) {
    local_24 = (arg2 & 0x1);
    if (((int32_t)((*(uint32_t *)(arg0 + 0x10) - *(uint32_t *)(arg0 + 0x14)))) > 4) {
        local_28 = 0x0;
        if (local_24 & 0x1) {
            local_28 = bswap32(arg0, arg1);
        }
        *(uint32_t *)(*(uint64_t *)(arg0) + (int64_t)(*(uint32_t *)(arg0 + 0x14))) = local_28;
        *(uint32_t *)(arg0 + 0x14) = (*(uint32_t *)(arg0 + 0x14) + 0x4);
        result = 0x1;
    } else {
        result = 0x0;
    }
    return result;
}
