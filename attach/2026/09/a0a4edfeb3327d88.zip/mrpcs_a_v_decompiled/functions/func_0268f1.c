uint64_t vm_func_0268f1(uint64_t arg0) {
    local_0 = arg0;
    result = 0x1505;
    while (*(uint8_t *)(local_0) != 0x0) {
        local_0 = (local_0 + 0x1);
        result = (result + ((result << 0x5) + *(uint8_t *)(local_0)));
        continue;
    }
    return result;
}
