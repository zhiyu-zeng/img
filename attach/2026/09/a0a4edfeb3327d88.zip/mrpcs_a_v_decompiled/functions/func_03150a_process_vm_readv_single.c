int64_t process_vm_readv_single(int32_t pid, void* local_buffer, uint64_t remote_address, uint64_t size) {
    uint8_t* stack_buf_020 = (uint8_t*)(fp + 0x20); /* observed >= 0x20 bytes */
    memset(stack_buf_020, 0x0, 0x20);
    *(uint64_t *)(stack_buf_020 + 0x8) = size;
    *(uint64_t *)(stack_buf_020 + 0x10) = remote_address;
    *(uint64_t *)(stack_buf_020 + 0x18) = size;
    return syscall_process_vm_readv(pid, stack_buf_020, 0x1, (stack_buf_020 + 0x10), 0x1, 0x0);
}
