uint64_t packet_append_u16(void* arg0, uint64_t arg1, uint64_t arg2) {
    local_28 = arg1;
    local_2a = (arg2 & 0x1);
    if (((int32_t)((*(uint32_t *)(arg0 + 0x10) - *(uint32_t *)(arg0 + 0x14)))) > 2) {
        if (local_2a & 0x1) {
            local_28 = bswap16(arg0, local_28);
        }
        *(uint16_t *)(*(uint64_t *)(arg0) + (int64_t)(*(uint32_t *)(arg0 + 0x14))) = local_28;
        *(uint32_t *)(arg0 + 0x14) = (*(uint32_t *)(arg0 + 0x14) + 0x2);
        result = 0x1;
    } else {
        result = 0x0;
    }
    return result;
}
