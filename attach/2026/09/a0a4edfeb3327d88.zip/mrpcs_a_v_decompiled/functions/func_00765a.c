void vm_func_00765a(uint64_t arg0, uint64_t arg1, uint64_t arg2) {
    vm_func_007ac9(arg0, arg1);
    vm_func_007b2d(arg1);
    return;
}
