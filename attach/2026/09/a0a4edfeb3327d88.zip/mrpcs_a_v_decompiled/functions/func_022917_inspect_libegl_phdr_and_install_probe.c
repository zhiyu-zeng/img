uint64_t inspect_libegl_phdr_and_install_probe(const char* arg0) {
    struct { uint64_t field_00; uint64_t field_08; uint64_t field_10; } local_obj_078;
    struct { uint64_t field_00; uint64_t field_08; uint64_t field_10; } local_obj_0d0;
    struct { uint64_t field_00; uint64_t field_08; uint64_t field_10; } local_obj_130;
    struct { uint64_t field_00; uint64_t field_08; uint64_t field_10; } local_obj_188;
    if (strstr(*(uint64_t *)(arg0 + 0x8), "libEGL.so") == 0x0) {
        result = 0xffffffff;
    } else {
        thread_probe_status = 0x1;
        local_70 = vm_func_024292(arg0);
        if (local_70 == 0x0) {
            result = 0x0;
        } else {
            thread_probe_status = 0x2;
            local_obj_078.field_00 = ((fp + 0x78) + 0x18);
            local_obj_078.field_08 = 0x0;
            local_obj_078.field_10 = 0x8;
            memset(((fp + 0x78) + 0x18), 0x0, 0x40);
            local_obj_0d0.field_00 = ((fp + 0xd0) + 0x18);
            local_obj_0d0.field_08 = 0x0;
            local_obj_0d0.field_10 = 0x8;
            memset(((fp + 0xd0) + 0x18), 0x0, 0x40);
            ptr_128 = vm_func_0246da(local_70, "eglSwapBuffers", 0x0, &local_obj_078, &local_obj_0d0);
            if (ptr_128 != 0x0) {
                egl_module_span = *(uint32_t *)(ptr_128 + 0x10);
            }
            local_obj_130.field_00 = ((fp + 0x130) + 0x18);
            local_obj_130.field_08 = 0x0;
            local_obj_130.field_10 = 0x8;
            memset(((fp + 0x130) + 0x18), 0x0, 0x40);
            local_obj_188.field_00 = ((fp + 0x188) + 0x18);
            local_obj_188.field_08 = 0x0;
            local_obj_188.field_10 = 0x8;
            memset(((fp + 0x188) + 0x18), 0x0, 0x40);
            local_1e0 = vm_func_0246da(local_70, "atrace_get_enabled_tags", 0x0, &local_obj_130, &local_obj_188);
            if (local_1e0 == 0x0) {
                vm_func_026ad1(local_70);
                result = 0x0;
            } else {
                if (local_obj_130.field_08 == 0x0) {
                    vm_func_026ad1(local_70);
                    result = 0x0;
                    return result;
                } else {
                    thread_probe_status = 0x3;
                    index_1e8 = 0x0;
                    local_1fc = 0x1;
                    ptr_200 = &thread_probe_phdr_value;
                    ptr_208 = &thread_probe_phdr_flags;
                    while (((uint64_t)(index_1e8)) < ((uint64_t)(local_obj_130.field_08))) {
                        local_1f0 = *(uint64_t *)(local_obj_130.field_00 + (index_1e8 << 0x3));
                        local_1f8 = *(uint64_t *)(local_obj_188.field_00 + (index_1e8 << 0x3));
                        if ((*(uint64_t *)(local_obj_188.field_00 + (index_1e8 << 0x3)) & 0x2) != 0x0) {
                            thread_probe_status = 0x5;
                            heap_ptr_022e54 = ((fn_operator_new)(0x20));
                            get_vm_callback_thunk(0x6c6e);
                            vm_call_reg(0x26b80);
                            g_22c8 = heap_ptr_022e54;
                            tmp_022e88 = vm_func_026cce(heap_ptr_022e54);
                            if (tmp_022e88 & 0x1) {
                                thread_probe_installed = local_1fc;
                                *(uint64_t *)(ptr_200) = local_1f0;
                                *(uint32_t *)(ptr_208) = local_1f8;
                                vm_func_026c1e(g_22c8);
                                thread_probe_status = 0x6;
                            }
                            if ((local_1f8 & 0x2) == 0x0) {
                                vm_func_02367f(local_1f0, local_1f8);
                            }
                            if (!(thread_probe_installed & 0x1)) {
                                index_1e8 = (index_1e8 + 0x1);
                                continue;
                            } else {
                                break;
                            }
                        } else {
                            if (vm_func_02367f(local_1f0, (local_1f8 | 0x2)) == 0x0) {
                                thread_probe_status = 0x5;
                                heap_ptr_022e54 = ((fn_operator_new)(0x20));
                                get_vm_callback_thunk(0x6c6e);
                                vm_call_reg(0x26b80);
                                g_22c8 = heap_ptr_022e54;
                                tmp_022e88 = vm_func_026cce(heap_ptr_022e54);
                                goto loc_022e4c;
                            } else {
                                thread_probe_status = 0x4;
                                vm_func_026ad1(local_70);
                                result = 0x0;
                                goto loc_02306e;
                            }
                        }
                    }
                    vm_func_026ad1(local_70);
                    result = 0x0;
                    return result;
                }
            }
        }
    }
    loc_02306e:
    return result;
}
