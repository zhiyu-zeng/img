void collect_symbol_probe_records(uint64_t arg0) {
    VmU64Pair u64_pair_100;
    uint8_t* stack_buf_0e8 = (uint8_t*)(fp + 0xe8); /* observed >= 0x9 bytes */
    uint8_t* stack_buf_128 = (uint8_t*)(fp + 0x128); /* observed >= 0x9 bytes */
    ptr_68 = vm_func_024292(arg0);
    if (ptr_68 != 0x0) {
        if (vm_func_0237da(ptr_68) == 0x0) {
            local_150 = 0x0;
            index_90 = 0x0;
            local_158 = 0x1;
            ptr_138 = &g_2fb8;
            ptr_160 = &g_2fc8;
            size_140 = 0x20;
            local_148 = 0x580;
            local_14c = 0x372;
            while (((uint64_t)(index_90)) < ((uint64_t)(*(uint64_t *)(ptr_68 + 0x28)))) {
                local_98 = (*(uint64_t *)(ptr_68 + 0x20) + (index_90 * 0x18));
                local_a0 = *(uint32_t *)((*(uint64_t *)(ptr_68 + 0x20) + (index_90 * 0x18)) + 0x8);
                local_a4 = *(uint32_t *)((*(uint64_t *)(ptr_68 + 0x20) + (index_90 * 0x18)) + 0xc);
                local_a8 = (*(uint64_t *)(ptr_68 + 0x8) + *(uint64_t *)(*(uint64_t *)(ptr_68 + 0x20) + (index_90 * 0x18)));
                if (*(uint32_t *)((*(uint64_t *)(ptr_68 + 0x20) + (index_90 * 0x18)) + 0x8) != 0x402) {
                    index_90 = (index_90 + 0x1);
                    continue;
                } else {
                    if (*(uint64_t *)(local_a8) != 0x0) {
                        local_b0 = (*(uint64_t *)(ptr_68 + 0x58) + *(uint32_t *)(*(uint64_t *)(ptr_68 + 0x50) + (local_a4 * 0x18)));
                        local_b8 = (*(uint64_t *)(ptr_68 + 0x50) + (local_a4 * 0x18));
                        local_c0 = 0x0;
                        index_c4 = 0x0;
                        while (((int32_t)(index_c4)) <= 99) {
                            if (*(uint64_t *)(((int64_t)(index_c4) << 0x4) + &g_27c8) != 0x0) {
                                if (call_native_n(g_2eb8, *(uint64_t *)(arg0 + 0x8), *(uint64_t *)(((int64_t)(index_c4) << 0x4) + &g_27c8)) == 0x0) {
                                    index_c4 = (index_c4 + 0x1);
                                    continue;
                                } else {
                                    if (call_native_n(g_2eb8, local_b0, *(uint64_t *)(((int64_t)(index_c4) << 0x4) + &g_27d0)) == 0x0) {
                                        index_c4 = (index_c4 + 0x1);
                                        continue;
                                    } else {
                                        local_c0 = local_158;
                                        break;
                                    }
                                }
                            }
                        }
                        loc_029292:
                        if (!(local_c0 & 0x1)) {
                            local_c8 = (((((uint64_t)(*(uint64_t *)(local_a8))) < ((uint64_t)(*(uint64_t *)(ptr_138)))) ? 0x0 : (((((uint64_t)(*(uint64_t *)(local_a8))) < ((uint64_t)(*(uint64_t *)(ptr_160))))) ? 1 : 0)) & 0x1);
                            memset((fp + 0x70), 0x0, size_140);
                            local_d0 = vm_func_029d66(*(uint64_t *)(arg0 + 0x8));
                            local_d8 = vm_func_029d66(local_b0);
                            if (hostcall_dynamic(*(uint64_t *)(local_a8), (fp + 0x70)) != 0x0) {
                                local_f1 = 0x0;
                                local_f8 = local_150;
                                while (true) {
                                    tmp_029496 = vm_func_0288cd(g_2f60);
                                    if (((uint64_t)(local_f8)) >= ((uint64_t)(tmp_029496))) break;
                                    memcpy_checked(&u64_pair_100, vm_func_029e3c(g_2f60, local_f8), 0x10);
                                    if (((uint64_t)(*(uint64_t *)(local_a8))) < ((uint64_t)(u64_pair_100.first))) {
                                        local_f8 = (local_f8 + 0x1);
                                        continue;
                                    } else {
                                        if (((uint64_t)(*(uint64_t *)(local_a8))) >= ((uint64_t)(u64_pair_100.second))) {
                                            local_f8 = (local_f8 + 0x1);
                                            continue;
                                        } else {
                                            local_110 = local_70;
                                            local_118 = vm_func_029d66(local_70);
                                            local_120 = hostcall_dynamic(local_d0);
                                            size_124 = ((((int32_t)(local_120)) < 9) ? local_120 : 0x8);
                                            memset(stack_buf_128, 0x0, 0x9);
                                            strncpy(stack_buf_128, ((local_d0 + (int64_t)(local_120)) - (int64_t)(size_124)), (int64_t)(size_124));
                                            symbol_probe_records[symbol_probe_record_count].name0_tail.word[0] = local_128;
                                            symbol_probe_records[symbol_probe_record_count].name0_tail.word[1] = *(uint32_t *)(stack_buf_128 + 0x4);
                                            local_120 = hostcall_dynamic(local_d8);
                                            size_124 = ((((int32_t)(local_120)) < 9) ? local_120 : 0x8);
                                            memset(stack_buf_128, 0x0, 0x9);
                                            strncpy(stack_buf_128, ((local_d8 + (int64_t)(local_120)) - (int64_t)(size_124)), (int64_t)(size_124));
                                            symbol_probe_records[symbol_probe_record_count].name1_tail.word[0] = local_128;
                                            symbol_probe_records[symbol_probe_record_count].name1_tail.word[1] = *(uint32_t *)(stack_buf_128 + 0x4);
                                            local_120 = hostcall_dynamic(local_118);
                                            size_124 = ((((int32_t)(local_120)) < 9) ? local_120 : 0x8);
                                            memset(stack_buf_128, 0x0, 0x9);
                                            strncpy(stack_buf_128, ((local_118 + (int64_t)(local_120)) - (int64_t)(size_124)), (int64_t)(size_124));
                                            symbol_probe_records[symbol_probe_record_count].name2_tail.word[0] = local_128;
                                            symbol_probe_records[symbol_probe_record_count].name2_tail.word[1] = *(uint32_t *)(stack_buf_128 + 0x4);
                                            symbol_probe_records[symbol_probe_record_count].value_hi = *(uint32_t *)(local_a8 + 0x4);
                                            symbol_probe_records[symbol_probe_record_count].value_lo = *(uint32_t *)(local_a8);
                                            symbol_probe_record_count = (symbol_probe_record_count + 0x1);
                                            local_f1 = local_158;
                                            break;
                                        }
                                    }
                                }
                                loc_0299e9:
                                if (!(local_f1 & 0x1)) {
                                    index_90 = (index_90 + 0x1);
                                    continue;
                                }
                            } else {
                                if (local_c8 & 0x1) {
                                    local_f1 = 0x0;
                                    local_f8 = local_150;
                                    tmp_029496 = vm_func_0288cd(g_2f60);
                                    goto loc_029455;
                                } else {
                                    local_e0 = hostcall_dynamic(local_d0);
                                    size_e4 = ((((int32_t)(local_e0)) < 9) ? local_e0 : 0x8);
                                    memset(stack_buf_0e8, 0x0, 0x9);
                                    strncpy(stack_buf_0e8, ((local_d0 + (int64_t)(local_e0)) - (int64_t)(size_e4)), (int64_t)(size_e4));
                                    symbol_probe_records[symbol_probe_record_count].name0_tail.word[0] = local_e8;
                                    symbol_probe_records[symbol_probe_record_count].name0_tail.word[1] = *(uint32_t *)(stack_buf_0e8 + 0x4);
                                    local_e0 = hostcall_dynamic(local_d8);
                                    size_e4 = ((((int32_t)(local_e0)) < 9) ? local_e0 : 0x8);
                                    memset(stack_buf_0e8, 0x0, 0x9);
                                    strncpy(stack_buf_0e8, ((local_d8 + (int64_t)(local_e0)) - (int64_t)(size_e4)), (int64_t)(size_e4));
                                    symbol_probe_records[symbol_probe_record_count].name1_tail.word[0] = local_e8;
                                    symbol_probe_records[symbol_probe_record_count].name1_tail.word[1] = *(uint32_t *)(stack_buf_0e8 + 0x4);
                                    symbol_probe_records[symbol_probe_record_count].name2_tail.word[0] = 0x6e6f6e61;
                                    symbol_probe_records[symbol_probe_record_count].name2_tail.word[1] = 0x0;
                                    symbol_probe_records[symbol_probe_record_count].value_hi = *(uint32_t *)(local_a8 + 0x4);
                                    symbol_probe_records[symbol_probe_record_count].value_lo = *(uint32_t *)(local_a8);
                                    symbol_probe_record_count = (symbol_probe_record_count + 0x1);
                                    break;
                                }
                            }
                        } else {
                            index_90 = (index_90 + 0x1);
                            continue;
                        }
                    } else {
                        index_90 = (index_90 + 0x1);
                        continue;
                    }
                }
            }
        }
        loc_028d95:
        vm_func_026ad1(ptr_68);
    }
    return;
}
