uint64_t vm_func_028c25(const void* arg0) {
    return *(uint64_t *)(arg0);
}
