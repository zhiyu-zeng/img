uint64_t vm_func_01a037(uint8_t* arg0, uint64_t arg1) {
    local_0 = arg0;
    local_8 = arg1;
    result = 0x811c9dc5;
    while (true) {
        local_8 = (local_8 + 0xffffffff);
        if (local_8 == 0x0) break;
        local_10 = 0x1000193;
        local_0 = (local_0 + 0x1);
        result = ((result ^ *(uint8_t *)(local_0)) * 0x1000193);
        continue;
    }
    return result;
}
