uint64_t vm_func_00f6f0(uint64_t src, uint64_t size, uint64_t arg2) {
    if (src != 0x0) {
        if (((int32_t)(size)) > 0) {
            if (arg2 != 0x0) {
                heap_ptr_40 = malloc((int64_t)(size));
                if (heap_ptr_40 != 0x0) {
                    vm_func_00f149((fp + 0x48), heap_ptr_40);
                    memcpy_checked(vm_func_00fb4b((fp + 0x48)), src, (int64_t)(size));
                    local_50 = vm_func_00eca8(src, size, arg2);
                    if (local_50 != 0x0) {
                        vm_func_00f149((fp + 0x60), local_50);
                        tmp_00f949 = vm_func_00fb4b((fp + 0x48));
                        local_68 = vm_func_00f209(tmp_00f949, src, (int64_t)(size), vm_func_00fb4b((fp + 0x60)));
                        if (local_68 == 0x0) {
                            hash32_6c = hash32_buffer(vm_func_00fb4b((fp + 0x48)), (int64_t)(size));
                            result = hash32_6c;
                            local_58 = 0x1;
                        } else {
                            result = 0x0;
                            local_58 = 0x1;
                        }
                        vm_func_00f19b((fp + 0x60));
                    } else {
                        result = 0x0;
                        local_58 = 0x1;
                    }
                    vm_func_00f19b((fp + 0x48));
                } else {
                    result = 0x0;
                }
            } else {
                result = 0x0;
            }
        } else {
            result = 0x0;
        }
    } else {
        result = 0x0;
    }
    return result;
}
