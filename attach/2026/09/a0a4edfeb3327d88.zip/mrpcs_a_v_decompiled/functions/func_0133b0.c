uint64_t vm_func_0133b0(const void* arg0) {
    return *(uint64_t *)(arg0 + 0x8);
}
