uint64_t vm_func_030d2a(const void* arg0) {
    local_10 = *(uint64_t *)(arg0 + 0x2006d1c0);
    if (*(uint64_t *)(arg0 + 0x2006d1c0) != 0x0) {
        local_18 = *(uint64_t *)(local_10 + 0x8);
        if (*(uint64_t *)(local_10 + 0x8) == 0x0) {
            result = 0x0;
        } else {
            if (((uint64_t)(local_18)) > 0x2f) {
                local_20 = (local_18 + 0xffffffffffffffd0);
                if (((uint64_t)((local_18 + 0xffffffffffffffd0))) > 0xffffffff) {
                    result = *(uint64_t *)(local_20 + 0x280);
                } else {
                    result = 0x0;
                }
            } else {
                result = 0x0;
                return result;
            }
        }
    } else {
        result = 0x0;
    }
    return result;
}
