void vm_func_007558(uint64_t arg0, uint64_t arg1) {
    vm_func_008032(arg0, arg1);
    return;
}
