uint64_t vm_func_012436(void) {
    uint8_t* stack_buf_01c = (uint8_t*)(fp + 0x1c); /* observed >= 0x23 bytes */
    uint8_t* stack_buf_045 = (uint8_t*)(fp + 0x45); /* observed >= 0x22 bytes */
    result = 0x0;
    memcpy_checked(stack_buf_01c, &g_0478, 0x23);
    index_40 = 0x0;
    while (((uint64_t)(index_40)) <= 0x21) {
        local_44 = ((((((((((((0x0 - (((((*(uint8_t *)(stack_buf_01c + index_40) + 0xffffffb3) & 0xff) >> 0x5) | (((*(uint8_t *)(stack_buf_01c + index_40) + 0xffffffb3) & 0xff) << 0x3)) ^ 0xffffff39)) & 0xff) >> 0x3) | (((0x0 - (((((*(uint8_t *)(stack_buf_01c + index_40) + 0xffffffb3) & 0xff) >> 0x5) | (((*(uint8_t *)(stack_buf_01c + index_40) + 0xffffffb3) & 0xff) << 0x3)) ^ 0xffffff39)) & 0xff) << 0x5)) + 0x1) & 0xff) >> 0x2) | (((((((0x0 - (((((*(uint8_t *)(stack_buf_01c + index_40) + 0xffffffb3) & 0xff) >> 0x5) | (((*(uint8_t *)(stack_buf_01c + index_40) + 0xffffffb3) & 0xff) << 0x3)) ^ 0xffffff39)) & 0xff) >> 0x3) | (((0x0 - (((((*(uint8_t *)(stack_buf_01c + index_40) + 0xffffffb3) & 0xff) >> 0x5) | (((*(uint8_t *)(stack_buf_01c + index_40) + 0xffffffb3) & 0xff) << 0x3)) ^ 0xffffff39)) & 0xff) << 0x5)) + 0x1) & 0xff) << 0x6)) + 0xffffff4d) & 0xff) >> 0x7) | (((((((((((0x0 - (((((*(uint8_t *)(stack_buf_01c + index_40) + 0xffffffb3) & 0xff) >> 0x5) | (((*(uint8_t *)(stack_buf_01c + index_40) + 0xffffffb3) & 0xff) << 0x3)) ^ 0xffffff39)) & 0xff) >> 0x3) | (((0x0 - (((((*(uint8_t *)(stack_buf_01c + index_40) + 0xffffffb3) & 0xff) >> 0x5) | (((*(uint8_t *)(stack_buf_01c + index_40) + 0xffffffb3) & 0xff) << 0x3)) ^ 0xffffff39)) & 0xff) << 0x5)) + 0x1) & 0xff) >> 0x2) | (((((((0x0 - (((((*(uint8_t *)(stack_buf_01c + index_40) + 0xffffffb3) & 0xff) >> 0x5) | (((*(uint8_t *)(stack_buf_01c + index_40) + 0xffffffb3) & 0xff) << 0x3)) ^ 0xffffff39)) & 0xff) >> 0x3) | (((0x0 - (((((*(uint8_t *)(stack_buf_01c + index_40) + 0xffffffb3) & 0xff) >> 0x5) | (((*(uint8_t *)(stack_buf_01c + index_40) + 0xffffffb3) & 0xff) << 0x3)) ^ 0xffffff39)) & 0xff) << 0x5)) + 0x1) & 0xff) << 0x6)) + 0xffffff4d) & 0xff) << 0x1));
        *(uint8_t *)(stack_buf_01c + index_40) = ((((((((((((0x0 - (((((*(uint8_t *)(stack_buf_01c + index_40) + 0xffffffb3) & 0xff) >> 0x5) | (((*(uint8_t *)(stack_buf_01c + index_40) + 0xffffffb3) & 0xff) << 0x3)) ^ 0xffffff39)) & 0xff) >> 0x3) | (((0x0 - (((((*(uint8_t *)(stack_buf_01c + index_40) + 0xffffffb3) & 0xff) >> 0x5) | (((*(uint8_t *)(stack_buf_01c + index_40) + 0xffffffb3) & 0xff) << 0x3)) ^ 0xffffff39)) & 0xff) << 0x5)) + 0x1) & 0xff) >> 0x2) | (((((((0x0 - (((((*(uint8_t *)(stack_buf_01c + index_40) + 0xffffffb3) & 0xff) >> 0x5) | (((*(uint8_t *)(stack_buf_01c + index_40) + 0xffffffb3) & 0xff) << 0x3)) ^ 0xffffff39)) & 0xff) >> 0x3) | (((0x0 - (((((*(uint8_t *)(stack_buf_01c + index_40) + 0xffffffb3) & 0xff) >> 0x5) | (((*(uint8_t *)(stack_buf_01c + index_40) + 0xffffffb3) & 0xff) << 0x3)) ^ 0xffffff39)) & 0xff) << 0x5)) + 0x1) & 0xff) << 0x6)) + 0xffffff4d) & 0xff) >> 0x7) | (((((((((((0x0 - (((((*(uint8_t *)(stack_buf_01c + index_40) + 0xffffffb3) & 0xff) >> 0x5) | (((*(uint8_t *)(stack_buf_01c + index_40) + 0xffffffb3) & 0xff) << 0x3)) ^ 0xffffff39)) & 0xff) >> 0x3) | (((0x0 - (((((*(uint8_t *)(stack_buf_01c + index_40) + 0xffffffb3) & 0xff) >> 0x5) | (((*(uint8_t *)(stack_buf_01c + index_40) + 0xffffffb3) & 0xff) << 0x3)) ^ 0xffffff39)) & 0xff) << 0x5)) + 0x1) & 0xff) >> 0x2) | (((((((0x0 - (((((*(uint8_t *)(stack_buf_01c + index_40) + 0xffffffb3) & 0xff) >> 0x5) | (((*(uint8_t *)(stack_buf_01c + index_40) + 0xffffffb3) & 0xff) << 0x3)) ^ 0xffffff39)) & 0xff) >> 0x3) | (((0x0 - (((((*(uint8_t *)(stack_buf_01c + index_40) + 0xffffffb3) & 0xff) >> 0x5) | (((*(uint8_t *)(stack_buf_01c + index_40) + 0xffffffb3) & 0xff) << 0x3)) ^ 0xffffff39)) & 0xff) << 0x5)) + 0x1) & 0xff) << 0x6)) + 0xffffff4d) & 0xff) << 0x1));
        index_40 = (index_40 + 0x1);
        continue;
    }
    memcpy_checked(stack_buf_045, &g_049b, 0x22);
    index_68 = 0x0;
    while (((uint64_t)(index_68)) <= 0x20) {
        local_6c = ((((0x0 - ((((((0x0 - (*(uint8_t *)(stack_buf_045 + index_68) ^ 0xff)) ^ index_68) - index_68) + 0x1) ^ 0x40) + index_68)) ^ 0xa8) + 0xbe) ^ 0xed);
        *(uint8_t *)(stack_buf_045 + index_68) = ((((0x0 - ((((((0x0 - (*(uint8_t *)(stack_buf_045 + index_68) ^ 0xff)) ^ index_68) - index_68) + 0x1) ^ 0x40) + index_68)) ^ 0xa8) + 0xbe) ^ 0xed);
        index_68 = (index_68 + 0x1);
        continue;
    }
    if (vm_func_01137f(stack_buf_01c) == 0xfffffffe) {
        if (vm_func_01137f(stack_buf_045) == 0x0) {
            result = 0x1;
        }
    }
    return result;
}
