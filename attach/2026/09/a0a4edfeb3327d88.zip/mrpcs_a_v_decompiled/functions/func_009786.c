void vm_func_009786(uint64_t arg0, uint64_t arg1, uint64_t arg2, uint64_t arg3) {
    local_14 = (arg3 & 0x1);
    return;
}
