void vm_func_00c4e2(uint64_t arg0, uint64_t arg1) {
    if (arg1 != 0x0) {
        vm_func_005692(arg0, arg1);
    }
    return;
}
