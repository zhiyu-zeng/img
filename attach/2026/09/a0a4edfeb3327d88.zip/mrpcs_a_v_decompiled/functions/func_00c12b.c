void vm_func_00c12b(uint64_t arg0, uint64_t arg1, uint64_t arg2) {
    local_40 = vm_func_00330c(arg0, arg1);
    if (local_40 == 0x0) {
        vm_func_006a7e(arg0);
        local_20 = 0x0;
    } else {
        if (vm_func_006a36(arg0) == 0x0) {
            vm_call_reg(0x9628);
            vm_func_006ac6((fp + 0x48), local_40);
            local_60 = vm_func_003bcc(arg0, local_40, arg1, "I");
            if (local_60 == 0x0) {
                vm_func_006a7e(arg0);
                local_20 = 0x0;
                local_68 = 0x1;
            } else {
                if (vm_func_006a36(arg0) == 0x0) {
                    local_20 = vm_func_003d46(arg0, local_40, local_60);
                    local_68 = 0x1;
                } else {
                    vm_func_006a7e(arg0);
                    local_20 = 0x0;
                    local_68 = 0x1;
                    vm_call_reg(0x7279);
                    return;
                }
            }
            vm_call_reg(0x7279);
        } else {
            vm_func_006a7e(arg0);
            local_20 = 0x0;
            return;
        }
    }
    return;
}
