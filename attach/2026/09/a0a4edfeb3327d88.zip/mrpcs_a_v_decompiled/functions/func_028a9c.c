void vm_func_028a9c(void* arg0) {
    vm_func_028b4f(arg0, *(uint64_t *)(arg0), ((*(uint64_t *)(arg0 + 0x10) - *(uint64_t *)(arg0)) >> 0x4));
    *(uint64_t *)(arg0) = 0x0;
    *(uint64_t *)(arg0 + 0x8) = 0x0;
    *(uint64_t *)(arg0 + 0x10) = 0x0;
    return;
}
