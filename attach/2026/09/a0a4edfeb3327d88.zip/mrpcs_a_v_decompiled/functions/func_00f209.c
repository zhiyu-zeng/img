uint64_t vm_func_00f209(uint64_t dst, uint64_t arg1, uint64_t arg2, uint64_t arg3) {
    index_20 = 0x0;
    while (((uint64_t)((int64_t)(index_20))) < ((uint64_t)(*(uint64_t *)(arg3)))) {
        local_28 = *(uint64_t *)((arg3 + ((int64_t)(index_20) * 0x38)) + 0x18);
        local_30 = (*(uint64_t *)((arg3 + ((int64_t)(index_20) * 0x38)) + 0x18) + *(uint32_t *)((arg3 + ((int64_t)(index_20) * 0x38)) + 0x10));
        local_38 = arg1;
        local_40 = (arg1 + arg2);
        if (((uint64_t)(*(uint64_t *)((arg3 + ((int64_t)(index_20) * 0x38)) + 0x18))) > arg1) {
            if (((uint64_t)(local_28)) >= ((uint64_t)(local_38))) {
                if (((uint64_t)(local_28)) < ((uint64_t)(local_40))) {
                    size_58 = 0x0;
                    if (((uint64_t)(local_30)) >= ((uint64_t)(local_40))) {
                        size_58 = (local_40 - local_28);
                    } else {
                        size_58 = (local_30 - local_28);
                    }
                    memcpy_checked((dst + (local_28 - arg1)), ((arg3 + ((int64_t)(index_20) * 0x38)) + 0x20), size_58);
                }
            }
        } else {
            if (((uint64_t)(local_30)) <= ((uint64_t)(local_38))) {
                goto loc_00f468;
            } else {
                local_48 = (local_38 - local_28);
                size_50 = 0x0;
                if (((uint64_t)(local_30)) >= ((uint64_t)(local_40))) {
                    size_50 = (local_40 - local_38);
                } else {
                    size_50 = (local_30 - local_38);
                }
                memcpy_checked(dst, (((arg3 + ((int64_t)(index_20) * 0x38)) + local_48) + 0x20), size_50);
            }
        }
        index_20 = (index_20 + 0x1);
        continue;
    }
    return 0x0;
}
