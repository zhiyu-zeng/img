void vm_func_00c0d3(uint64_t arg0, uint64_t arg1) {
    vm_func_005692(arg0, arg1);
    return;
}
