uint64_t vm_func_029d66(uint64_t arg0) {
    result = call_native_n(g_2ed8, arg0);
    ptr_10 = vm_func_029e9d(result, ".");
    if (ptr_10 != 0x0) {
        *(uint8_t *)(ptr_10) = 0x0;
    }
    return result;
}
