uint64_t vm_func_02ec4c(uint64_t arg0, uint64_t arg1) {
    if (arg1 != 0x0) {
        *(uint32_t *)(arg1) = 0xffffffff;
    }
    if (g_37c0 != 0x0) {
        if (g_3878 != 0x0) {
            local_20 = call_native_n(g_3878, arg0);
            if (arg1 != 0x0) {
                *(uint32_t *)(arg1) = 0x1;
            }
            result = local_20;
        } else {
            dst_18 = call_native_n(g_37c0, 0x0, 0x1000, 0x7, 0x22, 0xffffffff, 0x0);
            if (dst_18 == 0x0) {
                if (arg1 != 0x0) {
                    *(uint32_t *)(arg1) = 0xfffffffd;
                }
                result = 0x0;
            } else {
                if (dst_18 != 0xffffffffffffffff) {
                    memcpy_checked(dst_18, &g_3880, 0x18);
                    clear_icache(dst_18, (dst_18 + 0x18));
                    g_3878 = dst_18;
                    goto loc_02ee06;
                } else {
                    goto loc_02ef23;
                }
            }
        }
    } else {
        if (arg1 != 0x0) {
            *(uint32_t *)(arg1) = 0xfffffffe;
        }
        result = 0x0;
    }
    return result;
}
