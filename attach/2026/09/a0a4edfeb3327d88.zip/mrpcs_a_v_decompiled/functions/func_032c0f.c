void vm_func_032c0f(void) {
    VmU64Pair u64_pair_020;
    VmU64Pair u64_pair_030;
    g_3ed0 = 0x0;
    g_3ef1 = 0x0;
    local_18 = vm_func_03315e();
    if (vm_func_03300d(local_18) & 0x1) {
        vm_func_0331a8((fp + 0x40), local_18);
        u64_pair_020.first = local_40;
        u64_pair_020.second = *(uint64_t *)((fp + 0x40) + 0x8);
        vm_func_0332b7((fp + 0x50));
        u64_pair_030.first = local_50;
        u64_pair_030.second = *(uint64_t *)((fp + 0x50) + 0x8);
        vm_func_0333b6(&u64_pair_020, &g_3ed0, 0x21);
        vm_func_0333b6(&u64_pair_030, &g_3ef1, 0x21);
    }
    return;
}
