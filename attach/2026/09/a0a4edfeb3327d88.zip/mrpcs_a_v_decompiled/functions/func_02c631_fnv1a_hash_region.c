void fnv1a_hash_region(void) {
    g_37d8 = 0xffffffff00000000;
    module_base_20 = get_cached_module_base(0x1);
    if (module_base_20 != 0x0) {
        local_28 = 0x4;
        local_34 = 0x811c9dc5;
        index_38 = 0x0;
        while (((uint64_t)(index_38)) <= 0xd2d) {
            local_40 = 0x4;
            if (((uint64_t)((index_38 + 0x4))) >= 0xd2f) {
                local_40 = (0xd2e - index_38);
            }
            local_48 = ((module_base_20 + index_38) + 0x500980);
            local_50 = copy_bytes_via_aligned_u32(((module_base_20 + index_38) + 0x500980), (fp + 0x30), local_40);
            if (local_50 == 0x0) {
                index_58 = 0x0;
                while (((uint64_t)(index_58)) < ((uint64_t)(local_40))) {
                    local_34 = ((local_34 ^ *(uint8_t *)((fp + 0x30) + index_58)) * 0x1000193);
                    index_58 = (index_58 + 0x1);
                    continue;
                }
                index_38 = (index_38 + 0x4);
                continue;
            } else {
                g_37dc = local_50;
                goto loc_02c959;
            }
        }
        g_37d8 = local_34;
        g_37dc = 0x0;
    } else {
        g_37dc = 0xfffffff6;
    }
    loc_02c959:
    return;
}
