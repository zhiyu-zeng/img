void vm_func_002d21(void) {
    register_vm_callback(0x2aee, 0x6c92, 0x1, 0x3c);
    return;
}
