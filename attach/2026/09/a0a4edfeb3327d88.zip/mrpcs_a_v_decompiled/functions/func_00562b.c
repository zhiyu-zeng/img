void vm_func_00562b(const void* arg0) {
    dispatch_registered_handler(0xe, *(uint64_t *)(arg0), 0x0, 0x0);
    return;
}
