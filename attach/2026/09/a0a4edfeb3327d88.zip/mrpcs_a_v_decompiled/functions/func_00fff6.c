void vm_func_00fff6(void* arg0) {
    *(uint64_t *)(arg0) = 0x0;
    *(uint64_t *)(arg0 + 0x8) = 0x0;
    *(uint64_t *)(arg0 + 0x10) = 0x0;
    ptr_01008a = vm_func_0103de(arg0, 0x20);
    *(uint64_t *)(arg0) = ptr_01008a;
    *(uint64_t *)(arg0 + 0x8) = ptr_01008a;
    *(uint64_t *)(arg0 + 0x10) = (ptr_01008a + (0x20 * 0x38));
    return;
}
