uint64_t scan_file_for_pattern_streaming(uint8_t* arg0, uint8_t* arg1, uint64_t arg2, uint64_t arg3, uint64_t arg4) {
    if (arg3 != 0x0) {
        *(uint32_t *)(arg3) = 0xffffffff;
    }
    if (arg4 != 0x0) {
        *(uint32_t *)(arg4) = 0x0;
    }
    if (arg0 == 0x0) {
        result = 0xfffffffc;
    } else {
        if (arg1 == 0x0) {
            result = 0xfffffffc;
            return result;
        } else {
            if (arg2 != 0x0) {
                local_48 = 0x2000;
                local_50 = sys_mmap(0x0, 0x2000, 0x3, 0x22, 0xffffffff, 0x0);
                if (local_50 == 0x0) {
                    if (arg3 != 0x0) {
                        *(uint32_t *)(arg3) = 0xfffffffd;
                    }
                    result = 0xffffffff;
                } else {
                    if (local_50 != 0xffffffffffffffff) {
                        fd_58 = sys_openat(0xffffff9c, arg0, 0x0, 0x0);
                        if (((int64_t)(fd_58)) > -1) {
                            local_60 = local_50;
                            local_68 = 0x0;
                            local_70 = 0x0;
                            local_78 = 0x0;
                            local_7c = 0x0;
                            while (true) {
                                if (((uint64_t)(local_68)) < 0x2000) {
                                } else {
                                    local_80 = (arg2 + 0xffffffffffffffff);
                                    index_88 = 0x0;
                                    while (((uint64_t)(index_88)) < ((uint64_t)(local_80))) {
                                        *(uint8_t *)(local_60 + index_88) = *(uint8_t *)(((index_88 - local_80) + local_60) + 0x2000);
                                        index_88 = (index_88 + 0x1);
                                        continue;
                                    }
                                    local_68 = local_80;
                                }
                                loc_02d874:
                                local_90 = sys_read(fd_58, (local_60 + local_68), (0x2000 - local_68));
                                if (((int64_t)(local_90)) > -1) {
                                    if (local_90 != 0x0) {
                                        local_98 = (local_68 + local_90);
                                        local_70 = (local_70 + local_90);
                                        local_a0 = memmem_linear(local_60, (local_68 + local_90), arg1, arg2);
                                        if (local_a0 == 0x0) {
                                            local_a8 = 0xffffffffffffffff;
                                            local_b0 = local_98;
                                            while (local_b0 != 0x0) {
                                                if (*(uint8_t *)((local_b0 + local_60) + 0xffffffffffffffff) != 0xa) {
                                                    local_b0 = (local_b0 + 0xffffffffffffffff);
                                                    continue;
                                                } else {
                                                    local_a8 = (local_b0 + 0xffffffffffffffff);
                                                    break;
                                                }
                                            }
                                            loc_02dab9:
                                            local_b8 = ((local_a8 != 0xffffffffffffffff) ? (local_a8 + 0x1) : 0x0);
                                            local_c0 = (local_98 - ((local_a8 != 0xffffffffffffffff) ? (local_a8 + 0x1) : 0x0));
                                            local_c8 = 0x0;
                                            if (local_a8 != 0xffffffffffffffff) {
                                                local_c8 = (arg2 + 0xffffffffffffffff);
                                            }
                                            local_d0 = ((((uint64_t)(local_c0)) <= ((uint64_t)(local_c8))) ? local_c8 : local_c0);
                                            if (((uint64_t)(((((uint64_t)(local_c0)) > ((uint64_t)(local_c8))) ? local_c8 : local_c0))) <= ((uint64_t)(local_98))) {
                                                local_d0 = local_98;
                                            }
                                            local_d8 = (local_98 - local_d0);
                                            index_e0 = 0x0;
                                            while (((uint64_t)(index_e0)) < ((uint64_t)(local_d0))) {
                                                *(uint8_t *)(local_60 + index_e0) = *(uint8_t *)(local_60 + (local_d8 + index_e0));
                                                index_e0 = (index_e0 + 0x1);
                                                continue;
                                            }
                                            local_68 = local_d0;
                                            continue;
                                        } else {
                                            local_78 = 0x1;
                                            sys_close(fd_58);
                                            if (arg4 != 0x0) {
                                                *(uint32_t *)(arg4) = ((((uint64_t)(local_70)) < 0x80000000) ? local_70 : 0x7fffffff);
                                            }
                                            if (arg3 != 0x0) {
                                                once_value_02df79 = vm_mov_once_d(0xfffffffa, 0x1);
                                                *(uint32_t *)(arg3) = once_value_02df79;
                                            }
                                            sys_munmap(local_50, 0x2000);
                                            result = ((local_78) != (0x0));
                                            return result;
                                        }
                                    }
                                } else {
                                    local_7c = 0x1;
                                    sys_close(fd_58);
                                    if (arg4 != 0x0) {
                                        *(uint32_t *)(arg4) = ((((uint64_t)(local_70)) < 0x80000000) ? local_70 : 0x7fffffff);
                                    }
                                    if (arg3 != 0x0) {
                                        once_value_02df79 = vm_mov_once_d(0xfffffffa, 0x1);
                                        *(uint32_t *)(arg3) = once_value_02df79;
                                    }
                                    sys_munmap(local_50, 0x2000);
                                    result = ((local_78) != (0x0));
                                    return result;
                                }
                                sys_close(fd_58);
                                if (arg4 != 0x0) {
                                    *(uint32_t *)(arg4) = ((((uint64_t)(local_70)) < 0x80000000) ? local_70 : 0x7fffffff);
                                }
                                if (arg3 != 0x0) {
                                    once_value_02df79 = vm_mov_once_d(0xfffffffa, 0x1);
                                    *(uint32_t *)(arg3) = once_value_02df79;
                                }
                                sys_munmap(local_50, 0x2000);
                                result = ((local_78) != (0x0));
                                return result;
                            }
                        } else {
                            sys_munmap(local_50, 0x2000);
                            if (arg3 != 0x0) {
                                *(uint32_t *)(arg3) = 0xfffffffb;
                            }
                            result = 0xfffffffe;
                        }
                    } else {
                        goto loc_02dd6b;
                    }
                }
            } else {
                result = 0xfffffffc;
                return result;
            }
        }
    }
    return result;
}
