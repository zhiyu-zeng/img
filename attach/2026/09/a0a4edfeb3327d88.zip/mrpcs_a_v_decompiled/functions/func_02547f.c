uint64_t vm_func_02547f(const void* arg0, const void* arg1, uint64_t string, uint64_t arg3, uint64_t arg4, uint64_t arg5, uint64_t arg6, uint64_t arg7) {
    local_48 = (arg7 & 0x1);
    local_4c = *(uint32_t *)(arg1 + 0x8);
    local_50 = *(uint32_t *)(arg1 + 0xc);
    local_58 = (*(uint64_t *)(arg0 + 0x8) + *(uint64_t *)(arg1));
    if (!(arg7 & 0x1)) {
        if (local_4c == 0x401) {
            if (*(uint64_t *)(arg6) != 0x0) {
                if ((*(uint64_t *)(arg0 + 0x50) + (local_50 * 0x18)) != *(uint64_t *)(arg6)) {
                    result = 0x0;
                } else {
                    if (arg3 == 0x0) {
                        if (vm_func_023125(arg4, local_58) == 0x0) {
                            if (vm_func_023125(arg5, (int64_t)(vm_func_0264cb(arg0, local_58))) == 0x0) {
                                result = 0x0;
                                return result;
                            } else {
                                result = 0xffffffff;
                            }
                        } else {
                            result = 0xffffffff;
                        }
                    } else {
                        if (*(uint64_t *)(local_58) == arg3) {
                            goto loc_0258b0;
                        } else {
                            result = 0xffffffff;
                        }
                    }
                }
            } else {
                if (strcmp((*(uint64_t *)(arg0 + 0x58) + *(uint32_t *)(*(uint64_t *)(arg0 + 0x50) + (local_50 * 0x18))), string) != 0x0) {
                    result = 0x0;
                    return result;
                } else {
                    *(uint64_t *)(arg6) = (*(uint64_t *)(arg0 + 0x50) + (local_50 * 0x18));
                    if (arg3 == 0x0) {
                        if (vm_func_023125(arg4, local_58) == 0x0) {
                            if (vm_func_023125(arg5, (int64_t)(vm_func_0264cb(arg0, local_58))) == 0x0) {
                                result = 0x0;
                                return result;
                            } else {
                                result = 0xffffffff;
                            }
                        } else {
                            result = 0xffffffff;
                        }
                    } else {
                        if (*(uint64_t *)(local_58) == arg3) {
                            goto loc_02590e;
                        } else {
                            result = 0xffffffff;
                        }
                    }
                }
            }
        } else {
            if (local_4c == 0x101) {
                goto loc_025659;
            } else {
                result = 0x0;
            }
        }
    } else {
        if (local_4c == 0x402) {
            goto loc_025659;
        } else {
            result = 0x0;
        }
    }
    return result;
}
