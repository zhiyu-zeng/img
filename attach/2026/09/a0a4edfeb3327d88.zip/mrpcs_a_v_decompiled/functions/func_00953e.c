void vm_func_00953e(uint64_t arg0, uint64_t arg1) {
    vm_func_009596(arg0, arg1);
    return;
}
