void vm_func_032dce(void) {
    uint8_t* stack_buf_038 = (uint8_t*)(fp + 0x38); /* observed >= 0x80 bytes */
    g_3f12 = 0x0;
    local_28 = *(uint64_t *)(g_3f58);
    if (vm_func_03300d(*(uint64_t *)(g_3f58)) & 0x1) {
        local_30 = *(uint64_t *)(local_28 + 0x1a0);
        if (vm_func_03300d(*(uint64_t *)(local_28 + 0x1a0)) & 0x1) {
            memset(stack_buf_038, 0x0, 0x80);
            vm_func_03305e(local_30, "require");
            vm_func_0330d4(local_30, ">S", stack_buf_038);
            if (*(uint64_t *)(stack_buf_038 + 0x20) != 0x0) {
                strncpy(&g_3f12, *(uint64_t *)(stack_buf_038 + 0x20), 0x3f);
                g_3f51 = 0x0;
            }
        }
    }
    return;
}
