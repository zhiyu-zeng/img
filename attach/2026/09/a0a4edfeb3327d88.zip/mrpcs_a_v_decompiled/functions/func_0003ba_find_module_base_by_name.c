uint64_t find_module_base_by_name(uint64_t arg0) {
    return find_module_base(arg0);
}
