void vm_func_020441(void) {
    if (((int32_t)(g_2210)) <= 4) {
        call_native_n(g_21c8, get_vm_callback_thunk(0x6c6b), 0x0);
    }
    return;
}
