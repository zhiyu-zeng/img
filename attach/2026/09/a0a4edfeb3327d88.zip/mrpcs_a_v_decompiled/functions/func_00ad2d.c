uint64_t vm_func_00ad2d(uint64_t arg0, uint64_t arg1, uint64_t arg2) {
    result = vm_func_003c97(arg0, arg1, arg2);
    return result;
}
