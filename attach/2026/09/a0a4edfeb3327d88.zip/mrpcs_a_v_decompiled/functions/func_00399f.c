uint64_t vm_func_00399f(const void* arg0, uint64_t arg1, uint64_t arg2, uint64_t arg3) {
    struct { uint64_t field_00; uint64_t field_08; uint64_t field_10; uint64_t field_18; } local_obj_020;
    local_obj_020.field_00 = arg1;
    local_obj_020.field_08 = arg2;
    local_obj_020.field_10 = arg3;
    local_obj_020.field_18 = 0x0;
    return dispatch_registered_handler(0x5b, *(uint64_t *)(arg0), &local_obj_020, 0x3);
}
