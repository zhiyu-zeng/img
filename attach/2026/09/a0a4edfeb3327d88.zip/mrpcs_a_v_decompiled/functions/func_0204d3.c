void vm_func_0204d3(const char* arg0) {
    struct { uint32_t field_00; uint32_t field_04; uint32_t field_08; } local_obj_0a4;
    local_b8 = fn_strncpy;
    file_handle_70 = fopen(*(uint64_t *)(arg0 + 0x8), "rb");
    if (file_handle_70 != 0x0) {
        index_78 = 0x0;
        local_c0 = 0x372;
        local_d8 = 0xc;
        local_c8 = 0xd;
        local_d0 = 0x36e;
        local_d4 = 0x0;
        local_e8 = 0x1;
        local_e0 = &g_2220;
        while (((int32_t)(index_78)) < ((int32_t)(*(uint16_t *)(arg0 + 0x18)))) {
            local_80 = (*(uint64_t *)(arg0 + 0x10) + ((int64_t)(index_78) * 0x38));
            if (*(uint32_t *)(*(uint64_t *)(arg0 + 0x10) + ((int64_t)(index_78) * 0x38)) == 0x1) {
                if (*(uint32_t *)(local_80 + 0x4) == 0x5) {
                    local_88 = ((((uint64_t)(*(uint64_t *)(local_80 + 0x28))) >= ((uint64_t)(*(uint64_t *)(local_80 + 0x20)))) ? *(uint64_t *)(local_80 + 0x20) : *(uint64_t *)(local_80 + 0x28));
                    index_90 = 0x0;
                    while (((uint64_t)((int64_t)(index_90))) < ((uint64_t)(local_88))) {
                        fseek(file_handle_70, (*(uint64_t *)(local_80 + 0x8) + (int64_t)(index_90)), 0x0);
                        local_94 = ((((uint64_t)((local_88 - (int64_t)(index_90)))) < 0x1001) ? (local_88 - (int64_t)(index_90)) : 0x1000);
                        fread(g_21a0, ((((((uint64_t)((local_88 - (int64_t)(index_90)))) < 0x1001) ? (local_88 - (int64_t)(index_90)) : 0x1000) << 0x20) >> 0x20), 0x1, file_handle_70);
                        if (memcmp(((*(uint64_t *)(arg0) + *(uint64_t *)(local_80 + 0x10)) + (int64_t)(index_90)), g_21a0, (int64_t)(local_94)) == 0x0) {
                            index_90 = (index_90 + 0x1000);
                            continue;
                        } else {
                            local_98 = vm_func_020fa8(((*(uint64_t *)(arg0) + *(uint64_t *)(local_80 + 0x10)) + (int64_t)(index_90)), local_94);
                            local_9c = hostcall_dynamic(*(uint64_t *)(arg0 + 0x8));
                            local_a0 = ((((int32_t)(local_9c)) < 13) ? local_9c : local_d8);
                            hostcall_dynamic(&local_obj_0a4, 0x0, local_c8);
                            ((local_b8)(&local_obj_0a4, ((*(uint64_t *)(arg0 + 0x8) + (int64_t)(local_9c)) - (int64_t)(local_a0)), (int64_t)(local_a0)));
                            local_b1 = local_d4;
                            index_b4 = 0x0;
                            while (((int32_t)(index_b4)) < ((int32_t)(g_2210))) {
                                if (*(uint32_t *)(((int64_t)(index_b4) * 0x14) + &g_2214) != local_obj_0a4.field_00) {
                                    index_b4 = (index_b4 + 0x1);
                                    continue;
                                } else {
                                    if (*(uint32_t *)(((int64_t)(index_b4) * 0x14) + &g_2218) != local_obj_0a4.field_04) {
                                        index_b4 = (index_b4 + 0x1);
                                        continue;
                                    } else {
                                        if (*(uint32_t *)(((int64_t)(index_b4) * 0x14) + &g_221c) != local_obj_0a4.field_08) {
                                            index_b4 = (index_b4 + 0x1);
                                            continue;
                                        } else {
                                            local_b1 = local_e8;
                                            break;
                                        }
                                    }
                                }
                            }
                            loc_020d1c:
                            if (!(local_b1 & 0x1)) {
                                *(uint32_t *)(((int64_t)(g_2210) * 0x14) + &g_2214) = local_obj_0a4.field_00;
                                *(uint32_t *)(((int64_t)(g_2210) * 0x14) + &g_2218) = local_obj_0a4.field_04;
                                *(uint32_t *)(((int64_t)(g_2210) * 0x14) + &g_221c) = local_obj_0a4.field_08;
                                *(uint32_t *)(((int64_t)(g_2210) * 0x14) + local_e0) = ((*(uint64_t *)(local_80 + 0x10) + (int64_t)(index_90)) + vm_func_021198(((*(uint64_t *)(arg0) + *(uint64_t *)(local_80 + 0x10)) + (int64_t)(index_90)), g_21a0, local_94));
                                *(uint32_t *)(((int64_t)(g_2210) * 0x14) + &g_2224) = local_98;
                                g_2210 = (g_2210 + 0x1);
                            }
                            break;
                        }
                    }
                } else {
                    if (*(uint32_t *)(local_80 + 0x4) == 0x4) {
                        goto loc_0207ce;
                    }
                }
            }
            loc_020e8a:
            index_78 = (index_78 + 0x1);
            continue;
        }
        fclose(file_handle_70);
        local_60 = 0x0;
    } else {
        local_60 = 0xffffffff;
    }
    return;
}
