void vm_func_00973e(uint64_t arg0) {
    vm_func_0097f8(arg0);
    return;
}
