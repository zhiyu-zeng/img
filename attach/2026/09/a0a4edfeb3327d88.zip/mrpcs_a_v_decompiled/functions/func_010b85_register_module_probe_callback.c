void register_module_probe_callback(uint64_t arg0) {
    register_vm_callback(0x10479, arg0, 0xb);
    return;
}
