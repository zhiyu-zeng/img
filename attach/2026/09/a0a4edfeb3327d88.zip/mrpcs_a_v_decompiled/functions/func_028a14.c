uint64_t vm_func_028a14(const void* arg0) {
    return *(uint64_t *)(arg0);
}
