uint64_t vm_func_0101a2(uint64_t arg0, uint64_t arg1) {
    return vm_func_0102fc(arg0, arg1);
}
