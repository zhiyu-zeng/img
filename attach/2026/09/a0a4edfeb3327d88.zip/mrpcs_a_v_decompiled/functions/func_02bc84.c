void vm_func_02bc84(void) {
    g_3120 = " rwxp 00230000 ";
    g_3128 = 0x1000;
    g_3130 = " rwxp 0038c000 ";
    g_3138 = 0x1000;
    g_3140 = " rwxp 004a9000 ";
    g_3148 = 0x1000;
    g_3790 = resolve_symbol("libc.so", "strstr");
    g_37a0 = resolve_symbol("libc.so", "sscanf");
    g_37b0 = resolve_symbol("libc.so", "strdup");
    g_37c0 = resolve_symbol("libc.so", "mmap");
    register_vm_callback(0x2be0b, 0x6c76, 0x1, 0x78);
    return;
}
