void vm_func_01aff7(void) {
    register_vm_callback(0x1b056, 0x6c67, 0x1, 0x1e);
    return;
}
