uint32_t point_vs_aabb_axis_delta_helper(const float* point_xyz, const float* aabb_minmax) {
    local_10 = 0x0;
    local_14 = 0x0;
    local_18 = 0x0;
    if (f32(*(uint32_t *)(point_xyz)) >= f32(*(uint32_t *)(aabb_minmax))) {
        if (f32(*(uint32_t *)(point_xyz)) > f32(*(uint32_t *)(aabb_minmax + 0xc))) {
            local_10 = (f32(*(uint32_t *)(point_xyz)) - f32(*(uint32_t *)(aabb_minmax + 0xc)));
        }
    } else {
        local_10 = (f32(*(uint32_t *)(aabb_minmax)) - f32(*(uint32_t *)(point_xyz)));
    }
    if (f32(*(uint32_t *)(point_xyz + 0x4)) >= f32(*(uint32_t *)(aabb_minmax + 0x4))) {
        if (f32(*(uint32_t *)(point_xyz + 0x4)) > f32(*(uint32_t *)(aabb_minmax + 0x10))) {
            local_14 = (f32(*(uint32_t *)(point_xyz + 0x4)) - f32(*(uint32_t *)(aabb_minmax + 0x10)));
        }
    } else {
        local_14 = (f32(*(uint32_t *)(aabb_minmax + 0x4)) - f32(*(uint32_t *)(point_xyz + 0x4)));
    }
    if (f32(*(uint32_t *)(point_xyz + 0x8)) >= f32(*(uint32_t *)(aabb_minmax + 0x8))) {
        if (f32(*(uint32_t *)(point_xyz + 0x8)) > f32(*(uint32_t *)(aabb_minmax + 0x14))) {
            local_18 = (f32(*(uint32_t *)(point_xyz + 0x8)) - f32(*(uint32_t *)(aabb_minmax + 0x14)));
        }
    } else {
        local_18 = (f32(*(uint32_t *)(aabb_minmax + 0x8)) - f32(*(uint32_t *)(point_xyz + 0x8)));
    }
    local_1c = ((f32(local_10) <= f32(local_14)) ? local_14 : local_10);
    return ((f32(0x0) <= f32(local_18)) ? local_18 : local_1c);
}
