void vm_func_0022fa(void) {
    if (g_0118 != 0x0) {
        vm_call_reg(0x2d80);
        jni_env_holder_48 = jni_get_or_create_env_holder((fp + 0x28));
        local_50 = vm_func_00330c(jni_env_holder_48, "java/util/UUID");
        vm_func_00562b(jni_env_holder_48);
        local_58 = vm_func_00330c(jni_env_holder_48, "android/media/MediaDrm");
        vm_func_00562b(jni_env_holder_48);
        if (local_50 != 0x0) {
            if (local_58 != 0x0) {
                local_60 = vm_func_003809(jni_env_holder_48, local_50, "<init>", "(JJ)V");
                vm_func_00562b(jni_env_holder_48);
                local_68 = vm_func_003809(jni_env_holder_48, local_58, "<init>", "(Ljava/util/UUID;)V");
                vm_func_00562b(jni_env_holder_48);
                local_70 = vm_func_003809(jni_env_holder_48, local_58, "getPropertyByteArray", "(Ljava/lang/String;)[B");
                vm_func_00562b(jni_env_holder_48);
                if (local_60 != 0x0) {
                    if (local_68 != 0x0) {
                        if (local_70 != 0x0) {
                            local_78 = vm_func_0034ae(jni_env_holder_48, "deviceUniqueId");
                            vm_func_00562b(jni_env_holder_48);
                            if (local_78 != 0x0) {
                                local_80 = vm_func_00339f(jni_env_holder_48, local_50, local_60, 0xedef8ba979d64ace, 0xa3c827dcd51d21ed, 0x0, 0x0);
                                vm_func_00562b(jni_env_holder_48);
                                if (local_80 != 0x0) {
                                    local_88 = vm_func_00339f(jni_env_holder_48, local_58, local_68, local_80, 0x0, 0x0, 0x0);
                                    vm_func_00562b(jni_env_holder_48);
                                    if (local_88 != 0x0) {
                                        local_90 = vm_func_003f18(jni_env_holder_48, local_88, local_70, local_78, 0x0, 0x0, 0x0);
                                        vm_func_00562b(jni_env_holder_48);
                                        if (local_90 != 0x0) {
                                            size_98 = vm_func_00516f(jni_env_holder_48, local_90);
                                            vm_func_00562b(jni_env_holder_48);
                                            if (((int32_t)(size_98)) <= 597) {
                                                src_a0 = vm_func_006266(jni_env_holder_48, local_90, 0x0);
                                                vm_func_00562b(jni_env_holder_48);
                                                if (src_a0 != 0x0) {
                                                    g_0110 = size_98;
                                                    memset(g_0118, 0x0, 0x256);
                                                    memcpy_checked(g_0118, src_a0, (int64_t)(size_98));
                                                    vm_func_006305(jni_env_holder_48, local_90, src_a0, 0x0);
                                                }
                                            }
                                            vm_func_005692(jni_env_holder_48, local_90);
                                        }
                                        vm_func_005692(jni_env_holder_48, local_88);
                                    }
                                    vm_func_005692(jni_env_holder_48, local_80);
                                }
                                vm_func_005692(jni_env_holder_48, local_78);
                            }
                        }
                    }
                }
                vm_func_005692(jni_env_holder_48, local_50);
                vm_func_005692(jni_env_holder_48, local_58);
            }
        }
        vm_call_reg(0x2dea);
    } else {
        heap_ptr_002386 = malloc(0x256);
        g_0118 = heap_ptr_002386;
        if (heap_ptr_002386 != 0x0) {
            goto loc_0023a9;
        }
    }
    return;
}
