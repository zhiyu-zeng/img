void vm_func_011100(void) {
    g_03b8 = get_cached_module_base(0x2);
    g_03c0 = get_cached_module_base(0x1);
    if (((uint64_t)(g_03b8)) >= 0x100000001) {
        if (((uint64_t)(g_03c0)) >= 0x100000001) {
            register_vm_callback(0x10e76, 0x6c55, 0x1, 0x1e);
            register_vm_callback(0x10beb, 0x6c56, 0x1, 0x3c);
        }
    }
    return;
}
