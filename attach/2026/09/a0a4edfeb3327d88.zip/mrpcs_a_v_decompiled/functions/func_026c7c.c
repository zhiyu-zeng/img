void vm_func_026c7c(const void* arg0) {
    *(uint64_t *)(*(uint64_t *)(arg0)) = *(uint64_t *)(arg0 + 0x10);
    return;
}
