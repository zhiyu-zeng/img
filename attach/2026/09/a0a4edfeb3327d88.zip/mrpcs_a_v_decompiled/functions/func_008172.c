uint64_t vm_func_008172(uint64_t arg0, uint64_t arg1) {
    result = arg1;
    while (true) {
        loc_008218:
        if (!((result != 0x0) ? 0x0 : ((((*(uint64_t *)(result + 0x8)) != (0x0))) ? 1 : 0) & 0x1)) {
            result = *(uint64_t *)(result + 0x8);
            continue;
        }
        break;
    }
    return result;
}
