void vm_func_01eab0(void) {
    VmProcMapsPathLine maps_path_line_470;
    uint8_t* stack_buf_069 = (uint8_t*)(fp + 0x69); /* observed >= 0x400 bytes */
    uint8_t* stack_buf_888 = (uint8_t*)(fp + 0x888); /* observed >= 0xd bytes */
    g_1ab8 = 0xffffff9c;
    fn_ptr_28 = resolve_symbol("libc.so", "sigaction");
    fn_ptr_30 = resolve_symbol("libc.so", "sscanf");
    if (fn_ptr_28 != 0x0) {
        if (fn_ptr_30 != 0x0) {
            g_1ab8 = 0x0;
            local_58 = call_native_n(fn_ptr_28, 0xb, 0x0, (fp + 0x38));
            if (local_58 != 0x0) {
                g_1ab8 = local_58;
            } else {
                g_1abc = (*(uint64_t *)((fp + 0x38) + 0x8) >> 0x20);
                g_1ac0 = *(uint32_t *)((fp + 0x38) + 0x8);
                local_5c = 0x2;
                mincore((*(uint64_t *)((fp + 0x38) + 0x8) & 0xfffffffffffff000), 0x1000, (fp + 0x5c));
                g_1ad4 = local_5c;
                maps_file_60 = fopen("/proc/self/maps", "r");
                if (maps_file_60 == 0x0) {
                    g_1ab8 = 0xffffff9b;
                } else {
                    local_68 = 0x0;
                    while (true) {
                        if (fgets(stack_buf_069, 0x400, maps_file_60) == 0x0) break;
                        maps_path_line_470.start = 0x0;
                        maps_path_line_470.end = 0x0;
                        memset(maps_path_line_470.path, 0x0, 0x400);
                        call_native_n(fn_ptr_30, stack_buf_069, "%llx-%llx %*s %*s %*s %*s %s", &maps_path_line_470.start, &maps_path_line_470.end, maps_path_line_470.path);
                        if (((uint64_t)(maps_path_line_470.start)) > ((uint64_t)(*(uint64_t *)((fp + 0x38) + 0x8)))) {
                            continue;
                        } else {
                            if (((uint64_t)(*(uint64_t *)((fp + 0x38) + 0x8))) >= ((uint64_t)(maps_path_line_470.end))) {
                                continue;
                            } else {
                                local_68 = 0x1;
                                length_880 = strlen(maps_path_line_470.path);
                                size_884 = ((((int32_t)(length_880)) < 13) ? length_880 : 0xc);
                                memset(stack_buf_888, 0x0, 0xd);
                                strncpy(stack_buf_888, ((maps_path_line_470.path + (int64_t)(length_880)) - (int64_t)(size_884)), (int64_t)(size_884));
                                g_1ac4 = local_888;
                                g_1ac8 = *(uint64_t *)(stack_buf_888 + 0x4);
                                g_1ad0 = (*(uint64_t *)((fp + 0x38) + 0x8) - maps_path_line_470.start);
                                break;
                            }
                        }
                    }
                    loc_01f04b:
                    fclose(maps_file_60);
                    if (!(local_68 & 0x1)) {
                        g_1ac4 = 0xffffffffffffffff;
                        g_1ad0 = 0xffffffff;
                    }
                }
            }
        }
    }
    return;
}
