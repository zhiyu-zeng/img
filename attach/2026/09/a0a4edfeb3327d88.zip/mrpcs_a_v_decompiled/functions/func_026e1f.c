void vm_func_026e1f(const void* arg0, uint64_t arg1, uint64_t arg2, uint64_t arg3, uint64_t arg4, uint64_t arg5, uint64_t arg6, uint64_t arg7) {
    vm_func_026ef7(*(uint64_t *)(arg0 + 0x10), arg1, arg2, arg3, arg4, arg5, arg6, arg7);
    return;
}
