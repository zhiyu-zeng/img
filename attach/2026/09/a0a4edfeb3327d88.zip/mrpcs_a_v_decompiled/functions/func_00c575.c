void vm_func_00c575(uint64_t arg0) {
    local_28 = 0x0;
    vm_call_reg(0x9628);
    local_48 = vm_func_00330c(arg0, "android/app/ActivityThread");
    if (local_48 == 0x0) {
        vm_func_006a7e(arg0);
        serializer.append_u32(0x265);
        serializer.append_cstring("jniGetContext");
        serializer.flush(0x0);
        local_18 = 0x0;
        local_50 = 0x1;
    } else {
        if (vm_func_006a36(arg0) == 0x0) {
            vm_func_006ac6((fp + 0x30), local_48);
            local_58 = vm_func_0038d4(arg0, local_48, "currentActivityThread", "()Landroid/app/ActivityThread;");
            if (vm_func_006a36(arg0) == 0x0) {
                local_60 = vm_func_004824(arg0, local_48, local_58, 0x0, 0x0, 0x0, 0x0);
                if (local_60 == 0x0) {
                    vm_func_006a7e(arg0);
                    serializer.append_u32(0x269);
                    serializer.append_cstring("jniGetContext");
                    serializer.flush(0x0);
                    local_18 = 0x0;
                    local_50 = 0x1;
                } else {
                    if (vm_func_006a36(arg0) == 0x0) {
                        vm_func_006ac6((fp + 0x30), local_60);
                        local_68 = vm_func_003809(arg0, local_48, "getApplication", "()Landroid/app/Application;");
                        if (vm_func_006a36(arg0) == 0x0) {
                            local_28 = vm_func_003f18(arg0, local_60, local_68, 0x0, 0x0, 0x0, 0x0);
                            local_18 = local_28;
                            local_50 = 0x1;
                        } else {
                            vm_func_006a7e(arg0);
                            serializer.append_u32(0x26b);
                            serializer.append_cstring("jniGetContext");
                            serializer.flush(0x0);
                            local_18 = 0x0;
                            local_50 = 0x1;
                        }
                    } else {
                        vm_func_006a7e(arg0);
                        serializer.append_u32(0x269);
                        serializer.append_cstring("jniGetContext");
                        serializer.flush(0x0);
                        local_18 = 0x0;
                        local_50 = 0x1;
                        vm_call_reg(0x7279);
                        return;
                    }
                }
            } else {
                vm_func_006a7e(arg0);
                serializer.append_u32(0x267);
                serializer.append_cstring("jniGetContext");
                serializer.flush(0x0);
                local_18 = 0x0;
                local_50 = 0x1;
            }
        } else {
            vm_func_006a7e(arg0);
            serializer.append_u32(0x265);
            serializer.append_cstring("jniGetContext");
            serializer.flush(0x0);
            local_18 = 0x0;
            local_50 = 0x1;
            vm_call_reg(0x7279);
            return;
        }
    }
    vm_call_reg(0x7279);
    return;
}
