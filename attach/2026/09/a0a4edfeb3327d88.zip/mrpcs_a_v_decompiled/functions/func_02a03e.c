void vm_func_02a03e(void) {
    g_2ff0 = resolve_symbol("libdl.so", "dl_iterate_phdr");
    g_3008 = resolve_symbol("libc.so", "strstr");
    g_3018 = resolve_symbol("libc.so", "sscanf");
    g_3028 = resolve_symbol("libc.so", "strdup");
    register_vm_callback(0x2a174, 0x6c74, 0xb);
    register_vm_callback(0x2a328, 0x6c75, 0x1, 0x78);
    return;
}
