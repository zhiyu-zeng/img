uint64_t vm_func_0052f5(const void* arg0, uint64_t arg1, uint64_t arg2) {
    VmU64Triple u64_triple_018;
    u64_triple_018.first = arg1;
    u64_triple_018.second = (int64_t)(arg2);
    u64_triple_018.third = 0x0;
    return dispatch_registered_handler(0xaa, *(uint64_t *)(arg0), &u64_triple_018, 0x2);
}
