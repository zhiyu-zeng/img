void vm_func_005efb(uint64_t arg0, uint64_t arg1, uint64_t arg2, uint64_t arg3, uint64_t arg4, uint64_t arg5, uint64_t arg6, uint64_t arg7) {
    local_70 = vm_func_003809(arg0, arg1, arg2, arg3);
    vm_func_0044c3(arg0, arg1, local_70, arg4, arg5, arg6, arg7);
    return;
}
