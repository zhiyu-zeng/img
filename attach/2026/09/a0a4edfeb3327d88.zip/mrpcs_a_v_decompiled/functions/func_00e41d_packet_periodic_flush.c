uint64_t packet_periodic_flush(void* arg0, uint64_t arg1) {
    result = 0x0;
    *(uint16_t *)(arg0 + 0x8) = (*(uint16_t *)(arg0 + 0x8) + 0x1);
    if (((int32_t)((int64_t)((*(uint16_t *)(arg0 + 0x8) + 0x1)))) >= ((int32_t)(arg1))) {
        if (*(uint16_t *)(arg0 + 0xc) & 0x1) {
            result = (submit_packet_format_a(arg0) & 0x1);
        }
        if ((*(uint16_t *)(arg0 + 0xc) & 0x2) != 0x0) {
            result = (submit_packet_format_b(arg0) & 0x1);
        }
        *(uint16_t *)(arg0 + 0x8) = 0x0;
        *(uint32_t *)(arg0 + 0x14) = 0x0;
        memset(*(uint64_t *)(arg0), 0x0, (int64_t)(*(uint32_t *)(arg0 + 0x10)));
    }
    return result;
}
