void vm_func_015c6a(void* arg0, uint64_t src) {
    if (*(uint64_t *)(arg0 + 0x8) == *(uint64_t *)(arg0 + 0x10)) {
        vm_func_015e60(arg0);
    }
    if (*(uint64_t *)(arg0 + 0x8) != 0x0) {
        memcpy_checked(*(uint64_t *)(arg0 + 0x8), src, 0x14);
        *(uint64_t *)(arg0 + 0x8) = (*(uint64_t *)(arg0 + 0x8) + 0x14);
    }
    return;
}
