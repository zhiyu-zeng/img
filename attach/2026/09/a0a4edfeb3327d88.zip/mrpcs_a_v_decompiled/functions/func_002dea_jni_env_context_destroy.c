void jni_env_context_destroy(void* arg0) {
    if (*(uint8_t *)(arg0 + 0x11) & 0x1) {
        status_20 = jvm_detach_current_thread(*(uint64_t *)(arg0));
    }
    if (*(uint64_t *)(arg0 + 0x18) != 0x0) {
        if (*(uint64_t *)(arg0 + 0x18) != 0x0) {
            vm_call_reg(0x2f5a);
            ((fn_operator_delete)(*(uint64_t *)(arg0 + 0x18)));
        }
        *(uint64_t *)(arg0 + 0x18) = 0x0;
    }
    return;
}
