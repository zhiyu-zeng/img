uint64_t vm_func_00fb8d(const void* arg0) {
    fn_ptr_38 = get_vm_callback_thunk(*(uint32_t *)(arg0));
    if (fn_ptr_38 != 0x0) {
        vm_func_00fff6((fp + 0x40));
        if (((uint64_t)(*(uint64_t *)(arg0 + 0x8))) < 0x10000001) {
            result = 0x0;
            local_58 = 0x1;
        } else {
            call_native_n(*(uint64_t *)(arg0 + 0x8), fn_ptr_38, (fp + 0x40));
            local_5c = vm_func_0100f2((fp + 0x40));
            local_60 = ((((local_5c << 0x20) >> 0x20) * 0x38) + 0x40);
            heap_ptr_68 = malloc(((((((local_5c << 0x20) >> 0x20) * 0x38) + 0x40) << 0x20) >> 0x20));
            if (heap_ptr_68 != 0x0) {
                index_70 = 0x0;
                while (((int32_t)(index_70)) < ((int32_t)(local_5c))) {
                    *(uint64_t *)((heap_ptr_68 + ((int64_t)(index_70) * 0x38)) + 0x18) = *(uint64_t *)(vm_func_0101a2((fp + 0x40), (int64_t)(index_70)) + 0x10);
                    memcpy_checked(((heap_ptr_68 + ((int64_t)(index_70) * 0x38)) + 0x20), (vm_func_0101a2((fp + 0x40), (int64_t)(index_70)) + 0x18), 0x20);
                    *(uint32_t *)((heap_ptr_68 + ((int64_t)(index_70) * 0x38)) + 0x10) = *(uint32_t *)(vm_func_0101a2((fp + 0x40), (int64_t)(index_70)) + 0x8);
                    index_70 = (index_70 + 0x1);
                    continue;
                }
                *(uint64_t *)(heap_ptr_68) = (int64_t)(local_5c);
                result = heap_ptr_68;
                local_58 = 0x1;
            } else {
                result = 0x0;
                local_58 = 0x1;
            }
        }
        vm_func_0101fa((fp + 0x40));
    } else {
        result = 0x0;
    }
    return result;
}
