void vm_func_0054f2(const void* arg0) {
    dispatch_registered_handler(0xc, *(uint64_t *)(arg0), 0x0, 0x0);
    return;
}
