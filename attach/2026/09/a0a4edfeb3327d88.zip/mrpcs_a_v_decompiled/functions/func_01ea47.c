void vm_func_01ea47(void) {
    vm_func_01eab0();
    register_vm_callback(0x1f0e2, 0x6c6a, 0x1, 0x78);
    return;
}
