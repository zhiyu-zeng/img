uint64_t vm_func_013825(void) {
    VmCpuSet1024 cpu_set_060;
    VmCpuSet1024 cpu_set_0e8;
    struct { union { uint64_t word_00; struct { uint32_t field_00; uint32_t field_04; }; uint8_t byte_00[8]; }; union { uint8_t tail_08[12]; struct { uint32_t field_08; uint32_t field_0c; uint32_t field_10; }; }; } record20_1f8;
    struct { union { uint64_t word_00; struct { uint32_t field_00; uint32_t field_04; }; uint8_t byte_00[8]; }; union { uint8_t tail_08[12]; struct { uint32_t field_08; uint32_t field_0c; uint32_t field_10; }; }; } record20_2d8;
    struct { union { uint64_t word_00; struct { uint32_t field_00; uint32_t field_04; }; uint8_t byte_00[8]; }; union { uint8_t tail_08[12]; struct { uint32_t field_08; uint32_t field_0c; uint32_t field_10; }; }; } record20_4c8;
    struct { union { uint64_t word_00; struct { uint32_t field_00; uint32_t field_04; }; uint8_t byte_00[8]; }; union { uint8_t tail_08[12]; struct { uint32_t field_08; uint32_t field_0c; uint32_t field_10; }; }; } record20_520;
    struct { union { uint64_t word_00; struct { uint32_t field_00; uint32_t field_04; }; }; uint64_t field_08; uint32_t field_10; } local_overlay_1c8;
    uint8_t* stack_buf_1b0 = (uint8_t*)(fp + 0x1b0); /* observed >= 0xa bytes */
    uint8_t* stack_buf_2f0 = (uint8_t*)(fp + 0x2f0); /* observed >= 0x17 bytes */
    uint8_t* stack_buf_30d = (uint8_t*)(fp + 0x30d); /* observed >= 0x1e bytes */
    uint8_t* stack_buf_331 = (uint8_t*)(fp + 0x331); /* observed >= 0x18 bytes */
    uint8_t* stack_buf_351 = (uint8_t*)(fp + 0x351); /* observed >= 0x15 bytes */
    uint8_t* stack_buf_4e8 = (uint8_t*)(fp + 0x4e8); /* observed >= 0x14 bytes */
    status_e0 = syscall_sched_getaffinity(0x0, 0x80, &cpu_set_060);
    local_568 = 0x36e;
    if (((int32_t)(status_e0)) >= 0) {
        hostcall_dynamic(&cpu_set_0e8, 0x0, 0x80);
        local_168 = 0x0;
        if (((uint64_t)(0x0)) <= 0x3ff) {
            cpu_set_0e8.bits[(((local_168) >> 0x6) & 0xf)] = (cpu_set_0e8.bits[(((local_168) >> 0x6) & 0xf)] | (0x1 << (local_168 & 0x3f)));
        }
        local_170 = 0x1;
        if (0x1 <= 0x3ff) {
            cpu_set_0e8.bits[(((local_170) >> 0x6) & 0xf)] = (cpu_set_0e8.bits[(((local_170) >> 0x6) & 0xf)] | (0x1 << (local_170 & 0x3f)));
        }
        local_178 = 0x3;
        if (0x3 <= 0x3ff) {
            cpu_set_0e8.bits[(((local_178) >> 0x6) & 0xf)] = (cpu_set_0e8.bits[(((local_178) >> 0x6) & 0xf)] | (0x1 << (local_178 & 0x3f)));
        }
        local_180 = 0x4;
        if (0x4 <= 0x3ff) {
            cpu_set_0e8.bits[(((local_180) >> 0x6) & 0xf)] = (cpu_set_0e8.bits[(((local_180) >> 0x6) & 0xf)] | (0x1 << (local_180 & 0x3f)));
        }
        local_188 = 0x6;
        if (0x6 <= 0x3ff) {
            cpu_set_0e8.bits[(((local_188) >> 0x6) & 0xf)] = (cpu_set_0e8.bits[(((local_188) >> 0x6) & 0xf)] | (0x1 << (local_188 & 0x3f)));
        }
        status_e0 = syscall_sched_setaffinity(0x0, 0x80, &cpu_set_0e8);
    }
    result = 0x0;
    vm_func_015b6e((fp + 0x198));
    memcpy_checked(stack_buf_1b0, &g_04bd, 0xa);
    index_1bc = 0x0;
    while (((uint64_t)(index_1bc)) <= 0x8) {
        local_1c0 = ((((0xdd - ((((((((((((index_1bc - ((((*(uint8_t *)(stack_buf_1b0 + index_1bc) + 0x12) & 0xff) >> 0x6) | (((*(uint8_t *)(stack_buf_1b0 + index_1bc) + 0x12) & 0xff) << 0x2))) & 0xff) >> 0x1) | (((index_1bc - ((((*(uint8_t *)(stack_buf_1b0 + index_1bc) + 0x12) & 0xff) >> 0x6) | (((*(uint8_t *)(stack_buf_1b0 + index_1bc) + 0x12) & 0xff) << 0x2))) & 0xff) << 0x7)) - index_1bc) & 0xff) >> 0x5) | (((((((index_1bc - ((((*(uint8_t *)(stack_buf_1b0 + index_1bc) + 0x12) & 0xff) >> 0x6) | (((*(uint8_t *)(stack_buf_1b0 + index_1bc) + 0x12) & 0xff) << 0x2))) & 0xff) >> 0x1) | (((index_1bc - ((((*(uint8_t *)(stack_buf_1b0 + index_1bc) + 0x12) & 0xff) >> 0x6) | (((*(uint8_t *)(stack_buf_1b0 + index_1bc) + 0x12) & 0xff) << 0x2))) & 0xff) << 0x7)) - index_1bc) & 0xff) << 0x3)) + 0x2d) & 0xff) >> 0x7) | (((((((((((index_1bc - ((((*(uint8_t *)(stack_buf_1b0 + index_1bc) + 0x12) & 0xff) >> 0x6) | (((*(uint8_t *)(stack_buf_1b0 + index_1bc) + 0x12) & 0xff) << 0x2))) & 0xff) >> 0x1) | (((index_1bc - ((((*(uint8_t *)(stack_buf_1b0 + index_1bc) + 0x12) & 0xff) >> 0x6) | (((*(uint8_t *)(stack_buf_1b0 + index_1bc) + 0x12) & 0xff) << 0x2))) & 0xff) << 0x7)) - index_1bc) & 0xff) >> 0x5) | (((((((index_1bc - ((((*(uint8_t *)(stack_buf_1b0 + index_1bc) + 0x12) & 0xff) >> 0x6) | (((*(uint8_t *)(stack_buf_1b0 + index_1bc) + 0x12) & 0xff) << 0x2))) & 0xff) >> 0x1) | (((index_1bc - ((((*(uint8_t *)(stack_buf_1b0 + index_1bc) + 0x12) & 0xff) >> 0x6) | (((*(uint8_t *)(stack_buf_1b0 + index_1bc) + 0x12) & 0xff) << 0x2))) & 0xff) << 0x7)) - index_1bc) & 0xff) << 0x3)) + 0x2d) & 0xff) << 0x1))) & 0xff) >> 0x7) | (((0xdd - ((((((((((((index_1bc - ((((*(uint8_t *)(stack_buf_1b0 + index_1bc) + 0x12) & 0xff) >> 0x6) | (((*(uint8_t *)(stack_buf_1b0 + index_1bc) + 0x12) & 0xff) << 0x2))) & 0xff) >> 0x1) | (((index_1bc - ((((*(uint8_t *)(stack_buf_1b0 + index_1bc) + 0x12) & 0xff) >> 0x6) | (((*(uint8_t *)(stack_buf_1b0 + index_1bc) + 0x12) & 0xff) << 0x2))) & 0xff) << 0x7)) - index_1bc) & 0xff) >> 0x5) | (((((((index_1bc - ((((*(uint8_t *)(stack_buf_1b0 + index_1bc) + 0x12) & 0xff) >> 0x6) | (((*(uint8_t *)(stack_buf_1b0 + index_1bc) + 0x12) & 0xff) << 0x2))) & 0xff) >> 0x1) | (((index_1bc - ((((*(uint8_t *)(stack_buf_1b0 + index_1bc) + 0x12) & 0xff) >> 0x6) | (((*(uint8_t *)(stack_buf_1b0 + index_1bc) + 0x12) & 0xff) << 0x2))) & 0xff) << 0x7)) - index_1bc) & 0xff) << 0x3)) + 0x2d) & 0xff) >> 0x7) | (((((((((((index_1bc - ((((*(uint8_t *)(stack_buf_1b0 + index_1bc) + 0x12) & 0xff) >> 0x6) | (((*(uint8_t *)(stack_buf_1b0 + index_1bc) + 0x12) & 0xff) << 0x2))) & 0xff) >> 0x1) | (((index_1bc - ((((*(uint8_t *)(stack_buf_1b0 + index_1bc) + 0x12) & 0xff) >> 0x6) | (((*(uint8_t *)(stack_buf_1b0 + index_1bc) + 0x12) & 0xff) << 0x2))) & 0xff) << 0x7)) - index_1bc) & 0xff) >> 0x5) | (((((((index_1bc - ((((*(uint8_t *)(stack_buf_1b0 + index_1bc) + 0x12) & 0xff) >> 0x6) | (((*(uint8_t *)(stack_buf_1b0 + index_1bc) + 0x12) & 0xff) << 0x2))) & 0xff) >> 0x1) | (((index_1bc - ((((*(uint8_t *)(stack_buf_1b0 + index_1bc) + 0x12) & 0xff) >> 0x6) | (((*(uint8_t *)(stack_buf_1b0 + index_1bc) + 0x12) & 0xff) << 0x2))) & 0xff) << 0x7)) - index_1bc) & 0xff) << 0x3)) + 0x2d) & 0xff) << 0x1))) & 0xff) << 0x1));
        *(uint8_t *)(stack_buf_1b0 + index_1bc) = ((((0xdd - ((((((((((((index_1bc - ((((*(uint8_t *)(stack_buf_1b0 + index_1bc) + 0x12) & 0xff) >> 0x6) | (((*(uint8_t *)(stack_buf_1b0 + index_1bc) + 0x12) & 0xff) << 0x2))) & 0xff) >> 0x1) | (((index_1bc - ((((*(uint8_t *)(stack_buf_1b0 + index_1bc) + 0x12) & 0xff) >> 0x6) | (((*(uint8_t *)(stack_buf_1b0 + index_1bc) + 0x12) & 0xff) << 0x2))) & 0xff) << 0x7)) - index_1bc) & 0xff) >> 0x5) | (((((((index_1bc - ((((*(uint8_t *)(stack_buf_1b0 + index_1bc) + 0x12) & 0xff) >> 0x6) | (((*(uint8_t *)(stack_buf_1b0 + index_1bc) + 0x12) & 0xff) << 0x2))) & 0xff) >> 0x1) | (((index_1bc - ((((*(uint8_t *)(stack_buf_1b0 + index_1bc) + 0x12) & 0xff) >> 0x6) | (((*(uint8_t *)(stack_buf_1b0 + index_1bc) + 0x12) & 0xff) << 0x2))) & 0xff) << 0x7)) - index_1bc) & 0xff) << 0x3)) + 0x2d) & 0xff) >> 0x7) | (((((((((((index_1bc - ((((*(uint8_t *)(stack_buf_1b0 + index_1bc) + 0x12) & 0xff) >> 0x6) | (((*(uint8_t *)(stack_buf_1b0 + index_1bc) + 0x12) & 0xff) << 0x2))) & 0xff) >> 0x1) | (((index_1bc - ((((*(uint8_t *)(stack_buf_1b0 + index_1bc) + 0x12) & 0xff) >> 0x6) | (((*(uint8_t *)(stack_buf_1b0 + index_1bc) + 0x12) & 0xff) << 0x2))) & 0xff) << 0x7)) - index_1bc) & 0xff) >> 0x5) | (((((((index_1bc - ((((*(uint8_t *)(stack_buf_1b0 + index_1bc) + 0x12) & 0xff) >> 0x6) | (((*(uint8_t *)(stack_buf_1b0 + index_1bc) + 0x12) & 0xff) << 0x2))) & 0xff) >> 0x1) | (((index_1bc - ((((*(uint8_t *)(stack_buf_1b0 + index_1bc) + 0x12) & 0xff) >> 0x6) | (((*(uint8_t *)(stack_buf_1b0 + index_1bc) + 0x12) & 0xff) << 0x2))) & 0xff) << 0x7)) - index_1bc) & 0xff) << 0x3)) + 0x2d) & 0xff) << 0x1))) & 0xff) >> 0x7) | (((0xdd - ((((((((((((index_1bc - ((((*(uint8_t *)(stack_buf_1b0 + index_1bc) + 0x12) & 0xff) >> 0x6) | (((*(uint8_t *)(stack_buf_1b0 + index_1bc) + 0x12) & 0xff) << 0x2))) & 0xff) >> 0x1) | (((index_1bc - ((((*(uint8_t *)(stack_buf_1b0 + index_1bc) + 0x12) & 0xff) >> 0x6) | (((*(uint8_t *)(stack_buf_1b0 + index_1bc) + 0x12) & 0xff) << 0x2))) & 0xff) << 0x7)) - index_1bc) & 0xff) >> 0x5) | (((((((index_1bc - ((((*(uint8_t *)(stack_buf_1b0 + index_1bc) + 0x12) & 0xff) >> 0x6) | (((*(uint8_t *)(stack_buf_1b0 + index_1bc) + 0x12) & 0xff) << 0x2))) & 0xff) >> 0x1) | (((index_1bc - ((((*(uint8_t *)(stack_buf_1b0 + index_1bc) + 0x12) & 0xff) >> 0x6) | (((*(uint8_t *)(stack_buf_1b0 + index_1bc) + 0x12) & 0xff) << 0x2))) & 0xff) << 0x7)) - index_1bc) & 0xff) << 0x3)) + 0x2d) & 0xff) >> 0x7) | (((((((((((index_1bc - ((((*(uint8_t *)(stack_buf_1b0 + index_1bc) + 0x12) & 0xff) >> 0x6) | (((*(uint8_t *)(stack_buf_1b0 + index_1bc) + 0x12) & 0xff) << 0x2))) & 0xff) >> 0x1) | (((index_1bc - ((((*(uint8_t *)(stack_buf_1b0 + index_1bc) + 0x12) & 0xff) >> 0x6) | (((*(uint8_t *)(stack_buf_1b0 + index_1bc) + 0x12) & 0xff) << 0x2))) & 0xff) << 0x7)) - index_1bc) & 0xff) >> 0x5) | (((((((index_1bc - ((((*(uint8_t *)(stack_buf_1b0 + index_1bc) + 0x12) & 0xff) >> 0x6) | (((*(uint8_t *)(stack_buf_1b0 + index_1bc) + 0x12) & 0xff) << 0x2))) & 0xff) >> 0x1) | (((index_1bc - ((((*(uint8_t *)(stack_buf_1b0 + index_1bc) + 0x12) & 0xff) >> 0x6) | (((*(uint8_t *)(stack_buf_1b0 + index_1bc) + 0x12) & 0xff) << 0x2))) & 0xff) << 0x7)) - index_1bc) & 0xff) << 0x3)) + 0x2d) & 0xff) << 0x1))) & 0xff) << 0x1));
        index_1bc = (index_1bc + 0x1);
        continue;
    }
    local_570 = 0x80;
    local_1c4 = 0x12c;
    local_560 = 0x523;
    while (((uint32_t)(local_1c4)) <= 0x7fff) {
        hostcall_dynamic(&local_overlay_1c8, 0x0, 0x14);
        local_overlay_1c8.word_00 = 0xffffffff00000000;
        local_overlay_1c8.field_08 = 0xffffffff;
        local_overlay_1c8.field_10 = 0x0;
        hostcall_dynamic((fp + 0x1dc), 0x0, 0x10);
        hostcall_dynamic((fp + 0x1dc), 0x10, stack_buf_1b0, local_1c4);
        if (local_1c4 != *(uint32_t *)(*(uint64_t *)(&g_0470) + 0x4)) {
            if (vm_func_0117fc((fp + 0x1dc)) == 0x0) {
                local_overlay_1c8.word_00 = (local_overlay_1c8.word_00 | 0x1);
                local_overlay_1c8.field_04 = local_1c4;
                vm_func_015c6a((fp + 0x198), &local_overlay_1c8);
            }
        }
        local_1c4 = (local_1c4 + 0x1);
        continue;
    }
    index_1f0 = 0x0;
    while (true) {
        if (((uint64_t)(index_1f0)) >= ((uint64_t)(vm_func_012bf1((fp + 0x198))))) break;
        memcpy_checked(&record20_1f8, vm_func_012ca1((fp + 0x198), index_1f0), 0x14);
        if (record20_1f8.word_00 != 0x1) {
            index_1f0 = (index_1f0 + 0x1);
            continue;
        } else {
            status_20c = sys_tgkill_checked(record20_1f8.field_04, record20_1f8.field_04, 0x1c);
            if (status_20c == 0xfffffffd) {
                ptr_0141a8 = vm_func_012cfb((fp + 0x198), index_1f0);
                *(uint32_t *)(ptr_0141a8) = (*(uint32_t *)(ptr_0141a8) | 0x2);
                index_1f0 = (index_1f0 + 0x1);
                continue;
            } else {
                if (status_20c != 0x0) {
                    index_1f0 = (index_1f0 + 0x1);
                    continue;
                } else {
                    hostcall_dynamic((fp + 0x210), 0x0, 0x10);
                    hostcall_dynamic((fp + 0x210), 0x10, stack_buf_1b0, record20_1f8.field_04);
                    if (vm_func_01122f((fp + 0x210)) != 0xfffffff3) {
                        index_1f0 = (index_1f0 + 0x1);
                        continue;
                    } else {
                        result = 0x3;
                        goto loc_015681;
                    }
                }
            }
        }
    }
    set_context_offset(0x1);
    if ((*(uint8_t *)(*(uint64_t *)(&g_0470)) & 0x40) != 0x0) {
        memcpy_checked((fp + 0x220), &g_04c7, 0x23);
        index_244 = 0x0;
        while (((uint64_t)(index_244)) <= 0x21) {
            local_248 = ((((((((((((0x0 - (((((*(uint8_t *)((fp + 0x220) + index_244) + 0xffffffb3) & 0xff) >> 0x5) | (((*(uint8_t *)((fp + 0x220) + index_244) + 0xffffffb3) & 0xff) << 0x3)) ^ 0xffffff39)) & 0xff) >> 0x3) | (((0x0 - (((((*(uint8_t *)((fp + 0x220) + index_244) + 0xffffffb3) & 0xff) >> 0x5) | (((*(uint8_t *)((fp + 0x220) + index_244) + 0xffffffb3) & 0xff) << 0x3)) ^ 0xffffff39)) & 0xff) << 0x5)) + 0x1) & 0xff) >> 0x2) | (((((((0x0 - (((((*(uint8_t *)((fp + 0x220) + index_244) + 0xffffffb3) & 0xff) >> 0x5) | (((*(uint8_t *)((fp + 0x220) + index_244) + 0xffffffb3) & 0xff) << 0x3)) ^ 0xffffff39)) & 0xff) >> 0x3) | (((0x0 - (((((*(uint8_t *)((fp + 0x220) + index_244) + 0xffffffb3) & 0xff) >> 0x5) | (((*(uint8_t *)((fp + 0x220) + index_244) + 0xffffffb3) & 0xff) << 0x3)) ^ 0xffffff39)) & 0xff) << 0x5)) + 0x1) & 0xff) << 0x6)) + 0xffffff4d) & 0xff) >> 0x7) | (((((((((((0x0 - (((((*(uint8_t *)((fp + 0x220) + index_244) + 0xffffffb3) & 0xff) >> 0x5) | (((*(uint8_t *)((fp + 0x220) + index_244) + 0xffffffb3) & 0xff) << 0x3)) ^ 0xffffff39)) & 0xff) >> 0x3) | (((0x0 - (((((*(uint8_t *)((fp + 0x220) + index_244) + 0xffffffb3) & 0xff) >> 0x5) | (((*(uint8_t *)((fp + 0x220) + index_244) + 0xffffffb3) & 0xff) << 0x3)) ^ 0xffffff39)) & 0xff) << 0x5)) + 0x1) & 0xff) >> 0x2) | (((((((0x0 - (((((*(uint8_t *)((fp + 0x220) + index_244) + 0xffffffb3) & 0xff) >> 0x5) | (((*(uint8_t *)((fp + 0x220) + index_244) + 0xffffffb3) & 0xff) << 0x3)) ^ 0xffffff39)) & 0xff) >> 0x3) | (((0x0 - (((((*(uint8_t *)((fp + 0x220) + index_244) + 0xffffffb3) & 0xff) >> 0x5) | (((*(uint8_t *)((fp + 0x220) + index_244) + 0xffffffb3) & 0xff) << 0x3)) ^ 0xffffff39)) & 0xff) << 0x5)) + 0x1) & 0xff) << 0x6)) + 0xffffff4d) & 0xff) << 0x1));
            *(uint8_t *)((fp + 0x220) + index_244) = ((((((((((((0x0 - (((((*(uint8_t *)((fp + 0x220) + index_244) + 0xffffffb3) & 0xff) >> 0x5) | (((*(uint8_t *)((fp + 0x220) + index_244) + 0xffffffb3) & 0xff) << 0x3)) ^ 0xffffff39)) & 0xff) >> 0x3) | (((0x0 - (((((*(uint8_t *)((fp + 0x220) + index_244) + 0xffffffb3) & 0xff) >> 0x5) | (((*(uint8_t *)((fp + 0x220) + index_244) + 0xffffffb3) & 0xff) << 0x3)) ^ 0xffffff39)) & 0xff) << 0x5)) + 0x1) & 0xff) >> 0x2) | (((((((0x0 - (((((*(uint8_t *)((fp + 0x220) + index_244) + 0xffffffb3) & 0xff) >> 0x5) | (((*(uint8_t *)((fp + 0x220) + index_244) + 0xffffffb3) & 0xff) << 0x3)) ^ 0xffffff39)) & 0xff) >> 0x3) | (((0x0 - (((((*(uint8_t *)((fp + 0x220) + index_244) + 0xffffffb3) & 0xff) >> 0x5) | (((*(uint8_t *)((fp + 0x220) + index_244) + 0xffffffb3) & 0xff) << 0x3)) ^ 0xffffff39)) & 0xff) << 0x5)) + 0x1) & 0xff) << 0x6)) + 0xffffff4d) & 0xff) >> 0x7) | (((((((((((0x0 - (((((*(uint8_t *)((fp + 0x220) + index_244) + 0xffffffb3) & 0xff) >> 0x5) | (((*(uint8_t *)((fp + 0x220) + index_244) + 0xffffffb3) & 0xff) << 0x3)) ^ 0xffffff39)) & 0xff) >> 0x3) | (((0x0 - (((((*(uint8_t *)((fp + 0x220) + index_244) + 0xffffffb3) & 0xff) >> 0x5) | (((*(uint8_t *)((fp + 0x220) + index_244) + 0xffffffb3) & 0xff) << 0x3)) ^ 0xffffff39)) & 0xff) << 0x5)) + 0x1) & 0xff) >> 0x2) | (((((((0x0 - (((((*(uint8_t *)((fp + 0x220) + index_244) + 0xffffffb3) & 0xff) >> 0x5) | (((*(uint8_t *)((fp + 0x220) + index_244) + 0xffffffb3) & 0xff) << 0x3)) ^ 0xffffff39)) & 0xff) >> 0x3) | (((0x0 - (((((*(uint8_t *)((fp + 0x220) + index_244) + 0xffffffb3) & 0xff) >> 0x5) | (((*(uint8_t *)((fp + 0x220) + index_244) + 0xffffffb3) & 0xff) << 0x3)) ^ 0xffffff39)) & 0xff) << 0x5)) + 0x1) & 0xff) << 0x6)) + 0xffffff4d) & 0xff) << 0x1));
            index_244 = (index_244 + 0x1);
            continue;
        }
        local_588 = 0x360;
        hostcall_dynamic((fp + 0x249), 0x0, local_570);
        index_2d0 = 0x0;
        while (true) {
            if (((uint64_t)(index_2d0)) >= ((uint64_t)(vm_func_012bf1((fp + 0x198))))) break;
            memcpy_checked(&record20_2d8, vm_func_012ca1((fp + 0x198), index_2d0), 0x14);
            if (record20_2d8.word_00 & 0x1) {
                if ((record20_2d8.word_00 & 0x802) == 0x0) {
                    hostcall_dynamic((fp + 0x249), local_570, (fp + 0x220), record20_2d8.field_04);
                    if (vm_func_01137f((fp + 0x249)) == 0x0) {
                        local_2ec = vm_func_0134a7((fp + 0x198), record20_2d8.field_04);
                        ptr_01456a = vm_func_012cfb((fp + 0x198), index_2d0);
                        *(uint32_t *)(ptr_01456a) = (*(uint32_t *)(ptr_01456a) | 0x8000);
                        *(uint32_t *)(vm_func_012cfb((fp + 0x198), index_2d0) + 0xc) = local_2ec;
                    }
                }
            }
            index_2d0 = (index_2d0 + 0x1);
            continue;
        }
    }
    hostcall_dynamic(0x2);
    if (*(uint8_t *)(*(uint64_t *)(&g_0470)) & 0x1) {
        size_590 = 0x17;
        memcpy_checked(stack_buf_2f0, &g_04ea, 0x17);
        index_308 = 0x0;
        while (((uint64_t)(index_308)) <= 0x15) {
            local_30c = (0x0 - ((((((0x0 - ((((((((((*(uint8_t *)(stack_buf_2f0 + index_308) + 0xef) ^ 0xffffffff) & 0xff) >> 0x7) | ((((*(uint8_t *)(stack_buf_2f0 + index_308) + 0xef) ^ 0xffffffff) & 0xff) << 0x1)) - index_308) & 0xff) >> 0x2) | ((((((((*(uint8_t *)(stack_buf_2f0 + index_308) + 0xef) ^ 0xffffffff) & 0xff) >> 0x7) | ((((*(uint8_t *)(stack_buf_2f0 + index_308) + 0xef) ^ 0xffffffff) & 0xff) << 0x1)) - index_308) & 0xff) << 0x6)) + index_308)) & 0xff) >> 0x5) | (((0x0 - ((((((((((*(uint8_t *)(stack_buf_2f0 + index_308) + 0xef) ^ 0xffffffff) & 0xff) >> 0x7) | ((((*(uint8_t *)(stack_buf_2f0 + index_308) + 0xef) ^ 0xffffffff) & 0xff) << 0x1)) - index_308) & 0xff) >> 0x2) | ((((((((*(uint8_t *)(stack_buf_2f0 + index_308) + 0xef) ^ 0xffffffff) & 0xff) >> 0x7) | ((((*(uint8_t *)(stack_buf_2f0 + index_308) + 0xef) ^ 0xffffffff) & 0xff) << 0x1)) - index_308) & 0xff) << 0x6)) + index_308)) & 0xff) << 0x3)) ^ 0xffffffff) - index_308));
            *(uint8_t *)(stack_buf_2f0 + index_308) = (0x0 - ((((((0x0 - ((((((((((*(uint8_t *)(stack_buf_2f0 + index_308) + 0xef) ^ 0xffffffff) & 0xff) >> 0x7) | ((((*(uint8_t *)(stack_buf_2f0 + index_308) + 0xef) ^ 0xffffffff) & 0xff) << 0x1)) - index_308) & 0xff) >> 0x2) | ((((((((*(uint8_t *)(stack_buf_2f0 + index_308) + 0xef) ^ 0xffffffff) & 0xff) >> 0x7) | ((((*(uint8_t *)(stack_buf_2f0 + index_308) + 0xef) ^ 0xffffffff) & 0xff) << 0x1)) - index_308) & 0xff) << 0x6)) + index_308)) & 0xff) >> 0x5) | (((0x0 - ((((((((((*(uint8_t *)(stack_buf_2f0 + index_308) + 0xef) ^ 0xffffffff) & 0xff) >> 0x7) | ((((*(uint8_t *)(stack_buf_2f0 + index_308) + 0xef) ^ 0xffffffff) & 0xff) << 0x1)) - index_308) & 0xff) >> 0x2) | ((((((((*(uint8_t *)(stack_buf_2f0 + index_308) + 0xef) ^ 0xffffffff) & 0xff) >> 0x7) | ((((*(uint8_t *)(stack_buf_2f0 + index_308) + 0xef) ^ 0xffffffff) & 0xff) << 0x1)) - index_308) & 0xff) << 0x6)) + index_308)) & 0xff) << 0x3)) ^ 0xffffffff) - index_308));
            index_308 = (index_308 + 0x1);
            continue;
        }
        memcpy_checked(stack_buf_30d, &g_0501, 0x1e);
        index_32c = 0x0;
        while (((uint64_t)(index_32c)) <= 0x1c) {
            local_330 = ((((((((*(uint8_t *)(stack_buf_30d + index_32c) + 0xaa) ^ 0x7d) + 0x71) ^ 0x68) + 0x34) ^ 0x9b) + 0x18) ^ 0x69);
            *(uint8_t *)(stack_buf_30d + index_32c) = ((((((((*(uint8_t *)(stack_buf_30d + index_32c) + 0xaa) ^ 0x7d) + 0x71) ^ 0x68) + 0x34) ^ 0x9b) + 0x18) ^ 0x69);
            index_32c = (index_32c + 0x1);
            continue;
        }
        local_58c = 0x0;
        local_588 = 0x2;
        vm_func_012ddb(0x0, stack_buf_2f0, stack_buf_30d, (fp + 0x198));
        if (!(*(uint8_t *)(*(uint64_t *)(&g_0470) + 0x1) & 0x1)) {
            memcpy_checked(stack_buf_331, &g_051f, 0x18);
            index_34c = 0x0;
            while (((uint64_t)(index_34c)) <= 0x16) {
                local_350 = ((((((((0x0 - ((((((0x0 - (((((((*(uint8_t *)(stack_buf_331 + index_34c) - index_34c) ^ index_34c) - index_34c) + 0x37) & 0xff) >> 0x1) | ((((((*(uint8_t *)(stack_buf_331 + index_34c) - index_34c) ^ index_34c) - index_34c) + 0x37) & 0xff) << 0x7))) & 0xff) ^ 0xc4) >> 0x7) | ((((0x0 - (((((((*(uint8_t *)(stack_buf_331 + index_34c) - index_34c) ^ index_34c) - index_34c) + 0x37) & 0xff) >> 0x1) | ((((((*(uint8_t *)(stack_buf_331 + index_34c) - index_34c) ^ index_34c) - index_34c) + 0x37) & 0xff) << 0x7))) & 0xff) ^ 0xc4) << 0x1)) ^ index_34c)) & 0xff) >> 0x5) | (((0x0 - ((((((0x0 - (((((((*(uint8_t *)(stack_buf_331 + index_34c) - index_34c) ^ index_34c) - index_34c) + 0x37) & 0xff) >> 0x1) | ((((((*(uint8_t *)(stack_buf_331 + index_34c) - index_34c) ^ index_34c) - index_34c) + 0x37) & 0xff) << 0x7))) & 0xff) ^ 0xc4) >> 0x7) | ((((0x0 - (((((((*(uint8_t *)(stack_buf_331 + index_34c) - index_34c) ^ index_34c) - index_34c) + 0x37) & 0xff) >> 0x1) | ((((((*(uint8_t *)(stack_buf_331 + index_34c) - index_34c) ^ index_34c) - index_34c) + 0x37) & 0xff) << 0x7))) & 0xff) ^ 0xc4) << 0x1)) ^ index_34c)) & 0xff) << 0x3)) + 0xffffff4c) & 0xff) >> 0x1) | (((((((0x0 - ((((((0x0 - (((((((*(uint8_t *)(stack_buf_331 + index_34c) - index_34c) ^ index_34c) - index_34c) + 0x37) & 0xff) >> 0x1) | ((((((*(uint8_t *)(stack_buf_331 + index_34c) - index_34c) ^ index_34c) - index_34c) + 0x37) & 0xff) << 0x7))) & 0xff) ^ 0xc4) >> 0x7) | ((((0x0 - (((((((*(uint8_t *)(stack_buf_331 + index_34c) - index_34c) ^ index_34c) - index_34c) + 0x37) & 0xff) >> 0x1) | ((((((*(uint8_t *)(stack_buf_331 + index_34c) - index_34c) ^ index_34c) - index_34c) + 0x37) & 0xff) << 0x7))) & 0xff) ^ 0xc4) << 0x1)) ^ index_34c)) & 0xff) >> 0x5) | (((0x0 - ((((((0x0 - (((((((*(uint8_t *)(stack_buf_331 + index_34c) - index_34c) ^ index_34c) - index_34c) + 0x37) & 0xff) >> 0x1) | ((((((*(uint8_t *)(stack_buf_331 + index_34c) - index_34c) ^ index_34c) - index_34c) + 0x37) & 0xff) << 0x7))) & 0xff) ^ 0xc4) >> 0x7) | ((((0x0 - (((((((*(uint8_t *)(stack_buf_331 + index_34c) - index_34c) ^ index_34c) - index_34c) + 0x37) & 0xff) >> 0x1) | ((((((*(uint8_t *)(stack_buf_331 + index_34c) - index_34c) ^ index_34c) - index_34c) + 0x37) & 0xff) << 0x7))) & 0xff) ^ 0xc4) << 0x1)) ^ index_34c)) & 0xff) << 0x3)) + 0xffffff4c) & 0xff) << 0x7));
                *(uint8_t *)(stack_buf_331 + index_34c) = ((((((((0x0 - ((((((0x0 - (((((((*(uint8_t *)(stack_buf_331 + index_34c) - index_34c) ^ index_34c) - index_34c) + 0x37) & 0xff) >> 0x1) | ((((((*(uint8_t *)(stack_buf_331 + index_34c) - index_34c) ^ index_34c) - index_34c) + 0x37) & 0xff) << 0x7))) & 0xff) ^ 0xc4) >> 0x7) | ((((0x0 - (((((((*(uint8_t *)(stack_buf_331 + index_34c) - index_34c) ^ index_34c) - index_34c) + 0x37) & 0xff) >> 0x1) | ((((((*(uint8_t *)(stack_buf_331 + index_34c) - index_34c) ^ index_34c) - index_34c) + 0x37) & 0xff) << 0x7))) & 0xff) ^ 0xc4) << 0x1)) ^ index_34c)) & 0xff) >> 0x5) | (((0x0 - ((((((0x0 - (((((((*(uint8_t *)(stack_buf_331 + index_34c) - index_34c) ^ index_34c) - index_34c) + 0x37) & 0xff) >> 0x1) | ((((((*(uint8_t *)(stack_buf_331 + index_34c) - index_34c) ^ index_34c) - index_34c) + 0x37) & 0xff) << 0x7))) & 0xff) ^ 0xc4) >> 0x7) | ((((0x0 - (((((((*(uint8_t *)(stack_buf_331 + index_34c) - index_34c) ^ index_34c) - index_34c) + 0x37) & 0xff) >> 0x1) | ((((((*(uint8_t *)(stack_buf_331 + index_34c) - index_34c) ^ index_34c) - index_34c) + 0x37) & 0xff) << 0x7))) & 0xff) ^ 0xc4) << 0x1)) ^ index_34c)) & 0xff) << 0x3)) + 0xffffff4c) & 0xff) >> 0x1) | (((((((0x0 - ((((((0x0 - (((((((*(uint8_t *)(stack_buf_331 + index_34c) - index_34c) ^ index_34c) - index_34c) + 0x37) & 0xff) >> 0x1) | ((((((*(uint8_t *)(stack_buf_331 + index_34c) - index_34c) ^ index_34c) - index_34c) + 0x37) & 0xff) << 0x7))) & 0xff) ^ 0xc4) >> 0x7) | ((((0x0 - (((((((*(uint8_t *)(stack_buf_331 + index_34c) - index_34c) ^ index_34c) - index_34c) + 0x37) & 0xff) >> 0x1) | ((((((*(uint8_t *)(stack_buf_331 + index_34c) - index_34c) ^ index_34c) - index_34c) + 0x37) & 0xff) << 0x7))) & 0xff) ^ 0xc4) << 0x1)) ^ index_34c)) & 0xff) >> 0x5) | (((0x0 - ((((((0x0 - (((((((*(uint8_t *)(stack_buf_331 + index_34c) - index_34c) ^ index_34c) - index_34c) + 0x37) & 0xff) >> 0x1) | ((((((*(uint8_t *)(stack_buf_331 + index_34c) - index_34c) ^ index_34c) - index_34c) + 0x37) & 0xff) << 0x7))) & 0xff) ^ 0xc4) >> 0x7) | ((((0x0 - (((((((*(uint8_t *)(stack_buf_331 + index_34c) - index_34c) ^ index_34c) - index_34c) + 0x37) & 0xff) >> 0x1) | ((((((*(uint8_t *)(stack_buf_331 + index_34c) - index_34c) ^ index_34c) - index_34c) + 0x37) & 0xff) << 0x7))) & 0xff) ^ 0xc4) << 0x1)) ^ index_34c)) & 0xff) << 0x3)) + 0xffffff4c) & 0xff) << 0x7));
                index_34c = (index_34c + 0x1);
                continue;
            }
            memcpy_checked(stack_buf_351, &g_0537, 0x15);
            index_368 = 0x0;
            while (((uint64_t)(index_368)) <= 0x13) {
                local_36c = ((((((((((0x0 - (*(uint8_t *)(stack_buf_351 + index_368) + index_368)) & 0xff) >> 0x1) | (((0x0 - (*(uint8_t *)(stack_buf_351 + index_368) + index_368)) & 0xff) << 0x7)) ^ index_368) ^ 0xffffffff) & 0xff) >> 0x6) | ((((((((0x0 - (*(uint8_t *)(stack_buf_351 + index_368) + index_368)) & 0xff) >> 0x1) | (((0x0 - (*(uint8_t *)(stack_buf_351 + index_368) + index_368)) & 0xff) << 0x7)) ^ index_368) ^ 0xffffffff) & 0xff) << 0x2)) + 0x3);
                *(uint8_t *)(stack_buf_351 + index_368) = ((((((((((0x0 - (*(uint8_t *)(stack_buf_351 + index_368) + index_368)) & 0xff) >> 0x1) | (((0x0 - (*(uint8_t *)(stack_buf_351 + index_368) + index_368)) & 0xff) << 0x7)) ^ index_368) ^ 0xffffffff) & 0xff) >> 0x6) | ((((((((0x0 - (*(uint8_t *)(stack_buf_351 + index_368) + index_368)) & 0xff) >> 0x1) | (((0x0 - (*(uint8_t *)(stack_buf_351 + index_368) + index_368)) & 0xff) << 0x7)) ^ index_368) ^ 0xffffffff) & 0xff) << 0x2)) + 0x3);
                index_368 = (index_368 + 0x1);
                continue;
            }
            if (vm_func_011743(stack_buf_331) == 0x0) {
                *(uint32_t *)(*(uint64_t *)(&g_0470)) = (*(uint32_t *)(*(uint64_t *)(&g_0470)) | 0x800000);
            } else {
                if (vm_func_011743(stack_buf_351) != 0x0) {
                    goto loc_014e4e;
                } else {
                    memcpy_checked((fp + 0x36d), &g_054c, size_590);
                    index_384 = 0x0;
                    while (((uint64_t)(index_384)) <= 0x15) {
                        local_388 = (0x80 - ((local_58c - ((local_58c - (((((((((*(uint8_t *)((fp + 0x36d) + index_384) ^ 0xfa) >> 0x1) | ((*(uint8_t *)((fp + 0x36d) + index_384) ^ 0xfa) << 0x7)) + 0xf1) ^ 0xffffffff) & 0xff) ^ 0xb8) >> 0x1) | ((((((((*(uint8_t *)((fp + 0x36d) + index_384) ^ 0xfa) >> 0x1) | ((*(uint8_t *)((fp + 0x36d) + index_384) ^ 0xfa) << 0x7)) + 0xf1) ^ 0xffffffff) & 0xff) ^ 0xb8) << 0x7))) ^ 0x26)) ^ 0x96));
                        *(uint8_t *)((fp + 0x36d) + index_384) = (0x80 - ((local_58c - ((local_58c - (((((((((*(uint8_t *)((fp + 0x36d) + index_384) ^ 0xfa) >> 0x1) | ((*(uint8_t *)((fp + 0x36d) + index_384) ^ 0xfa) << 0x7)) + 0xf1) ^ 0xffffffff) & 0xff) ^ 0xb8) >> 0x1) | ((((((((*(uint8_t *)((fp + 0x36d) + index_384) ^ 0xfa) >> 0x1) | ((*(uint8_t *)((fp + 0x36d) + index_384) ^ 0xfa) << 0x7)) + 0xf1) ^ 0xffffffff) & 0xff) ^ 0xb8) << 0x7))) ^ 0x26)) ^ 0x96));
                        index_384 = (index_384 + 0x1);
                        continue;
                    }
                    local_38c = 0xa;
                    while (((uint32_t)(local_38c)) <= 0x3e7) {
                        hostcall_dynamic((fp + 0x390), 0x0, local_570);
                        hostcall_dynamic((fp + 0x390), local_570, (fp + 0x36d), local_38c);
                        if (vm_func_011743((fp + 0x390)) == 0x0) {
                            *(uint32_t *)(*(uint64_t *)(&g_0470)) = (*(uint32_t *)(*(uint64_t *)(&g_0470)) | 0x80);
                            vm_func_012ddb(local_38c, stack_buf_2f0, stack_buf_30d, (fp + 0x198));
                        }
                        local_38c = (local_38c + 0x1);
                        continue;
                    }
                }
            }
        } else {
            if ((*(uint8_t *)(*(uint64_t *)(&g_0470)) & 0x80) != 0x0) {
                goto loc_0148fb;
            }
        }
    }
    hostcall_dynamic((((*(uint8_t *)(*(uint64_t *)(&g_0470)) & 0x1) == 0x0) ? 0x2 : local_588));
    if ((*(uint8_t *)(*(uint64_t *)(&g_0470)) & 0x40) != 0x0) {
        memcpy_checked((fp + 0x410), &g_0563, 0x23);
        index_434 = 0x0;
        while (((uint64_t)(index_434)) <= 0x21) {
            local_438 = ((((((((((((0x0 - (((((*(uint8_t *)((fp + 0x410) + index_434) + 0xffffffb3) & 0xff) >> 0x5) | (((*(uint8_t *)((fp + 0x410) + index_434) + 0xffffffb3) & 0xff) << 0x3)) ^ 0xffffff39)) & 0xff) >> 0x3) | (((0x0 - (((((*(uint8_t *)((fp + 0x410) + index_434) + 0xffffffb3) & 0xff) >> 0x5) | (((*(uint8_t *)((fp + 0x410) + index_434) + 0xffffffb3) & 0xff) << 0x3)) ^ 0xffffff39)) & 0xff) << 0x5)) + 0x1) & 0xff) >> 0x2) | (((((((0x0 - (((((*(uint8_t *)((fp + 0x410) + index_434) + 0xffffffb3) & 0xff) >> 0x5) | (((*(uint8_t *)((fp + 0x410) + index_434) + 0xffffffb3) & 0xff) << 0x3)) ^ 0xffffff39)) & 0xff) >> 0x3) | (((0x0 - (((((*(uint8_t *)((fp + 0x410) + index_434) + 0xffffffb3) & 0xff) >> 0x5) | (((*(uint8_t *)((fp + 0x410) + index_434) + 0xffffffb3) & 0xff) << 0x3)) ^ 0xffffff39)) & 0xff) << 0x5)) + 0x1) & 0xff) << 0x6)) + 0xffffff4d) & 0xff) >> 0x7) | (((((((((((0x0 - (((((*(uint8_t *)((fp + 0x410) + index_434) + 0xffffffb3) & 0xff) >> 0x5) | (((*(uint8_t *)((fp + 0x410) + index_434) + 0xffffffb3) & 0xff) << 0x3)) ^ 0xffffff39)) & 0xff) >> 0x3) | (((0x0 - (((((*(uint8_t *)((fp + 0x410) + index_434) + 0xffffffb3) & 0xff) >> 0x5) | (((*(uint8_t *)((fp + 0x410) + index_434) + 0xffffffb3) & 0xff) << 0x3)) ^ 0xffffff39)) & 0xff) << 0x5)) + 0x1) & 0xff) >> 0x2) | (((((((0x0 - (((((*(uint8_t *)((fp + 0x410) + index_434) + 0xffffffb3) & 0xff) >> 0x5) | (((*(uint8_t *)((fp + 0x410) + index_434) + 0xffffffb3) & 0xff) << 0x3)) ^ 0xffffff39)) & 0xff) >> 0x3) | (((0x0 - (((((*(uint8_t *)((fp + 0x410) + index_434) + 0xffffffb3) & 0xff) >> 0x5) | (((*(uint8_t *)((fp + 0x410) + index_434) + 0xffffffb3) & 0xff) << 0x3)) ^ 0xffffff39)) & 0xff) << 0x5)) + 0x1) & 0xff) << 0x6)) + 0xffffff4d) & 0xff) << 0x1));
            *(uint8_t *)((fp + 0x410) + index_434) = ((((((((((((0x0 - (((((*(uint8_t *)((fp + 0x410) + index_434) + 0xffffffb3) & 0xff) >> 0x5) | (((*(uint8_t *)((fp + 0x410) + index_434) + 0xffffffb3) & 0xff) << 0x3)) ^ 0xffffff39)) & 0xff) >> 0x3) | (((0x0 - (((((*(uint8_t *)((fp + 0x410) + index_434) + 0xffffffb3) & 0xff) >> 0x5) | (((*(uint8_t *)((fp + 0x410) + index_434) + 0xffffffb3) & 0xff) << 0x3)) ^ 0xffffff39)) & 0xff) << 0x5)) + 0x1) & 0xff) >> 0x2) | (((((((0x0 - (((((*(uint8_t *)((fp + 0x410) + index_434) + 0xffffffb3) & 0xff) >> 0x5) | (((*(uint8_t *)((fp + 0x410) + index_434) + 0xffffffb3) & 0xff) << 0x3)) ^ 0xffffff39)) & 0xff) >> 0x3) | (((0x0 - (((((*(uint8_t *)((fp + 0x410) + index_434) + 0xffffffb3) & 0xff) >> 0x5) | (((*(uint8_t *)((fp + 0x410) + index_434) + 0xffffffb3) & 0xff) << 0x3)) ^ 0xffffff39)) & 0xff) << 0x5)) + 0x1) & 0xff) << 0x6)) + 0xffffff4d) & 0xff) >> 0x7) | (((((((((((0x0 - (((((*(uint8_t *)((fp + 0x410) + index_434) + 0xffffffb3) & 0xff) >> 0x5) | (((*(uint8_t *)((fp + 0x410) + index_434) + 0xffffffb3) & 0xff) << 0x3)) ^ 0xffffff39)) & 0xff) >> 0x3) | (((0x0 - (((((*(uint8_t *)((fp + 0x410) + index_434) + 0xffffffb3) & 0xff) >> 0x5) | (((*(uint8_t *)((fp + 0x410) + index_434) + 0xffffffb3) & 0xff) << 0x3)) ^ 0xffffff39)) & 0xff) << 0x5)) + 0x1) & 0xff) >> 0x2) | (((((((0x0 - (((((*(uint8_t *)((fp + 0x410) + index_434) + 0xffffffb3) & 0xff) >> 0x5) | (((*(uint8_t *)((fp + 0x410) + index_434) + 0xffffffb3) & 0xff) << 0x3)) ^ 0xffffff39)) & 0xff) >> 0x3) | (((0x0 - (((((*(uint8_t *)((fp + 0x410) + index_434) + 0xffffffb3) & 0xff) >> 0x5) | (((*(uint8_t *)((fp + 0x410) + index_434) + 0xffffffb3) & 0xff) << 0x3)) ^ 0xffffff39)) & 0xff) << 0x5)) + 0x1) & 0xff) << 0x6)) + 0xffffff4d) & 0xff) << 0x1));
            index_434 = (index_434 + 0x1);
            continue;
        }
        hostcall_dynamic((fp + 0x439), 0x0, local_570);
        index_4c0 = 0x0;
        while (true) {
            if (((uint64_t)(index_4c0)) >= ((uint64_t)(vm_func_012bf1((fp + 0x198))))) break;
            memcpy_checked(&record20_4c8, vm_func_012ca1((fp + 0x198), index_4c0), 0x14);
            if (record20_4c8.word_00 & 0x1) {
                if ((record20_4c8.byte_00[1] & 0x80) != 0x0) {
                    if ((record20_4c8.word_00 & 0x802) == 0x0) {
                        hostcall_dynamic((fp + 0x439), local_570, (fp + 0x410), record20_4c8.field_04);
                        if (vm_func_01137f((fp + 0x439)) != 0x0) {
                            ptr_0151cd = vm_func_012cfb((fp + 0x198), index_4c0);
                            *(uint32_t *)(ptr_0151cd) = (*(uint32_t *)(ptr_0151cd) | 0x800);
                            ptr_0151f9 = vm_func_012cfb((fp + 0x198), index_4c0);
                            *(uint32_t *)(ptr_0151f9) = (*(uint32_t *)(ptr_0151f9) & 0xfffffffe);
                        } else {
                            local_4dc = vm_func_0134a7((fp + 0x198), record20_4c8.field_04);
                            if (local_4dc != *(uint32_t *)(vm_func_012cfb((fp + 0x198), index_4c0) + 0xc)) {
                                ptr_0152cf = vm_func_012cfb((fp + 0x198), index_4c0);
                                *(uint32_t *)(ptr_0152cf) = (*(uint32_t *)(ptr_0152cf) | 0x200);
                                if (local_4dc == 0x0) {
                                    ptr_015330 = vm_func_012cfb((fp + 0x198), index_4c0);
                                    *(uint32_t *)(ptr_015330) = (*(uint32_t *)(ptr_015330) | 0x800);
                                    ptr_01534f = vm_func_012cfb((fp + 0x198), index_4c0);
                                    *(uint32_t *)(ptr_01534f) = (*(uint32_t *)(ptr_01534f) & 0xfffffffe);
                                }
                            }
                            ptr_01538a = vm_func_012cfb((fp + 0x198), index_4c0);
                            *(uint32_t *)(ptr_01538a) = (*(uint32_t *)(ptr_01538a) | 0x8000);
                            *(uint32_t *)(vm_func_012cfb((fp + 0x198), index_4c0) + 0xc) = local_4dc;
                        }
                    }
                }
            }
            index_4c0 = (index_4c0 + 0x1);
            continue;
        }
        index_4e0 = 0x0;
        while (true) {
            if (((uint64_t)(index_4e0)) >= ((uint64_t)(vm_func_012bf1((fp + 0x198))))) break;
            memcpy_checked(stack_buf_4e8, vm_func_012ca1((fp + 0x198), index_4e0), 0x14);
            if (local_4e8 & 0x1) {
                if ((*(uint8_t *)(stack_buf_4e8 + 0x1) & 0x80) != 0x0) {
                    if ((local_4e8 & 0x802) == 0x0) {
                        ptr_015510 = vm_func_012cfb((fp + 0x198), index_4e0);
                        local_4fc = *(uint32_t *)(ptr_015510 + 0xc);
                        if (((uint32_t)(*(uint32_t *)(ptr_015510 + 0xc))) < 0x14) {
                            ptr_015568 = vm_func_012cfb((fp + 0x198), index_4e0);
                            *(uint32_t *)(ptr_015568) = (*(uint32_t *)(ptr_015568) | 0x100000);
                            *(uint32_t *)(*(uint64_t *)(&g_0470)) = (*(uint32_t *)(*(uint64_t *)(&g_0470)) | 0x20);
                        } else {
                            if (*(uint8_t *)(*(uint64_t *)(&g_0470)) & 0x1) {
                                if ((local_4e8 & 0x40) == 0x0) {
                                    if (((uint32_t)(local_4fc)) <= 0xc7) {
                                        ptr_015568 = vm_func_012cfb((fp + 0x198), index_4e0);
                                        *(uint32_t *)(ptr_015568) = (*(uint32_t *)(ptr_015568) | 0x100000);
                                        *(uint32_t *)(*(uint64_t *)(&g_0470)) = (*(uint32_t *)(*(uint64_t *)(&g_0470)) | 0x20);
                                        index_4e0 = (index_4e0 + 0x1);
                                        continue;
                                    }
                                }
                            }
                        }
                    }
                }
            }
            index_4e0 = (index_4e0 + 0x1);
            continue;
        }
    }
    *(uint32_t *)(*(uint64_t *)(&g_0470)) = (*(uint32_t *)(*(uint64_t *)(&g_0470)) | 0x100);
    loc_015681:
    if (status_e0 == 0x0) {
        syscall_sched_setaffinity(0x0, local_570, &cpu_set_060);
    }
    local_500 = 0x1;
    src_510 = vm_func_01336e((fp + 0x198));
    local_518 = vm_func_0133b0((fp + 0x198));
    local_570 = 0x3;
    local_560 = 0x398;
    local_568 = 0xcbbc;
    while (src_510 != local_518) {
        memcpy_checked(&record20_520, src_510, 0x14);
        if ((record20_520.byte_00[1] & 0x80) != 0x0) {
            local_534 = 0x1;
            if ((record20_520.byte_00[2] & 0x10) != 0x0) {
                local_534 = local_570;
            } else {
                if ((*(uint8_t *)(*(uint64_t *)(&g_0470)) & 0x20) == 0x0) {
                    if (local_500 & 0x1) {
                        local_534 = local_570;
                        local_500 = 0x0;
                        hostcall_dynamic();
                        vm_call_reg(local_568);
                        packet_append_typed_field((fp + 0x538), *(uint32_t *)(*(uint64_t *)(&g_0470)), 0x3, 0xb6);
                        packet_append_typed_field((fp + 0x538), *(uint32_t *)(*(uint64_t *)(&g_0470) + 0x8), 0x3, 0xb6);
                        packet_append_typed_field((fp + 0x538), *(uint32_t *)(*(uint64_t *)(&g_0470) + 0x4), 0x3, 0xb6);
                        packet_append_typed_field((fp + 0x538), record20_520.field_04, 0x3, 0xb6);
                        packet_append_typed_field((fp + 0x538), record20_520.field_08, 0x3, 0xb6);
                        packet_append_typed_field((fp + 0x538), record20_520.word_00, 0x3, 0xb6);
                        packet_append_typed_field((fp + 0x538), record20_520.field_0c, 0x3, 0xb6);
                        tmp_015a4e = packet_periodic_flush((fp + 0x538), 0x0);
                        local_550 = (tmp_015a4e & 0x1);
                        set_context_offset(0x1);
                        vm_call_reg(0xcb46);
                        src_510 = (src_510 + 0x14);
                        continue;
                    }
                }
            }
            local_500 = 0x0;
            hostcall_dynamic();
            vm_call_reg(local_568);
            packet_append_typed_field((fp + 0x538), *(uint32_t *)(*(uint64_t *)(&g_0470)), 0x3, 0xb6);
            packet_append_typed_field((fp + 0x538), *(uint32_t *)(*(uint64_t *)(&g_0470) + 0x8), 0x3, 0xb6);
            packet_append_typed_field((fp + 0x538), *(uint32_t *)(*(uint64_t *)(&g_0470) + 0x4), 0x3, 0xb6);
            packet_append_typed_field((fp + 0x538), record20_520.field_04, 0x3, 0xb6);
            packet_append_typed_field((fp + 0x538), record20_520.field_08, 0x3, 0xb6);
            packet_append_typed_field((fp + 0x538), record20_520.word_00, 0x3, 0xb6);
            packet_append_typed_field((fp + 0x538), record20_520.field_0c, 0x3, 0xb6);
            tmp_015a4e = packet_periodic_flush((fp + 0x538), 0x0);
            local_550 = (tmp_015a4e & 0x1);
            set_context_offset(0x1);
            vm_call_reg(0xcb46);
        }
        src_510 = (src_510 + 0x14);
        continue;
    }
    vm_func_015d5e((fp + 0x198));
    return result;
}
