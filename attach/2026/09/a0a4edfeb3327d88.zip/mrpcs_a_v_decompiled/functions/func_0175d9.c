void vm_func_0175d9(const void* arg0) {
    VmU64Pair u64_pair_0a0;
    VmU64Pair u64_pair_0b8;
    local_60 = *(uint64_t *)(arg0);
    local_68 = ((*(uint64_t *)(arg0 + 0x8) - *(uint64_t *)(arg0)) >> 0x3);
    index_70 = 0x0;
    while (((int64_t)((int64_t)(index_70))) < ((int64_t)(local_68))) {
        local_78 = *(uint64_t *)(local_60 + ((int64_t)(index_70) << 0x3));
        if (*(uint64_t *)(local_60 + ((int64_t)(index_70) << 0x3)) != 0x0) {
            local_80 = *(uint32_t *)(local_78);
            local_88 = *(uint64_t *)(local_78 + 0x8);
            index_90 = 0x0;
            while (((int32_t)(index_90)) <= 299) {
                if (*(uint32_t *)(((int64_t)(index_90) << 0x2) + &g_05e4) == local_80) {
                    if (*(uint64_t *)(((int64_t)(index_90) << 0x3) + &g_0a98) != local_88) {
                        if (local_80 != 0x3c3ec63f) {
                            g_13fc = local_80;
                        }
                    }
                    local_94 = 0x0;
                    index_98 = 0x0;
                    while (true) {
                        if (((uint64_t)(index_98)) >= ((uint64_t)(vm_func_016fa4(g_1598)))) break;
                        memcpy_checked(&u64_pair_0a0, vm_func_017d64(g_1598, index_98), 0x10);
                        if (((uint64_t)(*(uint64_t *)(((int64_t)(index_90) << 0x3) + &g_0a98))) < ((uint64_t)(u64_pair_0a0.first))) {
                            index_98 = (index_98 + 0x1);
                            continue;
                        } else {
                            if (((uint64_t)(*(uint64_t *)(((int64_t)(index_90) << 0x3) + &g_0a98))) > ((uint64_t)(u64_pair_0a0.second))) {
                                index_98 = (index_98 + 0x1);
                                continue;
                            } else {
                                local_94 = 0x1;
                                break;
                            }
                        }
                    }
                    loc_017a56:
                    if (local_94 == 0x0) {
                        if (g_1400 == 0x0) {
                            vm_func_016b06();
                            index_b0 = 0x0;
                            while (true) {
                                if (((uint64_t)(index_b0)) >= ((uint64_t)(vm_func_016fa4(g_1598)))) break;
                                memcpy_checked(&u64_pair_0b8, vm_func_017d64(g_1598, index_b0), 0x10);
                                if (((uint64_t)(*(uint64_t *)(((int64_t)(index_90) << 0x3) + &g_0a98))) < ((uint64_t)(u64_pair_0b8.first))) {
                                    index_b0 = (index_b0 + 0x1);
                                    continue;
                                } else {
                                    if (((uint64_t)(*(uint64_t *)(((int64_t)(index_90) << 0x3) + &g_0a98))) > ((uint64_t)(u64_pair_0b8.second))) {
                                        index_b0 = (index_b0 + 0x1);
                                        continue;
                                    } else {
                                        local_94 = 0x1;
                                        break;
                                    }
                                }
                            }
                            loc_017be0:
                            if (local_94 == 0x0) {
                                if (vm_func_016fa4(g_1598) != 0x0) {
                                    g_1400 = local_80;
                                }
                            }
                        }
                    }
                }
                if (*(uint32_t *)(((int64_t)(index_90) << 0x2) + &g_05e4) != 0x0) {
                    index_90 = (index_90 + 0x1);
                    continue;
                }
            }
        }
        index_70 = (index_70 + 0x1);
        continue;
    }
    return;
}
