void vm_func_00cbbc(void* arg0, uint64_t arg1, uint64_t arg2, uint64_t arg3, uint64_t arg4) {
    *(uint16_t *)(arg0 + 0x8) = 0x0;
    if (arg2 < 0xfb) {
        *(uint32_t *)(arg0 + 0x10) = (arg2 << 0x2);
    } else {
        *(uint32_t *)(arg0 + 0x10) = 0x3e8;
    }
    *(uint16_t *)(arg0 + 0xe) = arg1;
    *(uint32_t *)(arg0 + 0x14) = 0x0;
    *(uint16_t *)(arg0 + 0xc) = arg4;
    *(uint16_t *)(arg0 + 0xa) = arg3;
    heap_ptr_00ccfb = malloc((int64_t)(*(uint32_t *)(arg0 + 0x10)));
    *(uint64_t *)(arg0) = heap_ptr_00ccfb;
    memset(heap_ptr_00ccfb, 0x0, (int64_t)(*(uint32_t *)(arg0 + 0x10)));
    return;
}
