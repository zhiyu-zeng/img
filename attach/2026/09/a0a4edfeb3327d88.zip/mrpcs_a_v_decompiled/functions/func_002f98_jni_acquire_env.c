uint64_t jni_acquire_env(void* arg0) {
    if (*(uint8_t *)(arg0 + 0x10) & 0x1) {
        result = *(uint64_t *)(arg0 + 0x8);
    } else {
        *(uint8_t *)(arg0 + 0x10) = 0x1;
        java_vm_10 = get_java_vm();
        if (java_vm_10 != 0x0) {
            local_18 = 0x0;
            if (jvm_get_env(java_vm_10, (fp + 0x18)) == 0x0) {
                *(uint64_t *)(arg0) = java_vm_10;
                *(uint64_t *)(arg0 + 0x8) = local_18;
                result = *(uint64_t *)(arg0 + 0x8);
                return result;
            } else {
                if (((int32_t)(jvm_attach_current_thread(java_vm_10, (fp + 0x18)))) > -1) {
                    *(uint8_t *)(arg0 + 0x11) = 0x1;
                    *(uint64_t *)(arg0) = java_vm_10;
                    *(uint64_t *)(arg0 + 0x8) = local_18;
                    result = *(uint64_t *)(arg0 + 0x8);
                    return result;
                } else {
                    result = 0x0;
                }
            }
        } else {
            result = 0x0;
        }
    }
    return result;
}
