void rb_node_init(void* arg0, uint64_t arg1, uint64_t arg2) {
    *(uint64_t *)(arg0) = 0x0;
    *(uint64_t *)(arg0 + 0x8) = 0x0;
    *(uint64_t *)(arg0 + 0x10) = 0x0;
    vm_func_00953e((arg0 + 0x18), arg1);
    *(uint32_t *)(arg0 + 0x28) = arg2;
    return;
}
