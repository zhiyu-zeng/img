uint64_t vm_func_0269ce(uint64_t arg0) {
    local_0 = arg0;
    result = 0x0;
    while (*(uint8_t *)(local_0) != 0x0) {
        local_0 = (local_0 + 0x1);
        local_c = (((result << 0x4) + *(uint8_t *)(local_0)) & 0xf0000000);
        result = ((((result << 0x4) + *(uint8_t *)(local_0)) ^ (((result << 0x4) + *(uint8_t *)(local_0)) & 0xf0000000)) ^ *(uint8_t *)((fp + 0xc) | 0x3));
        continue;
    }
    return result;
}
