void vm_func_02c99f(void) {
    vm_func_02c9ef();
    vm_func_02cfe9();
    vm_func_02d179();
    return;
}
