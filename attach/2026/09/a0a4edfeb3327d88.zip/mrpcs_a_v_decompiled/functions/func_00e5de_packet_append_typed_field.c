void packet_append_typed_field(uint64_t arg0, uint64_t string, uint64_t arg2, uint64_t arg3) {
    if (((int32_t)(arg2)) < 3) {
        if (((int32_t)(arg2)) > 1) {
            local_12 = (packet_append_u16(arg0, string, 0x1) & 0x1);
        } else {
            if (arg2 != 0x1) {
                local_12 = 0x0;
            } else {
                local_12 = (packet_append_u8(arg0, string) & 0x1);
            }
        }
    } else {
        if (((int32_t)(arg2)) < 4) {
            local_12 = (packet_append_u32(arg0, string, 0x1) & 0x1);
        } else {
            if (((int32_t)(arg2)) < 5) {
                local_12 = (packet_append_u64(arg0, string, 0x1) & 0x1);
            } else {
                if (arg2 == 0x5) {
                    local_12 = (packet_append_xor_bytes(arg0, string, strlen(string), arg3) & 0x1);
                } else {
                    local_12 = 0x0;
                    return;
                }
            }
        }
    }
    return;
}
