uint64_t vm_func_0288cd(uint64_t arg0) {
    tmp_028915 = vm_func_028bdf(arg0);
    return (tmp_028915 - vm_func_028c25(arg0)) >> 0x4;
}
