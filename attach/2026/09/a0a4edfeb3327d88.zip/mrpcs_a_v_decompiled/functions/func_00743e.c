void vm_func_00743e(void* arg0) {
    *(uint64_t *)(arg0) = 0x0;
    return;
}
