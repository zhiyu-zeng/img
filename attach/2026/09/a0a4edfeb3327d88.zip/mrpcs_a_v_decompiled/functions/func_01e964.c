uint64_t vm_func_01e964(uint64_t path, uint64_t arg1) {
    *(uint32_t *)(__errno()) = 0x0;
    result = syscall_faccessat(0xffffff9c, path, arg1);
    if (result != 0x0) {
        result = (0x0 - *(uint32_t *)(__errno()));
    }
    return result;
}
