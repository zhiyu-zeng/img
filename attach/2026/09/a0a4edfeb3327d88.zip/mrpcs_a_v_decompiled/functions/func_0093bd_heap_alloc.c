uint64_t heap_alloc(uint64_t size) {
    return malloc(size);
}
