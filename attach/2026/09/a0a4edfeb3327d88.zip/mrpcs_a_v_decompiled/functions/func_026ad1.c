void vm_func_026ad1(uint64_t arg0) {
    if (arg0 != 0x0) {
        if (*(uint64_t *)(arg0) != 0x0) {
            free(*(uint64_t *)(arg0));
        }
    }
    return;
}
