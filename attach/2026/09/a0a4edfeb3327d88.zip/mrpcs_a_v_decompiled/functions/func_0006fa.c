uint64_t vm_func_0006fa(uint64_t arg0, uint64_t arg1, uint64_t arg2) {
    result = arg2;
    index_20 = 0x0;
    while (((uint32_t)(index_20)) < ((uint32_t)(arg1))) {
        result = (result ^ (((index_20 & 0x1) != 0x0) ? ((((result << 0xb) | *(uint8_t *)(arg0 + index_20)) ^ (result >> 0x5)) ^ 0xffffffff) : (((result << 0x7) ^ *(uint8_t *)(arg0 + index_20)) ^ (result >> 0x3))));
        index_20 = (index_20 + 0x1);
        continue;
    }
    return result;
}
