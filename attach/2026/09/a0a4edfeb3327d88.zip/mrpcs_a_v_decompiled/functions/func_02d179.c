void vm_func_02d179(void) {
    uint8_t* stack_buf_00c = (uint8_t*)(fp + 0xc); /* observed >= 0xc bytes */
    uint8_t* stack_buf_018 = (uint8_t*)(fp + 0x18); /* observed >= 0x10 bytes */
    memcpy_checked(stack_buf_00c, &g_37f8, 0xc);
    memcpy_checked(stack_buf_018, &g_3804, 0x10);
    index_28 = 0x0;
    while (((uint64_t)(index_28)) <= 0xa) {
        local_2c = ((((((((((((*(uint8_t *)(stack_buf_00c + index_28) ^ 0xffffffff) + 0xffffff1e) & 0xff) >> 0x2) | ((((*(uint8_t *)(stack_buf_00c + index_28) ^ 0xffffffff) + 0xffffff1e) & 0xff) << 0x6)) ^ 0xffffffff) & 0xff) >> 0x7) | ((((((((*(uint8_t *)(stack_buf_00c + index_28) ^ 0xffffffff) + 0xffffff1e) & 0xff) >> 0x2) | ((((*(uint8_t *)(stack_buf_00c + index_28) ^ 0xffffffff) + 0xffffff1e) & 0xff) << 0x6)) ^ 0xffffffff) & 0xff) << 0x1)) + 0x93) ^ 0xff) + 0x1b);
        *(uint8_t *)(stack_buf_00c + index_28) = ((((((((((((*(uint8_t *)(stack_buf_00c + index_28) ^ 0xffffffff) + 0xffffff1e) & 0xff) >> 0x2) | ((((*(uint8_t *)(stack_buf_00c + index_28) ^ 0xffffffff) + 0xffffff1e) & 0xff) << 0x6)) ^ 0xffffffff) & 0xff) >> 0x7) | ((((((((*(uint8_t *)(stack_buf_00c + index_28) ^ 0xffffffff) + 0xffffff1e) & 0xff) >> 0x2) | ((((*(uint8_t *)(stack_buf_00c + index_28) ^ 0xffffffff) + 0xffffff1e) & 0xff) << 0x6)) ^ 0xffffffff) & 0xff) << 0x1)) + 0x93) ^ 0xff) + 0x1b);
        index_28 = (index_28 + 0x1);
        continue;
    }
    index_30 = 0x0;
    while (((uint64_t)(index_30)) <= 0xe) {
        local_34 = ((((((((((*(uint8_t *)(stack_buf_018 + index_30) ^ 0xffffffff) + 0xffffff77) & 0xff) >> 0x3) | ((((*(uint8_t *)(stack_buf_018 + index_30) ^ 0xffffffff) + 0xffffff77) & 0xff) << 0x5)) ^ 0xff) + 0x71) ^ 0xff) + 0x24) ^ 0xff);
        *(uint8_t *)(stack_buf_018 + index_30) = ((((((((((*(uint8_t *)(stack_buf_018 + index_30) ^ 0xffffffff) + 0xffffff77) & 0xff) >> 0x3) | ((((*(uint8_t *)(stack_buf_018 + index_30) ^ 0xffffffff) + 0xffffff77) & 0xff) << 0x5)) ^ 0xff) + 0x71) ^ 0xff) + 0x24) ^ 0xff);
        index_30 = (index_30 + 0x1);
        continue;
    }
    g_37f0 = scan_file_for_pattern_streaming(stack_buf_018, stack_buf_00c, 0xb, &g_37f4, (fp + 0x8));
    g_3814 = 0x0;
    return;
}
