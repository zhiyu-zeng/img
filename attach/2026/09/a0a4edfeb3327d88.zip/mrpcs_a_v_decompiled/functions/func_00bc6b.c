uint64_t vm_func_00bc6b(uint64_t arg0, uint64_t arg1, uint64_t arg2, uint64_t arg3, uint64_t arg4, uint64_t arg5, uint64_t arg6) {
    result = vm_func_00339f(arg0, arg1, arg2, arg3, arg4, arg5, arg6);
    return result;
}
