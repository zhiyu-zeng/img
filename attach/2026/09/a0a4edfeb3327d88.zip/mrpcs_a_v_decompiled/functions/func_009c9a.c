uint64_t vm_func_009c9a(uint64_t arg0, uint64_t arg1, uint64_t arg2, uint64_t arg3, uint64_t arg4, uint64_t arg5, uint64_t arg6, uint64_t arg7) {
    memcpy_checked((fp + 0x8), &g_01c8, 0x8);
    local_50 = vm_func_006447(arg3);
    if (((int32_t)(local_50)) < 76) {
        if (((int32_t)(local_50)) < 73) {
            if (((int32_t)(local_50)) < 67) {
                if (local_50 == 0x42) {
                    result = vm_func_004a66(arg0, arg1, arg4, arg5, arg6, arg7, 0x0);
                }
            } else {
                if (local_50 == 0x43) {
                    result = vm_func_004b89(arg0, arg1, arg4, arg5, arg6, arg7, 0x0);
                }
            }
        } else {
            if (((int32_t)(local_50)) < 74) {
                result = vm_func_004dcf(arg0, arg1, arg4, arg5, arg6, arg7, 0x0);
            } else {
                if (local_50 == 0x4a) {
                    result = vm_func_004ef2(arg0, arg1, arg4, arg5, arg6, arg7, 0x0);
                }
            }
        }
    } else {
        if (((int32_t)(local_50)) < 86) {
            if (((int32_t)(local_50)) < 83) {
                if (local_50 == 0x4c) {
                    tmp_00a2d9 = vm_func_00a32b(arg0, arg1, arg4, arg5, arg6, arg7, 0x0);
                    result = tmp_00a2d9;
                }
            } else {
                if (local_50 == 0x53) {
                    result = vm_func_004cac(arg0, arg1, arg4, arg5, arg6, arg7, 0x0);
                }
            }
        } else {
            if (((int32_t)(local_50)) < 90) {
                if (local_50 == 0x56) {
                    vm_func_004705(arg0, arg1, arg4, arg5, arg6, arg7, 0x0);
                }
            } else {
                if (((int32_t)(local_50)) < 91) {
                    result = vm_func_004943(arg0, arg1, arg4, arg5, arg6, arg7, 0x0);
                } else {
                    if (local_50 == 0x5b) {
                        tmp_00a2d9 = vm_func_00a32b(arg0, arg1, arg4, arg5, arg6, arg7, 0x0);
                        result = tmp_00a2d9;
                        return result;
                    }
                }
            }
        }
    }
    return result;
}
