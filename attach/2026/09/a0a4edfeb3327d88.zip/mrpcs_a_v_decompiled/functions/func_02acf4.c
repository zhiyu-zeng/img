void vm_func_02acf4(void) {
    if (((int32_t)(map_probe_record_count)) <= 3) {
        collect_proc_maps_probe_records();
    }
    if (((int32_t)(map_probe_record_count)) <= 3) {
        call_native_n(g_2ff0, get_vm_callback_thunk(0x6c74), 0x0);
    }
    return;
}
