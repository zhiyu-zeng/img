void vm_func_0283ea(void) {
    if (((int32_t)(symbol_probe_record_count)) <= 2) {
        call_native_n(g_2ea0, get_vm_callback_thunk(0x6c72), 0x0);
    }
    return;
}
