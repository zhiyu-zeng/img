uint64_t vm_func_0114c0(uint64_t path, uint64_t arg1) {
    *(uint32_t *)(__errno()) = 0x0;
    result = syscall_faccessat(0xffffff9c, path, arg1);
    if (result != 0x0) {
        result = (0x0 - *(uint32_t *)(__errno()));
    }
    g_03ec = (g_03ec + 0x1);
    if ((((g_03ec + 0x1)) % (uint64_t)(g_03f0)) == 0x0) {
        set_context_offset(0x1);
    }
    return result;
}
