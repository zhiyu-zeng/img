void vm_func_009628(void* arg0, uint64_t arg1, uint64_t arg2, uint64_t arg3, uint64_t arg4) {
    local_3c = (arg4 & 0x1);
    *(uint64_t *)(arg0) = arg1;
    vm_func_00973e((arg0 + 0x8));
    vm_func_009786(arg0, arg2, arg3, local_3c);
    return;
}
