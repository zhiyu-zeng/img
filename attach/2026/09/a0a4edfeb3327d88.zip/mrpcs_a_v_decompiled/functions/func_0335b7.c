void vm_func_0335b7(void) {
    module_base_8 = get_cached_module_base(0x0);
    if (((uint64_t)(module_base_8)) >= 0x100000001) {
        register_vm_callback(0x328f1, 0x6c9a, 0x3, 0x0, 0x100, (module_base_8 + 0x11b23b40), 0x0, 0x2000);
    }
    return;
}
