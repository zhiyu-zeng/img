void vm_func_026c1e(void* arg0) {
    *(uint64_t *)(arg0 + 0x10) = *(uint64_t *)(*(uint64_t *)(arg0));
    *(uint64_t *)(*(uint64_t *)(arg0)) = *(uint64_t *)(arg0 + 0x8);
    return;
}
