void vm_func_023400(const void* arg0) {
    if ((*(uint64_t *)(arg0)) != ((arg0 + 0x18))) {
        free(*(uint64_t *)(arg0));
    }
    return;
}
