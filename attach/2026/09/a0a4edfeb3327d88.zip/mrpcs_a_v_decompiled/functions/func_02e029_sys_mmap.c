uint64_t sys_mmap(uint64_t arg0, uint64_t arg1, uint64_t arg2, uint64_t arg3, uint64_t arg4, uint64_t arg5) {
    if (g_3838 == 0x0) {
        g_3838 = build_aarch64_syscall_stub(0xde);
    }
    if (g_3838 != 0x0) {
        result = call_native_n(g_3838, arg0, arg1, (int64_t)(arg2), (int64_t)(arg3), (int64_t)(arg4), arg5);
    } else {
        result = 0xffffffffffffffff;
    }
    return result;
}
