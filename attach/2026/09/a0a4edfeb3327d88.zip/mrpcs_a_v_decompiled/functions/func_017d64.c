uint64_t vm_func_017d64(const void* arg0, uint64_t arg1) {
    return (*(uint64_t *)(arg0) + (arg1 << 0x4));
}
