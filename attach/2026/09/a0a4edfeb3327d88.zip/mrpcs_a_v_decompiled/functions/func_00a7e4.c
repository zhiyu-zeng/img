uint64_t vm_func_00a7e4(uint64_t arg0, uint64_t arg1, uint64_t arg2) {
    result = vm_func_003a6a(arg0, arg1, arg2);
    return result;
}
