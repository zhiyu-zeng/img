uint64_t submit_packet_format_a(void* arg0) {
    VmPacketSubmitDesc packet_submit_440;
    uint8_t* stack_buf_038 = (uint8_t*)(fp + 0x38); /* observed >= 0x400 bytes */
    if (((int32_t)(*(uint32_t *)(arg0 + 0x14))) > 3) {
        if (((int32_t)(*(uint32_t *)(arg0 + 0x14))) >= 1001) {
            *(uint32_t *)(arg0 + 0x14) = 0x3e8;
        }
        local_438 = 0x0;
        memset(stack_buf_038, 0x0, 0x400);
        local_43a = (*(uint16_t *)(arg0 + 0x14) + 0xa);
        *(uint16_t *)(stack_buf_038 + local_438) = bswap16(arg0, (*(uint16_t *)(arg0 + 0x14) + 0xa));
        local_438 = (local_438 + 0x2);
        *(uint32_t *)(stack_buf_038 + local_438) = bswap32(arg0, ((*(uint16_t *)(arg0 + 0xe) << 0x10) | *(uint16_t *)(arg0 + 0xa)));
        local_438 = (local_438 + 0x4);
        *(uint32_t *)(stack_buf_038 + local_438) = bswap32(arg0, 0x23456);
        local_438 = (local_438 + 0x4);
        *(uint16_t *)(stack_buf_038 + local_438) = bswap16(arg0, *(uint16_t *)(arg0 + 0x8));
        local_438 = (local_438 + 0x2);
        index_43c = 0x0;
        while (((int32_t)(index_43c)) < ((int32_t)(*(uint32_t *)(arg0 + 0x14)))) {
            *(uint8_t *)(stack_buf_038 + (int64_t)((local_438 + index_43c))) = *(uint8_t *)(*(uint64_t *)(arg0) + (int64_t)(index_43c));
            index_43c = (index_43c + 0x1);
            continue;
        }
        local_438 = (local_438 + *(uint32_t *)(arg0 + 0x14));
        packet_submit_440.tag_or_header = 0xa00000102;
        packet_submit_440.data = stack_buf_038;
        packet_submit_440.length = ((local_438 + *(uint32_t *)(arg0 + 0x14)) & 0xffff);
        if (submit_packet(&packet_submit_440, 0x0) == 0x0) {
            result = 0x1;
        } else {
            result = 0x0;
        }
    } else {
        result = 0x0;
    }
    return result;
}
