uint64_t vm_func_00fb4b(const void* arg0) {
    return *(uint64_t *)(arg0);
}
