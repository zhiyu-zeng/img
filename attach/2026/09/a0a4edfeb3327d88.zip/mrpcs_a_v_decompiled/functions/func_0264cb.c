uint64_t vm_func_0264cb(uint64_t arg0, uint64_t arg1) {
    index_18 = 0x0;
    while (((uint64_t)(index_18)) < ((uint64_t)(*(uint64_t *)(arg0 + 0x18)))) {
        local_20 = (*(uint64_t *)(arg0 + 0x10) + (index_18 * 0x38));
        if (*(uint32_t *)(*(uint64_t *)(arg0 + 0x10) + (index_18 * 0x38)) != 0x6474e552) {
            index_18 = (index_18 + 0x1);
            continue;
        } else {
            if (arg1 < ((uint64_t)((*(uint64_t *)(arg0 + 0x8) + *(uint64_t *)(local_20 + 0x10))))) {
                index_18 = (index_18 + 0x1);
                continue;
            } else {
                if (arg1 >= ((uint64_t)(((*(uint64_t *)(arg0 + 0x8) + *(uint64_t *)(local_20 + 0x10)) + *(uint64_t *)(local_20 + 0x28))))) {
                    index_18 = (index_18 + 0x1);
                    continue;
                } else {
                    result = 0x1;
                    goto loc_0268cb;
                }
            }
        }
    }
    index_28 = 0x0;
    while (((uint64_t)(index_28)) < ((uint64_t)(*(uint64_t *)(arg0 + 0x18)))) {
        local_30 = (*(uint64_t *)(arg0 + 0x10) + (index_28 * 0x38));
        if (*(uint32_t *)(*(uint64_t *)(arg0 + 0x10) + (index_28 * 0x38)) != 0x1) {
            index_28 = (index_28 + 0x1);
            continue;
        } else {
            if (arg1 < ((uint64_t)((*(uint64_t *)(arg0 + 0x8) + *(uint64_t *)(local_30 + 0x10))))) {
                index_28 = (index_28 + 0x1);
                continue;
            } else {
                if (arg1 >= ((uint64_t)(((*(uint64_t *)(arg0 + 0x8) + *(uint64_t *)(local_30 + 0x10)) + *(uint64_t *)(local_30 + 0x28))))) {
                    index_28 = (index_28 + 0x1);
                    continue;
                } else {
                    result = ((vm_mov_once_d(0x4, 0x0) | ((*(uint32_t *)(local_30 + 0x4) & 0x4) >> 0x2)) | vm_mov_once_d(0x2, 0x0));
                    goto loc_0268cb;
                }
            }
        }
    }
    result = 0x1;
    loc_0268cb:
    return result;
}
