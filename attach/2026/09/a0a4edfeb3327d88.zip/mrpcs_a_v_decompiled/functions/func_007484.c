void vm_func_007484(uint64_t arg0, uint64_t arg1) {
    vm_func_0080e0(arg0, arg1);
    return;
}
