uint64_t tree_is_left_child(uint64_t arg0, const void* arg1) {
    local_18 = *(uint64_t *)(arg1);
    if (*(uint64_t *)(arg1) == 0x0) {
        result = 0x0;
    } else {
        if (*(uint64_t *)(local_18 + 0x8) != arg1) {
            result = 0x0;
            return result;
        } else {
            result = 0x1;
        }
    }
    return result;
}
