void vm_func_026ef7(uint64_t arg0, uint64_t arg1, uint64_t arg2, uint64_t arg3, uint64_t arg4, uint64_t arg5, uint64_t arg6, uint64_t arg7) {
    uint8_t* stack_buf_050 = (uint8_t*)(fp + 0x50); /* observed >= 0x1b8 bytes */
    memset(stack_buf_050, 0x0, 0x1b8);
    *(uint64_t *)(stack_buf_050 + 0x8) = arg1;
    *(uint64_t *)(stack_buf_050 + 0x10) = 0x90;
    *(uint64_t *)(stack_buf_050 + 0x18) = arg2;
    *(uint64_t *)(stack_buf_050 + 0x20) = arg3;
    *(uint64_t *)(stack_buf_050 + 0x28) = arg4;
    *(uint64_t *)(stack_buf_050 + 0x30) = arg5;
    *(uint64_t *)(stack_buf_050 + 0x38) = arg6;
    *(uint64_t *)(stack_buf_050 + 0x40) = arg7;
    *(uint64_t *)(stack_buf_050 + 0x1a0) = 0x0;
    *(uint64_t *)(stack_buf_050 + 0x178) = 0x0;
    module_base_02707c = get_cached_module_base(0x1);
    local_208 = (module_base_02707c + 0x2bb77c);
    call_native_n((module_base_02707c + 0x2bb77c), stack_buf_050);
    return;
}
