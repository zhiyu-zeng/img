void vm_func_0332b7(void* arg0) {
    VmU64Pair u64_pair_010;
    uint8_t* stack_buf_020 = (uint8_t*)(fp + 0x20); /* observed >= 0x90 bytes */
    memset(stack_buf_020, 0x0, 0x90);
    memset(&u64_pair_010, 0x0, 0x10);
    vm_func_026ef7(g_3f88, stack_buf_020, "8", &u64_pair_010, 0x0, 0x0, 0x0, 0x0);
    *(uint64_t *)(arg0 + 0x8) = u64_pair_010.second;
    *(uint64_t *)(arg0) = u64_pair_010.first;
    return;
}
