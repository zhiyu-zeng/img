void vm_func_00b826(uint64_t arg0, uint64_t arg1, uint64_t arg2, uint64_t arg3, uint64_t arg4, uint64_t arg5, uint64_t arg6, uint64_t arg7) {
    local_68 = vm_func_009c32(arg0, arg1);
    if (local_68 == 0x0) {
        vm_func_006a7e(arg0);
        local_20 = 0x0;
    } else {
        if (vm_func_006a36(arg0) == 0x0) {
            vm_call_reg(0x9628);
            vm_func_006ac6((fp + 0x70), local_68);
            local_88 = vm_func_003809(arg0, local_68, arg2, arg3);
            if (local_88 == 0x0) {
                vm_func_006a7e(arg0);
                local_20 = 0x0;
                local_90 = 0x1;
            } else {
                if (vm_func_006a36(arg0) == 0x0) {
                    local_98 = vm_func_00bc6b(arg0, local_68, local_88, arg4, arg5, arg6, arg7);
                    if (local_98 == 0x0) {
                        vm_func_006a7e(arg0);
                        local_20 = 0x0;
                        local_90 = 0x1;
                    } else {
                        if (vm_func_006a36(arg0) == 0x0) {
                            local_20 = local_98;
                            local_90 = 0x1;
                        } else {
                            vm_func_006a7e(arg0);
                            local_20 = 0x0;
                            local_90 = 0x1;
                            vm_call_reg(0x7279);
                            return;
                        }
                    }
                } else {
                    vm_func_006a7e(arg0);
                    local_20 = 0x0;
                    local_90 = 0x1;
                    vm_call_reg(0x7279);
                    return;
                }
            }
            vm_call_reg(0x7279);
        } else {
            vm_func_006a7e(arg0);
            local_20 = 0x0;
            return;
        }
    }
    return;
}
