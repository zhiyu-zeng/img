void vm_func_01f352(void) {
    g_1b28 = &g_1b20;
    g_1e58 = "/libUE4.so";
    g_1e60 = "/libHttpDnsPlugin.so";
    g_1e68 = "/libc++_shared.so";
    g_21a0 = malloc(0x1000);
    g_21c8 = resolve_symbol("libdl.so", "dl_iterate_phdr");
    g_21e0 = resolve_symbol("libc.so", "strstr");
    g_21f0 = resolve_symbol("libc.so", "sscanf");
    g_2200 = resolve_symbol("libc.so", "strdup");
    register_vm_callback(0x1f511, 0x6c6b, 0xb);
    register_vm_callback(0x1fab3, 0x6c6c, 0x1, 0x78);
    return;
}
