uint64_t vm_func_029e9d(uint64_t arg0, const void* arg1) {
    local_8 = arg0;
    local_18 = 0x0;
    if (*(uint8_t *)(arg1) != 0x0) {
        while (true) {
            local_20 = call_native_n(g_2eb8, local_8, arg1);
            if (local_20 == 0x0) break;
            local_18 = local_20;
            local_8 = (local_20 + 0x1);
            continue;
        }
        result = local_18;
    } else {
        result = call_native_n(g_2ee8, local_8, 0x0);
    }
    return result;
}
