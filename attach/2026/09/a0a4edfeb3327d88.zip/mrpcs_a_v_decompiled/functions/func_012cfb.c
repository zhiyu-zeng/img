uint64_t vm_func_012cfb(uint64_t arg0, uint64_t arg1) {
    return vm_func_012ca1(arg0, arg1);
}
