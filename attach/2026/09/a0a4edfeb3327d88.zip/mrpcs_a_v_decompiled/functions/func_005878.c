void vm_func_005878(const void* arg0, uint64_t arg1, uint64_t arg2, uint64_t arg3, uint64_t arg4, uint64_t arg5, uint64_t arg6, uint64_t arg7) {
    struct { uint64_t field_00; uint64_t field_08; uint64_t field_10; uint64_t field_18; uint64_t field_20; uint64_t field_28; uint64_t field_30; uint64_t field_38; } local_obj_048;
    local_obj_048.field_00 = arg1;
    local_obj_048.field_08 = arg2;
    local_obj_048.field_10 = arg3;
    local_obj_048.field_18 = arg4;
    local_obj_048.field_20 = arg5;
    local_obj_048.field_28 = arg6;
    local_obj_048.field_30 = arg7;
    local_obj_048.field_38 = 0x0;
    dispatch_registered_handler(0x1f, *(uint64_t *)(arg0), &local_obj_048, 0x7);
    return;
}
