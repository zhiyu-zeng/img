void heap_free(uint64_t arg0, uint64_t arg1) {
    free(arg0);
    return;
}
