void vm_func_005206(const void* arg0, uint64_t arg1, uint64_t arg2, uint64_t arg3, uint64_t arg4) {
    struct { uint64_t field_00; uint64_t field_08; uint64_t field_10; uint64_t field_18; uint64_t field_20; } local_obj_020;
    local_obj_020.field_00 = arg1;
    local_obj_020.field_08 = (int64_t)(arg2);
    local_obj_020.field_10 = (int64_t)(arg3);
    local_obj_020.field_18 = arg4;
    local_obj_020.field_20 = 0x0;
    dispatch_registered_handler(0xcd, *(uint64_t *)(arg0), &local_obj_020, 0x4);
    return;
}
