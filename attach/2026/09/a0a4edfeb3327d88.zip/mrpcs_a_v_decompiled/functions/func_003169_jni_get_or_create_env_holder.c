uint64_t jni_get_or_create_env_holder(void* arg0) {
    if (*(uint64_t *)(arg0 + 0x18) != 0x0) {
        result = *(uint64_t *)(arg0 + 0x18);
    } else {
        local_20 = jni_acquire_env(arg0);
        if (local_20 != 0x0) {
            heap_ptr_00321c = ((fn_operator_new)(0x8));
            vm_call_reg(0x32b2);
            *(uint64_t *)(arg0 + 0x18) = heap_ptr_00321c;
            result = *(uint64_t *)(arg0 + 0x18);
            return result;
        } else {
            result = 0x0;
        }
    }
    return result;
}
