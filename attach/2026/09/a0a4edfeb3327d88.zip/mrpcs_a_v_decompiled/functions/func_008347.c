void vm_func_008347(void* arg0, const void* arg1, uint64_t arg2) {
    *(uint64_t *)(arg0) = *(uint64_t *)(arg1);
    *(uint8_t *)(arg0 + 0x8) = (*(uint8_t *)(arg2) & 0x1);
    return;
}
