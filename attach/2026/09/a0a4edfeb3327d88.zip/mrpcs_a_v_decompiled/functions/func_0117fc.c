uint64_t vm_func_0117fc(uint64_t arg0) {
    local_18 = vm_func_01137f(arg0);
    if (local_18 != 0x0) {
        result = 0xffffffff;
    } else {
        local_1c = vm_func_0114c0(arg0, 0x0);
        if (local_1c != 0xfffffffe) {
            result = 0xffffffff;
            return result;
        } else {
            result = 0x0;
        }
    }
    return result;
}
