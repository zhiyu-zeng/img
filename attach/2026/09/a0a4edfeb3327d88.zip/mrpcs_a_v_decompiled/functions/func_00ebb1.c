void vm_func_00ebb1(void* arg0, uint64_t arg1) {
    if (((int32_t)(arg1)) < 0) {
        local_0 = 0x0;
    } else {
        if (((int32_t)(arg1)) > 3) {
            local_0 = 0x0;
            return;
        } else {
            *(uint16_t *)(arg0 + 0xc) = arg1;
            local_0 = ((arg1) != (0x0));
        }
    }
    return;
}
