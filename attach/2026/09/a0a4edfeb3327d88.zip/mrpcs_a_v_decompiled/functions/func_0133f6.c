uint64_t vm_func_0133f6(uint64_t pid, uint64_t tid) {
    if (sys_tgkill_checked(pid, tid, 0x1c) == 0xfffffffd) {
        result = 0x0;
    } else {
        result = 0x1;
    }
    return result;
}
