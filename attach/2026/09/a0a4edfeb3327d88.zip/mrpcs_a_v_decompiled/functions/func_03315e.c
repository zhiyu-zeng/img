uint64_t vm_func_03315e(void) {
    return call_native_n(g_3fa8);
}
