void rb_rotate_left(void* arg0, const void* arg1, uint64_t arg2) {
    local_18 = *(uint64_t *)(arg1);
    local_20 = *(uint64_t *)(arg1 + 0x10);
    if (*(uint64_t *)(arg1) != 0x0) {
        if (!(rb_is_left_child(arg0, arg1) & 0x1)) {
            *(uint64_t *)(local_18 + 0x10) = local_20;
        } else {
            *(uint64_t *)(local_18 + 0x8) = local_20;
        }
        *(uint64_t *)(local_20) = local_18;
    } else {
        *(uint64_t *)(arg0) = local_20;
        *(uint64_t *)(local_20) = 0x0;
    }
    *(uint64_t *)(arg1 + 0x10) = *(uint64_t *)(local_20 + 0x8);
    if (*(uint64_t *)(arg1 + 0x10) != 0x0) {
        *(uint64_t *)(*(uint64_t *)(arg1 + 0x10)) = arg1;
    }
    *(uint64_t *)(local_20 + 0x8) = arg1;
    *(uint64_t *)(arg1) = local_20;
    return;
}
