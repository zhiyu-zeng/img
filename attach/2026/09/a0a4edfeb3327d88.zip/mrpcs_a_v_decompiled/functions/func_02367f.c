uint64_t vm_func_02367f(uint64_t arg0, uint64_t arg1) {
    address_30 = vm_func_02358a(arg0);
    local_38 = vm_func_0235fe((arg0 + 0x8));
    local_40 = (local_38 - address_30);
    if (mprotect(address_30, (local_38 - address_30), arg1) == 0x0) {
        result = 0x0;
    } else {
        result = 0xffffffff;
    }
    return result;
}
