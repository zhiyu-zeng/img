uint64_t vm_func_0069ce(uint64_t arg0, uint64_t arg1) {
    result = vm_func_003776(arg0, arg1);
    return result;
}
