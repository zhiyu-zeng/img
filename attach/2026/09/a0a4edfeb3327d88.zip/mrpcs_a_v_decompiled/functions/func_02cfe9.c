void vm_func_02cfe9(void) {
    memcpy_checked(fp, &g_3840, 0x33);
    index_34 = 0x0;
    while (((uint64_t)(index_34)) <= 0x31) {
        local_38 = ((((((((((((*(uint8_t *)(fp + index_34) + 0xf4) & 0xff) >> 0x3) | (((*(uint8_t *)(fp + index_34) + 0xf4) & 0xff) << 0x5)) ^ 0xffffffff) + 0xffffffe0) ^ 0xffffffff) + 0xe1) & 0xff) >> 0x7) | ((((((((((*(uint8_t *)(fp + index_34) + 0xf4) & 0xff) >> 0x3) | (((*(uint8_t *)(fp + index_34) + 0xf4) & 0xff) << 0x5)) ^ 0xffffffff) + 0xffffffe0) ^ 0xffffffff) + 0xe1) & 0xff) << 0x1)) + 0x98);
        *(uint8_t *)(fp + index_34) = ((((((((((((*(uint8_t *)(fp + index_34) + 0xf4) & 0xff) >> 0x3) | (((*(uint8_t *)(fp + index_34) + 0xf4) & 0xff) << 0x5)) ^ 0xffffffff) + 0xffffffe0) ^ 0xffffffff) + 0xe1) & 0xff) >> 0x7) | ((((((((((*(uint8_t *)(fp + index_34) + 0xf4) & 0xff) >> 0x3) | (((*(uint8_t *)(fp + index_34) + 0xf4) & 0xff) << 0x5)) ^ 0xffffffff) + 0xffffffe0) ^ 0xffffffff) + 0xe1) & 0xff) << 0x1)) + 0x98);
        index_34 = (index_34 + 0x1);
        continue;
    }
    g_37e8 = vm_func_02ec4c(fp, &g_37ec);
    return;
}
