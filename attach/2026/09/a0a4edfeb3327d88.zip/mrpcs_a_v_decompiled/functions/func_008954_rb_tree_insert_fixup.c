void rb_tree_insert_fixup(uint64_t arg0, void* arg1, uint64_t arg2) {
    local_38 = arg1;
    *(uint32_t *)(arg1 + 0x28) = 0x0;
    while (true) {
        loc_008a5b:
        if (!((local_38 != *(uint64_t *)(arg2)) ? 0x0 : ((((*(uint32_t *)(*(uint64_t *)(local_38) + 0x28)) == (0x0))) ? 1 : 0) & 0x1)) {
            if (*(uint64_t *)(local_38) != *(uint64_t *)(*(uint64_t *)(*(uint64_t *)(local_38)) + 0x8)) {
                local_48 = *(uint64_t *)(*(uint64_t *)(*(uint64_t *)(local_38)) + 0x8);
                if (*(uint64_t *)(*(uint64_t *)(*(uint64_t *)(local_38)) + 0x8) == 0x0) {
                    if (local_38 == *(uint64_t *)(*(uint64_t *)(local_38) + 0x8)) {
                        local_38 = *(uint64_t *)(local_38);
                        rb_rotate_right(arg0, *(uint64_t *)(local_38), arg2);
                    }
                    *(uint32_t *)(*(uint64_t *)(local_38) + 0x28) = 0x1;
                    *(uint32_t *)(*(uint64_t *)(*(uint64_t *)(local_38)) + 0x28) = 0x0;
                    rb_rotate_left(arg0, *(uint64_t *)(*(uint64_t *)(local_38)), arg2);
                    continue;
                } else {
                    if (*(uint32_t *)(local_48 + 0x28) != 0x0) {
                        goto loc_008b38;
                    } else {
                        *(uint32_t *)(*(uint64_t *)(local_38) + 0x28) = 0x1;
                        *(uint32_t *)(local_48 + 0x28) = 0x1;
                        *(uint32_t *)(*(uint64_t *)(*(uint64_t *)(local_38)) + 0x28) = 0x0;
                        local_38 = *(uint64_t *)(*(uint64_t *)(local_38));
                        continue;
                    }
                }
            } else {
                local_40 = *(uint64_t *)(*(uint64_t *)(*(uint64_t *)(local_38)) + 0x10);
                if (*(uint64_t *)(*(uint64_t *)(*(uint64_t *)(local_38)) + 0x10) == 0x0) {
                    if (local_38 == *(uint64_t *)(*(uint64_t *)(local_38) + 0x10)) {
                        local_38 = *(uint64_t *)(local_38);
                        rb_rotate_left(arg0, *(uint64_t *)(local_38), arg2);
                    }
                    *(uint32_t *)(*(uint64_t *)(local_38) + 0x28) = 0x1;
                    *(uint32_t *)(*(uint64_t *)(*(uint64_t *)(local_38)) + 0x28) = 0x0;
                    rb_rotate_right(arg0, *(uint64_t *)(*(uint64_t *)(local_38)), arg2);
                    continue;
                } else {
                    if (*(uint32_t *)(local_40 + 0x28) != 0x0) {
                        goto loc_008c78;
                    } else {
                        *(uint32_t *)(*(uint64_t *)(local_38) + 0x28) = 0x1;
                        *(uint32_t *)(local_40 + 0x28) = 0x1;
                        *(uint32_t *)(*(uint64_t *)(*(uint64_t *)(local_38)) + 0x28) = 0x0;
                        local_38 = *(uint64_t *)(*(uint64_t *)(local_38));
                        continue;
                    }
                }
            }
            continue;
        }
        break;
    }
    *(uint32_t *)(*(uint64_t *)(arg2) + 0x28) = 0x1;
    return;
}
