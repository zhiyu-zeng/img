void vm_func_005559(const void* arg0) {
    dispatch_registered_handler(0xd, *(uint64_t *)(arg0), 0x0, 0x0);
    return;
}
