void vm_func_019d33(void) {
    g_15f0 = get_cached_module_base(0x1);
    g_15f8 = get_cached_module_base(0x0);
    if (((uint64_t)(g_15f0)) >= 0x100000001) {
        local_10 = *(uint64_t *)(g_15f0 + 0x454aec);
        local_18 = *(uint64_t *)(g_15f8 + 0xb7c7f20);
        if (*(uint64_t *)(g_15f0 + 0x454aec) == 0x91206100f94007e8) {
            if (local_18 == 0x912d62d6f00a4696) {
                register_vm_callback(0x19159, 0x6c61, 0x3, 0x0, 0x90, (g_15f8 + 0xb7c7f00));
            }
        }
    }
    return;
}
