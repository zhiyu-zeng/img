void vm_func_00b7a8(uint64_t arg0, uint64_t arg1) {
    vm_func_00b826(arg0, arg1, "<init>", "()V", 0x0, 0x0, 0x0, 0x0);
    return;
}
