void vm_func_01e68a(void) {
    g_1a38 = vm_func_01e964("/data/data/com.proxima.dfm/files/.Save", 0x0);
    g_1a3c = vm_func_01e964("/data/data/com.proxima.dfm/files/key", 0x0);
    g_1a40 = vm_func_01e964("/data/data/com.proxima.dfm/files/serial", 0x0);
    return;
}
