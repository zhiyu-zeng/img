void vm_func_03305e(uint64_t arg0, uint64_t arg1) {
    call_native_n(g_3f78, arg0, arg1);
    return;
}
