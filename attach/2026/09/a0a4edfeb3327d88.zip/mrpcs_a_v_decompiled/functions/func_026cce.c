uint64_t vm_func_026cce(const void* arg0) {
    return (*(uint64_t *)(*(uint64_t *)(arg0))) == (*(uint64_t *)(arg0 + 0x18));
}
