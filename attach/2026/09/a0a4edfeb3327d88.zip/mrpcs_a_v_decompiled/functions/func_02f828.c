uint64_t vm_func_02f828(uint64_t arg0, uint64_t arg1) {
    local_18 = (arg0 + 0x1127a74c);
    if (((uint64_t)((arg0 + 0x1127a74c))) <= arg0) {
        result = 0x0;
    } else {
        result = call_native_n(local_18, arg1, 0x0);
    }
    return result;
}
