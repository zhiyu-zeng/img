void vm_func_0076f0(uint64_t arg0) {
    vm_func_007738(arg0);
    return;
}
