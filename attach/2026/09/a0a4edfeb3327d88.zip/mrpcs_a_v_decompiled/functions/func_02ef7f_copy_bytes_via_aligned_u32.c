uint64_t copy_bytes_via_aligned_u32(uint64_t arg0, uint64_t arg1, uint64_t arg2) {
    if (arg1 == 0x0) {
        result = 0xffffffff;
    } else {
        if (arg2 == 0x0) {
            result = 0xffffffff;
            return result;
        } else {
            if (arg0 != 0x0) {
                index_20 = 0x0;
                while (((uint64_t)(index_20)) < arg2) {
                    local_28 = ((arg0 + index_20) & 0xfffffffffffffffc);
                    local_30 = ((arg0 + index_20) & 0x3);
                    local_38 = ((arg0 + index_20) & 0xfffffffffffffffc);
                    local_40 = *(uint32_t *)((arg0 + index_20) & 0xfffffffffffffffc);
                    *(uint8_t *)(arg1 + index_20) = (*(uint32_t *)((arg0 + index_20) & 0xfffffffffffffffc) >> (((arg0 + index_20) & 0x3) << 0x3));
                    index_20 = (index_20 + 0x1);
                    continue;
                }
                result = 0x0;
            } else {
                result = 0xffffffff;
                return result;
            }
        }
    }
    return result;
}
