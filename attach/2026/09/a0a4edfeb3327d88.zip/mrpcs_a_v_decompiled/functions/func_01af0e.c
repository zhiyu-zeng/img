void vm_func_01af0e(void) {
    module_base_01af3a = get_cached_module_base(0x1);
    g_16a8 = module_base_01af3a;
    if (((uint64_t)(module_base_01af3a)) >= 0x100000001) {
        local_8 = *(uint64_t *)(g_16a8 + 0x454aec);
        if (*(uint64_t *)(g_16a8 + 0x454aec) == 0x91206100f94007e8) {
            register_vm_callback(0x1adf3, 0x6c64, 0x1, 0x1e);
        }
    }
    return;
}
