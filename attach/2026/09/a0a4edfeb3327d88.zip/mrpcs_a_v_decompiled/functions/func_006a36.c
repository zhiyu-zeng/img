uint64_t vm_func_006a36(uint64_t arg0) {
    return vm_func_0055c0(arg0);
}
