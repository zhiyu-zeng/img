uint64_t vm_func_000f25(uint64_t arg0, uint64_t arg1, uint64_t arg2) {
    VmU64Pair u64_pair_050;
    VmU64Pair u64_pair_060;
    uint8_t* stack_buf_030 = (uint8_t*)(fp + 0x30); /* observed >= 0x20 bytes */
    if (g_00d0 == 0x0) {
        g_00d0 = getpid();
    }
    memset(stack_buf_030, 0x0, 0x20);
    u64_pair_050.first = stack_buf_030;
    u64_pair_050.second = 0x10;
    u64_pair_060.first = arg0;
    u64_pair_060.second = 0x10;
    if (sys_process_vm_readv(g_00d0, &u64_pair_050, 0x1, &u64_pair_060, 0x1, 0x0) != 0x10) {
        result = 0x0;
    } else {
        *(uint32_t *)(arg2) = vm_func_0006fa(arg0, 0x10, *(uint32_t *)(arg2));
        *(uint32_t *)(arg1) = vm_func_0006fa(stack_buf_030, 0x10, *(uint32_t *)(arg1));
        result = 0x1;
    }
    return result;
}
