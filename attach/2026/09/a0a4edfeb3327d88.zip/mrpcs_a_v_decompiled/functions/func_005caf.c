void vm_func_005caf(uint64_t arg0, uint64_t arg1) {
    local_28 = vm_func_005011(arg0, arg1, (fp + 0x20));
    vm_func_00562b(arg0);
    return;
}
