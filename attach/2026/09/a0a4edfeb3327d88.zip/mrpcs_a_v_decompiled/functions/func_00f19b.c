void vm_func_00f19b(const void* arg0) {
    if (*(uint64_t *)(arg0) != 0x0) {
        free(*(uint64_t *)(arg0));
    }
    return;
}
