uint64_t vm_func_007612(uint64_t arg0) {
    return vm_func_007fec(arg0);
}
