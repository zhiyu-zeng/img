void vm_func_0167c7(void) {
    g_0590 = resolve_symbol("libc.so", "pthread_mutex_trylock");
    g_0598 = resolve_symbol("libc.so", "pthread_mutex_unlock");
    g_1580 = resolve_symbol("libc.so", "strstr");
    g_1590 = resolve_symbol("libc.so", "sscanf");
    heap_ptr_0168da = ((fn_operator_new)(0x18));
    vm_func_016a03(heap_ptr_0168da, 0x1e);
    g_1598 = heap_ptr_0168da;
    if (g_0590 == 0x0) {
        g_058c = 0x1;
    } else {
        if (g_0598 == 0x0) {
            g_058c = 0x1;
            return;
        } else {
            if (g_1580 == 0x0) {
                g_058c = 0x1;
                return;
            } else {
                if (g_1590 != 0x0) {
                    vm_func_016b06();
                    g_058c = 0x2;
                } else {
                    g_058c = 0x1;
                    return;
                }
            }
        }
    }
    return;
}
