uint64_t sys_openat(uint64_t arg0, uint64_t arg1, uint64_t arg2, uint64_t arg3) {
    if (g_3830 == 0x0) {
        g_3830 = build_aarch64_syscall_stub(0x38);
    }
    if (g_3830 != 0x0) {
        result = call_native_n(g_3830, (int64_t)(arg0), arg1, (int64_t)(arg2), (int64_t)(arg3));
    } else {
        result = 0xffffffffffffffff;
    }
    return result;
}
