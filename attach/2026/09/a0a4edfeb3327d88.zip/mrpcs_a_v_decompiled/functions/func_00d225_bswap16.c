uint64_t bswap16(uint64_t arg0, uint64_t arg1) {
    return ((arg1 >> 0x8) | (arg1 << 0x8));
}
