uint64_t vm_func_02483d(const void* arg0, uint64_t arg1, uint64_t arg2, uint64_t arg3, uint64_t arg4) {
    struct { uint64_t field_00; uint64_t field_08; uint64_t field_10; uint64_t field_18; uint64_t field_20; uint64_t field_28; } local_obj_058;
    local_40 = 0x0;
    if (*(uint32_t *)(arg0 + 0x68) != 0x0) {
        local_40 = vm_func_024d98(arg0, arg1);
    }
    if (local_40 == 0x0) {
        if (*(uint32_t *)(arg0 + 0x88) != 0x0) {
            local_40 = vm_func_02504d(arg0, arg1);
        }
    }
    index_48 = 0x0;
    while (((uint64_t)(index_48)) < ((uint64_t)(*(uint64_t *)(arg0 + 0x28)))) {
        if (vm_func_02547f(arg0, (*(uint64_t *)(arg0 + 0x20) + (index_48 * 0x18)), arg1, arg2, arg3, arg4, (fp + 0x40), 0x1) == 0x0) {
            index_48 = (index_48 + 0x1);
            continue;
        } else {
            result = 0x0;
            goto loc_024d44;
        }
    }
    index_50 = 0x0;
    while (((uint64_t)(index_50)) < ((uint64_t)(*(uint64_t *)(arg0 + 0x38)))) {
        if (vm_func_02547f(arg0, (*(uint64_t *)(arg0 + 0x30) + (index_50 * 0x18)), arg1, arg2, arg3, arg4, (fp + 0x40), 0x0) == 0x0) {
            index_50 = (index_50 + 0x1);
            continue;
        } else {
            result = 0x0;
            goto loc_024d44;
        }
    }
    local_obj_058.field_00 = arg0;
    local_obj_058.field_08 = arg1;
    local_obj_058.field_10 = arg2;
    local_obj_058.field_18 = arg3;
    local_obj_058.field_20 = arg4;
    local_obj_058.field_28 = (fp + 0x40);
    if (*(uint64_t *)(arg0 + 0x40) != 0x0) {
        vm_func_025ab8((fp + 0x88), *(uint64_t *)(arg0 + 0x40), *(uint64_t *)(arg0 + 0x48));
        vm_func_025c75((fp + 0x88), 0x25b32, &local_obj_058);
    }
    result = local_40;
    loc_024d44:
    return result;
}
