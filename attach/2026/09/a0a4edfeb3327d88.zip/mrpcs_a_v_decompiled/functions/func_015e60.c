void vm_func_015e60(void* arg0) {
    local_28 = vm_func_012bf1(arg0);
    local_30 = ((local_28 == 0x0) ? 0x1 : (local_28 << 0x1));
    local_38 = vm_func_0160b3(arg0, ((local_28 == 0x0) ? 0x1 : (local_28 << 0x1)));
    dst_40 = local_38;
    src_48 = vm_func_01336e(arg0);
    while (true) {
        if (src_48 == vm_func_0133b0(arg0)) break;
        memcpy_checked(dst_40, src_48, 0x14);
        dst_40 = (dst_40 + 0x14);
        src_48 = (src_48 + 0x14);
        continue;
    }
    vm_func_01614e(arg0);
    *(uint64_t *)(arg0) = local_38;
    *(uint64_t *)(arg0 + 0x8) = dst_40;
    *(uint64_t *)(arg0 + 0x10) = (local_38 + (local_30 * 0x14));
    return;
}
