uint64_t vm_func_0160b3(uint64_t arg0, uint64_t arg1) {
    heap_ptr_10 = ((fn_operator_new_array)(vm_mov_once_q(0xffffffffffffffff, (arg1 * 0x14))));
    return heap_ptr_10;
}
