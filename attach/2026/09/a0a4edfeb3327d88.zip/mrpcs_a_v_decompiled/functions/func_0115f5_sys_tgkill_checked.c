uint64_t sys_tgkill_checked(uint64_t pid, uint64_t tid, uint64_t signal) {
    *(uint32_t *)(__errno()) = 0x0;
    result = syscall_tgkill(pid, tid, (int64_t)(signal));
    if (result != 0x0) {
        result = (0x0 - *(uint32_t *)(__errno()));
    }
    g_03ec = (g_03ec + 0x1);
    if ((((g_03ec + 0x1)) % (uint64_t)(g_03f0)) == 0x0) {
        set_context_offset(0x1);
    }
    return result;
}
