void vm_func_0059cb(uint64_t arg0, uint64_t arg1, uint64_t arg2) {
    local_28 = vm_func_003b19(arg0, arg1, arg2);
    vm_func_00562b(arg0);
    return;
}
