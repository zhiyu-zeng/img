void vm_func_025c75(uint64_t arg0, uint64_t arg1, uint64_t arg2) {
    VmU64Triple u64_triple_028;
    if (vm_func_026293(arg0, (fp + 0x20)) == 0x0) {
        if (vm_func_026293(arg0, &u64_triple_028) == 0x0) {
            local_40 = 0x0;
            while (((uint64_t)(local_40)) < ((uint64_t)(local_20))) {
                if (vm_func_026293(arg0, (fp + 0x48)) == 0x0) {
                    if (vm_func_026293(arg0, (fp + 0x50)) == 0x0) {
                        local_58 = 0x0;
                        if ((local_50 & 0x2) == 0x0) {
                            if (!(local_50 & 0x1)) {
                                local_60 = (local_50 & 0xc);
                                if ((local_50 & 0xc) != 0xc) {
                                    u64_triple_028.third = 0x0;
                                    index_70 = 0x0;
                                    while (((uint64_t)(index_70)) < ((uint64_t)(local_48))) {
                                        if ((local_50 & 0x2) == 0x0) {
                                            if (vm_func_026293(arg0, (fp + 0x78)) == 0x0) {
                                                u64_triple_028.first = (u64_triple_028.first + local_78);
                                                if (local_50 & 0x1) {
                                                    if (local_60 != 0x8) {
                                                        call_result_0261c9 = vm_call_reg(arg1);
                                                        if (call_result_0261c9 & 0x1) {
                                                            index_70 = (index_70 + 0x1);
                                                            continue;
                                                        }
                                                    } else {
                                                        if (vm_func_026293(arg0, (fp + 0x80)) == 0x0) {
                                                            u64_triple_028.third = (u64_triple_028.third + local_80);
                                                            call_result_0261c9 = vm_call_reg(arg1);
                                                            goto loc_02619d;
                                                        }
                                                    }
                                                } else {
                                                    if (vm_func_026293(arg0, &u64_triple_028.second) == 0x0) {
                                                        goto loc_026109;
                                                    }
                                                }
                                            }
                                        } else {
                                            u64_triple_028.first = (u64_triple_028.first + local_58);
                                            goto loc_0260a0;
                                        }
                                    }
                                    local_40 = (local_40 + local_48);
                                    continue;
                                } else {
                                    if (vm_func_026293(arg0, (fp + 0x68)) == 0x0) {
                                        u64_triple_028.third = (u64_triple_028.third + local_68);
                                        index_70 = 0x0;
                                        goto loc_025fa1;
                                    }
                                }
                            } else {
                                if (vm_func_026293(arg0, &u64_triple_028.second) == 0x0) {
                                    local_60 = (local_50 & 0xc);
                                    goto loc_025edf;
                                }
                            }
                        } else {
                            if (vm_func_026293(arg0, (fp + 0x58)) == 0x0) {
                                goto loc_025e76;
                            }
                        }
                    }
                }
            }
        }
    }
    loc_026253:
    return;
}
