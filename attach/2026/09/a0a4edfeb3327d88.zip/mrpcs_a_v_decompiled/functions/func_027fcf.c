void vm_func_027fcf(void) {
    VmProcMapsLine maps_line;
    VmU64Pair u64_pair_880;
    uint8_t* stack_buf_068 = (uint8_t*)(fp + 0x68); /* observed >= 0x400 bytes */
    heap_ptr_02808f = ((fn_operator_new)(0x18));
    vm_func_02847c(heap_ptr_02808f, 0x64);
    g_2f60 = heap_ptr_02808f;
    maps_file_60 = fopen("/proc/self/maps", "r");
    if (maps_file_60 != 0x0) {
        local_890 = "00000000 00:00 0";
        while (true) {
            if (fgets(stack_buf_068, 0x400, maps_file_60) == 0x0) break;
            maps_line.start = 0x0;
            maps_line.end = 0x0;
            memset(maps_line.perms, 0x0, 0x5);
            memset(maps_line.path, 0x0, 0x400);
            call_native_n(g_2ec8, stack_buf_068, "%llx-%llx %s %*s %*s %*s %s", &maps_line.start, &maps_line.end, maps_line.perms, maps_line.path);
            if (call_native_n(g_2eb8, maps_line.perms, "x") != 0x0) {
                if (call_native_n(g_2eb8, stack_buf_068, local_890) != 0x0) {
                    u64_pair_880.first = maps_line.start;
                    u64_pair_880.second = maps_line.end;
                    vm_func_02857f(*(uint64_t *)(&g_2f60), &u64_pair_880);
                    continue;
                }
            }
        }
        fclose(maps_file_60);
    }
    return;
}
