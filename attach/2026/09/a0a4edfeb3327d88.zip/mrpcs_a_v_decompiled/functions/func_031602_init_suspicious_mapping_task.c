void init_suspicious_mapping_task(void) {
    fn_sscanf_maps = resolve_symbol("libc.so", "sscanf");
    fn_open_presence = resolve_symbol("libc.so", "open");
    register_vm_callback(0x316bd, 0x6c99, 0x1, 0x3c);
    return;
}
