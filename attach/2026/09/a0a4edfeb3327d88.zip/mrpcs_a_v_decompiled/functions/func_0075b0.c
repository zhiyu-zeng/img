uint64_t vm_func_0075b0(const void* arg0, const void* arg1) {
    return (*(uint64_t *)(arg0)) != (*(uint64_t *)(arg1));
}
