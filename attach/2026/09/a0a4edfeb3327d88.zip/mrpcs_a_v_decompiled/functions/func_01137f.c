uint64_t vm_func_01137f(uint64_t path) {
    uint8_t* stack_buf_008 = (uint8_t*)(fp + 0x8); /* observed >= 0x400 bytes */
    *(uint32_t *)(__errno()) = 0x0;
    memset(stack_buf_008, 0x0, 0x400);
    result = syscall_statfs(path, stack_buf_008);
    if (result != 0x0) {
        result = (0x0 - *(uint32_t *)(__errno()));
    }
    g_03ec = (g_03ec + 0x1);
    if ((((g_03ec + 0x1)) % (uint64_t)(g_03f0)) == 0x0) {
        set_context_offset(0x1);
    }
    return result;
}
