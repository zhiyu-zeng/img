void vm_func_00bdf3(uint64_t arg0, uint64_t arg1, uint64_t arg2) {
    local_18 = vm_func_0052f5(arg0, arg1, arg2);
    return;
}
