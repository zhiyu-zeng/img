uint64_t vm_func_011743(uint64_t arg0) {
    local_10 = vm_func_01122f(arg0);
    if (local_10 != 0xfffffff3) {
        result = local_10;
    } else {
        result = 0x0;
    }
    return result;
}
