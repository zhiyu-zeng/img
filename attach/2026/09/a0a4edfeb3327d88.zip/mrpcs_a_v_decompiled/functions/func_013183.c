void vm_func_013183(uint64_t arg0, uint64_t arg1, uint64_t arg2) {
    local_10 = arg1;
    local_14 = arg2;
    local_18 = 0x0;
    src_28 = vm_func_01336e(arg0);
    local_30 = vm_func_0133b0(arg0);
    while (src_28 != local_30) {
        memcpy_checked((fp + 0x38), src_28, 0x14);
        if ((local_38 & local_10) != 0x0) {
            if ((local_38 & local_14) == 0x0) {
                local_18 = (local_18 + 0x1);
            }
        }
        src_28 = (src_28 + 0x14);
        continue;
    }
    return;
}
