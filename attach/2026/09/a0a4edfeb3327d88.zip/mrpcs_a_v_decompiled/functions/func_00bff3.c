void vm_func_00bff3(uint64_t arg0, uint64_t arg1) {
    vm_func_00516f(arg0, arg1);
    return;
}
