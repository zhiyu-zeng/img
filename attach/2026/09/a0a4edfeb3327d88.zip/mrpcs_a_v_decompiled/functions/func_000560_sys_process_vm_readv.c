int64_t sys_process_vm_readv(int32_t pid, const VmU64Pair* local_iov, uint64_t local_iov_count, const VmU64Pair* remote_iov, uint64_t remote_iov_count, uint64_t flags) {
    return syscall_process_vm_readv(pid, local_iov, local_iov_count, remote_iov, remote_iov_count, flags);
}
