uint64_t vm_func_004cac(const void* arg0, uint64_t arg1, uint64_t arg2, uint64_t arg3, uint64_t arg4, uint64_t arg5, uint64_t arg6) {
    struct { uint64_t field_00; uint64_t field_08; uint64_t field_10; uint64_t field_18; uint64_t field_20; uint64_t field_28; uint64_t field_30; } local_obj_038;
    local_obj_038.field_00 = arg1;
    local_obj_038.field_08 = arg2;
    local_obj_038.field_10 = arg3;
    local_obj_038.field_18 = arg4;
    local_obj_038.field_20 = arg5;
    local_obj_038.field_28 = arg6;
    local_obj_038.field_30 = 0x0;
    return dispatch_registered_handler(0x7b, *(uint64_t *)(arg0), &local_obj_038, 0x6);
}
