void vm_func_007279(const void* arg0) {
    vm_func_00743e((fp + 0x28));
    vm_func_007484((fp + 0x30), (arg0 + 0x8));
    vm_func_0074dc((fp + 0x28), (fp + 0x30));
    while (true) {
        vm_func_007558((fp + 0x38), (arg0 + 0x8));
        if (!(vm_func_0075b0((fp + 0x28), (fp + 0x38)) & 0x1)) break;
        vm_func_005692(*(uint64_t *)(arg0), *(uint64_t *)(vm_func_007612((fp + 0x28))));
        vm_func_00765a((fp + 0x40), (fp + 0x28), 0x0);
        continue;
    }
    vm_func_0076f0((arg0 + 0x8));
    return;
}
