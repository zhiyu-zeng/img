void vm_func_032a90(void) {
    g_3ecc = 0x1;
    module_base_032ad7 = get_cached_module_base(0x0);
    g_3fb0 = module_base_032ad7;
    if (vm_func_03300d(module_base_032ad7) & 0x1) {
        g_3fa8 = (g_3fb0 + 0x164914a4);
        g_3f98 = (g_3fb0 + 0x16429050);
        g_3f88 = (g_3fb0 + 0x16417b00);
        g_3f80 = (g_3fb0 + 0x110c7a24);
        g_3f58 = (g_3fb0 + 0x1fc9dbc0);
        g_3f78 = (g_3fb0 + 0x10b5f9b4);
        g_3f70 = (g_3fb0 + 0x11216050);
        g_3ecc = 0x2;
    }
    return;
}
