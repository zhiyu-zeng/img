void vm_func_005a8d(uint64_t arg0, uint64_t arg1, uint64_t arg2) {
    local_30 = vm_func_00399f(arg0, arg1, arg2, "I");
    if (local_30 != 0x0) {
        local_38 = vm_func_003b19(arg0, arg1, local_30);
        vm_func_00562b(arg0);
        local_10 = local_38;
    } else {
        local_10 = 0x0;
    }
    return;
}
