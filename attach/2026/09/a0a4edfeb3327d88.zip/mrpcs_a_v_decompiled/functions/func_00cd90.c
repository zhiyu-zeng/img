void vm_func_00cd90(void* arg0, uint64_t arg1) {
    local_14 = 0x0;
    size_18 = (arg1 << 0x2);
    if (((int32_t)((arg1 << 0x2))) > 1000) {
        local_0 = (local_14 & 0x1);
    } else {
        if (((int32_t)(size_18)) >= ((int32_t)(*(uint32_t *)(arg0 + 0x10)))) {
            heap_ptr_20 = malloc((int64_t)(size_18));
            memset(heap_ptr_20, 0x0, (int64_t)(size_18));
            memcpy_checked(heap_ptr_20, *(uint64_t *)(arg0), (int64_t)(*(uint32_t *)(arg0 + 0x10)));
            if (*(uint64_t *)(arg0) != 0x0) {
                free(*(uint64_t *)(arg0));
                *(uint64_t *)(arg0) = 0x0;
            }
            *(uint32_t *)(arg0 + 0x10) = size_18;
            *(uint64_t *)(arg0) = heap_ptr_20;
            local_14 = 0x1;
            local_0 = 0x1;
        } else {
            local_0 = (local_14 & 0x1);
            return;
        }
    }
    return;
}
