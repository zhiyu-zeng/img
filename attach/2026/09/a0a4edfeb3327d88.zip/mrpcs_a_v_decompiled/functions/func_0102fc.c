uint64_t vm_func_0102fc(const void* arg0, uint64_t arg1) {
    return (*(uint64_t *)(arg0) + (arg1 * 0x38));
}
