void vm_func_0330d4(uint64_t arg0, uint64_t arg1, uint8_t* arg2) {
    call_native_n(g_3f70, arg0, arg1, arg2);
    return;
}
