uint64_t vm_func_012bf1(uint64_t arg0) {
    tmp_012c39 = vm_func_012d53(arg0);
    return (((tmp_012c39 - vm_func_012d99(arg0)) >> 0x2) * 0xcccccccccccccccd);
}
