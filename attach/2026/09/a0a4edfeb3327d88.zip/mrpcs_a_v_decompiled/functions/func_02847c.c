void vm_func_02847c(void* arg0, uint64_t arg1) {
    *(uint64_t *)(arg0) = 0x0;
    *(uint64_t *)(arg0 + 0x8) = 0x0;
    *(uint64_t *)(arg0 + 0x10) = 0x0;
    ptr_028510 = vm_func_028972(arg0, arg1);
    *(uint64_t *)(arg0) = ptr_028510;
    *(uint64_t *)(arg0 + 0x8) = ptr_028510;
    *(uint64_t *)(arg0 + 0x10) = (ptr_028510 + (arg1 << 0x4));
    return;
}
