uint64_t packet_append_xor_bytes(void* arg0, uint64_t arg1, uint64_t arg2, uint64_t arg3) {
    if (arg1 == 0x0) {
        result = 0x0;
    } else {
        if (((int32_t)((*(uint32_t *)(arg0 + 0x10) - *(uint32_t *)(arg0 + 0x14)))) > ((int32_t)(arg2))) {
            *(uint32_t *)(arg0 + 0x14) = (*(uint32_t *)(arg0 + 0x14) + 0x1);
            *(uint8_t *)(*(uint64_t *)(arg0) + (int64_t)(*(uint32_t *)(arg0 + 0x14))) = arg2;
            index_1c = 0x0;
            while (((int32_t)(index_1c)) < ((int32_t)(arg2))) {
                *(uint32_t *)(arg0 + 0x14) = (*(uint32_t *)(arg0 + 0x14) + 0x1);
                *(uint8_t *)(*(uint64_t *)(arg0) + (int64_t)(*(uint32_t *)(arg0 + 0x14))) = (*(uint8_t *)(arg1 + (int64_t)(index_1c)) ^ arg3);
                index_1c = (index_1c + 0x1);
                continue;
            }
            result = 0x1;
        } else {
            result = 0x0;
            return result;
        }
    }
    return result;
}
