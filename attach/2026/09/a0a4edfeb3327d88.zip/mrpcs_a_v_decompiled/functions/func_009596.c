void vm_func_009596(void* arg0, uint64_t arg1) {
    if (arg1 != arg0) {
        *(uint64_t *)(arg0) = *(uint64_t *)(arg1);
        *(uint8_t *)(arg0 + 0x8) = (*(uint8_t *)(arg1 + 0x8) & 0x1);
    }
    return;
}
