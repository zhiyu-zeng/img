void vm_func_0077f4(void* arg0, uint64_t arg1) {
    if (arg1 != 0x0) {
        local_20 = *(uint64_t *)(arg1 + 0x8);
        local_28 = *(uint64_t *)(arg1 + 0x10);
        vm_func_00798e(arg0, arg1);
        *(uint64_t *)(arg0 + 0x8) = (*(uint64_t *)(arg0 + 0x8) + 0xffffffffffffffff);
        if (local_20 != 0x0) {
            vm_func_0077f4(arg0, local_20);
        }
        if (local_28 != 0x0) {
            vm_func_0077f4(arg0, local_28);
        }
    }
    return;
}
