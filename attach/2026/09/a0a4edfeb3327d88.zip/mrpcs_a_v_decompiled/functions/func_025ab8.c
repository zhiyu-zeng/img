void vm_func_025ab8(void* arg0, uint64_t arg1, uint64_t arg2) {
    *(uint64_t *)(arg0) = arg1;
    *(uint64_t *)(arg0 + 0x8) = (arg1 + arg2);
    return;
}
