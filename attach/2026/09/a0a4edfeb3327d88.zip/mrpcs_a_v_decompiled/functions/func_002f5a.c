void vm_func_002f5a(uint64_t arg0) {
    return;
}
