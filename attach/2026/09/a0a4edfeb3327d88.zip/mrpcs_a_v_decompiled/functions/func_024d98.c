uint64_t vm_func_024d98(uint64_t arg0, uint64_t string) {
    local_20 = vm_func_0269ce(string);
    local_24 = *(uint32_t *)(*(uint64_t *)(arg0 + 0x60) + (((local_20) % (uint64_t)(*(uint32_t *)(arg0 + 0x68))) << 0x2));
    while (local_24 != 0x0) {
        local_28 = (*(uint64_t *)(arg0 + 0x50) + (local_24 * 0x18));
        local_30 = (*(uint8_t *)((*(uint64_t *)(arg0 + 0x50) + (local_24 * 0x18)) + 0x4) & 0xf);
        if ((*(uint8_t *)((*(uint64_t *)(arg0 + 0x50) + (local_24 * 0x18)) + 0x4) & 0xf) == 0x2) {
            compare_result_024f77 = strcmp((*(uint64_t *)(arg0 + 0x58) + *(uint32_t *)(local_28)), string);
            if (compare_result_024f77 == 0x0) {
                result = local_28;
                goto loc_02501b;
            } else {
                local_24 = *(uint32_t *)(*(uint64_t *)(arg0 + 0x70) + (local_24 << 0x2));
                continue;
            }
        } else {
            if (local_30 == 0xa) {
                compare_result_024f77 = strcmp((*(uint64_t *)(arg0 + 0x58) + *(uint32_t *)(local_28)), string);
                goto loc_024f2b;
            } else {
                if (local_30 == 0x0) {
                    compare_result_024f77 = strcmp((*(uint64_t *)(arg0 + 0x58) + *(uint32_t *)(local_28)), string);
                    goto loc_024f2b;
                } else {
                    local_24 = *(uint32_t *)(*(uint64_t *)(arg0 + 0x70) + (local_24 << 0x2));
                    continue;
                }
            }
        }
    }
    result = 0x0;
    loc_02501b:
    return result;
}
