void vm_func_00bd23(uint64_t arg0, uint64_t arg1) {
    local_10 = vm_func_0034ae(arg0, arg1);
    return;
}
