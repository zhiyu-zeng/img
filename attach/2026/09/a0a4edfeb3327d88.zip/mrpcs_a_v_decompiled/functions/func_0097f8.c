void vm_func_0097f8(void* arg0) {
    *(uint64_t *)(arg0) = 0x0;
    *(uint64_t *)(arg0 + 0x8) = 0x0;
    return;
}
