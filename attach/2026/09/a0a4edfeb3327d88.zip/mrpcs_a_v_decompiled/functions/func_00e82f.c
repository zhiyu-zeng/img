void vm_func_00e82f(uint64_t arg0, uint64_t arg1, uint64_t arg2, uint64_t arg3) {
    local_32 = 0x1;
    packet_append_u16(arg0, arg3, 0x1);
    packet_append_u32(arg0, arg2, 0x1);
    index_34 = 0x0;
    while (((uint64_t)((int64_t)(index_34))) < ((uint64_t)(((arg2) / arg3)))) {
        if (((int32_t)(arg3)) < 4) {
            if (((int32_t)(arg3)) < 2) {
                if (arg3 != 0x1) {
                    local_32 = 0x0;
                } else {
                    packet_append_u8(arg0, *(uint8_t *)(arg1 + (int64_t)(index_34)));
                }
            } else {
                if (arg3 == 0x2) {
                    packet_append_u16(arg0, *(uint16_t *)(arg1 + ((int64_t)(index_34) << 0x1)), 0x1);
                } else {
                    local_32 = 0x0;
                    index_34 = (index_34 + 0x1);
                    continue;
                }
            }
        } else {
            if (((int32_t)(arg3)) < 8) {
                if (arg3 == 0x4) {
                    packet_append_u32(arg0, *(uint32_t *)(arg1 + ((int64_t)(index_34) << 0x2)), 0x1);
                } else {
                    local_32 = 0x0;
                    index_34 = (index_34 + 0x1);
                    continue;
                }
            } else {
                if (arg3 == 0x8) {
                    packet_append_u64(arg0, *(uint64_t *)(arg1 + ((int64_t)(index_34) << 0x3)), 0x1);
                } else {
                    local_32 = 0x0;
                    index_34 = (index_34 + 0x1);
                    continue;
                }
            }
        }
        index_34 = (index_34 + 0x1);
        continue;
    }
    return;
}
