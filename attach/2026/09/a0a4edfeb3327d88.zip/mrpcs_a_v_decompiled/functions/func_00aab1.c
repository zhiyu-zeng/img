uint64_t vm_func_00aab1(uint64_t arg0, uint64_t arg1, uint64_t arg2, uint64_t arg3) {
    memcpy_checked(fp, &g_01e0, 0x8);
    local_28 = vm_func_003bcc(arg0, arg1, arg2, arg3);
    if (local_28 == 0x0) {
        vm_func_006a7e(arg0);
    } else {
        if (vm_func_006a36(arg0) == 0x0) {
            local_30 = *(uint8_t *)(arg3);
            if (((int32_t)(*(uint8_t *)(arg3))) < 76) {
                if (*(uint8_t *)(arg3) == 0x49) {
                    result = vm_func_003d46(arg0, arg1, local_28);
                }
            } else {
                if (((int32_t)(*(uint8_t *)(arg3))) < 91) {
                    if (*(uint8_t *)(arg3) == 0x4c) {
                        tmp_00ad0d = vm_func_00ad2d(arg0, arg1, local_28);
                        result = tmp_00ad0d;
                    }
                } else {
                    if (*(uint8_t *)(arg3) == 0x5b) {
                        tmp_00ad0d = vm_func_00ad2d(arg0, arg1, local_28);
                        result = tmp_00ad0d;
                        return result;
                    }
                }
            }
        } else {
            vm_func_006a7e(arg0);
            return result;
        }
    }
    return result;
}
