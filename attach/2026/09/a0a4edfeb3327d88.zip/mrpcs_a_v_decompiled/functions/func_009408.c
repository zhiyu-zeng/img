uint64_t vm_func_009408(uint64_t arg0, uint64_t arg1, uint64_t arg2) {
    return arg2;
}
