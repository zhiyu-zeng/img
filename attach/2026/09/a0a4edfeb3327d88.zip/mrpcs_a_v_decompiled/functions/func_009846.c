void vm_func_009846(uint64_t arg0, uint64_t arg1, uint64_t arg2, uint64_t arg3, uint64_t arg4, uint64_t arg5, uint64_t arg6, uint64_t arg7) {
    uint8_t* stack_buf_028 = (uint8_t*)(fp + 0x28); /* observed >= 0x8 bytes */
    memcpy_checked(stack_buf_028, &g_01c0, 0x8);
    local_70 = vm_func_009c32(arg0, arg1);
    if (local_70 == 0x0) {
        vm_func_006a7e(arg0);
    } else {
        if (vm_func_006a36(arg0) == 0x0) {
            vm_call_reg(0x9628);
            vm_func_006ac6((fp + 0x78), local_70);
            local_90 = vm_func_0038d4(arg0, local_70, arg2, arg3);
            if (local_90 == 0x0) {
                vm_func_006a7e(arg0);
                local_98 = 0x1;
            } else {
                if (vm_func_006a36(arg0) == 0x0) {
                    local_a0 = vm_func_009c9a(arg0, local_70, arg2, arg3, local_90, arg4, arg5, arg6);
                    memcpy_checked(stack_buf_028, (fp + 0xa0), 0x8);
                    local_98 = 0x1;
                } else {
                    vm_func_006a7e(arg0);
                    local_98 = 0x1;
                    vm_call_reg(0x7279);
                    return;
                }
            }
            vm_call_reg(0x7279);
        } else {
            vm_func_006a7e(arg0);
            return;
        }
    }
    return;
}
