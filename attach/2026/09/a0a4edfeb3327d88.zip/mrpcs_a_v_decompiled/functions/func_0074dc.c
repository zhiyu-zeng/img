void vm_func_0074dc(uint64_t arg0, uint64_t arg1) {
    vm_func_007f72(arg0, arg1);
    return;
}
