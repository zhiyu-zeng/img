void vm_func_005bed(uint64_t arg0, uint64_t arg1, uint64_t arg2) {
    local_28 = vm_func_003a6a(arg0, arg1, arg2);
    vm_func_00562b(arg0);
    return;
}
