void vm_func_006a7e(uint64_t arg0) {
    vm_func_00562b(arg0);
    return;
}
