uint64_t build_aarch64_syscall_stub(uint64_t arg0) {
    if (g_37c0 != 0x0) {
        ptr_10 = call_native_n(g_37c0, 0x0, 0x1000, 0x7, 0x22, 0xffffffff, 0x0);
        if (ptr_10 == 0x0) {
            result = 0x0;
        } else {
            if (ptr_10 != 0xffffffffffffffff) {
                local_18 = ptr_10;
                *(uint32_t *)(ptr_10) = ((arg0 << 0x5) | 0x52800008);
                *(uint32_t *)(local_18 + 0x4) = 0xd4000001;
                *(uint32_t *)(local_18 + 0x8) = 0xd65f03c0;
                *(uint32_t *)(local_18 + 0xc) = 0xd503201f;
                *(uint32_t *)(local_18 + 0x10) = 0xd503201f;
                clear_icache(ptr_10, (ptr_10 + 0x14));
                result = ptr_10;
            } else {
                result = 0x0;
                return result;
            }
        }
    } else {
        result = 0x0;
    }
    return result;
}
