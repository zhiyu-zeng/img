uint64_t vm_func_03300d(uint64_t arg0) {
    return arg0 > ((uint64_t)(0x100000000));
}
