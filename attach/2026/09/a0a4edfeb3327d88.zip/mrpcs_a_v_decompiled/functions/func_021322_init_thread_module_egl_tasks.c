void init_thread_module_egl_tasks(void) {
    fn_dl_iterate_phdr = resolve_symbol("libdl.so", "dl_iterate_phdr");
    fn_strstr = resolve_symbol("libc.so", "strstr");
    fn_sscanf = resolve_symbol("libc.so", "sscanf");
    fn_strdup = resolve_symbol("libc.so", "strdup");
    fn_eglSwapBuffers = resolve_symbol("libEGL.so", "eglSwapBuffers");
    module_base_0 = find_module_base("libUE4.so");
    ue_probe_fn0 = (module_base_0 + 0x11a86c9c);
    ue_probe_fn1 = (module_base_0 + 0xa2d2108);
    ue_probe_fn2 = (module_base_0 + 0x11ef17ec);
    register_vm_callback(0x2153f, 0x6c6d, 0xb);
    register_vm_callback(0x216f4, 0x6c6e, 0xb);
    register_vm_callback(0x2227d, 0x6c6f, 0x8);
    register_vm_callback(0x2241a, 0x6c70, 0x1, 0x1e);
    return;
}
