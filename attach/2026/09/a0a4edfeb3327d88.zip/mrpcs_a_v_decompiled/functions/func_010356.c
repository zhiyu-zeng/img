uint64_t vm_func_010356(const void* arg0) {
    return *(uint64_t *)(arg0 + 0x8);
}
