uint64_t vm_func_01336e(const void* arg0) {
    return *(uint64_t *)(arg0);
}
