uint64_t vm_func_024292(uint64_t arg0) {
    if (vm_func_024579() == 0x0) {
        if (*(uint64_t *)(arg0 + 0x10) == 0x0) {
            result = 0x0;
        } else {
            if (*(uint64_t *)(arg0 + 0x8) == 0x0) {
                result = 0x0;
                return result;
            } else {
                if (*(uint64_t *)(arg0 + 0x10) == 0x0) {
                    result = 0x0;
                    return result;
                } else {
                    if (*(uint16_t *)(arg0 + 0x18) != 0x0) {
                        ptr_10 = call_native_n(g_2468, 0x1, 0xb0);
                        if (ptr_10 != 0x0) {
                            native_result_024441 = call_native_n(g_2470, *(uint64_t *)(arg0 + 0x8));
                            *(uint64_t *)(ptr_10) = native_result_024441;
                            if (native_result_024441 != 0x0) {
                                *(uint64_t *)(ptr_10 + 0x8) = *(uint64_t *)(arg0);
                                *(uint64_t *)(ptr_10 + 0x10) = *(uint64_t *)(arg0 + 0x10);
                                *(uint64_t *)(ptr_10 + 0x18) = *(uint16_t *)(arg0 + 0x18);
                                result = ptr_10;
                            } else {
                                free(ptr_10);
                                result = 0x0;
                            }
                        } else {
                            result = 0x0;
                        }
                    } else {
                        result = 0x0;
                        return result;
                    }
                }
            }
        }
    } else {
        result = 0x0;
    }
    return result;
}
