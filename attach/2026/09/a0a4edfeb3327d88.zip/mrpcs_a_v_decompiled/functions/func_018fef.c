void vm_func_018fef(void) {
    g_05a0 = get_cached_module_base(0x1);
    g_05a8 = get_cached_module_base(0x0);
    if (((uint64_t)(g_05a0)) >= 0x100000001) {
        local_10 = *(uint64_t *)(g_05a0 + 0x454aec);
        if (*(uint64_t *)(g_05a0 + 0x454aec) == 0x91206100f94007e8) {
            register_vm_callback(0x18be3, 0x6c53, 0x1, 0x3c);
            register_vm_callback(0x18d15, 0x6c54, 0x1, 0x3c);
            register_vm_callback(0x18625, 0x6c71, 0x1, 0x3c);
        }
    }
    return;
}
