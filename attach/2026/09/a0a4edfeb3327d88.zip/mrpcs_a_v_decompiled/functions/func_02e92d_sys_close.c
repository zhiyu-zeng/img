void sys_close(uint64_t arg0) {
    if (g_3818 == 0x0) {
        g_3818 = build_aarch64_syscall_stub(0x39);
    }
    if (g_3818 != 0x0) {
        local_8 = call_native_n(g_3818, (int64_t)(arg0));
    } else {
        local_8 = 0xffffffffffffffff;
    }
    return;
}
