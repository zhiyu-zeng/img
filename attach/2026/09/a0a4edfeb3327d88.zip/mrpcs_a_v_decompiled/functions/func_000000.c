void vm_func_000000(void) {
    fn___errno = dlsym(0x0, &g_4168);
    module_handle_000075 = dlopen(&g_4170, (int)0x0);
    fn_operator_delete = dlsym(module_handle_000075, &g_417d);
    fn_operator_new = dlsym(module_handle_000075, &g_4184);
    fn_strncpy = dlsym(0x0, &g_418a);
    fn_operator_delete_array = dlsym(module_handle_000075, &g_4192);
    fn_operator_new_array = dlsym(module_handle_000075, &g_4199);
    fn_getuid = dlsym(0x0, &g_419f);
    fn_sprintf = dlsym(0x0, &g_41a6);
    serializer_set_u16_config(0x1010);
    init_module_base_cache();
    register_module_probe_callback(0x6c57);
    libanogs_base_checked = get_cached_module_base(0x1);
    module_base_0001f3 = get_cached_module_base(0x0);
    libue4_base_checked = module_base_0001f3;
    if (((uint64_t)(module_base_0001f3)) >= 0x100000001) {
        if (((uint64_t)(libanogs_base_checked)) >= 0x100000001) {
            local_18 = *(uint64_t *)(libanogs_base_checked + 0x454aec);
            local_20 = *(uint64_t *)(libue4_base_checked + 0xb7c7f20);
            if (*(uint64_t *)(libanogs_base_checked + 0x454aec) == 0x91206100f94007e8) {
                if (local_20 == 0x912d62d6f00a4696) {
                    vm_func_0021e9();
                    vm_func_002d21();
                    vm_func_011100();
                    vm_func_0166d2();
                    vm_func_018fef();
                    vm_func_019d33();
                    vm_func_01aae7();
                    vm_func_01af0e();
                    vm_func_01aff7();
                    vm_func_01e621();
                    vm_func_01ea47();
                    vm_func_01f352();
                    init_thread_module_egl_tasks();
                    vm_func_0270de();
                    vm_func_02a03e();
                    vm_func_02bc84();
                    init_runtime_sampling_tasks();
                    init_suspicious_mapping_task();
                    vm_func_0335b7();
                }
            }
        }
    }
    return;
}
