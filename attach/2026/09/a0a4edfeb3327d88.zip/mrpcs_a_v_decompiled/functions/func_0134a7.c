uint64_t vm_func_0134a7(uint64_t arg0, uint64_t arg1) {
    struct { union { uint64_t word_00; struct { uint32_t field_00; uint32_t field_04; }; uint8_t byte_00[8]; }; union { uint8_t tail_08[12]; struct { uint32_t field_08; uint32_t field_0c; uint32_t field_10; }; }; } record20_048;
    if (((uint32_t)(arg1)) < 0x12c) {
        result = 0x0;
    } else {
        if (((uint32_t)(arg1)) < 0x8000) {
            local_2c = 0x1;
            local_30 = arg0;
            src_38 = vm_func_01336e(arg0);
            local_40 = vm_func_0133b0(local_30);
            while (src_38 != local_40) {
                memcpy_checked(&record20_048, src_38, 0x14);
                if ((record20_048.word_00 & 0x2) != 0x0) {
                    if (record20_048.field_04 != arg1) {
                        if (vm_func_0133f6(arg1, record20_048.field_04) & 0x1) {
                            local_2c = (local_2c + 0x1);
                        }
                    }
                }
                src_38 = (src_38 + 0x14);
                continue;
            }
            if (local_2c != 0x1) {
                result = local_2c;
            } else {
                if (!(vm_func_0133f6(arg1, arg1) & 0x1)) {
                    result = 0x0;
                } else {
                    result = 0x1;
                }
            }
        } else {
            result = 0x0;
            return result;
        }
    }
    return result;
}
