void vm_func_00bef3(uint64_t arg0, uint64_t arg1, uint64_t arg2, uint64_t arg3) {
    vm_func_0036a7(arg0, arg1, arg2, arg3);
    return;
}
