uint64_t vm_func_009c32(uint64_t arg0, uint64_t arg1) {
    result = vm_func_00330c(arg0, arg1);
    return result;
}
