void vm_func_00bd8b(uint64_t arg0, uint64_t arg1) {
    local_10 = vm_func_003541(arg0, arg1);
    return;
}
