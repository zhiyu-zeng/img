uint64_t vm_func_016fa4(uint64_t arg0) {
    tmp_016fec = vm_func_0174c1(arg0);
    return (tmp_016fec - vm_func_017507(arg0)) >> 0x4;
}
