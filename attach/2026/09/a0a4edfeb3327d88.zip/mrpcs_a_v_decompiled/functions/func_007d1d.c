uint64_t vm_func_007d1d(uint64_t arg0, uint64_t arg1) {
    local_20 = arg1;
    while (local_20 != 0x0) {
        if (!(tree_is_left_child(arg0, local_20) & 0x1)) {
            local_20 = *(uint64_t *)(local_20);
            continue;
        } else {
            result = *(uint64_t *)(local_20);
            goto loc_007e49;
        }
    }
    result = 0x0;
    loc_007e49:
    return result;
}
