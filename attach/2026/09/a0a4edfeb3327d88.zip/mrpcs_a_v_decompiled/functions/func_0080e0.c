void vm_func_0080e0(uint64_t arg0, const void* arg1) {
    vm_func_00808e(arg0, vm_func_008172(arg1, *(uint64_t *)(arg1)));
    return;
}
