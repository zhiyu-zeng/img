void vm_func_012ddb(uint64_t arg0, uint8_t* arg1, uint8_t* arg2, uint64_t arg3) {
    local_30 = (arg0 * 0x186a0);
    while (((uint32_t)(((arg0 * 0x186a0) + 0x270f))) >= ((uint32_t)(local_30))) {
        vm_func_01279c(local_30, arg1, arg2, arg3);
        local_30 = (local_30 + 0x1);
        continue;
    }
    set_context_offset(0x1);
    local_34 = ((arg0 * 0x186a0) + 0x2710);
    while (((uint32_t)(((arg0 * 0x186a0) + 0x4e1f))) >= ((uint32_t)(local_34))) {
        if (vm_func_01279c(local_34, arg1, arg2, arg3) & 0x1) {
            vm_func_01279c((local_34 + 0x2710), arg1, arg2, arg3);
        }
        local_34 = (local_34 + 0x1);
        continue;
    }
    set_context_offset(0x1);
    local_38 = ((arg0 * 0x186a0) + 0x15f90);
    while (((uint32_t)(((arg0 * 0x186a0) + 0x1869f))) >= ((uint32_t)(local_38))) {
        vm_func_01279c(local_38, arg1, arg2, arg3);
        local_38 = (local_38 + 0x1);
        continue;
    }
    set_context_offset(0x1);
    return;
}
