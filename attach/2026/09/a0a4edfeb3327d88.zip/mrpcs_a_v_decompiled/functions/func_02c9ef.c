void vm_func_02c9ef(void) {
    VmProcMapsLine maps_line;
    uint8_t* stack_buf_068 = (uint8_t*)(fp + 0x68); /* observed >= 0x400 bytes */
    g_37d0 = 0x0;
    maps_file_60 = fopen("/proc/self/maps", "r");
    if (maps_file_60 == 0x0) {
        g_37d0 = 0xffffffffffffffff;
    } else {
        local_888 = "rwx";
        local_890 = 0x0;
        local_8a0 = 0x1;
        ptr_898 = &g_37d4;
        while (true) {
            if (fgets(stack_buf_068, 0x400, maps_file_60) == 0x0) break;
            maps_line.start = 0x0;
            maps_line.end = 0x0;
            memset(maps_line.perms, 0x0, 0x5);
            memset(maps_line.path, 0x0, 0x400);
            call_native_n(g_37a0, stack_buf_068, "%llx-%llx %s %*s %*s %*s %s", &maps_line.start, &maps_line.end, maps_line.perms, maps_line.path);
            if (call_native_n(g_3790, maps_line.path, "/libanogs.so") != 0x0) {
                g_37d0 = (g_37d0 + 0x1);
                if (call_native_n(g_3790, maps_line.perms, local_888) != 0x0) {
                    local_87d = local_890;
                    index_880 = 0x0;
                    while (((uint64_t)((int64_t)(index_880))) <= 0x63) {
                        if (*(uint64_t *)(((int64_t)(index_880) << 0x4) + &g_3120) != 0x0) {
                            if (call_native_n(g_3790, stack_buf_068, *(uint64_t *)(((int64_t)(index_880) << 0x4) + &g_3120)) == 0x0) {
                                index_880 = (index_880 + 0x1);
                                continue;
                            } else {
                                if ((maps_line.end - maps_line.start) != (int64_t)(*(uint32_t *)(((int64_t)(index_880) << 0x4) + &g_3128))) {
                                    index_880 = (index_880 + 0x1);
                                    continue;
                                } else {
                                    local_87d = local_8a0;
                                    break;
                                }
                            }
                        }
                    }
                    loc_02cebd:
                    if (!(local_87d & 0x1)) {
                        *(uint32_t *)(ptr_898) = (*(uint32_t *)(ptr_898) + 0x1);
                        continue;
                    }
                }
            }
        }
        fclose(maps_file_60);
    }
    return;
}
