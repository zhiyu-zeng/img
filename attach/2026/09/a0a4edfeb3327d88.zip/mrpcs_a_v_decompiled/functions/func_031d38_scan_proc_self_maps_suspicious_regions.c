void scan_proc_self_maps_suspicious_regions(void) {
    VmProcMapsLine maps_line;
    uint8_t* stack_buf_070 = (uint8_t*)(fp + 0x70); /* observed >= 0x400 bytes */
    memset(&suspicious_map_records, 0x0, 0x90);
    index_60 = 0x0;
    maps_file_68 = fopen("/proc/self/maps", "r");
    if (maps_file_68 != 0x0) {
        local_8b0 = 0x390;
        ptr_8c0 = &noaccess_resident_map_count;
        local_898 = &suspicious_map_records[0].reason;
        local_8c8 = 0x1;
        local_8a0 = &suspicious_map_records[0].aux0;
        local_8a8 = &suspicious_map_records[0].aux1;
        local_8b4 = 0x52a;
        while (true) {
            if (fgets(stack_buf_070, 0x400, maps_file_68) == 0x0) break;
            if (((uint32_t)(index_60)) < 0x6) {
                maps_line.start = 0x0;
                maps_line.end = 0x0;
                memset(maps_line.perms, 0x0, 0x5);
                memset(maps_line.path, 0x0, 0x400);
                call_native_n(fn_sscanf_maps, stack_buf_070, "%llx-%llx %s %*s %*s %*s %s", &maps_line.start, &maps_line.end, maps_line.perms, maps_line.path);
                if (strcmp(maps_line.perms, "---p") != 0x0) {
                    match_ptr_032407 = strstr(maps_line.path, "shadowhook-enter");
                    if (match_ptr_032407 != 0x0) {
                        shadowhook_map_count = (shadowhook_map_count + 0x1);
                        suspicious_map_records[index_60].span = (maps_line.end - maps_line.start);
                        suspicious_map_records[index_60].reason = 0x7;
                        suspicious_map_records[index_60].aux0 = (uint32_t)(maps_line.start >> 32);
                        suspicious_map_records[index_60].aux1 = maps_line.start;
                        suspicious_map_records[index_60].start_hi = 0x0;
                        suspicious_map_records[index_60].start_lo = 0x0;
                        index_60 = (index_60 + 0x1);
                    }
                    if (strcmp(maps_line.perms, "rwxp") == 0x0) {
                        if (strstr(maps_line.path, "anon:LMA") != 0x0) {
                            rwx_anon_lma_count = (rwx_anon_lma_count + 0x1);
                            suspicious_map_records[index_60].span = (maps_line.end - maps_line.start);
                            suspicious_map_records[index_60].reason = 0x7;
                            suspicious_map_records[index_60].aux0 = (uint32_t)(maps_line.start >> 32);
                            suspicious_map_records[index_60].aux1 = maps_line.start;
                            suspicious_map_records[index_60].start_hi = 0x0;
                            suspicious_map_records[index_60].start_lo = 0x0;
                            index_60 = (index_60 + 0x1);
                            continue;
                        }
                    }
                } else {
                    if (maps_line.path[0] != 0x0) {
                        match_ptr_032407 = strstr(maps_line.path, "shadowhook-enter");
                        goto loc_0323e2;
                    } else {
                        local_888 = (maps_line.end - maps_line.start);
                        if (((uint64_t)((maps_line.end - maps_line.start))) >= 0x1000) {
                            if (((uint64_t)(local_888)) < 0x200001) {
                                local_8d0 = &suspicious_map_records;
                                local_8d8 = 0x0;
                                local_890 = 0x0;
                                local_8e0 = maps_line.start;
                                local_8b8 = 0x5;
                                local_894 = hostcall_dynamic(local_8e0, (int64_t)(get_page_size_cached()), (fp + 0x890));
                                if (local_894 == 0x0) {
                                    if (local_890 & 0x1) {
                                        *(uint32_t *)(ptr_8c0) = (*(uint32_t *)(ptr_8c0) + 0x1);
                                        *(uint32_t *)((index_60 * 0x18) + local_8d0) = local_888;
                                        local_8e0 = (fp + 0x60);
                                        suspicious_map_records[index_60].reason = local_8c8;
                                        suspicious_map_records[index_60].aux0 = (uint32_t)(maps_line.start >> 32);
                                        ptr_8f0 = &maps_line.start;
                                        suspicious_map_records[index_60].aux1 = maps_line.start;
                                        native_result_03230c = hostcall_dynamic();
                                        local_8e8 = 0x4;
                                        process_vm_readv_single(native_result_03230c, &suspicious_map_records[index_60].start_hi, maps_line.start, 0x4);
                                        process_vm_readv_single(hostcall_dynamic(), ((*(uint32_t *)(local_8e0) * 0x18) + &g_3dac), (*(uint64_t *)(ptr_8f0) + 0x4), local_8e8);
                                        *(uint32_t *)(local_8e0) = (*(uint32_t *)(local_8e0) + 0x1);
                                    }
                                }
                                match_ptr_032407 = strstr(maps_line.path, "shadowhook-enter");
                                goto loc_0323e2;
                            }
                        }
                    }
                }
                continue;
            }
        }
        fclose(maps_file_68);
    }
    suspicious_record_count = index_60;
    return;
}
