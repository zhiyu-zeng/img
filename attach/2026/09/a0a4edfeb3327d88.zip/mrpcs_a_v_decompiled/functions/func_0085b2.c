uint64_t vm_func_0085b2(uint64_t arg0, uint64_t arg1, uint64_t arg2) {
    heap_ptr_28 = heap_alloc(0x30);
    if (heap_ptr_28 != 0x0) {
        tmp_008663 = vm_func_009408(0x30, local_40, heap_ptr_28);
        rb_node_init(tmp_008663, arg1, arg2);
        local_38 = tmp_008663;
        result = tmp_008663;
    } else {
        result = 0x0;
    }
    return result;
}
