void vm_func_00cd36(const void* arg0) {
    return;
}
