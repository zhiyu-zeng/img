uint64_t vm_func_020fa8(uint64_t arg0, uint64_t arg1) {
    local_c = 0x0;
    index_18 = 0x0;
    while (((uint32_t)(index_18)) < ((uint32_t)(arg1))) {
        local_c = (local_c ^ (((index_18 & 0x1) != 0x0) ? ((((local_c << 0xb) | *(uint8_t *)(arg0 + index_18)) ^ (local_c >> 0x5)) ^ 0xffffffff) : (((local_c << 0x7) ^ *(uint8_t *)(arg0 + index_18)) ^ (local_c >> 0x3))));
        index_18 = (index_18 + 0x1);
        continue;
    }
    return (local_c & 0x7fffffff);
}
