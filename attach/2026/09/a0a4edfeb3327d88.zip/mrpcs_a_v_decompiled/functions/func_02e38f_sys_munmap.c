void sys_munmap(uint64_t arg0, uint64_t arg1) {
    if (g_3828 == 0x0) {
        g_3828 = build_aarch64_syscall_stub(0xd7);
    }
    if (g_3828 != 0x0) {
        local_8 = call_native_n(g_3828, arg0, arg1);
    } else {
        local_8 = 0xffffffffffffffff;
    }
    return;
}
