uint64_t vm_func_02f918(uint64_t arg0, const void* arg1) {
    local_18 = *(uint64_t *)(arg1 + 0x8);
    if (*(uint64_t *)(arg1 + 0x8) != 0x0) {
        local_20 = (arg0 + 0x108cdcb4);
        local_28 = call_native_n((arg0 + 0x108cdcb4));
        if (local_28 != 0x0) {
            local_30 = (arg0 + 0x108cc130);
            result = call_native_n((arg0 + 0x108cc130), local_18, local_28);
        } else {
            result = 0x0;
        }
    } else {
        result = 0x0;
    }
    return result;
}
