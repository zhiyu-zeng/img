uint64_t vm_func_023125(const void* arg0, uint64_t arg1) {
    if (((uint64_t)(*(uint64_t *)(arg0 + 0x8))) < ((uint64_t)(*(uint64_t *)(arg0 + 0x10)))) {
        *(uint64_t *)(*(uint64_t *)(arg0) + (*(uint64_t *)(arg0 + 0x8) << 0x3)) = arg1;
        *(uint64_t *)(arg0 + 0x8) = (*(uint64_t *)(arg0 + 0x8) + 0x1);
        result = 0x0;
    } else {
        *(uint64_t *)(arg0 + 0x10) = (*(uint64_t *)(arg0 + 0x10) << 0x1);
        dst_18 = 0x0;
        if (*(uint64_t *)(arg0) != (arg0 + 0x18)) {
            dst_18 = realloc(*(uint64_t *)(arg0), (*(uint64_t *)(arg0 + 0x10) << 0x3));
            if (dst_18 != 0x0) {
                *(uint64_t *)(arg0) = dst_18;
                *(uint64_t *)(*(uint64_t *)(arg0) + (*(uint64_t *)(arg0 + 0x8) << 0x3)) = arg1;
                *(uint64_t *)(arg0 + 0x8) = (*(uint64_t *)(arg0 + 0x8) + 0x1);
                result = 0x0;
                return result;
            } else {
                free(*(uint64_t *)(arg0));
                result = 0xffffffff;
            }
        } else {
            dst_18 = malloc((*(uint64_t *)(arg0 + 0x10) << 0x3));
            if (dst_18 != 0x0) {
                memcpy_checked(dst_18, (arg0 + 0x18), 0x40);
                *(uint64_t *)(arg0) = dst_18;
                *(uint64_t *)(*(uint64_t *)(arg0) + (*(uint64_t *)(arg0 + 0x8) << 0x3)) = arg1;
                *(uint64_t *)(arg0 + 0x8) = (*(uint64_t *)(arg0 + 0x8) + 0x1);
                result = 0x0;
                return result;
            } else {
                result = 0xffffffff;
            }
        }
    }
    return result;
}
