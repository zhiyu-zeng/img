void init_module_base_cache(void) {
    module_base_libUE4 = find_module_base_by_name("libUE4.so");
    module_base_libanogs = find_module_base_by_name("libanogs.so");
    module_base_libanort = find_module_base_by_name("libanort.so");
    return;
}
