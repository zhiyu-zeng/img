void vm_func_01ffdb(void) {
    VmProcMapsLine maps_line;
    uint8_t* stack_buf_069 = (uint8_t*)(fp + 0x69); /* observed >= 0x400 bytes */
    g_2280 = malloc(((int64_t)(*(uint32_t *)("d")) << 0x3));
    maps_file_60 = fopen("/proc/self/maps", "r");
    if (maps_file_60 != 0x0) {
        local_68 = 0x0;
        ptr_888 = &g_2200;
        local_890 = 0x51d;
        local_898 = 0x1;
        while (true) {
            if (fgets(stack_buf_069, 0x400, maps_file_60) == 0x0) break;
            maps_line.start = 0x0;
            maps_line.end = 0x0;
            memset(maps_line.perms, 0x0, 0x5);
            memset(maps_line.path, 0x0, 0x400);
            call_native_n(g_21f0, stack_buf_069, "%llx-%llx %s %*s %*s %*s %s", &maps_line.start, &maps_line.end, maps_line.perms, maps_line.path);
            if (call_native_n(g_21e0, maps_line.perms, "--x") != 0x0) {
                *(uint64_t *)(g_2280 + ((int64_t)(g_22bc) << 0x3)) = call_native_n(*(uint64_t *)(ptr_888), maps_line.path);
                g_22bc = (g_22bc + 0x1);
                if (((int32_t)((g_22bc + 0x1))) >= ((int32_t)(*(uint32_t *)("d")))) {
                    g_2280 = hostcall_dynamic(g_2280, ((int64_t)(*(uint32_t *)("d")) << 0x4));
                    *(uint32_t *)("d") = (*(uint32_t *)("d") << local_898);
                    continue;
                }
            }
        }
        fclose(maps_file_60);
    }
    return;
}
