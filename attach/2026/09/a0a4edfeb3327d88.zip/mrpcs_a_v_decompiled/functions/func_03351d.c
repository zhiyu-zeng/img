void vm_func_03351d(uint64_t arg0, uint64_t arg1, uint64_t arg2, uint64_t arg3) {
    call_native_n(g_3f80, fp, arg1, arg2, arg3);
    return;
}
