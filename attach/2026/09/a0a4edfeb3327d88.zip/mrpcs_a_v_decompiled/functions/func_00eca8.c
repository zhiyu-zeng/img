uint64_t vm_func_00eca8(uint64_t arg0, uint64_t arg1, uint64_t arg2) {
    ptr_28 = vm_func_00fb8d(arg2);
    if (ptr_28 != 0x0) {
        vm_func_00f149((fp + 0x30), ptr_28);
        ptr_38 = merge_record_lists_0x38((arg0 + 0xffffffffffffffe0), (int64_t)((arg1 + 0x20)));
        vm_func_00f149((fp + 0x40), ptr_38);
        if (ptr_38 != 0x0) {
            heap_ptr_50 = malloc((((*(uint64_t *)(ptr_28) + *(uint64_t *)(ptr_38)) * 0x38) + 0x40));
            if (heap_ptr_50 != 0x0) {
                *(uint64_t *)(heap_ptr_50) = (*(uint64_t *)(ptr_28) + *(uint64_t *)(ptr_38));
                index_58 = 0x0;
                while (((uint64_t)((int64_t)(index_58))) < ((uint64_t)(*(uint64_t *)(ptr_28)))) {
                    memcpy_checked(((heap_ptr_50 + ((int64_t)(index_58) * 0x38)) + 0x8), ((ptr_28 + ((int64_t)(index_58) * 0x38)) + 0x8), 0x38);
                    index_58 = (index_58 + 0x1);
                    continue;
                }
                index_5c = 0x0;
                while (((uint64_t)((int64_t)(index_5c))) < ((uint64_t)(*(uint64_t *)(ptr_38)))) {
                    memcpy_checked(((heap_ptr_50 + (((int64_t)(index_5c) + *(uint64_t *)(ptr_28)) * 0x38)) + 0x8), ((ptr_38 + ((int64_t)(index_5c) * 0x38)) + 0x8), 0x38);
                    index_5c = (index_5c + 0x1);
                    continue;
                }
                result = heap_ptr_50;
                local_48 = 0x1;
            } else {
                result = 0x0;
                local_48 = 0x1;
            }
        } else {
            result = 0x0;
            local_48 = 0x1;
        }
        vm_func_00f19b((fp + 0x40));
        vm_func_00f19b((fp + 0x30));
    } else {
        result = 0x0;
    }
    return result;
}
