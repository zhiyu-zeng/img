void vm_func_0107ec(void* arg0) {
    local_28 = vm_func_0100f2(arg0);
    local_30 = ((local_28 == 0x0) ? 0x1 : (local_28 << 0x1));
    local_38 = vm_func_0103de(arg0, ((local_28 == 0x0) ? 0x1 : (local_28 << 0x1)));
    dst_40 = local_38;
    src_48 = vm_func_010a3f(arg0);
    while (true) {
        if (src_48 == vm_func_010a81(arg0)) break;
        memcpy_checked(dst_40, src_48, 0x38);
        dst_40 = (dst_40 + 0x38);
        src_48 = (src_48 + 0x38);
        continue;
    }
    vm_func_010ac7(arg0);
    *(uint64_t *)(arg0) = local_38;
    *(uint64_t *)(arg0 + 0x8) = dst_40;
    *(uint64_t *)(arg0 + 0x10) = (local_38 + (local_30 * 0x38));
    return;
}
