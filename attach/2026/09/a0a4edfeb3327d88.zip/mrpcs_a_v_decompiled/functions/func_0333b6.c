void vm_func_0333b6(VmU64Pair* arg0, void* arg1, uint64_t arg2) {
    *(uint8_t *)(arg1) = 0x0;
    if (*(uint32_t *)(arg0 + 0x8) == 0x21) {
        if (*(uint64_t *)(arg0) != 0x0) {
            vm_func_03351d(arg1, arg2, *(uint64_t *)(arg0), *(uint32_t *)(arg0 + 0x8));
            *(uint8_t *)(arg1 + (int64_t)((arg2 + 0xffffffff))) = 0x0;
        }
    }
    return;
}
