void vm_func_015b6e(void* arg0) {
    *(uint64_t *)(arg0) = 0x0;
    *(uint64_t *)(arg0 + 0x8) = 0x0;
    *(uint64_t *)(arg0 + 0x10) = 0x0;
    ptr_015c02 = vm_func_0160b3(arg0, 0x20);
    *(uint64_t *)(arg0) = ptr_015c02;
    *(uint64_t *)(arg0 + 0x8) = ptr_015c02;
    *(uint64_t *)(arg0 + 0x10) = (ptr_015c02 + (0x20 * 0x14));
    return;
}
