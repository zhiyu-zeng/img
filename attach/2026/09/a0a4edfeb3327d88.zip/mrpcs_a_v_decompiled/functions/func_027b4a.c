void vm_func_027b4a(void) {
    VmProcMapsLine maps_line;
    uint8_t* stack_buf_071 = (uint8_t*)(fp + 0x71); /* observed >= 0x400 bytes */
    fn_ptr_60 = resolve_symbol("libc.so", "getauxval");
    g_2fb8 = call_native_n(fn_ptr_60, 0x7);
    maps_file_68 = fopen("/proc/self/maps", "r");
    if (maps_file_68 != 0x0) {
        local_70 = 0x0;
        while (true) {
            if (fgets(stack_buf_071, 0x400, maps_file_68) == 0x0) break;
            maps_line.start = 0x0;
            maps_line.end = 0x0;
            memset(maps_line.perms, 0x0, 0x5);
            memset(maps_line.path, 0x0, 0x400);
            call_native_n(g_2ec8, stack_buf_071, "%llx-%llx %s %*s %*s %*s %s", &maps_line.start, &maps_line.end, maps_line.perms, maps_line.path);
            if (call_native_n(g_2eb8, maps_line.path, "/linker") != 0x0) {
                if (!(local_70 & 0x1)) {
                    if (maps_line.start == g_2fb8) {
                        g_2fb8 = maps_line.start;
                        local_70 = 0x1;
                    } else {
                        if (g_2fb8 == 0x0) {
                            g_2fb8 = maps_line.start;
                            local_70 = 0x1;
                            goto loc_027e8c;
                        }
                    }
                }
                if (local_70 & 0x1) {
                    g_2fc8 = maps_line.end;
                    continue;
                }
            }
        }
        fclose(maps_file_68);
    }
    return;
}
