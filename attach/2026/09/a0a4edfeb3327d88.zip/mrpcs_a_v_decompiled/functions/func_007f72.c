void vm_func_007f72(void* arg0, uint64_t arg1) {
    if (arg1 != arg0) {
        *(uint64_t *)(arg0) = *(uint64_t *)(arg1);
    }
    return;
}
