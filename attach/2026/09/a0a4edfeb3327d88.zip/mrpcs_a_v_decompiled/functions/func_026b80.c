void vm_func_026b80(void* arg0, uint64_t arg1, uint64_t arg2, uint64_t arg3) {
    *(uint64_t *)(arg0) = arg1;
    *(uint64_t *)(arg0 + 0x8) = arg2;
    *(uint64_t *)(arg0 + 0x10) = 0x0;
    *(uint64_t *)(arg0 + 0x18) = arg3;
    return;
}
