void vm_func_023988(uint64_t arg0, uint64_t arg1) {
    local_10 = arg1;
    while (true) {
        loc_023a2a:
        if (!((local_10 != 0x0) ? 0x0 : ((((*(uint64_t *)(local_10)) != (0x0))) ? 1 : 0) & 0x1)) {
            if (((int64_t)(*(uint64_t *)(local_10))) < 18) {
                if (((int64_t)(*(uint64_t *)(local_10))) < 6) {
                    if (((int64_t)(*(uint64_t *)(local_10))) < 4) {
                        if (*(uint64_t *)(local_10) == 0x2) {
                            *(uint64_t *)(arg0 + 0x28) = ((*(uint64_t *)(local_10 + 0x8)) / (uint64_t)(0x18));
                        }
                    } else {
                        if (((int64_t)(*(uint64_t *)(local_10))) < 5) {
                            *(uint32_t *)(arg0 + 0x68) = *(uint32_t *)(*(uint64_t *)(arg0 + 0x8) + *(uint64_t *)(local_10 + 0x8));
                            *(uint32_t *)(arg0 + 0x78) = *(uint32_t *)((*(uint64_t *)(arg0 + 0x8) + *(uint64_t *)(local_10 + 0x8)) + 0x4);
                            *(uint64_t *)(arg0 + 0x60) = ((*(uint64_t *)(arg0 + 0x8) + *(uint64_t *)(local_10 + 0x8)) + 0x8);
                            *(uint64_t *)(arg0 + 0x70) = (*(uint64_t *)(arg0 + 0x60) + (*(uint32_t *)(arg0 + 0x68) << 0x2));
                        } else {
                            *(uint64_t *)(arg0 + 0x58) = (*(uint64_t *)(arg0 + 0x8) + *(uint64_t *)(local_10 + 0x8));
                        }
                    }
                } else {
                    if (((int64_t)(*(uint64_t *)(local_10))) < 8) {
                        if (((int64_t)(*(uint64_t *)(local_10))) < 7) {
                            *(uint64_t *)(arg0 + 0x50) = (*(uint64_t *)(arg0 + 0x8) + *(uint64_t *)(local_10 + 0x8));
                        } else {
                            *(uint64_t *)(arg0 + 0x30) = (*(uint64_t *)(arg0 + 0x8) + *(uint64_t *)(local_10 + 0x8));
                        }
                    } else {
                        if (((int64_t)(*(uint64_t *)(local_10))) > 16) {
                            *(uint64_t *)(arg0 + 0x30) = (*(uint64_t *)(arg0 + 0x8) + *(uint64_t *)(local_10 + 0x8));
                            local_10 = (local_10 + 0x10);
                            continue;
                        } else {
                            if (*(uint64_t *)(local_10) == 0x8) {
                                *(uint64_t *)(arg0 + 0x38) = ((*(uint64_t *)(local_10 + 0x8)) / (uint64_t)(0x18));
                            }
                        }
                    }
                }
            } else {
                if (((int64_t)(*(uint64_t *)(local_10))) < 1610612752) {
                    if (((int64_t)(*(uint64_t *)(local_10))) < 23) {
                        if (*(uint64_t *)(local_10) == 0x12) {
                            *(uint64_t *)(arg0 + 0x38) = ((*(uint64_t *)(local_10 + 0x8)) / (uint64_t)(0x18));
                            local_10 = (local_10 + 0x10);
                            continue;
                        }
                    } else {
                        if (((int64_t)(*(uint64_t *)(local_10))) > 1610612750) {
                            *(uint64_t *)(arg0 + 0x40) = (*(uint64_t *)(arg0 + 0x8) + *(uint64_t *)(local_10 + 0x8));
                        } else {
                            if (*(uint64_t *)(local_10) == 0x17) {
                                *(uint64_t *)(arg0 + 0x20) = (*(uint64_t *)(arg0 + 0x8) + *(uint64_t *)(local_10 + 0x8));
                            }
                        }
                    }
                } else {
                    if (((int64_t)(*(uint64_t *)(local_10))) < 1610612754) {
                        if (((int64_t)(*(uint64_t *)(local_10))) < 1610612753) {
                            *(uint64_t *)(arg0 + 0x48) = *(uint64_t *)(local_10 + 0x8);
                        } else {
                            *(uint64_t *)(arg0 + 0x40) = (*(uint64_t *)(arg0 + 0x8) + *(uint64_t *)(local_10 + 0x8));
                            local_10 = (local_10 + 0x10);
                            continue;
                        }
                    } else {
                        if (((int64_t)(*(uint64_t *)(local_10))) < 1879047925) {
                            if (*(uint64_t *)(local_10) == 0x60000012) {
                                *(uint64_t *)(arg0 + 0x48) = *(uint64_t *)(local_10 + 0x8);
                                local_10 = (local_10 + 0x10);
                                continue;
                            }
                        } else {
                            if (*(uint64_t *)(local_10) == 0x6ffffef5) {
                                *(uint32_t *)(arg0 + 0x88) = *(uint32_t *)(*(uint64_t *)(arg0 + 0x8) + *(uint64_t *)(local_10 + 0x8));
                                *(uint32_t *)(arg0 + 0x98) = *(uint32_t *)((*(uint64_t *)(arg0 + 0x8) + *(uint64_t *)(local_10 + 0x8)) + 0x4);
                                *(uint32_t *)(arg0 + 0xa8) = *(uint32_t *)((*(uint64_t *)(arg0 + 0x8) + *(uint64_t *)(local_10 + 0x8)) + 0x8);
                                *(uint32_t *)(arg0 + 0xac) = *(uint32_t *)((*(uint64_t *)(arg0 + 0x8) + *(uint64_t *)(local_10 + 0x8)) + 0xc);
                                *(uint64_t *)(arg0 + 0xa0) = ((*(uint64_t *)(arg0 + 0x8) + *(uint64_t *)(local_10 + 0x8)) + 0x10);
                                *(uint64_t *)(arg0 + 0x80) = (*(uint64_t *)(arg0 + 0xa0) + (*(uint32_t *)(arg0 + 0xa8) << 0x3));
                                *(uint64_t *)(arg0 + 0x90) = (*(uint64_t *)(arg0 + 0x80) + (*(uint32_t *)(arg0 + 0x88) << 0x2));
                            }
                        }
                    }
                }
            }
            local_10 = (local_10 + 0x10);
            continue;
        }
        break;
    }
    if (*(uint64_t *)(arg0 + 0x40) != 0x0) {
        local_18 = *(uint64_t *)(arg0 + 0x40);
        if (((uint64_t)(*(uint64_t *)(arg0 + 0x48))) < 0x4) {
            *(uint64_t *)(arg0 + 0x40) = 0x0;
            *(uint64_t *)(arg0 + 0x48) = 0x0;
        } else {
            if (*(uint8_t *)(local_18) != 0x41) {
                *(uint64_t *)(arg0 + 0x40) = 0x0;
                *(uint64_t *)(arg0 + 0x48) = 0x0;
                return;
            } else {
                if (*(uint8_t *)(local_18 + 0x1) != 0x50) {
                    *(uint64_t *)(arg0 + 0x40) = 0x0;
                    *(uint64_t *)(arg0 + 0x48) = 0x0;
                    return;
                } else {
                    if (*(uint8_t *)(local_18 + 0x2) != 0x53) {
                        *(uint64_t *)(arg0 + 0x40) = 0x0;
                        *(uint64_t *)(arg0 + 0x48) = 0x0;
                        return;
                    } else {
                        if (*(uint8_t *)(local_18 + 0x3) == 0x32) {
                            *(uint64_t *)(arg0 + 0x40) = (*(uint64_t *)(arg0 + 0x40) + 0x4);
                            *(uint64_t *)(arg0 + 0x48) = (*(uint64_t *)(arg0 + 0x48) + 0xfffffffffffffffc);
                        } else {
                            *(uint64_t *)(arg0 + 0x40) = 0x0;
                            *(uint64_t *)(arg0 + 0x48) = 0x0;
                            return;
                        }
                    }
                }
            }
        }
    }
    return;
}
