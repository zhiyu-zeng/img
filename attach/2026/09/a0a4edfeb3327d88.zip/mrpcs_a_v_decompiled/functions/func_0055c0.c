uint64_t vm_func_0055c0(const void* arg0) {
    return dispatch_registered_handler(0xe1, *(uint64_t *)(arg0), 0x0, 0x0);
}
