void vm_func_01a18b(void* arg0) {
    uint8_t* stack_buf_040 = (uint8_t*)(fp + 0x40); /* observed >= 0xc bytes */
    uint8_t* stack_buf_0c0 = (uint8_t*)(fp + 0xc0); /* observed >= 0x8 bytes */
    memset(stack_buf_040, 0x0, 0xc);
    if (*(uint64_t *)(arg0) == 0x0) {
        *(uint32_t *)(arg0 + 0xc) = 0x1;
    } else {
        if (((uint64_t)(*(uint64_t *)(arg0))) < 0x1000001) {
            *(uint32_t *)(arg0 + 0xc) = 0x1;
            return;
        } else {
            if (((int32_t)(*(uint32_t *)(arg0 + 0x8))) > 0) {
                if (((int32_t)(*(uint32_t *)(arg0 + 0x8))) < 4194305) {
                    *(uint32_t *)(arg0 + 0x10) = vm_func_019eb6(*(uint64_t *)(arg0), (int64_t)(*(uint32_t *)(arg0 + 0x8)));
                } else {
                    local_50 = (*(uint64_t *)(arg0) + (int64_t)(*(uint32_t *)(arg0 + 0x8)));
                    local_58 = *(uint64_t *)(arg0);
                    local_60 = ((*(uint64_t *)(arg0) + 0xfff) & 0xfffffffffffff000);
                    local_68 = (((*(uint64_t *)(arg0) + 0xfff) & 0xfffffffffffff000) - *(uint64_t *)(arg0));
                    local_70 = vm_func_019eb6(*(uint64_t *)(arg0), (((*(uint64_t *)(arg0) + 0xfff) & 0xfffffffffffff000) - *(uint64_t *)(arg0)));
                    if (local_70 != 0x0) {
                        local_78 = local_50;
                        local_80 = (local_50 & 0xfffffffffffff000);
                        local_88 = (local_50 & 0xfff);
                        local_90 = vm_func_019eb6((local_50 & 0xfffffffffffff000), (local_50 & 0xfff));
                        if (local_90 != 0x0) {
                            local_98 = local_60;
                            local_a0 = local_80;
                            local_a8 = (local_80 - local_60);
                            local_b0 = ((local_80 - local_60) >> 0x14);
                            local_b8 = ((local_80 - local_60) & 0xfffff);
                            memset(stack_buf_0c0, 0x0, 0x8);
                            local_c8 = 0x0;
                            index_cc = 0x0;
                            while (((uint64_t)((int64_t)(index_cc))) < ((uint64_t)(local_b0))) {
                                local_d0 = vm_func_019eb6((local_98 + (int64_t)((index_cc << 0x14))), 0x100000);
                                if (local_d0 != 0x0) {
                                    local_c0 = local_d0;
                                    *(uint32_t *)(stack_buf_0c0 + 0x4) = local_c8;
                                    local_c8 = vm_func_01a037(stack_buf_0c0, 0x8);
                                    if (((int64_t)(index_cc) % (int64_t)(0x14)) == 0x13) {
                                        set_context_offset(0x1);
                                    }
                                    index_cc = (index_cc + 0x1);
                                    continue;
                                } else {
                                    *(uint64_t *)(arg0 + 0xc) = 0x3;
                                    goto loc_01a7c5;
                                }
                            }
                            local_d4 = vm_func_019eb6((local_a0 - local_b8), local_b8);
                            if (local_d4 != 0x0) {
                                local_c0 = local_d4;
                                *(uint32_t *)(stack_buf_0c0 + 0x4) = local_c8;
                                local_c8 = vm_func_01a037(stack_buf_0c0, 0x8);
                                local_40 = local_70;
                                *(uint32_t *)(stack_buf_040 + 0x4) = local_c8;
                                *(uint32_t *)(stack_buf_040 + 0x8) = local_90;
                                *(uint32_t *)(arg0 + 0x10) = vm_func_01a037(stack_buf_040, 0xc);
                            } else {
                                *(uint64_t *)(arg0 + 0xc) = 0x3;
                            }
                        } else {
                            if (local_88 == 0x0) {
                                goto loc_01a3e4;
                            } else {
                                *(uint64_t *)(arg0 + 0xc) = 0x3;
                            }
                        }
                    } else {
                        if (local_68 == 0x0) {
                            goto loc_01a35f;
                        } else {
                            *(uint64_t *)(arg0 + 0xc) = 0x3;
                        }
                    }
                }
            } else {
                *(uint32_t *)(arg0 + 0xc) = 0x1;
                return;
            }
        }
    }
    loc_01a7c5:
    return;
}
