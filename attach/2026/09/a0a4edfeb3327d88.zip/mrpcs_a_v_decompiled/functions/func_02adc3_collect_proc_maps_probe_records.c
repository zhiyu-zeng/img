void collect_proc_maps_probe_records(void) {
    VmProcMapsLine maps_line;
    uint8_t* stack_buf_068 = (uint8_t*)(fp + 0x68); /* observed >= 0x400 bytes */
    maps_file_60 = fopen("/proc/self/maps", "r");
    if (maps_file_60 != 0x0) {
        local_884 = 0x1000;
        local_890 = &map_probe_records[0].key_tail.word[0];
        local_898 = 0x656b6166;
        local_8a0 = &map_probe_records[0].key_tail.word[1];
        local_8a8 = &map_probe_records[0].key_tail.word[2];
        local_8b0 = &map_probe_records[0].range_word;
        local_8b8 = &map_probe_records[0].address_word;
        local_888 = 0x376;
        while (true) {
            if (fgets(stack_buf_068, 0x400, maps_file_60) == 0x0) break;
            maps_line.start = 0x0;
            maps_line.end = 0x0;
            memset(maps_line.perms, 0x0, 0x5);
            memset(maps_line.path, 0x0, 0x400);
            call_native_n(g_3018, stack_buf_068, "%llx-%llx %s %*s %*s %*s %s", &maps_line.start, &maps_line.end, maps_line.perms, maps_line.path);
            if (hostcall_dynamic(maps_line.path, "[anon:objects_external_alloc]") != 0x0) {
                continue;
            } else {
                local_880 = vm_func_02b304(maps_line.start, local_884);
                if (local_880 == 0x306c25b5) {
                    continue;
                } else {
                    map_probe_records[map_probe_record_count].key_tail.word[0] = local_898;
                    map_probe_records[map_probe_record_count].key_tail.word[1] = 0x0;
                    map_probe_records[map_probe_record_count].key_tail.word[2] = 0x0;
                    map_probe_records[map_probe_record_count].range_word = (uint32_t)(maps_line.start >> 32);
                    map_probe_records[map_probe_record_count].address_word = maps_line.start;
                    map_probe_records[map_probe_record_count].classifier = local_880;
                    map_probe_record_count = (map_probe_record_count + 0x1);
                    if (((int32_t)((map_probe_record_count + 0x1))) < 4) {
                        continue;
                    }
                }
            }
        }
        fclose(maps_file_60);
    }
    return;
}
