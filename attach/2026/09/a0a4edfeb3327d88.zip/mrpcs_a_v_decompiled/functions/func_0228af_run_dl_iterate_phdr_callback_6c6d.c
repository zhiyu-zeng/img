void run_dl_iterate_phdr_callback_6c6d(void) {
    dl_iterate_phdr(get_vm_callback_thunk(0x6c6d), 0x0);
    return;
}
