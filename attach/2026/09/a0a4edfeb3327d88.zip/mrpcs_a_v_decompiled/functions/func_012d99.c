uint64_t vm_func_012d99(const void* arg0) {
    return *(uint64_t *)(arg0);
}
