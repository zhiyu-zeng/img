uint64_t vm_func_0235fe(uint64_t arg0) {
    return vm_func_02358a(((arg0 + vm_func_02348e()) + 0xffffffffffffffff));
}
