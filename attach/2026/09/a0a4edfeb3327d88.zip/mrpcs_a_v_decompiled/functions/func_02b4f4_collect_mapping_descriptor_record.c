void collect_mapping_descriptor_record(uint64_t arg0) {
    VmU64Pair u64_pair_060;
    uint8_t* stack_buf_07c = (uint8_t*)(fp + 0x7c); /* observed >= 0xd bytes */
    local_38 = 0xffffffffffffffff;
    index_40 = 0x0;
    while (((uint64_t)(index_40)) < ((uint64_t)(*(uint16_t *)(arg0 + 0x18)))) {
        local_48 = (*(uint64_t *)(arg0 + 0x10) + (index_40 * 0x38));
        if (*(uint32_t *)(*(uint64_t *)(arg0 + 0x10) + (index_40 * 0x38)) == 0x1) {
            if (((uint64_t)(local_38)) > ((uint64_t)(*(uint64_t *)(local_48 + 0x10)))) {
                local_38 = *(uint64_t *)(local_48 + 0x10);
            }
        }
        index_40 = (index_40 + 0x1);
        continue;
    }
    if (local_38 != 0xffffffffffffffff) {
        local_50 = (*(uint64_t *)(arg0) + local_38);
        index_58 = 0x0;
        while (true) {
            if (((uint64_t)(index_58)) >= ((uint64_t)(vm_func_0288cd(g_30e8)))) break;
            memcpy_checked(&u64_pair_060, vm_func_029e3c(g_30e8, index_58), 0x10);
            if (((uint64_t)(local_50)) < ((uint64_t)(u64_pair_060.first))) {
                index_58 = (index_58 + 0x1);
                continue;
            } else {
                if (((uint64_t)(local_50)) >= ((uint64_t)(u64_pair_060.second))) {
                    index_58 = (index_58 + 0x1);
                    continue;
                } else {
                    local_70 = vm_func_02b304(local_50, 0x1000);
                    length_74 = strlen(*(uint64_t *)(arg0 + 0x8));
                    size_78 = ((((int32_t)(length_74)) < 13) ? length_74 : 0xc);
                    memset(stack_buf_07c, 0x0, 0xd);
                    strncpy(stack_buf_07c, ((*(uint64_t *)(arg0 + 0x8) + (int64_t)(length_74)) - (int64_t)(size_78)), (int64_t)(size_78));
                    local_89 = 0x0;
                    index_8c = 0x0;
                    while (((int32_t)(index_8c)) < ((int32_t)(map_probe_record_count))) {
                        if (map_probe_records[index_8c].key_tail.word[0] != local_7c) {
                            index_8c = (index_8c + 0x1);
                            continue;
                        } else {
                            if (map_probe_records[index_8c].key_tail.word[1] != *(uint32_t *)(stack_buf_07c + 0x4)) {
                                index_8c = (index_8c + 0x1);
                                continue;
                            } else {
                                if (map_probe_records[index_8c].key_tail.word[2] != *(uint32_t *)(stack_buf_07c + 0x8)) {
                                    index_8c = (index_8c + 0x1);
                                    continue;
                                } else {
                                    local_89 = 0x1;
                                    break;
                                }
                            }
                        }
                    }
                    loc_02bae0:
                    if (!(local_89 & 0x1)) {
                        map_probe_records[map_probe_record_count].key_tail.word[0] = local_7c;
                        map_probe_records[map_probe_record_count].key_tail.word[1] = *(uint32_t *)(stack_buf_07c + 0x4);
                        map_probe_records[map_probe_record_count].key_tail.word[2] = *(uint32_t *)(stack_buf_07c + 0x8);
                        map_probe_records[map_probe_record_count].range_word = *(uint32_t *)((fp + 0x50) | 0x4);
                        map_probe_records[map_probe_record_count].address_word = local_50;
                        map_probe_records[map_probe_record_count].classifier = local_70;
                        map_probe_record_count = (map_probe_record_count + 0x1);
                    }
                    break;
                }
            }
        }
        loc_02bc0e:
        local_28 = 0x0;
    } else {
        local_28 = 0x0;
    }
    return;
}
