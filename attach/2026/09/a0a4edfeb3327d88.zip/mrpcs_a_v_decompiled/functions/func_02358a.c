uint64_t vm_func_02358a(uint64_t arg0) {
    return (arg0 & (0x0 - vm_func_02348e()));
}
