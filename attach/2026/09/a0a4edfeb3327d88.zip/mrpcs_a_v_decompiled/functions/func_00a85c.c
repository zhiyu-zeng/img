uint64_t vm_func_00a85c(uint64_t arg0, uint64_t arg1, uint64_t arg2, uint64_t arg3) {
    uint8_t* stack_buf_018 = (uint8_t*)(fp + 0x18); /* observed >= 0x8 bytes */
    uint8_t* stack_buf_040 = (uint8_t*)(fp + 0x40); /* observed >= 0x8 bytes */
    memcpy_checked(stack_buf_040, &g_01d8, 0x8);
    local_48 = vm_func_009c32(arg0, arg1);
    if (local_48 == 0x0) {
        vm_func_006a7e(arg0);
        memcpy_checked(stack_buf_018, stack_buf_040, 0x8);
    } else {
        if (vm_func_006a36(arg0) == 0x0) {
            vm_call_reg(0x9628);
            vm_func_006ac6((fp + 0x50), local_48);
            result = vm_func_00aab1(arg0, local_48, arg2, arg3);
            vm_call_reg(0x7279);
        } else {
            vm_func_006a7e(arg0);
            memcpy_checked(stack_buf_018, stack_buf_040, 0x8);
            return result;
        }
    }
    return result;
}
