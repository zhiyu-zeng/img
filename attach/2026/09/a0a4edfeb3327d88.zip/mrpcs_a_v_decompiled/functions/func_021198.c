uint64_t vm_func_021198(uint64_t arg0, uint64_t arg1, uint64_t arg2) {
    index_30 = 0x0;
    while (((uint32_t)(index_30)) < ((uint32_t)(arg2))) {
        if (*(uint8_t *)(arg0 + index_30) == *(uint8_t *)(arg1 + index_30)) {
            index_30 = (index_30 + 0x1);
            continue;
        } else {
            result = index_30;
            goto loc_0212fc;
        }
    }
    result = 0x0;
    loc_0212fc:
    return result;
}
