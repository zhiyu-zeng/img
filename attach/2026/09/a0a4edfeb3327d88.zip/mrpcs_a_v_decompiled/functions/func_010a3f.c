uint64_t vm_func_010a3f(const void* arg0) {
    return *(uint64_t *)(arg0);
}
