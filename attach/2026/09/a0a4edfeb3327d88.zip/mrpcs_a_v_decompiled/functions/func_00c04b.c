void vm_func_00c04b(uint64_t arg0, uint64_t arg1, uint64_t arg2, uint64_t arg3, uint64_t arg4) {
    vm_func_005206(arg0, arg1, arg2, arg3, arg4);
    return;
}
