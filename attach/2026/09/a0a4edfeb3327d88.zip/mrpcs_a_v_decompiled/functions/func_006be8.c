uint64_t vm_func_006be8(uint64_t arg0, uint64_t arg1, uint64_t arg2, uint64_t arg3, uint64_t arg4, uint64_t arg5, uint64_t arg6, uint64_t arg7) {
    memcpy_checked((fp + 0x8), &g_01b8, 0x8);
    local_50 = vm_func_006447(arg3);
    if (((int32_t)(local_50)) < 76) {
        if (((int32_t)(local_50)) < 73) {
            if (((int32_t)(local_50)) < 67) {
                if (local_50 == 0x42) {
                    result = vm_func_00415a(arg0, arg1, arg4, arg5, arg6, arg7, 0x0);
                }
            } else {
                if (local_50 == 0x43) {
                    result = vm_func_00427d(arg0, arg1, arg4, arg5, arg6, arg7, 0x0);
                }
            }
        } else {
            if (((int32_t)(local_50)) < 74) {
                result = vm_func_0044c3(arg0, arg1, arg4, arg5, arg6, arg7, 0x0);
            } else {
                if (local_50 == 0x4a) {
                    result = vm_func_0045e6(arg0, arg1, arg4, arg5, arg6, arg7, 0x0);
                }
            }
        }
    } else {
        if (((int32_t)(local_50)) < 86) {
            if (((int32_t)(local_50)) < 83) {
                if (local_50 == 0x4c) {
                    tmp_007227 = vm_func_00828f(arg0, arg1, arg4, arg5, arg6, arg7, 0x0);
                    result = tmp_007227;
                }
            } else {
                if (local_50 == 0x53) {
                    result = vm_func_0043a0(arg0, arg1, arg4, arg5, arg6, arg7, 0x0);
                }
            }
        } else {
            if (((int32_t)(local_50)) < 90) {
                if (local_50 == 0x56) {
                    vm_func_003df9(arg0, arg1, arg4, arg5, arg6, arg7, 0x0);
                }
            } else {
                if (((int32_t)(local_50)) < 91) {
                    result = vm_func_004037(arg0, arg1, arg4, arg5, arg6, arg7, 0x0);
                } else {
                    if (local_50 == 0x5b) {
                        tmp_007227 = vm_func_00828f(arg0, arg1, arg4, arg5, arg6, arg7, 0x0);
                        result = tmp_007227;
                        return result;
                    }
                }
            }
        }
    }
    return result;
}
