void vm_func_007780(void* arg0) {
    vm_func_0077f4(arg0, *(uint64_t *)(arg0));
    *(uint64_t *)(arg0) = 0x0;
    return;
}
