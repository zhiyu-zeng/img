uint64_t bswap64(uint64_t arg0, uint64_t arg1) {
    return ((((((((arg1 >> 0x38) | ((arg1 & 0xff000000000000) >> 0x28)) | ((arg1 & 0xff0000000000) >> 0x18)) | ((arg1 & 0xff00000000) >> 0x8)) | ((arg1 & 0xff000000) << 0x8)) | ((arg1 & 0xff0000) << 0x18)) | ((arg1 & 0xff00) << 0x28)) | (arg1 << 0x38));
}
