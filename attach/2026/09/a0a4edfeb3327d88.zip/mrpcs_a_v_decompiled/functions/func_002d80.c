void vm_func_002d80(void* arg0) {
    *(uint64_t *)(arg0) = 0x0;
    *(uint64_t *)(arg0 + 0x8) = 0x0;
    *(uint16_t *)(arg0 + 0x10) = 0x0;
    *(uint64_t *)(arg0 + 0x18) = 0x0;
    return;
}
