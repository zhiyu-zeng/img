uint64_t vm_func_02faa7(uint64_t arg0, uint64_t arg1, uint64_t arg2, uint64_t dst, uint64_t arg4) {
    struct { uint32_t field_00; uint32_t field_04; uint32_t field_08; uint32_t field_0c; uint32_t field_10; uint32_t field_14; uint32_t field_18; uint32_t field_1c; uint32_t field_20; uint32_t field_24; } local_obj_180;
    uint8_t* stack_buf_0a0 = (uint8_t*)(fp + 0xa0); /* observed >= 0x10 bytes */
    uint8_t* stack_buf_100 = (uint8_t*)(fp + 0x100); /* observed >= 0x10 bytes */
    uint8_t* stack_buf_118 = (uint8_t*)(fp + 0x118); /* observed >= 0x30 bytes */
    uint8_t* stack_buf_150 = (uint8_t*)(fp + 0x150); /* observed >= 0x30 bytes */
    uint8_t* stack_buf_200 = (uint8_t*)(fp + 0x200); /* observed >= 0x90 bytes */
    local_80 = (arg0 + 0x1acda0d4);
    local_88 = (arg0 + 0x1acda114);
    local_90 = (arg0 + 0x107bbb8c);
    local_98 = call_native_n((arg0 + 0x1acda0d4), arg1);
    if (local_98 != 0x0) {
        memcpy_checked(stack_buf_0a0, (local_98 + 0x40), 0x10);
        if (local_a0 == 0x0) {
            result = 0x5;
        } else {
            if (((int32_t)(*(uint32_t *)(stack_buf_0a0 + 0x8))) > 0) {
                local_b0 = local_a0;
                local_b8 = 0x0;
                index_c0 = 0x0;
                while (((int32_t)(index_c0)) < ((int32_t)(*(uint32_t *)(stack_buf_0a0 + 0x8)))) {
                    local_c8 = *(uint64_t *)(local_b0 + ((int64_t)(index_c0) << 0x3));
                    if (*(uint64_t *)(local_b0 + ((int64_t)(index_c0) << 0x3)) != 0x0) {
                        memcpy_checked((fp + 0xd0), (local_c8 + 0x80), 0x8);
                        if (local_d0 != arg2) {
                            index_c0 = (index_c0 + 0x1);
                            continue;
                        } else {
                            local_b8 = local_c8;
                            break;
                        }
                    } else {
                        index_c0 = (index_c0 + 0x1);
                        continue;
                    }
                }
                loc_02fe95:
                if (local_b8 != 0x0) {
                    local_d8 = (local_b8 + 0x28);
                    local_e8 = (fp + 0xe0);
                    local_e0 = arg2;
                    local_f0 = call_native_n(local_88, arg1, arg2);
                    *(uint32_t *)(arg4) = local_f0;
                    if (((int32_t)(local_f0)) > -1) {
                        local_f4 = *(uint32_t *)(arg1 + 0x794);
                        if (((int32_t)(*(uint32_t *)(arg1 + 0x794))) < 0) {
                            local_f4 = 0x0;
                        } else {
                            if (((int32_t)(local_f4)) >= 2) {
                                goto loc_02ffee;
                            }
                        }
                        local_f8 = ((arg1 + ((local_f4 & 0x1) << 0x4)) + 0x750);
                        memcpy_checked(stack_buf_100, ((arg1 + ((local_f4 & 0x1) << 0x4)) + 0x750), 0x10);
                        if (local_100 == 0x0) {
                            once_value_0300f4 = vm_mov_once_d(0xa, 0xb);
                            result = once_value_0300f4;
                        } else {
                            if (((int32_t)(local_f0)) < ((int32_t)(*(uint32_t *)(stack_buf_100 + 0x8)))) {
                                local_110 = local_100;
                                memcpy_checked(stack_buf_118, (local_100 + ((int64_t)(local_f0) * 0x30)), 0x30);
                                src_148 = call_native_n(local_90, arg1);
                                if (src_148 != 0x0) {
                                    memcpy_checked(stack_buf_150, src_148, 0x30);
                                    local_1b0 = stack_buf_150;
                                    local_1b8 = stack_buf_118;
                                    local_obj_180.field_00 = (f32((f32((f32((f32(*(uint32_t *)(stack_buf_150 + 0xc)) * f32(local_118))) + f32((f32(local_150) * f32(*(uint32_t *)(stack_buf_118 + 0xc)))))) + f32((f32(*(uint32_t *)(stack_buf_150 + 0x4)) * f32(*(uint32_t *)(stack_buf_118 + 0x8)))))) - f32((f32(*(uint32_t *)(stack_buf_150 + 0x8)) * f32(*(uint32_t *)(stack_buf_118 + 0x4)))));
                                    local_obj_180.field_04 = (f32((f32((f32((f32(*(uint32_t *)(stack_buf_150 + 0xc)) * f32(*(uint32_t *)(stack_buf_118 + 0x4)))) - f32((f32(local_150) * f32(*(uint32_t *)(stack_buf_118 + 0x8)))))) + f32((f32(*(uint32_t *)(stack_buf_150 + 0x4)) * f32(*(uint32_t *)(stack_buf_118 + 0xc)))))) + f32((f32(*(uint32_t *)(stack_buf_150 + 0x8)) * f32(local_118))));
                                    local_obj_180.field_08 = (f32((f32((f32((f32(*(uint32_t *)(stack_buf_150 + 0xc)) * f32(*(uint32_t *)(local_1b8 + 0x8)))) + f32((f32(local_150) * f32(*(uint32_t *)(local_1b8 + 0x4)))))) - f32((f32(*(uint32_t *)(stack_buf_150 + 0x4)) * f32(*(uint32_t *)(local_1b8)))))) + f32((f32(*(uint32_t *)(stack_buf_150 + 0x8)) * f32(*(uint32_t *)(local_1b8 + 0xc)))));
                                    local_obj_180.field_0c = (f32((f32((f32((f32(*(uint32_t *)(local_1b0 + 0xc)) * f32(*(uint32_t *)(local_1b8 + 0xc)))) - f32((f32(*(uint32_t *)(local_1b0)) * f32(*(uint32_t *)(local_1b8)))))) - f32((f32(*(uint32_t *)(local_1b0 + 0x4)) * f32(*(uint32_t *)(local_1b8 + 0x4)))))) - f32((f32(*(uint32_t *)(local_1b0 + 0x8)) * f32(*(uint32_t *)(local_1b8 + 0x8)))));
                                    local_obj_180.field_1c = (f32(*(uint32_t *)(stack_buf_118 + 0x1c)) * f32(*(uint32_t *)(stack_buf_150 + 0x1c)));
                                    local_obj_180.field_20 = (f32(*(uint32_t *)(stack_buf_118 + 0x20)) * f32(*(uint32_t *)(stack_buf_150 + 0x20)));
                                    local_obj_180.field_24 = (f32(*(uint32_t *)(stack_buf_118 + 0x24)) * f32(*(uint32_t *)(stack_buf_150 + 0x24)));
                                    local_1c0 = (f32(*(uint32_t *)(stack_buf_118 + 0x10)) * f32(*(uint32_t *)(stack_buf_150 + 0x1c)));
                                    *(uint32_t *)((fp + 0x1c0) + 0x4) = (f32(*(uint32_t *)(stack_buf_118 + 0x14)) * f32(*(uint32_t *)(stack_buf_150 + 0x20)));
                                    *(uint32_t *)((fp + 0x1c0) + 0x8) = (f32(*(uint32_t *)(stack_buf_118 + 0x18)) * f32(*(uint32_t *)(stack_buf_150 + 0x24)));
                                    local_1d0 = stack_buf_150;
                                    local_1d8 = (f32((f32(*(uint32_t *)(stack_buf_150 + 0x4)) * f32((f32(*(uint32_t *)(stack_buf_118 + 0x18)) * f32(*(uint32_t *)(stack_buf_150 + 0x24)))))) - f32((f32(*(uint32_t *)(stack_buf_150 + 0x8)) * f32((f32(*(uint32_t *)(stack_buf_118 + 0x14)) * f32(*(uint32_t *)(stack_buf_150 + 0x20)))))));
                                    local_1dc = (f32((f32(*(uint32_t *)(stack_buf_150 + 0x8)) * f32((f32(*(uint32_t *)(stack_buf_118 + 0x10)) * f32(*(uint32_t *)(stack_buf_150 + 0x1c)))))) - f32((f32(local_150) * f32((f32(*(uint32_t *)(stack_buf_118 + 0x18)) * f32(*(uint32_t *)(stack_buf_150 + 0x24)))))));
                                    local_1e0 = (f32((f32(local_150) * f32((f32(*(uint32_t *)(stack_buf_118 + 0x14)) * f32(*(uint32_t *)(stack_buf_150 + 0x20)))))) - f32((f32(*(uint32_t *)(stack_buf_150 + 0x4)) * f32(local_1c0))));
                                    local_1e4 = (f32((f32(*(uint32_t *)(local_1d0 + 0x4)) * f32((f32((f32(local_150) * f32((f32(*(uint32_t *)(stack_buf_118 + 0x14)) * f32(*(uint32_t *)(stack_buf_150 + 0x20)))))) - f32((f32(*(uint32_t *)(stack_buf_150 + 0x4)) * f32(local_1c0))))))) - f32((f32(*(uint32_t *)(local_1d0 + 0x8)) * f32((f32((f32(*(uint32_t *)(stack_buf_150 + 0x8)) * f32((f32(*(uint32_t *)(stack_buf_118 + 0x10)) * f32(*(uint32_t *)(stack_buf_150 + 0x1c)))))) - f32((f32(local_150) * f32((f32(*(uint32_t *)(stack_buf_118 + 0x18)) * f32(*(uint32_t *)(stack_buf_150 + 0x24)))))))))));
                                    local_1e8 = (f32((f32(*(uint32_t *)(local_1d0 + 0x8)) * f32(local_1d8))) - f32((f32(*(uint32_t *)(local_1d0)) * f32((f32((f32(local_150) * f32((f32(*(uint32_t *)(stack_buf_118 + 0x14)) * f32(*(uint32_t *)(stack_buf_150 + 0x20)))))) - f32((f32(*(uint32_t *)(stack_buf_150 + 0x4)) * f32(local_1c0))))))));
                                    local_1ec = (f32((f32(*(uint32_t *)(local_1d0)) * f32(local_1dc))) - f32((f32(*(uint32_t *)(local_1d0 + 0x4)) * f32(local_1d8))));
                                    local_obj_180.field_10 = (f32((f32(local_1c0) + f32((f32((f32((f32(local_1d8) * f32(*(uint32_t *)(local_1d0 + 0xc)))) + f32((f32((f32(*(uint32_t *)(local_1d0 + 0x4)) * f32((f32((f32(local_150) * f32((f32(*(uint32_t *)(stack_buf_118 + 0x14)) * f32(*(uint32_t *)(stack_buf_150 + 0x20)))))) - f32((f32(*(uint32_t *)(stack_buf_150 + 0x4)) * f32(local_1c0))))))) - f32((f32(*(uint32_t *)(local_1d0 + 0x8)) * f32((f32((f32(*(uint32_t *)(stack_buf_150 + 0x8)) * f32((f32(*(uint32_t *)(stack_buf_118 + 0x10)) * f32(*(uint32_t *)(stack_buf_150 + 0x1c)))))) - f32((f32(local_150) * f32((f32(*(uint32_t *)(stack_buf_118 + 0x18)) * f32(*(uint32_t *)(stack_buf_150 + 0x24)))))))))))))) + f32((f32((f32(local_1d8) * f32(*(uint32_t *)(local_1d0 + 0xc)))) + f32((f32((f32(*(uint32_t *)(local_1d0 + 0x4)) * f32((f32((f32(local_150) * f32((f32(*(uint32_t *)(stack_buf_118 + 0x14)) * f32(*(uint32_t *)(stack_buf_150 + 0x20)))))) - f32((f32(*(uint32_t *)(stack_buf_150 + 0x4)) * f32(local_1c0))))))) - f32((f32(*(uint32_t *)(local_1d0 + 0x8)) * f32((f32((f32(*(uint32_t *)(stack_buf_150 + 0x8)) * f32((f32(*(uint32_t *)(stack_buf_118 + 0x10)) * f32(*(uint32_t *)(stack_buf_150 + 0x1c)))))) - f32((f32(local_150) * f32((f32(*(uint32_t *)(stack_buf_118 + 0x18)) * f32(*(uint32_t *)(stack_buf_150 + 0x24)))))))))))))))))) + f32(*(uint32_t *)(stack_buf_150 + 0x10)));
                                    local_obj_180.field_14 = (f32((f32(*(uint32_t *)((fp + 0x1c0) + 0x4)) + f32((f32((f32((f32(local_1dc) * f32(*(uint32_t *)(local_1d0 + 0xc)))) + f32((f32((f32(*(uint32_t *)(local_1d0 + 0x8)) * f32(local_1d8))) - f32((f32(*(uint32_t *)(local_1d0)) * f32((f32((f32(local_150) * f32((f32(*(uint32_t *)(stack_buf_118 + 0x14)) * f32(*(uint32_t *)(stack_buf_150 + 0x20)))))) - f32((f32(*(uint32_t *)(stack_buf_150 + 0x4)) * f32(local_1c0))))))))))) + f32((f32((f32(local_1dc) * f32(*(uint32_t *)(local_1d0 + 0xc)))) + f32((f32((f32(*(uint32_t *)(local_1d0 + 0x8)) * f32(local_1d8))) - f32((f32(*(uint32_t *)(local_1d0)) * f32((f32((f32(local_150) * f32((f32(*(uint32_t *)(stack_buf_118 + 0x14)) * f32(*(uint32_t *)(stack_buf_150 + 0x20)))))) - f32((f32(*(uint32_t *)(stack_buf_150 + 0x4)) * f32(local_1c0))))))))))))))) + f32(*(uint32_t *)(stack_buf_150 + 0x14)));
                                    local_obj_180.field_18 = (f32((f32(*(uint32_t *)((fp + 0x1c0) + 0x8)) + f32((f32((f32((f32(local_1e0) * f32(*(uint32_t *)(local_1d0 + 0xc)))) + f32((f32((f32(*(uint32_t *)(local_1d0)) * f32(local_1dc))) - f32((f32(*(uint32_t *)(local_1d0 + 0x4)) * f32(local_1d8))))))) + f32((f32((f32(local_1e0) * f32(*(uint32_t *)(local_1d0 + 0xc)))) + f32((f32((f32(*(uint32_t *)(local_1d0)) * f32(local_1dc))) - f32((f32(*(uint32_t *)(local_1d0 + 0x4)) * f32(local_1d8))))))))))) + f32(*(uint32_t *)(stack_buf_150 + 0x18)));
                                    index_1f0 = 0x0;
                                    while (((int32_t)(index_1f0)) <= 7) {
                                        *(uint8_t *)(((fp + 0x180) + (int64_t)(index_1f0)) + 0x28) = 0x0;
                                        index_1f0 = (index_1f0 + 0x1);
                                        continue;
                                    }
                                    local_1f8 = (arg0 + 0x10e18714);
                                    g_3d4c = 0x0;
                                    memset(stack_buf_200, 0x0, 0x90);
                                    vm_func_026ef7(local_1f8, stack_buf_200, "LL8", local_d8, &local_obj_180, &g_3d34, 0x0, 0x0);
                                    if (g_3d4c != 0x0) {
                                        memcpy_checked(dst, &g_3d34, 0x1c);
                                        result = 0x0;
                                    } else {
                                        result = 0xc;
                                    }
                                } else {
                                    result = 0xc;
                                }
                            } else {
                                once_value_0300f4 = vm_mov_once_d(0xa, 0xb);
                                result = once_value_0300f4;
                                return result;
                            }
                        }
                    } else {
                        result = 0x8;
                    }
                } else {
                    result = 0x6;
                }
            } else {
                result = 0x5;
                return result;
            }
        }
    } else {
        local_98 = vm_func_030d2a(arg0);
        if (local_98 != 0x0) {
            goto loc_02fc56;
        } else {
            result = 0x4;
        }
    }
    return result;
}
