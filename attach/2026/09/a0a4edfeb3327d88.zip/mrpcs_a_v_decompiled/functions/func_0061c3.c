void vm_func_0061c3(const void* arg0, uint64_t arg1, uint64_t arg2) {
    VmU64Pair u64_pair_018;
    u64_pair_018.first = arg1;
    u64_pair_018.second = arg2;
    dispatch_registered_handler(0x5d, *(uint64_t *)(arg0), &u64_pair_018, 0x2);
    return;
}
