void vm_func_01713d(void* arg0) {
    local_28 = vm_func_016fa4(arg0);
    local_30 = ((local_28 == 0x0) ? 0x1 : (local_28 << 0x1));
    local_38 = vm_func_017397(arg0, ((local_28 == 0x0) ? 0x1 : (local_28 << 0x1)));
    dst_40 = local_38;
    src_48 = vm_func_017439(arg0);
    while (true) {
        if (src_48 == vm_func_01747b(arg0)) break;
        memcpy_checked(dst_40, src_48, 0x10);
        dst_40 = (dst_40 + 0x10);
        src_48 = (src_48 + 0x10);
        continue;
    }
    vm_func_016ef1(arg0);
    *(uint64_t *)(arg0) = local_38;
    *(uint64_t *)(arg0 + 0x8) = dst_40;
    *(uint64_t *)(arg0 + 0x10) = (local_38 + (local_30 << 0x4));
    return;
}
