uint64_t vm_func_0237da(uint64_t arg0) {
    local_10 = 0x0;
    index_18 = 0x0;
    while (((uint64_t)(index_18)) < ((uint64_t)(*(uint64_t *)(arg0 + 0x18)))) {
        if (*(uint32_t *)(*(uint64_t *)(arg0 + 0x10) + (index_18 * 0x38)) != 0x2) {
            index_18 = (index_18 + 0x1);
            continue;
        } else {
            local_10 = (*(uint64_t *)(arg0 + 0x8) + *(uint64_t *)((*(uint64_t *)(arg0 + 0x10) + (index_18 * 0x38)) + 0x10));
            vm_func_023988(arg0, (*(uint64_t *)(arg0 + 0x8) + *(uint64_t *)((*(uint64_t *)(arg0 + 0x10) + (index_18 * 0x38)) + 0x10)));
            result = 0x0;
            goto loc_023962;
        }
    }
    result = 0xffffffff;
    loc_023962:
    return result;
}
