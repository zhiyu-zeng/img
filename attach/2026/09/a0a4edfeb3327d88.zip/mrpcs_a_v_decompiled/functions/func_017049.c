void vm_func_017049(void* arg0, VmU64Pair* src) {
    if (*(uint64_t *)(arg0 + 0x8) == *(uint64_t *)(arg0 + 0x10)) {
        vm_func_01713d(arg0);
    }
    if (*(uint64_t *)(arg0 + 0x8) != 0x0) {
        memcpy_checked(*(uint64_t *)(arg0 + 0x8), src, 0x10);
        *(uint64_t *)(arg0 + 0x8) = (*(uint64_t *)(arg0 + 0x8) + 0x10);
    }
    return;
}
