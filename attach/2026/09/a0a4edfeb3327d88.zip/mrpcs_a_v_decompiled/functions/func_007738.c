void vm_func_007738(uint64_t arg0) {
    vm_func_007780(arg0);
    return;
}
