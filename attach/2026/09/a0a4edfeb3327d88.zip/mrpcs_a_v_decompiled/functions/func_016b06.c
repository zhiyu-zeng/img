void vm_func_016b06(void) {
    VmProcMapsLine maps_line;
    VmU64Pair u64_pair_888;
    uint8_t* stack_buf_069 = (uint8_t*)(fp + 0x69); /* observed >= 0x400 bytes */
    vm_func_016ef1(g_1598);
    maps_file_60 = fopen("/proc/self/maps", "r");
    if (maps_file_60 != 0x0) {
        local_68 = 0x0;
        while (true) {
            if (fgets(stack_buf_069, 0x400, maps_file_60) == 0x0) break;
            maps_line.start = 0x0;
            maps_line.end = 0x0;
            memset(maps_line.perms, 0x0, 0x5);
            memset(maps_line.path, 0x0, 0x400);
            call_native_n(g_1590, stack_buf_069, "%llx-%llx %s %*s %*s %*s %s", &maps_line.start, &maps_line.end, maps_line.perms, maps_line.path);
            if (call_native_n(g_1580, maps_line.path, "anon:objects_external_alloc") != 0x0) {
                u64_pair_888.first = maps_line.start;
                u64_pair_888.second = maps_line.end;
                if (((uint64_t)(vm_func_016fa4(*(uint64_t *)(&g_1598)))) <= 0x1d) {
                    vm_func_017049(*(uint64_t *)(&g_1598), &u64_pair_888);
                    continue;
                }
            }
        }
        fclose(maps_file_60);
    }
    return;
}
