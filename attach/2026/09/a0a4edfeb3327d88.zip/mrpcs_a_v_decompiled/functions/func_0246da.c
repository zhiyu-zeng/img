uint64_t vm_func_0246da(uint64_t arg0, uint64_t arg1, uint64_t arg2, uint64_t arg3, uint64_t arg4) {
    if (vm_func_0237da(arg0) == 0x0) {
        local_38 = 0x0;
        local_38 = vm_func_02483d(arg0, arg1, arg2, arg3, arg4);
        result = local_38;
    } else {
        result = 0x0;
    }
    return result;
}
