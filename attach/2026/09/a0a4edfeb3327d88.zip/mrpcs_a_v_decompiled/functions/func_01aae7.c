void vm_func_01aae7(void) {
    struct { uint64_t field_00; uint64_t field_08; uint64_t field_10; uint64_t field_18; } local_obj_028;
    g_1618 = get_cached_module_base(0x1);
    g_1620 = get_cached_module_base(0x0);
    if (((uint64_t)(g_1618)) >= 0x100000001) {
        if (((uint64_t)(g_1620)) >= 0x100000001) {
            local_10 = *(uint64_t *)(g_1618 + 0x454aec);
            local_18 = *(uint64_t *)(g_1620 + 0xb7c7f20);
            if (*(uint64_t *)(g_1618 + 0x454aec) == 0x91206100f94007e8) {
                if (local_18 == 0x912d62d6f00a4696) {
                    g_1650 = (g_1620 + 0x82683d0);
                    g_1658 = 0x13a9f2a4;
                    g_1664 = (g_1620 + 0x174ab40);
                    g_166c = 0x260cd92;
                    g_1678 = (g_1618 + 0x1b1170);
                    g_1680 = 0x34f808;
                    g_168c = (g_1618 + 0x8cac0);
                    g_1694 = 0x7adac;
                    local_20 = 0x6c60;
                    local_obj_028.field_00 = 0x6c60;
                    local_obj_028.field_08 = (g_1618 + 0x371b18);
                    local_obj_028.field_10 = (g_1618 + 0x3c2d10);
                    local_obj_028.field_18 = (g_1618 + 0x3b9ab8);
                    memcpy_checked(&g_1630, &local_obj_028, 0x20);
                    register_module_probe_callback(0x6c60);
                    register_vm_callback(0x1a82f, 0x6c62, 0x1, 0x12c);
                    register_vm_callback(0x1a9eb, 0x6c63, 0x1, 0x46);
                }
            }
        }
    }
    return;
}
