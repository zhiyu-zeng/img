uint64_t vm_func_026293(uint64_t arg0, uint64_t arg1) {
    local_18 = 0x0;
    index_20 = 0x0;
    while (((uint64_t)(*(uint64_t *)(arg0))) < ((uint64_t)(*(uint64_t *)(arg0 + 0x8)))) {
        *(uint64_t *)(arg0) = (*(uint64_t *)(arg0) + 0x1);
        local_28 = *(uint8_t *)(*(uint64_t *)(arg0));
        local_18 = (local_18 | ((*(uint8_t *)(*(uint64_t *)(arg0)) & 0x7f) << index_20));
        index_20 = (index_20 + 0x7);
        if ((local_28 & 0x80) != 0x0) {
            continue;
        } else {
            if (((uint64_t)(index_20)) <= 0x3f) {
                if ((local_28 & 0x40) != 0x0) {
                    local_18 = (local_18 | (0x0 - (0x1 << index_20)));
                }
            }
            *(uint64_t *)(arg1) = local_18;
            result = 0x0;
            goto loc_026488;
        }
    }
    result = 0xffffffff;
    loc_026488:
    return result;
}
