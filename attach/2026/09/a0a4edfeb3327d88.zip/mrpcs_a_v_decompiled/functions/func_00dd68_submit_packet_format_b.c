uint64_t submit_packet_format_b(void* arg0) {
    uint8_t* stack_buf_060 = (uint8_t*)(fp + 0x60); /* observed >= 0x10 bytes */
    if (((int32_t)(*(uint32_t *)(arg0 + 0x14))) >= 1001) {
        *(uint32_t *)(arg0 + 0x14) = 0x3e8;
    }
    local_40 = 0x0;
    heap_ptr_48 = malloc(0x400);
    result = 0x0;
    if (heap_ptr_48 != 0x0) {
        memset(heap_ptr_48, 0x0, 0x8);
        local_51 = ((((prng_next() & 0xff)) % (uint64_t)(0xa0)) + 0x10);
        *(uint8_t *)(heap_ptr_48) = 0x11;
        *(uint8_t *)(heap_ptr_48 + 0x1) = local_51;
        local_40 = 0x2;
        *(uint16_t *)(heap_ptr_48 + (int64_t)(local_40)) = bswap16(arg0, (*(uint16_t *)(arg0 + 0xe) ^ 0xb6b6));
        local_40 = (local_40 + 0x2);
        if (((int32_t)(*(uint32_t *)(arg0 + 0x14))) < 1) {
            *(uint16_t *)(heap_ptr_48 + (int64_t)(local_40)) = 0x0;
            local_40 = (local_40 + 0x2);
        } else {
            if (((int32_t)((*(uint32_t *)(arg0 + 0x14) + (int64_t)(local_40)))) > 1023) {
                goto loc_00e204;
            } else {
                *(uint16_t *)(heap_ptr_48 + (int64_t)(local_40)) = bswap16(arg0, (*(uint16_t *)(arg0 + 0x14) + 0x4));
                local_40 = (local_40 + 0x2);
                *(uint16_t *)(heap_ptr_48 + (int64_t)(local_40)) = bswap16(arg0, *(uint16_t *)(arg0 + 0xa));
                local_40 = (local_40 + 0x2);
                *(uint16_t *)(heap_ptr_48 + (int64_t)(local_40)) = bswap16(arg0, *(uint16_t *)(arg0 + 0x8));
                local_40 = (local_40 + 0x2);
                index_54 = 0x0;
                while (((int32_t)(index_54)) <= 3) {
                    *(uint8_t *)(heap_ptr_48 + (int64_t)(((index_54 + (int64_t)(local_40)) + 0xfffffffc))) = (*(uint8_t *)(heap_ptr_48 + (int64_t)(((index_54 + (int64_t)(local_40)) + 0xfffffffc))) ^ local_51);
                    index_54 = (index_54 + 0x1);
                    continue;
                }
                index_58 = 0x0;
                while (((int32_t)(index_58)) < ((int32_t)(*(uint32_t *)(arg0 + 0x14)))) {
                    *(uint8_t *)(heap_ptr_48 + (int64_t)(((int64_t)(local_40) + index_58))) = (*(uint8_t *)(*(uint64_t *)(arg0) + (int64_t)(index_58)) ^ local_51);
                    index_58 = (index_58 + 0x1);
                    continue;
                }
                local_40 = (local_40 + *(uint32_t *)(arg0 + 0x14));
            }
        }
        transport_result_5c = transport_control(0x24, 0x0, 0x0, 0x0, 0x0);
        if (((int32_t)(transport_result_5c)) < 1024) {
            memset(stack_buf_060, 0x0, 0x10);
            local_70 = stack_buf_060;
            local_78 = (stack_buf_060 + 0x2);
            *(uint64_t *)(stack_buf_060 + 0x2) = heap_ptr_48;
            local_60 = local_40;
            transport_result_80 = transport_control(0x23, stack_buf_060, 0x0, 0x0, 0x0);
            if (transport_result_80 == 0x0) {
                result = 0x1;
            }
        }
    }
    if (heap_ptr_48 != 0x0) {
        free(heap_ptr_48);
    }
    return result;
}
