void vm_func_008032(uint64_t arg0, uint64_t arg1) {
    vm_func_00808e(arg0, 0x0);
    return;
}
