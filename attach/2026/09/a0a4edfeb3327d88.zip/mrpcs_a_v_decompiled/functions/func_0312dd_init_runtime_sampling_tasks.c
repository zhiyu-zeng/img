void init_runtime_sampling_tasks(void) {
    sample_libue4_base = get_cached_module_base(0x0);
    module_base_18 = get_cached_module_base(0x1);
    if (((uint64_t)(sample_libue4_base)) >= 0x100000001) {
        if (((uint64_t)(module_base_18)) >= 0x100000001) {
            local_20 = *(uint64_t *)(module_base_18 + 0x454aec);
            local_28 = *(uint64_t *)(sample_libue4_base + 0xb7c7f20);
            if (*(uint64_t *)(module_base_18 + 0x454aec) == 0x91206100f94007e8) {
                if (local_28 == 0x912d62d6f00a4696) {
                    local_30 = (sample_libue4_base + 0xbe91294);
                    register_vm_callback(0x2f19b, 0x6c97, 0x3, 0x0, 0x100, (sample_libue4_base + 0xbe91294), 0x0, 0x2000);
                    register_vm_callback(0x30ed9, 0x6c98, 0x1, 0x1e, 0x100, 0x0, 0x0, 0x2000);
                }
            }
        }
    }
    return;
}
