uint64_t rb_tree_insert_link_unique(const void* arg0, uint64_t arg1) {
    local_18 = *(uint64_t *)(arg0);
    while (*(uint64_t *)(arg1 + 0x18) != *(uint64_t *)(local_18 + 0x18)) {
        if (((uint64_t)(*(uint64_t *)(arg1 + 0x18))) >= ((uint64_t)(*(uint64_t *)(local_18 + 0x18)))) {
            if (*(uint64_t *)(local_18 + 0x10) != 0x0) {
                local_18 = *(uint64_t *)(local_18 + 0x10);
                continue;
            } else {
                *(uint64_t *)(local_18 + 0x10) = arg1;
                *(uint64_t *)(arg1) = local_18;
                result = 0x0;
                goto loc_00892e;
            }
        } else {
            if (*(uint64_t *)(local_18 + 0x8) != 0x0) {
                local_18 = *(uint64_t *)(local_18 + 0x8);
                continue;
            } else {
                *(uint64_t *)(local_18 + 0x8) = arg1;
                *(uint64_t *)(arg1) = local_18;
                result = 0x0;
                goto loc_00892e;
            }
        }
    }
    result = 0xffffffff;
    loc_00892e:
    return result;
}
