void vm_func_0063c4(const void* arg0, uint64_t arg1) {
    dispatch_registered_handler(0x18, *(uint64_t *)(arg0), (fp + 0x10), 0x1);
    return;
}
