void vm_func_0021e9(void) {
    module_base_002215 = get_cached_module_base(0x1);
    g_00b0 = module_base_002215;
    if (((uint64_t)(module_base_002215)) >= 0x100000001) {
        local_8 = *(uint64_t *)(g_00b0 + 0x454aec);
        if (*(uint64_t *)(g_00b0 + 0x454aec) == 0x91206100f94007e8) {
            register_vm_callback(0x113a, 0x6c51, 0x1, 0x1e);
            register_vm_callback(0x8f3, 0x6c52, 0x1, 0x78);
        }
    }
    return;
}
