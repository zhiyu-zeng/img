uint64_t vm_func_00a3e3(uint64_t arg0, uint64_t arg1, uint64_t arg2, uint64_t arg3) {
    memcpy_checked((fp + 0x18), &g_01d0, 0x8);
    local_40 = vm_func_0069ce(arg0, arg1);
    if (local_40 == 0x0) {
        vm_func_006a7e(arg0);
    } else {
        if (vm_func_006a36(arg0) == 0x0) {
            vm_call_reg(0x9628);
            vm_func_006ac6((fp + 0x48), local_40);
            local_60 = vm_func_00399f(arg0, local_40, arg2, arg3);
            if (local_60 == 0x0) {
                vm_func_006a7e(arg0);
                local_68 = 0x1;
            } else {
                if (vm_func_006a36(arg0) == 0x0) {
                    local_6c = *(uint8_t *)(arg3);
                    if (((int32_t)(*(uint8_t *)(arg3))) < 76) {
                        if (*(uint8_t *)(arg3) == 0x49) {
                            result = vm_func_003b19(arg0, arg1, local_60);
                        }
                    } else {
                        if (((int32_t)(*(uint8_t *)(arg3))) < 91) {
                            if (*(uint8_t *)(arg3) == 0x4c) {
                                tmp_00a74c = vm_func_00a7e4(arg0, arg1, local_60);
                                result = tmp_00a74c;
                            }
                        } else {
                            if (*(uint8_t *)(arg3) == 0x5b) {
                                tmp_00a74c = vm_func_00a7e4(arg0, arg1, local_60);
                                result = tmp_00a74c;
                                local_68 = 0x1;
                                vm_call_reg(0x7279);
                                return result;
                            }
                        }
                    }
                    local_68 = 0x1;
                } else {
                    vm_func_006a7e(arg0);
                    local_68 = 0x1;
                    vm_call_reg(0x7279);
                    return result;
                }
            }
            vm_call_reg(0x7279);
        } else {
            vm_func_006a7e(arg0);
            return result;
        }
    }
    return result;
}
