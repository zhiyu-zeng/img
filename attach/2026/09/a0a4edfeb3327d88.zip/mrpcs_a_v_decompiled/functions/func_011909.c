uint64_t vm_func_011909(void) {
    uint8_t* stack_buf_064 = (uint8_t*)(fp + 0x64); /* observed >= 0x10 bytes */
    uint8_t* stack_buf_084 = (uint8_t*)(fp + 0x84); /* observed >= 0x80 bytes */
    uint8_t* stack_buf_104 = (uint8_t*)(fp + 0x104); /* observed >= 0x15 bytes */
    uint8_t* stack_buf_128 = (uint8_t*)(fp + 0x128); /* observed >= 0x17 bytes */
    uint8_t* stack_buf_150 = (uint8_t*)(fp + 0x150); /* observed >= 0x1c bytes */
    uint8_t* stack_buf_178 = (uint8_t*)(fp + 0x178); /* observed >= 0x1e bytes */
    result = 0x0;
    memcpy_checked(stack_buf_064, &g_03f4, 0x10);
    index_74 = 0x0;
    while (((uint64_t)(index_74)) <= 0xe) {
        local_78 = ((0xf9 - (((*(uint8_t *)(stack_buf_064 + index_74) >> 0x5) | (*(uint8_t *)(stack_buf_064 + index_74) << 0x3)) + index_74)) ^ 0xff);
        *(uint8_t *)(stack_buf_064 + index_74) = ((0xf9 - (((*(uint8_t *)(stack_buf_064 + index_74) >> 0x5) | (*(uint8_t *)(stack_buf_064 + index_74) << 0x3)) + index_74)) ^ 0xff);
        index_74 = (index_74 + 0x1);
        continue;
    }
    if (vm_func_01122f(stack_buf_064) != 0x0) {
        *(uint32_t *)(g_0470) = (*(uint32_t *)(g_0470) | 0x2);
        if (vm_func_01137f(stack_buf_064) == 0x0) {
            *(uint32_t *)(g_0470) = (*(uint32_t *)(g_0470) | 0x4);
        }
        if (vm_func_0114c0(stack_buf_064, 0x0) == 0xfffffff2) {
            *(uint32_t *)(g_0470) = (*(uint32_t *)(g_0470) | 0x8);
        }
    } else {
        uid_7c = getuid();
        pid_80 = getpid();
        memset(stack_buf_084, 0x0, 0x80);
        memcpy_checked(stack_buf_104, &g_0404, 0x15);
        index_11c = 0x0;
        while (((uint64_t)(index_11c)) <= 0x13) {
            local_120 = ((((((((((0x0 - (((*(uint8_t *)(stack_buf_104 + index_11c) >> 0x7) | (*(uint8_t *)(stack_buf_104 + index_11c) << 0x1)) ^ 0xda)) & 0xff) >> 0x6) | (((0x0 - (((*(uint8_t *)(stack_buf_104 + index_11c) >> 0x7) | (*(uint8_t *)(stack_buf_104 + index_11c) << 0x1)) ^ 0xda)) & 0xff) << 0x2)) + 0x4c) ^ 0xff) + 0x25) ^ 0xd7) + 0x81) ^ 0xd6);
            *(uint8_t *)(stack_buf_104 + index_11c) = ((((((((((0x0 - (((*(uint8_t *)(stack_buf_104 + index_11c) >> 0x7) | (*(uint8_t *)(stack_buf_104 + index_11c) << 0x1)) ^ 0xda)) & 0xff) >> 0x6) | (((0x0 - (((*(uint8_t *)(stack_buf_104 + index_11c) >> 0x7) | (*(uint8_t *)(stack_buf_104 + index_11c) << 0x1)) ^ 0xda)) & 0xff) << 0x2)) + 0x4c) ^ 0xff) + 0x25) ^ 0xd7) + 0x81) ^ 0xd6);
            index_11c = (index_11c + 0x1);
            continue;
        }
        local_1a8 = fn_sprintf;
        snprintf(stack_buf_084, 0x80, stack_buf_104);
        local_124 = vm_func_011743(stack_buf_084);
        memset(stack_buf_084, 0x0, 0x80);
        memcpy_checked(stack_buf_128, &g_0419, 0x17);
        index_140 = 0x0;
        while (((uint64_t)(index_140)) <= 0x15) {
            local_144 = (0x0 - ((((((0x0 - ((((((((((*(uint8_t *)(stack_buf_128 + index_140) + 0xef) ^ 0xffffffff) & 0xff) >> 0x7) | ((((*(uint8_t *)(stack_buf_128 + index_140) + 0xef) ^ 0xffffffff) & 0xff) << 0x1)) - index_140) & 0xff) >> 0x2) | ((((((((*(uint8_t *)(stack_buf_128 + index_140) + 0xef) ^ 0xffffffff) & 0xff) >> 0x7) | ((((*(uint8_t *)(stack_buf_128 + index_140) + 0xef) ^ 0xffffffff) & 0xff) << 0x1)) - index_140) & 0xff) << 0x6)) + index_140)) & 0xff) >> 0x5) | (((0x0 - ((((((((((*(uint8_t *)(stack_buf_128 + index_140) + 0xef) ^ 0xffffffff) & 0xff) >> 0x7) | ((((*(uint8_t *)(stack_buf_128 + index_140) + 0xef) ^ 0xffffffff) & 0xff) << 0x1)) - index_140) & 0xff) >> 0x2) | ((((((((*(uint8_t *)(stack_buf_128 + index_140) + 0xef) ^ 0xffffffff) & 0xff) >> 0x7) | ((((*(uint8_t *)(stack_buf_128 + index_140) + 0xef) ^ 0xffffffff) & 0xff) << 0x1)) - index_140) & 0xff) << 0x6)) + index_140)) & 0xff) << 0x3)) ^ 0xffffffff) - index_140));
            *(uint8_t *)(stack_buf_128 + index_140) = (0x0 - ((((((0x0 - ((((((((((*(uint8_t *)(stack_buf_128 + index_140) + 0xef) ^ 0xffffffff) & 0xff) >> 0x7) | ((((*(uint8_t *)(stack_buf_128 + index_140) + 0xef) ^ 0xffffffff) & 0xff) << 0x1)) - index_140) & 0xff) >> 0x2) | ((((((((*(uint8_t *)(stack_buf_128 + index_140) + 0xef) ^ 0xffffffff) & 0xff) >> 0x7) | ((((*(uint8_t *)(stack_buf_128 + index_140) + 0xef) ^ 0xffffffff) & 0xff) << 0x1)) - index_140) & 0xff) << 0x6)) + index_140)) & 0xff) >> 0x5) | (((0x0 - ((((((((((*(uint8_t *)(stack_buf_128 + index_140) + 0xef) ^ 0xffffffff) & 0xff) >> 0x7) | ((((*(uint8_t *)(stack_buf_128 + index_140) + 0xef) ^ 0xffffffff) & 0xff) << 0x1)) - index_140) & 0xff) >> 0x2) | ((((((((*(uint8_t *)(stack_buf_128 + index_140) + 0xef) ^ 0xffffffff) & 0xff) >> 0x7) | ((((*(uint8_t *)(stack_buf_128 + index_140) + 0xef) ^ 0xffffffff) & 0xff) << 0x1)) - index_140) & 0xff) << 0x6)) + index_140)) & 0xff) << 0x3)) ^ 0xffffffff) - index_140));
            index_140 = (index_140 + 0x1);
            continue;
        }
        snprintf(stack_buf_084, 0x80, stack_buf_128, uid_7c);
        local_148 = vm_func_011743(stack_buf_084);
        local_14c = vm_func_01122f(stack_buf_084);
        if (local_148 == 0x0) {
            if (local_124 != 0x0) {
                memset(stack_buf_084, 0x0, 0x80);
                memcpy_checked(stack_buf_150, &g_0430, 0x1c);
                index_16c = 0x0;
                while (((uint64_t)(index_16c)) <= 0x1a) {
                    local_170 = (0xf - ((((0xffffff38 - *(uint8_t *)(stack_buf_150 + index_16c)) & 0xff) >> 0x2) | (((0xffffff38 - *(uint8_t *)(stack_buf_150 + index_16c)) & 0xff) << 0x6)));
                    *(uint8_t *)(stack_buf_150 + index_16c) = (0xf - ((((0xffffff38 - *(uint8_t *)(stack_buf_150 + index_16c)) & 0xff) >> 0x2) | (((0xffffff38 - *(uint8_t *)(stack_buf_150 + index_16c)) & 0xff) << 0x6)));
                    index_16c = (index_16c + 0x1);
                    continue;
                }
                ((local_1a8)(stack_buf_084, stack_buf_150, uid_7c));
                local_174 = vm_func_011743(stack_buf_084);
                memset(stack_buf_084, 0x0, 0x80);
                memcpy_checked(stack_buf_178, &g_044c, 0x1e);
                index_198 = 0x0;
                while (((uint64_t)(index_198)) <= 0x1c) {
                    local_19c = ((((((((*(uint8_t *)(stack_buf_178 + index_198) + 0xaa) ^ 0x7d) + 0x71) ^ 0x68) + 0x34) ^ 0x9b) + 0x18) ^ 0x69);
                    *(uint8_t *)(stack_buf_178 + index_198) = ((((((((*(uint8_t *)(stack_buf_178 + index_198) + 0xaa) ^ 0x7d) + 0x71) ^ 0x68) + 0x34) ^ 0x9b) + 0x18) ^ 0x69);
                    index_198 = (index_198 + 0x1);
                    continue;
                }
                ((local_1a8)(stack_buf_084, stack_buf_178, uid_7c, pid_80));
                local_1a0 = vm_func_011743(stack_buf_084);
                local_1a4 = vm_func_01122f(stack_buf_084);
                if (local_1a0 == 0x0) {
                    if (local_174 != 0x0) {
                        result = 0x1;
                        if (local_14c == 0x0) {
                            result = (result | 0x2);
                        }
                        if (local_1a4 == 0x0) {
                            result = (result | 0x4);
                        }
                    }
                }
            }
        }
    }
    return result;
}
