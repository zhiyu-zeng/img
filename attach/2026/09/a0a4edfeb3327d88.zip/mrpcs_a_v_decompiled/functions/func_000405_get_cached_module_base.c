uint64_t get_cached_module_base(uint64_t arg0) {
    if (((int32_t)(arg0)) < 3) {
        result = *(uint64_t *)((arg0 << 0x3) + &module_base_libUE4);
    } else {
        result = 0x0;
    }
    return result;
}
