uint64_t vm_func_024579(void) {
    if (g_2468 == 0x0) {
        g_2468 = resolve_symbol("libc.so", "calloc");
        g_2470 = resolve_symbol("libc.so", "strdup");
        if (g_2468 == 0x0) {
            result = 0xffffffff;
        } else {
            if (g_2470 != 0x0) {
                result = 0x0;
            } else {
                result = 0xffffffff;
                return result;
            }
        }
    } else {
        if (g_2470 == 0x0) {
            goto loc_0245ff;
        } else {
            result = 0x0;
        }
    }
    return result;
}
