uint64_t vm_func_0100f2(uint64_t arg0) {
    tmp_01013a = vm_func_010356(arg0);
    return (((tmp_01013a - vm_func_01039c(arg0)) >> 0x3) * 0x6db6db6db6db6db7);
}
