void vm_func_01e621(void) {
    vm_func_01e68a();
    register_vm_callback(0x1e74c, 0x6c69, 0x1, 0x78);
    return;
}
