void vm_func_007ac9(void* arg0, uint64_t arg1) {
    *(uint64_t *)(arg0) = 0x0;
    vm_func_007f72(arg0, arg1);
    return;
}
