void vm_func_00b3b0(uint64_t arg0, uint64_t arg1, uint64_t arg2) {
    local_40 = vm_func_00a3e3(arg0, arg1, arg2, "Ljava/lang/String;");
    local_38 = local_40;
    if (local_40 == 0x0) {
        vm_func_006a7e(arg0);
        local_18 = 0x0;
    } else {
        if (vm_func_006a36(arg0) == 0x0) {
            vm_call_reg(0x9628);
            vm_func_006ac6((fp + 0x48), local_38);
            local_18 = vm_func_00b22a(arg0, local_38);
            vm_call_reg(0x7279);
        } else {
            vm_func_006a7e(arg0);
            local_18 = 0x0;
            return;
        }
    }
    return;
}
