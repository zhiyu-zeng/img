void vm_func_00c42e(uint64_t arg0) {
    if (vm_func_006a36(arg0) != 0x1) {
        local_0 = 0x0;
    } else {
        vm_func_006a7e(arg0);
        local_0 = 0x1;
    }
    return;
}
