# MVM 函数索引

- 全部函数：**393**
- Callback：**33**
- 已命名非 Callback：**55**
- 根可达未命名 helper：**187**
- 其他 / 动态路径函数：**118**

优先阅读顺序：Callback → 已命名函数 → 可达 helper → 其他函数。

## Callback

| 地址 | 函数 | 原型 | Callers | Callees |
|---:|---|---|---:|---:|
| `0x0008f3` | [vm_func_0008f3](func_0008f3.c) | `void vm_func_0008f3(void)` | 0 | 0 |
| `0x00113a` | [vm_func_00113a](func_00113a.c) | `void vm_func_00113a(void)` | 0 | 2 |
| `0x002aee` | [vm_func_002aee](func_002aee.c) | `void vm_func_002aee(void)` | 0 | 1 |
| `0x010479` | [module_relative_probe_callback](func_010479_module_relative_probe_callback.c) | `void module_relative_probe_callback(void)` | 0 | 1 |
| `0x010beb` | [vm_func_010beb](func_010beb.c) | `void vm_func_010beb(void)` | 0 | 0 |
| `0x010e76` | [vm_func_010e76](func_010e76.c) | `void vm_func_010e76(void)` | 0 | 1 |
| `0x01620c` | [persistent_vm_worker_6c93](func_01620c_persistent_vm_worker_6c93.c) | `void persistent_vm_worker_6c93(void)` | 0 | 7 |
| `0x016680` | [cleanup_vm_worker_6c94](func_016680_cleanup_vm_worker_6c94.c) | `void cleanup_vm_worker_6c94(void)` | 0 | 0 |
| `0x018625` | [vm_func_018625](func_018625.c) | `void vm_func_018625(void)` | 0 | 2 |
| `0x018be3` | [vm_func_018be3](func_018be3.c) | `void vm_func_018be3(void)` | 0 | 0 |
| `0x018d15` | [vm_func_018d15](func_018d15.c) | `void vm_func_018d15(void)` | 0 | 1 |
| `0x019159` | [vm_func_019159](func_019159.c) | `void vm_func_019159(void)` | 0 | 0 |
| `0x01a82f` | [vm_func_01a82f](func_01a82f.c) | `void vm_func_01a82f(void)` | 0 | 1 |
| `0x01a9eb` | [vm_func_01a9eb](func_01a9eb.c) | `void vm_func_01a9eb(void)` | 0 | 0 |
| `0x01adf3` | [vm_func_01adf3](func_01adf3.c) | `void vm_func_01adf3(void)` | 0 | 0 |
| `0x01b056` | [vm_func_01b056](func_01b056.c) | `void vm_func_01b056(void)` | 0 | 2 |
| `0x01e74c` | [vm_func_01e74c](func_01e74c.c) | `void vm_func_01e74c(void)` | 0 | 0 |
| `0x01f0e2` | [vm_func_01f0e2](func_01f0e2.c) | `void vm_func_01f0e2(void)` | 0 | 0 |
| `0x01f511` | [vm_func_01f511](func_01f511.c) | `void vm_func_01f511(void)` | 0 | 1 |
| `0x01fab3` | [vm_func_01fab3](func_01fab3.c) | `void vm_func_01fab3(void)` | 0 | 2 |
| `0x02153f` | [vm_func_02153f](func_02153f.c) | `void vm_func_02153f(void)` | 0 | 1 |
| `0x0216f4` | [inspect_thread_module_egl](func_0216f4_inspect_thread_module_egl.c) | `void inspect_thread_module_egl(void)` | 0 | 2 |
| `0x02227d` | [vm_func_02227d](func_02227d.c) | `void vm_func_02227d(void)` | 1 | 2 |
| `0x02241a` | [report_thread_module_egl_1350254](func_02241a_report_thread_module_egl_1350254.c) | `void report_thread_module_egl_1350254(void)` | 0 | 1 |
| `0x027319` | [collect_symbol_probe_callback](func_027319_collect_symbol_probe_callback.c) | `void collect_symbol_probe_callback(void)` | 0 | 1 |
| `0x027601` | [report_symbol_probe_1350259](func_027601_report_symbol_probe_1350259.c) | `void report_symbol_probe_1350259(void)` | 0 | 3 |
| `0x02a174` | [collect_mapping_probe_callback](func_02a174_collect_mapping_probe_callback.c) | `void collect_mapping_probe_callback(void)` | 0 | 1 |
| `0x02a328` | [report_mapping_probe_135025c](func_02a328_report_mapping_probe_135025c.c) | `void report_mapping_probe_135025c(void)` | 0 | 2 |
| `0x02be0b` | [serialize_integrity_record_135025e](func_02be0b_serialize_integrity_record_135025e.c) | `void serialize_integrity_record_135025e(void)` | 0 | 2 |
| `0x02f19b` | [sample_runtime_ring](func_02f19b_sample_runtime_ring.c) | `void sample_runtime_ring(void)` | 0 | 4 |
| `0x030ed9` | [report_runtime_ring_sample](func_030ed9_report_runtime_ring_sample.c) | `void report_runtime_ring_sample(void)` | 0 | 0 |
| `0x0316bd` | [report_suspicious_mappings_13525d9](func_0316bd_report_suspicious_mappings_13525d9.c) | `void report_suspicious_mappings_13525d9(void)` | 0 | 1 |
| `0x0328f1` | [runtime_state_machine_6c9a](func_0328f1_runtime_state_machine_6c9a.c) | `void runtime_state_machine_6c9a(void)` | 0 | 7 |

## 已命名函数

| 地址 | 函数 | 原型 | Callers | Callees |
|---:|---|---|---:|---:|
| `0x0003ba` | [find_module_base_by_name](func_0003ba_find_module_base_by_name.c) | `uint64_t find_module_base_by_name(uint64_t arg0)` | 1 | 0 |
| `0x000405` | [get_cached_module_base](func_000405_get_cached_module_base.c) | `uint64_t get_cached_module_base(uint64_t arg0)` | 12 | 0 |
| `0x0004c6` | [init_module_base_cache](func_0004c6_init_module_base_cache.c) | `void init_module_base_cache(void)` | 1 | 1 |
| `0x000560` | [sys_process_vm_readv](func_000560_sys_process_vm_readv.c) | `int64_t sys_process_vm_readv(int32_t pid, const VmU64Pair* local_iov, uint64_t local_iov_count, const VmU64Pair* remote_iov, uint64_t remote_iov_count, uint64_t flags)` | 1 | 0 |
| `0x002dea` | [jni_env_context_destroy](func_002dea_jni_env_context_destroy.c) | `void jni_env_context_destroy(void* arg0)` | 3 | 1 |
| `0x002f98` | [jni_acquire_env](func_002f98_jni_acquire_env.c) | `uint64_t jni_acquire_env(void* arg0)` | 1 | 0 |
| `0x003169` | [jni_get_or_create_env_holder](func_003169_jni_get_or_create_env_holder.c) | `uint64_t jni_get_or_create_env_holder(void* arg0)` | 3 | 2 |
| `0x0032b2` | [jni_env_holder_init](func_0032b2_jni_env_holder_init.c) | `void jni_env_holder_init(void* arg0, uint64_t arg1)` | 1 | 0 |
| `0x007a14` | [tree_node_clear_links](func_007a14_tree_node_clear_links.c) | `void tree_node_clear_links(void* arg0)` | 1 | 0 |
| `0x007a6e` | [heap_free](func_007a6e_heap_free.c) | `void heap_free(uint64_t arg0, uint64_t arg1)` | 1 | 0 |
| `0x007e7b` | [tree_is_left_child](func_007e7b_tree_is_left_child.c) | `uint64_t tree_is_left_child(uint64_t arg0, const void* arg1)` | 1 | 0 |
| `0x00870b` | [rb_tree_insert_link_unique](func_00870b_rb_tree_insert_link_unique.c) | `uint64_t rb_tree_insert_link_unique(const void* arg0, uint64_t arg1)` | 1 | 0 |
| `0x008954` | [rb_tree_insert_fixup](func_008954_rb_tree_insert_fixup.c) | `void rb_tree_insert_fixup(uint64_t arg0, void* arg1, uint64_t arg2)` | 1 | 2 |
| `0x008e5c` | [rb_rotate_left](func_008e5c_rb_rotate_left.c) | `void rb_rotate_left(void* arg0, const void* arg1, uint64_t arg2)` | 1 | 1 |
| `0x009091` | [rb_rotate_right](func_009091_rb_rotate_right.c) | `void rb_rotate_right(void* arg0, const void* arg1, uint64_t arg2)` | 1 | 1 |
| `0x0092c6` | [rb_is_left_child](func_0092c6_rb_is_left_child.c) | `uint64_t rb_is_left_child(uint64_t arg0, const void* arg1)` | 2 | 0 |
| `0x0093bd` | [heap_alloc](func_0093bd_heap_alloc.c) | `uint64_t heap_alloc(uint64_t size)` | 1 | 0 |
| `0x00946a` | [rb_node_init](func_00946a_rb_node_init.c) | `void rb_node_init(void* arg0, uint64_t arg1, uint64_t arg2)` | 1 | 1 |
| `0x00cf86` | [packet_append_u8](func_00cf86_packet_append_u8.c) | `uint64_t packet_append_u8(void* arg0, uint64_t arg1)` | 2 | 0 |
| `0x00d075` | [packet_append_u16](func_00d075_packet_append_u16.c) | `uint64_t packet_append_u16(void* arg0, uint64_t arg1, uint64_t arg2)` | 2 | 1 |
| `0x00d225` | [bswap16](func_00d225_bswap16.c) | `uint64_t bswap16(uint64_t arg0, uint64_t arg1)` | 3 | 0 |
| `0x00d28f` | [packet_append_u32](func_00d28f_packet_append_u32.c) | `uint64_t packet_append_u32(void* arg0, uint64_t arg1, uint64_t arg2)` | 2 | 1 |
| `0x00d447` | [bswap32](func_00d447_bswap32.c) | `uint64_t bswap32(uint64_t arg0, uint64_t arg1)` | 2 | 0 |
| `0x00d4d1` | [packet_append_u64](func_00d4d1_packet_append_u64.c) | `uint64_t packet_append_u64(void* arg0, uint64_t arg1, uint64_t arg2)` | 2 | 1 |
| `0x00d681` | [bswap64](func_00d681_bswap64.c) | `uint64_t bswap64(uint64_t arg0, uint64_t arg1)` | 1 | 0 |
| `0x00d793` | [packet_append_xor_bytes](func_00d793_packet_append_xor_bytes.c) | `uint64_t packet_append_xor_bytes(void* arg0, uint64_t arg1, uint64_t arg2, uint64_t arg3)` | 1 | 0 |
| `0x00d998` | [submit_packet_format_a](func_00d998_submit_packet_format_a.c) | `uint64_t submit_packet_format_a(void* arg0)` | 1 | 2 |
| `0x00dd68` | [submit_packet_format_b](func_00dd68_submit_packet_format_b.c) | `uint64_t submit_packet_format_b(void* arg0)` | 1 | 1 |
| `0x00e41d` | [packet_periodic_flush](func_00e41d_packet_periodic_flush.c) | `uint64_t packet_periodic_flush(void* arg0, uint64_t arg1)` | 3 | 2 |
| `0x00e5de` | [packet_append_typed_field](func_00e5de_packet_append_typed_field.c) | `void packet_append_typed_field(uint64_t arg0, uint64_t string, uint64_t arg2, uint64_t arg3)` | 3 | 5 |
| `0x0106f8` | [recordvec_push_0x38](func_0106f8_recordvec_push_0x38.c) | `void recordvec_push_0x38(void* arg0, uint64_t src)` | 1 | 1 |
| `0x010b85` | [register_module_probe_callback](func_010b85_register_module_probe_callback.c) | `void register_module_probe_callback(uint64_t arg0)` | 2 | 0 |
| `0x0115f5` | [sys_tgkill_checked](func_0115f5_sys_tgkill_checked.c) | `uint64_t sys_tgkill_checked(uint64_t pid, uint64_t tid, uint64_t signal)` | 2 | 0 |
| `0x021322` | [init_thread_module_egl_tasks](func_021322_init_thread_module_egl_tasks.c) | `void init_thread_module_egl_tasks(void)` | 1 | 0 |
| `0x0228af` | [run_dl_iterate_phdr_callback_6c6d](func_0228af_run_dl_iterate_phdr_callback_6c6d.c) | `void run_dl_iterate_phdr_callback_6c6d(void)` | 1 | 0 |
| `0x022917` | [inspect_libegl_phdr_and_install_probe](func_022917_inspect_libegl_phdr_and_install_probe.c) | `uint64_t inspect_libegl_phdr_and_install_probe(const char* arg0)` | 1 | 7 |
| `0x028c67` | [collect_symbol_probe_records](func_028c67_collect_symbol_probe_records.c) | `void collect_symbol_probe_records(uint64_t arg0)` | 1 | 6 |
| `0x02adc3` | [collect_proc_maps_probe_records](func_02adc3_collect_proc_maps_probe_records.c) | `void collect_proc_maps_probe_records(void)` | 1 | 1 |
| `0x02b4f4` | [collect_mapping_descriptor_record](func_02b4f4_collect_mapping_descriptor_record.c) | `void collect_mapping_descriptor_record(uint64_t arg0)` | 1 | 3 |
| `0x02c631` | [fnv1a_hash_region](func_02c631_fnv1a_hash_region.c) | `void fnv1a_hash_region(void)` | 1 | 2 |
| `0x02d46e` | [scan_file_for_pattern_streaming](func_02d46e_scan_file_for_pattern_streaming.c) | `uint64_t scan_file_for_pattern_streaming(uint8_t* arg0, uint8_t* arg1, uint64_t arg2, uint64_t arg3, uint64_t arg4)` | 1 | 6 |
| `0x02e029` | [sys_mmap](func_02e029_sys_mmap.c) | `uint64_t sys_mmap(uint64_t arg0, uint64_t arg1, uint64_t arg2, uint64_t arg3, uint64_t arg4, uint64_t arg5)` | 1 | 1 |
| `0x02e200` | [sys_openat](func_02e200_sys_openat.c) | `uint64_t sys_openat(uint64_t arg0, uint64_t arg1, uint64_t arg2, uint64_t arg3)` | 1 | 1 |
| `0x02e38f` | [sys_munmap](func_02e38f_sys_munmap.c) | `void sys_munmap(uint64_t arg0, uint64_t arg1)` | 1 | 1 |
| `0x02e4ca` | [sys_read](func_02e4ca_sys_read.c) | `uint64_t sys_read(uint64_t arg0, uint64_t arg1, uint64_t arg2)` | 1 | 1 |
| `0x02e62d` | [memmem_linear](func_02e62d_memmem_linear.c) | `uint64_t memmem_linear(const uint8_t* haystack, uint64_t haystack_len, const uint8_t* needle, uint64_t needle_len)` | 1 | 0 |
| `0x02e92d` | [sys_close](func_02e92d_sys_close.c) | `void sys_close(uint64_t arg0)` | 1 | 1 |
| `0x02ea48` | [build_aarch64_syscall_stub](func_02ea48_build_aarch64_syscall_stub.c) | `uint64_t build_aarch64_syscall_stub(uint64_t arg0)` | 5 | 0 |
| `0x02ef7f` | [copy_bytes_via_aligned_u32](func_02ef7f_copy_bytes_via_aligned_u32.c) | `uint64_t copy_bytes_via_aligned_u32(uint64_t arg0, uint64_t arg1, uint64_t arg2)` | 1 | 0 |
| `0x0308ea` | [point_vs_aabb_axis_delta_helper](func_0308ea_point_vs_aabb_axis_delta_helper.c) | `uint32_t point_vs_aabb_axis_delta_helper(const float* point_xyz, const float* aabb_minmax)` | 1 | 0 |
| `0x0312dd` | [init_runtime_sampling_tasks](func_0312dd_init_runtime_sampling_tasks.c) | `void init_runtime_sampling_tasks(void)` | 1 | 1 |
| `0x03150a` | [process_vm_readv_single](func_03150a_process_vm_readv_single.c) | `int64_t process_vm_readv_single(int32_t pid, void* local_buffer, uint64_t remote_address, uint64_t size)` | 1 | 0 |
| `0x031602` | [init_suspicious_mapping_task](func_031602_init_suspicious_mapping_task.c) | `void init_suspicious_mapping_task(void)` | 1 | 0 |
| `0x031d38` | [scan_proc_self_maps_suspicious_regions](func_031d38_scan_proc_self_maps_suspicious_regions.c) | `void scan_proc_self_maps_suspicious_regions(void)` | 1 | 2 |
| `0x0327d9` | [get_page_size_cached](func_0327d9_get_page_size_cached.c) | `uint64_t get_page_size_cached(void)` | 1 | 0 |

## 根可达未命名 helper

| 地址 | 函数 | 原型 | Callers | Callees |
|---:|---|---|---:|---:|
| `0x000000` | [vm_func_000000](func_000000.c) | `void vm_func_000000(void)` | 0 | 22 |
| `0x000613` | [vm_func_000613](func_000613.c) | `uint64_t vm_func_000613(uint64_t path, uint8_t* arg1)` | 1 | 0 |
| `0x0006fa` | [vm_func_0006fa](func_0006fa.c) | `uint64_t vm_func_0006fa(uint64_t arg0, uint64_t arg1, uint64_t arg2)` | 1 | 0 |
| `0x000f25` | [vm_func_000f25](func_000f25.c) | `uint64_t vm_func_000f25(uint64_t arg0, uint64_t arg1, uint64_t arg2)` | 1 | 2 |
| `0x0021e9` | [vm_func_0021e9](func_0021e9.c) | `void vm_func_0021e9(void)` | 1 | 1 |
| `0x0022fa` | [vm_func_0022fa](func_0022fa.c) | `void vm_func_0022fa(void)` | 1 | 13 |
| `0x002d21` | [vm_func_002d21](func_002d21.c) | `void vm_func_002d21(void)` | 1 | 0 |
| `0x002d80` | [vm_func_002d80](func_002d80.c) | `void vm_func_002d80(void* arg0)` | 3 | 0 |
| `0x002f5a` | [vm_func_002f5a](func_002f5a.c) | `void vm_func_002f5a(uint64_t arg0)` | 1 | 0 |
| `0x00330c` | [vm_func_00330c](func_00330c.c) | `uint64_t vm_func_00330c(const void* arg0, uint64_t arg1)` | 6 | 0 |
| `0x00339f` | [vm_func_00339f](func_00339f.c) | `uint64_t vm_func_00339f(const void* arg0, uint64_t arg1, uint64_t arg2, uint64_t arg3, uint64_t arg4, uint64_t arg5, uint64_t arg6)` | 2 | 0 |
| `0x0034ae` | [vm_func_0034ae](func_0034ae.c) | `uint64_t vm_func_0034ae(const void* arg0, uint64_t arg1)` | 4 | 0 |
| `0x003776` | [vm_func_003776](func_003776.c) | `uint64_t vm_func_003776(const void* arg0, uint64_t arg1)` | 3 | 0 |
| `0x003809` | [vm_func_003809](func_003809.c) | `uint64_t vm_func_003809(const void* arg0, uint64_t arg1, uint64_t arg2, uint64_t arg3)` | 7 | 0 |
| `0x0038d4` | [vm_func_0038d4](func_0038d4.c) | `uint64_t vm_func_0038d4(const void* arg0, uint64_t arg1, uint64_t arg2, uint64_t arg3)` | 6 | 0 |
| `0x00399f` | [vm_func_00399f](func_00399f.c) | `uint64_t vm_func_00399f(const void* arg0, uint64_t arg1, uint64_t arg2, uint64_t arg3)` | 4 | 0 |
| `0x003a6a` | [vm_func_003a6a](func_003a6a.c) | `uint64_t vm_func_003a6a(const void* arg0, uint64_t arg1, uint64_t arg2)` | 4 | 0 |
| `0x003f18` | [vm_func_003f18](func_003f18.c) | `uint64_t vm_func_003f18(const void* arg0, uint64_t arg1, uint64_t arg2, uint64_t arg3, uint64_t arg4, uint64_t arg5, uint64_t arg6)` | 5 | 0 |
| `0x0044c3` | [vm_func_0044c3](func_0044c3.c) | `uint64_t vm_func_0044c3(const void* arg0, uint64_t arg1, uint64_t arg2, uint64_t arg3, uint64_t arg4, uint64_t arg5, uint64_t arg6)` | 3 | 0 |
| `0x004824` | [vm_func_004824](func_004824.c) | `uint64_t vm_func_004824(const void* arg0, uint64_t arg1, uint64_t arg2, uint64_t arg3, uint64_t arg4, uint64_t arg5, uint64_t arg6)` | 5 | 0 |
| `0x005011` | [vm_func_005011](func_005011.c) | `uint64_t vm_func_005011(const void* arg0, uint64_t arg1, uint64_t arg2)` | 3 | 0 |
| `0x0050c0` | [vm_func_0050c0](func_0050c0.c) | `void vm_func_0050c0(const void* arg0, uint64_t arg1, uint64_t arg2)` | 2 | 0 |
| `0x00516f` | [vm_func_00516f](func_00516f.c) | `uint64_t vm_func_00516f(const void* arg0, uint64_t arg1)` | 2 | 0 |
| `0x0055c0` | [vm_func_0055c0](func_0055c0.c) | `uint64_t vm_func_0055c0(const void* arg0)` | 3 | 0 |
| `0x00562b` | [vm_func_00562b](func_00562b.c) | `void vm_func_00562b(const void* arg0)` | 8 | 0 |
| `0x005692` | [vm_func_005692](func_005692.c) | `void vm_func_005692(const void* arg0, uint64_t arg1)` | 6 | 0 |
| `0x006266` | [vm_func_006266](func_006266.c) | `uint64_t vm_func_006266(const void* arg0, uint64_t arg1, uint64_t arg2)` | 1 | 0 |
| `0x006305` | [vm_func_006305](func_006305.c) | `void vm_func_006305(const void* arg0, uint64_t arg1, uint64_t arg2, uint64_t arg3)` | 1 | 0 |
| `0x00cb46` | [vm_func_00cb46](func_00cb46.c) | `void vm_func_00cb46(void* arg0)` | 3 | 0 |
| `0x00cbbc` | [vm_func_00cbbc](func_00cbbc.c) | `void vm_func_00cbbc(void* arg0, uint64_t arg1, uint64_t arg2, uint64_t arg3, uint64_t arg4)` | 3 | 0 |
| `0x00eca8` | [vm_func_00eca8](func_00eca8.c) | `uint64_t vm_func_00eca8(uint64_t arg0, uint64_t arg1, uint64_t arg2)` | 1 | 3 |
| `0x00f149` | [vm_func_00f149](func_00f149.c) | `void vm_func_00f149(void* arg0, uint64_t arg1)` | 2 | 0 |
| `0x00f19b` | [vm_func_00f19b](func_00f19b.c) | `void vm_func_00f19b(const void* arg0)` | 2 | 0 |
| `0x00f209` | [vm_func_00f209](func_00f209.c) | `uint64_t vm_func_00f209(uint64_t dst, uint64_t arg1, uint64_t arg2, uint64_t arg3)` | 1 | 0 |
| `0x00f6f0` | [vm_func_00f6f0](func_00f6f0.c) | `uint64_t vm_func_00f6f0(uint64_t src, uint64_t size, uint64_t arg2)` | 2 | 5 |
| `0x00fb4b` | [vm_func_00fb4b](func_00fb4b.c) | `uint64_t vm_func_00fb4b(const void* arg0)` | 1 | 0 |
| `0x00fb8d` | [vm_func_00fb8d](func_00fb8d.c) | `uint64_t vm_func_00fb8d(const void* arg0)` | 1 | 4 |
| `0x00fff6` | [vm_func_00fff6](func_00fff6.c) | `void vm_func_00fff6(void* arg0)` | 1 | 1 |
| `0x0100f2` | [vm_func_0100f2](func_0100f2.c) | `uint64_t vm_func_0100f2(uint64_t arg0)` | 2 | 2 |
| `0x0101a2` | [vm_func_0101a2](func_0101a2.c) | `uint64_t vm_func_0101a2(uint64_t arg0, uint64_t arg1)` | 1 | 1 |
| `0x0101fa` | [vm_func_0101fa](func_0101fa.c) | `void vm_func_0101fa(const void* arg0)` | 1 | 1 |
| `0x01026c` | [vm_func_01026c](func_01026c.c) | `void vm_func_01026c(uint64_t arg0, uint64_t arg1, uint64_t arg2)` | 2 | 0 |
| `0x0102fc` | [vm_func_0102fc](func_0102fc.c) | `uint64_t vm_func_0102fc(const void* arg0, uint64_t arg1)` | 1 | 0 |
| `0x010356` | [vm_func_010356](func_010356.c) | `uint64_t vm_func_010356(const void* arg0)` | 1 | 0 |
| `0x01039c` | [vm_func_01039c](func_01039c.c) | `uint64_t vm_func_01039c(const void* arg0)` | 1 | 0 |
| `0x0103de` | [vm_func_0103de](func_0103de.c) | `uint64_t vm_func_0103de(uint64_t arg0, uint64_t arg1)` | 2 | 0 |
| `0x0107ec` | [vm_func_0107ec](func_0107ec.c) | `void vm_func_0107ec(void* arg0)` | 1 | 5 |
| `0x010a3f` | [vm_func_010a3f](func_010a3f.c) | `uint64_t vm_func_010a3f(const void* arg0)` | 1 | 0 |
| `0x010a81` | [vm_func_010a81](func_010a81.c) | `uint64_t vm_func_010a81(const void* arg0)` | 1 | 0 |
| `0x010ac7` | [vm_func_010ac7](func_010ac7.c) | `void vm_func_010ac7(void* arg0)` | 1 | 1 |
| `0x011100` | [vm_func_011100](func_011100.c) | `void vm_func_011100(void)` | 1 | 1 |
| `0x01122f` | [vm_func_01122f](func_01122f.c) | `uint64_t vm_func_01122f(uint64_t path)` | 3 | 0 |
| `0x01137f` | [vm_func_01137f](func_01137f.c) | `uint64_t vm_func_01137f(uint64_t path)` | 4 | 0 |
| `0x0114c0` | [vm_func_0114c0](func_0114c0.c) | `uint64_t vm_func_0114c0(uint64_t path, uint64_t arg1)` | 2 | 0 |
| `0x011743` | [vm_func_011743](func_011743.c) | `uint64_t vm_func_011743(uint64_t arg0)` | 3 | 1 |
| `0x0117fc` | [vm_func_0117fc](func_0117fc.c) | `uint64_t vm_func_0117fc(uint64_t arg0)` | 1 | 2 |
| `0x011909` | [vm_func_011909](func_011909.c) | `uint64_t vm_func_011909(void)` | 1 | 4 |
| `0x012436` | [vm_func_012436](func_012436.c) | `uint64_t vm_func_012436(void)` | 1 | 1 |
| `0x01279c` | [vm_func_01279c](func_01279c.c) | `uint64_t vm_func_01279c(uint64_t arg0, uint64_t arg1, uint64_t arg2, uint64_t arg3)` | 1 | 4 |
| `0x012bf1` | [vm_func_012bf1](func_012bf1.c) | `uint64_t vm_func_012bf1(uint64_t arg0)` | 3 | 2 |
| `0x012ca1` | [vm_func_012ca1](func_012ca1.c) | `uint64_t vm_func_012ca1(const void* arg0, uint64_t arg1)` | 3 | 0 |
| `0x012cfb` | [vm_func_012cfb](func_012cfb.c) | `uint64_t vm_func_012cfb(uint64_t arg0, uint64_t arg1)` | 2 | 1 |
| `0x012d53` | [vm_func_012d53](func_012d53.c) | `uint64_t vm_func_012d53(const void* arg0)` | 1 | 0 |
| `0x012d99` | [vm_func_012d99](func_012d99.c) | `uint64_t vm_func_012d99(const void* arg0)` | 1 | 0 |
| `0x012ddb` | [vm_func_012ddb](func_012ddb.c) | `void vm_func_012ddb(uint64_t arg0, uint8_t* arg1, uint8_t* arg2, uint64_t arg3)` | 1 | 1 |
| `0x01336e` | [vm_func_01336e](func_01336e.c) | `uint64_t vm_func_01336e(const void* arg0)` | 4 | 0 |
| `0x0133b0` | [vm_func_0133b0](func_0133b0.c) | `uint64_t vm_func_0133b0(const void* arg0)` | 4 | 0 |
| `0x0133f6` | [vm_func_0133f6](func_0133f6.c) | `uint64_t vm_func_0133f6(uint64_t pid, uint64_t tid)` | 1 | 1 |
| `0x0134a7` | [vm_func_0134a7](func_0134a7.c) | `uint64_t vm_func_0134a7(uint64_t arg0, uint64_t arg1)` | 1 | 3 |
| `0x013825` | [vm_func_013825](func_013825.c) | `uint64_t vm_func_013825(void)` | 1 | 19 |
| `0x015b6e` | [vm_func_015b6e](func_015b6e.c) | `void vm_func_015b6e(void* arg0)` | 1 | 1 |
| `0x015c6a` | [vm_func_015c6a](func_015c6a.c) | `void vm_func_015c6a(void* arg0, uint64_t src)` | 1 | 1 |
| `0x015d5e` | [vm_func_015d5e](func_015d5e.c) | `void vm_func_015d5e(const void* arg0)` | 1 | 1 |
| `0x015dd0` | [vm_func_015dd0](func_015dd0.c) | `void vm_func_015dd0(uint64_t arg0, uint64_t arg1, uint64_t arg2)` | 2 | 0 |
| `0x015e60` | [vm_func_015e60](func_015e60.c) | `void vm_func_015e60(void* arg0)` | 1 | 5 |
| `0x0160b3` | [vm_func_0160b3](func_0160b3.c) | `uint64_t vm_func_0160b3(uint64_t arg0, uint64_t arg1)` | 2 | 0 |
| `0x01614e` | [vm_func_01614e](func_01614e.c) | `void vm_func_01614e(void* arg0)` | 1 | 1 |
| `0x0166d2` | [vm_func_0166d2](func_0166d2.c) | `void vm_func_0166d2(void)` | 1 | 0 |
| `0x0167c7` | [vm_func_0167c7](func_0167c7.c) | `void vm_func_0167c7(void)` | 1 | 2 |
| `0x016a03` | [vm_func_016a03](func_016a03.c) | `void vm_func_016a03(void* arg0, uint64_t arg1)` | 1 | 1 |
| `0x016b06` | [vm_func_016b06](func_016b06.c) | `void vm_func_016b06(void)` | 2 | 3 |
| `0x016ef1` | [vm_func_016ef1](func_016ef1.c) | `void vm_func_016ef1(void* arg0)` | 2 | 1 |
| `0x016fa4` | [vm_func_016fa4](func_016fa4.c) | `uint64_t vm_func_016fa4(uint64_t arg0)` | 3 | 2 |
| `0x017049` | [vm_func_017049](func_017049.c) | `void vm_func_017049(void* arg0, VmU64Pair* src)` | 1 | 1 |
| `0x01713d` | [vm_func_01713d](func_01713d.c) | `void vm_func_01713d(void* arg0)` | 1 | 5 |
| `0x017397` | [vm_func_017397](func_017397.c) | `uint64_t vm_func_017397(uint64_t arg0, uint64_t arg1)` | 2 | 0 |
| `0x017439` | [vm_func_017439](func_017439.c) | `uint64_t vm_func_017439(const void* arg0)` | 1 | 0 |
| `0x01747b` | [vm_func_01747b](func_01747b.c) | `uint64_t vm_func_01747b(const void* arg0)` | 1 | 0 |
| `0x0174c1` | [vm_func_0174c1](func_0174c1.c) | `uint64_t vm_func_0174c1(const void* arg0)` | 1 | 0 |
| `0x017507` | [vm_func_017507](func_017507.c) | `uint64_t vm_func_017507(const void* arg0)` | 1 | 0 |
| `0x017549` | [vm_func_017549](func_017549.c) | `void vm_func_017549(uint64_t arg0, uint64_t arg1, uint64_t arg2)` | 1 | 0 |
| `0x0175d9` | [vm_func_0175d9](func_0175d9.c) | `void vm_func_0175d9(const void* arg0)` | 1 | 3 |
| `0x017d64` | [vm_func_017d64](func_017d64.c) | `uint64_t vm_func_017d64(const void* arg0, uint64_t arg1)` | 1 | 0 |
| `0x017dc5` | [vm_func_017dc5](func_017dc5.c) | `void vm_func_017dc5(const void* arg0)` | 1 | 0 |
| `0x018fef` | [vm_func_018fef](func_018fef.c) | `void vm_func_018fef(void)` | 1 | 1 |
| `0x019d33` | [vm_func_019d33](func_019d33.c) | `void vm_func_019d33(void)` | 1 | 1 |
| `0x019eb6` | [vm_func_019eb6](func_019eb6.c) | `uint64_t vm_func_019eb6(uint64_t arg0, uint64_t arg1)` | 1 | 1 |
| `0x01a037` | [vm_func_01a037](func_01a037.c) | `uint64_t vm_func_01a037(uint8_t* arg0, uint64_t arg1)` | 1 | 0 |
| `0x01a18b` | [vm_func_01a18b](func_01a18b.c) | `void vm_func_01a18b(void* arg0)` | 1 | 2 |
| `0x01aae7` | [vm_func_01aae7](func_01aae7.c) | `void vm_func_01aae7(void)` | 1 | 2 |
| `0x01af0e` | [vm_func_01af0e](func_01af0e.c) | `void vm_func_01af0e(void)` | 1 | 1 |
| `0x01aff7` | [vm_func_01aff7](func_01aff7.c) | `void vm_func_01aff7(void)` | 1 | 0 |
| `0x01b207` | [vm_func_01b207](func_01b207.c) | `void vm_func_01b207(uint64_t arg0)` | 1 | 17 |
| `0x01cd5c` | [vm_func_01cd5c](func_01cd5c.c) | `uint64_t vm_func_01cd5c(uint64_t arg0)` | 1 | 16 |
| `0x01e621` | [vm_func_01e621](func_01e621.c) | `void vm_func_01e621(void)` | 1 | 1 |
| `0x01e68a` | [vm_func_01e68a](func_01e68a.c) | `void vm_func_01e68a(void)` | 1 | 1 |
| `0x01e964` | [vm_func_01e964](func_01e964.c) | `uint64_t vm_func_01e964(uint64_t path, uint64_t arg1)` | 1 | 0 |
| `0x01ea47` | [vm_func_01ea47](func_01ea47.c) | `void vm_func_01ea47(void)` | 1 | 1 |
| `0x01eab0` | [vm_func_01eab0](func_01eab0.c) | `void vm_func_01eab0(void)` | 1 | 0 |
| `0x01f352` | [vm_func_01f352](func_01f352.c) | `void vm_func_01f352(void)` | 1 | 0 |
| `0x01ffdb` | [vm_func_01ffdb](func_01ffdb.c) | `void vm_func_01ffdb(void)` | 1 | 0 |
| `0x020441` | [vm_func_020441](func_020441.c) | `void vm_func_020441(void)` | 1 | 0 |
| `0x0204d3` | [vm_func_0204d3](func_0204d3.c) | `void vm_func_0204d3(const char* arg0)` | 1 | 2 |
| `0x020fa8` | [vm_func_020fa8](func_020fa8.c) | `uint64_t vm_func_020fa8(uint64_t arg0, uint64_t arg1)` | 1 | 0 |
| `0x021198` | [vm_func_021198](func_021198.c) | `uint64_t vm_func_021198(uint64_t arg0, uint64_t arg1, uint64_t arg2)` | 1 | 0 |
| `0x023125` | [vm_func_023125](func_023125.c) | `uint64_t vm_func_023125(const void* arg0, uint64_t arg1)` | 1 | 0 |
| `0x02348e` | [vm_func_02348e](func_02348e.c) | `uint64_t vm_func_02348e(void)` | 2 | 0 |
| `0x02358a` | [vm_func_02358a](func_02358a.c) | `uint64_t vm_func_02358a(uint64_t arg0)` | 2 | 1 |
| `0x0235fe` | [vm_func_0235fe](func_0235fe.c) | `uint64_t vm_func_0235fe(uint64_t arg0)` | 1 | 2 |
| `0x02367f` | [vm_func_02367f](func_02367f.c) | `uint64_t vm_func_02367f(uint64_t arg0, uint64_t arg1)` | 2 | 2 |
| `0x0237da` | [vm_func_0237da](func_0237da.c) | `uint64_t vm_func_0237da(uint64_t arg0)` | 2 | 1 |
| `0x023988` | [vm_func_023988](func_023988.c) | `void vm_func_023988(uint64_t arg0, uint64_t arg1)` | 1 | 0 |
| `0x024292` | [vm_func_024292](func_024292.c) | `uint64_t vm_func_024292(uint64_t arg0)` | 2 | 1 |
| `0x024579` | [vm_func_024579](func_024579.c) | `uint64_t vm_func_024579(void)` | 1 | 0 |
| `0x0246da` | [vm_func_0246da](func_0246da.c) | `uint64_t vm_func_0246da(uint64_t arg0, uint64_t arg1, uint64_t arg2, uint64_t arg3, uint64_t arg4)` | 1 | 2 |
| `0x02483d` | [vm_func_02483d](func_02483d.c) | `uint64_t vm_func_02483d(const void* arg0, uint64_t arg1, uint64_t arg2, uint64_t arg3, uint64_t arg4)` | 1 | 5 |
| `0x024d98` | [vm_func_024d98](func_024d98.c) | `uint64_t vm_func_024d98(uint64_t arg0, uint64_t string)` | 1 | 1 |
| `0x02504d` | [vm_func_02504d](func_02504d.c) | `uint64_t vm_func_02504d(uint64_t arg0, uint64_t string)` | 1 | 1 |
| `0x02547f` | [vm_func_02547f](func_02547f.c) | `uint64_t vm_func_02547f(const void* arg0, const void* arg1, uint64_t string, uint64_t arg3, uint64_t arg4, uint64_t arg5, uint64_t arg6, uint64_t arg7)` | 2 | 2 |
| `0x025ab8` | [vm_func_025ab8](func_025ab8.c) | `void vm_func_025ab8(void* arg0, uint64_t arg1, uint64_t arg2)` | 1 | 0 |
| `0x025b32` | [vm_func_025b32](func_025b32.c) | `uint64_t vm_func_025b32(uint64_t arg0, const void* arg1)` | 1 | 1 |
| `0x025c75` | [vm_func_025c75](func_025c75.c) | `void vm_func_025c75(uint64_t arg0, uint64_t arg1, uint64_t arg2)` | 1 | 2 |
| `0x026293` | [vm_func_026293](func_026293.c) | `uint64_t vm_func_026293(uint64_t arg0, uint64_t arg1)` | 1 | 0 |
| `0x0264cb` | [vm_func_0264cb](func_0264cb.c) | `uint64_t vm_func_0264cb(uint64_t arg0, uint64_t arg1)` | 1 | 0 |
| `0x0268f1` | [vm_func_0268f1](func_0268f1.c) | `uint64_t vm_func_0268f1(uint64_t arg0)` | 1 | 0 |
| `0x0269ce` | [vm_func_0269ce](func_0269ce.c) | `uint64_t vm_func_0269ce(uint64_t arg0)` | 1 | 0 |
| `0x026ad1` | [vm_func_026ad1](func_026ad1.c) | `void vm_func_026ad1(uint64_t arg0)` | 2 | 0 |
| `0x026b80` | [vm_func_026b80](func_026b80.c) | `void vm_func_026b80(void* arg0, uint64_t arg1, uint64_t arg2, uint64_t arg3)` | 1 | 0 |
| `0x026c1e` | [vm_func_026c1e](func_026c1e.c) | `void vm_func_026c1e(void* arg0)` | 1 | 0 |
| `0x026c7c` | [vm_func_026c7c](func_026c7c.c) | `void vm_func_026c7c(const void* arg0)` | 1 | 0 |
| `0x026cce` | [vm_func_026cce](func_026cce.c) | `uint64_t vm_func_026cce(const void* arg0)` | 1 | 0 |
| `0x026d28` | [vm_func_026d28](func_026d28.c) | `uint64_t vm_func_026d28(const void* arg0, uint64_t arg1, uint64_t arg2, uint64_t arg3, uint64_t arg4, uint64_t arg5, uint64_t arg6, uint64_t arg7)` | 1 | 0 |
| `0x026ef7` | [vm_func_026ef7](func_026ef7.c) | `void vm_func_026ef7(uint64_t arg0, uint64_t arg1, uint64_t arg2, uint64_t arg3, uint64_t arg4, uint64_t arg5, uint64_t arg6, uint64_t arg7)` | 4 | 1 |
| `0x0270de` | [vm_func_0270de](func_0270de.c) | `void vm_func_0270de(void)` | 1 | 0 |
| `0x027b4a` | [vm_func_027b4a](func_027b4a.c) | `void vm_func_027b4a(void)` | 1 | 0 |
| `0x027fcf` | [vm_func_027fcf](func_027fcf.c) | `void vm_func_027fcf(void)` | 1 | 2 |
| `0x0283ea` | [vm_func_0283ea](func_0283ea.c) | `void vm_func_0283ea(void)` | 1 | 0 |
| `0x02847c` | [vm_func_02847c](func_02847c.c) | `void vm_func_02847c(void* arg0, uint64_t arg1)` | 2 | 1 |
| `0x02857f` | [vm_func_02857f](func_02857f.c) | `void vm_func_02857f(void* arg0, VmU64Pair* src)` | 2 | 1 |
| `0x028673` | [vm_func_028673](func_028673.c) | `void vm_func_028673(void* arg0)` | 1 | 5 |
| `0x0288cd` | [vm_func_0288cd](func_0288cd.c) | `uint64_t vm_func_0288cd(uint64_t arg0)` | 3 | 2 |
| `0x028972` | [vm_func_028972](func_028972.c) | `uint64_t vm_func_028972(uint64_t arg0, uint64_t arg1)` | 2 | 0 |
| `0x028a14` | [vm_func_028a14](func_028a14.c) | `uint64_t vm_func_028a14(const void* arg0)` | 1 | 0 |
| `0x028a56` | [vm_func_028a56](func_028a56.c) | `uint64_t vm_func_028a56(const void* arg0)` | 1 | 0 |
| `0x028a9c` | [vm_func_028a9c](func_028a9c.c) | `void vm_func_028a9c(void* arg0)` | 1 | 1 |
| `0x028b4f` | [vm_func_028b4f](func_028b4f.c) | `void vm_func_028b4f(uint64_t arg0, uint64_t arg1, uint64_t arg2)` | 1 | 0 |
| `0x028bdf` | [vm_func_028bdf](func_028bdf.c) | `uint64_t vm_func_028bdf(const void* arg0)` | 1 | 0 |
| `0x028c25` | [vm_func_028c25](func_028c25.c) | `uint64_t vm_func_028c25(const void* arg0)` | 1 | 0 |
| `0x029d66` | [vm_func_029d66](func_029d66.c) | `uint64_t vm_func_029d66(uint64_t arg0)` | 1 | 1 |
| `0x029e3c` | [vm_func_029e3c](func_029e3c.c) | `uint64_t vm_func_029e3c(const void* arg0, uint64_t arg1)` | 2 | 0 |
| `0x029e9d` | [vm_func_029e9d](func_029e9d.c) | `uint64_t vm_func_029e9d(uint64_t arg0, const void* arg1)` | 1 | 0 |
| `0x02a03e` | [vm_func_02a03e](func_02a03e.c) | `void vm_func_02a03e(void)` | 1 | 0 |
| `0x02a83d` | [vm_func_02a83d](func_02a83d.c) | `void vm_func_02a83d(void)` | 1 | 2 |
| `0x02acf4` | [vm_func_02acf4](func_02acf4.c) | `void vm_func_02acf4(void)` | 1 | 1 |
| `0x02b304` | [vm_func_02b304](func_02b304.c) | `uint64_t vm_func_02b304(uint64_t arg0, uint64_t arg1)` | 2 | 0 |
| `0x02bc84` | [vm_func_02bc84](func_02bc84.c) | `void vm_func_02bc84(void)` | 1 | 0 |
| `0x02c99f` | [vm_func_02c99f](func_02c99f.c) | `void vm_func_02c99f(void)` | 1 | 3 |
| `0x02c9ef` | [vm_func_02c9ef](func_02c9ef.c) | `void vm_func_02c9ef(void)` | 1 | 0 |
| `0x02cfe9` | [vm_func_02cfe9](func_02cfe9.c) | `void vm_func_02cfe9(void)` | 1 | 1 |
| `0x02d179` | [vm_func_02d179](func_02d179.c) | `void vm_func_02d179(void)` | 1 | 1 |
| `0x02ec4c` | [vm_func_02ec4c](func_02ec4c.c) | `uint64_t vm_func_02ec4c(uint64_t arg0, uint64_t arg1)` | 1 | 0 |
| `0x02f828` | [vm_func_02f828](func_02f828.c) | `uint64_t vm_func_02f828(uint64_t arg0, uint64_t arg1)` | 1 | 0 |
| `0x02f918` | [vm_func_02f918](func_02f918.c) | `uint64_t vm_func_02f918(uint64_t arg0, const void* arg1)` | 1 | 0 |
| `0x02faa7` | [vm_func_02faa7](func_02faa7.c) | `uint64_t vm_func_02faa7(uint64_t arg0, uint64_t arg1, uint64_t arg2, uint64_t dst, uint64_t arg4)` | 1 | 2 |
| `0x030d2a` | [vm_func_030d2a](func_030d2a.c) | `uint64_t vm_func_030d2a(const void* arg0)` | 1 | 0 |
| `0x032a90` | [vm_func_032a90](func_032a90.c) | `void vm_func_032a90(void)` | 1 | 2 |
| `0x032c0f` | [vm_func_032c0f](func_032c0f.c) | `void vm_func_032c0f(void)` | 1 | 5 |
| `0x032dce` | [vm_func_032dce](func_032dce.c) | `void vm_func_032dce(void)` | 1 | 3 |
| `0x03300d` | [vm_func_03300d](func_03300d.c) | `uint64_t vm_func_03300d(uint64_t arg0)` | 3 | 0 |
| `0x03305e` | [vm_func_03305e](func_03305e.c) | `void vm_func_03305e(uint64_t arg0, uint64_t arg1)` | 1 | 0 |
| `0x0330d4` | [vm_func_0330d4](func_0330d4.c) | `void vm_func_0330d4(uint64_t arg0, uint64_t arg1, uint8_t* arg2)` | 1 | 0 |
| `0x03315e` | [vm_func_03315e](func_03315e.c) | `uint64_t vm_func_03315e(void)` | 1 | 0 |
| `0x0331a8` | [vm_func_0331a8](func_0331a8.c) | `void vm_func_0331a8(void* arg0, uint64_t arg1)` | 1 | 1 |
| `0x0332b7` | [vm_func_0332b7](func_0332b7.c) | `void vm_func_0332b7(void* arg0)` | 1 | 1 |
| `0x0333b6` | [vm_func_0333b6](func_0333b6.c) | `void vm_func_0333b6(VmU64Pair* arg0, void* arg1, uint64_t arg2)` | 1 | 1 |
| `0x03351d` | [vm_func_03351d](func_03351d.c) | `void vm_func_03351d(uint64_t arg0, uint64_t arg1, uint64_t arg2, uint64_t arg3)` | 1 | 0 |
| `0x0335b7` | [vm_func_0335b7](func_0335b7.c) | `void vm_func_0335b7(void)` | 1 | 1 |

## 其他 / 动态路径函数

| 地址 | 函数 | 原型 | Callers | Callees |
|---:|---|---|---:|---:|
| `0x003541` | [vm_func_003541](func_003541.c) | `uint64_t vm_func_003541(const void* arg0, uint64_t arg1)` | 1 | 0 |
| `0x0035d8` | [vm_func_0035d8](func_0035d8.c) | `uint64_t vm_func_0035d8(const void* arg0, uint64_t arg1, uint64_t arg2, uint64_t arg3)` | 1 | 0 |
| `0x0036a7` | [vm_func_0036a7](func_0036a7.c) | `void vm_func_0036a7(const void* arg0, uint64_t arg1, uint64_t arg2, uint64_t arg3)` | 1 | 0 |
| `0x003b19` | [vm_func_003b19](func_003b19.c) | `uint64_t vm_func_003b19(const void* arg0, uint64_t arg1, uint64_t arg2)` | 3 | 0 |
| `0x003bcc` | [vm_func_003bcc](func_003bcc.c) | `uint64_t vm_func_003bcc(const void* arg0, uint64_t arg1, uint64_t arg2, uint64_t arg3)` | 2 | 0 |
| `0x003c97` | [vm_func_003c97](func_003c97.c) | `uint64_t vm_func_003c97(const void* arg0, uint64_t arg1, uint64_t arg2)` | 1 | 0 |
| `0x003d46` | [vm_func_003d46](func_003d46.c) | `uint64_t vm_func_003d46(const void* arg0, uint64_t arg1, uint64_t arg2)` | 2 | 0 |
| `0x003df9` | [vm_func_003df9](func_003df9.c) | `void vm_func_003df9(const void* arg0, uint64_t arg1, uint64_t arg2, uint64_t arg3, uint64_t arg4, uint64_t arg5, uint64_t arg6)` | 1 | 0 |
| `0x004037` | [vm_func_004037](func_004037.c) | `uint64_t vm_func_004037(const void* arg0, uint64_t arg1, uint64_t arg2, uint64_t arg3, uint64_t arg4, uint64_t arg5, uint64_t arg6)` | 1 | 0 |
| `0x00415a` | [vm_func_00415a](func_00415a.c) | `uint64_t vm_func_00415a(const void* arg0, uint64_t arg1, uint64_t arg2, uint64_t arg3, uint64_t arg4, uint64_t arg5, uint64_t arg6)` | 1 | 0 |
| `0x00427d` | [vm_func_00427d](func_00427d.c) | `uint64_t vm_func_00427d(const void* arg0, uint64_t arg1, uint64_t arg2, uint64_t arg3, uint64_t arg4, uint64_t arg5, uint64_t arg6)` | 1 | 0 |
| `0x0043a0` | [vm_func_0043a0](func_0043a0.c) | `uint64_t vm_func_0043a0(const void* arg0, uint64_t arg1, uint64_t arg2, uint64_t arg3, uint64_t arg4, uint64_t arg5, uint64_t arg6)` | 1 | 0 |
| `0x0045e6` | [vm_func_0045e6](func_0045e6.c) | `uint64_t vm_func_0045e6(const void* arg0, uint64_t arg1, uint64_t arg2, uint64_t arg3, uint64_t arg4, uint64_t arg5, uint64_t arg6)` | 1 | 0 |
| `0x004705` | [vm_func_004705](func_004705.c) | `void vm_func_004705(const void* arg0, uint64_t arg1, uint64_t arg2, uint64_t arg3, uint64_t arg4, uint64_t arg5, uint64_t arg6)` | 1 | 0 |
| `0x004943` | [vm_func_004943](func_004943.c) | `uint64_t vm_func_004943(const void* arg0, uint64_t arg1, uint64_t arg2, uint64_t arg3, uint64_t arg4, uint64_t arg5, uint64_t arg6)` | 1 | 0 |
| `0x004a66` | [vm_func_004a66](func_004a66.c) | `uint64_t vm_func_004a66(const void* arg0, uint64_t arg1, uint64_t arg2, uint64_t arg3, uint64_t arg4, uint64_t arg5, uint64_t arg6)` | 1 | 0 |
| `0x004b89` | [vm_func_004b89](func_004b89.c) | `uint64_t vm_func_004b89(const void* arg0, uint64_t arg1, uint64_t arg2, uint64_t arg3, uint64_t arg4, uint64_t arg5, uint64_t arg6)` | 1 | 0 |
| `0x004cac` | [vm_func_004cac](func_004cac.c) | `uint64_t vm_func_004cac(const void* arg0, uint64_t arg1, uint64_t arg2, uint64_t arg3, uint64_t arg4, uint64_t arg5, uint64_t arg6)` | 1 | 0 |
| `0x004dcf` | [vm_func_004dcf](func_004dcf.c) | `uint64_t vm_func_004dcf(const void* arg0, uint64_t arg1, uint64_t arg2, uint64_t arg3, uint64_t arg4, uint64_t arg5, uint64_t arg6)` | 1 | 0 |
| `0x004ef2` | [vm_func_004ef2](func_004ef2.c) | `uint64_t vm_func_004ef2(const void* arg0, uint64_t arg1, uint64_t arg2, uint64_t arg3, uint64_t arg4, uint64_t arg5, uint64_t arg6)` | 1 | 0 |
| `0x005206` | [vm_func_005206](func_005206.c) | `void vm_func_005206(const void* arg0, uint64_t arg1, uint64_t arg2, uint64_t arg3, uint64_t arg4)` | 1 | 0 |
| `0x0052f5` | [vm_func_0052f5](func_0052f5.c) | `uint64_t vm_func_0052f5(const void* arg0, uint64_t arg1, uint64_t arg2)` | 1 | 0 |
| `0x0053a8` | [vm_func_0053a8](func_0053a8.c) | `void vm_func_0053a8(const void* arg0, uint64_t arg1)` | 0 | 0 |
| `0x00543f` | [vm_func_00543f](func_00543f.c) | `void vm_func_00543f(const void* arg0, uint64_t arg1, uint64_t arg2)` | 0 | 0 |
| `0x0054f2` | [vm_func_0054f2](func_0054f2.c) | `void vm_func_0054f2(const void* arg0)` | 0 | 0 |
| `0x005559` | [vm_func_005559](func_005559.c) | `void vm_func_005559(const void* arg0)` | 0 | 0 |
| `0x005725` | [vm_func_005725](func_005725.c) | `void vm_func_005725(const void* arg0, uint64_t arg1, uint64_t arg2, uint64_t arg3, uint64_t arg4, uint64_t arg5, uint64_t arg6, uint64_t arg7)` | 0 | 0 |
| `0x005878` | [vm_func_005878](func_005878.c) | `void vm_func_005878(const void* arg0, uint64_t arg1, uint64_t arg2, uint64_t arg3, uint64_t arg4, uint64_t arg5, uint64_t arg6, uint64_t arg7)` | 0 | 0 |
| `0x0059cb` | [vm_func_0059cb](func_0059cb.c) | `void vm_func_0059cb(uint64_t arg0, uint64_t arg1, uint64_t arg2)` | 0 | 2 |
| `0x005a8d` | [vm_func_005a8d](func_005a8d.c) | `void vm_func_005a8d(uint64_t arg0, uint64_t arg1, uint64_t arg2)` | 0 | 3 |
| `0x005bed` | [vm_func_005bed](func_005bed.c) | `void vm_func_005bed(uint64_t arg0, uint64_t arg1, uint64_t arg2)` | 0 | 2 |
| `0x005caf` | [vm_func_005caf](func_005caf.c) | `void vm_func_005caf(uint64_t arg0, uint64_t arg1)` | 0 | 2 |
| `0x005d75` | [vm_func_005d75](func_005d75.c) | `void vm_func_005d75(uint64_t arg0, uint64_t arg1, uint64_t arg2, uint64_t arg3, uint64_t arg4, uint64_t arg5, uint64_t arg6, uint64_t arg7)` | 0 | 2 |
| `0x005efb` | [vm_func_005efb](func_005efb.c) | `void vm_func_005efb(uint64_t arg0, uint64_t arg1, uint64_t arg2, uint64_t arg3, uint64_t arg4, uint64_t arg5, uint64_t arg6, uint64_t arg7)` | 0 | 2 |
| `0x006081` | [vm_func_006081](func_006081.c) | `void vm_func_006081(const void* arg0, uint64_t arg1, uint64_t arg2)` | 0 | 0 |
| `0x006120` | [vm_func_006120](func_006120.c) | `void vm_func_006120(const void* arg0, uint64_t arg1, uint64_t arg2)` | 0 | 0 |
| `0x0061c3` | [vm_func_0061c3](func_0061c3.c) | `void vm_func_0061c3(const void* arg0, uint64_t arg1, uint64_t arg2)` | 0 | 0 |
| `0x0063c4` | [vm_func_0063c4](func_0063c4.c) | `void vm_func_0063c4(const void* arg0, uint64_t arg1)` | 0 | 0 |
| `0x006447` | [vm_func_006447](func_006447.c) | `uint64_t vm_func_006447(const char* string)` | 2 | 0 |
| `0x0065e2` | [vm_func_0065e2](func_0065e2.c) | `uint64_t vm_func_0065e2(uint64_t arg0, uint64_t arg1, uint64_t arg2, uint64_t arg3, uint64_t arg4, uint64_t arg5, uint64_t arg6, uint64_t arg7)` | 1 | 8 |
| `0x0069ce` | [vm_func_0069ce](func_0069ce.c) | `uint64_t vm_func_0069ce(uint64_t arg0, uint64_t arg1)` | 3 | 1 |
| `0x006a36` | [vm_func_006a36](func_006a36.c) | `uint64_t vm_func_006a36(uint64_t arg0)` | 13 | 1 |
| `0x006a7e` | [vm_func_006a7e](func_006a7e.c) | `void vm_func_006a7e(uint64_t arg0)` | 13 | 1 |
| `0x006ac6` | [vm_func_006ac6](func_006ac6.c) | `void vm_func_006ac6(const void* arg0, uint64_t arg1)` | 11 | 2 |
| `0x006be8` | [vm_func_006be8](func_006be8.c) | `uint64_t vm_func_006be8(uint64_t arg0, uint64_t arg1, uint64_t arg2, uint64_t arg3, uint64_t arg4, uint64_t arg5, uint64_t arg6, uint64_t arg7)` | 1 | 9 |
| `0x007279` | [vm_func_007279](func_007279.c) | `void vm_func_007279(const void* arg0)` | 11 | 9 |
| `0x00743e` | [vm_func_00743e](func_00743e.c) | `void vm_func_00743e(void* arg0)` | 1 | 0 |
| `0x007484` | [vm_func_007484](func_007484.c) | `void vm_func_007484(uint64_t arg0, uint64_t arg1)` | 1 | 1 |
| `0x0074dc` | [vm_func_0074dc](func_0074dc.c) | `void vm_func_0074dc(uint64_t arg0, uint64_t arg1)` | 1 | 1 |
| `0x007558` | [vm_func_007558](func_007558.c) | `void vm_func_007558(uint64_t arg0, uint64_t arg1)` | 1 | 1 |
| `0x0075b0` | [vm_func_0075b0](func_0075b0.c) | `uint64_t vm_func_0075b0(const void* arg0, const void* arg1)` | 1 | 0 |
| `0x007612` | [vm_func_007612](func_007612.c) | `uint64_t vm_func_007612(uint64_t arg0)` | 1 | 1 |
| `0x00765a` | [vm_func_00765a](func_00765a.c) | `void vm_func_00765a(uint64_t arg0, uint64_t arg1, uint64_t arg2)` | 1 | 2 |
| `0x0076f0` | [vm_func_0076f0](func_0076f0.c) | `void vm_func_0076f0(uint64_t arg0)` | 1 | 1 |
| `0x007738` | [vm_func_007738](func_007738.c) | `void vm_func_007738(uint64_t arg0)` | 1 | 1 |
| `0x007780` | [vm_func_007780](func_007780.c) | `void vm_func_007780(void* arg0)` | 1 | 1 |
| `0x0077f4` | [vm_func_0077f4](func_0077f4.c) | `void vm_func_0077f4(void* arg0, uint64_t arg1)` | 2 | 2 |
| `0x00798e` | [vm_func_00798e](func_00798e.c) | `void vm_func_00798e(uint64_t arg0, uint64_t arg1)` | 2 | 2 |
| `0x007ac9` | [vm_func_007ac9](func_007ac9.c) | `void vm_func_007ac9(void* arg0, uint64_t arg1)` | 1 | 1 |
| `0x007b2d` | [vm_func_007b2d](func_007b2d.c) | `void vm_func_007b2d(void* arg0)` | 1 | 2 |
| `0x007c00` | [vm_func_007c00](func_007c00.c) | `uint64_t vm_func_007c00(uint64_t arg0, uint64_t arg1)` | 1 | 0 |
| `0x007d1d` | [vm_func_007d1d](func_007d1d.c) | `uint64_t vm_func_007d1d(uint64_t arg0, uint64_t arg1)` | 1 | 1 |
| `0x007f72` | [vm_func_007f72](func_007f72.c) | `void vm_func_007f72(void* arg0, uint64_t arg1)` | 2 | 0 |
| `0x007fec` | [vm_func_007fec](func_007fec.c) | `uint64_t vm_func_007fec(const void* arg0)` | 1 | 0 |
| `0x008032` | [vm_func_008032](func_008032.c) | `void vm_func_008032(uint64_t arg0, uint64_t arg1)` | 1 | 1 |
| `0x00808e` | [vm_func_00808e](func_00808e.c) | `void vm_func_00808e(void* arg0, uint64_t arg1)` | 2 | 0 |
| `0x0080e0` | [vm_func_0080e0](func_0080e0.c) | `void vm_func_0080e0(uint64_t arg0, const void* arg1)` | 1 | 2 |
| `0x008172` | [vm_func_008172](func_008172.c) | `uint64_t vm_func_008172(uint64_t arg0, uint64_t arg1)` | 1 | 0 |
| `0x00828f` | [vm_func_00828f](func_00828f.c) | `uint64_t vm_func_00828f(uint64_t arg0, uint64_t arg1, uint64_t arg2, uint64_t arg3, uint64_t arg4, uint64_t arg5, uint64_t arg6)` | 1 | 1 |
| `0x008347` | [vm_func_008347](func_008347.c) | `void vm_func_008347(void* arg0, const void* arg1, uint64_t arg2)` | 1 | 0 |
| `0x0083c1` | [vm_func_0083c1](func_0083c1.c) | `void vm_func_0083c1(uint64_t arg0, uint64_t arg1)` | 1 | 1 |
| `0x008419` | [vm_func_008419](func_008419.c) | `void vm_func_008419(void* arg0, uint64_t arg1)` | 1 | 4 |
| `0x0085b2` | [vm_func_0085b2](func_0085b2.c) | `uint64_t vm_func_0085b2(uint64_t arg0, uint64_t arg1, uint64_t arg2)` | 1 | 3 |
| `0x009408` | [vm_func_009408](func_009408.c) | `uint64_t vm_func_009408(uint64_t arg0, uint64_t arg1, uint64_t arg2)` | 1 | 0 |
| `0x00953e` | [vm_func_00953e](func_00953e.c) | `void vm_func_00953e(uint64_t arg0, uint64_t arg1)` | 1 | 1 |
| `0x009596` | [vm_func_009596](func_009596.c) | `void vm_func_009596(void* arg0, uint64_t arg1)` | 1 | 0 |
| `0x009628` | [vm_func_009628](func_009628.c) | `void vm_func_009628(void* arg0, uint64_t arg1, uint64_t arg2, uint64_t arg3, uint64_t arg4)` | 11 | 2 |
| `0x00973e` | [vm_func_00973e](func_00973e.c) | `void vm_func_00973e(uint64_t arg0)` | 1 | 1 |
| `0x009786` | [vm_func_009786](func_009786.c) | `void vm_func_009786(uint64_t arg0, uint64_t arg1, uint64_t arg2, uint64_t arg3)` | 1 | 0 |
| `0x0097f8` | [vm_func_0097f8](func_0097f8.c) | `void vm_func_0097f8(void* arg0)` | 1 | 0 |
| `0x009846` | [vm_func_009846](func_009846.c) | `void vm_func_009846(uint64_t arg0, uint64_t arg1, uint64_t arg2, uint64_t arg3, uint64_t arg4, uint64_t arg5, uint64_t arg6, uint64_t arg7)` | 0 | 8 |
| `0x009c32` | [vm_func_009c32](func_009c32.c) | `uint64_t vm_func_009c32(uint64_t arg0, uint64_t arg1)` | 3 | 1 |
| `0x009c9a` | [vm_func_009c9a](func_009c9a.c) | `uint64_t vm_func_009c9a(uint64_t arg0, uint64_t arg1, uint64_t arg2, uint64_t arg3, uint64_t arg4, uint64_t arg5, uint64_t arg6, uint64_t arg7)` | 1 | 9 |
| `0x00a32b` | [vm_func_00a32b](func_00a32b.c) | `uint64_t vm_func_00a32b(uint64_t arg0, uint64_t arg1, uint64_t arg2, uint64_t arg3, uint64_t arg4, uint64_t arg5, uint64_t arg6)` | 1 | 1 |
| `0x00a3e3` | [vm_func_00a3e3](func_00a3e3.c) | `uint64_t vm_func_00a3e3(uint64_t arg0, uint64_t arg1, uint64_t arg2, uint64_t arg3)` | 1 | 9 |
| `0x00a7e4` | [vm_func_00a7e4](func_00a7e4.c) | `uint64_t vm_func_00a7e4(uint64_t arg0, uint64_t arg1, uint64_t arg2)` | 1 | 1 |
| `0x00a85c` | [vm_func_00a85c](func_00a85c.c) | `uint64_t vm_func_00a85c(uint64_t arg0, uint64_t arg1, uint64_t arg2, uint64_t arg3)` | 1 | 7 |
| `0x00aab1` | [vm_func_00aab1](func_00aab1.c) | `uint64_t vm_func_00aab1(uint64_t arg0, uint64_t arg1, uint64_t arg2, uint64_t arg3)` | 2 | 5 |
| `0x00ad2d` | [vm_func_00ad2d](func_00ad2d.c) | `uint64_t vm_func_00ad2d(uint64_t arg0, uint64_t arg1, uint64_t arg2)` | 1 | 1 |
| `0x00ada5` | [vm_func_00ada5](func_00ada5.c) | `void vm_func_00ada5(uint64_t arg0, uint64_t arg1, uint64_t arg2, uint64_t arg3)` | 0 | 7 |
| `0x00affa` | [vm_func_00affa](func_00affa.c) | `void vm_func_00affa(uint64_t arg0, uint64_t arg1, uint64_t arg2)` | 0 | 7 |
| `0x00b22a` | [vm_func_00b22a](func_00b22a.c) | `uint64_t vm_func_00b22a(uint64_t arg0, uint64_t arg1)` | 3 | 2 |
| `0x00b3b0` | [vm_func_00b3b0](func_00b3b0.c) | `void vm_func_00b3b0(uint64_t arg0, uint64_t arg1, uint64_t arg2)` | 0 | 7 |
| `0x00b5a4` | [vm_func_00b5a4](func_00b5a4.c) | `void vm_func_00b5a4(uint64_t arg0, uint64_t arg1, uint64_t arg2)` | 0 | 7 |
| `0x00b7a8` | [vm_func_00b7a8](func_00b7a8.c) | `void vm_func_00b7a8(uint64_t arg0, uint64_t arg1)` | 0 | 1 |
| `0x00b826` | [vm_func_00b826](func_00b826.c) | `void vm_func_00b826(uint64_t arg0, uint64_t arg1, uint64_t arg2, uint64_t arg3, uint64_t arg4, uint64_t arg5, uint64_t arg6, uint64_t arg7)` | 1 | 8 |
| `0x00bc6b` | [vm_func_00bc6b](func_00bc6b.c) | `uint64_t vm_func_00bc6b(uint64_t arg0, uint64_t arg1, uint64_t arg2, uint64_t arg3, uint64_t arg4, uint64_t arg5, uint64_t arg6)` | 1 | 1 |
| `0x00bd23` | [vm_func_00bd23](func_00bd23.c) | `void vm_func_00bd23(uint64_t arg0, uint64_t arg1)` | 0 | 1 |
| `0x00bd8b` | [vm_func_00bd8b](func_00bd8b.c) | `void vm_func_00bd8b(uint64_t arg0, uint64_t arg1)` | 0 | 1 |
| `0x00bdf3` | [vm_func_00bdf3](func_00bdf3.c) | `void vm_func_00bdf3(uint64_t arg0, uint64_t arg1, uint64_t arg2)` | 0 | 1 |
| `0x00be6b` | [vm_func_00be6b](func_00be6b.c) | `void vm_func_00be6b(uint64_t arg0, uint64_t arg1, uint64_t arg2, uint64_t arg3)` | 0 | 1 |
| `0x00bef3` | [vm_func_00bef3](func_00bef3.c) | `void vm_func_00bef3(uint64_t arg0, uint64_t arg1, uint64_t arg2, uint64_t arg3)` | 0 | 1 |
| `0x00bf6b` | [vm_func_00bf6b](func_00bf6b.c) | `void vm_func_00bf6b(uint64_t arg0, uint64_t arg1, uint64_t arg2, uint64_t arg3)` | 0 | 1 |
| `0x00bff3` | [vm_func_00bff3](func_00bff3.c) | `void vm_func_00bff3(uint64_t arg0, uint64_t arg1)` | 0 | 1 |
| `0x00c04b` | [vm_func_00c04b](func_00c04b.c) | `void vm_func_00c04b(uint64_t arg0, uint64_t arg1, uint64_t arg2, uint64_t arg3, uint64_t arg4)` | 0 | 1 |
| `0x00c0d3` | [vm_func_00c0d3](func_00c0d3.c) | `void vm_func_00c0d3(uint64_t arg0, uint64_t arg1)` | 0 | 1 |
| `0x00c12b` | [vm_func_00c12b](func_00c12b.c) | `void vm_func_00c12b(uint64_t arg0, uint64_t arg1, uint64_t arg2)` | 0 | 8 |
| `0x00c42e` | [vm_func_00c42e](func_00c42e.c) | `void vm_func_00c42e(uint64_t arg0)` | 0 | 2 |
| `0x00c4e2` | [vm_func_00c4e2](func_00c4e2.c) | `void vm_func_00c4e2(uint64_t arg0, uint64_t arg1)` | 0 | 1 |
| `0x00c575` | [vm_func_00c575](func_00c575.c) | `void vm_func_00c575(uint64_t arg0)` | 0 | 10 |
| `0x00cd36` | [vm_func_00cd36](func_00cd36.c) | `void vm_func_00cd36(const void* arg0)` | 0 | 0 |
| `0x00cd90` | [vm_func_00cd90](func_00cd90.c) | `void vm_func_00cd90(void* arg0, uint64_t arg1)` | 0 | 0 |
| `0x00e82f` | [vm_func_00e82f](func_00e82f.c) | `void vm_func_00e82f(uint64_t arg0, uint64_t arg1, uint64_t arg2, uint64_t arg3)` | 0 | 4 |
| `0x00ebb1` | [vm_func_00ebb1](func_00ebb1.c) | `void vm_func_00ebb1(void* arg0, uint64_t arg1)` | 0 | 0 |
| `0x013183` | [vm_func_013183](func_013183.c) | `void vm_func_013183(uint64_t arg0, uint64_t arg1, uint64_t arg2)` | 0 | 2 |
| `0x01a142` | [vm_func_01a142](func_01a142.c) | `void vm_func_01a142(uint64_t arg0)` | 0 | 0 |
| `0x023400` | [vm_func_023400](func_023400.c) | `void vm_func_023400(const void* arg0)` | 0 | 0 |
| `0x026e1f` | [vm_func_026e1f](func_026e1f.c) | `void vm_func_026e1f(const void* arg0, uint64_t arg1, uint64_t arg2, uint64_t arg3, uint64_t arg4, uint64_t arg5, uint64_t arg6, uint64_t arg7)` | 0 | 1 |
