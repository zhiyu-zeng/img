void vm_func_016a03(void* arg0, uint64_t arg1) {
    *(uint64_t *)(arg0) = 0x0;
    *(uint64_t *)(arg0 + 0x8) = 0x0;
    *(uint64_t *)(arg0 + 0x10) = 0x0;
    ptr_016a97 = vm_func_017397(arg0, arg1);
    *(uint64_t *)(arg0) = ptr_016a97;
    *(uint64_t *)(arg0 + 0x8) = ptr_016a97;
    *(uint64_t *)(arg0 + 0x10) = (ptr_016a97 + (arg1 << 0x4));
    return;
}
