void vm_func_00be6b(uint64_t arg0, uint64_t arg1, uint64_t arg2, uint64_t arg3) {
    local_20 = vm_func_0035d8(arg0, arg1, arg2, arg3);
    return;
}
