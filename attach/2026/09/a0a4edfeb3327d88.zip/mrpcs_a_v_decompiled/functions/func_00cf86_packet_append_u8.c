uint64_t packet_append_u8(void* arg0, uint64_t arg1) {
    if (((int32_t)((*(uint32_t *)(arg0 + 0x10) - *(uint32_t *)(arg0 + 0x14)))) > 1) {
        *(uint32_t *)(arg0 + 0x14) = (*(uint32_t *)(arg0 + 0x14) + 0x1);
        *(uint8_t *)(*(uint64_t *)(arg0) + (int64_t)(*(uint32_t *)(arg0 + 0x14))) = arg1;
        result = 0x1;
    } else {
        result = 0x0;
    }
    return result;
}
