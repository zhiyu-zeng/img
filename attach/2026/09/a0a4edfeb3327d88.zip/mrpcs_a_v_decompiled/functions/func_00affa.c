void vm_func_00affa(uint64_t arg0, uint64_t arg1, uint64_t arg2) {
    memcpy_checked((fp + 0x38), &g_01f0, 0x8);
    local_48 = vm_func_00a85c(arg0, arg1, arg2, "Ljava/lang/String;");
    local_40 = local_48;
    if (local_48 == 0x0) {
        vm_func_006a7e(arg0);
        local_18 = 0x0;
    } else {
        if (vm_func_006a36(arg0) == 0x0) {
            vm_call_reg(0x9628);
            vm_func_006ac6((fp + 0x50), local_40);
            local_18 = vm_func_00b22a(arg0, local_40);
            vm_call_reg(0x7279);
        } else {
            vm_func_006a7e(arg0);
            local_18 = 0x0;
            return;
        }
    }
    return;
}
