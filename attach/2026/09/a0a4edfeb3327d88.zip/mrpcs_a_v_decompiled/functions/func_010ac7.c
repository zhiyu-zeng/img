void vm_func_010ac7(void* arg0) {
    vm_func_01026c(arg0, *(uint64_t *)(arg0), (((*(uint64_t *)(arg0 + 0x10) - *(uint64_t *)(arg0)) >> 0x3) * 0x6db6db6db6db6db7));
    *(uint64_t *)(arg0) = 0x0;
    *(uint64_t *)(arg0 + 0x8) = 0x0;
    *(uint64_t *)(arg0 + 0x10) = 0x0;
    return;
}
