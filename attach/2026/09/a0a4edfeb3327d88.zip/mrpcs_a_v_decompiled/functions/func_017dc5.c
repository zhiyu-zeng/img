void vm_func_017dc5(const void* arg0) {
    local_68 = *(uint64_t *)(arg0);
    local_70 = ((*(uint64_t *)(arg0 + 0x8) - *(uint64_t *)(arg0)) >> 0x3);
    index_78 = 0x0;
    while (((int64_t)((int64_t)(index_78))) < ((int64_t)(local_70))) {
        local_80 = *(uint64_t *)(local_68 + ((int64_t)(index_78) << 0x3));
        if (*(uint64_t *)(local_68 + ((int64_t)(index_78) << 0x3)) != 0x0) {
            local_88 = *(uint8_t *)(local_80);
            if (*(uint8_t *)(local_80) == 0x4) {
                local_89 = *(uint8_t *)(local_80 + 0x1);
                if (*(uint8_t *)(local_80 + 0x1) == 0x8) {
                    local_8a = (*(uint8_t *)(local_80 + 0x1d0) & 0x1);
                    if (*(uint8_t *)(local_80 + 0x1d0) & 0x1) {
                        local_8b = *(uint8_t *)(local_80 + 0x129);
                        local_8c = *(uint16_t *)(local_80 + 0x2);
                        local_90 = *(uint64_t *)(local_80 + 0x78);
                        local_98 = (local_80 + 0xc8);
                        local_a0 = *(uint64_t *)(local_80 + 0xf0);
                        local_a8 = *(uint64_t *)(local_80 + 0x78);
                        local_b0 = *(uint8_t *)(local_80 + 0x45);
                        local_b4 = *(uint32_t *)(local_80 + 0x158);
                        if (memcmp((local_80 + 0xc8), *(uint64_t *)(local_80 + 0x78), *(uint64_t *)(local_80 + 0xf0)) != 0x0) {
                            g_05d0 = (g_05d0 + 0x1);
                        }
                        local_b8 = *(uint32_t *)(local_90);
                        if (*(uint32_t *)(local_90) == 0x58000050) {
                            local_c0 = *(uint64_t *)(local_90 + 0x8);
                            local_c8 = *(uint32_t *)(*(uint64_t *)(local_90 + 0x8));
                            if (*(uint32_t *)(*(uint64_t *)(local_90 + 0x8)) != 0xa93e77fe) {
                                g_05d1 = (g_05d1 + 0x1);
                            }
                            if (local_8b == 0x2) {
                                index_cc = 0x0;
                                while (((int32_t)(index_cc)) <= 39) {
                                    local_d0 = *(uint32_t *)(local_c0 + (int64_t)((index_cc << 0x2)));
                                    if (*(uint32_t *)(local_c0 + (int64_t)((index_cc << 0x2))) != *(uint32_t *)(((int64_t)(index_cc) << 0x2) + &g_1404)) {
                                        g_05e0 = (g_05e0 + 0x1);
                                        g_05d8 = local_d0;
                                        g_05dc = local_8c;
                                    }
                                    index_cc = (index_cc + 0x1);
                                    continue;
                                }
                                local_d8 = *(uint64_t *)(local_c0 + 0xa0);
                                *(uint32_t *)((g_13f8 << 0x2) + &g_05e4) = local_b4;
                                *(uint64_t *)((g_13f8 << 0x3) + &g_0a98) = *(uint64_t *)(local_c0 + 0xa0);
                                g_13f8 = (g_13f8 + 0x1);
                            }
                            if (local_8b == 0x0) {
                                index_e0 = 0x0;
                                while (((int32_t)(index_e0)) <= 38) {
                                    local_e4 = *(uint32_t *)(local_c0 + (int64_t)((index_e0 << 0x2)));
                                    if (*(uint32_t *)(local_c0 + (int64_t)((index_e0 << 0x2))) != *(uint32_t *)(((int64_t)(index_e0) << 0x2) + &g_14a4)) {
                                        g_05e0 = (g_05e0 + 0x1);
                                        g_05d8 = local_e4;
                                        g_05dc = local_8c;
                                    }
                                    index_e0 = (index_e0 + 0x1);
                                    continue;
                                }
                            }
                        }
                        if (local_b0 == 0x0) {
                            g_05d2 = (g_05d2 + 0x1);
                        }
                    }
                }
            }
        }
        index_78 = (index_78 + 0x1);
        continue;
    }
    return;
}
