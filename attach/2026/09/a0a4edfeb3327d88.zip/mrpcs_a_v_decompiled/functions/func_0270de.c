void vm_func_0270de(void) {
    g_2498 = &g_2494;
    g_27c8 = "/libc.so";
    g_27d0 = "__loader_shared_globals";
    g_27d8 = "/libdl_android.so";
    g_27e0 = "__loader_android_get_LD_LIBRARY_PATH";
    g_27e8 = "/libdl.so";
    g_27f0 = "__loader_android_get_LD_LIBRARY_PATH";
    g_27f8 = "/libEGL.so";
    g_2800 = "atrace_get_enabled_tags";
    g_2ea0 = resolve_symbol("libdl.so", "dl_iterate_phdr");
    g_2eb8 = resolve_symbol("libc.so", "strstr");
    g_2ec8 = resolve_symbol("libc.so", "sscanf");
    g_2ed8 = resolve_symbol("libc.so", "strdup");
    g_2ee8 = resolve_symbol("libc.so", "strchr");
    register_vm_callback(0x27319, 0x6c72, 0xb);
    register_vm_callback(0x27601, 0x6c73, 0x1, 0x78);
    return;
}
