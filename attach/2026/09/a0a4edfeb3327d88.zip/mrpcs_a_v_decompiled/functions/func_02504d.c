uint64_t vm_func_02504d(uint64_t arg0, uint64_t string) {
    local_20 = vm_func_0268f1(string);
    local_28 = *(uint64_t *)(*(uint64_t *)(arg0 + 0xa0) + (((((local_20) / (uint64_t)(*(uint32_t *)("@")))) % (uint64_t)(*(uint32_t *)(arg0 + 0xa8))) << 0x3));
    local_30 = ((0x1 << ((local_20) % (uint64_t)(*(uint32_t *)("@")))) | (0x1 << (((local_20 >> *(uint32_t *)(arg0 + 0xac))) % (uint64_t)(*(uint32_t *)("@")))));
    if ((*(uint64_t *)(*(uint64_t *)(arg0 + 0xa0) + (((((local_20) / (uint64_t)(*(uint32_t *)("@")))) % (uint64_t)(*(uint32_t *)(arg0 + 0xa8))) << 0x3)) & ((0x1 << ((local_20) % (uint64_t)(*(uint32_t *)("@")))) | (0x1 << (((local_20 >> *(uint32_t *)(arg0 + 0xac))) % (uint64_t)(*(uint32_t *)("@")))))) == ((0x1 << ((local_20) % (uint64_t)(*(uint32_t *)("@")))) | (0x1 << (((local_20 >> *(uint32_t *)(arg0 + 0xac))) % (uint64_t)(*(uint32_t *)("@")))))) {
        local_38 = *(uint32_t *)(*(uint64_t *)(arg0 + 0x80) + (((local_20) % (uint64_t)(*(uint32_t *)(arg0 + 0x88))) << 0x2));
        if (((uint32_t)(*(uint32_t *)(*(uint64_t *)(arg0 + 0x80) + (((local_20) % (uint64_t)(*(uint32_t *)(arg0 + 0x88))) << 0x2)))) >= ((uint32_t)(*(uint32_t *)(arg0 + 0x98)))) {
            while (true) {
                local_40 = (*(uint64_t *)(arg0 + 0x50) + (local_38 * 0x18));
                local_48 = (*(uint8_t *)((*(uint64_t *)(arg0 + 0x50) + (local_38 * 0x18)) + 0x4) & 0xf);
                local_4c = *(uint32_t *)(*(uint64_t *)(arg0 + 0x90) + ((local_38 - *(uint32_t *)(arg0 + 0x98)) << 0x2));
                if ((local_20 | 0x1) != (*(uint32_t *)(*(uint64_t *)(arg0 + 0x90) + ((local_38 - *(uint32_t *)(arg0 + 0x98)) << 0x2)) | 0x1)) {
                } else {
                    if (local_48 == 0x2) {
                        compare_result_0253ac = strcmp((*(uint64_t *)(arg0 + 0x58) + *(uint32_t *)(local_40)), string);
                        if (compare_result_0253ac != 0x0) {
                            if (!(local_4c & 0x1)) {
                                local_38 = (local_38 + 0x1);
                                continue;
                            } else {
                                result = 0x0;
                                goto loc_025427;
                            }
                        } else {
                            result = local_40;
                            goto loc_025427;
                        }
                    } else {
                        if (local_48 == 0xa) {
                            compare_result_0253ac = strcmp((*(uint64_t *)(arg0 + 0x58) + *(uint32_t *)(local_40)), string);
                            goto loc_025360;
                        } else {
                            if (local_48 != 0x0) {
                                goto loc_0253c7;
                            } else {
                                compare_result_0253ac = strcmp((*(uint64_t *)(arg0 + 0x58) + *(uint32_t *)(local_40)), string);
                                goto loc_025360;
                            }
                        }
                    }
                }
                goto loc_0253c7;
            }
        } else {
            result = 0x0;
        }
    } else {
        result = 0x0;
    }
    loc_025427:
    return result;
}
