uint64_t bswap32(uint64_t arg0, uint64_t arg1) {
    return ((((arg1 >> 0x18) | ((arg1 & 0xff0000) >> 0x8)) | ((arg1 & 0xff00) << 0x8)) | (arg1 << 0x18));
}
