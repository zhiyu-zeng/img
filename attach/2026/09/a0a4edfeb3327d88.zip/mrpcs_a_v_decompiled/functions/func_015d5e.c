void vm_func_015d5e(const void* arg0) {
    vm_func_015dd0(arg0, *(uint64_t *)(arg0), (((*(uint64_t *)(arg0 + 0x10) - *(uint64_t *)(arg0)) >> 0x2) * 0xcccccccccccccccd));
    return;
}
