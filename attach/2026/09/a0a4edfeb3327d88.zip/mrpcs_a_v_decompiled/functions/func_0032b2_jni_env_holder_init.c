void jni_env_holder_init(void* arg0, uint64_t arg1) {
    *(uint64_t *)(arg0) = arg1;
    *(uint64_t *)(arg0) = arg1;
    return;
}
