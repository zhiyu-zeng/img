void vm_func_0083c1(uint64_t arg0, uint64_t arg1) {
    vm_func_008419(arg0, arg1);
    return;
}
