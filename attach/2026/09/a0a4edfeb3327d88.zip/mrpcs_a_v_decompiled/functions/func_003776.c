uint64_t vm_func_003776(const void* arg0, uint64_t arg1) {
    VmU64Pair u64_pair_010;
    u64_pair_010.first = arg1;
    u64_pair_010.second = 0x0;
    return dispatch_registered_handler(0x1c, *(uint64_t *)(arg0), &u64_pair_010, 0x1);
}
