uint64_t vm_func_00b22a(uint64_t arg0, uint64_t arg1) {
    src_28 = vm_func_005011(arg0, arg1, 0x0);
    if (src_28 == 0x0) {
        *(uint8_t *)(&g_020b) = 0x0;
    } else {
        strncpy(&g_020b, src_28, 0x100);
    }
    vm_func_0050c0(arg0, arg1, src_28);
    return &g_020b;
}
