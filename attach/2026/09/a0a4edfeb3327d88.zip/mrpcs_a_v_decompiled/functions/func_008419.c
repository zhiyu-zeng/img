void vm_func_008419(void* arg0, uint64_t arg1) {
    ptr_18 = vm_func_0085b2(arg0, arg1, 0x0);
    if (ptr_18 != 0x0) {
        if (*(uint64_t *)(arg0) != 0x0) {
            local_20 = rb_tree_insert_link_unique(arg0, ptr_18);
            if (local_20 == 0x0) {
                rb_tree_insert_fixup(arg0, ptr_18, arg0);
                *(uint64_t *)(arg0 + 0x8) = (*(uint64_t *)(arg0 + 0x8) + 0x1);
            } else {
                vm_func_00798e(arg0, ptr_18);
            }
        } else {
            *(uint64_t *)(arg0) = ptr_18;
            *(uint32_t *)(ptr_18 + 0x28) = 0x1;
            *(uint64_t *)(arg0 + 0x8) = 0x1;
        }
    }
    return;
}
