void vm_func_00f149(void* arg0, uint64_t arg1) {
    *(uint64_t *)(arg0) = arg1;
    return;
}
