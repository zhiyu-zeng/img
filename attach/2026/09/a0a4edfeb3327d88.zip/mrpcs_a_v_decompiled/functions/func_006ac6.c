void vm_func_006ac6(const void* arg0, uint64_t arg1) {
    if (*(uint64_t *)(arg0) != 0x0) {
        if (arg1 != 0x0) {
            local_30 = 0x1;
            vm_func_008347((fp + 0x20), (fp + 0x18), (fp + 0x30));
            vm_func_0083c1((arg0 + 0x8), (fp + 0x20));
        }
    }
    return;
}
