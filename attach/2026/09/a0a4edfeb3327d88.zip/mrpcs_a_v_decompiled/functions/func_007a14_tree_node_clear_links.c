void tree_node_clear_links(void* arg0) {
    *(uint64_t *)(arg0) = 0x0;
    *(uint64_t *)(arg0 + 0x8) = 0x0;
    *(uint64_t *)(arg0 + 0x10) = 0x0;
    return;
}
