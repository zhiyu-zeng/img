void vm_func_007b2d(void* arg0) {
    local_10 = vm_func_007c00(arg0, *(uint64_t *)(*(uint64_t *)(arg0) + 0x10));
    if (local_10 == 0x0) {
        *(uint64_t *)(arg0) = vm_func_007d1d(arg0, *(uint64_t *)(arg0));
    } else {
        *(uint64_t *)(arg0) = local_10;
    }
    return;
}
