uint64_t vm_func_019eb6(uint64_t arg0, uint64_t arg1) {
    result = 0x0;
    result = vm_func_00f6f0(arg0, arg1, &g_1630);
    if (result == 0x0) {
        index_20 = 0x0;
        while (((uint64_t)(index_20)) <= 0x2) {
            result = vm_func_00f6f0(arg0, arg1, &g_1630);
            if (result == 0x0) {
                index_20 = (index_20 + 0x1);
                continue;
            }
        }
    }
    return result;
}
