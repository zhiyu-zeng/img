uint64_t vm_func_02348e(void) {
    if (g_2450 == 0x0) {
        fn_ptr_0234fd = resolve_symbol("libc.so", "sysconf");
    }
    g_2450 = ((g_2450 == 0x0) ? fn_ptr_0234fd : g_2450);
    if (((g_2450 == 0x0) ? fn_ptr_0234fd : g_2450) == 0x0) {
        result = 0x1000;
    } else {
        result = call_native_n(g_2450, 0x27);
    }
    return result;
}
