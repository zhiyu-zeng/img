uint64_t vm_func_01cd5c(uint64_t arg0) {
    vm_call_reg(0x2d80);
    jni_env_holder_48 = jni_get_or_create_env_holder((fp + 0x28));
    if (jni_env_holder_48 != 0x0) {
        if (arg0 != 0x0) {
            local_54 = 0x0;
            local_58 = vm_func_00330c(jni_env_holder_48, "android/app/ActivityThread");
            if (local_58 != 0x0) {
                local_60 = vm_func_0038d4(jni_env_holder_48, local_58, "currentApplication", "()Landroid/app/Application;");
                if (local_60 != 0x0) {
                    local_68 = vm_func_004824(jni_env_holder_48, local_58, local_60, 0x0, 0x0, 0x0, 0x0);
                    vm_func_005692(jni_env_holder_48, local_58);
                    if (local_68 != 0x0) {
                        local_70 = vm_func_003776(jni_env_holder_48, local_68);
                        if (local_70 != 0x0) {
                            local_78 = vm_func_003809(jni_env_holder_48, local_70, "getPackageName", "()Ljava/lang/String;");
                            if (local_78 != 0x0) {
                                local_80 = vm_func_003f18(jni_env_holder_48, local_68, local_78, 0x0, 0x0, 0x0, 0x0);
                                if (local_80 != 0x0) {
                                    local_88 = vm_func_003809(jni_env_holder_48, local_70, "getPackageManager", "()Landroid/content/pm/PackageManager;");
                                    if (local_88 != 0x0) {
                                        local_90 = vm_func_003f18(jni_env_holder_48, local_68, local_88, 0x0, 0x0, 0x0, 0x0);
                                        if (local_90 != 0x0) {
                                            vm_func_005692(jni_env_holder_48, local_70);
                                            local_98 = vm_func_003776(jni_env_holder_48, local_90);
                                            if (local_98 != 0x0) {
                                                local_a0 = vm_func_003809(jni_env_holder_48, local_98, "getApplicationInfo", "(Ljava/lang/String;I)Landroid/content/pm/ApplicationInfo;");
                                                if (local_a0 != 0x0) {
                                                    local_a8 = 0x80;
                                                    local_b0 = vm_func_003f18(jni_env_holder_48, local_90, local_a0, local_80, 0x80, 0x0, 0x0);
                                                    if (vm_func_0055c0(jni_env_holder_48) != 0x0) {
                                                        vm_func_00562b(jni_env_holder_48);
                                                    }
                                                    vm_func_005692(jni_env_holder_48, local_80);
                                                    vm_func_005692(jni_env_holder_48, local_90);
                                                    vm_func_005692(jni_env_holder_48, local_98);
                                                    if (local_b0 != 0x0) {
                                                        local_b8 = vm_func_003776(jni_env_holder_48, local_b0);
                                                        if (local_b8 != 0x0) {
                                                            local_c0 = vm_func_00399f(jni_env_holder_48, local_b8, "metaData", "Landroid/os/Bundle;");
                                                            if (local_c0 != 0x0) {
                                                                local_c8 = vm_func_003a6a(jni_env_holder_48, local_b0, local_c0);
                                                                if (vm_func_0055c0(jni_env_holder_48) != 0x0) {
                                                                    vm_func_00562b(jni_env_holder_48);
                                                                }
                                                                vm_func_005692(jni_env_holder_48, local_b0);
                                                                vm_func_005692(jni_env_holder_48, local_b8);
                                                                if (local_c8 != 0x0) {
                                                                    local_d0 = vm_func_003776(jni_env_holder_48, local_c8);
                                                                    if (local_d0 != 0x0) {
                                                                        local_d8 = vm_func_003809(jni_env_holder_48, local_d0, "getInt", "(Ljava/lang/String;)I");
                                                                        if (local_d8 != 0x0) {
                                                                            local_e0 = vm_func_0034ae(jni_env_holder_48, arg0);
                                                                            if (local_e0 != 0x0) {
                                                                                local_54 = vm_func_0044c3(jni_env_holder_48, local_c8, local_d8, local_e0, 0x0, 0x0, 0x0);
                                                                                if (local_54 == 0x0) {
                                                                                    if (vm_func_0055c0(jni_env_holder_48) != 0x0) {
                                                                                        vm_func_00562b(jni_env_holder_48);
                                                                                    }
                                                                                }
                                                                                vm_func_005692(jni_env_holder_48, local_e0);
                                                                                vm_func_005692(jni_env_holder_48, local_c8);
                                                                                vm_func_005692(jni_env_holder_48, local_d0);
                                                                                vm_func_005692(jni_env_holder_48, local_68);
                                                                                result = local_54;
                                                                                local_50 = 0x1;
                                                                            } else {
                                                                                if (vm_func_0055c0(jni_env_holder_48) != 0x0) {
                                                                                    vm_func_00562b(jni_env_holder_48);
                                                                                }
                                                                                vm_func_005692(jni_env_holder_48, local_c8);
                                                                                vm_func_005692(jni_env_holder_48, local_d0);
                                                                                vm_func_005692(jni_env_holder_48, local_68);
                                                                                result = local_54;
                                                                                local_50 = 0x1;
                                                                            }
                                                                        } else {
                                                                            if (vm_func_0055c0(jni_env_holder_48) != 0x0) {
                                                                                vm_func_00562b(jni_env_holder_48);
                                                                            }
                                                                            vm_func_005692(jni_env_holder_48, local_c8);
                                                                            vm_func_005692(jni_env_holder_48, local_d0);
                                                                            vm_func_005692(jni_env_holder_48, local_68);
                                                                            result = local_54;
                                                                            local_50 = 0x1;
                                                                        }
                                                                    } else {
                                                                        if (vm_func_0055c0(jni_env_holder_48) != 0x0) {
                                                                            vm_func_00562b(jni_env_holder_48);
                                                                        }
                                                                        vm_func_005692(jni_env_holder_48, local_c8);
                                                                        vm_func_005692(jni_env_holder_48, local_68);
                                                                        result = local_54;
                                                                        local_50 = 0x1;
                                                                    }
                                                                } else {
                                                                    if (vm_func_0055c0(jni_env_holder_48) != 0x0) {
                                                                        vm_func_00562b(jni_env_holder_48);
                                                                    }
                                                                    vm_func_005692(jni_env_holder_48, local_68);
                                                                    result = local_54;
                                                                    local_50 = 0x1;
                                                                }
                                                            } else {
                                                                if (vm_func_0055c0(jni_env_holder_48) != 0x0) {
                                                                    vm_func_00562b(jni_env_holder_48);
                                                                }
                                                                vm_func_005692(jni_env_holder_48, local_68);
                                                                vm_func_005692(jni_env_holder_48, local_b0);
                                                                vm_func_005692(jni_env_holder_48, local_b8);
                                                                result = local_54;
                                                                local_50 = 0x1;
                                                            }
                                                        } else {
                                                            if (vm_func_0055c0(jni_env_holder_48) != 0x0) {
                                                                vm_func_00562b(jni_env_holder_48);
                                                            }
                                                            vm_func_005692(jni_env_holder_48, local_b0);
                                                            vm_func_005692(jni_env_holder_48, local_68);
                                                            result = local_54;
                                                            local_50 = 0x1;
                                                        }
                                                    } else {
                                                        if (vm_func_0055c0(jni_env_holder_48) != 0x0) {
                                                            vm_func_00562b(jni_env_holder_48);
                                                        }
                                                        vm_func_005692(jni_env_holder_48, local_68);
                                                        result = local_54;
                                                        local_50 = 0x1;
                                                    }
                                                } else {
                                                    if (vm_func_0055c0(jni_env_holder_48) != 0x0) {
                                                        vm_func_00562b(jni_env_holder_48);
                                                    }
                                                    vm_func_005692(jni_env_holder_48, local_80);
                                                    vm_func_005692(jni_env_holder_48, local_68);
                                                    vm_func_005692(jni_env_holder_48, local_90);
                                                    vm_func_005692(jni_env_holder_48, local_98);
                                                    result = local_54;
                                                    local_50 = 0x1;
                                                }
                                            } else {
                                                if (vm_func_0055c0(jni_env_holder_48) != 0x0) {
                                                    vm_func_00562b(jni_env_holder_48);
                                                }
                                                vm_func_005692(jni_env_holder_48, local_80);
                                                vm_func_005692(jni_env_holder_48, local_68);
                                                vm_func_005692(jni_env_holder_48, local_90);
                                                result = local_54;
                                                local_50 = 0x1;
                                            }
                                        } else {
                                            if (vm_func_0055c0(jni_env_holder_48) != 0x0) {
                                                vm_func_00562b(jni_env_holder_48);
                                            }
                                            vm_func_005692(jni_env_holder_48, local_80);
                                            vm_func_005692(jni_env_holder_48, local_68);
                                            vm_func_005692(jni_env_holder_48, local_70);
                                            result = local_54;
                                            local_50 = 0x1;
                                        }
                                    } else {
                                        if (vm_func_0055c0(jni_env_holder_48) != 0x0) {
                                            vm_func_00562b(jni_env_holder_48);
                                        }
                                        vm_func_005692(jni_env_holder_48, local_80);
                                        vm_func_005692(jni_env_holder_48, local_68);
                                        vm_func_005692(jni_env_holder_48, local_70);
                                        result = local_54;
                                        local_50 = 0x1;
                                    }
                                } else {
                                    if (vm_func_0055c0(jni_env_holder_48) != 0x0) {
                                        vm_func_00562b(jni_env_holder_48);
                                    }
                                    vm_func_005692(jni_env_holder_48, local_70);
                                    vm_func_005692(jni_env_holder_48, local_68);
                                    result = local_54;
                                    local_50 = 0x1;
                                }
                            } else {
                                if (vm_func_0055c0(jni_env_holder_48) != 0x0) {
                                    vm_func_00562b(jni_env_holder_48);
                                }
                                vm_func_005692(jni_env_holder_48, local_70);
                                vm_func_005692(jni_env_holder_48, local_68);
                                result = local_54;
                                local_50 = 0x1;
                            }
                        } else {
                            if (vm_func_0055c0(jni_env_holder_48) != 0x0) {
                                vm_func_00562b(jni_env_holder_48);
                            }
                            vm_func_005692(jni_env_holder_48, local_68);
                            result = local_54;
                            local_50 = 0x1;
                        }
                    } else {
                        if (vm_func_0055c0(jni_env_holder_48) != 0x0) {
                            vm_func_00562b(jni_env_holder_48);
                        }
                        result = local_54;
                        local_50 = 0x1;
                    }
                } else {
                    if (vm_func_0055c0(jni_env_holder_48) != 0x0) {
                        vm_func_00562b(jni_env_holder_48);
                    }
                    vm_func_005692(jni_env_holder_48, local_58);
                    result = local_54;
                    local_50 = 0x1;
                }
            } else {
                if (vm_func_0055c0(jni_env_holder_48) != 0x0) {
                    vm_func_00562b(jni_env_holder_48);
                }
                result = local_54;
                local_50 = 0x1;
            }
        } else {
            result = 0x0;
            local_50 = 0x1;
        }
    } else {
        result = 0x0;
        local_50 = 0x1;
    }
    vm_call_reg(0x2dea);
    return result;
}
