uint64_t vm_func_01279c(uint64_t arg0, uint64_t arg1, uint64_t arg2, uint64_t arg3) {
    struct { union { uint64_t word_00; struct { uint32_t field_00; uint32_t field_04; }; uint8_t byte_00[8]; }; union { uint8_t tail_08[12]; struct { uint32_t field_08; uint32_t field_0c; uint32_t field_10; }; }; } record20_100;
    uint8_t* stack_buf_071 = (uint8_t*)(fp + 0x71); /* observed >= 0x80 bytes */
    result = 0x0;
    memset(stack_buf_071, 0x0, 0x80);
    snprintf(stack_buf_071, 0x80, arg1, arg0);
    if (vm_func_011743(stack_buf_071) == 0x0) {
        result = 0x1;
        index_f8 = 0x0;
        while (true) {
            if (((uint64_t)(index_f8)) >= ((uint64_t)(vm_func_012bf1(arg3)))) break;
            memcpy_checked(&record20_100, vm_func_012ca1(arg3, index_f8), 0x14);
            if ((record20_100.word_00 & 0x21) != 0x0) {
                if ((record20_100.word_00 & 0x42) == 0x0) {
                    memset(stack_buf_071, 0x0, 0x80);
                    sprintf(stack_buf_071, arg2, arg0, record20_100.field_04);
                    if (vm_func_011743(stack_buf_071) == 0x0) {
                        ptr_012b3b = vm_func_012cfb(arg3, index_f8);
                        *(uint32_t *)(ptr_012b3b) = (*(uint32_t *)(ptr_012b3b) | 0x40);
                        *(uint32_t *)(vm_func_012cfb(arg3, index_f8) + 0x8) = arg0;
                        if (((uint32_t)(((arg0) % (uint64_t)(0x186a0)))) <= 0x270f) {
                            ptr_012bbd = vm_func_012cfb(arg3, index_f8);
                            *(uint32_t *)(ptr_012bbd) = (*(uint32_t *)(ptr_012bbd) | 0x4);
                        }
                    }
                }
            }
            index_f8 = (index_f8 + 0x1);
            continue;
        }
    }
    return result;
}
