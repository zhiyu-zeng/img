uint64_t vm_func_006447(const char* string) {
    length_10 = strlen(string);
    index_18 = 0x0;
    while (((uint64_t)(index_18)) < ((uint64_t)(length_10))) {
        if (*(uint8_t *)(string + index_18) != 0x29) {
            index_18 = (index_18 + 0x1);
            continue;
        } else {
            if (((uint64_t)((index_18 + 0x1))) >= ((uint64_t)(length_10))) {
                index_18 = (index_18 + 0x1);
                continue;
            } else {
                result = *(uint8_t *)((index_18 + string) + 0x1);
                goto loc_0065bc;
            }
        }
    }
    result = 0x0;
    loc_0065bc:
    return result;
}
