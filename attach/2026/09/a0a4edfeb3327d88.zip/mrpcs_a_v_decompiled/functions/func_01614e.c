void vm_func_01614e(void* arg0) {
    vm_func_015dd0(arg0, *(uint64_t *)(arg0), (((*(uint64_t *)(arg0 + 0x10) - *(uint64_t *)(arg0)) >> 0x2) * 0xcccccccccccccccd));
    *(uint64_t *)(arg0) = 0x0;
    *(uint64_t *)(arg0 + 0x8) = 0x0;
    *(uint64_t *)(arg0 + 0x10) = 0x0;
    return;
}
