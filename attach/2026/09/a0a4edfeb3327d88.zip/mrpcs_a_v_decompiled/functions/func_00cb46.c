void vm_func_00cb46(void* arg0) {
    if (*(uint64_t *)(arg0) != 0x0) {
        free(*(uint64_t *)(arg0));
        *(uint64_t *)(arg0) = 0x0;
    }
    return;
}
