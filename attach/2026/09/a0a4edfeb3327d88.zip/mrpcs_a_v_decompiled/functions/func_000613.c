uint64_t vm_func_000613(uint64_t path, uint8_t* arg1) {
    *(uint32_t *)(__errno()) = 0x0;
    result = syscall_newfstatat(0xffffff9c, path, arg1, 0x0);
    if (result != 0x0) {
        result = (0x0 - *(uint32_t *)(__errno()));
    }
    return result;
}
