void vm_func_0101fa(const void* arg0) {
    vm_func_01026c(arg0, *(uint64_t *)(arg0), (((*(uint64_t *)(arg0 + 0x10) - *(uint64_t *)(arg0)) >> 0x3) * 0x6db6db6db6db6db7));
    return;
}
