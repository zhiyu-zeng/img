uint64_t sys_read(uint64_t arg0, uint64_t arg1, uint64_t arg2) {
    if (g_3820 == 0x0) {
        g_3820 = build_aarch64_syscall_stub(0x3f);
    }
    if (g_3820 != 0x0) {
        result = call_native_n(g_3820, (int64_t)(arg0), arg1, arg2);
    } else {
        result = 0xffffffffffffffff;
    }
    return result;
}
