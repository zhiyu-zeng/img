void vm_func_015dd0(uint64_t arg0, uint64_t arg1, uint64_t arg2) {
    if (arg1 != 0x0) {
        ((fn_operator_delete_array)(arg1));
    }
    return;
}
