void vm_func_01a142(uint64_t arg0) {
    return;
}
