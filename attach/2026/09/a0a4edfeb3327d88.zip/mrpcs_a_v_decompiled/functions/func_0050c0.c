void vm_func_0050c0(const void* arg0, uint64_t arg1, uint64_t arg2) {
    VmU64Triple u64_triple_018;
    u64_triple_018.first = arg1;
    u64_triple_018.second = arg2;
    u64_triple_018.third = 0x0;
    dispatch_registered_handler(0xa7, *(uint64_t *)(arg0), &u64_triple_018, 0x2);
    return;
}
