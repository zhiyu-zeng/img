void vm_func_006305(const void* arg0, uint64_t arg1, uint64_t arg2, uint64_t arg3) {
    VmU64Triple u64_triple_020;
    u64_triple_020.first = arg1;
    u64_triple_020.second = arg2;
    u64_triple_020.third = (int64_t)(arg3);
    dispatch_registered_handler(0xbd, *(uint64_t *)(arg0), &u64_triple_020, 0x3);
    return;
}
