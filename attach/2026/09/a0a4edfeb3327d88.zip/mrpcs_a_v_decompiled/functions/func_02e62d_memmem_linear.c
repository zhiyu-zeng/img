uint64_t memmem_linear(const uint8_t* haystack, uint64_t haystack_len, const uint8_t* needle, uint64_t needle_len) {
    if (needle_len == 0x0) {
        result = 0x0;
    } else {
        if (haystack_len >= needle_len) {
            local_28 = (haystack_len - needle_len);
            index_30 = 0x0;
            while (((uint64_t)(index_30)) <= ((uint64_t)(local_28))) {
                index_38 = 0x0;
                while (true) {
                    loc_02e81e:
                    if (!((((uint64_t)(index_38)) >= needle_len) ? 0x0 : ((((*(uint8_t *)(haystack + (index_30 + index_38))) != (*(uint8_t *)(needle + index_38)))) ? 1 : 0) & 0x1)) {
                        index_38 = (index_38 + 0x1);
                        continue;
                    }
                    break;
                }
                if (index_38 != needle_len) {
                    index_30 = (index_30 + 0x1);
                    continue;
                } else {
                    result = (haystack + index_30);
                    goto loc_02e907;
                }
            }
            result = 0x0;
        } else {
            result = 0x0;
            return result;
        }
    }
    loc_02e907:
    return result;
}
