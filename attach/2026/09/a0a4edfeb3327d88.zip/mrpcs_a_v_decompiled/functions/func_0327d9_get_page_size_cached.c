uint64_t get_page_size_cached(void) {
    if (g_3ec0 == 0x0) {
        fn_ptr_8 = resolve_symbol("libc.so", "sysconf");
        if (fn_ptr_8 == 0x0) {
        } else {
            native_result_0328a4 = call_native_n(fn_ptr_8, 0x27);
        }
        g_3ec0 = ((fn_ptr_8 == 0x0) ? 0x4000 : native_result_0328a4);
        result = ((fn_ptr_8 == 0x0) ? 0x4000 : native_result_0328a4);
    } else {
        result = g_3ec0;
    }
    return result;
}
