uint64_t vm_func_025b32(uint64_t arg0, const void* arg1) {
    local_18 = (arg1 + 0x8);
    local_20 = *(uint64_t *)(arg1);
    local_18 = (arg1 + 0x10);
    local_28 = *(uint64_t *)(arg1 + 0x8);
    local_18 = (arg1 + 0x18);
    local_30 = *(uint64_t *)(arg1 + 0x10);
    local_18 = (arg1 + 0x20);
    local_38 = *(uint64_t *)(arg1 + 0x18);
    local_18 = (arg1 + 0x28);
    local_40 = *(uint64_t *)(arg1 + 0x20);
    local_48 = *(uint64_t *)(arg1 + 0x28);
    return (vm_func_02547f(*(uint64_t *)(arg1), arg0, *(uint64_t *)(arg1 + 0x8), *(uint64_t *)(arg1 + 0x10), *(uint64_t *)(arg1 + 0x18), *(uint64_t *)(arg1 + 0x20), *(uint64_t *)(arg1 + 0x28), 0x0)) == (0x0);
}
