void vm_func_00798e(uint64_t arg0, uint64_t arg1) {
    tree_node_clear_links(arg1);
    heap_free(arg1, 0x30);
    return;
}
