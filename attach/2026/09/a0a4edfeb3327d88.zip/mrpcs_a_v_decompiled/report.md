# MVM反编译报告

## 总览

| 项目 | 结果 |
|---|---:|
| 输入文件 | `mrpcs_a_v.data` |
| VM 函数 | **393/393** |
| 零 fallback | **393/393** |
| Callback | **33** |
| 注册任务 | **34** |
| VM 调用边 | **906** |
| 未解析 `CALL_REG` | **0** |
| Backend 兼容性 | **99/100** |

> 结果：当前样本已完整进入 C-like 输出。

## 先看这里

- `callbacks/INDEX.md`：**建议第一个打开**，按任务 ID 查看 callback。
- `functions/INDEX.md`：393 个函数的分组索引，可直接跳到具体 C-like 文件。
- `callbacks/`：callback C-like 逻辑。
- `functions/`：全部 VM 函数的 C-like 伪代码。
- `analysis/function_inventory.csv`：函数名称、原型、调用关系和结构化状态。
- `analysis/callgraph.csv` / `analysis/callgraph.dot`：调用图。
- `analysis/local_structs.csv`：恢复出的局部结构体/聚合对象。
- `analysis/vm_function_signatures.csv`：函数参数和返回值推断。

## Callback / 注册任务

| 任务 ID | VM 入口 | 函数 |
|---|---:|---|
| `0x6c51` | `0x00113a` | `vm_func_00113a` |
| `0x6c52` | `0x0008f3` | `vm_func_0008f3` |
| `0x6c53` | `0x018be3` | `vm_func_018be3` |
| `0x6c54` | `0x018d15` | `vm_func_018d15` |
| `0x6c55` | `0x010e76` | `vm_func_010e76` |
| `0x6c56` | `0x010beb` | `vm_func_010beb` |
| `0x6c57` | `0x010479` | `module_relative_probe_callback` |
| `0x6c60` | `0x010479` | `module_relative_probe_callback` |
| `0x6c61` | `0x019159` | `vm_func_019159` |
| `0x6c62` | `0x01a82f` | `vm_func_01a82f` |
| `0x6c63` | `0x01a9eb` | `vm_func_01a9eb` |
| `0x6c64` | `0x01adf3` | `vm_func_01adf3` |
| `0x6c67` | `0x01b056` | `vm_func_01b056` |
| `0x6c69` | `0x01e74c` | `vm_func_01e74c` |
| `0x6c6a` | `0x01f0e2` | `vm_func_01f0e2` |
| `0x6c6b` | `0x01f511` | `vm_func_01f511` |
| `0x6c6c` | `0x01fab3` | `vm_func_01fab3` |
| `0x6c6d` | `0x02153f` | `vm_func_02153f` |
| `0x6c6e` | `0x0216f4` | `inspect_thread_module_egl` |
| `0x6c6f` | `0x02227d` | `vm_func_02227d` |
| `0x6c70` | `0x02241a` | `report_thread_module_egl_1350254` |
| `0x6c71` | `0x018625` | `vm_func_018625` |
| `0x6c72` | `0x027319` | `collect_symbol_probe_callback` |
| `0x6c73` | `0x027601` | `report_symbol_probe_1350259` |
| `0x6c74` | `0x02a174` | `collect_mapping_probe_callback` |
| `0x6c75` | `0x02a328` | `report_mapping_probe_135025c` |
| `0x6c76` | `0x02be0b` | `serialize_integrity_record_135025e` |
| `0x6c92` | `0x002aee` | `vm_func_002aee` |
| `0x6c93` | `0x01620c` | `persistent_vm_worker_6c93` |
| `0x6c94` | `0x016680` | `cleanup_vm_worker_6c94` |
| `0x6c97` | `0x02f19b` | `sample_runtime_ring` |
| `0x6c98` | `0x030ed9` | `report_runtime_ring_sample` |
| `0x6c99` | `0x0316bd` | `report_suspicious_mappings_13525d9` |
| `0x6c9a` | `0x0328f1` | `runtime_state_machine_6c9a` |

## 反编译质量

| 项目 | 数量 |
|---|---:|
| 初始化入口 / callback 根可达函数 | 265 |
| 类型/全局结构增强函数 | 12 |
| 结构字段重写 | 272 |
| 地址 / stride 重写 | 69 |
| 栈对象恢复函数 | 37 |
| 栈缓冲区对象 | 90 |
| `fp+offset` 重写 | 597 |
| 局部结构增强函数 | 75 |
| 局部结构/聚合对象 | 90 |
| 局部字段/对象重写 | 570 |
| 伪代码清理函数 | 393 |
| 删除无引用寄存器保存噪声 | 572 |
| 消除参数栈转存 | 823 |
| 合并 VM 临时寄存器复制 | 0 |
| 内联紧邻单用途 VM 临时寄存器 | 0 |
| 提升单次读取寄存器别名 | 0 |
| 传播稳定顶层常量/地址 | 18 |
| 合并寄存器到命名符号赋值 | 0 |
| 丢弃可证明未使用的物理寄存器调用返回值 | 0 |
| SSA 临时值提升到 local | 299 |
| SSA local 别名读取重写 | 240 |
| 内联紧邻单用途 SSA 临时值 | 386 |
| 移除未使用 SSA 返回临时值（调用保留） | 387 |
| SSA 临时值语义重命名 | 41 |
| 其中：普通指针 / heap 指针 | 16 / 8 |
| 其中：模块基址 / 句柄 / 函数指针 | 5 / 1 / 1 |
| 其中：length / strstr 指针 / compare result | 1 / 1 / 2 |
| 其中：CALL_REG / native / MOV_ONCE result | 1 / 3 / 2 |
| 高置信度 local 语义重命名 | 194 |
| 其中：文件 / 指针类 / length / status / index | 11 / 21 / 5 / 5 / 85 |
| 其中：PID/UID/JNI 等身份值 / hash / VM slot | 7 / 1 / 13 |
| 其中：基于直接解引用证据的 generic pointer | 16 |
| 其中：基于 API 参数位置的 local 用途名 | 18 |
| 高置信度参数用途重命名 | 24 |
| 统一返回值槽命名为 result | 86 |
| 冗余同类型参数 cast 消除 | 14 |
| 空 if/else 控制块消除 | 5 |
| 其中：path/string / buffer/src/dst / size/count / pid/tid/fd/signal | 10 / 7 / 2 / 5 |
| 跨函数命名局部结构类型传播 | 12 |
| 化简 0/1 布尔包装 | 93 |
| 标准化 typed dereference 语法 | 1860 |
| 推导出参数的函数 | 309 |
| 推导出返回值的函数 | 174 |
| 指针/字符串类参数 | 182 |

## 局部对象恢复

| 类型 | 数量 |
|---|---:|
| `/proc/self/maps` 完整对象 | 8 |
| `/proc/self/maps` start/end/path | 1 |
| CPU affinity mask | 2 |
| Packet submit descriptor | 1 |
| 3-qword 聚合 | 10 |
| 0x38 inline-payload record | 1 |
| 20-byte copied record overlay | 6 |
| Overlay / union 聚合 | 1 |
| Mixed-width + tail 聚合 | 1 |
| 通用匿名聚合 | 35 |
| 内联 qword vector | 0 |

## 输出结构

```text
mrpcs_a_v_decompiled/
├── report.md          # 本报告
├── callbacks/         # callback C-like 结果 + INDEX.md
├── functions/         # 全部 VM 函数 + INDEX.md
├── analysis/          # CSV / JSON / 调用图 / 类型 / backend 信息
└── raw/
    └── sections/      # 解出的原始 VMRPCS section
```

`analysis/` 保存研究和机器可读数据，默认不需要逐个打开。日常阅读优先看 `callbacks/INDEX.md`、`functions/INDEX.md` 和本报告。

## Backend

- Backend：**mvm_v1 v1.11.0**
- Opcode XOR key：**0x00**
- Type1：**210584 bytes**
- Type2：**16814 bytes**
- 详细兼容性探测：`analysis/compatibility.md`

> Backend 版本号属于内部解析器标识，不再放进应用标题或报告标题。
