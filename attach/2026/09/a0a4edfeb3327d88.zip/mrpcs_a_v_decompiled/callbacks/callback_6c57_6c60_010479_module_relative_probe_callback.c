void module_relative_probe_callback(void) {
    struct { uint8_t raw_00[8]; uint32_t length; uint8_t pad_0c[4]; uint64_t value_10; uint8_t payload[0x20]; } record38_028;
    slot_value_0 = vm_slot_get(0x0, 0x0);
    if (slot_value_0 != 0x0) {
        slot_value_8 = vm_slot_get(0x1, 0x0);
        if (slot_value_8 != 0x0) {
            slot_value_10 = vm_slot_get(0x2, 0x0);
            slot_value_14 = vm_slot_get(0x3, 0x0);
            slot_value_18 = vm_slot_get(0x4, 0x0);
            slot_value_1c = vm_slot_get(0x5, 0x0);
            slot_value_20 = vm_slot_get(0x6, 0x0);
            if (slot_value_20 != 0x0) {
                module_base_60 = find_module_base(slot_value_8);
                if (module_base_60 != 0x0) {
                    record38_028.value_10 = (module_base_60 + slot_value_18);
                    memcpy_checked(record38_028.payload, slot_value_20, slot_value_1c);
                    record38_028.length = slot_value_1c;
                    recordvec_push_0x38(slot_value_0, &record38_028);
                }
            }
        }
    }
    return;
}
