void vm_func_01f511(void) {
    slot_value_10 = vm_slot_get(0x0, 0x0);
    if (*(uint64_t *)(slot_value_10) == 0x0) {
        vm_slot_set(0x0, 0x0, 0x0);
        local_8 = 0x0;
    } else {
        if (*(uint64_t *)(slot_value_10 + 0x8) == 0x0) {
            vm_slot_set(0x0, 0x0, 0x0);
            local_8 = 0x0;
            return;
        } else {
            if (*(uint8_t *)(*(uint64_t *)(slot_value_10 + 0x8)) != 0x0) {
                local_18 = 0x0;
                index_1c = 0x0;
                while (((uint64_t)((int64_t)(index_1c))) <= 0x63) {
                    if (*(uint64_t *)(((int64_t)(index_1c) << 0x3) + &g_1e58) != 0x0) {
                        if (call_native_n(g_21e0, *(uint64_t *)(slot_value_10 + 0x8), *(uint64_t *)(((int64_t)(index_1c) << 0x3) + &g_1e58)) == 0x0) {
                            index_1c = (index_1c + 0x1);
                            continue;
                        } else {
                            local_18 = 0x1;
                            break;
                        }
                    }
                }
                loc_01f767:
                local_20 = 0x0;
                index_24 = 0x0;
                while (((int32_t)(index_24)) < ((int32_t)(g_22bc))) {
                    if (call_native_n(g_21e0, *(uint64_t *)(slot_value_10 + 0x8), *(uint64_t *)(g_2280 + ((int64_t)(index_24) << 0x3))) == 0x0) {
                        index_24 = (index_24 + 0x1);
                        continue;
                    } else {
                        local_20 = 0x1;
                        break;
                    }
                }
                loc_01f86f:
                if (!(local_18 & 0x1)) {
                    if (!(local_20 & 0x1)) {
                        index_28 = 0x0;
                        while (((uint64_t)((int64_t)(index_28))) <= 0x63) {
                            if (*(uint64_t *)(((int64_t)(index_28) << 0x3) + &g_1b28) != 0x0) {
                                if (call_native_n(g_21e0, *(uint64_t *)(slot_value_10 + 0x8), *(uint64_t *)(((int64_t)(index_28) << 0x3) + &g_1b28)) == 0x0) {
                                    index_28 = (index_28 + 0x1);
                                    continue;
                                } else {
                                    vm_func_0204d3(slot_value_10);
                                    break;
                                }
                            }
                        }
                    }
                }
                loc_01fa13:
                if (((int32_t)(g_2210)) < 5) {
                    vm_slot_set(0x0, 0x0, 0x0);
                } else {
                    vm_slot_set(0x0, 0x1, 0x0);
                }
                local_8 = 0x0;
            } else {
                vm_slot_set(0x0, 0x0, 0x0);
                local_8 = 0x0;
                return;
            }
        }
    }
    return;
}
