void inspect_thread_module_egl(void) {
    uint8_t* stack_buf_068 = (uint8_t*)(fp + 0x68); /* observed >= 0x1e bytes */
    uint8_t* stack_buf_086 = (uint8_t*)(fp + 0x86); /* observed >= 0x1e bytes */
    uint8_t* stack_buf_0b8 = (uint8_t*)(fp + 0xb8); /* observed >= 0x11 bytes */
    uint8_t* stack_buf_0e8 = (uint8_t*)(fp + 0xe8); /* observed >= 0x20 bytes */
    uint8_t* stack_buf_128 = (uint8_t*)(fp + 0x128); /* observed >= 0xd bytes */
    slot_value_50 = vm_slot_get(0x1e, 0x0);
    if (((uint64_t)(slot_value_50)) < ((uint64_t)(fn_eglSwapBuffers))) {
        tmp_02184d = vm_func_026d28(g_22c8, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0);
        local_48 = tmp_02184d;
    } else {
        if (((uint64_t)(slot_value_50)) < ((uint64_t)((fn_eglSwapBuffers + egl_module_span)))) {
            if (thread_probe_first_hit_seq == 0x0) {
                thread_probe_first_hit_seq = thread_probe_report_seq;
            }
            thread_probe_hit_count = (thread_probe_hit_count + 0x1);
            thread_probe_status = 0x7;
            tid_58 = gettid();
            local_60 = vm_slot_get(0x1d, 0x0);
            memset(stack_buf_068, 0x0, 0x1e);
            memset(stack_buf_086, 0x0, 0x1e);
            sprintf(stack_buf_068, "/proc/%d/comm", tid_58);
            file_handle_a8 = fopen(stack_buf_068, "r");
            if (file_handle_a8 != 0x0) {
                fgets(stack_buf_086, 0x1e, file_handle_a8);
                fclose(file_handle_a8);
            }
            length_b0 = strlen(stack_buf_086);
            size_b4 = ((((int32_t)(length_b0)) < 17) ? length_b0 : 0x10);
            memset(stack_buf_0b8, 0x0, 0x11);
            strncpy(stack_buf_0b8, ((stack_buf_086 + (int64_t)(length_b0)) - (int64_t)(size_b4)), (int64_t)(size_b4));
            thread_probe_value0 = call_native_n(ue_probe_fn0);
            thread_probe_value1 = call_native_n(ue_probe_fn1);
            thread_probe_value2 = call_native_n(ue_probe_fn2);
            fn_ptr_d0 = resolve_symbol("libEGL.so", "eglGetCurrentContext");
            local_d8 = 0x0;
            if (fn_ptr_d0 != 0x0) {
                local_d8 = call_native_n(fn_ptr_d0);
            }
            local_e0 = 0x5;
            index_108 = 0x0;
            while (((int32_t)(index_108)) <= 4) {
                if ((local_60 & 0x3) == 0x0) {
                    if (((uint64_t)(local_60)) >= 0x5000000000) {
                        if (((uint64_t)(local_60)) < 0x8000000000) {
                            local_110 = *(uint64_t *)(local_60);
                            local_118 = (*(uint64_t *)(local_60 + 0x8) & 0x7fffffffff);
                            if (*(uint64_t *)(local_60) != 0x0) {
                                if (local_110 != local_60) {
                                    memset(stack_buf_0e8, 0x0, 0x20);
                                    if (dladdr(local_118, stack_buf_0e8) != 0x0) {
                                        if (local_e8 == 0x0) {
                                            local_60 = local_110;
                                            index_108 = (index_108 + 0x1);
                                            continue;
                                        } else {
                                            if (strstr(local_e8, "/libhwui.so") != 0x0) {
                                                local_60 = local_110;
                                                index_108 = (index_108 + 0x1);
                                                continue;
                                            } else {
                                                if (strstr(local_e8, "/libutils.so") != 0x0) {
                                                    local_60 = local_110;
                                                    index_108 = (index_108 + 0x1);
                                                    continue;
                                                } else {
                                                    if (strstr(local_e8, "/libc.so") != 0x0) {
                                                        local_60 = local_110;
                                                        index_108 = (index_108 + 0x1);
                                                        continue;
                                                    } else {
                                                        if (strstr(local_e8, "/libEGL.so") != 0x0) {
                                                            local_60 = local_110;
                                                            index_108 = (index_108 + 0x1);
                                                            continue;
                                                        } else {
                                                            thread_probe_addr_hi = *(uint32_t *)((fp + 0x118) | 0x4);
                                                            thread_probe_addr_lo = local_118;
                                                            length_120 = strlen(local_e8);
                                                            size_124 = ((((int32_t)(length_120)) < 13) ? length_120 : 0xc);
                                                            memset(stack_buf_128, 0x0, 0xd);
                                                            strncpy(stack_buf_128, ((local_e8 + (int64_t)(length_120)) - (int64_t)(size_124)), (int64_t)(size_124));
                                                            thread_probe_module_tail12 = local_128;
                                                            g_23c0 = *(uint64_t *)(stack_buf_128 + 0x4);
                                                            break;
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    } else {
                                        thread_probe_addr_hi = *(uint32_t *)((fp + 0x118) | 0x4);
                                        thread_probe_addr_lo = local_118;
                                        thread_probe_module_tail12 = 0x6e6f6e61;
                                        g_23c4 = 0x0;
                                        break;
                                    }
                                }
                            }
                        }
                    }
                }
            }
            loc_021fa4:
            thread_probe_tid = tid_58;
            thread_probe_name16 = local_b8;
            g_23ac = *(uint64_t *)(stack_buf_0b8 + 0x8);
            thread_probe_egl_ctx_hi = *(uint32_t *)((fp + 0xd8) | 0x4);
            thread_probe_egl_ctx_lo = local_d8;
            vm_func_026d28(g_22c8, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0);
            if (((int32_t)((thread_probe_report_seq - thread_probe_first_hit_seq))) >= 4) {
                vm_func_02227d();
            }
            local_48 = 0x0;
        } else {
            tmp_02184d = vm_func_026d28(g_22c8, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0);
            local_48 = tmp_02184d;
            return;
        }
    }
    return;
}
