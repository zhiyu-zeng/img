void persistent_vm_worker_6c93(void) {
    *(uint32_t *)(g_0470 + 0x4) = getpid();
    *(uint32_t *)(g_0470 + 0x8) = getuid();
    *(uint32_t *)(g_0470 + 0x20) = vm_func_011909();
    if (*(uint32_t *)(g_0470 + 0x20) != 0x0) {
        *(uint32_t *)(g_0470) = (*(uint32_t *)(g_0470) | 0x1);
    }
    if (vm_func_012436() != 0x0) {
        *(uint32_t *)(g_0470) = (*(uint32_t *)(g_0470) | 0x40);
        while (true) {
            local_60 = vm_func_013825();
            if (local_60 != 0x0) break;
            if (g_0588 != 0x0) {
                hostcall_dynamic(0x12c);
            } else {
                hostcall_dynamic(0x78);
            }
            g_0588 = (g_0588 + 0x1);
            continue;
        }
        *(uint32_t *)(g_0470) = (*(uint32_t *)(g_0470) | ((local_60 << 0x18) & 0x7000000));
    }
    while (true) {
        hostcall_dynamic();
        vm_call_reg(0xcbbc);
        packet_append_typed_field((fp + 0x68), *(uint32_t *)(g_0470), 0x3, 0xb6);
        packet_append_typed_field((fp + 0x68), *(uint32_t *)(g_0470 + 0x8), 0x3, 0xb6);
        packet_append_typed_field((fp + 0x68), *(uint32_t *)(g_0470 + 0x4), 0x3, 0xb6);
        packet_append_typed_field((fp + 0x68), 0x0, 0x3, 0xb6);
        packet_append_typed_field((fp + 0x68), 0x0, 0x3, 0xb6);
        packet_append_typed_field((fp + 0x68), 0x0, 0x3, 0xb6);
        packet_append_typed_field((fp + 0x68), 0x0, 0x3, 0xb6);
        local_80 = (packet_periodic_flush((fp + 0x68), 0x0) & 0x1);
        if (g_0588 != 0x0) {
            hostcall_dynamic(0x12c);
        } else {
            hostcall_dynamic(0x78);
        }
        g_0588 = (g_0588 + 0x1);
        vm_call_reg(0xcb46);
        continue;
    }
}
