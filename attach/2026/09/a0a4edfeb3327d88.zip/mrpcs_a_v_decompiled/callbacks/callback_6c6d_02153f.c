void vm_func_02153f(void) {
    slot_value_10 = vm_slot_get(0x0, 0x0);
    if (*(uint64_t *)(slot_value_10) == 0x0) {
        vm_slot_set(0x0, 0x0, 0x0);
        local_8 = 0x0;
    } else {
        if (*(uint64_t *)(slot_value_10 + 0x8) == 0x0) {
            vm_slot_set(0x0, 0x0, 0x0);
            local_8 = 0x0;
            return;
        } else {
            if (*(uint8_t *)(*(uint64_t *)(slot_value_10 + 0x8)) != 0x0) {
                local_18 = inspect_libegl_phdr_and_install_probe(slot_value_10);
                if (local_18 != 0x0) {
                    vm_slot_set(0x0, 0x0, 0x0);
                } else {
                    vm_slot_set(0x0, 0x1, 0x0);
                }
                local_8 = 0x0;
            } else {
                vm_slot_set(0x0, 0x0, 0x0);
                local_8 = 0x0;
                return;
            }
        }
    }
    return;
}
