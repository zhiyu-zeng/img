void report_thread_module_egl_1350254(void) {
    if (fn_dl_iterate_phdr == 0x0) {
        thread_probe_status = 0xffffffff;
    } else {
        if (fn_strstr == 0x0) {
            goto loc_02289e;
        } else {
            if (fn_sscanf == 0x0) {
                goto loc_02289e;
            } else {
                if (fn_strdup != 0x0) {
                    if (!(thread_probe_phdr_initialized & 0x1)) {
                        run_dl_iterate_phdr_callback_6c6d();
                        thread_probe_phdr_initialized = 0x1;
                    }
                } else {
                    goto loc_02289e;
                }
            }
        }
    }
    thread_probe_report_seq = (thread_probe_report_seq + 0x1);
    if (((thread_probe_report_seq + 0x1) - (((thread_probe_report_seq + 0x1) + (((thread_probe_report_seq + 0x1) >> 0x1f) >> 0x1e)) & 0xfffffffc)) == 0x1) {
        serializer.set_mode(0x3);
        serializer.append_u32(0x1350254);
        serializer.append_u32((int64_t)(thread_probe_status));
        serializer.append_u32((int64_t)(thread_probe_report_seq));
        serializer.append_u32((int64_t)(thread_probe_tid));
        serializer.append_u32((int64_t)(thread_probe_value0));
        serializer.append_u32(thread_probe_egl_ctx_hi);
        serializer.append_u32(thread_probe_egl_ctx_lo);
        serializer.append_u32(thread_probe_name16);
        serializer.append_u32(g_23a8);
        serializer.append_u32(g_23ac);
        serializer.append_u32(g_23b0);
        serializer.append_u32(thread_probe_hit_count);
        serializer.append_u32((int64_t)(thread_probe_value1));
        serializer.append_u32(thread_probe_addr_hi);
        serializer.append_u32(thread_probe_addr_lo);
        serializer.append_u32(thread_probe_module_tail12);
        serializer.append_u32(g_23c0);
        serializer.append_u32(g_23c4);
        serializer.append_u32((int64_t)(thread_probe_value2));
        serializer.append_u32(0x0);
        serializer.append_u32(0x0);
        serializer.append_u32(0x0);
        serializer.append_u32(0x0);
        serializer.append_u32(0x0);
        serializer.append_u32(0x0);
        serializer.append_u32(0x0);
        serializer.append_u32(0x0);
        serializer.append_u32(0x0);
        serializer.append_u32(0x0);
        serializer.append_u32(0x0);
        serializer.flush(0x1);
    }
    return;
}
