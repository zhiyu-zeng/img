void vm_func_02227d(void) {
    if (g_22c8 != 0x0) {
        if (thread_probe_installed & 0x1) {
            thread_probe_status = 0x8;
            if ((thread_probe_phdr_flags & 0x2) == 0x0) {
                vm_func_02367f(thread_probe_phdr_value, (thread_probe_phdr_flags | 0x2));
            }
            vm_func_026c7c(g_22c8);
            g_22c8 = 0x0;
            thread_probe_installed = 0x0;
            if ((thread_probe_phdr_flags & 0x2) == 0x0) {
                vm_func_02367f(thread_probe_phdr_value, thread_probe_phdr_flags);
            }
        }
    }
    return;
}
