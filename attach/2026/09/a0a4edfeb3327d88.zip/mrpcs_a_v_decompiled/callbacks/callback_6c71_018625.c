void vm_func_018625(void) {
    if (g_058c == 0x2) {
        memset(&g_05e4, 0x0, 0x4b0);
        memset(&g_0a98, 0x0, 0x960);
        g_13f8 = 0x0;
        g_13fc = 0x0;
        g_05d4 = 0x0;
        g_05d0 = 0x0;
        g_05d1 = 0x0;
        g_05d2 = 0x0;
        g_05e0 = 0x0;
        local_48 = *(uint64_t *)(g_05a0 + 0x559c18);
        local_50 = (g_05a0 + 0x559c20);
        if (*(uint64_t *)(g_05a0 + 0x559c18) != 0x0) {
            if (call_native_n(g_0590, local_50) == 0x0) {
                vm_func_017dc5((local_48 + 0x18));
                vm_func_017dc5((local_48 + 0x138));
                call_native_n(g_0598, local_50);
            }
            local_58 = (local_48 + 0x5d4);
            if (call_native_n(g_0590, (local_48 + 0x5d4)) == 0x0) {
                local_60 = (local_48 + 0x2b0);
                index_68 = 0x0;
                while (((int32_t)(index_68)) <= 99) {
                    local_70 = *(uint64_t *)(local_60 + ((int64_t)(index_68) << 0x3));
                    if (*(uint64_t *)(local_60 + ((int64_t)(index_68) << 0x3)) != 0x0) {
                        local_78 = *(uint8_t *)(local_70 + 0x4);
                        if (*(uint8_t *)(local_70 + 0x4) == 0x3) {
                            vm_func_017dc5((local_70 + 0xd0));
                        }
                        index_68 = (index_68 + 0x1);
                        continue;
                    }
                }
                call_native_n(g_0598, local_58);
            }
            local_80 = *(uint64_t *)(g_05a0 + 0x554d50);
            if (*(uint64_t *)(g_05a0 + 0x554d50) != 0x0) {
                local_88 = (local_80 + 0x48);
                if (call_native_n(g_0590, (local_80 + 0x48)) == 0x0) {
                    vm_func_0175d9((local_80 + 0x18));
                    call_native_n(g_0598, local_88);
                }
                g_05d4 = (((g_05d0 << 0x10) | (g_05d1 << 0x8)) | g_05d2);
            }
        }
    }
    return;
}
