void collect_mapping_probe_callback(void) {
    slot_value_10 = vm_slot_get(0x0, 0x0);
    if (*(uint64_t *)(slot_value_10) == 0x0) {
        vm_slot_set(0x0, 0x0, 0x0);
        local_8 = 0x0;
    } else {
        if (*(uint64_t *)(slot_value_10 + 0x8) == 0x0) {
            vm_slot_set(0x0, 0x0, 0x0);
            local_8 = 0x0;
            return;
        } else {
            if (*(uint8_t *)(*(uint64_t *)(slot_value_10 + 0x8)) != 0x0) {
                collect_mapping_descriptor_record(slot_value_10);
                if (((int32_t)(map_probe_record_count)) < 4) {
                    vm_slot_set(0x0, 0x0, 0x0);
                } else {
                    vm_slot_set(0x0, 0x1, 0x0);
                }
                local_8 = 0x0;
            } else {
                vm_slot_set(0x0, 0x0, 0x0);
                local_8 = 0x0;
                return;
            }
        }
    }
    return;
}
