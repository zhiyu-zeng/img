# Callback 索引

| 任务 ID | VM 入口 | 函数 | 原型 |
|---|---:|---|---|
| `0x6c51` | `0x00113a` | [vm_func_00113a](callback_6c51_00113a.c) | `void vm_func_00113a(void)` |
| `0x6c52` | `0x0008f3` | [vm_func_0008f3](callback_6c52_0008f3.c) | `void vm_func_0008f3(void)` |
| `0x6c53` | `0x018be3` | [vm_func_018be3](callback_6c53_018be3.c) | `void vm_func_018be3(void)` |
| `0x6c54` | `0x018d15` | [vm_func_018d15](callback_6c54_018d15.c) | `void vm_func_018d15(void)` |
| `0x6c55` | `0x010e76` | [vm_func_010e76](callback_6c55_010e76.c) | `void vm_func_010e76(void)` |
| `0x6c56` | `0x010beb` | [vm_func_010beb](callback_6c56_010beb.c) | `void vm_func_010beb(void)` |
| `0x6c57` | `0x010479` | [module_relative_probe_callback](callback_6c57_6c60_010479_module_relative_probe_callback.c) | `void module_relative_probe_callback(void)` |
| `0x6c60` | `0x010479` | [module_relative_probe_callback](callback_6c57_6c60_010479_module_relative_probe_callback.c) | `void module_relative_probe_callback(void)` |
| `0x6c61` | `0x019159` | [vm_func_019159](callback_6c61_019159.c) | `void vm_func_019159(void)` |
| `0x6c62` | `0x01a82f` | [vm_func_01a82f](callback_6c62_01a82f.c) | `void vm_func_01a82f(void)` |
| `0x6c63` | `0x01a9eb` | [vm_func_01a9eb](callback_6c63_01a9eb.c) | `void vm_func_01a9eb(void)` |
| `0x6c64` | `0x01adf3` | [vm_func_01adf3](callback_6c64_01adf3.c) | `void vm_func_01adf3(void)` |
| `0x6c67` | `0x01b056` | [vm_func_01b056](callback_6c67_01b056.c) | `void vm_func_01b056(void)` |
| `0x6c69` | `0x01e74c` | [vm_func_01e74c](callback_6c69_01e74c.c) | `void vm_func_01e74c(void)` |
| `0x6c6a` | `0x01f0e2` | [vm_func_01f0e2](callback_6c6a_01f0e2.c) | `void vm_func_01f0e2(void)` |
| `0x6c6b` | `0x01f511` | [vm_func_01f511](callback_6c6b_01f511.c) | `void vm_func_01f511(void)` |
| `0x6c6c` | `0x01fab3` | [vm_func_01fab3](callback_6c6c_01fab3.c) | `void vm_func_01fab3(void)` |
| `0x6c6d` | `0x02153f` | [vm_func_02153f](callback_6c6d_02153f.c) | `void vm_func_02153f(void)` |
| `0x6c6e` | `0x0216f4` | [inspect_thread_module_egl](callback_6c6e_0216f4_inspect_thread_module_egl.c) | `void inspect_thread_module_egl(void)` |
| `0x6c6f` | `0x02227d` | [vm_func_02227d](callback_6c6f_02227d.c) | `void vm_func_02227d(void)` |
| `0x6c70` | `0x02241a` | [report_thread_module_egl_1350254](callback_6c70_02241a_report_thread_module_egl_1350254.c) | `void report_thread_module_egl_1350254(void)` |
| `0x6c71` | `0x018625` | [vm_func_018625](callback_6c71_018625.c) | `void vm_func_018625(void)` |
| `0x6c72` | `0x027319` | [collect_symbol_probe_callback](callback_6c72_027319_collect_symbol_probe_callback.c) | `void collect_symbol_probe_callback(void)` |
| `0x6c73` | `0x027601` | [report_symbol_probe_1350259](callback_6c73_027601_report_symbol_probe_1350259.c) | `void report_symbol_probe_1350259(void)` |
| `0x6c74` | `0x02a174` | [collect_mapping_probe_callback](callback_6c74_02a174_collect_mapping_probe_callback.c) | `void collect_mapping_probe_callback(void)` |
| `0x6c75` | `0x02a328` | [report_mapping_probe_135025c](callback_6c75_02a328_report_mapping_probe_135025c.c) | `void report_mapping_probe_135025c(void)` |
| `0x6c76` | `0x02be0b` | [serialize_integrity_record_135025e](callback_6c76_02be0b_serialize_integrity_record_135025e.c) | `void serialize_integrity_record_135025e(void)` |
| `0x6c92` | `0x002aee` | [vm_func_002aee](callback_6c92_002aee.c) | `void vm_func_002aee(void)` |
| `0x6c93` | `0x01620c` | [persistent_vm_worker_6c93](callback_6c93_01620c_persistent_vm_worker_6c93.c) | `void persistent_vm_worker_6c93(void)` |
| `0x6c94` | `0x016680` | [cleanup_vm_worker_6c94](callback_6c94_016680_cleanup_vm_worker_6c94.c) | `void cleanup_vm_worker_6c94(void)` |
| `0x6c97` | `0x02f19b` | [sample_runtime_ring](callback_6c97_02f19b_sample_runtime_ring.c) | `void sample_runtime_ring(void)` |
| `0x6c98` | `0x030ed9` | [report_runtime_ring_sample](callback_6c98_030ed9_report_runtime_ring_sample.c) | `void report_runtime_ring_sample(void)` |
| `0x6c99` | `0x0316bd` | [report_suspicious_mappings_13525d9](callback_6c99_0316bd_report_suspicious_mappings_13525d9.c) | `void report_suspicious_mappings_13525d9(void)` |
| `0x6c9a` | `0x0328f1` | [runtime_state_machine_6c9a](callback_6c9a_0328f1_runtime_state_machine_6c9a.c) | `void runtime_state_machine_6c9a(void)` |

> 同一 VM 入口可以对应多个注册任务 ID。
