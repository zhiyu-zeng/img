void vm_func_01a9eb(void) {
    g_16a0 = (g_16a0 + 0x1);
    serializer.set_mode(0x3);
    serializer.append_u32((int64_t)(g_16a0));
    serializer.append_u32(g_1608);
    serializer.append_u32(g_160c);
    serializer.append_u32(g_1610);
    serializer.append_u32(g_1614);
    serializer.flush(0x1);
    return;
}
