void report_mapping_probe_135025c(void) {
    local_8 = 0x0;
    if (g_2ff0 == 0x0) {
        local_8 = 0xffffffff;
    } else {
        if (g_3008 == 0x0) {
            local_8 = 0xffffffff;
            map_probe_report_seq = (map_probe_report_seq + 0x1);
            serializer.set_mode(0x3);
            serializer.append_u32(0x135025c);
            serializer.append_u32((int64_t)(local_8));
            serializer.append_u32((int64_t)(map_probe_report_seq));
            serializer.append_u32((int64_t)(map_probe_record_count));
            serializer.append_u32(map_probe_records[0].key_tail.word[0]);
            serializer.append_u32(map_probe_records[0].key_tail.word[1]);
            serializer.append_u32(map_probe_records[0].key_tail.word[2]);
            serializer.append_u32(map_probe_records[0].range_word);
            serializer.append_u32(map_probe_records[0].address_word);
            serializer.append_u32(map_probe_records[0].classifier);
            serializer.append_u32(map_probe_records[1].key_tail.word[0]);
            serializer.append_u32(map_probe_records[1].key_tail.word[1]);
            serializer.append_u32(map_probe_records[1].key_tail.word[2]);
            serializer.append_u32(map_probe_records[1].range_word);
            serializer.append_u32(map_probe_records[1].address_word);
            serializer.append_u32(map_probe_records[1].classifier);
            serializer.append_u32(map_probe_records[2].key_tail.word[0]);
            serializer.append_u32(map_probe_records[2].key_tail.word[1]);
            serializer.append_u32(map_probe_records[2].key_tail.word[2]);
            serializer.append_u32(map_probe_records[2].range_word);
            serializer.append_u32(map_probe_records[2].address_word);
            serializer.append_u32(map_probe_records[2].classifier);
            serializer.append_u32(map_probe_records[3].key_tail.word[0]);
            serializer.append_u32(map_probe_records[3].key_tail.word[1]);
            serializer.append_u32(map_probe_records[3].key_tail.word[2]);
            serializer.append_u32(map_probe_records[3].range_word);
            serializer.append_u32(map_probe_records[3].address_word);
            serializer.append_u32(map_probe_records[3].classifier);
            serializer.append_u32(0x0);
            serializer.append_u32(0x0);
            serializer.flush(0x1);
            return;
        } else {
            if (g_3018 == 0x0) {
                local_8 = 0xffffffff;
                map_probe_report_seq = (map_probe_report_seq + 0x1);
                serializer.set_mode(0x3);
                serializer.append_u32(0x135025c);
                serializer.append_u32((int64_t)(local_8));
                serializer.append_u32((int64_t)(map_probe_report_seq));
                serializer.append_u32((int64_t)(map_probe_record_count));
                serializer.append_u32(map_probe_records[0].key_tail.word[0]);
                serializer.append_u32(map_probe_records[0].key_tail.word[1]);
                serializer.append_u32(map_probe_records[0].key_tail.word[2]);
                serializer.append_u32(map_probe_records[0].range_word);
                serializer.append_u32(map_probe_records[0].address_word);
                serializer.append_u32(map_probe_records[0].classifier);
                serializer.append_u32(map_probe_records[1].key_tail.word[0]);
                serializer.append_u32(map_probe_records[1].key_tail.word[1]);
                serializer.append_u32(map_probe_records[1].key_tail.word[2]);
                serializer.append_u32(map_probe_records[1].range_word);
                serializer.append_u32(map_probe_records[1].address_word);
                serializer.append_u32(map_probe_records[1].classifier);
                serializer.append_u32(map_probe_records[2].key_tail.word[0]);
                serializer.append_u32(map_probe_records[2].key_tail.word[1]);
                serializer.append_u32(map_probe_records[2].key_tail.word[2]);
                serializer.append_u32(map_probe_records[2].range_word);
                serializer.append_u32(map_probe_records[2].address_word);
                serializer.append_u32(map_probe_records[2].classifier);
                serializer.append_u32(map_probe_records[3].key_tail.word[0]);
                serializer.append_u32(map_probe_records[3].key_tail.word[1]);
                serializer.append_u32(map_probe_records[3].key_tail.word[2]);
                serializer.append_u32(map_probe_records[3].range_word);
                serializer.append_u32(map_probe_records[3].address_word);
                serializer.append_u32(map_probe_records[3].classifier);
                serializer.append_u32(0x0);
                serializer.append_u32(0x0);
                serializer.flush(0x1);
                return;
            } else {
                if (g_3028 != 0x0) {
                    if (!(g_3030 & 0x1)) {
                        vm_func_02a83d();
                        vm_func_02acf4();
                        g_3030 = 0x1;
                    }
                } else {
                    local_8 = 0xffffffff;
                    map_probe_report_seq = (map_probe_report_seq + 0x1);
                    serializer.set_mode(0x3);
                    serializer.append_u32(0x135025c);
                    serializer.append_u32((int64_t)(local_8));
                    serializer.append_u32((int64_t)(map_probe_report_seq));
                    serializer.append_u32((int64_t)(map_probe_record_count));
                    serializer.append_u32(map_probe_records[0].key_tail.word[0]);
                    serializer.append_u32(map_probe_records[0].key_tail.word[1]);
                    serializer.append_u32(map_probe_records[0].key_tail.word[2]);
                    serializer.append_u32(map_probe_records[0].range_word);
                    serializer.append_u32(map_probe_records[0].address_word);
                    serializer.append_u32(map_probe_records[0].classifier);
                    serializer.append_u32(map_probe_records[1].key_tail.word[0]);
                    serializer.append_u32(map_probe_records[1].key_tail.word[1]);
                    serializer.append_u32(map_probe_records[1].key_tail.word[2]);
                    serializer.append_u32(map_probe_records[1].range_word);
                    serializer.append_u32(map_probe_records[1].address_word);
                    serializer.append_u32(map_probe_records[1].classifier);
                    serializer.append_u32(map_probe_records[2].key_tail.word[0]);
                    serializer.append_u32(map_probe_records[2].key_tail.word[1]);
                    serializer.append_u32(map_probe_records[2].key_tail.word[2]);
                    serializer.append_u32(map_probe_records[2].range_word);
                    serializer.append_u32(map_probe_records[2].address_word);
                    serializer.append_u32(map_probe_records[2].classifier);
                    serializer.append_u32(map_probe_records[3].key_tail.word[0]);
                    serializer.append_u32(map_probe_records[3].key_tail.word[1]);
                    serializer.append_u32(map_probe_records[3].key_tail.word[2]);
                    serializer.append_u32(map_probe_records[3].range_word);
                    serializer.append_u32(map_probe_records[3].address_word);
                    serializer.append_u32(map_probe_records[3].classifier);
                    serializer.append_u32(0x0);
                    serializer.append_u32(0x0);
                    serializer.flush(0x1);
                    return;
                }
            }
        }
    }
    map_probe_report_seq = (map_probe_report_seq + 0x1);
    serializer.set_mode(0x3);
    serializer.append_u32(0x135025c);
    serializer.append_u32((int64_t)(local_8));
    serializer.append_u32((int64_t)(map_probe_report_seq));
    serializer.append_u32((int64_t)(map_probe_record_count));
    serializer.append_u32(map_probe_records[0].key_tail.word[0]);
    serializer.append_u32(map_probe_records[0].key_tail.word[1]);
    serializer.append_u32(map_probe_records[0].key_tail.word[2]);
    serializer.append_u32(map_probe_records[0].range_word);
    serializer.append_u32(map_probe_records[0].address_word);
    serializer.append_u32(map_probe_records[0].classifier);
    serializer.append_u32(map_probe_records[1].key_tail.word[0]);
    serializer.append_u32(map_probe_records[1].key_tail.word[1]);
    serializer.append_u32(map_probe_records[1].key_tail.word[2]);
    serializer.append_u32(map_probe_records[1].range_word);
    serializer.append_u32(map_probe_records[1].address_word);
    serializer.append_u32(map_probe_records[1].classifier);
    serializer.append_u32(map_probe_records[2].key_tail.word[0]);
    serializer.append_u32(map_probe_records[2].key_tail.word[1]);
    serializer.append_u32(map_probe_records[2].key_tail.word[2]);
    serializer.append_u32(map_probe_records[2].range_word);
    serializer.append_u32(map_probe_records[2].address_word);
    serializer.append_u32(map_probe_records[2].classifier);
    serializer.append_u32(map_probe_records[3].key_tail.word[0]);
    serializer.append_u32(map_probe_records[3].key_tail.word[1]);
    serializer.append_u32(map_probe_records[3].key_tail.word[2]);
    serializer.append_u32(map_probe_records[3].range_word);
    serializer.append_u32(map_probe_records[3].address_word);
    serializer.append_u32(map_probe_records[3].classifier);
    serializer.append_u32(0x0);
    serializer.append_u32(0x0);
    serializer.flush(0x1);
    return;
}
