void vm_func_01a82f(void) {
    if (((uint64_t)(g_1620)) >= 0x100000001) {
        if (((uint64_t)(g_1618)) >= 0x100000001) {
            local_0 = &g_1650;
            local_8 = &g_1650;
            local_10 = &g_16a0;
            while (local_8 != local_10) {
                local_18 = local_8;
                vm_func_01a18b(local_8);
                local_8 = (local_8 + 0x14);
                continue;
            }
            g_1608 = g_1660;
            g_160c = g_1674;
            g_1610 = g_1688;
            g_1614 = g_169c;
        }
    }
    return;
}
