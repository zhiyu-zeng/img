void sample_runtime_ring(void) {
    struct { uint64_t field_00; uint64_t field_08; uint64_t field_10; uint8_t field_18; uint8_t pad_19[3]; } mixed_tail_074;
    uint8_t* stack_buf_048 = (uint8_t*)(fp + 0x48); /* observed >= 0x8 bytes */
    uint8_t* stack_buf_050 = (uint8_t*)(fp + 0x50); /* observed >= 0xc bytes */
    sample_sequence = (sample_sequence + 0x1);
    if (sample_threshold_latched == 0x0) {
        if (sample_quota != 0x0) {
            sample_quota = (sample_quota + 0xffffffff);
            local_30 = sample_libue4_base;
            if (sample_libue4_base != 0x0) {
                slot_value_38 = vm_slot_get(0x1, 0x1);
                if (((uint64_t)(slot_value_38)) >= 0x100000000) {
                    if (((uint64_t)(slot_value_38)) < 0x800000000001) {
                        local_40 = (slot_value_38 + 0x8);
                        memcpy_checked(stack_buf_048, (slot_value_38 + 0x80), 0x8);
                        memcpy_checked(stack_buf_050, (local_40 + 0x1c), 0xc);
                        local_60 = (local_40 + 0x70);
                        local_68 = vm_func_02f828(local_30, (local_40 + 0x70));
                        local_70 = 0x0;
                        mixed_tail_074.field_00 = 0x0;
                        mixed_tail_074.field_08 = 0x0;
                        mixed_tail_074.field_10 = 0x0;
                        mixed_tail_074.field_18 = 0x0;
                        local_90 = 0xffffffff;
                        if (local_68 != 0x0) {
                            if (vm_func_02f918(local_30, local_68) != 0x0) {
                                memcpy_checked((fp + 0x94), stack_buf_048, 0x8);
                                local_70 = vm_func_02faa7(local_30, local_68, local_94, &mixed_tail_074, (fp + 0x90));
                            } else {
                                local_70 = 0xd;
                            }
                        } else {
                            local_70 = 0x3;
                        }
                        local_9c = 0x0;
                        if (local_70 == 0x0) {
                            if (mixed_tail_074.field_18 != 0x0) {
                                local_9c = point_vs_aabb_axis_delta_helper(stack_buf_050, &mixed_tail_074);
                            }
                        }
                        local_a0 = (sample_ring_write_index & 0xf);
                        sample_ring_records[sample_ring_write_index & 0xf].sequence = sample_sequence;
                        memcpy_checked(&sample_ring_records[sample_ring_write_index & 0xf].source8.word[0], stack_buf_048, 0x8);
                        memcpy_checked(&sample_ring_records[local_a0].vector3[0], stack_buf_050, 0xc);
                        memcpy_checked(&sample_ring_records[local_a0].state28.word[0], &mixed_tail_074, 0x1c);
                        sample_ring_records[local_a0].status0 = local_90;
                        sample_ring_records[local_a0].status1 = local_70;
                        *(uint32_t *)(&sample_ring_records[local_a0].metric) = local_9c;
                        sample_ring_write_index = (sample_ring_write_index + 0x1);
                        if (f32(local_9c) >= 20.0f) {
                            sample_threshold_latched = 0x1;
                            memcpy_checked(&sample_latched_record, &sample_ring_records[local_a0], 0x40);
                        }
                    }
                }
            }
        }
    }
    return;
}
