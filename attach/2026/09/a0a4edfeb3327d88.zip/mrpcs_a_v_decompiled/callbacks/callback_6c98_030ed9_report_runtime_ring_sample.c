void report_runtime_ring_sample(void) {
    local_0 = sample_libue4_base;
    if (sample_libue4_base != 0x0) {
        sample_report_tick = (sample_report_tick + 0x1);
        if (sample_threshold_latched == 0x0) {
            if (((uint32_t)((sample_report_tick - sample_last_rearm_tick))) >= 0x4) {
                sample_quota = 0x7;
                sample_last_rearm_tick = sample_report_tick;
            }
        }
        if (sample_threshold_latched == 0x0) {
            if (((uint32_t)(sample_ring_write_index)) > ((uint32_t)(sample_last_reported_write_index))) {
                local_8 = (sample_ring_write_index + 0xffffffff);
                local_c = ((sample_ring_write_index + 0xffffffff) & 0xf);
                memcpy_checked(&sample_report_record, ((((sample_ring_write_index + 0xffffffff) & 0xf) << 0x6) + &sample_ring_records), 0x40);
                sample_last_reported_write_index = sample_ring_write_index;
            }
        } else {
            memcpy_checked(&sample_report_record, &sample_latched_record, 0x40);
        }
        local_10 = ucvtf_f32_u32(sample_report_record);
        local_14 = scvtf_f32_i32(g_3d60);
        serializer.set_mode(0x1);
        serializer.append_u32(local_10);
        serializer.append_u32(local_14);
        serializer.append_u32(g_3d68);
        serializer.append_u32(g_3d6c);
        serializer.append_u32(g_3d70);
        serializer.append_u32(g_3d74);
        serializer.append_u32(g_3d78);
        serializer.append_u32(g_3d7c);
        serializer.append_u32(g_3d80);
        serializer.append_u32(g_3d84);
        serializer.append_u32(g_3d88);
        serializer.append_u32(g_3d94);
        serializer.append_u32(g_3d90);
        serializer.append_u32(g_3d98);
        serializer.append_u32(sample_threshold_latched);
        serializer.append_u32(0x0);
        serializer.flush(0x1);
    }
    return;
}
