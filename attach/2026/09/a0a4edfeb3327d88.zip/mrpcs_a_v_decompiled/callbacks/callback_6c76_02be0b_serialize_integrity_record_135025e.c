void serialize_integrity_record_135025e(void) {
    local_40 = 0x0;
    if (g_3790 == 0x0) {
        local_40 = 0xffffffff;
    } else {
        if (g_37a0 == 0x0) {
            goto loc_02c614;
        } else {
            if (g_37b0 != 0x0) {
                fnv1a_hash_region();
                if (!(g_37c8 & 0x1)) {
                    vm_func_02c99f();
                    g_37c8 = 0x1;
                }
            } else {
                goto loc_02c614;
            }
        }
    }
    g_37cc = (g_37cc + 0x1);
    local_44 = g_37e8;
    local_48 = g_37ec;
    local_4c = g_37f0;
    local_50 = g_37f4;
    local_54 = (g_37cc + 0x1);
    local_58 = ((local_54 * 0x9e3779b1) ^ 0xa5a5c3c3);
    local_5c = (local_58 ^ 0x135025e);
    local_60 = local_44;
    *(uint32_t *)((fp + 0x60) + 0x4) = local_48;
    *(uint32_t *)((fp + 0x60) + 0x8) = local_4c;
    *(uint32_t *)((fp + 0x60) + 0xc) = local_50;
    *(uint32_t *)((fp + 0x60) + 0x10) = local_54;
    local_74 = 0x811c9dc5;
    index_78 = 0x0;
    while (((int32_t)(index_78)) <= 4) {
        local_7c = *(uint32_t *)((fp + 0x60) + ((int64_t)(index_78) << 0x2));
        index_80 = 0x0;
        while (((int32_t)(index_80)) <= 3) {
            local_74 = ((local_74 ^ (local_7c & 0xff)) * 0x1000193);
            local_7c = (local_7c >> 0x8);
            index_80 = (index_80 + 0x1);
            continue;
        }
        index_78 = (index_78 + 0x1);
        continue;
    }
    local_84 = (local_74 ^ local_58);
    local_88 = ((((local_44 & 0xff) | ((local_48 & 0xff) << 0x8)) | ((local_4c & 0xff) << 0x10)) | (local_50 << 0x18));
    local_8c = (((((local_44 & 0xff) | ((local_48 & 0xff) << 0x8)) | ((local_4c & 0xff) << 0x10)) | (local_50 << 0x18)) ^ (local_58 * 0x85ebca6b));
    local_90 = ((local_58 ^ ((((local_4c & 0xff) | ((local_48 & 0xff) << 0x8)) | ((local_50 & 0xff) << 0x10)) | (local_44 << 0x18))) ^ 0xffffffff);
    local_90 = (local_90 + (local_54 * 0x3));
    local_94 = (((local_84 ^ local_8c) + (local_90 * 0x7)) - local_58);
    serializer.set_mode(0x3);
    serializer.append_u32(0x135025e);
    serializer.append_u32((int64_t)(local_40));
    serializer.append_u32((int64_t)(g_37cc));
    serializer.append_u32((int64_t)(g_37d0));
    serializer.append_u32((int64_t)(g_37d4));
    serializer.append_u32((int64_t)(g_37dc));
    serializer.append_u32(g_37d8);
    serializer.append_u32((int64_t)(g_37e8));
    serializer.append_u32((int64_t)(g_37ec));
    serializer.append_u32((int64_t)(g_37f0));
    serializer.append_u32((int64_t)(g_37f4));
    serializer.append_u32(local_5c);
    serializer.append_u32(local_84);
    serializer.append_u32(local_8c);
    serializer.append_u32(local_90);
    serializer.append_u32(0x0);
    serializer.append_u32(0x0);
    serializer.append_u32(0x0);
    serializer.append_u32(0x0);
    serializer.append_u32(0x0);
    serializer.append_u32(0x0);
    serializer.append_u32(0x0);
    serializer.append_u32(0x0);
    serializer.append_u32(0x0);
    serializer.append_u32(0x0);
    serializer.append_u32(0x0);
    serializer.append_u32(0x0);
    serializer.append_u32(0x0);
    serializer.append_u32(0x0);
    serializer.append_u32(0x0);
    serializer.flush(0x1);
    return;
}
