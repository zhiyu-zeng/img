void vm_func_010e76(void) {
    struct { uint64_t field_00; uint64_t field_08; uint64_t field_10; uint64_t field_18; } local_obj_018;
    local_obj_018.field_00 = 0x6c57;
    local_obj_018.field_08 = (g_03c0 + 0x371b18);
    local_obj_018.field_10 = (g_03c0 + 0x3c2d10);
    local_obj_018.field_18 = (g_03c0 + 0x3b9ab8);
    if (((uint64_t)(g_03b8)) >= 0x100000001) {
        g_03d0 = vm_func_00f6f0((g_03b8 + 0x157750), 0x8f0, &local_obj_018);
        g_03c8 = vm_func_00f6f0((g_03b8 + 0x25230), 0x13251c, &local_obj_018);
        g_03cc = vm_func_00f6f0((g_03b8 + 0x162b00), 0x36ef8, &local_obj_018);
    }
    if (((uint64_t)(g_03c0)) >= 0x100000001) {
        g_03dc = vm_func_00f6f0((g_03c0 + 0x500980), 0xd30, &local_obj_018);
        g_03d4 = vm_func_00f6f0((g_03c0 + 0x1b1170), 0x34f808, &local_obj_018);
        g_03d8 = vm_func_00f6f0((g_03c0 + 0x8cac0), 0x7adac, &local_obj_018);
        g_03e0 = *(uint32_t *)(g_03c0 + 0x2e44d0);
        g_03e4 = *(uint32_t *)(g_03c0 + 0x34fbb4);
    }
    return;
}
