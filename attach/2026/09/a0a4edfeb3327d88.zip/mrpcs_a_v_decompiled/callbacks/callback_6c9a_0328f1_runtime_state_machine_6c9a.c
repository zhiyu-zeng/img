void runtime_state_machine_6c9a(void) {
    if (g_3ecc == 0x0) {
        vm_func_032a90();
    }
    if (g_3ecc == 0x2) {
        vm_func_032c0f();
        vm_func_032dce();
        serializer_get_u16_config();
        vm_call_reg(0xcbbc);
        packet_append_typed_field((fp + 0x18), &g_3ed0, 0x5, 0xb6);
        packet_append_typed_field((fp + 0x18), &g_3ef1, 0x5, 0xb6);
        packet_append_typed_field((fp + 0x18), &g_3f12, 0x5, 0xb6);
        packet_periodic_flush((fp + 0x18), 0x1);
        vm_call_reg(0xcb46);
    }
    return;
}
