void vm_func_01b056(void) {
    if (!(g_18bc & 0x1)) {
        vm_func_01b207("AnoStamp");
        g_18b8 = vm_func_01cd5c("INTL_STORE_CHANNEL");
        g_18bc = 0x1;
    }
    serializer.set_mode(0x3);
    serializer.append_cstring(&g_16b4);
    serializer.append_u32(g_18b4);
    serializer.append_u32((int64_t)(g_18b8));
    serializer.append_cstring(&g_18d9);
    serializer.append_cstring(&g_18d9);
    serializer.append_cstring(&g_18d9);
    serializer.append_cstring(&g_18d9);
    serializer.append_cstring(&g_18d9);
    serializer.append_cstring(&g_18d9);
    serializer.append_cstring(&g_18d9);
    serializer.append_cstring(&g_18d9);
    serializer.flush(0x1);
    return;
}
