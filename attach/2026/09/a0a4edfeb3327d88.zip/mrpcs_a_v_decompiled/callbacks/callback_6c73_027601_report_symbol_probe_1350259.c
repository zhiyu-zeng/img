void report_symbol_probe_1350259(void) {
    local_8 = 0x0;
    if (g_2ea0 == 0x0) {
        local_8 = 0xffffffff;
    } else {
        if (g_2eb8 == 0x0) {
            local_8 = 0xffffffff;
            symbol_probe_report_seq = (symbol_probe_report_seq + 0x1);
            serializer.set_mode(0x3);
            serializer.append_u32(0x1350259);
            serializer.append_u32((int64_t)(local_8));
            serializer.append_u32((int64_t)(symbol_probe_report_seq));
            serializer.append_u32((int64_t)(symbol_probe_record_count));
            serializer.append_u32(symbol_probe_records[0].name0_tail.word[0]);
            serializer.append_u32(symbol_probe_records[0].name0_tail.word[1]);
            serializer.append_u32(symbol_probe_records[0].name1_tail.word[0]);
            serializer.append_u32(symbol_probe_records[0].name1_tail.word[1]);
            serializer.append_u32(symbol_probe_records[0].name2_tail.word[0]);
            serializer.append_u32(symbol_probe_records[0].name2_tail.word[1]);
            serializer.append_u32(symbol_probe_records[0].value_hi);
            serializer.append_u32(symbol_probe_records[0].value_lo);
            serializer.append_u32(symbol_probe_records[1].name0_tail.word[0]);
            serializer.append_u32(symbol_probe_records[1].name0_tail.word[1]);
            serializer.append_u32(symbol_probe_records[1].name1_tail.word[0]);
            serializer.append_u32(symbol_probe_records[1].name1_tail.word[1]);
            serializer.append_u32(symbol_probe_records[1].name2_tail.word[0]);
            serializer.append_u32(symbol_probe_records[1].name2_tail.word[1]);
            serializer.append_u32(symbol_probe_records[1].value_hi);
            serializer.append_u32(symbol_probe_records[1].value_lo);
            serializer.append_u32(symbol_probe_records[2].name0_tail.word[0]);
            serializer.append_u32(symbol_probe_records[2].name0_tail.word[1]);
            serializer.append_u32(symbol_probe_records[2].name1_tail.word[0]);
            serializer.append_u32(symbol_probe_records[2].name1_tail.word[1]);
            serializer.append_u32(symbol_probe_records[2].name2_tail.word[0]);
            serializer.append_u32(symbol_probe_records[2].name2_tail.word[1]);
            serializer.append_u32(symbol_probe_records[2].value_hi);
            serializer.append_u32(symbol_probe_records[2].value_lo);
            serializer.append_u32(0x0);
            serializer.append_u32(0x0);
            serializer.flush(0x1);
            return;
        } else {
            if (g_2ec8 == 0x0) {
                local_8 = 0xffffffff;
                symbol_probe_report_seq = (symbol_probe_report_seq + 0x1);
                serializer.set_mode(0x3);
                serializer.append_u32(0x1350259);
                serializer.append_u32((int64_t)(local_8));
                serializer.append_u32((int64_t)(symbol_probe_report_seq));
                serializer.append_u32((int64_t)(symbol_probe_record_count));
                serializer.append_u32(symbol_probe_records[0].name0_tail.word[0]);
                serializer.append_u32(symbol_probe_records[0].name0_tail.word[1]);
                serializer.append_u32(symbol_probe_records[0].name1_tail.word[0]);
                serializer.append_u32(symbol_probe_records[0].name1_tail.word[1]);
                serializer.append_u32(symbol_probe_records[0].name2_tail.word[0]);
                serializer.append_u32(symbol_probe_records[0].name2_tail.word[1]);
                serializer.append_u32(symbol_probe_records[0].value_hi);
                serializer.append_u32(symbol_probe_records[0].value_lo);
                serializer.append_u32(symbol_probe_records[1].name0_tail.word[0]);
                serializer.append_u32(symbol_probe_records[1].name0_tail.word[1]);
                serializer.append_u32(symbol_probe_records[1].name1_tail.word[0]);
                serializer.append_u32(symbol_probe_records[1].name1_tail.word[1]);
                serializer.append_u32(symbol_probe_records[1].name2_tail.word[0]);
                serializer.append_u32(symbol_probe_records[1].name2_tail.word[1]);
                serializer.append_u32(symbol_probe_records[1].value_hi);
                serializer.append_u32(symbol_probe_records[1].value_lo);
                serializer.append_u32(symbol_probe_records[2].name0_tail.word[0]);
                serializer.append_u32(symbol_probe_records[2].name0_tail.word[1]);
                serializer.append_u32(symbol_probe_records[2].name1_tail.word[0]);
                serializer.append_u32(symbol_probe_records[2].name1_tail.word[1]);
                serializer.append_u32(symbol_probe_records[2].name2_tail.word[0]);
                serializer.append_u32(symbol_probe_records[2].name2_tail.word[1]);
                serializer.append_u32(symbol_probe_records[2].value_hi);
                serializer.append_u32(symbol_probe_records[2].value_lo);
                serializer.append_u32(0x0);
                serializer.append_u32(0x0);
                serializer.flush(0x1);
                return;
            } else {
                if (g_2ed8 == 0x0) {
                    local_8 = 0xffffffff;
                    symbol_probe_report_seq = (symbol_probe_report_seq + 0x1);
                    serializer.set_mode(0x3);
                    serializer.append_u32(0x1350259);
                    serializer.append_u32((int64_t)(local_8));
                    serializer.append_u32((int64_t)(symbol_probe_report_seq));
                    serializer.append_u32((int64_t)(symbol_probe_record_count));
                    serializer.append_u32(symbol_probe_records[0].name0_tail.word[0]);
                    serializer.append_u32(symbol_probe_records[0].name0_tail.word[1]);
                    serializer.append_u32(symbol_probe_records[0].name1_tail.word[0]);
                    serializer.append_u32(symbol_probe_records[0].name1_tail.word[1]);
                    serializer.append_u32(symbol_probe_records[0].name2_tail.word[0]);
                    serializer.append_u32(symbol_probe_records[0].name2_tail.word[1]);
                    serializer.append_u32(symbol_probe_records[0].value_hi);
                    serializer.append_u32(symbol_probe_records[0].value_lo);
                    serializer.append_u32(symbol_probe_records[1].name0_tail.word[0]);
                    serializer.append_u32(symbol_probe_records[1].name0_tail.word[1]);
                    serializer.append_u32(symbol_probe_records[1].name1_tail.word[0]);
                    serializer.append_u32(symbol_probe_records[1].name1_tail.word[1]);
                    serializer.append_u32(symbol_probe_records[1].name2_tail.word[0]);
                    serializer.append_u32(symbol_probe_records[1].name2_tail.word[1]);
                    serializer.append_u32(symbol_probe_records[1].value_hi);
                    serializer.append_u32(symbol_probe_records[1].value_lo);
                    serializer.append_u32(symbol_probe_records[2].name0_tail.word[0]);
                    serializer.append_u32(symbol_probe_records[2].name0_tail.word[1]);
                    serializer.append_u32(symbol_probe_records[2].name1_tail.word[0]);
                    serializer.append_u32(symbol_probe_records[2].name1_tail.word[1]);
                    serializer.append_u32(symbol_probe_records[2].name2_tail.word[0]);
                    serializer.append_u32(symbol_probe_records[2].name2_tail.word[1]);
                    serializer.append_u32(symbol_probe_records[2].value_hi);
                    serializer.append_u32(symbol_probe_records[2].value_lo);
                    serializer.append_u32(0x0);
                    serializer.append_u32(0x0);
                    serializer.flush(0x1);
                    return;
                } else {
                    if (g_2ee8 != 0x0) {
                        if (!(g_2ef0 & 0x1)) {
                            vm_func_027b4a();
                            vm_func_027fcf();
                            vm_func_0283ea();
                            g_2ef0 = 0x1;
                        }
                    } else {
                        local_8 = 0xffffffff;
                        symbol_probe_report_seq = (symbol_probe_report_seq + 0x1);
                        serializer.set_mode(0x3);
                        serializer.append_u32(0x1350259);
                        serializer.append_u32((int64_t)(local_8));
                        serializer.append_u32((int64_t)(symbol_probe_report_seq));
                        serializer.append_u32((int64_t)(symbol_probe_record_count));
                        serializer.append_u32(symbol_probe_records[0].name0_tail.word[0]);
                        serializer.append_u32(symbol_probe_records[0].name0_tail.word[1]);
                        serializer.append_u32(symbol_probe_records[0].name1_tail.word[0]);
                        serializer.append_u32(symbol_probe_records[0].name1_tail.word[1]);
                        serializer.append_u32(symbol_probe_records[0].name2_tail.word[0]);
                        serializer.append_u32(symbol_probe_records[0].name2_tail.word[1]);
                        serializer.append_u32(symbol_probe_records[0].value_hi);
                        serializer.append_u32(symbol_probe_records[0].value_lo);
                        serializer.append_u32(symbol_probe_records[1].name0_tail.word[0]);
                        serializer.append_u32(symbol_probe_records[1].name0_tail.word[1]);
                        serializer.append_u32(symbol_probe_records[1].name1_tail.word[0]);
                        serializer.append_u32(symbol_probe_records[1].name1_tail.word[1]);
                        serializer.append_u32(symbol_probe_records[1].name2_tail.word[0]);
                        serializer.append_u32(symbol_probe_records[1].name2_tail.word[1]);
                        serializer.append_u32(symbol_probe_records[1].value_hi);
                        serializer.append_u32(symbol_probe_records[1].value_lo);
                        serializer.append_u32(symbol_probe_records[2].name0_tail.word[0]);
                        serializer.append_u32(symbol_probe_records[2].name0_tail.word[1]);
                        serializer.append_u32(symbol_probe_records[2].name1_tail.word[0]);
                        serializer.append_u32(symbol_probe_records[2].name1_tail.word[1]);
                        serializer.append_u32(symbol_probe_records[2].name2_tail.word[0]);
                        serializer.append_u32(symbol_probe_records[2].name2_tail.word[1]);
                        serializer.append_u32(symbol_probe_records[2].value_hi);
                        serializer.append_u32(symbol_probe_records[2].value_lo);
                        serializer.append_u32(0x0);
                        serializer.append_u32(0x0);
                        serializer.flush(0x1);
                        return;
                    }
                }
            }
        }
    }
    symbol_probe_report_seq = (symbol_probe_report_seq + 0x1);
    serializer.set_mode(0x3);
    serializer.append_u32(0x1350259);
    serializer.append_u32((int64_t)(local_8));
    serializer.append_u32((int64_t)(symbol_probe_report_seq));
    serializer.append_u32((int64_t)(symbol_probe_record_count));
    serializer.append_u32(symbol_probe_records[0].name0_tail.word[0]);
    serializer.append_u32(symbol_probe_records[0].name0_tail.word[1]);
    serializer.append_u32(symbol_probe_records[0].name1_tail.word[0]);
    serializer.append_u32(symbol_probe_records[0].name1_tail.word[1]);
    serializer.append_u32(symbol_probe_records[0].name2_tail.word[0]);
    serializer.append_u32(symbol_probe_records[0].name2_tail.word[1]);
    serializer.append_u32(symbol_probe_records[0].value_hi);
    serializer.append_u32(symbol_probe_records[0].value_lo);
    serializer.append_u32(symbol_probe_records[1].name0_tail.word[0]);
    serializer.append_u32(symbol_probe_records[1].name0_tail.word[1]);
    serializer.append_u32(symbol_probe_records[1].name1_tail.word[0]);
    serializer.append_u32(symbol_probe_records[1].name1_tail.word[1]);
    serializer.append_u32(symbol_probe_records[1].name2_tail.word[0]);
    serializer.append_u32(symbol_probe_records[1].name2_tail.word[1]);
    serializer.append_u32(symbol_probe_records[1].value_hi);
    serializer.append_u32(symbol_probe_records[1].value_lo);
    serializer.append_u32(symbol_probe_records[2].name0_tail.word[0]);
    serializer.append_u32(symbol_probe_records[2].name0_tail.word[1]);
    serializer.append_u32(symbol_probe_records[2].name1_tail.word[0]);
    serializer.append_u32(symbol_probe_records[2].name1_tail.word[1]);
    serializer.append_u32(symbol_probe_records[2].name2_tail.word[0]);
    serializer.append_u32(symbol_probe_records[2].name2_tail.word[1]);
    serializer.append_u32(symbol_probe_records[2].value_hi);
    serializer.append_u32(symbol_probe_records[2].value_lo);
    serializer.append_u32(0x0);
    serializer.append_u32(0x0);
    serializer.flush(0x1);
    return;
}
