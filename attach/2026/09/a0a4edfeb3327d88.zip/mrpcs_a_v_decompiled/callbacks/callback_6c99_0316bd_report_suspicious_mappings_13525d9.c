void report_suspicious_mappings_13525d9(void) {
    local_8 = 0x0;
    if (fn_sscanf_maps == 0x0) {
        local_8 = 0xffffffff;
    } else {
        if (fn_open_presence != 0x0) {
            if (((uint32_t)(((suspicious_scan_tick * 0xcccccccd) + 0x19999999))) <= 0x33333332) {
                if (((int32_t)(suspicious_scan_tick)) <= 10) {
                    scan_proc_self_maps_suspicious_regions();
                }
            }
        } else {
            goto loc_031d1b;
        }
    }
    if (suspicious_record_count == 0x0) {
        suspicious_record_count = 0x1;
    }
    local_c = ((suspicious_scan_tick) % (uint64_t)(suspicious_record_count));
    if (((uint32_t)(((suspicious_scan_tick) % (uint64_t)(suspicious_record_count)))) > 0x5) {
        serializer.set_mode(0x3);
        serializer.append_u32(0x13525d9);
        serializer.append_u32((int64_t)(local_8));
        serializer.append_u32((int64_t)(suspicious_scan_tick));
        serializer.append_u32((int64_t)(noaccess_resident_map_count));
        serializer.append_u32((int64_t)(shadowhook_map_count));
        serializer.append_u32((int64_t)(rwx_anon_lma_count));
        serializer.append_u32(0x0);
        serializer.append_u32(0x0);
        serializer.append_u32(0x0);
        serializer.append_u32(0x0);
        serializer.append_u32(0x0);
        serializer.append_u32(0x0);
        serializer.append_u32(0x0);
        serializer.append_u32(0x0);
        serializer.append_u32(0x0);
        serializer.append_u32(0x0);
        serializer.append_u32(0x0);
        serializer.append_u32(0x0);
        serializer.append_u32(0x0);
        serializer.append_u32(0x0);
        serializer.append_u32(0x0);
        serializer.append_u32(0x0);
        serializer.append_u32(0x0);
        serializer.append_u32(0x0);
        serializer.append_u32(0x0);
        serializer.append_u32(0x0);
        serializer.append_u32(0x0);
        serializer.append_u32(0x0);
        serializer.append_u32(0x0);
        serializer.append_u32(0x0);
        serializer.flush(0x1);
    } else {
        if (((uint32_t)(local_c)) >= ((uint32_t)(suspicious_record_count))) {
            serializer.set_mode(0x3);
            serializer.append_u32(0x13525d9);
            serializer.append_u32((int64_t)(local_8));
            serializer.append_u32((int64_t)(suspicious_scan_tick));
            serializer.append_u32((int64_t)(noaccess_resident_map_count));
            serializer.append_u32((int64_t)(shadowhook_map_count));
            serializer.append_u32((int64_t)(rwx_anon_lma_count));
            serializer.append_u32(0x0);
            serializer.append_u32(0x0);
            serializer.append_u32(0x0);
            serializer.append_u32(0x0);
            serializer.append_u32(0x0);
            serializer.append_u32(0x0);
            serializer.append_u32(0x0);
            serializer.append_u32(0x0);
            serializer.append_u32(0x0);
            serializer.append_u32(0x0);
            serializer.append_u32(0x0);
            serializer.append_u32(0x0);
            serializer.append_u32(0x0);
            serializer.append_u32(0x0);
            serializer.append_u32(0x0);
            serializer.append_u32(0x0);
            serializer.append_u32(0x0);
            serializer.append_u32(0x0);
            serializer.append_u32(0x0);
            serializer.append_u32(0x0);
            serializer.append_u32(0x0);
            serializer.append_u32(0x0);
            serializer.append_u32(0x0);
            serializer.append_u32(0x0);
            serializer.flush(0x1);
            suspicious_scan_tick = (suspicious_scan_tick + 0x1);
            return;
        } else {
            serializer.set_mode(0x3);
            serializer.append_u32(0x13525d9);
            serializer.append_u32((int64_t)(local_8));
            serializer.append_u32((int64_t)(suspicious_scan_tick));
            serializer.append_u32((int64_t)(noaccess_resident_map_count));
            serializer.append_u32((int64_t)(shadowhook_map_count));
            serializer.append_u32((int64_t)(rwx_anon_lma_count));
            serializer.append_u32(0x0);
            serializer.append_u32(0x0);
            serializer.append_u32(0x0);
            serializer.append_u32(0x0);
            serializer.append_u32(0x0);
            serializer.append_u32(0x0);
            serializer.append_u32(0x0);
            serializer.append_u32(suspicious_map_records[local_c].span);
            serializer.append_u32(suspicious_map_records[local_c].reason);
            serializer.append_u32(suspicious_map_records[local_c].start_hi);
            serializer.append_u32(suspicious_map_records[local_c].start_lo);
            serializer.append_u32(suspicious_map_records[local_c].aux0);
            serializer.append_u32(suspicious_map_records[local_c].aux1);
            serializer.append_u32(0x0);
            serializer.append_u32(0x0);
            serializer.append_u32(0x0);
            serializer.append_u32(0x0);
            serializer.append_u32(0x0);
            serializer.append_u32(0x0);
            serializer.append_u32(0x0);
            serializer.append_u32(0x0);
            serializer.append_u32(0x0);
            serializer.append_u32(0x0);
            serializer.append_u32(0x0);
            serializer.flush(0x1);
        }
    }
    suspicious_scan_tick = (suspicious_scan_tick + 0x1);
    return;
}
