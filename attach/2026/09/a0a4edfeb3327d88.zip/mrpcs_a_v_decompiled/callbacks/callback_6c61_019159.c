void vm_func_019159(void) {
    g_1600 = (g_1600 + 0x1);
    if ((((g_1600 + 0x1)) % (uint64_t)(0x708)) == 0x1) {
        if (g_15f8 != 0x0) {
            local_20 = 0x0;
            local_24 = 0x0;
            local_28 = 0x0;
            local_2c = 0x0;
            local_30 = 0x0;
            local_34 = 0x0;
            local_38 = 0x0;
            local_3c = 0x0;
            local_40 = 0x0;
            local_44 = 0x0;
            local_48 = 0x0;
            local_4c = 0x0;
            local_50 = 0x0;
            local_58 = *(uint64_t *)(g_15f8 + 0x20aa87a0);
            if (*(uint64_t *)(g_15f8 + 0x20aa87a0) != 0x0) {
                local_60 = *(uint64_t *)(local_58 + 0x140);
                if (*(uint64_t *)(local_58 + 0x140) != 0x0) {
                    local_68 = (local_60 + 0x5b8);
                    local_20 = *(uint32_t *)(local_60 + 0x5bc);
                    local_24 = *(uint32_t *)(local_60 + 0x5c8);
                }
                local_70 = *(uint64_t *)(local_58 + 0x190);
                if (*(uint64_t *)(local_58 + 0x190) != 0x0) {
                    local_78 = *(uint64_t *)(local_70 + 0x38);
                    if (*(uint64_t *)(local_70 + 0x38) != 0x0) {
                        local_80 = *(uint64_t *)(local_78);
                        if (*(uint64_t *)(local_78) != 0x0) {
                            local_88 = *(uint64_t *)(local_80 + 0x30);
                            if (*(uint64_t *)(local_80 + 0x30) != 0x0) {
                                local_90 = *(uint64_t *)(local_88 + 0x3a0);
                                if (*(uint64_t *)(local_88 + 0x3a0) != 0x0) {
                                    local_98 = *(uint64_t *)(local_90);
                                    if ((*(uint64_t *)(local_90) - g_15f8) != 0x1f153e90) {
                                        local_a0 = *(uint64_t *)(local_90 + 0x3d8);
                                        if (*(uint64_t *)(local_90 + 0x3d8) != 0x0) {
                                            local_28 = *(uint32_t *)(local_a0 + 0x198);
                                            local_2c = *(uint32_t *)(local_a0 + 0x1a0);
                                            local_48 = *(uint32_t *)(local_a0 + 0xe40);
                                            local_50 = *(uint32_t *)(local_a0 + 0x1b8);
                                            local_a8 = *(uint64_t *)(local_a0 + 0xa58);
                                            if (*(uint64_t *)(local_a0 + 0xa58) != 0x0) {
                                                local_30 = *(uint32_t *)(local_a8 + 0x74);
                                                local_34 = *(uint32_t *)(local_a8 + 0x78);
                                                local_38 = *(uint32_t *)(local_a8 + 0x7c);
                                                local_3c = *(uint32_t *)(local_a8 + 0x80);
                                                local_40 = *(uint32_t *)(local_a8 + 0x84);
                                                local_44 = *(uint32_t *)(local_a8 + 0x88);
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
                local_b0 = *(uint64_t *)(g_15f8 + 0x2006d1c0);
                if (*(uint64_t *)(g_15f8 + 0x2006d1c0) != 0x0) {
                    local_b8 = *(uint64_t *)(local_b0 + 0x8);
                    if (*(uint64_t *)(local_b0 + 0x8) != 0x0) {
                        local_c0 = *(uint64_t *)(local_b8 + 0x250);
                        if (*(uint64_t *)(local_b8 + 0x250) != 0x0) {
                            local_c8 = *(uint64_t *)(local_c0 + 0x40);
                            local_d0 = *(uint32_t *)(local_c0 + 0x48);
                            local_4c = 0x0;
                            if (*(uint64_t *)(local_c0 + 0x40) != 0x0) {
                                if (local_d0 == 0x13) {
                                    index_d4 = 0x0;
                                    while (((int32_t)(index_d4)) < ((int32_t)(local_d0))) {
                                        local_d8 = *(uint64_t *)(local_c8 + ((int64_t)(index_d4) << 0x3));
                                        if (*(uint64_t *)(local_c8 + ((int64_t)(index_d4) << 0x3)) != 0x0) {
                                            local_e0 = *(uint64_t *)(local_d8 + 0x48);
                                            if (*(uint64_t *)(local_d8 + 0x48) != 0x0) {
                                                local_e8 = *(uint32_t *)(local_e0 + 0x48);
                                                local_ec = *(uint32_t *)(local_e0 + 0x4c);
                                                local_4c = (local_4c + (*(uint32_t *)(local_e0 + 0x48) + *(uint32_t *)(local_e0 + 0x4c)));
                                            }
                                        }
                                        index_d4 = (index_d4 + 0x1);
                                        continue;
                                    }
                                }
                            }
                        }
                    }
                }
                local_28 = (f32(local_28) * 1000.0f);
                local_2c = (f32(local_2c) * 1000.0f);
                local_30 = (f32(local_30) * 1000.0f);
                local_34 = (f32(local_34) * 1000.0f);
                local_38 = (f32(local_38) * 1000.0f);
                local_3c = (f32(local_3c) * 1000.0f);
                local_40 = (f32(local_40) * 1000.0f);
                local_44 = (f32(local_44) * 1000.0f);
                local_48 = (f32(local_48) * 1000.0f);
                serializer.set_mode(0x1);
                serializer.append_u32(g_1600);
                serializer.append_u32(local_20);
                serializer.append_u32(local_24);
                serializer.append_u32(fcvtz_u64_f32(f32(local_28)));
                serializer.append_u32(fcvtz_u64_f32(f32(local_2c)));
                serializer.append_u32(fcvtz_u64_f32(f32(local_30)));
                serializer.append_u32(fcvtz_u64_f32(f32(local_34)));
                serializer.append_u32(fcvtz_u64_f32(f32(local_38)));
                serializer.append_u32(fcvtz_u64_f32(f32(local_3c)));
                serializer.append_u32(fcvtz_u64_f32(f32(local_40)));
                serializer.append_u32(fcvtz_u64_f32(f32(local_44)));
                serializer.append_u32(fcvtz_u64_f32(f32(local_48)));
                serializer.append_u32(local_4c);
                serializer.append_u32(local_50);
                serializer.append_u32(0x0);
                serializer.append_u32(0x0);
                serializer.append_u32(0x0);
                serializer.append_u32(0x0);
                serializer.append_u32(0x0);
                serializer.append_u32(0x0);
                serializer.append_u32(0x0);
                serializer.append_u32(0x0);
                serializer.append_u32(0x0);
                serializer.append_u32(0x0);
                serializer.append_u32(0x0);
                serializer.append_u32(0x0);
                serializer.append_u32(0x0);
                serializer.append_u32(0x0);
                serializer.append_u32(0x0);
                serializer.append_u32(0x0);
                serializer.flush(0x1);
            }
        }
    }
    return;
}
