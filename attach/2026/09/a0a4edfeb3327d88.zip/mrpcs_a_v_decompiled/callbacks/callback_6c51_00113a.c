void vm_func_00113a(void) {
    uint8_t* stack_buf_0d0 = (uint8_t*)(fp + 0xd0); /* observed >= 0x80 bytes */
    g_00b8 = (g_00b8 + 0x1);
    g_004a = *(uint16_t *)(g_00b0 + 0x554860);
    g_004c = *(uint16_t *)(g_00b0 + 0x554cc8);
    g_004e = *(uint16_t *)(g_00b0 + 0x554d58);
    g_0050 = *(uint16_t *)(g_00b0 + 0x554d90);
    g_0052 = *(uint16_t *)(g_00b0 + 0x554dc0);
    g_0054 = *(uint16_t *)(g_00b0 + 0x554df0);
    g_0056 = *(uint16_t *)(g_00b0 + 0x554e18);
    g_0058 = *(uint16_t *)(g_00b0 + 0x5555d0);
    g_005a = *(uint16_t *)(g_00b0 + 0x555608);
    g_005c = *(uint16_t *)(g_00b0 + 0x555638);
    g_005e = *(uint16_t *)(g_00b0 + 0x555668);
    g_0060 = *(uint16_t *)(g_00b0 + 0x555698);
    g_0062 = *(uint16_t *)(g_00b0 + 0x557978);
    g_0064 = *(uint16_t *)(g_00b0 + 0x5579a8);
    g_0066 = *(uint16_t *)(g_00b0 + 0x557bf0);
    g_0068 = *(uint16_t *)(g_00b0 + 0x5587e0);
    g_006a = *(uint16_t *)(g_00b0 + 0x558830);
    g_006c = *(uint16_t *)(g_00b0 + 0x558878);
    g_006e = *(uint16_t *)(g_00b0 + 0x5588a8);
    g_0070 = *(uint16_t *)(g_00b0 + 0x558970);
    g_0072 = *(uint16_t *)(g_00b0 + 0x559998);
    g_0074 = *(uint16_t *)(g_00b0 + 0x5599e0);
    g_0076 = *(uint16_t *)(g_00b0 + 0x559b00);
    g_0078 = *(uint16_t *)(g_00b0 + 0x559b30);
    g_007a = *(uint16_t *)(g_00b0 + 0x559b88);
    g_007c = *(uint16_t *)(g_00b0 + 0x559bb8);
    g_007e = *(uint16_t *)(g_00b0 + 0x559bf0);
    g_0080 = *(uint16_t *)(g_00b0 + 0x559c20);
    local_28 = *(uint64_t *)(g_00b0 + 0x54fb60);
    if (((uint64_t)(*(uint64_t *)(g_00b0 + 0x54fb60))) >= 0x1001) {
        g_0082 = *(uint16_t *)(local_28 + 0x40);
    }
    local_30 = *(uint64_t *)(g_00b0 + 0x54fc18);
    if (((uint64_t)(*(uint64_t *)(g_00b0 + 0x54fc18))) >= 0x1001) {
        g_0084 = *(uint16_t *)(local_30 + 0x40);
    }
    local_38 = *(uint64_t *)(g_00b0 + 0x54ff38);
    if (((uint64_t)(*(uint64_t *)(g_00b0 + 0x54ff38))) >= 0x1001) {
        g_0086 = *(uint16_t *)(local_38 + 0x40);
    }
    local_40 = *(uint64_t *)(g_00b0 + 0x559b28);
    if (((uint64_t)(*(uint64_t *)(g_00b0 + 0x559b28))) >= 0x1001) {
        g_0088 = *(uint16_t *)(local_40 + 0xc);
    }
    local_48 = *(uint64_t *)(g_00b0 + 0x554d50);
    if (((uint64_t)(*(uint64_t *)(g_00b0 + 0x554d50))) >= 0x1001) {
        g_008a = *(uint16_t *)(local_48 + 0x48);
    }
    local_50 = *(uint64_t *)(g_00b0 + 0x555630);
    if (((uint64_t)(*(uint64_t *)(g_00b0 + 0x555630))) >= 0x1001) {
        g_008c = *(uint16_t *)(local_50);
    }
    local_58 = *(uint64_t *)(g_00b0 + 0x558870);
    if (((uint64_t)(*(uint64_t *)(g_00b0 + 0x558870))) >= 0x1001) {
        index_60 = 0x0;
        while (((int32_t)(index_60)) <= 19) {
            g_008e = *(uint16_t *)(local_58 + 0x10);
            if (*(uint16_t *)(local_58 + 0x10) != 0x4000) {
                g_0094 = (g_0094 + 0x1);
                g_0098 = g_008e;
            }
            index_60 = (index_60 + 0x1);
            continue;
        }
    }
    local_68 = *(uint64_t *)(g_00b0 + 0x5579a0);
    if (((uint64_t)(*(uint64_t *)(g_00b0 + 0x5579a0))) >= 0x1001) {
        g_0090 = *(uint16_t *)(local_68 + 0x18);
    }
    local_70 = *(uint64_t *)(g_00b0 + 0x54fed8);
    if (((uint64_t)(*(uint64_t *)(g_00b0 + 0x54fed8))) >= 0x1001) {
        local_78 = *(uint64_t *)(local_70 + 0x10);
        if (((uint64_t)(*(uint64_t *)(local_70 + 0x10))) >= 0x1001) {
            local_80 = *(uint64_t *)(local_78);
            if (((uint64_t)(*(uint64_t *)(local_78))) >= 0x1001) {
                local_88 = *(uint32_t *)(local_80);
                g_00a0 = *(uint32_t *)(local_80);
            }
        }
    }
    local_90 = *(uint64_t *)(g_00b0 + 0x559c18);
    if (((uint32_t)(g_00b8)) >= 0x3) {
        if (((uint64_t)(local_90)) >= 0x1001) {
            local_98 = *(uint64_t *)(local_90 + 0x278);
            local_a0 = *(uint32_t *)(local_90 + 0x288);
            if (((uint64_t)(*(uint64_t *)(local_90 + 0x278))) >= 0x1001) {
                if (((uint32_t)(local_a0)) >= 0x8) {
                    local_a8 = (local_98 + 0x20);
                    local_b0 = 0x2;
                    mincore(((local_98 + 0x20) & 0xfffffffffffff000), 0x1000, (fp + 0xb0));
                    local_b8 = (local_98 + 0x170);
                    local_c0 = 0x2;
                    mincore(((local_98 + 0x170) & 0xfffffffffffff000), 0x1000, (fp + 0xc0));
                    if (local_b0 == 0x1) {
                        if (local_c0 == 0x1) {
                            g_00a4 = *(uint32_t *)(local_98 + 0x20);
                            g_00a8 = *(uint32_t *)(local_98 + 0x170);
                        }
                    }
                }
            }
        }
    }
    if ((g_00b8 & 0x3) == 0x1) {
        local_c4 = 0x0;
        local_c8 = 0x0;
        if (vm_func_000f25((g_00b0 + 0x1dcbd0), (fp + 0xc4), (fp + 0xc8)) == 0x0) {
            g_00bc = (g_00bc | 0x80000000);
        }
        if (vm_func_000f25((g_00b0 + 0x29f924), (fp + 0xc4), (fp + 0xc8)) == 0x0) {
            g_00bc = (g_00bc | 0x80000000);
        }
        if (vm_func_000f25((g_00b0 + 0x39bbe8), (fp + 0xc4), (fp + 0xc8)) == 0x0) {
            g_00bc = (g_00bc | 0x80000000);
        }
        if (vm_func_000f25((g_00b0 + 0x3cdcf8), (fp + 0xc4), (fp + 0xc8)) == 0x0) {
            g_00bc = (g_00bc | 0x80000000);
        }
        if (vm_func_000f25((g_00b0 + 0x3d07cc), (fp + 0xc4), (fp + 0xc8)) == 0x0) {
            g_00bc = (g_00bc | 0x80000000);
        }
        if (vm_func_000f25((g_00b0 + 0x47bdcc), (fp + 0xc4), (fp + 0xc8)) == 0x0) {
            g_00bc = (g_00bc | 0x80000000);
        }
        if (vm_func_000f25((g_00b0 + 0x4971d8), (fp + 0xc4), (fp + 0xc8)) == 0x0) {
            g_00bc = (g_00bc | 0x80000000);
        }
        g_00c0 = (local_c4 & 0x7fffffff);
        g_00c4 = (local_c8 & 0x7fffffff);
        if ((g_00b8 & 0x7) == 0x1) {
            memset(stack_buf_0d0, 0x0, 0x80);
            local_150 = vm_func_000613("/data/adb", stack_buf_0d0);
            if (((int32_t)(local_150)) <= -1) {
                local_150 = (0x0 - local_150);
            }
            g_00bc = (g_00bc | (local_150 & 0xf));
            local_150 = vm_func_000613("/data/adb/ksud", stack_buf_0d0);
            if (((int32_t)(local_150)) <= -1) {
                local_150 = (0x0 - local_150);
            }
            g_00bc = (g_00bc | ((local_150 & 0xf) << 0x4));
            local_150 = vm_func_000613("data/adb/ksud", stack_buf_0d0);
            if (((int32_t)(local_150)) <= -1) {
                local_150 = (0x0 - local_150);
            }
            g_00bc = (g_00bc | ((local_150 & 0xf) << 0x8));
            memset(stack_buf_0d0, 0x0, 0x80);
            local_150 = vm_func_000613("/data/lost+found/", stack_buf_0d0);
            if (local_150 == 0x0) {
                g_00c8 = *(uint64_t *)(stack_buf_0d0 + 0x68);
                if (*(uint64_t *)(stack_buf_0d0 + 0x68) != *(uint64_t *)(stack_buf_0d0 + 0x48)) {
                    g_00bc = (g_00bc | 0x1000);
                    if (*(uint64_t *)(stack_buf_0d0 + 0x58) == *(uint64_t *)(stack_buf_0d0 + 0x68)) {
                        g_00bc = (g_00bc | 0x2000);
                    }
                    if (((int64_t)(*(uint64_t *)(stack_buf_0d0 + 0x68))) > ((int64_t)((time(0x0) + 0xfffffffffffeae80)))) {
                        g_00bc = (g_00bc | 0x4000);
                    }
                }
            }
        }
    }
    return;
}
