void vm_func_018be3(void) {
    if (((uint64_t)(g_05a8)) >= 0x100000001) {
        local_0 = *(uint64_t *)(g_05a8 + 0x1fc8c4c0);
        if (((uint64_t)(*(uint64_t *)(g_05a8 + 0x1fc8c4c0))) >= 0x100000001) {
            local_8 = *(uint64_t *)(local_0 + 0x10);
            g_05b0 = (*(uint64_t *)(local_0 + 0x10) - g_05a8);
        }
        local_10 = 0x0;
        local_18 = 0x0;
        local_20 = 0x0;
        g_05b8 = 0x0;
        g_05c0 = 0x0;
        g_05c8 = 0x0;
    }
    return;
}
