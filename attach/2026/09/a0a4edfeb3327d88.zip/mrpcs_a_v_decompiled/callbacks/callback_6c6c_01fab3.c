void vm_func_01fab3(void) {
    local_8 = 0x0;
    if (g_21c8 == 0x0) {
        local_8 = 0xffffffff;
    } else {
        if (g_21e0 == 0x0) {
            local_8 = 0xffffffff;
            g_220c = (g_220c + 0x1);
            serializer.set_mode(0x3);
            serializer.append_u32(0x1350251);
            serializer.append_u32((int64_t)(local_8));
            serializer.append_u32((int64_t)(g_220c));
            serializer.append_u32((int64_t)(g_2210));
            serializer.append_u32(g_2214);
            serializer.append_u32(g_2218);
            serializer.append_u32(g_221c);
            serializer.append_u32(g_2220);
            serializer.append_u32(g_2224);
            serializer.append_u32(g_2228);
            serializer.append_u32(g_222c);
            serializer.append_u32(g_2230);
            serializer.append_u32(g_2234);
            serializer.append_u32(g_2238);
            serializer.append_u32(g_223c);
            serializer.append_u32(g_2240);
            serializer.append_u32(g_2244);
            serializer.append_u32(g_2248);
            serializer.append_u32(g_224c);
            serializer.append_u32(g_2250);
            serializer.append_u32(g_2254);
            serializer.append_u32(g_2258);
            serializer.append_u32(g_225c);
            serializer.append_u32(g_2260);
            serializer.append_u32(g_2264);
            serializer.append_u32(g_2268);
            serializer.append_u32(g_226c);
            serializer.append_u32(g_2270);
            serializer.append_u32(g_2274);
            serializer.append_u32(0x0);
            serializer.flush(0x1);
            return;
        } else {
            if (g_21f0 == 0x0) {
                local_8 = 0xffffffff;
                g_220c = (g_220c + 0x1);
                serializer.set_mode(0x3);
                serializer.append_u32(0x1350251);
                serializer.append_u32((int64_t)(local_8));
                serializer.append_u32((int64_t)(g_220c));
                serializer.append_u32((int64_t)(g_2210));
                serializer.append_u32(g_2214);
                serializer.append_u32(g_2218);
                serializer.append_u32(g_221c);
                serializer.append_u32(g_2220);
                serializer.append_u32(g_2224);
                serializer.append_u32(g_2228);
                serializer.append_u32(g_222c);
                serializer.append_u32(g_2230);
                serializer.append_u32(g_2234);
                serializer.append_u32(g_2238);
                serializer.append_u32(g_223c);
                serializer.append_u32(g_2240);
                serializer.append_u32(g_2244);
                serializer.append_u32(g_2248);
                serializer.append_u32(g_224c);
                serializer.append_u32(g_2250);
                serializer.append_u32(g_2254);
                serializer.append_u32(g_2258);
                serializer.append_u32(g_225c);
                serializer.append_u32(g_2260);
                serializer.append_u32(g_2264);
                serializer.append_u32(g_2268);
                serializer.append_u32(g_226c);
                serializer.append_u32(g_2270);
                serializer.append_u32(g_2274);
                serializer.append_u32(0x0);
                serializer.flush(0x1);
                return;
            } else {
                if (g_2200 != 0x0) {
                    if (!(g_2208 & 0x1)) {
                        vm_func_01ffdb();
                        vm_func_020441();
                        g_2208 = 0x1;
                    }
                } else {
                    local_8 = 0xffffffff;
                    g_220c = (g_220c + 0x1);
                    serializer.set_mode(0x3);
                    serializer.append_u32(0x1350251);
                    serializer.append_u32((int64_t)(local_8));
                    serializer.append_u32((int64_t)(g_220c));
                    serializer.append_u32((int64_t)(g_2210));
                    serializer.append_u32(g_2214);
                    serializer.append_u32(g_2218);
                    serializer.append_u32(g_221c);
                    serializer.append_u32(g_2220);
                    serializer.append_u32(g_2224);
                    serializer.append_u32(g_2228);
                    serializer.append_u32(g_222c);
                    serializer.append_u32(g_2230);
                    serializer.append_u32(g_2234);
                    serializer.append_u32(g_2238);
                    serializer.append_u32(g_223c);
                    serializer.append_u32(g_2240);
                    serializer.append_u32(g_2244);
                    serializer.append_u32(g_2248);
                    serializer.append_u32(g_224c);
                    serializer.append_u32(g_2250);
                    serializer.append_u32(g_2254);
                    serializer.append_u32(g_2258);
                    serializer.append_u32(g_225c);
                    serializer.append_u32(g_2260);
                    serializer.append_u32(g_2264);
                    serializer.append_u32(g_2268);
                    serializer.append_u32(g_226c);
                    serializer.append_u32(g_2270);
                    serializer.append_u32(g_2274);
                    serializer.append_u32(0x0);
                    serializer.flush(0x1);
                    return;
                }
            }
        }
    }
    g_220c = (g_220c + 0x1);
    serializer.set_mode(0x3);
    serializer.append_u32(0x1350251);
    serializer.append_u32((int64_t)(local_8));
    serializer.append_u32((int64_t)(g_220c));
    serializer.append_u32((int64_t)(g_2210));
    serializer.append_u32(g_2214);
    serializer.append_u32(g_2218);
    serializer.append_u32(g_221c);
    serializer.append_u32(g_2220);
    serializer.append_u32(g_2224);
    serializer.append_u32(g_2228);
    serializer.append_u32(g_222c);
    serializer.append_u32(g_2230);
    serializer.append_u32(g_2234);
    serializer.append_u32(g_2238);
    serializer.append_u32(g_223c);
    serializer.append_u32(g_2240);
    serializer.append_u32(g_2244);
    serializer.append_u32(g_2248);
    serializer.append_u32(g_224c);
    serializer.append_u32(g_2250);
    serializer.append_u32(g_2254);
    serializer.append_u32(g_2258);
    serializer.append_u32(g_225c);
    serializer.append_u32(g_2260);
    serializer.append_u32(g_2264);
    serializer.append_u32(g_2268);
    serializer.append_u32(g_226c);
    serializer.append_u32(g_2270);
    serializer.append_u32(g_2274);
    serializer.append_u32(0x0);
    serializer.flush(0x1);
    return;
}
