void cleanup_vm_worker_6c94(void) {
    free(g_0470);
    g_0470 = 0x0;
    return;
}
