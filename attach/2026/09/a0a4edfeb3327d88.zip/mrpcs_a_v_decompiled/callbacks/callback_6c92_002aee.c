void vm_func_002aee(void) {
    g_01a4 = (g_01a4 + 0x1);
    if ((g_01a4 + 0x1) == 0x1) {
        vm_func_0022fa();
    }
    if (((int64_t)(g_01a4) % (int64_t)(0xa)) == 0x1) {
        serializer.set_mode(0x1);
        serializer.append_u32((int64_t)((((int64_t)(g_01a4) / (int64_t)(0xa)) + 0x1)));
        serializer.append_u32(g_0110);
        if (g_0118 == 0x0) {
            index_c = 0x0;
            while (((int32_t)(index_c)) <= 7) {
                serializer.append_u32(0xffffffff);
                index_c = (index_c + 0x1);
                continue;
            }
        } else {
            index_8 = 0x0;
            while (((int32_t)(index_8)) <= 7) {
                serializer.append_u32(*(uint32_t *)(g_0118 + ((int64_t)(index_8) << 0x2)));
                index_8 = (index_8 + 0x1);
                continue;
            }
        }
        serializer.flush(0x1);
    }
    return;
}
