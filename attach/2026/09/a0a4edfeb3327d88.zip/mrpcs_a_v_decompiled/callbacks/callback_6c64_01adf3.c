void vm_func_01adf3(void) {
    local_0 = *(uint64_t *)(g_16a8 + 0x54fc18);
    g_16b0 = *(uint32_t *)(*(uint64_t *)(g_16a8 + 0x54fc18) + 0x118);
    serializer.set_mode(0x3);
    serializer.append_u32(g_16b0);
    serializer.append_u32(0x0);
    serializer.append_u32(0x0);
    serializer.append_u32(0x0);
    serializer.append_u32(0x0);
    serializer.append_u32(0x0);
    serializer.append_u32(0x0);
    serializer.append_u32(0x0);
    serializer.append_u32(0x0);
    serializer.append_u32(0x0);
    serializer.flush(0x1);
    return;
}
