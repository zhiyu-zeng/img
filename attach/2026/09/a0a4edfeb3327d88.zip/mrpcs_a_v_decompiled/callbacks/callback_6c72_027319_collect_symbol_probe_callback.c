void collect_symbol_probe_callback(void) {
    slot_value_10 = vm_slot_get(0x0, 0x0);
    if (*(uint64_t *)(slot_value_10) == 0x0) {
        vm_slot_set(0x0, 0x0, 0x0);
        local_8 = 0x0;
    } else {
        if (*(uint64_t *)(slot_value_10 + 0x8) == 0x0) {
            vm_slot_set(0x0, 0x0, 0x0);
            local_8 = 0x0;
            return;
        } else {
            if (*(uint8_t *)(*(uint64_t *)(slot_value_10 + 0x8)) != 0x0) {
                index_18 = 0x0;
                while (((uint64_t)((int64_t)(index_18))) <= 0x63) {
                    if (*(uint64_t *)(((int64_t)(index_18) << 0x3) + &g_2498) != 0x0) {
                        if (call_native_n(g_2eb8, *(uint64_t *)(slot_value_10 + 0x8), *(uint64_t *)(((int64_t)(index_18) << 0x3) + &g_2498)) == 0x0) {
                            index_18 = (index_18 + 0x1);
                            continue;
                        } else {
                            collect_symbol_probe_records(slot_value_10);
                            break;
                        }
                    }
                }
                loc_027561:
                if (((int32_t)(symbol_probe_record_count)) < 3) {
                    vm_slot_set(0x0, 0x0, 0x0);
                } else {
                    vm_slot_set(0x0, 0x1, 0x0);
                }
                local_8 = 0x0;
            } else {
                vm_slot_set(0x0, 0x0, 0x0);
                local_8 = 0x0;
                return;
            }
        }
    }
    return;
}
