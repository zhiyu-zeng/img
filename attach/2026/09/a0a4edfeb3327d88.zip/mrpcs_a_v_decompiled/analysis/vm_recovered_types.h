#pragma once
#include <stdint.h>
#include <stddef.h>

/* Analyst-recovered layouts for the MVM/VMRPCS sample.
 * Names are descriptive, not original source symbols.
 */

typedef struct VmRBNode {
    struct VmRBNode *parent;        /* +0x00 */
    struct VmRBNode *left;          /* +0x08 */
    struct VmRBNode *right;         /* +0x10 */
    uint8_t          payload[0x10]; /* +0x18..+0x27 */
    uint32_t         color;         /* +0x28 */
} VmRBNode;

typedef struct VmProbeRecord38 {
    uint8_t raw[0x38];
} VmProbeRecord38;

/* 0x6C72/0x6C73 family: g_2EFC + index*0x20.
 * Writers store three 8-byte text tails followed by a 64-bit value split
 * into two 32-bit words.  The textual fields are truncated suffixes and are
 * not guaranteed to be NUL terminated when all 8 bytes are used.
 */
typedef union VmTextTail8 {
    char     text[8];
    uint32_t word[2];
} VmTextTail8;

typedef union VmTextTail12 {
    char     text[12];
    uint32_t word[3];
} VmTextTail12;

typedef union VmRaw8 {
    uint8_t  bytes[8];
    uint32_t word[2];
} VmRaw8;

typedef union VmRaw28 {
    uint8_t  bytes[0x1C];
    uint32_t word[7];
} VmRaw28;

typedef struct VmSymbolProbeRecord32 {
    VmTextTail8 name0_tail;   /* +0x00 */
    VmTextTail8 name1_tail;   /* +0x08 */
    VmTextTail8 name2_tail;   /* +0x10; may contain "anon" fallback */
    uint32_t value_hi;        /* +0x18 */
    uint32_t value_lo;        /* +0x1C */
} VmSymbolProbeRecord32;

/* 0x6C74/0x6C75 family: g_303C + index*0x18.
 * First 12 bytes form a short identifying suffix/key.  Remaining fields are
 * derived from a mapping/range and an associated 32-bit classifier/hash.
 * Exact business names remain intentionally conservative.
 */
typedef struct VmMapProbeRecord24 {
    VmTextTail12 key_tail;    /* +0x00 */
    uint32_t range_word;      /* +0x0C */
    uint32_t address_word;    /* +0x10 */
    uint32_t classifier;      /* +0x14 */
} VmMapProbeRecord24;

/* 0x031D38 stores up to six of these. */
typedef struct VmSuspiciousMapRecord {
    uint32_t span;            /* +0x00: end - start */
    uint32_t reason;          /* +0x04: observed 1 or 7 */
    uint32_t start_hi;        /* +0x08 */
    uint32_t start_lo;        /* +0x0C */
    uint32_t aux0;            /* +0x10 */
    uint32_t aux1;            /* +0x14 */
} VmSuspiciousMapRecord;

/* 0x6C97/0x6C98: ring buffer at g_38F4 with 16 entries and 0x40 stride.
 * The 0x1C-byte sub-block and final metric are produced by helper chains;
 * exact engine-specific semantics are still being recovered.
 */
typedef struct VmSampleRecord64 {
    uint32_t sequence;        /* +0x00 */
    VmRaw8   source8;         /* +0x04 */
    float    vector3[3];      /* +0x0C */
    VmRaw28  state28;         /* +0x18 */
    int32_t  status0;         /* +0x34 */
    int32_t  status1;         /* +0x38 */
    float    metric;          /* +0x3C; compared against 20.0f */
} VmSampleRecord64;

_Static_assert(sizeof(VmTextTail8) == 0x08, "VmTextTail8");
_Static_assert(sizeof(VmTextTail12) == 0x0C, "VmTextTail12");
_Static_assert(sizeof(VmRaw8) == 0x08, "VmRaw8");
_Static_assert(sizeof(VmRaw28) == 0x1C, "VmRaw28");
_Static_assert(sizeof(VmSymbolProbeRecord32) == 0x20, "VmSymbolProbeRecord32");
_Static_assert(sizeof(VmMapProbeRecord24) == 0x18, "VmMapProbeRecord24");
_Static_assert(sizeof(VmSuspiciousMapRecord) == 0x18, "VmSuspiciousMapRecord");
_Static_assert(sizeof(VmSampleRecord64) == 0x40, "VmSampleRecord64");

typedef long (*VmSyscallStub)(...);

typedef struct VmJniEnvHolder {
    void *jni_env;
} VmJniEnvHolder;

/* JNIEnv acquisition context recovered from 0x002F98 / 0x002DEA. */
typedef struct VmJniEnvContext {
    void    *java_vm;        /* +0x00 */
    void    *jni_env;        /* +0x08 */
    uint8_t  initialized;    /* +0x10 */
    uint8_t  did_attach;     /* +0x11 */
    uint8_t  _pad12[6];
    void    *env_holder;     /* +0x18, lazily allocated wrapper */
} VmJniEnvContext;

/* Internal byte-buffer builder used by the packet submission helpers. */
typedef struct VmPacketBuilder {
    uint8_t  *data;          /* +0x00 */
    uint16_t  flush_counter; /* +0x08 */
    uint8_t   _pad0a[2];
    uint16_t  flush_flags;   /* +0x0C, bit0=format A, bit1=format B */
    uint8_t   _pad0e[2];
    uint32_t  capacity;      /* +0x10 */
    uint32_t  length;        /* +0x14 */
} VmPacketBuilder;

/* Descriptor passed to the internal SUBMIT_PACKET host service by format-A path. */
typedef struct VmPacketSubmitDesc {
    uint64_t tag_or_header;  /* +0x00, observed 0x0000000A00000102 */
    void    *data;           /* +0x08 */
    uint32_t length;         /* +0x10 */
    uint32_t _reserved14;
} VmPacketSubmitDesc;

_Static_assert(sizeof(VmJniEnvContext) == 0x20, "VmJniEnvContext size");
_Static_assert(sizeof(VmPacketBuilder) == 0x18, "VmPacketBuilder size");
_Static_assert(sizeof(VmPacketSubmitDesc) == 0x18, "VmPacketSubmitDesc size");


/* Local aggregate recovered from sscanf("%llx-%llx %s ... %s").
 * Packed because the observed stack ABI places path at +0x15 exactly.
 */
typedef struct __attribute__((packed)) VmProcMapsLine {
    uint64_t start;           /* +0x00 */
    uint64_t end;             /* +0x08 */
    char     perms[5];        /* +0x10 */
    char     path[0x400];     /* +0x15 */
} VmProcMapsLine;

typedef struct VmU64Pair {
    uint64_t first;           /* +0x00 */
    uint64_t second;          /* +0x08 */
} VmU64Pair;

typedef struct VmInlineQwordVector8 {
    uint64_t *data;           /* +0x00, normally points at inline_values */
    uint64_t  size;           /* +0x08 */
    uint64_t  capacity;       /* +0x10, observed 8 */
    uint64_t  inline_values[8]; /* +0x18 */
} VmInlineQwordVector8;

_Static_assert(offsetof(VmProcMapsLine, path) == 0x15, "VmProcMapsLine path");
_Static_assert(sizeof(VmProcMapsLine) == 0x415, "VmProcMapsLine size");
_Static_assert(sizeof(VmU64Pair) == 0x10, "VmU64Pair size");
_Static_assert(sizeof(VmInlineQwordVector8) == 0x58, "VmInlineQwordVector8 size");

/* v1.8 local aggregates recovered from strong call/layout evidence. */
typedef struct VmProcMapsPathLine {
    uint64_t start;           /* +0x00 */
    uint64_t end;             /* +0x08 */
    char     path[0x400];     /* +0x10 */
} VmProcMapsPathLine;

typedef struct VmCpuSet1024 {
    uint64_t bits[16];        /* 1024 CPU bits / 0x80 bytes */
} VmCpuSet1024;

typedef struct VmU64Triple {
    uint64_t first;           /* +0x00 */
    uint64_t second;          /* +0x08 */
    uint64_t third;           /* +0x10 */
} VmU64Triple;

_Static_assert(sizeof(VmProcMapsPathLine) == 0x410, "VmProcMapsPathLine size");
_Static_assert(sizeof(VmCpuSet1024) == 0x80, "VmCpuSet1024 size");
_Static_assert(sizeof(VmU64Triple) == 0x18, "VmU64Triple size");
