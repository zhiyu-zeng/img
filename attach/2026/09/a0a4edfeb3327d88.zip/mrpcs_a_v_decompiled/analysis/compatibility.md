# MVM Backend Compatibility

- Backend: **mvm_v1 v1.11.0**
- Score: **99/100**
- Opcode XOR key: **0x00**

## Probe
- VMRPCS signature: match
- section ABI: type1/type2 present and in bounds
- opcode key candidates: 0x00(393)
- standard prologues: 393
- linear decode coverage inside function regions: 100.00% (210242/210242)
- compiler separator pattern: 87.24%
- opcode-key fingerprint: unambiguous
