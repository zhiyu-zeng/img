#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""扫描 fecs_inst.asm: 热立即数 / 12 字节步长指纹 / 指定子程序的调用点。"""
import re
import sys
import collections

def load(path):
    ins = []
    for l in open(path, encoding='utf-8', errors='replace'):
        m = re.match(r'^([0-9a-f]+): ([0-9a-f ]+?)\s{2,}(.+)$', l.rstrip('\n'))
        if m:
            ins.append((int(m.group(1), 16), m.group(3).strip()))
    return ins

ins = load(sys.argv[1] if len(sys.argv) > 1 else 'fecs_inst.asm')

hot = collections.Counter()
for a, t in ins:
    for m in re.finditer(r'mov \$r\d+ (0x[0-9a-f]+)', t):
        hot[m.group(1)] += 1
print('== 热立即数 Top 24 ==')
for k, v in hot.most_common(24):
    print(f'  {v:5d}  {k}')

print()
print('== 12 字节步长指纹(含 0xc 的操作数) ==')
n = 0
for a, t in ins:
    if re.search(r'\b0xc\b', t) or '*0xc' in t:
        print(f'  {a:#06x}: {t}')
        n += 1
        if n > 14:
            break

print()
targets = sys.argv[2:] or ['0x5850', '0x64ad']
for target in targets:
    print(f'== lcall {target} 的调用点 ==')
    for a, t in ins:
        if f'lcall {target}' in t:
            print(f'  {a:#06x}: {t}')
