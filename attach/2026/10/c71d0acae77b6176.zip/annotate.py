#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""annotate.py — 把 fecs_inst.asm 转成"逐条注释"的全量反汇编。
输出: fecs_annotated.html + fecs_annotated.txt
"""
import re, sys, html, collections

ASM = sys.argv[1] if len(sys.argv) > 1 else 'fecs_inst.asm'
OUTH = sys.argv[2] if len(sys.argv) > 2 else 'fecs_annotated.html'
OUTT = sys.argv[3] if len(sys.argv) > 3 else 'fecs_annotated.txt'

# ---------------- 符号表：已确认的函数名 ----------------
SYM = {
    0x0000: 'entry 入口',
    0x0010: 'io_write_guarded 带锁 I/O 写',
    0x0044: 'io_read_guarded 带锁 I/O 读',
    0x007a: 'io_ringread_guarded 带锁 I/O 队列读',
    0x0150: 'ext_read 外部空间读',
    0x01ac: 'ext_write 外部空间写',
    0x0237: 'ext_write2 外部写(变体 tag 0xe4)',
    0x028f: 'eng_reg_write 引擎寄存器写',
    0x0297: 'ext_read2 外部读(变体)',
    0x029f: 'ext_access3 外部访问(变体 0x1d400)',
    0x05c0: 'diag 诊断码上报(0x24/0x48/0x49=停机)',
    0x060b: 'ringA_push 环A生产者',
    0x0681: 'ringB_push 环B生产者',
    0x06f7: 'eng_err 引擎错误上报(bit3)',
    0x0a26: 'selftest? 自检/图案测试?(0x87654321)',
    0x0cc5: 'trace_pair (值,标签)→0x41a500/04',
    0x1021: 'state_store_helper1',
    0x1070: 'state_store_helper2',
    0x108e: 'state_store_helper3',
    0x10f8: 'state_store_helper4',
    0x1196: 'state_program 状态存储描述符编程器',
    0x16df: 'state_helper5',
    0x1c96: 'ringC_push 环C生产者',
    0x1d12: 'cmd_classify 命令分类器',
    0x1d81: 'irq_handler 中断处理器',
    0x1fc9: 'dispatcher 主分派器(环B消费者)',
    0x2ba3: 'init 底层初始化',
    0x4656: 'periodic_a 周期任务A(环C消费者)',
    0x5850: 'ctxsw_restore ctxsw后半(编程+校验)',
    0x64ad: 'ctxsw_save ctxsw前半(保存/准备)',
    0x7066: 'ringA_drain 环A排空(0x10000→门铃)',
    0x70e5: 'ctxsw_decision 上下文切换判定',
    0x7292: 'periodic_b 周期任务B(环A消费者)',
    0x7747: 'main 主循环',
    0x77ce: 'mul32 32位软件乘法',
    0x77e8: 'memset_byte 逐字节写',
}

# ---------------- I/O 端口表 ----------------
IOPORT = {
    0x100: '中断清除/ack', 0x200: '中断状态(bit2=主机消息,bit8+n=每引擎一位)',
    0x1900: '主机命令队列', 0x1a00: '主机参数队列', 0x1d00: '消息取走ack',
    0x10d00: '引擎位图回写', 0x20600: '诊断码端口', 0x30600: '诊断ack',
    0x30700: '诊断触发', 0x21200: '内部忙碌标志', 0x21800: '内部完成ack',
    0x1ac00: '通道选择', 0x20a00: '轨迹/签名端口(0xc0ffeeXX)',
    0x21400: '状态回写A', 0x21a00: '状态回写B', 0x21b00: '外部访问完成ack',
    0x21500: '外部访问控制', 0x1ca00: '外部访问命令/地址', 0x1cb00: '外部访问读数据',
    0x1cc00: '外部访问写数据', 0x2c000: '现役上下文描述符', 0x2c100: '请求的上下文描述符',
    0x2c300: '门铃', 0x2dc00: '请求清除/确认', 0x2de00: '引擎状态口(读)',
    0x20500: '引擎就绪状态0', 0x20800: '引擎就绪状态1', 0x22a00: '单元命令流',
    0x9400: '临界区忙标志', 0x1a400: '引擎错误寄存器0', 0x1a500: '引擎错误寄存器1',
    0x20c00: '错误镜像0', 0x20d00: '错误镜像1', 0x20e00: '错误镜像2', 0x20f00: '错误镜像3',
    0x20000: '状态/通知', 0x30000: '状态查询数组', 0x1d400: '外部队列',
    0x1c500: '外部读队列', 0x20a04: '轨迹数据', 0x20100: '事件置位',
    0x9200: '状态采样0', 0x9300: '状态采样1', 0x9000: '状态采样2',
    0x21300: 'XD控制(写0x200)', 0x28800: 'XD目标/模式选择', 0x4300: 'XD配置',
    0x4800: 'XD状态(读)', 0x1cb04: '外部访问状态',
}
# ---------------- DMEM 变量表 ----------------
DMEM = {
    0x2c: '临界区锁', 0x30: '模式标志(=D[0xe38]&0xff)', 0x24: '设备标识',
    0xc00: '配置块C(驱动patch)', 0xe00: '配置块E(驱动patch)', 0x1000: '配置块G(驱动patch)',
    0x12b8: 'ctxsw进行中标志', 0x12bc: 'ctxsw辅助标志', 0x12c0: '活动标志',
    0x12c4: '主循环退出标志', 0x12c8: '事件标志', 0x12d0: '主机命令原始值', 0x12d4: '命令号',
    0x12e0: '上下文地址打包0', 0x12e4: '上下文地址打包1', 0x12e8: '上下文地址打包2',
    0x12ec: '上下文地址打包3', 0x130c: '状态计数值', 0x1324: '忙标志',
    0x132c: '环A数组(16x8B)', 0x136c: '环A读指针', 0x1370: '环A写指针',
    0x1374: '环B数组(16x8B)', 0x13b4: '环B读指针', 0x13b8: '环B写指针',
    0x13c0: '引擎位图暂存', 0x13c4: '引擎状态就绪0', 0x13c8: '引擎状态就绪1',
    0x13cc: '统计0', 0x13d0: '统计1', 0x13d4: '统计2', 0x13d8: '统计3', 0x13dc: '统计4',
    0x13e0: '数组基址暂存', 0x13e8: '数组索引',
    0x13f0: 'ctxsw门控标志', 0x13f4: 'ctxsw计数',
    0x1444: '引擎号缓存', 0x1448: '上下文地址影子0', 0x144c: '上下文地址影子1(去重)',
    0x1450: '上下文地址影子2', 0x1454: '上下文地址影子3',
    0x145c: '地址计算缓存', 0x1464: '地址缓存', 0x1470: '尺寸计算缓存',
    0x1474: '尺寸源A', 0x1478: '尺寸源B', 0x147c: '表格式标志',
    0x1480: '尺寸源C', 0x1484: '轨迹参数', 0x1488: '幂等缓存:模式',
    0x148c: '幂等缓存:参数1', 0x1490: '幂等缓存:参数2', 0x1494: '几何缓存',
    0x14a0: '引擎数(循环上限)', 0x14a4: '状态存储尺寸A', 0x14ac: '状态存储尺寸B',
    0x14b0: '状态存储尺寸C', 0x14c8: '计数数组(状态表构建)', 0x14f8: '计数数组(遍历器)',
    0x1528: '12B状态表(每引擎3字)', 0x15b8: '环C数组(16x8B)',
    0x15f8: '环C读指针', 0x15fc: '环C写指针', 0x1604: '函数序言保存槽',
    0x1284: '校验影子0', 0x1288: '校验影子1', 0x12b4: '标志',
}

def num(v):
    """把地址/端口号转成名字注释"""
    if v in IOPORT: return '「%s」' % IOPORT[v]
    if v in DMEM:   return '「%s」' % DMEM[v]
    if v in SYM:    return '「%s」' % SYM[v]
    return ''

CC = {'e':'==','ne':'!=','a':'>','ae':'>=','b':'<','be':'<=',
      'c':'进位','nc':'无进位','o':'溢出','no':'无溢出','s':'负数','ns':'非负'}

# ---------------- 逐条指令注释 ----------------
def gloss(text):
    t = text.strip()
    # 去掉标志列（C=调用目标, B=分支目标）
    for p in ('C B ', 'CB ', 'C ', 'B '):
        if t.startswith(p):
            t = t[len(p):].strip()
            break
    parts = t.split(None, 1)
    op = parts[0]
    a = parts[1].strip() if len(parts) > 1 else ''

    # ---- 调用 ----
    m = re.match(r'l?call (0x[0-9a-f]+)', t)
    if m:
        v = int(m.group(1), 16)
        n = SYM.get(v, '')
        return '调用 %s%s' % (('子程序@' + m.group(1)), (' ' + n) if n else '')
    if t.startswith('lbra') or t.startswith('bra'):
        m = re.search(r'(0x[0-9a-f]+)$', t)
        tgt = m.group(1) if m else '?'
        if t.startswith('bra '):
            mm = re.match(r'bra (?:b32 )?\$r(\d+) (0x[0-9a-f]+|\d+) (\w+) (0x[0-9a-f]+)', t)
            if mm:
                r, v, cc, d = mm.groups()
                return '若 r%s %s %s 则跳到 %s' % (r, CC.get(cc, cc), v, d)
            mm = re.match(r'bra (\w+) (0x[0-9a-f]+)', t)
            if mm:
                cc, d = mm.groups()
                if cc == 'e': return '无条件跳到 %s' % d
                return '条件(%s)跳转 %s' % (CC.get(cc, cc), d)
        return '长跳转 %s' % tgt

    # ---- I/O ----
    m = re.match(r'iord \$r(\d+) I\[\$r(\d+)(?:\+\$r(\d+)\*0x4)?\]', t)
    if m:
        return 'I/O 读 → r%s（端口 = 基址+索引）' % m.group(1)
    m = re.match(r'iord \$r(\d+) I\[(0x[0-9a-f]+)(?:\+\$r(\d+)\*0x4)?\]', t)
    if m:
        v = int(m.group(2), 16)
        idx = (' + r%s*4' % m.group(3)) if m.group(3) else ''
        return 'r%s = I/O[%s%s] %s' % (m.group(1), m.group(2), idx, num(v))
    m = re.match(r'iowrs? I\[\$r(\d+)\] \$r(\d+)', t)
    if m:
        return 'I/O 写：I/O[r%s] ← r%s（r%s=端口）' % (m.group(1), m.group(2), m.group(1))
    m = re.match(r'iowrs? I\[(0x[0-9a-f]+)\] \$r(\d+)', t)
    if m:
        v = int(m.group(1), 16)
        return 'I/O 写：I/O[%s] ← r%s %s' % (m.group(1), m.group(2), num(v))
    m = re.match(r'iowrs? I\[\$r(\d+)\+\$r(\d+)\*0x4\] \$r(\d+)', t)
    if m:
        return 'I/O 写：I/O[r%s + r%s*4] ← r%s' % (m.group(1), m.group(2), m.group(3))

    # ---- 内存 ----
    m = re.match(r'ld (?:b\d+ )?\$r(\d+) D\[\$sp\+(0x[0-9a-f]+)\]', t)
    if m: return 'r%s = 栈帧[+%s]（读局部变量/入参）' % (m.group(1), m.group(2))
    m = re.match(r'st (?:b\d+ )?D\[\$sp\+(0x[0-9a-f]+)\] \$r(\d+)', t)
    if m: return '栈帧[+%s] ← r%s（写局部变量）' % (m.group(1), m.group(2))
    m = re.match(r'ld (?:b\d+ )?\$r(\d+) D\[\$r(\d+)\+\$r(\d+)\*0x4\]', t)
    if m: return 'r%s = DMEM[r%s + r%s*4]（数组索引读）' % (m.group(1), m.group(2), m.group(3))
    m = re.match(r'ld (b\d+|b16|b32) \$r(\d+) D\[\$r(\d+)(?:\+(0x[0-9a-f]+))?\]', t)
    if m:
        off = m.group(4)
        nm = ''
        if off and not m.group(3):
            nm = num(int(off, 16))
        return 'r%s = DMEM[r%s%s] %s' % (m.group(2), m.group(3), ('+'+off) if off else '', nm)
    m = re.match(r'ld (b\d+|b16|b32) \$r(\d+) D\[(0x[0-9a-f]+)(?:\+(0x[0-9a-f]+))?\]', t)
    if m:
        v = int(m.group(3), 16) + (int(m.group(4), 16) if m.group(4) else 0)
        return 'r%s = DMEM[%s] %s' % (m.group(2), hex(v) if m.group(4) else m.group(3), num(v))
    m = re.match(r'st (?:b\d+ )?D\[\$r(\d+)\+\$r(\d+)\*0x4\] \$r(\d+)', t)
    if m: return 'DMEM[r%s + r%s*4] ← r%s（数组索引写）' % (m.group(1), m.group(2), m.group(3))
    m = re.match(r'st (b\d+|b16|b32) D\[\$r(\d+)(?:\+(0x[0-9a-f]+))?\] \$r(\d+)', t)
    if m:
        return 'DMEM[r%s%s] ← r%s' % (m.group(2), ('+'+m.group(3)) if m.group(3) else '', m.group(4))
    m = re.match(r'st (b\d+|b16|b32) D\[(0x[0-9a-f]+)\] \$r(\d+)', t)
    if m:
        v = int(m.group(2), 16)
        return 'DMEM[%s] ← r%s %s' % (m.group(2), m.group(3), num(v))

    # ---- 特殊寄存器 ----
    m = re.match(r'mov \$xdbase \$r(\d+)', t)
    if m: return 'XD 传输基址寄存器 = r%s' % m.group(1)
    m = re.match(r'mov \$xtargets \$r(\d+)', t)
    if m: return 'XD 传输目标寄存器 = r%s' % m.group(1)
    m = re.match(r'mov \$sp \$r(\d+)', t)
    if m: return '栈指针 = r%s' % m.group(1)

    # ---- XD 数据搬移 ----
    m = re.match(r'xdld \$r(\d+) \$r(\d+)', t)
    if m: return 'XD 装载：从外部目标(xdbase,r%s)读入数据块 → r%s（配 xdwait）' % (m.group(2), m.group(1))
    m = re.match(r'xdst \$r(\d+) \$r(\d+)', t)
    if m: return 'XD 存储：把数据块 r%s 写出到外部目标(xdbase,r%s)（配 xdwait）' % (m.group(1), m.group(2))
    if t.startswith('xdwait'): return '等待 XD 传输完成'

    # ---- 数据传送 ----
    m = re.match(r'mov (?:b32 )?\$r(\d+) (0x[0-9a-f]+)', t)
    if m:
        return 'r%s = %s %s' % (m.group(1), m.group(2), num(int(m.group(2), 16)))
    m = re.match(r'mov (?:b32 )?\$r(\d+) \$r(\d+)', t)
    if m:
        return 'r%s ← r%s' % (m.group(1), m.group(2))
    m = re.match(r'mov \$r(\d+) (\d+)$', t)
    if m:
        return 'r%s = %s' % (m.group(1), m.group(2))

    # ---- 运算 ----
    m = re.match(r'and (?:b32 )?\$r(\d+) \$r(\d+) (0x[0-9a-f]+)$', t)
    if m: return 'r%s = r%s & %s' % (m.group(1), m.group(2), m.group(3))
    m = re.match(r'and (?:b32 )?\$r(\d+) (0x[0-9a-f]+)$', t)
    if m: return 'r%s &= %s（掩码）' % (m.group(1), m.group(2))
    m = re.match(r'and (?:b32 )?\$r(\d+) \$r(\d+)', t)
    if m: return 'r%s &= r%s' % (m.group(1), m.group(2))
    m = re.match(r'or \$r(\d+) \$r(\d+) \$r(\d+)', t)
    if m: return 'r%s = r%s | r%s' % (m.group(1), m.group(2), m.group(3))
    m = re.match(r'or \$r(\d+) (0x[0-9a-f]+)$', t)
    if m: return 'r%s |= %s' % (m.group(1), m.group(2))
    m = re.match(r'or \$r(\d+) \$r(\d+)', t)
    if m: return 'r%s |= r%s' % (m.group(1), m.group(2))
    m = re.match(r'xor \$r(\d+) \$r(\d+)', t)
    if m: return 'r%s ^= r%s' % (m.group(1), m.group(2))
    m = re.match(r'xor \$r(\d+) (0x[0-9a-f]+)$', t)
    if m: return 'r%s ^= %s（翻转低位）' % (m.group(1), m.group(2))
    m = re.match(r'not (?:b32 )?\$r(\d+) \$r(\d+)', t)
    if m: return 'r%s = ~r%s（按位取反）' % (m.group(1), m.group(2))
    m = re.match(r'neg (?:b32 )?\$r(\d+) \$r(\d+)', t)
    if m: return 'r%s = -r%s' % (m.group(1), m.group(2))
    m = re.match(r'mod \$r(\d+) \$r(\d+) \$r(\d+)', t)
    if m: return 'r%s = r%s %% r%s（取模）' % (m.group(1), m.group(2), m.group(3))
    m = re.match(r'add (?:b8 |b16 |b32 )?\$r(\d+) \$r(\d+) (0x[0-9a-f]+)', t)
    if m: return 'r%s = r%s + %s' % (m.group(1), m.group(2), m.group(3))
    m = re.match(r'add (?:b8 |b16 |b32 )?\$r(\d+) \$r(\d+) \$r(\d+)', t)
    if m: return 'r%s = r%s + r%s' % (m.group(1), m.group(2), m.group(3))
    m = re.match(r'add (?:b8 |b16 |b32 )?\$r(\d+) \$r(\d+) (0x[0-9a-f]+)$', t)
    if m: return 'r%s = r%s + %s' % (m.group(1), m.group(2), m.group(3))
    m = re.match(r'sub \$sp (0x[0-9a-f]+)', t)
    if m: return '栈指针 -= %s（开辟栈帧）' % m.group(1)
    m = re.match(r'sub (?:b32 )?\$r(\d+) \$r(\d+) (0x[0-9a-f]+)', t)
    if m: return 'r%s = r%s - %s' % (m.group(1), m.group(2), m.group(3))
    m = re.match(r'cmp (?:b32 )?\$r(\d+) (0x[0-9a-f]+|\d+)', t)
    if m: return '比较 r%s 与 %s（设标志）' % (m.group(1), m.group(2))
    m = re.match(r'cmp (?:b32 )?\$r(\d+) \$r(\d+)', t)
    if m: return '比较 r%s 与 r%s（设标志）' % (m.group(1), m.group(2))
    m = re.match(r'shl (?:b32 )?\$r(\d+) \$r(\d+) (0x[0-9a-f]+|\d+)$', t)
    if m: return 'r%s = r%s << %s' % (m.group(1), m.group(2), m.group(3))
    m = re.match(r'shl (?:b32 )?\$r(\d+) (0x[0-9a-f]+|\d+)$', t)
    if m: return 'r%s <<= %s' % (m.group(1), m.group(2))
    m = re.match(r'shr (?:b32 )?\$r(\d+) \$r(\d+) (0x[0-9a-f]+|\d+)$', t)
    if m: return 'r%s = r%s >> %s（逻辑右移）' % (m.group(1), m.group(2), m.group(3))
    m = re.match(r'shr (?:b32 )?\$r(\d+) (0x[0-9a-f]+|\d+)$', t)
    if m: return 'r%s >>= %s（逻辑右移）' % (m.group(1), m.group(2))
    m = re.match(r'sar (?:b\d+ )?\$r(\d+) (0x[0-9a-f]+|\d+)$', t)
    if m: return 'r%s 算术右移 %s（保符号）' % (m.group(1), m.group(2))

    # ---- 位操作 ----
    m = re.match(r'extr \$r(\d+) \$r(\d+) (0x[0-9a-f]+:0x[0-9a-f]+)', t)
    if m: return 'r%s = 提取 r%s 的位域 [%s]（高:低）' % (m.group(1), m.group(2), m.group(3))
    m = re.match(r'xbit \$r(\d+) \$flags (\w+)', t)
    if m: return 'r%s = 条件码 %s（0/1 提取）' % (m.group(1), m.group(2))
    m = re.match(r'sethi \$r(\d+) (0x[0-9a-f]+)', t)
    if m: return 'r%s 高 16 位 = %s（低 16 位保留）' % (m.group(1), m.group(2))
    m = re.match(r'muls \$r(\d+) \$r(\d+) \$r(\d+)', t)
    if m: return 'r%s = r%s * r%s（有符号 16x16→32）' % (m.group(1), m.group(2), m.group(3))
    m = re.match(r'muls \$r(\d+) \$r(\d+)', t)
    if m: return 'r%s *= r%s（有符号）' % (m.group(1), m.group(2))
    m = re.match(r'mulu \$r(\d+) \$r(\d+) \$r(\d+)', t)
    if m: return 'r%s = r%s * r%s（无符号 16x16→32）' % (m.group(1), m.group(2), m.group(3))
    m = re.match(r'clear (?:b32 )?\$r(\d+)', t)
    if m: return 'r%s = 0' % m.group(1)
    m = re.match(r'bset \$flags (\w+)', t)
    if m: return '置标志位 %s = 1' % m.group(1)
    m = re.match(r'bclr \$flags (\w+)', t)
    if m: return '清标志位 %s = 0' % m.group(1)
    m = re.match(r'btgl \$flags (\w+)', t)
    if m: return '翻转标志位 %s' % m.group(1)

    # ---- 栈/控制 ----
    if t == 'ret': return '子程序返回'
    if t == 'iret': return '中断返回'
    if t.startswith('exit'): return '停机（停止取指）'
    if t == 'sleep': return '休眠，等中断唤醒'
    if re.match(r'sleep \$p\d', t): return '条件休眠（%s）' % t.split()[1]
    m = re.match(r'mpush \$r(\d+)', t)
    if m: return '压栈 r0..r%s（多寄存器保存）' % m.group(1)
    m = re.match(r'mpopret \$r(\d+)', t)
    if m: return '弹栈 r0..r%s 并返回' % m.group(1)
    m = re.match(r'mpopaddret \$r(\d+) (0x[0-9a-f]+)', t)
    if m: return '弹栈 r0..r%s、栈指针 += %s 并返回' % (m.group(1), m.group(2))
    m = re.match(r'push(b32)? \$r(\d+)', t)
    if m: return '压栈 r%s' % m.group(2)
    m = re.match(r'pop \$r(\d+)', t)
    if m: return '弹栈 → r%s' % m.group(1)

    return ''

# ---------------- 解析 ----------------
ins = []   # (addr, bytes, flags, text)
for l in open(ASM, encoding='utf-8', errors='replace'):
    m = re.match(r'^([0-9a-f]+): ([0-9a-f ]+?)\s{2,}(.+)$', l.rstrip('\n'))
    if m:
        ins.append((int(m.group(1), 16), m.group(2).strip(), m.group(3).strip()))

# 函数切分：C 标志 = 调用目标；0x0 也是入口
funcs = []   # (start, name, [ins...])
cur = None
for addr, byt, text in ins:
    isC = text.startswith('C ')
    if isC or addr == 0:
        if cur: funcs.append(cur)
        cur = [addr, SYM.get(addr, ''), []]
    if cur is None:
        cur = [addr, '', []]
    cur[2].append((addr, byt, text, gloss(text)))
if cur: funcs.append(cur)

total = sum(len(f[2]) for f in funcs)
ngloss = sum(1 for f in funcs for i in f[2] if i[3])
print('instructions: %d, functions: %d, glossed: %d (%.1f%%)' %
      (total, len(funcs), ngloss, 100.0*ngloss/max(total,1)))

# ---------------- TXT 输出 ----------------
with open(OUTT, 'w', encoding='utf-8') as fo:
    fo.write('FECS 固件全量反汇编（逐条注释）\n')
    fo.write('共 %d 条指令 / %d 个函数\n' % (total, len(funcs)))
    fo.write('=' * 100 + '\n')
    for start, name, body in funcs:
        fo.write('\n; ======== sub_%04x  %s  (%d 条) ========\n' % (start, name, len(body)))
        for addr, byt, text, g in body:
            fo.write('%05x: %-44s ; %s\n' % (addr, text, g))
print('wrote', OUTT)

# ---------------- HTML 输出 ----------------
def esc(s): return html.escape(s)
with open(OUTH, 'w', encoding='utf-8') as fo:
    fo.write('''<!doctype html><html lang="zh"><head><meta charset="utf-8">
<title>FECS 固件全量反汇编（逐条注释）</title>
<style>
:root{--bg:#0f1115;--fg:#d8dee9;--dim:#7a8290;--accent:#7aa2f7;--io:#e0af68;--mem:#9ece6a;--ctl:#bb9af7;--call:#f7768e;--fnbg:#1a1f2b;}
@media (prefers-color-scheme: light){:root{--bg:#faf9f7;--fg:#2b2b2b;--dim:#8a8a8a;--accent:#1a4fa0;--io:#a05a00;--mem:#2e7d32;--ctl:#6a1b9a;--call:#c2185b;--fnbg:#eef1f6;}}
body{background:var(--bg);color:var(--fg);font:13px/1.5 ui-monospace,Consolas,monospace;margin:0;padding:16px 20px}
h1{font-size:18px;font-family:system-ui,sans-serif}
.meta{color:var(--dim);font-family:system-ui,sans-serif;font-size:12px;margin-bottom:14px}
details{background:var(--fnbg);border-radius:6px;margin:6px 0;padding:2px 8px}
summary{cursor:pointer;padding:4px 2px;color:var(--accent);font-family:system-ui,sans-serif;font-size:13px}
pre{margin:4px 0 8px;white-space:pre-wrap;word-break:break-all}
.a{color:var(--dim)}
.g{color:var(--dim);font-style:normal}
.io{color:var(--io)} .mem{color:var(--mem)} .ctl{color:var(--ctl)} .call{color:var(--call)}
</style></head><body>
<h1>FECS (AD102 NETA) 固件全量反汇编 · 逐条注释</h1>
<div class="meta">共 %d 条指令 / %d 个函数（其中 %d 条给出语义注释）。生成自 fecs_inst.asm（envydis fuc6，0 未知指令）。</div>
''' % (total, len(funcs), ngloss))
    for start, name, body in funcs:
        fo.write('<details><summary>sub_%04x &nbsp;%s &nbsp;<span class="a">(%d 条)</span></summary><pre>' %
                 (start, esc(name), len(body)))
        for addr, byt, text, g in body:
            cls = ''
            if 'iowr' in text or 'iord' in text: cls = 'io'
            elif text.startswith(('ld ', 'st ')): cls = 'mem'
            elif text.startswith(('bra', 'lbra', 'ret', 'exit', 'sleep', 'iret')): cls = 'ctl'
            elif 'call' in text.split()[0]: cls = 'call'
            fo.write('<span class="a">%05x</span> <span class="%s">%s</span>' % (addr, cls, esc(text)))
            if g:
                fo.write('  <span class="g">; %s</span>' % esc(g))
            fo.write('\n')
        fo.write('</pre></details>\n')
    fo.write('</body></html>')
print('wrote', OUTH)
