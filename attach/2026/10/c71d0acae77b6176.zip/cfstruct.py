#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
cfstruct.py — Falcon 反汇编 → 结构化 C(编译器级控制流恢复)。

相对 asm2c.py(平铺 switch/pc)的升级:
  1. 子程序提取: lcall 目标 → C 函数; ret/mpopret → return;
     **栈语义保持**: 调用点用 CALL() 宏(dummy push/pop 占住返回地址槽),
     否则被调函数的 D[$sp+K] 访问会整体错位 4 字节;
  2. 区间折叠: 前向条件分支且落空集干净(仅由该分支支配) → if(!cond){...};
     天然覆盖 if-then 与 if-then-else(两臂均被折叠时 else 自然形成);
  3. 循环/不干净结构 → 标签 + goto(保真优先, 交给后续 pass 优化)。

用法: python cfstruct.py fecs_inst.asm fecs_structured.c
"""
import re
import sys

LINE = re.compile(r'^([0-9a-f]+): ([0-9a-f ]+?)\s{2,}(.+)$')
REG_MACROS = '\n'.join(f'#define r{i} r[{i}]' for i in range(16))

def parse(path):
    ins = []
    for l in open(path, encoding='utf-8', errors='replace'):
        m = LINE.match(l.rstrip('\n'))
        if not m:
            continue
        ins.append((int(m.group(1), 16), m.group(2).split(), m.group(3).strip()))
    return ins

def main():
    src, dst = sys.argv[1], sys.argv[2]
    ins = parse(src)
    n = len(ins)
    addr_idx = {a: i for i, (a, _, _) in enumerate(ins)}
    next_of = {a: (ins[i + 1][0] if i + 1 < n else None) for i, (a, _, _) in enumerate(ins)}

    def tok_of(t):
        tok = t.split()
        while tok and re.fullmatch(r'[CB]{1,2}', tok[0]) and len(tok) > 1:
            tok = tok[1:]
        return tok

    # ---- 指令分类 ----
    def kind(a, t):
        tok = tok_of(t)
        mn = tok[0]
        clean = ' '.join(tok)
        if mn == 'lcall':
            m = re.search(r'0x([0-9a-f]+)\s*$', clean)
            return ('call', int(m.group(1), 16) if m else None)
        if mn in ('ret', 'iret', 'mpopret', 'mpopaddret'):
            return ('ret', None)
        if mn == 'exit':
            return ('exit', None)
        if mn == 'lbra':
            m = re.search(r'0x([0-9a-f]+)\s*$', clean)
            return ('jmp', int(m.group(1), 16) if m else None)
        if mn == 'bra':
            m = re.search(r'0x([0-9a-f]+)\s*$', clean)
            return ('cbr', int(m.group(1), 16) if m else None)
        return ('insn', None)

    kinds = {a: kind(a, t) for a, _, t in ins}

    # ---- 基本块: 划分 ----
    leaders = {ins[0][0]}
    for a, _, t in ins:
        k, tgt = kinds[a]
        if k in ('call', 'cbr', 'jmp') and tgt is not None:
            leaders.add(tgt)
        if k in ('cbr', 'jmp', 'ret', 'exit'):
            nx = next_of[a]
            if nx is not None:
                leaders.add(nx)
    leaders = sorted(x for x in leaders if x in addr_idx)

    blocks = []
    for i, a in enumerate(leaders):
        end = leaders[i + 1] if i + 1 < len(leaders) else None
        body = []
        j = addr_idx[a]
        while True:
            body.append(ins[j][0])
            k, tgt = kinds[ins[j][0]]
            if k in ('cbr', 'jmp', 'ret', 'exit'):
                break
            if j + 1 >= n:
                break
            if end is not None and ins[j + 1][0] >= end:
                break
            j += 1
        blocks.append({'start': a, 'addrs': body})

    blk_at = {b['start']: b for b in blocks}
    for b in blocks:
        last = b['addrs'][-1]
        k, tgt = kinds[last]
        succs = []
        if k == 'cbr':
            succs = [tgt, next_of[last]]
        elif k == 'jmp':
            succs = [tgt]
        elif k in ('ret', 'exit'):
            succs = []
        else:
            succs = [next_of[last]]
        b['succ'] = [s for s in succs if s in blk_at]

    # ---- 函数: lcall 目标 + 入口 ----
    func_entries = sorted({ins[0][0]} | {t for a, (k, t) in kinds.items() if k == 'call' and t in blk_at})
    entry_set = set(func_entries)
    owner = {}
    for e in func_entries:
        stack, seen = [e], set()
        while stack:
            b = stack.pop()
            if b in seen or b not in blk_at:
                continue
            seen.add(b)
            blk_at[b]['func'] = e
            for s in blk_at[b]['succ']:
                if s not in entry_set or s == e:
                    stack.append(s)
        owner[e] = seen
    assigned = {b for s in owner.values() for b in s}
    dead = [b['start'] for b in blocks if b['start'] not in assigned]

    # ---- 支配集(每函数内部) ----
    dom = {}
    for e, bset in owner.items():
        preds = {b: [] for b in bset}
        for b in bset:
            for s in blk_at[b]['succ']:
                if s in bset:
                    preds[s].append(b)
        d = {b: set(bset) for b in bset}
        d[e] = {e}
        changed = True
        while changed:
            changed = False
            for b in bset:
                if b == e:
                    continue
                new = {b} | set.intersection(*(d[p] for p in preds[b])) if preds[b] else {b}
                if new != d[b]:
                    d[b] = new
                    changed = True
        dom.update(d)

    # ---- 可达性(函数内) ----
    reach = {}
    for e, bset in owner.items():
        seen, stack = set(), [e]
        while stack:
            b = stack.pop()
            if b in seen:
                continue
            seen.add(b)
            for s in blk_at[b]['succ']:
                if s in bset and s not in seen:
                    stack.append(s)
        reach[e] = seen

    # ---- 发射 ----
    out = []
    out.append('/* fecs_structured.c — 由 cfstruct.py 从 fecs_inst.asm 结构化转译。')
    out.append(' * 结构: lcall 目标提为 C 函数; 干净前向区间折叠为 if/else; 循环回边保留 goto。')
    out.append(' * 栈语义: CALL() 宏在 C 调用前后 dummy push/pop, 保持 Falcon 的 SP 布局。')
    out.append(' * 语义未经运行验证; 与 fecs_inst.c(平铺保真版) 互为对照。')
    out.append(' */')
    out.append('#include <stdint.h>\n#include <stdio.h>\n#include <stdlib.h>')
    out.append('typedef uint8_t u8; typedef uint16_t u16; typedef uint32_t u32; typedef uint64_t u64;')
    out.append('static u32 r[16]; static u32 sp; static u8 p[8]; static u32 falcon_flags;')
    out.append(REG_MACROS)
    out.append('static u8 dmem[65536];')
    out.append('static u32 sr_flags_ie;')
    specials = set()
    for a, _, t in ins:
        for x in re.findall(r'\$[A-Za-z_]\w*', t):
            if x in ('$sp', '$flags') or re.fullmatch(r'\$(r|p)\d+', x):
                continue
            specials.add(x[1:])
    for s in sorted(specials):
        out.append(f'static u32 sr_{s};')
    out.append('static u32 d32(u32 a){ u32 v; __builtin_memcpy(&v,&dmem[a&0xffff],4); return v; }')
    out.append('static void s32(u32 a, u32 v){ __builtin_memcpy(&dmem[a&0xffff],&v,4); }')
    out.append('static u8 d8(u32 a){ return dmem[a&0xffff]; }')
    out.append('static void s8(u32 a, u8 v){ dmem[a&0xffff]=v; }')
    out.append('static u16 d16(u32 a){ u16 v; __builtin_memcpy(&v,&dmem[a&0xffff],2); return v; }')
    out.append('static void s16(u32 a, u16 v){ __builtin_memcpy(&dmem[a&0xffff],&v,2); }')
    out.append('static u32 xdld(u32 a){ (void)a; return 0; }  /* TODO: X 空间读 */')
    out.append('static void xdst(u32 a, u32 v){ (void)a; (void)v; }  /* TODO: X 空间写 */')
    out.append('static void push32(u32 v){ sp -= 4; s32(sp, v); }')
    out.append('static u32 pop32(void){ u32 v = d32(sp); sp += 4; return v; }')
    out.append('static u32 iord(u32 port){ (void)port; return 0; }  /* TODO: I/O 读 */')
    out.append('static void iowr(u32 port, u32 v){ (void)port; (void)v; }  /* TODO: I/O 写 */')
    out.append('#define iowrs iowr')
    out.append('#define INT_ENABLE(n) do{ sr_flags_ie |= (1u << (n)); }while(0)')
    out.append('#define XDWAIT()   do{ }while(0)\n#define XWAIT()    do{ }while(0)\n#define DMWAIT()   do{ }while(0)')
    out.append('#define SETFZ(v) (falcon_flags = (falcon_flags & ~1u) | (((v)==0)?1u:0u))')
    out.append('#define FZ(f) ((f)&1u)\n#define FC(f) (((f)>>1)&1u)')
    out.append('static void fc_cmp(u32 a, u32 b){ falcon_flags &= ~3u; SETFZ(a-b); if(a<b) falcon_flags |= 2u; }')
    out.append('static void fc_xbit(u32 v){ falcon_flags &= ~1u; SETFZ(v); }')
    out.append('static void intr_sleep(u8 *f){ while(!*f){ } *f = 0; }')
    out.append('static u32 falcon_muls(u32 a, u32 b){ return (u32)(((int64_t)(int32_t)a*(int32_t)b)>>32); }')
    out.append('static u32 falcon_mulu(u32 a, u32 b){ return (u32)(((u64)a*b)>>32); }')
    out.append('#define UNKNOWN(msg) do{ fprintf(stderr, "UNKNOWN: %s\\n", msg); abort(); }while(0)')
    out.append('#define CALL(fn) do{ push32(0u); (fn)(); pop32(); }while(0)  /* 保持 Falcon 栈布局 */')
    out.append('')
    for e in func_entries:
        out.append(f'static void sub_{e:x}(void);')
    out.append('')

    call_cnt = {}
    for a, _, t in ins:
        k, tgt = kinds[a]
        if k == 'call' and tgt is not None:
            call_cnt[tgt] = call_cnt.get(tgt, 0) + 1

    emitted, need_label = set(), set()
    cur_func = [None]
    for b in blocks:
        last = b['addrs'][-1]
        k, tgt = kinds[last]
        if k in ('cbr', 'jmp') and tgt is not None:
            need_label.add(tgt)

    def val(x):
        if re.fullmatch(r'\$r\d+', x):
            return 'r' + x[2:]
        if x == '$sp':
            return 'sp'
        if x == '$flags':
            return 'falcon_flags'
        if re.fullmatch(r'0x[0-9a-f]+|-0x[0-9a-f]+', x):
            return x + 'u'
        if x.startswith('$'):
            return 'sr_' + x[1:]
        return None

    def cond_text(t):
        tok = tok_of(t)
        clean = ' '.join(tok)
        m = re.fullmatch(r'bra\s+b(?:8|16|32)\s+(\$r\d+)\s+(\$r\d+|0x[0-9a-f]+)\s+(e|ne|a|b|g|l|ae|be|ge|le)\s+0x[0-9a-f]+', clean)
        if m:
            cc = {'e': '==', 'ne': '!=', 'a': '>', 'g': '>', 'b': '<', 'l': '<',
                  'ae': '>=', 'ge': '>=', 'be': '<=', 'le': '<='}[m.group(3)]
            return f'({val(m.group(1))} {cc} {val(m.group(2))})'
        conds = {
            'e': 'FZ(falcon_flags)', 'ne': '!FZ(falcon_flags)',
            'a': '(!FC(falcon_flags) && !FZ(falcon_flags))', 'b': 'FC(falcon_flags)',
            'ae': '!FC(falcon_flags)', 'be': '(FC(falcon_flags) || FZ(falcon_flags))',
            'g': '(!FC(falcon_flags) && !FZ(falcon_flags))', 'l': 'FC(falcon_flags)',
            'ge': '!FC(falcon_flags)', 'le': '(FC(falcon_flags) || FZ(falcon_flags))',
        }
        m = re.fullmatch(r'bra\s+(e|ne|a|b|g|l|ae|be|ge|le)\s+0x[0-9a-f]+', clean)
        if m:
            return conds[m.group(1)]
        return None

    def emit_stmt(t, indent):
        tok = tok_of(t)
        mn, ops = tok[0], tok[1:]
        pre = '    ' * indent
        o = [x for x in ops if not re.fullmatch(r'b(8|16|32)', x)]

        def dexpr(x):
            for pat, fmt in ((r'D\[\$r(\d+)\]', 'd32(r{0})'), (r'D\[\$r(\d+)\+0x([0-9a-f]+)\]', 'd32(r{0}+0x{1})'),
                             (r'D\[\$sp\+0x([0-9a-f]+)\]', 'd32(sp+0x{0})'),
                             (r'D\[\$r(\d+)\+\$r(\d+)\*0x(\d+)\]', 'd32(r{0}+r{1}*0x{2})'),
                             (r'D\[\$r(\d+)\+\$r(\d+)\]', 'd32(r{0}+r{1})')):
                m = re.fullmatch(pat, x)
                if m:
                    return fmt.format(*m.groups())
            return 'd32(sp)' if x == 'D[$sp]' else None

        def iexpr(x):
            for pat, fmt in ((r'I\[\$r(\d+)\]', 'r{0}'), (r'I\[\$r(\d+)\+0x([0-9a-f]+)\]', 'r{0}+0x{1}'),
                             (r'I\[\$r(\d+)\+\$r(\d+)\*0x(\d+)\]', 'r{0}+r{1}*0x{2}'),
                             (r'I\[\$r(\d+)\+\$r(\d+)\]', 'r{0}+r{1}')):
                m = re.fullmatch(pat, x)
                if m:
                    return fmt.format(*m.groups())
            return None

        if o and mn == 'mov' and len(o) == 2 and val(o[0]) and val(o[1]):
            return f'{pre}{val(o[0])} = {val(o[1])};'
        if o and mn == 'clear' and len(o) == 1 and val(o[0]):
            return f'{pre}{val(o[0])} = 0;'
        if o and mn in ('add', 'sub', 'and', 'or', 'xor', 'mod'):
            op = {'add': '+', 'sub': '-', 'and': '&', 'or': '|', 'xor': '^', 'mod': '%'}[mn]
            if len(o) == 3 and val(o[0]) and val(o[1]) and val(o[2]):
                return f'{pre}{val(o[0])} = {val(o[1])} {op} {val(o[2])};'
            if len(o) == 2 and val(o[0]) and val(o[1]):
                return f'{pre}{val(o[0])} {op}= {val(o[1])};'
        if o and mn in ('shl', 'shr', 'sar'):
            op = {'shl': '<<', 'shr': '>>', 'sar': '>>'}[mn]
            if len(o) == 3 and val(o[0]) and val(o[1]):
                return f'{pre}{val(o[0])} = {val(o[1])} {op} {val(o[2]) or (o[2] + "u")};'
            if len(o) == 2 and val(o[0]):
                return f'{pre}{val(o[0])} {op}= {val(o[1]) or (o[1] + "u")};'
        if o and mn == 'not' and ((len(o) == 2 and val(o[0]) and val(o[1]))):
            return f'{pre}{val(o[0])} = ~{val(o[1])};'
        if o and mn == 'neg' and (len(o) == 2 and val(o[0]) and val(o[1])):
            return f'{pre}{val(o[0])} = (u32)(-(int32_t){val(o[1])});'
        if o and mn == 'sethi' and len(o) == 2 and val(o[0]):
            return f'{pre}{val(o[0])} = ({val(o[0])} & 0xffffu) | ((u32){o[1]}u << 16); /* 待复核 */'
        if o and mn == 'cmp' and len(o) == 2 and val(o[0]) and val(o[1]):
            return f'{pre}fc_cmp({val(o[0])}, {val(o[1])});'
        if o and mn == 'ld' and len(ops) == 3:
            de = dexpr(ops[2])
            if de and val(ops[1]):
                return f'{pre}{val(ops[1])} = {de};'
        if o and mn == 'st' and len(ops) == 3:
            de = dexpr(ops[1])
            if de and val(ops[2]):
                fn = de.split('(')[0].replace('d', 's', 1)
                return f'{pre}{fn}({de[de.index("(")+1:-1]}, {val(ops[2])});'
        if o and mn in ('iowr', 'iowrs') and len(ops) == 2:
            ie = iexpr(ops[0])
            if ie and val(ops[1]):
                return f'{pre}{mn}({ie}, {val(ops[1])});'
        if o and mn == 'iord' and len(ops) == 2:
            ie = iexpr(ops[1])
            if ie and val(ops[0]):
                return f'{pre}{val(ops[0])} = iord({ie});'
        if o and mn == 'extr' and len(ops) == 3:
            m = re.fullmatch(r'0x([0-9a-f]+):0x([0-9a-f]+)', ops[2])
            if m and val(ops[0]) and val(ops[1]):
                lo, hi = int(m.group(1), 16), int(m.group(2), 16)
                return f'{pre}{val(ops[0])} = ({val(ops[1])} >> {lo}) & 0x{(1 << (hi-lo+1))-1:x}u;'
        if o and mn in ('muls', 'mulu') and len(o) >= 2 and val(o[0]) and val(o[1]):
            src2 = val(o[2]) if len(o) == 3 else val(o[0])
            return f'{pre}{val(o[0])} = falcon_{mn}({val(o[1])}, {src2});'
        if o and mn == 'bset' and len(ops) == 2 and ops[0] == '$flags' and re.fullmatch(r'ie\d+', ops[1]):
            return f'{pre}INT_ENABLE({ops[1][2:]});'
        if o and mn in ('bset', 'bclr', 'btgl'):
            if len(ops) == 2 and ops[0] == '$flags' and re.fullmatch(r'\$p\d+', ops[1]):
                return f'{pre}p[{ops[1][2:]}] = {1 if mn=="bset" else 0};'
            if len(ops) == 2 and re.fullmatch(r'\$r\d+', ops[0]) and re.fullmatch(r'0x[0-9a-f]+', ops[1]):
                op = {'bset': '|=', 'bclr': '&= ~', 'btgl': '^='}[mn]
                return f'{pre}{val(ops[0])} {op} (1u << {ops[1]});'
            if len(ops) == 3 and val(ops[0]) and val(ops[1]) and val(ops[2]):
                op = {'bset': '|', 'bclr': '& ~', 'btgl': '^'}[mn]
                return f'{pre}{val(ops[0])} = {val(ops[1])} {op} {val(ops[2])};'
        if o and mn in ('xdld', 'xdst') and len(ops) == 2 and val(ops[0]) and val(ops[1]):
            return (f'{pre}{val(ops[0])} = xdld({val(ops[1])});' if mn == 'xdld'
                    else f'{pre}xdst({val(ops[0])}, {val(ops[1])});')
        if o and mn == 'xbit' and ops and val(ops[0]):
            return f'{pre}fc_xbit({val(ops[0])});'
        if o and mn in ('xdwait', 'xwait', 'dmwait'):
            return f'{pre}{mn.upper()}();'
        if o and mn == 'sleep' and ops and re.fullmatch(r'\$p(\d+)', ops[0]):
            return f'{pre}intr_sleep(&p[{ops[0][2:]}]);'
        if o and mn == 'push' and ops and re.fullmatch(r'\$r\d+', ops[0]):
            return f'{pre}push32({val(ops[0])});'
        if o and mn == 'pop' and ops and re.fullmatch(r'\$r\d+', ops[0]):
            return f'{pre}{val(ops[0])} = pop32();'
        if o and mn == 'mpush' and ops and re.fullmatch(r'\$r(\d+)', ops[0]):
            g = ops[0][2:]
            return f'{pre}for (int i = {g}; i >= 0; i--) push32(r[i]);'
        if o and mn == 'mpop' and ops and re.fullmatch(r'\$r(\d+)', ops[0]):
            g = ops[0][2:]
            return f'{pre}for (int i = 0; i <= {g}; i++) r[i] = pop32();'
        if o and mn in ('lbra', 'jmp'):
            m = re.search(r'0x([0-9a-f]+)\s*$', ' '.join(tok))
            if m:
                return f'{pre}goto L_{int(m.group(1),16):x};'
        if o and mn == 'lcall':
            m = re.search(r'0x([0-9a-f]+)\s*$', ' '.join(tok))
            if m:
                return f'{pre}CALL(sub_{int(m.group(1),16):x});'
        return f'{pre}UNKNOWN("{t.replace(chr(34), "")}"); /* FIXME */'

    def fold_region(b, T):
        """b 的条件分支, 落空侧 b.next=F; 尝试折叠 [F..T) 为 {A}。
        返回 (A 或 None)。A 必须: 全部由 F 支配; 与 T 侧可达集不相交且不含函数入口。"""
        F = blk_at[b['start']]['succ'][0] if not blk_at[b['start']]['succ'] else next_of[blk_at[b['start']]['addrs'][-1]]
        if F is None or F not in blk_at:
            return None
        fn_entries = entry_set
        A = [x for x in reach.get(fn_of(b), set()) if x in reach.get(fn_of(b), set())]
        return None  # 见下方真正实现(保留占位)

    # 上面占位删除, 真正实现如下
    def fn_of(addr):
        b = blk_at[addr]
        return b.get('func')
    # 删掉占位函数, 重新定义
    del fold_region

    def region_after(bstart, taken, fall):
        """若 fall 侧区域可折叠(仅被 fall 支配, 不含 taken 侧块/函数入口), 返回块列表(按地址序)。"""
        e = blk_at[bstart].get('func')
        bset = owner.get(e, set())
        if fall not in bset or taken not in bset or fall == taken:
            return None
        # fall 支配的块集合
        A = {x for x in bset if fall in dom.get(x, set()) and x != taken}
        A.discard(taken)
        # 校验: A 内所有块不得被 taken 侧(或 A 外)到达
        for x in A:
            for p in bset:
                if x in blk_at[p]['succ'] and p not in A and p != bstart and p != fall:
                    return None
            if x in entry_set and x != fall:
                return None
            if x not in reach.get(e, set()):
                return None
        # 不允许跨过 taken(地址上): 折叠区必须"线性地"在 taken 之前, 否则语义仍正确但可读性差 → 仍允许
        if taken in A:
            return None
        # taken 不应在 A 内部被跳入
        if A and min(A) == fall and any(x == taken for x in A):
            return None
        return sorted(A)

    def emit_block(bstart, indent):
        if blk_at[bstart].get('func') != cur_func[0]:
            # 跨函数进入: 目标是另一个子程序入口 → 近似为尾调用
            out.append('    ' * indent + f'CALL(sub_{bstart:x});  /* 跨函数进入(尾调用近似) */')
            out.append('    ' * indent + 'return;')
            return
        if bstart in emitted:
            out.append('    ' * indent + f'goto L_{bstart:x};  /* 重复引用 */')
            return
        b = blk_at[bstart]
        lab = f'L_{bstart:x}:; '   # 每个块无条件发射标签: goto 目标必然有定义
        out.append('    ' * indent + f'{lab}/* 0x{bstart:x} */')
        for a in b['addrs'][:-1]:
            out.append(emit_stmt(kinds and ins[addr_idx[a]][2], indent))
        last = b['addrs'][-1]
        k, tgt = kinds[last]
        if k == 'cbr':
            c = cond_text(ins[addr_idx[last]][2])
            fall = next_of[last]
            A = region_after(bstart, tgt, fall) if (tgt is not None and fall in blk_at) else None
            emitted.add(bstart)
            if A:
                out.append('    ' * indent + f'if (!{c}) {{')
                for x in A:
                    emit_block(x, indent + 1)
                out.append('    ' * indent + '}')
                for x in A:
                    emitted.add(x)
                emit_block(tgt, indent)
            else:
                if c is None:
                    out.append(emit_stmt(ins[addr_idx[last]][2], indent))
                elif tgt in blk_at and blk_at[tgt].get('func') != cur_func[0]:
                    out.append('    ' * indent + f'if ({c}) {{ CALL(sub_{tgt:x}); return; }}  /* 跨函数分支 */')
                else:
                    out.append('    ' * indent + f'if ({c}) goto L_{tgt:x};')
                if fall in blk_at and fall not in emitted:
                    emit_block(fall, indent)
        elif k == 'jmp':
            emitted.add(bstart)
            if tgt in blk_at and blk_at[tgt].get('func') != cur_func[0]:
                out.append('    ' * indent + f'CALL(sub_{tgt:x});  /* 跨函数跳转 */')
                out.append('    ' * indent + 'return;')
            else:
                out.append(emit_stmt(ins[addr_idx[last]][2], indent))
            fall = next_of[last]
            if fall in blk_at and fall not in emitted:
                emit_block(fall, indent)     # 物理落空块(可能由其它路径引用)
        elif k in ('ret', 'exit'):
            emitted.add(bstart)
            pre = '    ' * indent
            tok = tok_of(ins[addr_idx[last]][2])
            if tok[0] == 'mpopret':
                g = re.fullmatch(r'\$r(\d+)', tok[1]).group(1) if len(tok) > 1 and re.fullmatch(r'\$r(\d+)', tok[1]) else '8'
                out.append(f'{pre}for (int i = 0; i <= {g}; i++) r[i] = pop32();')
            elif tok[0] == 'mpopaddret':
                m = re.fullmatch(r'\$r(\d+)\s+(0x[0-9a-f]+)', ' '.join(tok[1:]))
                out.append(f'{pre}for (int i = 0; i <= {m.group(1)}; i++) r[i] = pop32();')
                out.append(f'{pre}sp += {m.group(2)};')
            out.append(f'{pre}return;')
        else:
            emitted.add(bstart)
            out.append(emit_stmt(ins[addr_idx[last]][2], indent))
            nx = next_of[last]
            if nx in blk_at:
                if blk_at[nx].get('func') != blk_at[bstart].get('func'):
                    out.append('    ' * indent + f'CALL(sub_{nx:x});  /* 落入下一函数(尾调用语义近似) */')
                    out.append('    ' * indent + 'return;')
                elif nx not in emitted:
                    emit_block(nx, indent)

    for e in func_entries:
        out.append('')
        out.append(f'/* ==== sub_{e:x}  (被调用 {call_cnt.get(e,0)} 次) ==== */')
        out.append(f'static void sub_{e:x}(void) {{')
        emitted.clear()
        cur_func[0] = e
        emit_block(e, 1)
        # 兜底: 本函数内未发射的可达块
        for x in sorted(owner.get(e, set())):
            if x not in emitted:
                out.append(f'    /* 兜底发射(未被主路径覆盖) */')
                emit_block(x, 1)
        out.append('}')
    if dead:
        out.append('')
        out.append('/* 未归属任何函数的块(不可达/孤立): ' + ', '.join(f'0x{x:x}' for x in dead[:20]) + ' */')
    out.append('')
    out.append('int main(void){ push32(0u); sub_0(); return 0; }  /* 入口 0x0 */')

    txt = '\n'.join(out)
    open(dst, 'w', encoding='utf-8').write(txt)
    total = sum(len(v) for v in owner.values())
    print(f'函数 {len(func_entries)} 个; 块 {len(blocks)} 个(归属 {total}); 死块 {len(dead)}')
    print(f'输出 {dst}, {len(txt.splitlines())} 行')


if __name__ == '__main__':
    main()
