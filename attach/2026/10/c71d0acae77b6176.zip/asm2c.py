#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
asm2c.py v3 — 把 envydis 的 Falcon 反汇编转成"可编译的 C 骨架"。

模型:
  - 栈 = SP 基址的 DMEM 栈: lcall/ret/mpush/mpop/push/pop 共用;
  - 寄存器 r0..r15 以宏映射到 r[] 数组(便于 mpush 循环);
  - 特殊寄存器($iv0/$xdbase/$xtargets/ieN...)自动声明;
  - 变址寻址 D[$rN+0xK] / D[$sp+0xK] / D[$rA+$rB*4] 全覆盖。
用法: python asm2c.py fecs_inst.asm fecs_inst.c
"""
import re
import sys

LINE = re.compile(r'^([0-9a-f]+): ([0-9a-f ]+?)\s{2,}(.+)$')
REG_MACROS = '\n'.join(f'#define r{i} r[{i}]' for i in range(16))


def parse(path):
    ins = []
    for l in open(path, encoding='utf-8', errors='replace'):
        m = LINE.match(l.rstrip('\n'))
        if not m:
            continue
        ins.append((int(m.group(1), 16), m.group(2).split(), m.group(3).strip()))
    return ins


def main():
    src, dst = sys.argv[1], sys.argv[2]
    ins = parse(src)
    addr2next = {a: (ins[i + 1][0] if i + 1 < len(ins) else None)
                 for i, (a, _, _) in enumerate(ins)}

    targets, specials = set(), set()
    for a, raw, t in ins:
        tok = t.split()
        while tok and re.fullmatch(r'[CB]{1,2}', tok[0]) and len(tok) > 1:
            tok = tok[1:]
        clean = ' '.join(tok)
        if tok[0] in ('bra', 'lbra', 'lcall'):
            m = re.search(r'0x([0-9a-f]+)\s*$', clean)
            if m:
                targets.add(int(m.group(1), 16))
        for x in re.findall(r'\$[A-Za-z_]\w*', clean):
            if x in ('$sp', '$flags') or re.fullmatch(r'\$(r|p)\d+', x):
                continue
            specials.add(x[1:])
    dangling = sorted(targets - {a for a, _, _ in ins})

    out = []
    out.append('/* 由 asm2c.py v3 从 fecs_inst.asm 机械转译 —— 保真骨架, 非手工反编译。')
    out.append(' * 模型说明:')
    out.append(' *   - 栈: SP 基址 DMEM 栈; lcall/ret/mpush/mpopret/push/pop 共用 (与 Falcon 一致)')
    out.append(' *   - D[A]/B[A]: DMEM 32/8 位访问;  I[A]: I/O 空间(端口语义见 iord/iowr 垫片)')
    out.append(' *   - $flags: Z(bit0)/C(bit1); $p0-$p7: 谓词; ieN: 中断使能位')
    out.append(' *   - 语义未经运行验证; 不确定处标 TODO/UNKNOWN, 便于逐条复核')
    out.append(' */')
    out.append('#include <stdint.h>')
    out.append('#include <stdio.h>')
    out.append('#include <stdlib.h>')
    out.append('typedef uint8_t u8; typedef uint16_t u16; typedef uint32_t u32; typedef uint64_t u64;')
    out.append('static u32 r[16]; static u32 sp; static u8 p[8]; static u32 falcon_flags;')
    out.append(REG_MACROS)
    out.append('static u8 dmem[65536];')
    for s in sorted(specials):
        out.append(f'static u32 sr_{s};')
    out.append('static u32 sr_flags_ie;                  /* $flags.ieN 中断使能 */')
    out.append('static u32 d32(u32 a){ u32 v; __builtin_memcpy(&v, &dmem[a & 0xffff], 4); return v; }')
    out.append('static void s32(u32 a, u32 v){ __builtin_memcpy(&dmem[a & 0xffff], &v, 4); }')
    out.append('static u8  d8(u32 a){ return dmem[a & 0xffff]; }')
    out.append('static void s8(u32 a, u8 v){ dmem[a & 0xffff] = v; }')
    out.append('static u16 d16(u32 a){ u16 v; __builtin_memcpy(&v, &dmem[a & 0xffff], 2); return v; }')
    out.append('static void s16(u32 a, u16 v){ __builtin_memcpy(&dmem[a & 0xffff], &v, 2); }')
    out.append('static u32 xdld(u32 a){ (void)a; return 0; } /* TODO: X 空间读 */')
    out.append('static void xdst(u32 a, u32 v){ (void)a; (void)v; } /* TODO: X 空间写 */')
    out.append('static void push32(u32 v){ sp -= 4; s32(sp, v); }')
    out.append('static u32 pop32(void){ u32 v = d32(sp); sp += 4; return v; }')
    out.append('static u32 iord(u32 port){ (void)port; return 0; } /* TODO: I/O 读(0x18700 命令口) */')
    out.append('static void iowr(u32 port, u32 v){ (void)port; (void)v; } /* TODO: I/O 写(0x21200/0x21800 ack) */')
    out.append('#define iowrs iowr')
    out.append('#define INT_ENABLE(n) do{ sr_flags_ie |= (1u << (n)); }while(0)')
    out.append('#define XDWAIT()   do{ }while(0)')
    out.append('#define XWAIT()    do{ }while(0)')
    out.append('#define DMWAIT()   do{ }while(0)')
    out.append('#define SETFZ(v) (falcon_flags = (falcon_flags & ~1u) | (((v)==0)?1u:0u))')
    out.append('#define FZ(f)   ((f)&1u)')
    out.append('#define FC(f)   (((f)>>1)&1u)')
    out.append('static void fc_cmp(u32 a, u32 b){ falcon_flags &= ~3u; SETFZ(a-b); if (a < b) falcon_flags |= 2u; }')
    out.append('static void fc_xbit(u32 v){ falcon_flags &= ~1u; SETFZ(v); }')
    out.append('static void intr_sleep(u8 *f){ while (!*f) { } *f = 0; } /* 等中断置位 */')
    out.append('static u32 falcon_muls(u32 a, u32 b){ return (u32)(((int64_t)(int32_t)a * (int32_t)b) >> 32); }')
    out.append('static u32 falcon_mulu(u32 a, u32 b){ return (u32)(((u64)a * b) >> 32); }')
    out.append('#define UNKNOWN(msg) do{ fprintf(stderr, "UNKNOWN: %s\\n", msg); abort(); }while(0)')
    out.append('')
    out.append('void fecs(u32 entry_pc) {')
    out.append('    u32 pc = entry_pc;')
    out.append('    for (;;) switch (pc) {')

    def isr(x):
        return re.fullmatch(r'\$r\d+', x)

    def rn(x):
        return 'r' + x[2:]

    def val(x):
        if not x:
            return None
        if isr(x):
            return rn(x)
        if x == '$sp':
            return 'sp'
        if x == '$flags':
            return 'falcon_flags'
        if re.fullmatch(r'0x[0-9a-f]+|-0x[0-9a-f]+', x):
            return x + 'u'
        if x.startswith('$'):
            return 'sr_' + x[1:]
        return None

    def dmem_expr(x):
        for pat, fmt in (
            (r'D\[\$r(\d+)\]', 'd32(r{0})'),
            (r'D\[\$r(\d+)\+0x([0-9a-f]+)\]', 'd32(r{0}+0x{1})'),
            (r'D\[\$sp\+0x([0-9a-f]+)\]', 'd32(sp+0x{0})'),
            (r'D\[\$r(\d+)\+\$r(\d+)\*0x(\d+)\]', 'd32(r{0}+r{1}*0x{2})'),
            (r'D\[\$r(\d+)\+\$r(\d+)\]', 'd32(r{0}+r{1})'),
        ):
            m = re.fullmatch(pat, x)
            if m:
                return fmt.format(*m.groups())
        if x == 'D[$sp]':
            return 'd32(sp)'
        return None

    def io_expr(x):
        for pat, fmt in (
            (r'I\[\$r(\d+)\]', 'r{0}'),
            (r'I\[\$r(\d+)\+0x([0-9a-f]+)\]', 'r{0}+0x{1}'),
            (r'I\[\$r(\d+)\+\$r(\d+)\*0x(\d+)\]', 'r{0}+r{1}*0x{2}'),
            (r'I\[\$r(\d+)\+\$r(\d+)\]', 'r{0}+r{1}'),
        ):
            m = re.fullmatch(pat, x)
            if m:
                return fmt.format(*m.groups())
        return None

    ok = unk = 0
    for a, raw, t in ins:
        nxt = addr2next[a]
        tok = t.split()
        while tok and re.fullmatch(r'[CB]{1,2}', tok[0]) and len(tok) > 1:
            tok = tok[1:]
        mn, ops = tok[0], tok[1:]
        clean = ' '.join(tok)
        nxt_s = f'0x{nxt:x}' if nxt is not None else '0x0'
        head = f'    case 0x{a:x}:'
        if a in targets:
            head += '   /* 跳转目标 */'
        out.append(head)
        stmt, cont = None, True

        if mn == 'mov':
            o = [x for x in ops if not re.fullmatch(r'b(8|16|32)', x)]
            if len(o) == 2 and val(o[0]) and val(o[1]):
                stmt = f'{val(o[0])} = {val(o[1])};'
        elif mn == 'clear':
            o = [x for x in ops if not x.startswith('b')]
            if len(o) == 1 and isr(o[0]):
                stmt = f'{rn(o[0])} = 0;'
        elif mn in ('add', 'sub', 'and', 'or', 'xor', 'mod'):
            op = {'add': '+', 'sub': '-', 'and': '&', 'or': '|', 'xor': '^', 'mod': '%'}[mn]
            o = [x for x in ops if not re.fullmatch(r'b(8|16|32)', x)]
            if len(o) == 3 and val(o[0]) and val(o[1]) and val(o[2]):
                stmt = f'{val(o[0])} = {val(o[1])} {op} {val(o[2])};'
            elif len(o) == 2 and val(o[0]) and val(o[1]):
                stmt = f'{val(o[0])} {op}= {val(o[1])};'
        elif mn in ('shl', 'shr', 'sar'):
            op = {'shl': '<<', 'shr': '>>', 'sar': '>>'}[mn]
            o = [x for x in ops if not re.fullmatch(r'b(8|16|32)', x)]
            if len(o) == 3 and val(o[0]) and val(o[1]):
                stmt = f'{val(o[0])} = {val(o[1])} {op} {val(o[2]) or (o[2] + "u")};'
            elif len(o) == 2 and val(o[0]):
                stmt = f'{val(o[0])} {op}= {val(o[1]) or (o[1] + "u")};'
        elif mn == 'not':
            o = [x for x in ops if not re.fullmatch(r'b(8|16|32)', x)]
            if len(o) == 2 and val(o[0]) and val(o[1]):
                stmt = f'{val(o[0])} = ~{val(o[1])};'
            elif len(o) == 1 and val(o[0]):
                stmt = f'{val(o[0])} = ~{val(o[0])};'
        elif mn == 'neg':
            o = [x for x in ops if not re.fullmatch(r'b(8|16|32)', x)]
            if len(o) == 2 and val(o[0]) and val(o[1]):
                stmt = f'{val(o[0])} = (u32)(-(int32_t){val(o[1])});'
            elif len(o) == 1 and val(o[0]):
                stmt = f'{val(o[0])} = (u32)(-(int32_t){val(o[0])});'
        elif mn == 'sethi':
            if len(ops) == 2 and val(ops[0]):
                stmt = f'{val(ops[0])} = ({val(ops[0])} & 0xffffu) | ((u32){ops[1]}u << 16); /* sethi 语义待复核 */'
        elif mn == 'cmp':
            o = [x for x in ops if not re.fullmatch(r'b(8|16|32)', x)]
            if len(o) == 2 and val(o[0]) and val(o[1]):
                stmt = f'fc_cmp({val(o[0])}, {val(o[1])});'
        elif mn == 'ld':
            de = dmem_expr(ops[2]) if len(ops) == 3 else None
            if de and isr(ops[1]):
                stmt = f'{rn(ops[1])} = {de};'
        elif mn == 'st':
            de = dmem_expr(ops[1]) if len(ops) == 3 else None
            if de and val(ops[2]):
                fname = de.split('(')[0].replace('d', 's', 1)
                stmt = f'{fname}({de[de.index("(")+1:-1]}, {val(ops[2])});'
        elif mn in ('iowr', 'iowrs'):
            ie = io_expr(ops[0]) if len(ops) == 2 else None
            if ie and val(ops[1]):
                stmt = f'{mn}({ie}, {val(ops[1])});'
        elif mn == 'iord':
            ie = io_expr(ops[1]) if len(ops) == 2 else None
            if ie and isr(ops[0]):
                stmt = f'{rn(ops[0])} = iord({ie});'
        elif mn == 'extr':
            m = re.fullmatch(r'0x([0-9a-f]+):0x([0-9a-f]+)', ops[2]) if len(ops) == 3 else None
            if m and val(ops[0]) and val(ops[1]):
                lo, hi = int(m.group(1), 16), int(m.group(2), 16)
                stmt = f'{val(ops[0])} = ({val(ops[1])} >> {lo}) & 0x{(1 << (hi-lo+1))-1:x}u;'
        elif mn in ('muls', 'mulu'):
            if len(ops) >= 2 and val(ops[0]) and val(ops[1]):
                src2 = val(ops[2]) if len(ops) == 3 else val(ops[0])
                stmt = f'{val(ops[0])} = falcon_{mn}({val(ops[1])}, {src2}); /* 乘法步进 */'
        elif mn == 'bset' and len(ops) == 2 and ops[0] == '$flags' and re.fullmatch(r'ie\d+', ops[1]):
            stmt = f'INT_ENABLE({ops[1][2:]}); /* bset $flags {ops[1]} */'
        elif mn in ('bset', 'bclr', 'btgl'):
            if len(ops) == 2 and ops[0] == '$flags' and re.fullmatch(r'\$p\d+', ops[1]):
                stmt = f'p[{ops[1][2:]}] = {1 if mn=="bset" else 0};'
            elif len(ops) == 2 and isr(ops[0]) and re.fullmatch(r'0x[0-9a-f]+', ops[1]):
                op = {'bset': '|=', 'bclr': '&= ~', 'btgl': '^='}[mn]
                stmt = f'{rn(ops[0])} {op} (1u << {ops[1]});'
            elif len(ops) == 3 and val(ops[0]) and val(ops[1]) and val(ops[2]):
                op = {'bset': '|', 'bclr': '& ~', 'btgl': '^'}[mn]
                stmt = f'{val(ops[0])} = {val(ops[1])} {op} {val(ops[2])};'
        elif mn in ('xdld', 'xdst'):
            if len(ops) == 2 and val(ops[0]) and (val(ops[1]) or isr(ops[1])):
                v0, v1 = val(ops[0]), val(ops[1])
                stmt = (f'{v0} = xdld({v1});' if mn == 'xdld' else f'xdst({v0}, {v1});')
        elif mn == 'xbit':
            if ops and val(ops[0]):
                stmt = f'fc_xbit({val(ops[0])}); /* xbit → 置 Z */'
        elif mn in ('xdwait', 'xwait', 'dmwait'):
            stmt = f'{mn.upper()}(); /* X/DMA 等待 */'
        elif mn == 'bra':
            m = re.fullmatch(r'bra\s+b(?:8|16|32)\s+(\$r\d+)\s+(\$r\d+|0x[0-9a-f]+)\s+(e|ne|a|b|g|l|ae|be|ge|le)\s+0x([0-9a-f]+)', clean)
            if m:
                cc = {'e': '==', 'ne': '!=', 'a': '>', 'g': '>', 'b': '<', 'l': '<',
                      'ae': '>=', 'ge': '>=', 'be': '<=', 'le': '<='}[m.group(3)]
                stmt = f'pc = ({val(m.group(1))} {cc} {val(m.group(2))}) ? 0x{int(m.group(4),16):x} : {nxt_s}; continue;'
            else:
                m = re.fullmatch(r'bra\s+(e|ne|a|b|g|l|ae|be|ge|le)\s+0x([0-9a-f]+)', clean)
                if m:
                    cc = {'e': 'FZ(falcon_flags)', 'ne': '!FZ(falcon_flags)',
                          'a': '!(FC(falcon_flags)) && !FZ(falcon_flags)', 'b': 'FC(falcon_flags)',
                          'ae': '!FC(falcon_flags)', 'be': 'FC(falcon_flags) || FZ(falcon_flags)',
                          'g': '!(FC(falcon_flags)) && !FZ(falcon_flags)', 'l': 'FC(falcon_flags)',
                          'ge': '!FC(falcon_flags)', 'le': 'FC(falcon_flags) || FZ(falcon_flags)'}[m.group(1)]
                    stmt = f'pc = ({cc}) ? 0x{int(m.group(2),16):x} : {nxt_s}; continue;'
        elif mn in ('lbra', 'jmp'):
            m = re.search(r'0x([0-9a-f]+)\s*$', clean)
            if m:
                stmt = f'pc = 0x{int(m.group(1),16):x}; continue;'
        elif mn == 'lcall':
            m = re.search(r'0x([0-9a-f]+)\s*$', clean)
            if m:
                stmt = f'push32({nxt_s}); pc = 0x{int(m.group(1),16):x}; continue; /* lcall */'
        elif mn in ('ret', 'iret'):
            stmt = 'pc = pop32(); continue; /* ret */'
        elif mn == 'mpush':
            m = re.fullmatch(r'\$r(\d+)', ops[0]) if ops else None
            if m:
                stmt = f'for (int i = {m.group(1)}; i >= 0; i--) push32(r[i]); /* mpush r0..r{m.group(1)} */'
        elif mn == 'mpop':
            m = re.fullmatch(r'\$r(\d+)', ops[0]) if ops else None
            if m:
                stmt = f'for (int i = 0; i <= {m.group(1)}; i++) r[i] = pop32();'
        elif mn == 'mpopret':
            m = re.fullmatch(r'\$r(\d+)', ops[0]) if ops else None
            if m:
                stmt = f'for (int i = 0; i <= {m.group(1)}; i++) r[i] = pop32(); pc = pop32(); continue; /* mpopret */'
        elif mn == 'mpopaddret':
            m = re.fullmatch(r'\$r(\d+)\s+(0x[0-9a-f]+)', ' '.join(ops)) if ops else None
            if m:
                stmt = f'for (int i = 0; i <= {m.group(1)}; i++) r[i] = pop32(); sp += {m.group(2)}; pc = pop32(); continue; /* mpopaddret */'
        elif mn == 'push':
            if ops and isr(ops[0]):
                stmt = f'push32({rn(ops[0])});'
        elif mn == 'pop':
            if ops and isr(ops[0]):
                stmt = f'{rn(ops[0])} = pop32();'
        elif mn == 'sleep':
            if ops and re.fullmatch(r'\$p(\d+)', ops[0]):
                stmt = f'intr_sleep(&p[{ops[0][2:]}]);'
        elif mn == 'exit':
            stmt, cont = 'return;', False

        if stmt is None:
            stmt, cont = f'UNKNOWN("{t.replace(chr(34), "")}"); /* FIXME */', False
            unk += 1
        else:
            ok += 1
        out.append(f'        /* {a:04x}: {t} */')
        out.append(f'        {stmt}')
        if cont and 'continue;' not in stmt and not stmt.startswith('return'):
            out.append(f'        pc = {nxt_s}; continue;')
    out.append('    default: fprintf(stderr, "pc 越界 0x%x\\n", pc); return;')
    out.append('    }')
    out.append('}')

    open(dst, 'w', encoding='utf-8').write('\n'.join(out))
    print(f'指令 {len(ins)} 条 -> {dst}')
    print(f'已映射 {ok}; UNKNOWN {unk}; 目标点 {len(targets)}; 悬空 {dangling[:5]}')


if __name__ == '__main__':
    main()
