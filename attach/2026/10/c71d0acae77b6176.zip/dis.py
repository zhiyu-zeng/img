#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""打印 fecs_inst.asm 中 [start,end] 地址区间的指令。用法: dis.py <asm> <start_hex> <end_hex>"""
import re, sys

def load(path):
    ins = []
    for l in open(path, encoding='utf-8', errors='replace'):
        m = re.match(r'^([0-9a-f]+): ([0-9a-f ]+?)\s{2,}(.+)$', l.rstrip('\n'))
        if m:
            ins.append((int(m.group(1), 16), m.group(2).strip(), m.group(3).strip()))
    return ins

ins = load(sys.argv[1])
start = int(sys.argv[2], 16)
end = int(sys.argv[3], 16) if len(sys.argv) > 3 else start + 0x100
for a, b, t in ins:
    if start <= a <= end:
        print(f'{a:#06x}: {b:<12} {t}')
