#!/usr/bin/env python3
"""从 ctxsw_ucode 头文件提取 FECS/GPCCS 微码与镜像各段。"""
import struct, sys, re, os
def parse_hdr(path):
    s = open(path, encoding='utf-8', errors='replace').read()
    out = {}
    for m in re.finditer(r'static unsigned char\s+(\w+)\[\]\s*=\s*\{(.*?)\};', s, re.S):
        out[m.group(1)] = bytes(int(x,16) for x in re.findall(r'0x([0-9a-fA-F]{2})', m.group(2)))
    return out
def parse_img(path):
    d = open(path,'rb').read()
    ver, cnt = struct.unpack_from('<II', d, 0)
    rows = [struct.unpack_from('<III', d, 8+12*i) for i in range(cnt)]
    return ver, [(rid, d[off:off+sz]) for rid, sz, off in rows]
if __name__ == '__main__':
    base = sys.argv[1] if len(sys.argv) > 1 else '.'
    for name, data in parse_hdr(os.path.join(base, 'NETA_fecs_ucode_img.h')).items():
        open(f'fecs_{name}.bin','wb').write(data); print(name, len(data))
    ver, segs = parse_img(os.path.join(base, 'NETA_img.bin'))
    print('image version', ver, 'regions', len(segs))
