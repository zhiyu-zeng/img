00000000: d0 00 28 00 00        mov $r0 0x2800
00000005: fe 04 00              mov $sp $r0
00000008: bd a4                 clear b32 $r10
0000000a: 7e 47 77 00           lcall 0x7747
0000000e: f8 02                 exit

00000010: 89 2c 00 00        C  mov $r9 0x2c
00000014: bf 99                 ld b32 $r9 D[$r9]
00000016: b3 94 00 29           bra b32 $r9 0x0 ne 0x3f
0000001a: 0f 0f                 mov $r15 0xf
0000001c: 89 00 94 00           mov $r9 0x9400
00000020: fa 9f 01              iowrs I[$r9] $r15
00000023: 0f 01                 mov $r15 0x1
00000025: 89 2c 00 00           mov $r9 0x2c
00000029: a0 9f                 st b32 D[$r9] $r15
0000002b: fa ab 01              iowrs I[$r10] $r11
0000002e: bd f4                 clear b32 $r15
00000030: 89 00 94 00           mov $r9 0x9400
00000034: fa 9f 01              iowrs I[$r9] $r15
00000037: 89 2c 00 00           mov $r9 0x2c
0000003b: a0 9f                 st b32 D[$r9] $r15
0000003d: f8 00                 ret
0000003f: fa ab 01            B iowrs I[$r10] $r11
00000042: f8 00                 ret

00000044: 89 2c 00 00        C  mov $r9 0x2c
00000048: bf 99                 ld b32 $r9 D[$r9]
0000004a: b3 94 00 29           bra b32 $r9 0x0 ne 0x73
0000004e: 0f 0f                 mov $r15 0xf
00000050: 89 00 94 00           mov $r9 0x9400
00000054: fa 9f 01              iowrs I[$r9] $r15
00000057: 0f 01                 mov $r15 0x1
00000059: 89 2c 00 00           mov $r9 0x2c
0000005d: a0 9f                 st b32 D[$r9] $r15
0000005f: bd f4                 clear b32 $r15
00000061: ff af af              iord $r10 I[$r10+$r15*0x4]
00000064: 89 00 94 00           mov $r9 0x9400
00000068: fa 9f 01              iowrs I[$r9] $r15
0000006b: 89 2c 00 00           mov $r9 0x2c
0000006f: a0 9f                 st b32 D[$r9] $r15
00000071: f8 00                 ret
00000073: bd 94               B clear b32 $r9
00000075: ff a9 af              iord $r10 I[$r10+$r9*0x4]
00000078: f8 00                 ret

0000007a: 0f 0f              C  mov $r15 0xf
0000007c: 89 00 94 00           mov $r9 0x9400
00000080: fa 9f 01              iowrs I[$r9] $r15
00000083: 0f 01                 mov $r15 0x1
00000085: 89 2c 00 00           mov $r9 0x2c
00000089: 8e 00 c5 01           mov $r14 0x1c500
0000008d: a0 9f                 st b32 D[$r9] $r15
0000008f: 89 28 13 00           mov $r9 0x1328
00000093: bf 9f                 ld b32 $r15 D[$r9]
00000095: 3e 9f 00 00           lbra 0x9f
00000099: ff ef 9f            B iord $r9 I[$r14+$r15*0x4]
0000009c: c4 9f 1f              and $r15 $r9 0x1f
0000009f: b3 f0 00 fa         B bra b32 $r15 0x0 e 0x99
000000a3: 89 00 c8 01           mov $r9 0x1c800
000000a7: fa 9a 00              iowr I[$r9] $r10
000000aa: 89 28 13 00           mov $r9 0x1328
000000ae: 92 ff 01              sub b32 $r15 $r15 0x1
000000b1: a0 9f                 st b32 D[$r9] $r15
000000b3: bd f4                 clear b32 $r15
000000b5: 89 00 94 00           mov $r9 0x9400
000000b9: fa 9f 01              iowrs I[$r9] $r15
000000bc: 89 2c 00 00           mov $r9 0x2c
000000c0: a0 9f                 st b32 D[$r9] $r15
000000c2: f8 00                 ret

000000c4: d9 ff ff ff 03     C  mov $r9 0x3ffffff
000000c9: fd b9 04              and $r11 $r9
000000cc: d9 00 00 00 80        mov $r9 0x80000000
000000d1: f0 a4 1f              and $r10 0x1f
000000d4: b6 a4 1a              shl b32 $r10 0x1a
000000d7: fd ab 05              or $r10 $r11
000000da: fd a9 05              or $r10 $r9
000000dd: 7e 7a 00 00           lcall 0x7a
000000e1: f8 00                 ret

000000e3: f0 a4 01           C  and $r10 0x1
000000e6: b6 a4 10              shl b32 $r10 0x10
000000e9: db 00 10 00 40        mov $r11 0x40001000
000000ee: ff ab b5              or $r11 $r10 $r11
000000f1: 8a 00 c5 01           mov $r10 0x1c500
000000f5: 7e 10 00 00           lcall 0x10
000000f9: f8 00                 ret

000000fb: bd 94              C  clear b32 $r9
000000fd: 8f 00 90 00           mov $r15 0x9000
00000101: ff f9 af              iord $r10 I[$r15+$r9*0x4]
00000104: c4 a9 01              and $r9 $r10 0x1
00000107: b3 90 01 08           bra b32 $r9 0x1 e 0x10f
0000010b: bd a4                 clear b32 $r10
0000010d: f8 00                 ret
0000010f: c7 aa 24            B extr $r10 $r10 0x4:0x5
00000112: f8 00                 ret

00000114: b3 a0 00 1b        C  bra b32 $r10 0x0 e 0x12f
00000118: df 00 00 00 80        mov $r15 0x80000000
0000011d: d9 ff ff ff 3f        mov $r9 0x3fffffff
00000122: ff a9 94              and $r9 $r10 $r9
00000125: fd 9f 05              or $r9 $r15
00000128: 8f 00 0c 01           mov $r15 0x10c00
0000012c: fa f9 00              iowr I[$r15] $r9
0000012f: f8 00               B ret
00000131: bd f4                 clear b32 $r15
00000133: 89 00 0c 01           mov $r9 0x10c00
00000137: fa 9f 00              iowr I[$r9] $r15
0000013a: f8 00                 ret
0000013c: 89 00 2e 02           mov $r9 0x22e00
00000140: fa 9b 00              iowr I[$r9] $r11
00000143: f0 a4 ff              and $r10 0xff
00000146: b8 99 00 01 00        add b32 $r9 $r9 0x100
0000014b: fa 9a 00              iowr I[$r9] $r10
0000014e: f8 00                 ret

00000150: 0f 10              C  mov $r15 0x10
00000152: 89 00 15 02           mov $r9 0x21500
00000156: fa 9f 00              iowr I[$r9] $r15
00000159: d9 fc ff ff 03        mov $r9 0x3fffffc
0000015e: fd a9 04              and $r10 $r9
00000161: d9 00 00 00 80        mov $r9 0x80000000
00000166: fd a9 05              or $r10 $r9
00000169: f0 b4 01              and $r11 0x1
0000016c: b6 b4 1a              shl b32 $r11 0x1a
0000016f: ff ab b5              or $r11 $r10 $r11
00000172: 8a 00 ca 01           mov $r10 0x1ca00
00000176: 7e 10 00 00           lcall 0x10
0000017a: 8e 00 ca 01           mov $r14 0x1ca00
0000017e: bd f4                 clear b32 $r15
00000180: ff ef 9f            B iord $r9 I[$r14+$r15*0x4]
00000183: b6 95 1f              shr b32 $r9 0x1f
00000186: b3 90 01 fa           bra b32 $r9 0x1 e 0x180
0000018a: 8e 00 ca 01           mov $r14 0x1ca00
0000018e: bd f4                 clear b32 $r15
00000190: ff ef 9f            B iord $r9 I[$r14+$r15*0x4]
00000193: c7 99 3b              extr $r9 $r9 0x1b:0x1c
00000196: f4 1b fa              bra ne 0x190
00000199: 8a 00 cb 01           mov $r10 0x1cb00
0000019d: 7e 44 00 00           lcall 0x44
000001a1: 0f 10                 mov $r15 0x10
000001a3: 89 00 1b 02           mov $r9 0x21b00
000001a7: fa 9f 00              iowr I[$r9] $r15
000001aa: f8 00                 ret

000001ac: f9 42              C  mpush $r4
000001ae: 0f 08                 mov $r15 0x8
000001b0: b2 a1                 mov b32 $r1 $r10
000001b2: b2 c3                 mov b32 $r3 $r12
000001b4: b2 d4                 mov b32 $r4 $r13
000001b6: b2 e2                 mov b32 $r2 $r14
000001b8: 89 00 15 02           mov $r9 0x21500
000001bc: fa 9f 00              iowr I[$r9] $r15
000001bf: 8a 00 cc 01           mov $r10 0x1cc00
000001c3: b0 d6 01              cmp b32 $r13 0x1
000001c6: f0 0c 0b              xbit $r0 $flags z
000001c9: 7e 10 00 00           lcall 0x10
000001cd: d9 fc ff ff 03        mov $r9 0x3fffffc
000001d2: fd 19 04              and $r1 $r9
000001d5: d9 00 00 00 80        mov $r9 0x80000000
000001da: 90 00 02              add b32 $r0 $r0 0x2
000001dd: fd 19 05              or $r1 $r9
000001e0: f0 34 01              and $r3 0x1
000001e3: f0 24 01              and $r2 0x1
000001e6: f0 04 03              and $r0 0x3
000001e9: b6 24 1a              shl b32 $r2 0x1a
000001ec: b6 04 1d              shl b32 $r0 0x1d
000001ef: fd 13 05              or $r1 $r3
000001f2: 8a 00 ca 01           mov $r10 0x1ca00
000001f6: fd 12 05              or $r1 $r2
000001f9: ff 10 b5              or $r11 $r1 $r0
000001fc: 7e 10 00 00           lcall 0x10
00000200: 8e 00 ca 01           mov $r14 0x1ca00
00000204: bd f4                 clear b32 $r15
00000206: ff ef 9f            B iord $r9 I[$r14+$r15*0x4]
00000209: b6 95 1f              shr b32 $r9 0x1f
0000020c: b3 90 01 fa           bra b32 $r9 0x1 e 0x206
00000210: b3 44 01 14           bra b32 $r4 0x1 ne 0x224
00000214: 8e 00 ca 01           mov $r14 0x1ca00
00000218: bd f4                 clear b32 $r15
0000021a: ff ef 9f            B iord $r9 I[$r14+$r15*0x4]
0000021d: c7 99 3b              extr $r9 $r9 0x1b:0x1c
00000220: b3 94 02 fa           bra b32 $r9 0x2 ne 0x21a
00000224: 0f 08               B mov $r15 0x8
00000226: 89 00 1b 02           mov $r9 0x21b00
0000022a: fa 9f 00              iowr I[$r9] $r15
0000022d: fb 41                 mpopret $r4

0000022f: bd e4              C  clear b32 $r14
00000231: 7e ac 01 00           lcall 0x1ac
00000235: f8 00                 ret

00000237: f9 02              C  mpush $r0
00000239: 0f 08                 mov $r15 0x8
0000023b: b2 a0                 mov b32 $r0 $r10
0000023d: 89 00 15 02           mov $r9 0x21500
00000241: fa 9f 00              iowr I[$r9] $r15
00000244: 8a 00 cc 01           mov $r10 0x1cc00
00000248: 7e 10 00 00           lcall 0x10
0000024c: d9 fc ff ff 03        mov $r9 0x3fffffc
00000251: 8a 00 ca 01           mov $r10 0x1ca00
00000255: fd 09 04              and $r0 $r9
00000258: db 00 00 00 e4        mov $r11 0xe4000000
0000025d: ff 0b b5              or $r11 $r0 $r11
00000260: 7e 10 00 00           lcall 0x10
00000264: 8e 00 ca 01           mov $r14 0x1ca00
00000268: bd f4                 clear b32 $r15
0000026a: ff ef 9f            B iord $r9 I[$r14+$r15*0x4]
0000026d: b6 95 1f              shr b32 $r9 0x1f
00000270: b3 90 01 fa           bra b32 $r9 0x1 e 0x26a
00000274: 8e 00 ca 01           mov $r14 0x1ca00
00000278: bd f4                 clear b32 $r15
0000027a: ff ef 9f            B iord $r9 I[$r14+$r15*0x4]
0000027d: c7 99 3b              extr $r9 $r9 0x1b:0x1c
00000280: b3 94 02 fa           bra b32 $r9 0x2 ne 0x27a
00000284: 0f 08                 mov $r15 0x8
00000286: 89 00 1b 02           mov $r9 0x21b00
0000028a: fa 9f 00              iowr I[$r9] $r15
0000028d: fb 01                 mpopret $r0

0000028f: 0e 01              C  mov $r14 0x1
00000291: 7e ac 01 00           lcall 0x1ac
00000295: f8 00                 ret

00000297: 0b 01              C  mov $r11 0x1
00000299: 7e 50 01 00           lcall 0x150
0000029d: f8 00                 ret
0000029f: f9 12                 mpush $r1
000002a1: 0f 20                 mov $r15 0x20
000002a3: b2 a0                 mov b32 $r0 $r10
000002a5: b2 c1                 mov b32 $r1 $r12
000002a7: 89 00 15 02           mov $r9 0x21500
000002ab: fa 9f 00              iowr I[$r9] $r15
000002ae: 8a 00 d4 01           mov $r10 0x1d400
000002b2: 7e 10 00 00           lcall 0x10
000002b6: d9 fc ff ff 03        mov $r9 0x3fffffc
000002bb: fd 09 04              and $r0 $r9
000002be: d9 00 00 00 c0        mov $r9 0xc0000000
000002c3: f0 14 01              and $r1 0x1
000002c6: fd 09 05              or $r0 $r9
000002c9: 8a 00 ce 01           mov $r10 0x1ce00
000002cd: ff 01 b5              or $r11 $r0 $r1
000002d0: 7e 10 00 00           lcall 0x10
000002d4: 8e 00 ce 01           mov $r14 0x1ce00
000002d8: bd f4                 clear b32 $r15
000002da: ff ef 9f            B iord $r9 I[$r14+$r15*0x4]
000002dd: b6 95 1f              shr b32 $r9 0x1f
000002e0: b3 90 01 fa           bra b32 $r9 0x1 e 0x2da
000002e4: 0f 20                 mov $r15 0x20
000002e6: 89 00 1b 02           mov $r9 0x21b00
000002ea: fa 9f 00              iowr I[$r9] $r15
000002ed: fb 11                 mpopret $r1
000002ef: f8 00                 ret
000002f1: bd f4                 clear b32 $r15
000002f3: 49 00 0b              mov $r9 0xb00
000002f6: ff 9f 9f              iord $r9 I[$r9+$r15*0x4]
000002f9: 4a 00 0c              mov $r10 0xc00
000002fc: ff af af              iord $r10 I[$r10+$r15*0x4]
000002ff: fd a9 06              xor $r10 $r9
00000302: f8 00                 ret
00000304: bd e4                 clear b32 $r14
00000306: 4f 00 0b              mov $r15 0xb00
00000309: ff fe ff              iord $r15 I[$r15+$r14*0x4]
0000030c: 49 00 0c              mov $r9 0xc00
0000030f: ff 9e 9f              iord $r9 I[$r9+$r14*0x4]
00000312: fd 9f 06              xor $r9 $r15
00000315: 8f 04 16 00           mov $r15 0x1604
00000319: a0 f9                 st b32 D[$r15] $r9
0000031b: f8 00                 ret
0000031d: 4a ec 03              mov $r10 0x3ec
00000320: f8 00                 ret
00000322: 4a 88 00              mov $r10 0x88
00000325: f8 00                 ret
00000327: 0a 2c                 mov $r10 0x2c
00000329: f8 00                 ret

0000032b: bd 94              C  clear b32 $r9
0000032d: 4f 00 0b              mov $r15 0xb00
00000330: ff f9 df              iord $r13 I[$r15+$r9*0x4]
00000333: 4f 00 0c              mov $r15 0xc00
00000336: ff f9 ef              iord $r14 I[$r15+$r9*0x4]
00000339: a6 ab                 cmp b32 $r10 $r11
0000033b: f4 0d 0d              bra be 0x348
0000033e: 90 a9 01              add b32 $r9 $r10 0x1
00000341: bc 9b f2              sub b32 $r15 $r9 $r11
00000344: 3e 4e 03 00           lbra 0x34e
00000348: bc ba 92            B sub b32 $r9 $r11 $r10
0000034b: 90 9f 01              add b32 $r15 $r9 0x1
0000034e: ff ed 96            B xor $r9 $r14 $r13
00000351: ff 9f 9d              mod $r9 $r9 $r15
00000354: a6 ab                 cmp b32 $r10 $r11
00000356: f4 0d 08              bra be 0x35e
00000359: bc 9b a0              add b32 $r10 $r9 $r11
0000035c: f8 00                 ret
0000035e: bc 9a a0            B add b32 $r10 $r9 $r10
00000361: f8 00                 ret

00000363: f9 42              C  mpush $r4
00000365: b0 c6 00              cmp b32 $r12 0x0
00000368: f0 4c 0b              xbit $r4 $flags z
0000036b: f0 46 01              xor $r4 0x1
0000036e: b2 a0                 mov b32 $r0 $r10
00000370: b2 b2                 mov b32 $r2 $r11
00000372: bd 14                 clear b32 $r1
00000374: 03 fe                 mov $r3 -0x2
00000376: 3e 96 03 00           lbra 0x396
0000037a: 7e 97 02 00         B lcall 0x297
0000037e: 90 11 01              add b32 $r1 $r1 0x1
00000381: ff a3 b4              and $r11 $r10 $r3
00000384: bd c4                 clear b32 $r12
00000386: b2 0a                 mov b32 $r10 $r0
00000388: ff 4b b5              or $r11 $r4 $r11
0000038b: b8 00 00 02 00        add b32 $r0 $r0 0x200
00000390: bd d4                 clear b32 $r13
00000392: 7e 8f 02 00           lcall 0x28f
00000396: b2 0a               B mov b32 $r10 $r0
00000398: a6 12                 cmp b32 $r1 $r2
0000039a: f4 08 e0              bra b 0x37a
0000039d: fb 41                 mpopret $r4

0000039f: f9 82              C  mpush $r8
000003a1: b2 a3                 mov b32 $r3 $r10
000003a3: b2 b7                 mov b32 $r7 $r11
000003a5: b2 c6                 mov b32 $r6 $r12
000003a7: b2 d5                 mov b32 $r5 $r13
000003a9: b2 e4                 mov b32 $r4 $r14
000003ab: b4 80 0a              ld b32 $r8 D[$sp+0x28]
000003ae: bd 24                 clear b32 $r2
000003b0: 3e de 03 00           lbra 0x3de
000003b4: bc 80 95            B shr b32 $r9 $r8 $r0
000003b7: f0 94 01              and $r9 0x1
000003ba: f4 1b 0f              bra ne 0x3c9
000003bd: b2 1a                 mov b32 $r10 $r1
000003bf: b2 5b                 mov b32 $r11 $r5
000003c1: bd c4                 clear b32 $r12
000003c3: b2 4d                 mov b32 $r13 $r4
000003c5: 7e 8f 02 00           lcall 0x28f
000003c9: 90 00 01            B add b32 $r0 $r0 0x1
000003cc: b8 11 00 02 00        add b32 $r1 $r1 0x200
000003d1: a6 06               B cmp b32 $r0 $r6
000003d3: f4 08 e1              bra b 0x3b4
000003d6: 90 22 01              add b32 $r2 $r2 0x1
000003d9: b8 33 00 40 00        add b32 $r3 $r3 0x4000
000003de: a6 27               B cmp b32 $r2 $r7
000003e0: f4 18 0b              bra ae 0x3eb
000003e3: b2 31                 mov b32 $r1 $r3
000003e5: bd 04                 clear b32 $r0
000003e7: 3e d1 03 00           lbra 0x3d1
000003eb: fb 81               B mpopret $r8

000003ed: f9 02              C  mpush $r0
000003ef: b2 b0                 mov b32 $r0 $r11
000003f1: b2 ab                 mov b32 $r11 $r10
000003f3: 8a fc 4f 02           mov $r10 0x24ffc
000003f7: 7e 10 00 00           lcall 0x10
000003fb: b3 00 00 0e           bra b32 $r0 0x0 e 0x409
000003ff: 8a fc 4a 02           mov $r10 0x24afc
00000403: 0b 0a                 mov $r11 0xa
00000405: 3e 0f 04 00           lbra 0x40f
00000409: 8a fc 4a 02         B mov $r10 0x24afc
0000040d: 0b 0b                 mov $r11 0xb
0000040f: 7e 10 00 00         B lcall 0x10
00000413: fb 01                 mpopret $r0

00000415: b3 a0 00 0e        C  bra b32 $r10 0x0 e 0x423
00000419: 8a fc 4a 02           mov $r10 0x24afc
0000041d: 0b 0c                 mov $r11 0xc
0000041f: 3e 29 04 00           lbra 0x429
00000423: 8a fc 4a 02         B mov $r10 0x24afc
00000427: 0b 0d                 mov $r11 0xd
00000429: 7e 10 00 00         B lcall 0x10
0000042d: f8 00                 ret

0000042f: b2 ab              C  mov b32 $r11 $r10
00000431: 8a fc 47 02           mov $r10 0x247fc
00000435: 7e 10 00 00           lcall 0x10
00000439: 8a fc 4a 02           mov $r10 0x24afc
0000043d: 0b 04                 mov $r11 0x4
0000043f: 7e 10 00 00           lcall 0x10
00000443: f8 00                 ret

00000445: b2 ab              C  mov b32 $r11 $r10
00000447: 8a fc 47 02           mov $r10 0x247fc
0000044b: 7e 10 00 00           lcall 0x10
0000044f: 8a fc 4a 02           mov $r10 0x24afc
00000453: 0b 03                 mov $r11 0x3
00000455: 7e 10 00 00           lcall 0x10
00000459: f8 00                 ret

0000045b: f9 72              C  mpush $r7
0000045d: df 00 00 00 40        mov $r15 0x40000000
00000462: 89 00 14 02           mov $r9 0x21400
00000466: fa 9f 00              iowr I[$r9] $r15
00000469: b3 ad 02 09 01        bra b32 $r10 0x2 ne 0x572
0000046e: 8f b4 12 00           mov $r15 0x12b4
00000472: bf f9                 ld b32 $r9 D[$r15]
00000474: b3 9d 01 81 00        bra b32 $r9 0x1 ne 0x4f5
00000479: 3e 81 05 00           lbra 0x581
0000047d: b2 f7               B mov b32 $r7 $r15
0000047f: bd 44                 clear b32 $r4
00000481: 82 00 42 02           mov $r2 0x24200
00000485: 43 a4 00              mov $r3 0xa4
00000488: 85 00 10 00           mov $r5 0x1000
0000048c: 06 02                 mov $r6 0x2
0000048e: 95 39 02            B shr b32 $r9 $r3 0x2
00000491: 94 9f 02              shl b32 $r15 $r9 0x2
00000494: 89 00 10 00           mov $r9 0x1000
00000498: bc f9 f0              add b32 $r15 $r15 $r9
0000049b: 90 39 04              add b32 $r9 $r3 0x4
0000049e: b6 95 02              shr b32 $r9 0x2
000004a1: 94 91 02              shl b32 $r1 $r9 0x2
000004a4: 89 00 10 00           mov $r9 0x1000
000004a8: bc 19 10              add b32 $r1 $r1 $r9
000004ab: 98 59 01              ld b32 $r9 D[$r5+0x4]
000004ae: b2 2a                 mov b32 $r10 $r2
000004b0: 90 33 08              add b32 $r3 $r3 0x8
000004b3: f0 94 1f              and $r9 0x1f
000004b6: a6 49                 cmp b32 $r4 $r9
000004b8: f5 18 c9 00           bra ae 0x581
000004bc: bf f9                 ld b32 $r9 D[$r15]
000004be: 98 50 26              ld b32 $r0 D[$r5+0x98]
000004c1: bf 11                 ld b32 $r1 D[$r1]
000004c3: a0 76                 st b32 D[$r7] $r6
000004c5: 90 44 01              add b32 $r4 $r4 0x1
000004c8: f1 04 ff ff           and $r0 0xffff
000004cc: bc 09 00              add b32 $r0 $r0 $r9
000004cf: b2 0b                 mov b32 $r11 $r0
000004d1: 7e 10 00 00           lcall 0x10
000004d5: b8 2a 00 01 00        add b32 $r10 $r2 0x100
000004da: b2 0b                 mov b32 $r11 $r0
000004dc: 7e 10 00 00           lcall 0x10
000004e0: b8 2a 00 02 00        add b32 $r10 $r2 0x200
000004e5: b6 15 02              shr b32 $r1 0x2
000004e8: 90 22 04              add b32 $r2 $r2 0x4
000004eb: b2 1b                 mov b32 $r11 $r1
000004ed: 7e 10 00 00           lcall 0x10
000004f1: 3e 8e 04 00           lbra 0x48e
000004f5: b2 f7               B mov b32 $r7 $r15
000004f7: bd 44                 clear b32 $r4
000004f9: 82 00 42 02           mov $r2 0x24200
000004fd: 43 04 01              mov $r3 0x104
00000500: 85 00 10 00           mov $r5 0x1000
00000504: 06 01                 mov $r6 0x1
00000506: 95 39 02            B shr b32 $r9 $r3 0x2
00000509: 94 9f 02              shl b32 $r15 $r9 0x2
0000050c: 89 00 10 00           mov $r9 0x1000
00000510: bc f9 f0              add b32 $r15 $r15 $r9
00000513: 90 39 04              add b32 $r9 $r3 0x4
00000516: b6 95 02              shr b32 $r9 0x2
00000519: 94 91 02              shl b32 $r1 $r9 0x2
0000051c: 89 00 10 00           mov $r9 0x1000
00000520: bc 19 10              add b32 $r1 $r1 $r9
00000523: 98 59 01              ld b32 $r9 D[$r5+0x4]
00000526: b2 2a                 mov b32 $r10 $r2
00000528: 90 33 08              add b32 $r3 $r3 0x8
0000052b: f0 94 1f              and $r9 0x1f
0000052e: a6 49                 cmp b32 $r4 $r9
00000530: f4 18 51              bra ae 0x581
00000533: 98 50 03              ld b32 $r0 D[$r5+0xc]
00000536: bf ff                 ld b32 $r15 D[$r15]
00000538: bf 11                 ld b32 $r1 D[$r1]
0000053a: a0 76                 st b32 D[$r7] $r6
0000053c: e4 09 ff ff           and $r9 $r0 0xffff
00000540: c7 00 f0              extr $r0 $r0 0x10:0x17
00000543: bc 09 00              add b32 $r0 $r0 $r9
00000546: bc 0f 00              add b32 $r0 $r0 $r15
00000549: b2 0b                 mov b32 $r11 $r0
0000054b: 7e 10 00 00           lcall 0x10
0000054f: b8 2a 00 01 00        add b32 $r10 $r2 0x100
00000554: b2 0b                 mov b32 $r11 $r0
00000556: 7e 10 00 00           lcall 0x10
0000055a: b8 2a 00 02 00        add b32 $r10 $r2 0x200
0000055f: b6 15 02              shr b32 $r1 0x2
00000562: 90 44 01              add b32 $r4 $r4 0x1
00000565: b2 1b                 mov b32 $r11 $r1
00000567: 90 22 04              add b32 $r2 $r2 0x4
0000056a: 7e 10 00 00           lcall 0x10
0000056e: 3e 06 05 00           lbra 0x506
00000572: b3 a4 04 0f         B bra b32 $r10 0x4 ne 0x581
00000576: 8f b4 12 00           mov $r15 0x12b4
0000057a: bf f9                 ld b32 $r9 D[$r15]
0000057c: b3 9d 02 01 ff        bra b32 $r9 0x2 ne 0x47d
00000581: df 00 00 00 40      B mov $r15 0x40000000
00000586: 89 00 1a 02           mov $r9 0x21a00
0000058a: fa 9f 00              iowr I[$r9] $r15
0000058d: fb 71                 mpopret $r7
0000058f: f0 a4 0f              and $r10 0xf
00000592: 89 00 ac 01           mov $r9 0x1ac00
00000596: fa 9a 00              iowr I[$r9] $r10
00000599: f8 00                 ret

0000059b: 92 aa 01           C  sub b32 $r10 $r10 0x1
0000059e: b0 a6 01              cmp b32 $r10 0x1
000005a1: f4 0c 0b              bra a 0x5ac
000005a4: 0a 0c                 mov $r10 0xc
000005a6: bd b4                 clear b32 $r11
000005a8: 7e c4 00 00           lcall 0xc4
000005ac: f8 00               B ret

000005ae: b3 a0 02 08        C  bra b32 $r10 0x2 e 0x5b6
000005b2: b3 a4 04 0c           bra b32 $r10 0x4 ne 0x5be
000005b6: 0a 0a               B mov $r10 0xa
000005b8: bd b4                 clear b32 $r11
000005ba: 7e c4 00 00           lcall 0xc4
000005be: f8 00               B ret

000005c0: 8e 00 06 02        C  mov $r14 0x20600
000005c4: bd f4                 clear b32 $r15
000005c6: ff ef 9f              iord $r9 I[$r14+$r15*0x4]
000005c9: b3 90 00 0f           bra b32 $r9 0x0 e 0x5d8
000005cd: b3 a4 18 12           bra b32 $r10 0x18 ne 0x5df
000005d1: ff ef 9f              iord $r9 I[$r14+$r15*0x4]
000005d4: b3 94 17 0b           bra b32 $r9 0x17 ne 0x5df
000005d8: 89 00 06 02         B mov $r9 0x20600
000005dc: fa 9a 00              iowr I[$r9] $r10
000005df: 09 01               B mov $r9 0x1
000005e1: 8f 00 07 03           mov $r15 0x30700
000005e5: fa f9 00              iowr I[$r15] $r9
000005e8: 92 a9 48              sub b32 $r9 $r10 0x48
000005eb: b0 96 01              cmp b32 $r9 0x1
000005ee: f4 0d 07              bra be 0x5f5
000005f1: b3 a4 24 08           bra b32 $r10 0x24 ne 0x5f9
000005f5: f8 02               B exit
000005f7: f8 00                 ret
000005f9: 8e 00 06 03         B mov $r14 0x30600
000005fd: bd f4                 clear b32 $r15
000005ff: ff ef 9f            B iord $r9 I[$r14+$r15*0x4]
00000602: f0 94 01              and $r9 0x1
00000605: b3 90 01 fa           bra b32 $r9 0x1 e 0x5ff
00000609: f8 00                 ret

0000060b: 0f 02              C  mov $r15 0x2
0000060d: 89 00 12 02           mov $r9 0x21200
00000611: fa 9f 00              iowr I[$r9] $r15
00000614: 8e 70 13 00           mov $r14 0x1370
00000618: 8d 6c 13 00           mov $r13 0x136c
0000061c: bf ef                 ld b32 $r15 D[$r14]
0000061e: bf d9                 ld b32 $r9 D[$r13]
00000620: fd 9f 06              xor $r9 $r15
00000623: f0 94 07              and $r9 0x7
00000626: f4 1b 1c              bra ne 0x642
00000629: bf ef                 ld b32 $r15 D[$r14]
0000062b: bf d9                 ld b32 $r9 D[$r13]
0000062d: c7 ff 03              extr $r15 $r15 0x3:0x3
00000630: c7 99 03              extr $r9 $r9 0x3:0x3
00000633: a6 f9                 cmp b32 $r15 $r9
00000635: f4 0b 0d              bra e 0x642
00000638: 0a 10                 mov $r10 0x10
0000063a: 7e c0 05 00           lcall 0x5c0
0000063e: 3e 76 06 00           lbra 0x676
00000642: 8d 70 13 00         B mov $r13 0x1370
00000646: bf d9                 ld b32 $r9 D[$r13]
00000648: bf df                 ld b32 $r15 D[$r13]
0000064a: bf de                 ld b32 $r14 D[$r13]
0000064c: 8c 2c 13 00           mov $r12 0x132c
00000650: f0 94 07              and $r9 0x7
00000653: b6 94 03              shl b32 $r9 0x3
00000656: 90 ee 01              add b32 $r14 $r14 0x1
00000659: bc 9c 90              add b32 $r9 $r9 $r12
0000065c: a0 9a                 st b32 D[$r9] $r10
0000065e: a0 de                 st b32 D[$r13] $r14
00000660: bf de                 ld b32 $r14 D[$r13]
00000662: f0 f4 07              and $r15 0x7
00000665: bc ff f0              add b32 $r15 $r15 $r15
00000668: 90 ff 01              add b32 $r15 $r15 0x1
0000066b: bc cb f9              st b32 D[$r12+$r15*0x4] $r11
0000066e: b3 e4 10 08           bra b32 $r14 0x10 ne 0x676
00000672: bd 94                 clear b32 $r9
00000674: a0 d9                 st b32 D[$r13] $r9
00000676: 0f 02               B mov $r15 0x2
00000678: 89 00 18 02           mov $r9 0x21800
0000067c: fa 9f 00              iowr I[$r9] $r15
0000067f: f8 00                 ret

00000681: 0f 04              C  mov $r15 0x4
00000683: 89 00 12 02           mov $r9 0x21200
00000687: fa 9f 00              iowr I[$r9] $r15
0000068a: 8e b8 13 00           mov $r14 0x13b8
0000068e: 8d b4 13 00           mov $r13 0x13b4
00000692: bf ef                 ld b32 $r15 D[$r14]
00000694: bf d9                 ld b32 $r9 D[$r13]
00000696: fd 9f 06              xor $r9 $r15
00000699: f0 94 07              and $r9 0x7
0000069c: f4 1b 1c              bra ne 0x6b8
0000069f: bf ef                 ld b32 $r15 D[$r14]
000006a1: bf d9                 ld b32 $r9 D[$r13]
000006a3: c7 ff 03              extr $r15 $r15 0x3:0x3
000006a6: c7 99 03              extr $r9 $r9 0x3:0x3
000006a9: a6 f9                 cmp b32 $r15 $r9
000006ab: f4 0b 0d              bra e 0x6b8
000006ae: 0a 12                 mov $r10 0x12
000006b0: 7e c0 05 00           lcall 0x5c0
000006b4: 3e ec 06 00           lbra 0x6ec
000006b8: 8d b8 13 00         B mov $r13 0x13b8
000006bc: bf d9                 ld b32 $r9 D[$r13]
000006be: bf df                 ld b32 $r15 D[$r13]
000006c0: bf de                 ld b32 $r14 D[$r13]
000006c2: 8c 74 13 00           mov $r12 0x1374
000006c6: f0 94 07              and $r9 0x7
000006c9: b6 94 03              shl b32 $r9 0x3
000006cc: 90 ee 01              add b32 $r14 $r14 0x1
000006cf: bc 9c 90              add b32 $r9 $r9 $r12
000006d2: a0 9a                 st b32 D[$r9] $r10
000006d4: a0 de                 st b32 D[$r13] $r14
000006d6: bf de                 ld b32 $r14 D[$r13]
000006d8: f0 f4 07              and $r15 0x7
000006db: bc ff f0              add b32 $r15 $r15 $r15
000006de: 90 ff 01              add b32 $r15 $r15 0x1
000006e1: bc cb f9              st b32 D[$r12+$r15*0x4] $r11
000006e4: b3 e4 10 08           bra b32 $r14 0x10 ne 0x6ec
000006e8: bd 94                 clear b32 $r9
000006ea: a0 d9                 st b32 D[$r13] $r9
000006ec: 0f 04               B mov $r15 0x4
000006ee: 89 00 18 02           mov $r9 0x21800
000006f2: fa 9f 00              iowr I[$r9] $r15
000006f5: f8 00                 ret

000006f7: bd 94              C  clear b32 $r9
000006f9: 8e 00 a4 01           mov $r14 0x1a400
000006fd: ff e9 ef              iord $r14 I[$r14+$r9*0x4]
00000700: 8f 00 a5 01           mov $r15 0x1a500
00000704: ff f9 ff              iord $r15 I[$r15+$r9*0x4]
00000707: 89 00 0e 02           mov $r9 0x20e00
0000070b: fa 9e 00              iowr I[$r9] $r14
0000070e: b8 99 00 01 00        add b32 $r9 $r9 0x100
00000713: fa 9f 00              iowr I[$r9] $r15
00000716: 0a 20                 mov $r10 0x20
00000718: b6 e5 1f              shr b32 $r14 0x1f
0000071b: b3 e4 01 26           bra b32 $r14 0x1 ne 0x741
0000071f: bd f4                 clear b32 $r15
00000721: 89 00 92 00           mov $r9 0x9200
00000725: ff 9f 9f              iord $r9 I[$r9+$r15*0x4]
00000728: 8f 00 0c 02           mov $r15 0x20c00
0000072c: fa f9 00              iowr I[$r15] $r9
0000072f: bd f4                 clear b32 $r15
00000731: 89 00 93 00           mov $r9 0x9300
00000735: ff 9f 9f              iord $r9 I[$r9+$r15*0x4]
00000738: 8f 00 0d 02           mov $r15 0x20d00
0000073c: fa f9 00              iowr I[$r15] $r9
0000073f: 0a 22                 mov $r10 0x22
00000741: 7e c0 05 00         B lcall 0x5c0
00000745: f8 00                 ret

00000747: 0a 24              C  mov $r10 0x24
00000749: 7e c0 05 00           lcall 0x5c0
0000074d: f8 02                 exit
0000074f: f8 00                 ret

00000751: 8f 00 00 01        C  mov $r15 0x10000
00000755: bd 94                 clear b32 $r9
00000757: ff f9 9f              iord $r9 I[$r15+$r9*0x4]
0000075a: fd 9f 04              and $r9 $r15
0000075d: f4 0b 09              bra e 0x766
00000760: 0a 21                 mov $r10 0x21
00000762: 7e c0 05 00           lcall 0x5c0
00000766: f8 00               B ret

00000768: bd f4              C  clear b32 $r15
0000076a: 89 00 90 00           mov $r9 0x9000
0000076e: ff 9f 9f              iord $r9 I[$r9+$r15*0x4]
00000771: c4 9a 01              and $r10 $r9 0x1
00000774: b3 a4 01 19           bra b32 $r10 0x1 ne 0x78d
00000778: c7 99 24              extr $r9 $r9 0x4:0x5
0000077b: b3 90 02 14           bra b32 $r9 0x2 e 0x78f
0000077f: b3 90 00 0e           bra b32 $r9 0x0 e 0x78d
00000783: 0a 50                 mov $r10 0x50
00000785: 7e c0 05 00           lcall 0x5c0
00000789: bd a4                 clear b32 $r10
0000078b: f8 00                 ret
0000078d: bd a4               B clear b32 $r10
0000078f: f8 00               B ret

00000791: f9 02              C  mpush $r0
00000793: b2 a0                 mov b32 $r0 $r10
00000795: 7e fb 00 00           lcall 0xfb
00000799: b3 00 05 20           bra b32 $r0 0x5 e 0x7b9
0000079d: b0 06 05              cmp b32 $r0 0x5
000007a0: f4 0c 0b              bra a 0x7ab
000007a3: b3 04 02 10           bra b32 $r0 0x2 ne 0x7b3
000007a7: 3e b9 07 00           lbra 0x7b9
000007ab: b3 00 06 0e         B bra b32 $r0 0x6 e 0x7b9
000007af: b3 00 07 0a           bra b32 $r0 0x7 e 0x7b9
000007b3: bd b4               B clear b32 $r11
000007b5: 3e c9 07 00           lbra 0x7c9
000007b9: c4 a9 03            B and $r9 $r10 0x3
000007bc: 94 9f 0c              shl b32 $r15 $r9 0xc
000007bf: b6 94 04              shl b32 $r9 0x4
000007c2: fd 9f 05              or $r9 $r15
000007c5: e5 9b 03 03           or $r11 $r9 0x303
000007c9: b3 a4 00 0e         B bra b32 $r10 0x0 ne 0x7d7
000007cd: 89 20 00 00           mov $r9 0x20
000007d1: bf 99                 ld b32 $r9 D[$r9]
000007d3: b3 94 00 0c           bra b32 $r9 0x0 ne 0x7df
000007d7: 8a 00 8b 02         B mov $r10 0x28b00
000007db: 7e 10 00 00           lcall 0x10
000007df: fb 01               B mpopret $r0

000007e1: f4 30 f8           C  add $sp -0x8
000007e4: 0f 10                 mov $r15 0x10
000007e6: f9 82                 mpush $r8
000007e8: 89 00 13 02           mov $r9 0x21300
000007ec: b2 a1                 mov b32 $r1 $r10
000007ee: b0 b1 0a              st b32 D[$sp+0x28] $r11
000007f1: b2 c2                 mov b32 $r2 $r12
000007f3: b0 d1 09              st b32 D[$sp+0x24] $r13
000007f6: fa 9f 00              iowr I[$r9] $r15
000007f9: 89 a4 14 00           mov $r9 0x14a4
000007fd: bf 99                 ld b32 $r9 D[$r9]
000007ff: 0f 01                 mov $r15 0x1
00000801: bc f9 94              shl b32 $r9 $r15 $r9
00000804: 92 90 01              sub b32 $r0 $r9 0x1
00000807: b3 a0 0d 08           bra b32 $r10 0xd e 0x80f
0000080b: b3 a4 0f 17           bra b32 $r10 0xf ne 0x822
0000080f: 0a 09               B mov $r10 0x9
00000811: 8b 00 00 08           mov $r11 0x80000
00000815: 7e c4 00 00           lcall 0xc4
00000819: 0a 0e                 mov $r10 0xe
0000081b: 4b 00 40              mov $r11 0x4000
0000081e: 3e 35 08 00           lbra 0x835
00000822: b3 a4 0e 1f         B bra b32 $r10 0xe ne 0x841
00000826: 8b 00 18 09           mov $r11 0x91800
0000082a: 0a 09                 mov $r10 0x9
0000082c: 7e c4 00 00           lcall 0xc4
00000830: b2 1a                 mov b32 $r10 $r1
00000832: 4b 00 02              mov $r11 0x200
00000835: 7e c4 00 00         B lcall 0xc4
00000839: b2 0b                 mov b32 $r11 $r0
0000083b: 0a 0d                 mov $r10 0xd
0000083d: 3e a6 08 00           lbra 0x8a6
00000841: b3 a4 16 25         B bra b32 $r10 0x16 ne 0x866
00000845: 0a 09                 mov $r10 0x9
00000847: 8b 00 00 24           mov $r11 0x240000
0000084b: 7e c4 00 00           lcall 0xc4
0000084f: 0a 0e                 mov $r10 0xe
00000851: 4b 00 40              mov $r11 0x4000
00000854: 7e c4 00 00           lcall 0xc4
00000858: 89 a8 14 00           mov $r9 0x14a8
0000085c: 0a 0d                 mov $r10 0xd
0000085e: bf 9b                 ld b32 $r11 D[$r9]
00000860: 05 03                 mov $r5 0x3
00000862: 3e 8f 08 00           lbra 0x88f
00000866: b3 a4 17 31         B bra b32 $r10 0x17 ne 0x897
0000086a: 89 b0 14 00           mov $r9 0x14b0
0000086e: bf 90                 ld b32 $r0 D[$r9]
00000870: 0a 09                 mov $r10 0x9
00000872: 8b 00 00 05           mov $r11 0x50000
00000876: 05 03                 mov $r5 0x3
00000878: bc f0 04              shl b32 $r0 $r15 $r0
0000087b: 7e c4 00 00           lcall 0xc4
0000087f: 0a 0e                 mov $r10 0xe
00000881: 4b 00 20              mov $r11 0x2000
00000884: 7e c4 00 00           lcall 0xc4
00000888: 92 00 01              sub b32 $r0 $r0 0x1
0000088b: 0a 0d                 mov $r10 0xd
0000088d: b2 0b                 mov b32 $r11 $r0
0000088f: 7e c4 00 00         B lcall 0xc4
00000893: 3e ac 08 00           lbra 0x8ac
00000897: b3 a0 14 0a         B bra b32 $r10 0x14 e 0x8a1
0000089b: bd 54                 clear b32 $r5
0000089d: 3e ac 08 00           lbra 0x8ac
000008a1: 0a 0e               B mov $r10 0xe
000008a3: 4b 00 02              mov $r11 0x200
000008a6: 7e c4 00 00         B lcall 0xc4
000008aa: 05 03                 mov $r5 0x3
000008ac: b4 a0 0a            B ld b32 $r10 D[$sp+0x28]
000008af: 7e 9b 05 00           lcall 0x59b
000008b3: b3 10 14 0c           bra b32 $r1 0x14 e 0x8bf
000008b7: b2 21                 mov b32 $r1 $r2
000008b9: bd 04                 clear b32 $r0
000008bb: 3e 5f 09 00           lbra 0x95f
000008bf: b2 27               B mov b32 $r7 $r2
000008c1: bd 64                 clear b32 $r6
000008c3: 3e 43 09 00           lbra 0x943
000008c7: bf 79               B ld b32 $r9 D[$r7]
000008c9: bd 44                 clear b32 $r4
000008cb: ff 59 85              or $r8 $r5 $r9
000008ce: 89 00 08 02         B mov $r9 0x20800
000008d2: fa 94 00              iowr I[$r9] $r4
000008d5: bd 34                 clear b32 $r3
000008d7: 94 49 02              shl b32 $r9 $r4 0x2
000008da: bd 24                 clear b32 $r2
000008dc: c4 90 1f              and $r0 $r9 0x1f
000008df: 95 91 05              shr b32 $r1 $r9 0x5
000008e2: b0 16 01            B cmp b32 $r1 0x1
000008e5: f4 0d 0d              bra be 0x8f2
000008e8: 0a 37                 mov $r10 0x37
000008ea: 7e c0 05 00           lcall 0x5c0
000008ee: 3e 11 09 00           lbra 0x911
000008f2: 8f e0 13 00         B mov $r15 0x13e0
000008f6: bc f1 98              ld b32 $r9 D[$r15+$r1*0x4]
000008f9: bb 90 05              shr b32 $r9 $r0
000008fc: 90 00 01              add b32 $r0 $r0 0x1
000008ff: f0 94 01              and $r9 0x1
00000902: bb 93 04              shl b32 $r9 $r3
00000905: fd 29 05              or $r2 $r9
00000908: b3 04 20 09           bra b32 $r0 0x20 ne 0x911
0000090c: 90 11 01              add b32 $r1 $r1 0x1
0000090f: bd 04                 clear b32 $r0
00000911: 90 33 01            B add b32 $r3 $r3 0x1
00000914: b3 34 04 ce           bra b32 $r3 0x4 ne 0x8e2
00000918: b3 20 00 1e           bra b32 $r2 0x0 e 0x936
0000091c: b2 2b                 mov b32 $r11 $r2
0000091e: 0a 0d                 mov $r10 0xd
00000920: 7e c4 00 00           lcall 0xc4
00000924: 0a 09                 mov $r10 0x9
00000926: 94 4b 0d              shl b32 $r11 $r4 0xd
00000929: b6 b5 02              shr b32 $r11 0x2
0000092c: 7e c4 00 00           lcall 0xc4
00000930: b2 8a                 mov b32 $r10 $r8
00000932: 7e 7a 00 00           lcall 0x7a
00000936: 90 44 01            B add b32 $r4 $r4 0x1
00000939: b3 44 0c 95           bra b32 $r4 0xc ne 0x8ce
0000093d: 90 66 01              add b32 $r6 $r6 0x1
00000940: 90 77 04              add b32 $r7 $r7 0x4
00000943: b4 90 09            B ld b32 $r9 D[$sp+0x24]
00000946: a6 69                 cmp b32 $r6 $r9
00000948: f5 08 7f ff           bra b 0x8c7
0000094c: 3e 67 09 00           lbra 0x967
00000950: bf 1a               B ld b32 $r10 D[$r1]
00000952: 90 00 01              add b32 $r0 $r0 0x1
00000955: 90 11 04              add b32 $r1 $r1 0x4
00000958: ff 5a a5              or $r10 $r5 $r10
0000095b: 7e 7a 00 00           lcall 0x7a
0000095f: b4 f0 09            B ld b32 $r15 D[$sp+0x24]
00000962: a6 0f                 cmp b32 $r0 $r15
00000964: f4 08 ec              bra b 0x950
00000967: b4 a0 0a            B ld b32 $r10 D[$sp+0x28]
0000096a: 7e ae 05 00           lcall 0x5ae
0000096e: 0f 10                 mov $r15 0x10
00000970: 89 00 19 02           mov $r9 0x21900
00000974: fa 9f 00              iowr I[$r9] $r15
00000977: fb 85 08              mpopaddret $r8 0x8

0000097a: f9 02              C  mpush $r0
0000097c: b2 a9                 mov b32 $r9 $r10
0000097e: 4a c8 03              mov $r10 0x3c8
00000981: b3 99 01 94 00        bra b32 $r9 0x1 e 0xa15
00000986: 4a 34 0d              mov $r10 0xd34
00000989: b3 99 02 8c 00        bra b32 $r9 0x2 e 0xa15
0000098e: 0a 30                 mov $r10 0x30
00000990: b3 99 0c 85 00        bra b32 $r9 0xc e 0xa15
00000995: 4a fc 00              mov $r10 0xfc
00000998: b3 90 1a 7d           bra b32 $r9 0x1a e 0xa15
0000099c: b3 99 1b 84 00        bra b32 $r9 0x1b e 0xa20
000009a1: b3 94 0d 4d           bra b32 $r9 0xd ne 0x9ee
000009a5: 89 a4 14 00           mov $r9 0x14a4
000009a9: bf 90                 ld b32 $r0 D[$r9]
000009ab: 4b 18 03              mov $r11 0x318
000009ae: b2 0a                 mov b32 $r10 $r0
000009b0: 7e ce 77 00           lcall 0x77ce
000009b4: 89 ac 14 00           mov $r9 0x14ac
000009b8: bf 9f                 ld b32 $r15 D[$r9]
000009ba: 89 b0 14 00           mov $r9 0x14b0
000009be: bf 9e                 ld b32 $r14 D[$r9]
000009c0: 94 09 03              shl b32 $r9 $r0 0x3
000009c3: bc 00 00              add b32 $r0 $r0 $r0
000009c6: bc 09 00              add b32 $r0 $r0 $r9
000009c9: bc ff 90              add b32 $r9 $r15 $r15
000009cc: bc 9f 90              add b32 $r9 $r9 $r15
000009cf: b6 94 02              shl b32 $r9 0x2
000009d2: bc 0a 00              add b32 $r0 $r0 $r10
000009d5: b6 04 02              shl b32 $r0 0x2
000009d8: 90 00 0c              add b32 $r0 $r0 0xc
000009db: bc 09 00              add b32 $r0 $r0 $r9
000009de: 94 e9 02              shl b32 $r9 $r14 0x2
000009e1: bc 9e 90              add b32 $r9 $r9 $r14
000009e4: b6 94 02              shl b32 $r9 0x2
000009e7: bc 09 a0              add b32 $r10 $r0 $r9
000009ea: 3e 11 0a 00           lbra 0xa11
000009ee: b3 94 0f 17         B bra b32 $r9 0xf ne 0xa05
000009f2: 89 a4 14 00           mov $r9 0x14a4
000009f6: bf 99                 ld b32 $r9 D[$r9]
000009f8: bc 99 f0              add b32 $r15 $r9 $r9
000009fb: bc f9 f0              add b32 $r15 $r15 $r9
000009fe: 94 fa 04              shl b32 $r10 $r15 0x4
00000a01: 3e 11 0a 00           lbra 0xa11
00000a05: 0a 40               B mov $r10 0x40
00000a07: 7e c0 05 00           lcall 0x5c0
00000a0b: bd a4                 clear b32 $r10
00000a0d: 3e 1e 0a 00           lbra 0xa1e
00000a11: b3 a0 00 0d         B bra b32 $r10 0x0 e 0xa1e
00000a15: 95 a9 08            B shr b32 $r9 $r10 0x8
00000a18: 90 99 01              add b32 $r9 $r9 0x1
00000a1b: 94 9a 08              shl b32 $r10 $r9 0x8
00000a1e: fb 01               B mpopret $r0
00000a20: 0a 08               B mov $r10 0x8
00000a22: 3e 15 0a 00           lbra 0xa15

00000a26: f9 32              C  mpush $r3
00000a28: 0f 01                 mov $r15 0x1
00000a2a: 89 00 15 02           mov $r9 0x21500
00000a2e: fa 9f 00              iowr I[$r9] $r15
00000a31: bd 14                 clear b32 $r1
00000a33: 80 00 28 50           mov $r0 0x502800
00000a37: 83 a0 14 00           mov $r3 0x14a0
00000a3b: d2 21 43 65 87        mov $r2 0x87654321
00000a40: 3e 57 0a 00           lbra 0xa57
00000a44: b2 0a               B mov b32 $r10 $r0
00000a46: 7e 97 02 00           lcall 0x297
00000a4a: a6 a2                 cmp b32 $r10 $r2
00000a4c: f4 1b f8              bra ne 0xa44
00000a4f: 90 11 01              add b32 $r1 $r1 0x1
00000a52: b8 00 00 80 00        add b32 $r0 $r0 0x8000
00000a57: bf 39               B ld b32 $r9 D[$r3]
00000a59: a6 19                 cmp b32 $r1 $r9
00000a5b: f4 08 e9              bra b 0xa44
00000a5e: 0f 01                 mov $r15 0x1
00000a60: 89 00 1b 02           mov $r9 0x21b00
00000a64: fa 9f 00              iowr I[$r9] $r15
00000a67: fb 31                 mpopret $r3

00000a69: 0f 02              C  mov $r15 0x2
00000a6b: 89 00 15 02           mov $r9 0x21500
00000a6f: fa 9f 00              iowr I[$r9] $r15
00000a72: da 08 58 82 00      B mov $r10 0x825808
00000a77: 7e 97 02 00           lcall 0x297
00000a7b: f0 a4 02              and $r10 0x2
00000a7e: f4 0b f4              bra e 0xa72
00000a81: 0f 02                 mov $r15 0x2
00000a83: 89 00 1b 02           mov $r9 0x21b00
00000a87: fa 9f 00              iowr I[$r9] $r15
00000a8a: f8 00                 ret
00000a8c: f8 00                 ret

00000a8e: f9 62              C  mpush $r6
00000a90: bd 24                 clear b32 $r2
00000a92: 81 08 26 50           mov $r1 0x502608
00000a96: bd 04                 clear b32 $r0
00000a98: 84 a0 14 00           mov $r4 0x14a0
00000a9c: bd 34                 clear b32 $r3
00000a9e: 3e be 0a 00           lbra 0xabe
00000aa2: 7e 97 02 00         B lcall 0x297
00000aa6: 8f c4 14 00           mov $r15 0x14c4
00000aaa: bc 0f 90              add b32 $r9 $r0 $r15
00000aad: f0 a4 1f              and $r10 0x1f
00000ab0: 8f f4 14 00           mov $r15 0x14f4
00000ab4: a0 9a                 st b32 D[$r9] $r10
00000ab6: 90 22 01              add b32 $r2 $r2 0x1
00000ab9: bc 0f 90              add b32 $r9 $r0 $r15
00000abc: a0 93                 st b32 D[$r9] $r3
00000abe: bf 49               B ld b32 $r9 D[$r4]
00000ac0: b2 1a                 mov b32 $r10 $r1
00000ac2: 90 00 04              add b32 $r0 $r0 0x4
00000ac5: b8 11 00 80 00        add b32 $r1 $r1 0x8000
00000aca: a6 29                 cmp b32 $r2 $r9
00000acc: f4 08 d6              bra b 0xaa2
00000acf: 85 f8 14 00           mov $r5 0x14f8
00000ad3: bd 34                 clear b32 $r3
00000ad5: b2 52                 mov b32 $r2 $r5
00000ad7: 81 3c 0c 50           mov $r1 0x500c3c
00000adb: 84 a0 14 00           mov $r4 0x14a0
00000adf: 3e 07 0b 00           lbra 0xb07
00000ae3: b2 0a               B mov b32 $r10 $r0
00000ae5: 90 00 04              add b32 $r0 $r0 0x4
00000ae8: 7e 97 02 00           lcall 0x297
00000aec: 33 a0 00 0b           bra b8 $r10 0x0 e 0xaf7
00000af0: bf 29                 ld b32 $r9 D[$r2]
00000af2: 90 99 01              add b32 $r9 $r9 0x1
00000af5: a0 29                 st b32 D[$r2] $r9
00000af7: a6 01               B cmp b32 $r0 $r1
00000af9: f4 1b ea              bra ne 0xae3
00000afc: 90 33 01              add b32 $r3 $r3 0x1
00000aff: b8 11 00 80 00        add b32 $r1 $r1 0x8000
00000b04: 90 22 04              add b32 $r2 $r2 0x4
00000b07: bf 49               B ld b32 $r9 D[$r4]
00000b09: a6 39                 cmp b32 $r3 $r9
00000b0b: f4 08 11              bra b 0xb1c
00000b0e: bd 14                 clear b32 $r1
00000b10: 84 30 0c 50           mov $r4 0x500c30
00000b14: 86 a0 14 00           mov $r6 0x14a0
00000b18: 3e 62 0b 00           lbra 0xb62
00000b1c: 92 10 0c            B sub b32 $r0 $r1 0xc
00000b1f: 3e e3 0a 00           lbra 0xae3
00000b23: b2 3a               B mov b32 $r10 $r3
00000b25: 7e 97 02 00           lcall 0x297
00000b29: c4 a9 ff              and $r9 $r10 0xff
00000b2c: f4 0b 19              bra e 0xb45
00000b2f: b2 9a                 mov b32 $r10 $r9
00000b31: bd f4                 clear b32 $r15
00000b33: 92 a9 01            B sub b32 $r9 $r10 0x1
00000b36: 90 ff 01              add b32 $r15 $r15 0x1
00000b39: fd a9 04              and $r10 $r9
00000b3c: f4 1b f7              bra ne 0xb33
00000b3f: a0 0f                 st b32 D[$r0] $r15
00000b41: 3e 47 0b 00           lbra 0xb47
00000b45: a0 09               B st b32 D[$r0] $r9
00000b47: 90 22 01            B add b32 $r2 $r2 0x1
00000b4a: 90 00 04              add b32 $r0 $r0 0x4
00000b4d: 90 33 04              add b32 $r3 $r3 0x4
00000b50: bf 59               B ld b32 $r9 D[$r5]
00000b52: a6 29                 cmp b32 $r2 $r9
00000b54: f4 08 cf              bra b 0xb23
00000b57: 90 11 01              add b32 $r1 $r1 0x1
00000b5a: b8 44 00 80 00        add b32 $r4 $r4 0x8000
00000b5f: 90 55 04              add b32 $r5 $r5 0x4
00000b62: bf 69               B ld b32 $r9 D[$r6]
00000b64: a6 19                 cmp b32 $r1 $r9
00000b66: f4 18 1b              bra ae 0xb81
00000b69: bc 11 90              add b32 $r9 $r1 $r1
00000b6c: bc 91 90              add b32 $r9 $r9 $r1
00000b6f: b2 43                 mov b32 $r3 $r4
00000b71: 94 90 02              shl b32 $r0 $r9 0x2
00000b74: bd 24                 clear b32 $r2
00000b76: 89 28 15 00           mov $r9 0x1528
00000b7a: bc 09 00              add b32 $r0 $r0 $r9
00000b7d: 3e 50 0b 00           lbra 0xb50
00000b81: bd f4               B clear b32 $r15
00000b83: 89 b4 12 00           mov $r9 0x12b4
00000b87: a0 9f                 st b32 D[$r9] $r15
00000b89: fb 61                 mpopret $r6

00000b8b: f9 12              C  mpush $r1
00000b8d: 4f 80 00              mov $r15 0x80
00000b90: 89 00 14 02           mov $r9 0x21400
00000b94: fa 9f 00              iowr I[$r9] $r15
00000b97: 8a 00 39 02           mov $r10 0x23900
00000b9b: 7e 44 00 00           lcall 0x44
00000b9f: df 00 00 00 ff        mov $r15 0xff000000
00000ba4: b2 a9                 mov b32 $r9 $r10
00000ba6: fd 9f 04              and $r9 $r15
00000ba9: f0 95 05              or $r9 0x5
00000bac: 80 18 00 00           mov $r0 0x18
00000bb0: b2 9b                 mov b32 $r11 $r9
00000bb2: a0 0a                 st b32 D[$r0] $r10
00000bb4: 81 1c 00 00           mov $r1 0x1c
00000bb8: 8a 00 39 02           mov $r10 0x23900
00000bbc: a0 19                 st b32 D[$r1] $r9
00000bbe: 7e 10 00 00           lcall 0x10
00000bc2: 8a a8 9d 41           mov $r10 0x419da8
00000bc6: 0b 11                 mov $r11 0x11
00000bc8: bd c4                 clear b32 $r12
00000bca: 0d 01                 mov $r13 0x1
00000bcc: 7e 2f 02 00           lcall 0x22f
00000bd0: 8a ac a0 41           mov $r10 0x41a0ac
00000bd4: 0b 3f                 mov $r11 0x3f
00000bd6: bd c4                 clear b32 $r12
00000bd8: 0d 01                 mov $r13 0x1
00000bda: 7e 2f 02 00           lcall 0x22f
00000bde: bd c4                 clear b32 $r12
00000be0: 0d 01                 mov $r13 0x1
00000be2: 8a 28 a9 41           mov $r10 0x41a928
00000be6: 0b 11                 mov $r11 0x11
00000be8: 7e 2f 02 00           lcall 0x22f
00000bec: 0b 11                 mov $r11 0x11
00000bee: 8a fc 4a 02           mov $r10 0x24afc
00000bf2: 7e 10 00 00           lcall 0x10
00000bf6: 8a 00 39 02           mov $r10 0x23900
00000bfa: 7e 44 00 00           lcall 0x44
00000bfe: d9 0f 00 00 ff        mov $r9 0xff00000f
00000c03: a0 0a                 st b32 D[$r0] $r10
00000c05: b2 ab                 mov b32 $r11 $r10
00000c07: 8a 00 39 02           mov $r10 0x23900
00000c0b: fd b9 04              and $r11 $r9
00000c0e: f0 b5 50              or $r11 0x50
00000c11: a0 1b                 st b32 D[$r1] $r11
00000c13: 7e 10 00 00           lcall 0x10
00000c17: fb 11                 mpopret $r1

00000c19: 4f 00 02           C  mov $r15 0x200
00000c1c: 89 00 14 02           mov $r9 0x21400
00000c20: fa 9f 00              iowr I[$r9] $r15
00000c23: 8a 08 ac 10           mov $r10 0x10ac08
00000c27: 7e 97 02 00           lcall 0x297
00000c2b: 89 00 00 10           mov $r9 0x100000
00000c2f: fd a9 04              and $r10 $r9
00000c32: f4 0b 0b              bra e 0xc3d
00000c35: 0f 01                 mov $r15 0x1
00000c37: 89 10 14 00           mov $r9 0x1410
00000c3b: a0 9f                 st b32 D[$r9] $r15
00000c3d: 0f 01               B mov $r15 0x1
00000c3f: 89 00 00 02           mov $r9 0x20000
00000c43: fa 9f 00              iowr I[$r9] $r15
00000c46: 4f 00 02              mov $r15 0x200
00000c49: b8 99 00 1a 00        add b32 $r9 $r9 0x1a00
00000c4e: fa 9f 00              iowr I[$r9] $r15
00000c51: f8 00                 ret

00000c53: b0 a6 00           C  cmp b32 $r10 0x0
00000c56: f0 ec 0b              xbit $r14 $flags z
00000c59: f0 e6 01              xor $r14 0x1
00000c5c: b3 b4 01 0e           bra b32 $r11 0x1 ne 0xc6a
00000c60: 94 ef 04              shl b32 $r15 $r14 0x4
00000c63: 89 00 23 02           mov $r9 0x22300
00000c67: fa 9f 00              iowr I[$r9] $r15
00000c6a: b3 c4 01 0f         B bra b32 $r12 0x1 ne 0xc79
00000c6e: 94 eb 04              shl b32 $r11 $r14 0x4
00000c71: 8a 8c a8 41           mov $r10 0x41a88c
00000c75: 7e 37 02 00           lcall 0x237
00000c79: f8 00               B ret

00000c7b: b2 be              C  mov b32 $r14 $r11
00000c7d: b2 cd                 mov b32 $r13 $r12
00000c7f: 0f 20                 mov $r15 0x20
00000c81: 89 00 14 02           mov $r9 0x21400
00000c85: fa 9f 00              iowr I[$r9] $r15
00000c88: b2 ab                 mov b32 $r11 $r10
00000c8a: b2 ec                 mov b32 $r12 $r14
00000c8c: bd a4                 clear b32 $r10
00000c8e: 7e 53 0c 00           lcall 0xc53
00000c92: 0f 20                 mov $r15 0x20
00000c94: 89 00 1a 02           mov $r9 0x21a00
00000c98: fa 9f 00              iowr I[$r9] $r15
00000c9b: f8 00                 ret

00000c9d: 8f 00 00 02        C  mov $r15 0x20000
00000ca1: 89 00 14 02           mov $r9 0x21400
00000ca5: fa 9f 00              iowr I[$r9] $r15
00000ca8: 8e 00 00 01           mov $r14 0x10000
00000cac: bd f4                 clear b32 $r15
00000cae: ff ef 9f            B iord $r9 I[$r14+$r15*0x4]
00000cb1: f1 94 00 02           and $r9 0x200
00000cb5: f4 0b f9              bra e 0xcae
00000cb8: 8f 00 00 02           mov $r15 0x20000
00000cbc: 89 00 1a 02           mov $r9 0x21a00
00000cc0: fa 9f 00              iowr I[$r9] $r15
00000cc3: f8 00                 ret

00000cc5: f9 12              C  mpush $r1
00000cc7: b2 a1                 mov b32 $r1 $r10
00000cc9: b2 b0                 mov b32 $r0 $r11
00000ccb: 8a 00 05 01           mov $r10 0x10500
00000ccf: bd b4                 clear b32 $r11
00000cd1: 7e 10 00 00           lcall 0x10
00000cd5: 8a 04 05 01           mov $r10 0x10504
00000cd9: bd b4                 clear b32 $r11
00000cdb: 7e 10 00 00           lcall 0x10
00000cdf: b2 0b                 mov b32 $r11 $r0
00000ce1: 8a 00 a5 41           mov $r10 0x41a500
00000ce5: 7e 37 02 00           lcall 0x237
00000ce9: b2 1b                 mov b32 $r11 $r1
00000ceb: 8a 04 a5 41           mov $r10 0x41a504
00000cef: 7e 37 02 00           lcall 0x237
00000cf3: fb 11                 mpopret $r1

00000cf5: b2 be              C  mov b32 $r14 $r11
00000cf7: b2 cd                 mov b32 $r13 $r12
00000cf9: 0f 10                 mov $r15 0x10
00000cfb: 89 00 14 02           mov $r9 0x21400
00000cff: fa 9f 00              iowr I[$r9] $r15
00000d02: b2 ab                 mov b32 $r11 $r10
00000d04: b2 ec                 mov b32 $r12 $r14
00000d06: 0a 01                 mov $r10 0x1
00000d08: 7e 53 0c 00           lcall 0xc53
00000d0c: 0f 10                 mov $r15 0x10
00000d0e: 89 00 1a 02           mov $r9 0x21a00
00000d12: fa 9f 00              iowr I[$r9] $r15
00000d15: f8 00                 ret

00000d17: bd f4              C  clear b32 $r15
00000d19: 89 00 91 01           mov $r9 0x19100
00000d1d: ff 9f 9f              iord $r9 I[$r9+$r15*0x4]
00000d20: f0 94 03              and $r9 0x3
00000d23: f4 0b 6c              bra e 0xd8f
00000d26: b3 b4 00 12           bra b32 $r11 0x0 ne 0xd38
00000d2a: 89 c4 13 00           mov $r9 0x13c4
00000d2e: 8f 00 05 02           mov $r15 0x20500
00000d32: bf 9e                 ld b32 $r14 D[$r9]
00000d34: 3e 4e 0d 00           lbra 0xd4e
00000d38: b3 b0 01 0c         B bra b32 $r11 0x1 e 0xd44
00000d3c: bd f4                 clear b32 $r15
00000d3e: bd e4                 clear b32 $r14
00000d40: 3e 4e 0d 00           lbra 0xd4e
00000d44: 89 c8 13 00         B mov $r9 0x13c8
00000d48: bf 9e                 ld b32 $r14 D[$r9]
00000d4a: 8f 00 08 02           mov $r15 0x20800
00000d4e: bd 94               B clear b32 $r9
00000d50: ff f9 9f              iord $r9 I[$r15+$r9*0x4]
00000d53: b3 90 0e 24           bra b32 $r9 0xe e 0xd77
00000d57: b3 e0 00 22           bra b32 $r14 0x0 e 0xd79
00000d5b: fa fa 00              iowr I[$r15] $r10
00000d5e: bd d4                 clear b32 $r13
00000d60: ff fd 9f            B iord $r9 I[$r15+$r13*0x4]
00000d63: b3 90 00 0b           bra b32 $r9 0x0 e 0xd6e
00000d67: ff fd 9f              iord $r9 I[$r15+$r13*0x4]
00000d6a: b3 94 0e f6           bra b32 $r9 0xe ne 0xd60
00000d6e: bd 94               B clear b32 $r9
00000d70: ff f9 9f              iord $r9 I[$r15+$r9*0x4]
00000d73: b3 94 0e 06           bra b32 $r9 0xe ne 0xd79
00000d77: bd e4               B clear b32 $r14
00000d79: b3 b4 00 0c         B bra b32 $r11 0x0 ne 0xd85
00000d7d: 89 c4 13 00           mov $r9 0x13c4
00000d81: a0 9e                 st b32 D[$r9] $r14
00000d83: f8 00                 ret
00000d85: b3 b4 01 0a         B bra b32 $r11 0x1 ne 0xd8f
00000d89: 89 c8 13 00           mov $r9 0x13c8
00000d8d: a0 9e                 st b32 D[$r9] $r14
00000d8f: f8 00               B ret

00000d91: f9 52              C  mpush $r5
00000d93: df 00 00 00 10        mov $r15 0x10000000
00000d98: 89 00 14 02           mov $r9 0x21400
00000d9c: fa 9f 00              iowr I[$r9] $r15
00000d9f: b3 a0 00 4b           bra b32 $r10 0x0 e 0xdea
00000da3: 84 c8 14 00           mov $r4 0x14c8
00000da7: bd 34                 clear b32 $r3
00000da9: 82 40 43 50           mov $r2 0x504340
00000dad: 85 a0 14 00           mov $r5 0x14a0
00000db1: 3e db 0d 00           lbra 0xddb
00000db5: 90 00 01            B add b32 $r0 $r0 0x1
00000db8: bd c4                 clear b32 $r12
00000dba: b2 bd                 mov b32 $r13 $r11
00000dbc: 7e 2f 02 00           lcall 0x22f
00000dc0: bf 49               B ld b32 $r9 D[$r4]
00000dc2: b2 1a                 mov b32 $r10 $r1
00000dc4: 0b 01                 mov $r11 0x1
00000dc6: b8 11 00 08 00        add b32 $r1 $r1 0x800
00000dcb: a6 09                 cmp b32 $r0 $r9
00000dcd: f4 08 e8              bra b 0xdb5
00000dd0: bc 3b 30              add b32 $r3 $r3 $r11
00000dd3: b8 22 00 80 00        add b32 $r2 $r2 0x8000
00000dd8: 90 44 04              add b32 $r4 $r4 0x4
00000ddb: bf 59               B ld b32 $r9 D[$r5]
00000ddd: a6 39                 cmp b32 $r3 $r9
00000ddf: f4 18 19              bra ae 0xdf8
00000de2: b2 21                 mov b32 $r1 $r2
00000de4: bd 04                 clear b32 $r0
00000de6: 3e c0 0d 00           lbra 0xdc0
00000dea: 0b 01               B mov $r11 0x1
00000dec: 8a 40 9b 41           mov $r10 0x419b40
00000df0: bd c4                 clear b32 $r12
00000df2: b2 bd                 mov b32 $r13 $r11
00000df4: 7e 2f 02 00           lcall 0x22f
00000df8: fb 51               B mpopret $r5
00000dfa: 89 00 de 02           mov $r9 0x2de00
00000dfe: fa 9b 00              iowr I[$r9] $r11
00000e01: 0f 01                 mov $r15 0x1
00000e03: 89 00 00 02           mov $r9 0x20000
00000e07: fa 9f 00              iowr I[$r9] $r15
00000e0a: f8 00                 ret

00000e0c: 8a 00 a8 1f        C  mov $r10 0x1fa800
00000e10: 7e 97 02 00           lcall 0x297
00000e14: f8 00                 ret

00000e16: f9 22              C  mpush $r2
00000e18: 49 00 10              mov $r9 0x1000
00000e1b: 8f 00 14 02           mov $r15 0x21400
00000e1f: fa f9 00              iowr I[$r15] $r9
00000e22: 7e 0c 0e 00           lcall 0xe0c
00000e26: f0 a4 10              and $r10 0x10
00000e29: f4 1b 11              bra ne 0xe3a
00000e2c: bd 14                 clear b32 $r1
00000e2e: 80 04 03 50           mov $r0 0x500304
00000e32: 82 a0 14 00           mov $r2 0x14a0
00000e36: 3e 66 0e 00           lbra 0xe66
00000e3a: 4f 00 10            B mov $r15 0x1000
00000e3d: 89 00 1a 02           mov $r9 0x21a00
00000e41: fa 9f 00              iowr I[$r9] $r15
00000e44: 0a 01                 mov $r10 0x1
00000e46: 3e 80 0e 00           lbra 0xe80
00000e4a: 7e 97 02 00         B lcall 0x297
00000e4e: 90 11 01              add b32 $r1 $r1 0x1
00000e51: f0 a4 01              and $r10 0x1
00000e54: b3 a4 01 12           bra b32 $r10 0x1 ne 0xe66
00000e58: 4f 00 10              mov $r15 0x1000
00000e5b: 89 00 1a 02           mov $r9 0x21a00
00000e5f: fa 9f 00              iowr I[$r9] $r15
00000e62: 3e 80 0e 00           lbra 0xe80
00000e66: bf 29               B ld b32 $r9 D[$r2]
00000e68: b2 0a                 mov b32 $r10 $r0
00000e6a: b8 00 00 80 00        add b32 $r0 $r0 0x8000
00000e6f: a6 19                 cmp b32 $r1 $r9
00000e71: f4 08 d9              bra b 0xe4a
00000e74: 4f 00 10              mov $r15 0x1000
00000e77: 89 00 1a 02           mov $r9 0x21a00
00000e7b: fa 9f 00              iowr I[$r9] $r15
00000e7e: bd a4                 clear b32 $r10
00000e80: fb 21               B mpopret $r2

00000e82: 0f 20              C  mov $r15 0x20
00000e84: 89 00 13 02           mov $r9 0x21300
00000e88: fa 9f 00              iowr I[$r9] $r15
00000e8b: 0f 04                 mov $r15 0x4
00000e8d: c4 ae 01              and $r14 $r10 0x1
00000e90: f4 0b 06              bra e 0xe96
00000e93: 4f 04 01              mov $r15 0x104
00000e96: c4 a9 02            B and $r9 $r10 0x2
00000e99: f4 0b 0b              bra e 0xea4
00000e9c: f1 f5 00 10           or $r15 0x1000
00000ea0: 3e ae 0e 00           lbra 0xeae
00000ea4: c4 a9 04            B and $r9 $r10 0x4
00000ea7: f4 0b 07              bra e 0xeae
00000eaa: f1 f5 00 20           or $r15 0x2000
00000eae: 89 00 02 03         B mov $r9 0x30200
00000eb2: fa 9f 00              iowr I[$r9] $r15
00000eb5: 0f 01                 mov $r15 0x1
00000eb7: 89 c0 12 00           mov $r9 0x12c0
00000ebb: a0 9f                 st b32 D[$r9] $r15
00000ebd: b3 e0 00 12           bra b32 $r14 0x0 e 0xecf
00000ec1: 7e 16 0e 00           lcall 0xe16
00000ec5: b3 a0 00 0a           bra b32 $r10 0x0 e 0xecf
00000ec9: 0a 19                 mov $r10 0x19
00000ecb: 7e c0 05 00           lcall 0x5c0
00000ecf: f8 00               B ret

00000ed1: 8e 00 21 02        C  mov $r14 0x22100
00000ed5: bd 94                 clear b32 $r9
00000ed7: ff e9 ff              iord $r15 I[$r14+$r9*0x4]
00000eda: c7 f9 08              extr $r9 $r15 0x8:0x8
00000edd: f4 0b 18              bra e 0xef5
00000ee0: 49 ff fe              mov $r9 -0x101
00000ee3: ff f9 94              and $r9 $r15 $r9
00000ee6: fa e9 00              iowr I[$r14] $r9
00000ee9: bd f4                 clear b32 $r15
00000eeb: ff ef 9f            B iord $r9 I[$r14+$r15*0x4]
00000eee: f1 94 00 01           and $r9 0x100
00000ef2: f4 1b f9              bra ne 0xeeb
00000ef5: f8 00               B ret

00000ef7: f9 02              C  mpush $r0
00000ef9: bd 94                 clear b32 $r9
00000efb: 8f 00 87 01           mov $r15 0x18700
00000eff: ff f9 ff              iord $r15 I[$r15+$r9*0x4]
00000f02: 89 d0 12 00           mov $r9 0x12d0
00000f06: c7 fe 90              extr $r14 $r15 0x10:0x14
00000f09: a0 9f                 st b32 D[$r9] $r15
00000f0b: 89 d4 12 00           mov $r9 0x12d4
00000f0f: 8a 00 c0 01           mov $r10 0x1c000
00000f13: a0 9e                 st b32 D[$r9] $r14
00000f15: bd b4                 clear b32 $r11
00000f17: 7e 10 00 00           lcall 0x10
00000f1b: bd b4                 clear b32 $r11
00000f1d: 8a 00 c1 01           mov $r10 0x1c100
00000f21: 7e 10 00 00           lcall 0x10
00000f25: 7e d1 0e 00           lcall 0xed1
00000f29: 8a 04 96 40           mov $r10 0x409604
00000f2d: 7e 97 02 00           lcall 0x297
00000f31: 89 a0 14 00           mov $r9 0x14a0
00000f35: f0 a4 1f              and $r10 0x1f
00000f38: a0 9a                 st b32 D[$r9] $r10
00000f3a: 8a 04 96 40           mov $r10 0x409604
00000f3e: 7e 97 02 00           lcall 0x297
00000f42: 89 a4 14 00           mov $r9 0x14a4
00000f46: c7 aa 90              extr $r10 $r10 0x10:0x14
00000f49: a0 9a                 st b32 D[$r9] $r10
00000f4b: 8a 3c 24 02           mov $r10 0x2243c
00000f4f: 7e 97 02 00           lcall 0x297
00000f53: b2 a0                 mov b32 $r0 $r10
00000f55: da 14 0c 82 00        mov $r10 0x820c14
00000f5a: 7e 97 02 00           lcall 0x297
00000f5e: f0 04 1f              and $r0 0x1f
00000f61: 09 01                 mov $r9 0x1
00000f63: bb 90 04              shl b32 $r9 $r0
00000f66: 92 99 01              sub b32 $r9 $r9 0x1
00000f69: bd e4                 clear b32 $r14
00000f6b: ff 9a f6              xor $r15 $r9 $r10
00000f6e: 89 a8 14 00           mov $r9 0x14a8
00000f72: a0 9f                 st b32 D[$r9] $r15
00000f74: 3e 80 0f 00           lbra 0xf80
00000f78: b2 9e               B mov b32 $r14 $r9
00000f7a: 92 f9 01              sub b32 $r9 $r15 0x1
00000f7d: fd f9 04              and $r15 $r9
00000f80: 90 e9 01            B add b32 $r9 $r14 0x1
00000f83: b3 f4 00 f5           bra b32 $r15 0x0 ne 0xf78
00000f87: 89 ac 14 00           mov $r9 0x14ac
00000f8b: 8a 6c 00 12           mov $r10 0x12006c
00000f8f: a0 9e                 st b32 D[$r9] $r14
00000f91: 7e 97 02 00           lcall 0x297
00000f95: 89 a0 14 00           mov $r9 0x14a0
00000f99: bf 9f                 ld b32 $r15 D[$r9]
00000f9b: f0 a4 1f              and $r10 0x1f
00000f9e: 89 b0 14 00           mov $r9 0x14b0
00000fa2: 00 01                 mov $r0 0x1
00000fa4: a0 9a                 st b32 D[$r9] $r10
00000fa6: bb 0f 04              shl b32 $r0 $r15
00000fa9: 8a 00 03 01           mov $r10 0x10300
00000fad: 92 00 01              sub b32 $r0 $r0 0x1
00000fb0: b2 0b                 mov b32 $r11 $r0
00000fb2: 7e 10 00 00           lcall 0x10
00000fb6: b2 0b                 mov b32 $r11 $r0
00000fb8: 8a 00 04 01           mov $r10 0x10400
00000fbc: 7e 10 00 00           lcall 0x10
00000fc0: b2 0b                 mov b32 $r11 $r0
00000fc2: 8a 04 03 01           mov $r10 0x10304
00000fc6: 7e 10 00 00           lcall 0x10
00000fca: b2 0b                 mov b32 $r11 $r0
00000fcc: 8a 04 04 01           mov $r10 0x10404
00000fd0: 7e 10 00 00           lcall 0x10
00000fd4: 7e 8e 0a 00           lcall 0xa8e
00000fd8: fb 01                 mpopret $r0
00000fda: 8d e0 13 00           mov $r13 0x13e0
00000fde: bd a4                 clear b32 $r10
00000fe0: 8b e8 13 00           mov $r11 0x13e8
00000fe4: 3e 06 10 00           lbra 0x1006
00000fe8: bc cf 95            B shr b32 $r9 $r12 $r15
00000feb: 90 ae 01              add b32 $r14 $r10 0x1
00000fee: f0 94 01              and $r9 0x1
00000ff1: 90 ff 01              add b32 $r15 $r15 0x1
00000ff4: b3 90 00 06           bra b32 $r9 0x0 e 0xffa
00000ff8: b2 ea                 mov b32 $r10 $r14
00000ffa: b3 f4 20 ee         B bra b32 $r15 0x20 ne 0xfe8
00000ffe: 90 dd 04              add b32 $r13 $r13 0x4
00001001: a6 db                 cmp b32 $r13 $r11
00001003: f4 0b 0b              bra e 0x100e
00001006: bf dc               B ld b32 $r12 D[$r13]
00001008: bd f4                 clear b32 $r15
0000100a: 3e e8 0f 00           lbra 0xfe8
0000100e: f8 00               B ret
00001010: 0f 01                 mov $r15 0x1
00001012: b3 a4 00 06           bra b32 $r10 0x0 ne 0x1018
00001016: bd f4                 clear b32 $r15
00001018: 89 00 dc 02         B mov $r9 0x2dc00
0000101c: fa 9f 00              iowr I[$r9] $r15
0000101f: f8 00                 ret

00001021: f9 22              C  mpush $r2
00001023: 98 cf 01              ld b32 $r15 D[$r12+0x4]
00001026: bf c0                 ld b32 $r0 D[$r12]
00001028: bf b1                 ld b32 $r1 D[$r11]
0000102a: 98 b9 01              ld b32 $r9 D[$r11+0x4]
0000102d: 98 b2 03              ld b32 $r2 D[$r11+0xc]
00001030: 98 cd 03              ld b32 $r13 D[$r12+0xc]
00001033: 98 ce 02              ld b32 $r14 D[$r12+0x8]
00001036: 98 bc 02              ld b32 $r12 D[$r11+0x8]
00001039: bc 01 00              add b32 $r0 $r0 $r1
0000103c: bc f9 f0              add b32 $r15 $r15 $r9
0000103f: 95 09 10              shr b32 $r9 $r0 0x10
00001042: f0 03 00              sethi $r0 0x0
00001045: bc f9 f0              add b32 $r15 $r15 $r9
00001048: 95 f9 10              shr b32 $r9 $r15 0x10
0000104b: bc d2 d0              add b32 $r13 $r13 $r2
0000104e: bc ec e0              add b32 $r14 $r14 $r12
00001051: a0 a0                 st b32 D[$r10] $r0
00001053: bc e9 e0              add b32 $r14 $r14 $r9
00001056: f0 f3 00              sethi $r15 0x0
00001059: 95 e9 10              shr b32 $r9 $r14 0x10
0000105c: b5 af 01              st b32 D[$r10+0x4] $r15
0000105f: bc d9 d0              add b32 $r13 $r13 $r9
00001062: f0 e3 00              sethi $r14 0x0
00001065: f0 d3 00              sethi $r13 0x0
00001068: b5 ae 02              st b32 D[$r10+0x8] $r14
0000106b: b5 ad 03              st b32 D[$r10+0xc] $r13
0000106e: fb 21                 mpopret $r2

00001070: 8d 00 0e 00        C  mov $r13 0xe00
00001074: 98 de 0e              ld b32 $r14 D[$r13+0x38]
00001077: 89 30 00 00           mov $r9 0x30
0000107b: c4 af ff              and $r15 $r10 0xff
0000107e: a0 9a                 st b32 D[$r9] $r10
00001080: 49 00 ff              mov $r9 -0x100
00001083: fd e9 04              and $r14 $r9
00001086: fd fe 05              or $r15 $r14
00001089: b5 df 0e              st b32 D[$r13+0x38] $r15
0000108c: f8 00                 ret

0000108e: 8d 94 14 00        C  mov $r13 0x1494
00001092: 98 d9 01              ld b32 $r9 D[$r13+0x4]
00001095: de ff ff 00 ff        mov $r14 0xff00ffff
0000109a: 8f 80 14 00           mov $r15 0x1480
0000109e: bf ff                 ld b32 $r15 D[$r15]
000010a0: ff 9e e4              and $r14 $r9 $r14
000010a3: c7 99 f0              extr $r9 $r9 0x10:0x17
000010a6: 90 99 01              add b32 $r9 $r9 0x1
000010a9: f0 94 ff              and $r9 0xff
000010ac: b6 94 10              shl b32 $r9 0x10
000010af: fd 9e 05              or $r9 $r14
000010b2: bd e4                 clear b32 $r14
000010b4: b5 d9 01              st b32 D[$r13+0x4] $r9
000010b7: bd 94                 clear b32 $r9
000010b9: 3e f0 10 00           lbra 0x10f0
000010bd: a6 ea               B cmp b32 $r14 $r10
000010bf: f4 1b 1b              bra ne 0x10da
000010c2: 8f 34 0c 00           mov $r15 0xc34
000010c6: b6 94 02              shl b32 $r9 0x2
000010c9: bc 9f 90              add b32 $r9 $r9 $r15
000010cc: bf 9e                 ld b32 $r14 D[$r9]
000010ce: 0f 01                 mov $r15 0x1
000010d0: bb fd 04              shl b32 $r15 $r13
000010d3: fd fe 05              or $r15 $r14
000010d6: a0 9f                 st b32 D[$r9] $r15
000010d8: f8 00                 ret
000010da: 90 ee 01            B add b32 $r14 $r14 0x1
000010dd: a6 ef                 cmp b32 $r14 $r15
000010df: f4 0c 17              bra a 0x10f6
000010e2: 90 dd 01              add b32 $r13 $r13 0x1
000010e5: b3 d4 20 d8           bra b32 $r13 0x20 ne 0x10bd
000010e9: 90 99 01              add b32 $r9 $r9 0x1
000010ec: b3 90 04 0a           bra b32 $r9 0x4 e 0x10f6
000010f0: bd d4               B clear b32 $r13
000010f2: 3e bd 10 00           lbra 0x10bd
000010f6: f8 00               B ret

000010f8: f9 22              C  mpush $r2
000010fa: 89 80 14 00           mov $r9 0x1480
000010fe: 8d 34 0c 00           mov $r13 0xc34
00001102: bf 90                 ld b32 $r0 D[$r9]
00001104: bd a4                 clear b32 $r10
00001106: 0f 0d                 mov $r15 0xd
00001108: 02 01                 mov $r2 0x1
0000110a: 81 44 0c 00           mov $r1 0xc44
0000110e: 3e 6c 11 00           lbra 0x116c
00001112: bc 2e c4            B shl b32 $r12 $r2 $r14
00001115: 90 ee 01              add b32 $r14 $r14 0x1
00001118: ff cb 94              and $r9 $r12 $r11
0000111b: f4 0b 3a              bra e 0x1155
0000111e: 8d 94 14 00           mov $r13 0x1494
00001122: 98 de 01              ld b32 $r14 D[$r13+0x4]
00001125: b9 c9 00              not b32 $r9 $r12
00001128: b6 f4 02              shl b32 $r15 0x2
0000112b: fd 9b 04              and $r9 $r11
0000112e: 8c 00 0c 00           mov $r12 0xc00
00001132: bc fc f0              add b32 $r15 $r15 $r12
00001135: a0 f9                 st b32 D[$r15] $r9
00001137: e4 e9 00 ff           and $r9 $r14 0xff00
0000113b: 8f ff 00 ff           mov $r15 -0xff01
0000113f: b8 99 00 01 00        add b32 $r9 $r9 0x100
00001144: fd ef 04              and $r14 $r15
00001147: f1 94 ff ff           and $r9 0xffff
0000114b: fd 9e 05              or $r9 $r14
0000114e: b5 d9 01              st b32 D[$r13+0x4] $r9
00001151: 3e 94 11 00           lbra 0x1194
00001155: 90 aa 01            B add b32 $r10 $r10 0x1
00001158: a6 a0                 cmp b32 $r10 $r0
0000115a: f4 0c 1a              bra a 0x1174
0000115d: b3 e4 20 b5           bra b32 $r14 0x20 ne 0x1112
00001161: 90 dd 04              add b32 $r13 $r13 0x4
00001164: 90 ff 01              add b32 $r15 $r15 0x1
00001167: a6 d1                 cmp b32 $r13 $r1
00001169: f4 0b 0b              bra e 0x1174
0000116c: bf db               B ld b32 $r11 D[$r13]
0000116e: bd e4                 clear b32 $r14
00001170: 3e 12 11 00           lbra 0x1112
00001174: 89 94 14 00         B mov $r9 0x1494
00001178: 98 9f 01              ld b32 $r15 D[$r9+0x4]
0000117b: de ff ff ff 00        mov $r14 0xffffff
00001180: 0a ff                 mov $r10 -0x1
00001182: ff fe e4              and $r14 $r15 $r14
00001185: b6 f5 18              shr b32 $r15 0x18
00001188: 90 ff 01              add b32 $r15 $r15 0x1
0000118b: b6 f4 18              shl b32 $r15 0x18
0000118e: fd fe 05              or $r15 $r14
00001191: b5 9f 01              st b32 D[$r9+0x4] $r15
00001194: fb 21               B mpopret $r2

00001196: f4 30 b4           C  add $sp -0x4c
00001199: b2 ab                 mov b32 $r11 $r10
0000119b: f9 82                 mpush $r8
0000119d: df c0 ee ff c0        mov $r15 0xc0ffeec0
000011a2: 89 00 0a 02           mov $r9 0x20a00
000011a6: fa 9f 00              iowr I[$r9] $r15
000011a9: 89 84 14 00           mov $r9 0x1484
000011ad: bf 9a                 ld b32 $r10 D[$r9]
000011af: 89 00 0a 02           mov $r9 0x20a00
000011b3: fa 9a 00              iowr I[$r9] $r10
000011b6: 89 00 0e 00           mov $r9 0xe00
000011ba: 98 9f 0e              ld b32 $r15 D[$r9+0x38]
000011bd: 89 88 14 00           mov $r9 0x1488
000011c1: bf 9e                 ld b32 $r14 D[$r9]
000011c3: 89 30 00 00           mov $r9 0x30
000011c7: c4 f1 ff              and $r1 $r15 0xff
000011ca: a0 91                 st b32 D[$r9] $r1
000011cc: a6 e1                 cmp b32 $r14 $r1
000011ce: f4 1b 1a              bra ne 0x11e8
000011d1: 89 8c 14 00           mov $r9 0x148c
000011d5: bf 99                 ld b32 $r9 D[$r9]
000011d7: a6 9b                 cmp b32 $r9 $r11
000011d9: f4 1b 0f              bra ne 0x11e8
000011dc: 89 90 14 00           mov $r9 0x1490
000011e0: bf 99                 ld b32 $r9 D[$r9]
000011e2: a6 9a                 cmp b32 $r9 $r10
000011e4: f5 0b f8 04           bra e 0x16dc
000011e8: 8f 00 0c 00         B mov $r15 0xc00
000011ec: bf f2                 ld b32 $r2 D[$r15]
000011ee: 89 78 14 00           mov $r9 0x1478
000011f2: 8e 00 0e 00           mov $r14 0xe00
000011f6: 98 ec 3a              ld b32 $r12 D[$r14+0xe8]
000011f9: a0 92                 st b32 D[$r9] $r2
000011fb: 98 f2 04              ld b32 $r2 D[$r15+0x10]
000011fe: 89 74 14 00           mov $r9 0x1474
00001202: bf ed                 ld b32 $r13 D[$r14]
00001204: b6 c4 18              shl b32 $r12 0x18
00001207: a0 92                 st b32 D[$r9] $r2
00001209: 98 f2 0c              ld b32 $r2 D[$r15+0x30]
0000120c: 89 80 14 00           mov $r9 0x1480
00001210: b6 d5 08              shr b32 $r13 0x8
00001213: 98 e8 31              ld b32 $r8 D[$r14+0xc4]
00001216: a0 92                 st b32 D[$r9] $r2
00001218: 89 88 14 00           mov $r9 0x1488
0000121c: a0 91                 st b32 D[$r9] $r1
0000121e: 89 8c 14 00           mov $r9 0x148c
00001222: a0 9b                 st b32 D[$r9] $r11
00001224: 89 90 14 00           mov $r9 0x1490
00001228: a0 9a                 st b32 D[$r9] $r10
0000122a: 89 5c 14 00           mov $r9 0x145c
0000122e: ff cd 25              or $r2 $r12 $r13
00001231: a0 92                 st b32 D[$r9] $r2
00001233: 98 e9 27              ld b32 $r9 D[$r14+0x9c]
00001236: 98 f4 07              ld b32 $r4 D[$r15+0x1c]
00001239: 98 f6 18              ld b32 $r6 D[$r15+0x60]
0000123c: 98 f7 03              ld b32 $r7 D[$r15+0xc]
0000123f: b0 91 0a              st b32 D[$sp+0x28] $r9
00001242: 98 e9 2e              ld b32 $r9 D[$r14+0xb8]
00001245: b0 91 19              st b32 D[$sp+0x64] $r9
00001248: 98 e9 2f              ld b32 $r9 D[$r14+0xbc]
0000124b: b0 91 09              st b32 D[$sp+0x24] $r9
0000124e: 98 e9 30              ld b32 $r9 D[$r14+0xc0]
00001251: 98 ee 26              ld b32 $r14 D[$r14+0x98]
00001254: b0 91 1a              st b32 D[$sp+0x68] $r9
00001257: b0 e1 1b              st b32 D[$sp+0x6c] $r14
0000125a: 98 fe 01              ld b32 $r14 D[$r15+0x4]
0000125d: 98 f9 02              ld b32 $r9 D[$r15+0x8]
00001260: b0 e1 0f              st b32 D[$sp+0x3c] $r14
00001263: 98 fe 05              ld b32 $r14 D[$r15+0x14]
00001266: b0 91 10              st b32 D[$sp+0x40] $r9
00001269: 98 f9 06              ld b32 $r9 D[$r15+0x18]
0000126c: b0 e1 11              st b32 D[$sp+0x44] $r14
0000126f: b0 91 12              st b32 D[$sp+0x48] $r9
00001272: 98 fe 08              ld b32 $r14 D[$r15+0x20]
00001275: 98 f9 09              ld b32 $r9 D[$r15+0x24]
00001278: 98 f0 0a              ld b32 $r0 D[$r15+0x28]
0000127b: 98 f5 17              ld b32 $r5 D[$r15+0x5c]
0000127e: b0 e1 13              st b32 D[$sp+0x4c] $r14
00001281: 98 fe 0b              ld b32 $r14 D[$r15+0x2c]
00001284: b0 91 14              st b32 D[$sp+0x50] $r9
00001287: 98 f3 16              ld b32 $r3 D[$r15+0x58]
0000128a: b0 e1 15              st b32 D[$sp+0x54] $r14
0000128d: b3 4e 00 02 07        bra b32 $r4 0x200 ne 0x1294
00001292: bd 44                 clear b32 $r4
00001294: b3 0e 00 02 07      B bra b32 $r0 0x200 ne 0x129b
00001299: bd 04                 clear b32 $r0
0000129b: 89 74 14 00         B mov $r9 0x1474
0000129f: bf 9b                 ld b32 $r11 D[$r9]
000012a1: 7e ce 77 00           lcall 0x77ce
000012a5: 89 70 14 00           mov $r9 0x1470
000012a9: a0 9a                 st b32 D[$r9] $r10
000012ab: 8c 94 14 00           mov $r12 0x1494
000012af: b3 14 02 2f           bra b32 $r1 0x2 ne 0x12de
000012b3: 98 cd 01              ld b32 $r13 D[$r12+0x4]
000012b6: bc a6 90              add b32 $r9 $r10 $r6
000012b9: b6 95 08              shr b32 $r9 0x8
000012bc: bc a7 f0              add b32 $r15 $r10 $r7
000012bf: bc 92 10              add b32 $r1 $r9 $r2
000012c2: 10 de 01              add b8 $r14 $r13 0x1
000012c5: b6 f5 08              shr b32 $r15 0x8
000012c8: f0 e4 ff              and $r14 0xff
000012cb: 49 00 ff              mov $r9 -0x100
000012ce: bc f2 20              add b32 $r2 $r15 $r2
000012d1: fd d9 04              and $r13 $r9
000012d4: fd ed 05              or $r14 $r13
000012d7: b5 ce 01              st b32 D[$r12+0x4] $r14
000012da: 3e 15 13 00           lbra 0x1315
000012de: b4 90 1a            B ld b32 $r9 D[$sp+0x68]
000012e1: 94 8f 18              shl b32 $r15 $r8 0x18
000012e4: bf ce                 ld b32 $r14 D[$r12]
000012e6: b2 53                 mov b32 $r3 $r5
000012e8: b6 95 08              shr b32 $r9 0x8
000012eb: ff f9 25              or $r2 $r15 $r9
000012ee: b4 f0 0a              ld b32 $r15 D[$sp+0x28]
000012f1: b4 90 1b              ld b32 $r9 D[$sp+0x6c]
000012f4: b2 40                 mov b32 $r0 $r4
000012f6: b6 f4 18              shl b32 $r15 0x18
000012f9: b6 95 08              shr b32 $r9 0x8
000012fc: ff f9 15              or $r1 $r15 $r9
000012ff: 95 e9 18              shr b32 $r9 $r14 0x18
00001302: df ff ff ff 00        mov $r15 0xffffff
00001307: 90 99 01              add b32 $r9 $r9 0x1
0000130a: fd ef 04              and $r14 $r15
0000130d: b6 94 18              shl b32 $r9 0x18
00001310: fd 9e 05              or $r9 $r14
00001313: a0 c9                 st b32 D[$r12] $r9
00001315: 8a 70 80 40         B mov $r10 0x408070
00001319: b2 1b                 mov b32 $r11 $r1
0000131b: bd c4                 clear b32 $r12
0000131d: bd d4                 clear b32 $r13
0000131f: 7e 8f 02 00           lcall 0x28f
00001323: e4 3b ff 7f           and $r11 $r3 0x7fff
00001327: 8a 74 80 40           mov $r10 0x408074
0000132b: bd c4                 clear b32 $r12
0000132d: bd d4                 clear b32 $r13
0000132f: 7e 8f 02 00           lcall 0x28f
00001333: b2 1b                 mov b32 $r11 $r1
00001335: 8a 34 90 41           mov $r10 0x419034
00001339: bd c4                 clear b32 $r12
0000133b: bd d4                 clear b32 $r13
0000133d: 7e 8f 02 00           lcall 0x28f
00001341: 8a 0c 80 40           mov $r10 0x40800c
00001345: b2 2b                 mov b32 $r11 $r2
00001347: bd c4                 clear b32 $r12
00001349: bd d4                 clear b32 $r13
0000134b: 7e 8f 02 00           lcall 0x28f
0000134f: f1 04 ff 03           and $r0 0x3ff
00001353: 8a 10 80 40           mov $r10 0x408010
00001357: bd c4                 clear b32 $r12
00001359: bd d4                 clear b32 $r13
0000135b: db 00 d8 07 80        mov $r11 0x8007d800
00001360: ff 0b b5              or $r11 $r0 $r11
00001363: 7e 8f 02 00           lcall 0x28f
00001367: b2 2b                 mov b32 $r11 $r2
00001369: 8a 04 90 41           mov $r10 0x419004
0000136d: bd c4                 clear b32 $r12
0000136f: bd d4                 clear b32 $r13
00001371: 7e 8f 02 00           lcall 0x28f
00001375: bd d4                 clear b32 $r13
00001377: b2 0b                 mov b32 $r11 $r0
00001379: 8a 08 90 41           mov $r10 0x419008
0000137d: bd c4                 clear b32 $r12
0000137f: 7e 8f 02 00           lcall 0x28f
00001383: 89 a0 14 00           mov $r9 0x14a0
00001387: bf 9d                 ld b32 $r13 D[$r9]
00001389: 8f c8 14 00           mov $r15 0x14c8
0000138d: bd 34                 clear b32 $r3
0000138f: 94 de 02              shl b32 $r14 $r13 0x2
00001392: bc ef e0              add b32 $r14 $r14 $r15
00001395: 3e a1 13 00           lbra 0x13a1
00001399: bf f9               B ld b32 $r9 D[$r15]
0000139b: 90 ff 04              add b32 $r15 $r15 0x4
0000139e: bc 39 30              add b32 $r3 $r3 $r9
000013a1: a6 fe               B cmp b32 $r15 $r14
000013a3: f4 1b f6              bra ne 0x1399
000013a6: 89 7c 14 00           mov $r9 0x147c
000013aa: bf 99                 ld b32 $r9 D[$r9]
000013ac: b3 94 00 0a           bra b32 $r9 0x0 ne 0x13b6
000013b0: b2 3b                 mov b32 $r11 $r3
000013b2: 3e bf 13 00           lbra 0x13bf
000013b6: bc dd 90            B add b32 $r9 $r13 $r13
000013b9: bc 9d 90              add b32 $r9 $r9 $r13
000013bc: bc 99 b0              add b32 $r11 $r9 $r9
000013bf: 89 30 00 00         B mov $r9 0x30
000013c3: bf 99                 ld b32 $r9 D[$r9]
000013c5: b3 94 02 3d           bra b32 $r9 0x2 ne 0x1402
000013c9: b4 a0 13              ld b32 $r10 D[$sp+0x4c]
000013cc: b6 a4 05              shl b32 $r10 0x5
000013cf: 7e ce 77 00           lcall 0x77ce
000013d3: b2 a5                 mov b32 $r5 $r10
000013d5: b4 a0 14              ld b32 $r10 D[$sp+0x50]
000013d8: b2 3b                 mov b32 $r11 $r3
000013da: b6 a4 05              shl b32 $r10 0x5
000013dd: 7e ce 77 00           lcall 0x77ce
000013e1: 89 70 14 00           mov $r9 0x1470
000013e5: b4 20 10              ld b32 $r2 D[$sp+0x40]
000013e8: bf 99                 ld b32 $r9 D[$r9]
000013ea: 8f 5c 14 00           mov $r15 0x145c
000013ee: bf ff                 ld b32 $r15 D[$r15]
000013f0: b2 a4                 mov b32 $r4 $r10
000013f2: bc 29 90              add b32 $r9 $r2 $r9
000013f5: b6 95 08              shr b32 $r9 0x8
000013f8: bc 9f 90              add b32 $r9 $r9 $r15
000013fb: 95 92 04              shr b32 $r2 $r9 0x4
000013fe: 3e 2b 14 00           lbra 0x142b
00001402: b4 a0 11            B ld b32 $r10 D[$sp+0x44]
00001405: b6 a4 05              shl b32 $r10 0x5
00001408: 7e ce 77 00           lcall 0x77ce
0000140c: b2 a5                 mov b32 $r5 $r10
0000140e: b4 a0 12              ld b32 $r10 D[$sp+0x48]
00001411: b2 3b                 mov b32 $r11 $r3
00001413: b6 a4 05              shl b32 $r10 0x5
00001416: 7e ce 77 00           lcall 0x77ce
0000141a: b4 f0 09              ld b32 $r15 D[$sp+0x24]
0000141d: b4 90 19              ld b32 $r9 D[$sp+0x64]
00001420: b2 a4                 mov b32 $r4 $r10
00001422: b6 f4 14              shl b32 $r15 0x14
00001425: b6 95 0c              shr b32 $r9 0xc
00001428: ff f9 25              or $r2 $r15 $r9
0000142b: d1 00 00 00 80      B mov $r1 0x80000000
00001430: 8a 10 88 41           mov $r10 0x418810
00001434: bd c4                 clear b32 $r12
00001436: bd d4                 clear b32 $r13
00001438: d0 ff ff ff 0f        mov $r0 0xfffffff
0000143d: ff 20 04              and $r0 $r2 $r0
00001440: ff 01 b5              or $r11 $r0 $r1
00001443: 7e 8f 02 00           lcall 0x28f
00001447: d9 00 00 00 10        mov $r9 0x10000000
0000144c: 8a 48 98 41           mov $r10 0x419848
00001450: fd 09 05              or $r0 $r9
00001453: bd c4                 clear b32 $r12
00001455: bd d4                 clear b32 $r13
00001457: b2 0b                 mov b32 $r11 $r0
00001459: 7e 8f 02 00           lcall 0x28f
0000145d: b2 0b                 mov b32 $r11 $r0
0000145f: 8a 2c 9c 41           mov $r10 0x419c2c
00001463: bd c4                 clear b32 $r12
00001465: bd d4                 clear b32 $r13
00001467: 7e 8f 02 00           lcall 0x28f
0000146b: b2 2b                 mov b32 $r11 $r2
0000146d: 8a 00 9e 41           mov $r10 0x419e00
00001471: bd c4                 clear b32 $r12
00001473: bd d4                 clear b32 $r13
00001475: 7e 8f 02 00           lcall 0x28f
00001479: 09 80                 mov $r9 -0x80
0000147b: bc 45 b0              add b32 $r11 $r4 $r5
0000147e: 8a 04 9e 41           mov $r10 0x419e04
00001482: fd b9 04              and $r11 $r9
00001485: bd c4                 clear b32 $r12
00001487: 90 bb 80              add b32 $r11 $r11 0x80
0000148a: bd d4                 clear b32 $r13
0000148c: e7 bb 87 02           extr $r11 $r11 0x7:0x1b
00001490: fd b1 05              or $r11 $r1
00001493: 7e 8f 02 00           lcall 0x28f
00001497: 89 30 00 00           mov $r9 0x30
0000149b: bf 99                 ld b32 $r9 D[$r9]
0000149d: b3 90 02 16           bra b32 $r9 0x2 e 0x14b3
000014a1: b4 90 11              ld b32 $r9 D[$sp+0x44]
000014a4: b4 10 12              ld b32 $r1 D[$sp+0x48]
000014a7: b0 91 0d              st b32 D[$sp+0x34] $r9
000014aa: b0 11 0e              st b32 D[$sp+0x38] $r1
000014ad: b2 9b                 mov b32 $r11 $r9
000014af: 3e c2 14 00           lbra 0x14c2
000014b3: b4 10 14            B ld b32 $r1 D[$sp+0x50]
000014b6: b4 e0 13              ld b32 $r14 D[$sp+0x4c]
000014b9: b4 b0 11              ld b32 $r11 D[$sp+0x44]
000014bc: b0 11 0e              st b32 D[$sp+0x38] $r1
000014bf: b0 e1 0d              st b32 D[$sp+0x34] $r14
000014c2: 8a 30 58 40         B mov $r10 0x405830
000014c6: bd c4                 clear b32 $r12
000014c8: bd d4                 clear b32 $r13
000014ca: 80 ff ff 3f           mov $r0 0x3fffff
000014ce: fd b0 04              and $r11 $r0
000014d1: 7e 8f 02 00           lcall 0x28f
000014d5: 74 b0 1c              ld b16 $r11 D[$sp+0x38]
000014d8: 8a 5c 58 40           mov $r10 0x40585c
000014dc: bd c4                 clear b32 $r12
000014de: bd d4                 clear b32 $r13
000014e0: f0 b3 00              sethi $r11 0x0
000014e3: 7e 8f 02 00           lcall 0x28f
000014e7: b4 b0 0e              ld b32 $r11 D[$sp+0x38]
000014ea: bd c4                 clear b32 $r12
000014ec: bd d4                 clear b32 $r13
000014ee: 8a c4 64 40           mov $r10 0x4064c4
000014f2: b6 b4 0e              shl b32 $r11 0xe
000014f5: f1 b5 ff ff           or $r11 0xffff
000014f9: 7e 8f 02 00           lcall 0x28f
000014fd: b2 1a                 mov b32 $r10 $r1
000014ff: b2 3b                 mov b32 $r11 $r3
00001501: 7e ce 77 00           lcall 0x77ce
00001505: 8f f8 14 00           mov $r15 0x14f8
00001509: bd 24                 clear b32 $r2
0000150b: 89 a0 8e 41           mov $r9 0x418ea0
0000150f: 8e c0 30 50           mov $r14 0x5030c0
00001513: b0 a1 0c              st b32 D[$sp+0x30] $r10
00001516: b0 f1 18              st b32 D[$sp+0x60] $r15
00001519: b0 21 0b              st b32 D[$sp+0x2c] $r2
0000151c: bd 64                 clear b32 $r6
0000151e: b0 91 17              st b32 D[$sp+0x5c] $r9
00001521: b0 e1 16              st b32 D[$sp+0x58] $r14
00001524: 3e 09 16 00           lbra 0x1609
00001528: 8f 7c 14 00         B mov $r15 0x147c
0000152c: bf f9                 ld b32 $r9 D[$r15]
0000152e: bf 50                 ld b32 $r0 D[$r5]
00001530: 90 77 01              add b32 $r7 $r7 0x1
00001533: 90 55 04              add b32 $r5 $r5 0x4
00001536: b3 94 00 06           bra b32 $r9 0x0 ne 0x153c
0000153a: b2 04                 mov b32 $r4 $r0
0000153c: b2 4a               B mov b32 $r10 $r4
0000153e: 7e ce 77 00           lcall 0x77ce
00001542: b2 a2                 mov b32 $r2 $r10
00001544: b4 a0 0e              ld b32 $r10 D[$sp+0x38]
00001547: b2 0b                 mov b32 $r11 $r0
00001549: 7e ce 77 00           lcall 0x77ce
0000154d: 89 ff ff 3f           mov $r9 0x3fffff
00001551: b2 a1                 mov b32 $r1 $r10
00001553: ff 29 b4              and $r11 $r2 $r9
00001556: b2 3a                 mov b32 $r10 $r3
00001558: bd c4                 clear b32 $r12
0000155a: bd d4                 clear b32 $r13
0000155c: 7e 8f 02 00           lcall 0x28f
00001560: b4 b0 0c              ld b32 $r11 D[$sp+0x30]
00001563: 8e ff ff 3f           mov $r14 0x3fffff
00001567: bd c4                 clear b32 $r12
00001569: bd d4                 clear b32 $r13
0000156b: fd be 04              and $r11 $r14
0000156e: 90 3a 34              add b32 $r10 $r3 0x34
00001571: 7e 8f 02 00           lcall 0x28f
00001575: b4 b0 11              ld b32 $r11 D[$sp+0x44]
00001578: b2 4a                 mov b32 $r10 $r4
0000157a: 7e ce 77 00           lcall 0x77ce
0000157e: 8f ff ff 3f           mov $r15 0x3fffff
00001582: bd c4                 clear b32 $r12
00001584: ff af 04              and $r0 $r10 $r15
00001587: bd d4                 clear b32 $r13
00001589: 90 3a 30              add b32 $r10 $r3 0x30
0000158c: b2 0b                 mov b32 $r11 $r0
0000158e: 7e 8f 02 00           lcall 0x28f
00001592: 90 3a 24              add b32 $r10 $r3 0x24
00001595: e4 1b ff ff           and $r11 $r1 0xffff
00001599: bd c4                 clear b32 $r12
0000159b: bd d4                 clear b32 $r13
0000159d: 7e 8f 02 00           lcall 0x28f
000015a1: b4 b0 0b              ld b32 $r11 D[$sp+0x2c]
000015a4: 89 ff ff 3f           mov $r9 0x3fffff
000015a8: 90 3a 38              add b32 $r10 $r3 0x38
000015ab: bd c4                 clear b32 $r12
000015ad: fd b9 04              and $r11 $r9
000015b0: bd d4                 clear b32 $r13
000015b2: 7e 8f 02 00           lcall 0x28f
000015b6: b4 e0 0c              ld b32 $r14 D[$sp+0x30]
000015b9: b4 f0 0b              ld b32 $r15 D[$sp+0x2c]
000015bc: b2 8a                 mov b32 $r10 $r8
000015be: b2 0b                 mov b32 $r11 $r0
000015c0: bc e2 e0              add b32 $r14 $r14 $r2
000015c3: bc f1 f0              add b32 $r15 $r15 $r1
000015c6: b0 e1 0c              st b32 D[$sp+0x30] $r14
000015c9: b0 f1 0b              st b32 D[$sp+0x2c] $r15
000015cc: b8 33 00 02 00        add b32 $r3 $r3 0x200
000015d1: 90 88 04              add b32 $r8 $r8 0x4
000015d4: bd c4                 clear b32 $r12
000015d6: bd d4                 clear b32 $r13
000015d8: 7e 8f 02 00           lcall 0x28f
000015dc: b4 20 18            B ld b32 $r2 D[$sp+0x60]
000015df: b4 b0 0d              ld b32 $r11 D[$sp+0x34]
000015e2: 04 02                 mov $r4 0x2
000015e4: bf 29                 ld b32 $r9 D[$r2]
000015e6: a6 79                 cmp b32 $r7 $r9
000015e8: f5 08 40 ff           bra b 0x1528
000015ec: b4 90 17              ld b32 $r9 D[$sp+0x5c]
000015ef: b4 e0 16              ld b32 $r14 D[$sp+0x58]
000015f2: 90 22 04              add b32 $r2 $r2 0x4
000015f5: 90 66 01              add b32 $r6 $r6 0x1
000015f8: 90 99 0c              add b32 $r9 $r9 0xc
000015fb: b8 ee 00 80 00        add b32 $r14 $r14 0x8000
00001600: b0 91 17              st b32 D[$sp+0x5c] $r9
00001603: b0 e1 16              st b32 D[$sp+0x58] $r14
00001606: b0 21 18              st b32 D[$sp+0x60] $r2
00001609: 8f a0 14 00         B mov $r15 0x14a0
0000160d: bf f9                 ld b32 $r9 D[$r15]
0000160f: a6 69                 cmp b32 $r6 $r9
00001611: f4 18 1f              bra ae 0x1630
00001614: bc 66 90              add b32 $r9 $r6 $r6
00001617: 82 28 15 00           mov $r2 0x1528
0000161b: bc 96 90              add b32 $r9 $r9 $r6
0000161e: b4 30 16              ld b32 $r3 D[$sp+0x58]
00001621: 94 95 02              shl b32 $r5 $r9 0x2
00001624: b4 80 17              ld b32 $r8 D[$sp+0x5c]
00001627: bc 52 50              add b32 $r5 $r5 $r2
0000162a: bd 74                 clear b32 $r7
0000162c: 3e dc 15 00           lbra 0x15dc
00001630: 89 30 00 00         B mov $r9 0x30
00001634: bf 99                 ld b32 $r9 D[$r9]
00001636: b3 94 02 62           bra b32 $r9 0x2 ne 0x1698
0000163a: b4 30 15              ld b32 $r3 D[$sp+0x54]
0000163d: bd 24                 clear b32 $r2
0000163f: bd 14                 clear b32 $r1
00001641: 80 d8 01 50           mov $r0 0x5001d8
00001645: 86 a0 14 00           mov $r6 0x14a0
00001649: 85 70 14 00           mov $r5 0x1470
0000164d: 84 5c 14 00           mov $r4 0x145c
00001651: f1 34 ff ff           and $r3 0xffff
00001655: 3e 8b 16 00           lbra 0x168b
00001659: bf 5b               B ld b32 $r11 D[$r5]
0000165b: bf 49                 ld b32 $r9 D[$r4]
0000165d: b4 e0 0f              ld b32 $r14 D[$sp+0x3c]
00001660: 90 22 01              add b32 $r2 $r2 0x1
00001663: bc eb b0              add b32 $r11 $r14 $r11
00001666: b6 b5 08              shr b32 $r11 0x8
00001669: bc b9 b0              add b32 $r11 $r11 $r9
0000166c: bc b1 b0              add b32 $r11 $r11 $r1
0000166f: 7e 8f 02 00           lcall 0x28f
00001673: b4 f0 15              ld b32 $r15 D[$sp+0x54]
00001676: 90 0a 04              add b32 $r10 $r0 0x4
00001679: b2 3b                 mov b32 $r11 $r3
0000167b: b8 00 00 80 00        add b32 $r0 $r0 0x8000
00001680: bc 1f 10              add b32 $r1 $r1 $r15
00001683: bd c4                 clear b32 $r12
00001685: bd d4                 clear b32 $r13
00001687: 7e 8f 02 00           lcall 0x28f
0000168b: bf 69               B ld b32 $r9 D[$r6]
0000168d: b2 0a                 mov b32 $r10 $r0
0000168f: bd c4                 clear b32 $r12
00001691: bd d4                 clear b32 $r13
00001693: a6 29                 cmp b32 $r2 $r9
00001695: f4 08 c4              bra b 0x1659
00001698: 8a e4 81 41         B mov $r10 0x4181e4
0000169c: 4b 00 01              mov $r11 0x100
0000169f: bd c4                 clear b32 $r12
000016a1: bd d4                 clear b32 $r13
000016a3: 7e 8f 02 00           lcall 0x28f
000016a7: bd c4                 clear b32 $r12
000016a9: bd d4                 clear b32 $r13
000016ab: 8a fc be 41           mov $r10 0x41befc
000016af: 4b 00 01              mov $r11 0x100
000016b2: 7e 8f 02 00           lcall 0x28f
000016b6: 8a fc 19 12           mov $r10 0x1219fc
000016ba: 8b ce e7 0f           mov $r11 0xfe7ce
000016be: 7e 37 02 00           lcall 0x237
000016c2: 8a fc 09 12           mov $r10 0x1209fc
000016c6: db ce e7 0f 01        mov $r11 0x10fe7ce
000016cb: 7e 37 02 00           lcall 0x237
000016cf: 8a fc 11 12           mov $r10 0x1211fc
000016d3: db ce e7 0f 02        mov $r11 0x20fe7ce
000016d8: 7e 37 02 00           lcall 0x237
000016dc: fb 85 4c            B mpopaddret $r8 0x4c

000016df: 8f 00 00 40        C  mov $r15 0x400000
000016e3: 89 00 14 02           mov $r9 0x21400
000016e7: fa 9f 00              iowr I[$r9] $r15
000016ea: 8e 00 0e 00           mov $r14 0xe00
000016ee: 98 e9 07              ld b32 $r9 D[$r14+0x1c]
000016f1: 8f 08 13 00           mov $r15 0x1308
000016f5: f0 94 07              and $r9 0x7
000016f8: a0 f9                 st b32 D[$r15] $r9
000016fa: b3 94 02 41           bra b32 $r9 0x2 ne 0x173b
000016fe: 98 ec 18              ld b32 $r12 D[$r14+0x60]
00001701: 98 ee 08              ld b32 $r14 D[$r14+0x20]
00001704: 89 f0 12 00           mov $r9 0x12f0
00001708: 8f ff ff 01           mov $r15 0x1ffff
0000170c: fd cf 04              and $r12 $r15
0000170f: a0 9e                 st b32 D[$r9] $r14
00001711: 89 ec 12 00           mov $r9 0x12ec
00001715: bf 99                 ld b32 $r9 D[$r9]
00001717: 8f f4 12 00           mov $r15 0x12f4
0000171b: c4 bd 3f              and $r13 $r11 0x3f
0000171e: a0 fc                 st b32 D[$r15] $r12
00001720: c4 9e 3f              and $r14 $r9 0x3f
00001723: b6 d4 18              shl b32 $r13 0x18
00001726: b6 e4 10              shl b32 $r14 0x10
00001729: 90 99 40              add b32 $r9 $r9 0x40
0000172c: 8f f8 12 00           mov $r15 0x12f8
00001730: f0 94 ff              and $r9 0xff
00001733: fd 9e 05              or $r9 $r14
00001736: fd 9d 05              or $r9 $r13
00001739: a0 f9                 st b32 D[$r15] $r9
0000173b: 8f 00 00 40         B mov $r15 0x400000
0000173f: 89 00 1a 02           mov $r9 0x21a00
00001743: fa 9f 00              iowr I[$r9] $r15
00001746: f8 00                 ret

00001748: f9 02              C  mpush $r0
0000174a: 8d 00 01 02           mov $r13 0x20100
0000174e: bd e4                 clear b32 $r14
00001750: ff de ff              iord $r15 I[$r13+$r14*0x4]
00001753: 89 b0 12 00           mov $r9 0x12b0
00001757: a0 9f                 st b32 D[$r9] $r15
00001759: fa de 00              iowr I[$r13] $r14
0000175c: 7e 68 07 00           lcall 0x768
00001760: b2 a0                 mov b32 $r0 $r10
00001762: da 34 04 82 00        mov $r10 0x820434
00001767: 7e 97 02 00           lcall 0x297
0000176b: 89 b0 12 00           mov $r9 0x12b0
0000176f: bf 9f                 ld b32 $r15 D[$r9]
00001771: f0 a4 01              and $r10 0x1
00001774: 89 20 00 00           mov $r9 0x20
00001778: a0 9a                 st b32 D[$r9] $r10
0000177a: b3 f0 00 14           bra b32 $r15 0x0 e 0x178e
0000177e: b3 04 00 10           bra b32 $r0 0x0 ne 0x178e
00001782: 0f 01                 mov $r15 0x1
00001784: 89 ec 13 00           mov $r9 0x13ec
00001788: a0 9f                 st b32 D[$r9] $r15
0000178a: 3e c5 17 00           lbra 0x17c5
0000178e: b3 04 01 37         B bra b32 $r0 0x1 ne 0x17c5
00001792: bd 94                 clear b32 $r9
00001794: 8b 00 54 02           mov $r11 0x25400
00001798: ff b9 bf              iord $r11 I[$r11+$r9*0x4]
0000179b: 49 00 fc              mov $r9 -0x400
0000179e: 8a fc 54 02           mov $r10 0x254fc
000017a2: fd b9 04              and $r11 $r9
000017a5: f1 b5 cf 03           or $r11 0x3cf
000017a9: 7e 10 00 00           lcall 0x10
000017ad: 8a 00 1f 02           mov $r10 0x21f00
000017b1: 7e 44 00 00           lcall 0x44
000017b5: 09 f0                 mov $r9 -0x10
000017b7: ff a9 b4              and $r11 $r10 $r9
000017ba: 8a 00 1f 02           mov $r10 0x21f00
000017be: f0 b5 0c              or $r11 0xc
000017c1: 7e 10 00 00           lcall 0x10
000017c5: fb 01               B mpopret $r0

000017c7: 4a 00 12           C  mov $r10 0x1200
000017ca: 0b 02                 mov $r11 0x2
000017cc: 7e 10 00 00           lcall 0x10
000017d0: 89 65 1c 00           mov $r9 0x1c65
000017d4: fe 90 00              mov $iv0 $r9
000017d7: 4a 00 07              mov $r10 0x700
000017da: bd b4                 clear b32 $r11
000017dc: 7e 10 00 00           lcall 0x10
000017e0: 4a 00 04              mov $r10 0x400
000017e3: 8b 05 cf 00           mov $r11 0xcf05
000017e7: 7e 10 00 00           lcall 0x10
000017eb: 4a 00 03              mov $r10 0x300
000017ee: 0b 04                 mov $r11 0x4
000017f0: 7e 10 00 00           lcall 0x10
000017f4: 4f 03 20              mov $r15 0x2003
000017f7: 89 00 01 01           mov $r9 0x10100
000017fb: fa 9f 00              iowr I[$r9] $r15
000017fe: 4f 04 20              mov $r15 0x2004
00001801: 90 99 04              add b32 $r9 $r9 0x4
00001804: fa 9f 00              iowr I[$r9] $r15
00001807: 4f 0b 20              mov $r15 0x200b
0000180a: 90 99 04              add b32 $r9 $r9 0x4
0000180d: fa 9f 00              iowr I[$r9] $r15
00001810: 4f 13 20              mov $r15 0x2013
00001813: 90 99 10              add b32 $r9 $r9 0x10
00001816: fa 9f 00              iowr I[$r9] $r15
00001819: 4f 3d 20              mov $r15 0x203d
0000181c: 92 99 0c              sub b32 $r9 $r9 0xc
0000181f: fa 9f 00              iowr I[$r9] $r15
00001822: 4f 0c 20              mov $r15 0x200c
00001825: 90 99 10              add b32 $r9 $r9 0x10
00001828: fa 9f 00              iowr I[$r9] $r15
0000182b: 4f 2d 20              mov $r15 0x202d
0000182e: 89 40 05 03           mov $r9 0x30540
00001832: fa 9f 00              iowr I[$r9] $r15
00001835: f4 31 10              bset $flags ie0
00001838: f4 31 02              bset $flags $p2
0000183b: f8 00                 ret

0000183d: 0f 05              C  mov $r15 0x5
0000183f: 49 00 21              mov $r9 0x2100
00001842: fa 9f 00              iowr I[$r9] $r15
00001845: 0f ff                 mov $r15 -0x1
00001847: 89 00 09 03           mov $r9 0x30900
0000184b: fa 9f 00              iowr I[$r9] $r15
0000184e: 7e 48 17 00           lcall 0x1748
00001852: bd f4                 clear b32 $r15
00001854: 89 00 94 00           mov $r9 0x9400
00001858: fa 9f 01              iowrs I[$r9] $r15
0000185b: 89 2c 00 00           mov $r9 0x2c
0000185f: a0 9f                 st b32 D[$r9] $r15
00001861: 89 00 c2 02           mov $r9 0x2c200
00001865: fa 9f 00              iowr I[$r9] $r15
00001868: 7e c7 17 00           lcall 0x17c7
0000186c: f8 00                 ret

0000186e: bd f4              C  clear b32 $r15
00001870: 89 00 06 02           mov $r9 0x20600
00001874: ff 9f af              iord $r10 I[$r9+$r15*0x4]
00001877: 89 ec 13 00           mov $r9 0x13ec
0000187b: b3 a4 17 12           bra b32 $r10 0x17 ne 0x188d
0000187f: bf 99                 ld b32 $r9 D[$r9]
00001881: b3 94 01 06           bra b32 $r9 0x1 ne 0x1887
00001885: 0a 18                 mov $r10 0x18
00001887: 7e c0 05 00         B lcall 0x5c0
0000188b: f8 00                 ret
0000188d: bf 99               B ld b32 $r9 D[$r9]
0000188f: b3 94 01 0a           bra b32 $r9 0x1 ne 0x1899
00001893: 0a 16                 mov $r10 0x16
00001895: 7e c0 05 00           lcall 0x5c0
00001899: f8 00               B ret

0000189b: f9 62              C  mpush $r6
0000189d: 83 00 0a 00           mov $r3 0xa00
000018a1: bd 04                 clear b32 $r0
000018a3: b2 34                 mov b32 $r4 $r3
000018a5: bd 54                 clear b32 $r5
000018a7: 02 01                 mov $r2 0x1
000018a9: 81 18 26 50           mov $r1 0x502618
000018ad: 86 a0 14 00           mov $r6 0x14a0
000018b1: 3e dc 18 00           lbra 0x18dc
000018b5: 7e 97 02 00         B lcall 0x297
000018b9: c7 aa 0d              extr $r10 $r10 0xd:0xd
000018bc: a0 4a                 st b32 D[$r4] $r10
000018be: b3 04 00 0a           bra b32 $r0 0x0 ne 0x18c8
000018c2: 02 01                 mov $r2 0x1
000018c4: 3e cf 18 00           lbra 0x18cf
000018c8: a6 a5               B cmp b32 $r10 $r5
000018ca: f4 0b 05              bra e 0x18cf
000018cd: bd 24                 clear b32 $r2
000018cf: 90 00 01            B add b32 $r0 $r0 0x1
000018d2: b8 11 00 80 00        add b32 $r1 $r1 0x8000
000018d7: 90 44 04              add b32 $r4 $r4 0x4
000018da: b2 a5                 mov b32 $r5 $r10
000018dc: bf 69               B ld b32 $r9 D[$r6]
000018de: b2 1a                 mov b32 $r10 $r1
000018e0: a6 09                 cmp b32 $r0 $r9
000018e2: f4 08 d3              bra b 0x18b5
000018e5: b3 24 00 1c           bra b32 $r2 0x0 ne 0x1901
000018e9: bd 14                 clear b32 $r1
000018eb: 80 34 1b 50           mov $r0 0x501b34
000018ef: 85 a0 14 00           mov $r5 0x14a0
000018f3: d4 ff ff ff 9f        mov $r4 0x9fffffff
000018f8: d2 00 00 00 80        mov $r2 0x80000000
000018fd: 3e 68 19 00           lbra 0x1968
00001901: bd 14               B clear b32 $r1
00001903: 80 34 1b 50           mov $r0 0x501b34
00001907: 85 a0 14 00           mov $r5 0x14a0
0000190b: d4 ff ff ff 9f        mov $r4 0x9fffffff
00001910: d2 ff ff ff 7f        mov $r2 0x7fffffff
00001915: bf 59               B ld b32 $r9 D[$r5]
00001917: b2 0a                 mov b32 $r10 $r0
00001919: a6 19                 cmp b32 $r1 $r9
0000191b: f4 18 56              bra ae 0x1971
0000191e: 7e 97 02 00           lcall 0x297
00001922: bf 39                 ld b32 $r9 D[$r3]
00001924: ff a4 b4              and $r11 $r10 $r4
00001927: 90 11 01              add b32 $r1 $r1 0x1
0000192a: b2 0a                 mov b32 $r10 $r0
0000192c: b6 94 1d              shl b32 $r9 0x1d
0000192f: 90 33 04              add b32 $r3 $r3 0x4
00001932: fd b9 05              or $r11 $r9
00001935: b8 00 00 80 00        add b32 $r0 $r0 0x8000
0000193a: fd b2 04              and $r11 $r2
0000193d: 7e 37 02 00           lcall 0x237
00001941: 3e 15 19 00           lbra 0x1915
00001945: 7e 97 02 00         B lcall 0x297
00001949: bf 3b                 ld b32 $r11 D[$r3]
0000194b: fd a4 04              and $r10 $r4
0000194e: 90 11 01              add b32 $r1 $r1 0x1
00001951: 90 33 04              add b32 $r3 $r3 0x4
00001954: b6 b4 1d              shl b32 $r11 0x1d
00001957: fd b2 05              or $r11 $r2
0000195a: fd ba 05              or $r11 $r10
0000195d: b2 0a                 mov b32 $r10 $r0
0000195f: b8 00 00 80 00        add b32 $r0 $r0 0x8000
00001964: 7e 37 02 00           lcall 0x237
00001968: bf 59               B ld b32 $r9 D[$r5]
0000196a: b2 0a                 mov b32 $r10 $r0
0000196c: a6 19                 cmp b32 $r1 $r9
0000196e: f4 08 d7              bra b 0x1945
00001971: fb 61               B mpopret $r6

00001973: f9 22              C  mpush $r2
00001975: df 00 00 00 01        mov $r15 0x1000000
0000197a: f4 30 fc              add $sp -0x4
0000197d: 89 00 14 02           mov $r9 0x21400
00001981: fa 9f 00              iowr I[$r9] $r15
00001984: 89 0c 13 00           mov $r9 0x130c
00001988: bf 99                 ld b32 $r9 D[$r9]
0000198a: b3 94 02 59           bra b32 $r9 0x2 ne 0x19e3
0000198e: 42 f0 3f              mov $r2 0x3ff0
00001991: 8a 9c 00 26           mov $r10 0x26009c
00001995: 0b 01                 mov $r11 0x1
00001997: 0c 16                 mov $r12 0x16
00001999: bd d4                 clear b32 $r13
0000199b: bd e4                 clear b32 $r14
0000199d: b0 21 00              st b32 D[$sp] $r2
000019a0: 7e 9f 03 00           lcall 0x39f
000019a4: 81 a4 14 00           mov $r1 0x14a4
000019a8: bf 1b                 ld b32 $r11 D[$r1]
000019aa: bd 04                 clear b32 $r0
000019ac: 8a 9c 00 20           mov $r10 0x20009c
000019b0: 0c 0c                 mov $r12 0xc
000019b2: bd d4                 clear b32 $r13
000019b4: bd e4                 clear b32 $r14
000019b6: b0 01 00              st b32 D[$sp] $r0
000019b9: 7e 9f 03 00           lcall 0x39f
000019bd: 8a 6c 00 26           mov $r10 0x26006c
000019c1: 0b 01                 mov $r11 0x1
000019c3: 0c 16                 mov $r12 0x16
000019c5: 0d ff                 mov $r13 -0x1
000019c7: bd e4                 clear b32 $r14
000019c9: b0 21 00              st b32 D[$sp] $r2
000019cc: 7e 9f 03 00           lcall 0x39f
000019d0: bf 1b                 ld b32 $r11 D[$r1]
000019d2: b0 01 00              st b32 D[$sp] $r0
000019d5: 8a 6c 00 20           mov $r10 0x20006c
000019d9: 0c 0c                 mov $r12 0xc
000019db: 0d ff                 mov $r13 -0x1
000019dd: bd e4                 clear b32 $r14
000019df: 7e 9f 03 00           lcall 0x39f
000019e3: df 00 00 00 01      B mov $r15 0x1000000
000019e8: 89 00 1a 02           mov $r9 0x21a00
000019ec: fa 9f 00              iowr I[$r9] $r15
000019ef: f4 30 04              add $sp 0x4
000019f2: fb 21                 mpopret $r2
000019f4: f8 00                 ret

000019f6: 89 0c 13 00        C  mov $r9 0x130c
000019fa: bf 99                 ld b32 $r9 D[$r9]
000019fc: 92 99 01              sub b32 $r9 $r9 0x1
000019ff: b0 96 01              cmp b32 $r9 0x1
00001a02: f4 0c 3e              bra a 0x1a40
00001a05: 8f 00 0e 00           mov $r15 0xe00
00001a09: 98 fe 25              ld b32 $r14 D[$r15+0x94]
00001a0c: 98 ff 0b              ld b32 $r15 D[$r15+0x2c]
00001a0f: 89 fc 12 00           mov $r9 0x12fc
00001a13: c4 bd 3f              and $r13 $r11 0x3f
00001a16: b6 d4 18              shl b32 $r13 0x18
00001a19: a0 9f                 st b32 D[$r9] $r15
00001a1b: 89 ff ff 01           mov $r9 0x1ffff
00001a1f: c4 af 3f              and $r15 $r10 0x3f
00001a22: fd e9 04              and $r14 $r9
00001a25: b6 f4 10              shl b32 $r15 0x10
00001a28: 89 00 13 00           mov $r9 0x1300
00001a2c: a0 9e                 st b32 D[$r9] $r14
00001a2e: 90 a9 40              add b32 $r9 $r10 0x40
00001a31: f0 94 ff              and $r9 0xff
00001a34: fd 9f 05              or $r9 $r15
00001a37: 8f 04 13 00           mov $r15 0x1304
00001a3b: fd 9d 05              or $r9 $r13
00001a3e: a0 f9                 st b32 D[$r15] $r9
00001a40: f8 00               B ret

00001a42: 8c 00 0e 00        C  mov $r12 0xe00
00001a46: 98 c9 0a              ld b32 $r9 D[$r12+0x28]
00001a49: 8f 10 13 00           mov $r15 0x1310
00001a4d: c7 9e 43              extr $r14 $r9 0x3:0x5
00001a50: f0 94 07              and $r9 0x7
00001a53: a0 fe                 st b32 D[$r15] $r14
00001a55: 8f 0c 13 00           mov $r15 0x130c
00001a59: a0 f9                 st b32 D[$r15] $r9
00001a5b: 92 99 01              sub b32 $r9 $r9 0x1
00001a5e: b0 96 01              cmp b32 $r9 0x1
00001a61: f4 0c 3a              bra a 0x1a9b
00001a64: 98 cf 25              ld b32 $r15 D[$r12+0x94]
00001a67: 98 cc 0b              ld b32 $r12 D[$r12+0x2c]
00001a6a: 89 fc 12 00           mov $r9 0x12fc
00001a6e: c4 ae 3f              and $r14 $r10 0x3f
00001a71: c4 bd 3f              and $r13 $r11 0x3f
00001a74: a0 9c                 st b32 D[$r9] $r12
00001a76: 89 ff ff 01           mov $r9 0x1ffff
00001a7a: fd f9 04              and $r15 $r9
00001a7d: 89 00 13 00           mov $r9 0x1300
00001a81: b6 e4 10              shl b32 $r14 0x10
00001a84: a0 9f                 st b32 D[$r9] $r15
00001a86: b6 d4 18              shl b32 $r13 0x18
00001a89: 90 a9 40              add b32 $r9 $r10 0x40
00001a8c: 8f 04 13 00           mov $r15 0x1304
00001a90: f0 94 ff              and $r9 0xff
00001a93: fd 9e 05              or $r9 $r14
00001a96: fd 9d 05              or $r9 $r13
00001a99: a0 f9                 st b32 D[$r15] $r9
00001a9b: f8 00               B ret
00001a9d: f9 82                 mpush $r8
00001a9f: df 00 00 00 20        mov $r15 0x20000000
00001aa4: 89 00 14 02           mov $r9 0x21400
00001aa8: fa 9f 00              iowr I[$r9] $r15
00001aab: bd 54                 clear b32 $r5
00001aad: d7 38 08 82 00        mov $r7 0x820838
00001ab2: 86 14 26 50           mov $r6 0x502614
00001ab6: 84 c0 c0 10           mov $r4 0x10c0c0
00001aba: 08 01                 mov $r8 0x1
00001abc: 3e d2 1b 00           lbra 0x1bd2
00001ac0: b2 6a               B mov b32 $r10 $r6
00001ac2: 4b 00 08              mov $r11 0x800
00001ac5: 7e 37 02 00           lcall 0x237
00001ac9: c4 59 01              and $r9 $r5 0x1
00001acc: 95 5f 01              shr b32 $r15 $r5 0x1
00001acf: b3 94 00 18           bra b32 $r9 0x0 ne 0x1ae7
00001ad3: 94 f9 02              shl b32 $r9 $r15 0x2
00001ad6: 8f 40 0e 00           mov $r15 0xe40
00001ada: bc 9f 90              add b32 $r9 $r9 $r15
00001add: bf 99                 ld b32 $r9 D[$r9]
00001adf: e4 93 ff ff           and $r3 $r9 0xffff
00001ae3: 3e f6 1a 00           lbra 0x1af6
00001ae7: 94 f9 02            B shl b32 $r9 $r15 0x2
00001aea: 8f 40 0e 00           mov $r15 0xe40
00001aee: bc 9f 90              add b32 $r9 $r9 $r15
00001af1: bf 99                 ld b32 $r9 D[$r9]
00001af3: 95 93 10              shr b32 $r3 $r9 0x10
00001af6: bd d4               B clear b32 $r13
00001af8: bd b4                 clear b32 $r11
00001afa: bd 24                 clear b32 $r2
00001afc: bd 14                 clear b32 $r1
00001afe: bd e4                 clear b32 $r14
00001b00: bc 8e 94            B shl b32 $r9 $r8 $r14
00001b03: ff 9b a5              or $r10 $r9 $r11
00001b06: 09 02                 mov $r9 0x2
00001b08: bb 9e 04              shl b32 $r9 $r14
00001b0b: ff 92 c5              or $r12 $r9 $r2
00001b0e: 09 07                 mov $r9 0x7
00001b10: bb 9e 04              shl b32 $r9 $r14
00001b13: bc 8d f4              shl b32 $r15 $r8 $r13
00001b16: fd 19 05              or $r1 $r9
00001b19: fd f3 04              and $r15 $r3
00001b1c: 09 03                 mov $r9 0x3
00001b1e: bb 9e 04              shl b32 $r9 $r14
00001b21: ff 9b b5              or $r11 $r9 $r11
00001b24: b3 f4 00 08           bra b32 $r15 0x0 ne 0x1b2c
00001b28: b2 c2                 mov b32 $r2 $r12
00001b2a: b2 ab                 mov b32 $r11 $r10
00001b2c: 90 dd 01            B add b32 $r13 $r13 0x1
00001b2f: 90 ee 04              add b32 $r14 $r14 0x4
00001b32: b3 d4 06 ce           bra b32 $r13 0x6 ne 0x1b00
00001b36: 92 4a 0c              sub b32 $r10 $r4 0xc
00001b39: bd c4                 clear b32 $r12
00001b3b: 0d 01                 mov $r13 0x1
00001b3d: 92 40 08              sub b32 $r0 $r4 0x8
00001b40: 7e 2f 02 00           lcall 0x22f
00001b44: b2 0a               B mov b32 $r10 $r0
00001b46: 7e 97 02 00           lcall 0x297
00001b4a: fd a2 06              xor $r10 $r2
00001b4d: fd a1 04              and $r10 $r1
00001b50: f4 1b f4              bra ne 0x1b44
00001b53: bd d4                 clear b32 $r13
00001b55: bd b4                 clear b32 $r11
00001b57: bd 14                 clear b32 $r1
00001b59: bd 04                 clear b32 $r0
00001b5b: bd e4                 clear b32 $r14
00001b5d: bc 8e 94            B shl b32 $r9 $r8 $r14
00001b60: ff 9b a5              or $r10 $r9 $r11
00001b63: 09 02                 mov $r9 0x2
00001b65: bb 9e 04              shl b32 $r9 $r14
00001b68: ff 91 c5              or $r12 $r9 $r1
00001b6b: 09 07                 mov $r9 0x7
00001b6d: bb 9e 04              shl b32 $r9 $r14
00001b70: bc 8d f4              shl b32 $r15 $r8 $r13
00001b73: fd 09 05              or $r0 $r9
00001b76: fd f3 04              and $r15 $r3
00001b79: 09 03                 mov $r9 0x3
00001b7b: bb 9e 04              shl b32 $r9 $r14
00001b7e: ff 9b b5              or $r11 $r9 $r11
00001b81: b3 f4 00 08           bra b32 $r15 0x0 ne 0x1b89
00001b85: b2 c1                 mov b32 $r1 $r12
00001b87: b2 ab                 mov b32 $r11 $r10
00001b89: 90 dd 01            B add b32 $r13 $r13 0x1
00001b8c: 90 ee 04              add b32 $r14 $r14 0x4
00001b8f: b3 d4 06 ce           bra b32 $r13 0x6 ne 0x1b5d
00001b93: 92 4a 04              sub b32 $r10 $r4 0x4
00001b96: bd c4                 clear b32 $r12
00001b98: 0d 01                 mov $r13 0x1
00001b9a: 7e 2f 02 00           lcall 0x22f
00001b9e: b2 4a               B mov b32 $r10 $r4
00001ba0: 7e 97 02 00           lcall 0x297
00001ba4: fd a1 06              xor $r10 $r1
00001ba7: fd a0 04              and $r10 $r0
00001baa: f4 1b f4              bra ne 0x1b9e
00001bad: b2 7a                 mov b32 $r10 $r7
00001baf: b2 3b                 mov b32 $r11 $r3
00001bb1: bd c4                 clear b32 $r12
00001bb3: 0d 01                 mov $r13 0x1
00001bb5: 7e 2f 02 00           lcall 0x22f
00001bb9: b2 6a                 mov b32 $r10 $r6
00001bbb: 90 55 01              add b32 $r5 $r5 0x1
00001bbe: 90 77 04              add b32 $r7 $r7 0x4
00001bc1: b8 66 00 80 00        add b32 $r6 $r6 0x8000
00001bc6: b8 44 00 01 00        add b32 $r4 $r4 0x100
00001bcb: 4b 20 0a              mov $r11 0xa20
00001bce: 7e 37 02 00           lcall 0x237
00001bd2: 8f a0 14 00         B mov $r15 0x14a0
00001bd6: bf f9                 ld b32 $r9 D[$r15]
00001bd8: a6 59                 cmp b32 $r5 $r9
00001bda: f5 08 e6 fe           bra b 0x1ac0
00001bde: df 00 00 00 20        mov $r15 0x20000000
00001be3: 89 00 1a 02           mov $r9 0x21a00
00001be7: fa 9f 00              iowr I[$r9] $r15
00001bea: fb 81                 mpopret $r8

00001bec: df 00 00 80 00     C  mov $r15 0x800000
00001bf1: 89 00 12 02           mov $r9 0x21200
00001bf5: fa 9f 00              iowr I[$r9] $r15
00001bf8: 89 a0 14 00           mov $r9 0x14a0
00001bfc: bf 99                 ld b32 $r9 D[$r9]
00001bfe: 8f 0c 16 00           mov $r15 0x160c
00001c02: 4e 00 03              mov $r14 0x300
00001c05: a0 fe                 st b32 D[$r15] $r14
00001c07: 94 9f 0c              shl b32 $r15 $r9 0xc
00001c0a: b6 94 08              shl b32 $r9 0x8
00001c0d: bc 9f 90              add b32 $r9 $r9 $r15
00001c10: 8f 08 16 00           mov $r15 0x1608
00001c14: bc 9e 90              add b32 $r9 $r9 $r14
00001c17: 4e 00 11              mov $r14 0x1100
00001c1a: a0 fe                 st b32 D[$r15] $r14
00001c1c: 8f 00 00 02           mov $r15 0x20000
00001c20: fa f9 00              iowr I[$r15] $r9
00001c23: df 00 00 80 00        mov $r15 0x800000
00001c28: 89 00 18 02           mov $r9 0x21800
00001c2c: fa 9f 00              iowr I[$r9] $r15
00001c2f: f8 00                 ret

00001c31: df 00 00 00 01     C  mov $r15 0x1000000
00001c36: 89 00 12 02           mov $r9 0x21200
00001c3a: fa 9f 00              iowr I[$r9] $r15
00001c3d: bd f4                 clear b32 $r15
00001c3f: b8 99 00 0e 02        sub b32 $r9 $r9 0xe00
00001c44: ff 9f 9f              iord $r9 I[$r9+$r15*0x4]
00001c47: 8f 10 16 00           mov $r15 0x1610
00001c4b: a0 f9                 st b32 D[$r15] $r9
00001c4d: 0f 01                 mov $r15 0x1
00001c4f: 89 00 00 02           mov $r9 0x20000
00001c53: fa 9f 00              iowr I[$r9] $r15
00001c56: df 00 00 00 01        mov $r15 0x1000000
00001c5b: b8 99 00 18 00        add b32 $r9 $r9 0x1800
00001c60: fa 9f 00              iowr I[$r9] $r15
00001c63: f8 00                 ret
00001c65: f9 90                 push $r9
00001c67: f9 a0                 push $r10
00001c69: f9 b0                 push $r11
00001c6b: f9 c0                 push $r12
00001c6d: f9 d0                 push $r13
00001c6f: f9 e0                 push $r14
00001c71: f9 f0                 push $r15
00001c73: fe 8a 01              mov $r10 $flags
00001c76: f9 a0                 push $r10
00001c78: 7e 81 1d 00           lcall 0x1d81
00001c7c: fc a0                 pop $r10
00001c7e: fe a8 00              mov $flags $r10
00001c81: f4 32 02              bclr $flags $p2
00001c84: fc f0                 pop $r15
00001c86: fc e0                 pop $r14
00001c88: fc d0                 pop $r13
00001c8a: fc c0                 pop $r12
00001c8c: fc b0                 pop $r11
00001c8e: fc a0                 pop $r10
00001c90: fc 90                 pop $r9
00001c92: f8 01                 iret
00001c94: f8 00                 ret

00001c96: df 00 00 00 20     C  mov $r15 0x20000000
00001c9b: 89 00 12 02           mov $r9 0x21200
00001c9f: fa 9f 00              iowr I[$r9] $r15
00001ca2: 8e fc 15 00           mov $r14 0x15fc
00001ca6: 8d f8 15 00           mov $r13 0x15f8
00001caa: bf ef                 ld b32 $r15 D[$r14]
00001cac: bf d9                 ld b32 $r9 D[$r13]
00001cae: fd 9f 06              xor $r9 $r15
00001cb1: f0 94 07              and $r9 0x7
00001cb4: f4 1b 1c              bra ne 0x1cd0
00001cb7: bf ef                 ld b32 $r15 D[$r14]
00001cb9: bf d9                 ld b32 $r9 D[$r13]
00001cbb: c7 ff 03              extr $r15 $r15 0x3:0x3
00001cbe: c7 99 03              extr $r9 $r9 0x3:0x3
00001cc1: a6 f9                 cmp b32 $r15 $r9
00001cc3: f4 0b 0d              bra e 0x1cd0
00001cc6: 0a 13                 mov $r10 0x13
00001cc8: 7e c0 05 00           lcall 0x5c0
00001ccc: 3e 04 1d 00           lbra 0x1d04
00001cd0: 8d fc 15 00         B mov $r13 0x15fc
00001cd4: bf d9                 ld b32 $r9 D[$r13]
00001cd6: bf df                 ld b32 $r15 D[$r13]
00001cd8: bf de                 ld b32 $r14 D[$r13]
00001cda: 8c b8 15 00           mov $r12 0x15b8
00001cde: f0 94 07              and $r9 0x7
00001ce1: b6 94 03              shl b32 $r9 0x3
00001ce4: 90 ee 01              add b32 $r14 $r14 0x1
00001ce7: bc 9c 90              add b32 $r9 $r9 $r12
00001cea: a0 9a                 st b32 D[$r9] $r10
00001cec: a0 de                 st b32 D[$r13] $r14
00001cee: bf de                 ld b32 $r14 D[$r13]
00001cf0: f0 f4 07              and $r15 0x7
00001cf3: bc ff f0              add b32 $r15 $r15 $r15
00001cf6: 90 ff 01              add b32 $r15 $r15 0x1
00001cf9: bc cb f9              st b32 D[$r12+$r15*0x4] $r11
00001cfc: b3 e4 10 08           bra b32 $r14 0x10 ne 0x1d04
00001d00: bd 94                 clear b32 $r9
00001d02: a0 d9                 st b32 D[$r13] $r9
00001d04: df 00 00 00 20      B mov $r15 0x20000000
00001d09: 89 00 18 02           mov $r9 0x21800
00001d0d: fa 9f 00              iowr I[$r9] $r15
00001d10: f8 00                 ret

00001d12: 89 ff 0f ff        C  mov $r9 -0xf001
00001d16: b2 ae                 mov b32 $r14 $r10
00001d18: ff a9 f4              and $r15 $r10 $r9
00001d1b: b2 bd                 mov b32 $r13 $r11
00001d1d: b0 f6 3a              cmp b32 $r15 0x3a
00001d20: f4 0c 20              bra a 0x1d40
00001d23: b0 f6 38              cmp b32 $r15 0x38
00001d26: f4 18 41              bra ae 0x1d67
00001d29: b3 f0 04 3e           bra b32 $r15 0x4 e 0x1d67
00001d2d: b0 f6 04              cmp b32 $r15 0x4
00001d30: f4 08 47              bra b 0x1d77
00001d33: 92 f9 2c              sub b32 $r9 $r15 0x2c
00001d36: b0 96 01              cmp b32 $r9 0x1
00001d39: f4 0c 3e              bra a 0x1d77
00001d3c: 3e 67 1d 00           lbra 0x1d67
00001d40: 89 02 00 01         B mov $r9 0x10002
00001d44: a6 f9                 cmp b32 $r15 $r9
00001d46: f4 0b 2b              bra e 0x1d71
00001d49: a6 f9                 cmp b32 $r15 $r9
00001d4b: f4 0c 0b              bra a 0x1d56
00001d4e: b3 f4 3c 29           bra b32 $r15 0x3c ne 0x1d77
00001d52: 3e 67 1d 00           lbra 0x1d67
00001d56: 89 03 00 01         B mov $r9 0x10003
00001d5a: a6 f9                 cmp b32 $r15 $r9
00001d5c: f4 0b 0b              bra e 0x1d67
00001d5f: 90 99 04              add b32 $r9 $r9 0x4
00001d62: a6 f9                 cmp b32 $r15 $r9
00001d64: f4 1b 13              bra ne 0x1d77
00001d67: b2 ea               B mov b32 $r10 $r14
00001d69: b2 db                 mov b32 $r11 $r13
00001d6b: 7e 81 06 00           lcall 0x681
00001d6f: f8 00                 ret
00001d71: 7e 96 1c 00         B lcall 0x1c96
00001d75: f8 00                 ret
00001d77: b2 ea               B mov b32 $r10 $r14
00001d79: b2 db                 mov b32 $r11 $r13
00001d7b: 7e 0b 06 00           lcall 0x60b
00001d7f: f8 00                 ret

00001d81: f9 12              C  mpush $r1
00001d83: bd f4                 clear b32 $r15
00001d85: 49 00 02              mov $r9 0x200
00001d88: ff 9f 1f              iord $r1 I[$r9+$r15*0x4]
00001d8b: c4 19 04              and $r9 $r1 0x4
00001d8e: f4 0b 1b              bra e 0x1da9
00001d91: 4a 00 1a              mov $r10 0x1a00
00001d94: ff af af              iord $r10 I[$r10+$r15*0x4]
00001d97: 4b 00 19              mov $r11 0x1900
00001d9a: ff bf bf              iord $r11 I[$r11+$r15*0x4]
00001d9d: 7e 12 1d 00           lcall 0x1d12
00001da1: 0f 01                 mov $r15 0x1
00001da3: 49 00 1d              mov $r9 0x1d00
00001da6: fa 9f 00              iowr I[$r9] $r15
00001da9: 95 19 08            B shr b32 $r9 $r1 0x8
00001dac: c4 90 ff              and $r0 $r9 0xff
00001daf: f4 0b 63              bra e 0x1e12
00001db2: f0 94 01              and $r9 0x1
00001db5: f4 0b 0d              bra e 0x1dc2
00001db8: 8a 00 00 01           mov $r10 0x10000
00001dbc: bd b4                 clear b32 $r11
00001dbe: 7e 0b 06 00           lcall 0x60b
00001dc2: c4 09 02            B and $r9 $r0 0x2
00001dc5: f4 0b 0b              bra e 0x1dd0
00001dc8: 0a 04                 mov $r10 0x4
00001dca: bd b4                 clear b32 $r11
00001dcc: 7e 81 06 00           lcall 0x681
00001dd0: c4 09 08            B and $r9 $r0 0x8
00001dd3: f4 0b 07              bra e 0x1dda
00001dd6: 7e f7 06 00           lcall 0x6f7
00001dda: c4 09 04            B and $r9 $r0 0x4
00001ddd: f4 0b 0d              bra e 0x1dea
00001de0: 8a 02 00 01           mov $r10 0x10002
00001de4: 0b 01                 mov $r11 0x1
00001de6: 7e 96 1c 00           lcall 0x1c96
00001dea: c4 09 80            B and $r9 $r0 0x80
00001ded: 33 90 00 0e           bra b8 $r9 0x0 e 0x1dfb
00001df1: 8a 03 00 01           mov $r10 0x10003
00001df5: bd b4                 clear b32 $r11
00001df7: 7e 81 06 00           lcall 0x681
00001dfb: c4 09 40            B and $r9 $r0 0x40
00001dfe: f4 0b 0d              bra e 0x1e0b
00001e01: 8a 07 00 01           mov $r10 0x10007
00001e05: bd b4                 clear b32 $r11
00001e07: 7e 81 06 00           lcall 0x681
00001e0b: 89 00 0d 01         B mov $r9 0x10d00
00001e0f: fa 90 00              iowr I[$r9] $r0
00001e12: 49 00 01            B mov $r9 0x100
00001e15: fa 91 00              iowr I[$r9] $r1
00001e18: fb 11                 mpopret $r1

00001e1a: 8a 6c e2 17        C  mov $r10 0x17e26c
00001e1e: 7e 97 02 00           lcall 0x297
00001e22: bd c4                 clear b32 $r12
00001e24: c5 ab 04              or $r11 $r10 0x4
00001e27: 0d 01                 mov $r13 0x1
00001e29: 8a 6c e2 17           mov $r10 0x17e26c
00001e2d: 7e 2f 02 00           lcall 0x22f
00001e31: f8 00                 ret
00001e33: df 00 00 00 10        mov $r15 0x10000000
00001e38: 89 00 12 02           mov $r9 0x21200
00001e3c: fa 9f 00              iowr I[$r9] $r15
00001e3f: 89 f0 13 00           mov $r9 0x13f0
00001e43: 0f 01                 mov $r15 0x1
00001e45: a0 9f                 st b32 D[$r9] $r15
00001e47: 89 00 00 02           mov $r9 0x20000
00001e4b: fa 9f 00              iowr I[$r9] $r15
00001e4e: df 00 00 00 10        mov $r15 0x10000000
00001e53: b8 99 00 18 00        add b32 $r9 $r9 0x1800
00001e58: fa 9f 00              iowr I[$r9] $r15
00001e5b: f8 00                 ret
00001e5d: f8 00                 ret

00001e5f: f9 02              C  mpush $r0
00001e61: 89 40 a1 00           mov $r9 0xa140
00001e65: a6 c9                 cmp b32 $r12 $r9
00001e67: f4 0b 28              bra e 0x1e8f
00001e6a: a6 c9                 cmp b32 $r12 $r9
00001e6c: f4 0c 0c              bra a 0x1e78
00001e6f: b8 99 13 11 02        sub b32 $r9 $r9 0x1113
00001e74: 3e 84 1e 00           lbra 0x1e84
00001e78: 89 97 c9 00         B mov $r9 0xc997
00001e7c: a6 c9                 cmp b32 $r12 $r9
00001e7e: f4 0b 11              bra e 0x1e8f
00001e81: 90 99 29              add b32 $r9 $r9 0x29
00001e84: a6 c9               B cmp b32 $r12 $r9
00001e86: f4 0b 09              bra e 0x1e8f
00001e89: bd 04                 clear b32 $r0
00001e8b: 3e b3 1e 00           lbra 0x1eb3
00001e8f: e4 ce ff ff         B and $r14 $r12 0xffff
00001e93: b8 af 00 0d 00        add b32 $r15 $r10 0xd00
00001e98: f0 d4 01              and $r13 0x1
00001e9b: f1 f4 ff 0f           and $r15 0xfff
00001e9f: b6 d4 1d              shl b32 $r13 0x1d
00001ea2: b6 f4 10              shl b32 $r15 0x10
00001ea5: d9 00 00 00 80        mov $r9 0x80000000
00001eaa: fd e9 05              or $r14 $r9
00001ead: fd ef 05              or $r14 $r15
00001eb0: ff ed 05              or $r0 $r14 $r13
00001eb3: 8a 8c 44 40         B mov $r10 0x40448c
00001eb7: 7e 37 02 00           lcall 0x237
00001ebb: b2 0b                 mov b32 $r11 $r0
00001ebd: 8a 88 44 40           mov $r10 0x404488
00001ec1: d0 00 00 00 80        mov $r0 0x80000000
00001ec6: 7e 37 02 00           lcall 0x237
00001eca: 8a 88 44 40         B mov $r10 0x404488
00001ece: 7e 97 02 00           lcall 0x297
00001ed2: fd a0 04              and $r10 $r0
00001ed5: f4 1b f5              bra ne 0x1eca
00001ed8: fb 01                 mpopret $r0

00001eda: f9 02              C  mpush $r0
00001edc: 89 40 a1 00           mov $r9 0xa140
00001ee0: a6 b9                 cmp b32 $r11 $r9
00001ee2: f4 0b 28              bra e 0x1f0a
00001ee5: a6 b9                 cmp b32 $r11 $r9
00001ee7: f4 0c 0c              bra a 0x1ef3
00001eea: b8 99 13 11 02        sub b32 $r9 $r9 0x1113
00001eef: 3e ff 1e 00           lbra 0x1eff
00001ef3: 89 97 c9 00         B mov $r9 0xc997
00001ef7: a6 b9                 cmp b32 $r11 $r9
00001ef9: f4 0b 11              bra e 0x1f0a
00001efc: 90 99 29              add b32 $r9 $r9 0x29
00001eff: a6 b9               B cmp b32 $r11 $r9
00001f01: f4 0b 09              bra e 0x1f0a
00001f04: bd b4                 clear b32 $r11
00001f06: 3e 2e 1f 00           lbra 0x1f2e
00001f0a: e4 be ff ff         B and $r14 $r11 0xffff
00001f0e: c4 cd 01              and $r13 $r12 0x1
00001f11: b8 af 00 0d 00        add b32 $r15 $r10 0xd00
00001f16: b6 d4 1d              shl b32 $r13 0x1d
00001f19: f1 f4 ff 0f           and $r15 0xfff
00001f1d: d9 00 00 00 40        mov $r9 0x40000000
00001f22: b6 f4 10              shl b32 $r15 0x10
00001f25: fd e9 05              or $r14 $r9
00001f28: fd ed 05              or $r14 $r13
00001f2b: ff ef b5              or $r11 $r14 $r15
00001f2e: 8a 88 44 40         B mov $r10 0x404488
00001f32: d0 00 00 00 40        mov $r0 0x40000000
00001f37: 7e 37 02 00           lcall 0x237
00001f3b: 8a 88 44 40         B mov $r10 0x404488
00001f3f: 7e 97 02 00           lcall 0x297
00001f43: fd a0 04              and $r10 $r0
00001f46: f4 1b f5              bra ne 0x1f3b
00001f49: 8a 8c 44 40           mov $r10 0x40448c
00001f4d: 7e 97 02 00           lcall 0x297
00001f51: fb 01                 mpopret $r0

00001f53: 89 f0 13 00        C  mov $r9 0x13f0
00001f57: bf 99                 ld b32 $r9 D[$r9]
00001f59: 0a 01                 mov $r10 0x1
00001f5b: b3 94 00 23           bra b32 $r9 0x0 ne 0x1f7e
00001f5f: 89 00 0e 00           mov $r9 0xe00
00001f63: 98 9e 0f              ld b32 $r14 D[$r9+0x3c]
00001f66: 0f 3c                 mov $r15 0x3c
00001f68: 89 00 06 02           mov $r9 0x20600
00001f6c: c7 ea 03              extr $r10 $r14 0x3:0x3
00001f6f: fa 9f 00              iowr I[$r9] $r15
00001f72: fa 9e 00              iowr I[$r9] $r14
00001f75: b3 a4 00 09           bra b32 $r10 0x0 ne 0x1f7e
00001f79: 0f 02                 mov $r15 0x2
00001f7b: fa 9f 00              iowr I[$r9] $r15
00001f7e: f8 00               B ret

00001f80: db 00 00 00 40     C  mov $r11 0x40000000
00001f85: 8a 48 44 50           mov $r10 0x504448
00001f89: 7e 37 02 00           lcall 0x237
00001f8d: 8a 48 44 50           mov $r10 0x504448
00001f91: 7e 97 02 00           lcall 0x297
00001f95: d9 ff ff ff 00        mov $r9 0xffffff
00001f9a: fd a9 04              and $r10 $r9
00001f9d: 90 aa 10              add b32 $r10 $r10 0x10
00001fa0: f0 a4 3f              and $r10 0x3f
00001fa3: db 00 00 00 80        mov $r11 0x80000000
00001fa8: ff ab b5              or $r11 $r10 $r11
00001fab: 8a 48 9c 41           mov $r10 0x419c48
00001faf: 7e 37 02 00           lcall 0x237
00001fb3: 8a c4 41 40           mov $r10 0x4041c4
00001fb7: 4b 00 30              mov $r11 0x3000
00001fba: 7e 37 02 00           lcall 0x237
00001fbe: 0f 08                 mov $r15 0x8
00001fc0: 89 00 c3 02           mov $r9 0x2c300
00001fc4: fa 9f 00              iowr I[$r9] $r15
00001fc7: f8 00                 ret

00001fc9: f9 62              C  mpush $r6
00001fcb: 0f 10                 mov $r15 0x10
00001fcd: 89 00 12 02           mov $r9 0x21200
00001fd1: fa 9f 00              iowr I[$r9] $r15
00001fd4: 85 c4 12 00           mov $r5 0x12c4
00001fd8: 86 b8 13 00           mov $r6 0x13b8
00001fdc: 81 b4 13 00           mov $r1 0x13b4
00001fe0: 84 74 13 00           mov $r4 0x1374
00001fe4: 83 ff 0f ff           mov $r3 -0xf001
00001fe8: 82 07 00 01           mov $r2 0x10007
00001fec: 3e 31 21 00           lbra 0x2131
00001ff0: bf 19               B ld b32 $r9 D[$r1]
00001ff2: bf 1f                 ld b32 $r15 D[$r1]
00001ff4: bf 1e                 ld b32 $r14 D[$r1]
00001ff6: 8c 74 13 00           mov $r12 0x1374
00001ffa: f0 94 07              and $r9 0x7
00001ffd: b6 94 03              shl b32 $r9 0x3
00002000: bc 9c 90              add b32 $r9 $r9 $r12
00002003: 90 ee 01              add b32 $r14 $r14 0x1
00002006: bf 9a                 ld b32 $r10 D[$r9]
00002008: a0 1e                 st b32 D[$r1] $r14
0000200a: bf 19                 ld b32 $r9 D[$r1]
0000200c: f0 f4 07              and $r15 0x7
0000200f: bc ff f0              add b32 $r15 $r15 $r15
00002012: 90 ff 01              add b32 $r15 $r15 0x1
00002015: bc 4f 08              ld b32 $r0 D[$r4+$r15*0x4]
00002018: b3 94 10 06           bra b32 $r9 0x10 ne 0x201e
0000201c: a0 1d                 st b32 D[$r1] $r13
0000201e: fd a3 04            B and $r10 $r3
00002021: b3 a0 38 44           bra b32 $r10 0x38 e 0x2065
00002025: b0 a6 38              cmp b32 $r10 0x38
00002028: f4 0c 16              bra a 0x203e
0000202b: b3 a9 2c a0 00        bra b32 $r10 0x2c e 0x20cb
00002030: b3 a9 2d bd 00        bra b32 $r10 0x2d e 0x20ed
00002035: b3 ad 04 14 01        bra b32 $r10 0x4 ne 0x2149
0000203a: 3e 56 20 00           lbra 0x2056
0000203e: b3 a0 3a 5e         B bra b32 $r10 0x3a e 0x209c
00002042: b0 a6 3a              cmp b32 $r10 0x3a
00002045: f4 08 4b              bra b 0x2090
00002048: b3 a0 3c 6d           bra b32 $r10 0x3c e 0x20b5
0000204c: a6 a2                 cmp b32 $r10 $r2
0000204e: f5 1b fb 00           bra ne 0x2149
00002052: 3e bf 20 00           lbra 0x20bf
00002056: b2 0b               B mov b32 $r11 $r0
00002058: 7e 3d 40 00           lcall 0x403d
0000205c: a6 a0                 cmp b32 $r10 $r0
0000205e: f4 1b 5b              bra ne 0x20b9
00002061: 3e 09 21 00           lbra 0x2109
00002065: 89 b8 12 00         B mov $r9 0x12b8
00002069: bf 99                 ld b32 $r9 D[$r9]
0000206b: b3 94 00 17           bra b32 $r9 0x0 ne 0x2082
0000206f: 8f c8 12 00           mov $r15 0x12c8
00002073: 09 01                 mov $r9 0x1
00002075: a0 f9                 st b32 D[$r15] $r9
00002077: 8f 00 01 02           mov $r15 0x20100
0000207b: fa f9 00              iowr I[$r15] $r9
0000207e: 3e 31 21 00           lbra 0x2131
00002082: b2 0b               B mov b32 $r11 $r0
00002084: 8a 04 00 01           mov $r10 0x10004
00002088: 7e 0b 06 00           lcall 0x60b
0000208c: 3e 31 21 00           lbra 0x2131
00002090: bd f4               B clear b32 $r15
00002092: 89 c8 12 00           mov $r9 0x12c8
00002096: a0 9f                 st b32 D[$r9] $r15
00002098: 3e b9 20 00           lbra 0x20b9
0000209c: 8f 00 0e 00         B mov $r15 0xe00
000020a0: 98 f9 3c              ld b32 $r9 D[$r15+0xf0]
000020a3: a6 09                 cmp b32 $r0 $r9
000020a5: f4 1b 14              bra ne 0x20b9
000020a8: 98 f9 23              ld b32 $r9 D[$r15+0x8c]
000020ab: f0 95 10              or $r9 0x10
000020ae: b5 f9 23              st b32 D[$r15+0x8c] $r9
000020b1: 3e b9 20 00           lbra 0x20b9
000020b5: 7e 7e 3d 00         B lcall 0x3d7e
000020b9: 0f 01               B mov $r15 0x1
000020bb: 3e 2a 21 00           lbra 0x212a
000020bf: b2 0b               B mov b32 $r11 $r0
000020c1: b2 2a                 mov b32 $r10 $r2
000020c3: 7e 80 1f 00           lcall 0x1f80
000020c7: 3e 31 21 00           lbra 0x2131
000020cb: 89 2c 14 00         B mov $r9 0x142c
000020cf: bf 99                 ld b32 $r9 D[$r9]
000020d1: b3 94 00 30           bra b32 $r9 0x0 ne 0x2101
000020d5: 8e 1c 14 00           mov $r14 0x141c
000020d9: bf e9                 ld b32 $r9 D[$r14]
000020db: b3 94 00 26           bra b32 $r9 0x0 ne 0x2101
000020df: 89 14 14 00           mov $r9 0x1414
000020e3: 0f 01                 mov $r15 0x1
000020e5: a0 90                 st b32 D[$r9] $r0
000020e7: a0 ef                 st b32 D[$r14] $r15
000020e9: 3e 2a 21 00           lbra 0x212a
000020ed: 89 2c 14 00         B mov $r9 0x142c
000020f1: bf 99                 ld b32 $r9 D[$r9]
000020f3: b3 94 00 0e           bra b32 $r9 0x0 ne 0x2101
000020f7: 8d 20 14 00           mov $r13 0x1420
000020fb: bf d9                 ld b32 $r9 D[$r13]
000020fd: b3 90 00 12           bra b32 $r9 0x0 e 0x210f
00002101: 0f 01               B mov $r15 0x1
00002103: 89 28 14 00           mov $r9 0x1428
00002107: a0 9f                 st b32 D[$r9] $r15
00002109: 0f 02               B mov $r15 0x2
0000210b: 3e 2a 21 00           lbra 0x212a
0000210f: 8f 18 14 00         B mov $r15 0x1418
00002113: d9 ff ff ff 3f        mov $r9 0x3fffffff
00002118: ff 09 94              and $r9 $r0 $r9
0000211b: 95 0e 1e              shr b32 $r14 $r0 0x1e
0000211e: a0 f9                 st b32 D[$r15] $r9
00002120: 89 24 14 00           mov $r9 0x1424
00002124: 0f 01                 mov $r15 0x1
00002126: a0 9e                 st b32 D[$r9] $r14
00002128: a0 df                 st b32 D[$r13] $r15
0000212a: 89 00 01 02         B mov $r9 0x20100
0000212e: fa 9f 00              iowr I[$r9] $r15
00002131: bf 59               B ld b32 $r9 D[$r5]
00002133: b3 90 00 14           bra b32 $r9 0x0 e 0x2147
00002137: 8f b8 13 00           mov $r15 0x13b8
0000213b: 89 b4 13 00           mov $r9 0x13b4
0000213f: bf fe               B ld b32 $r14 D[$r15]
00002141: bf 9e                 ld b32 $r14 D[$r9]
00002143: 3e 3f 21 00           lbra 0x213f
00002147: bd d4               B clear b32 $r13
00002149: bf 6f               B ld b32 $r15 D[$r6]
0000214b: bf 19                 ld b32 $r9 D[$r1]
0000214d: a6 f9                 cmp b32 $r15 $r9
0000214f: f5 1b a1 fe           bra ne 0x1ff0
00002153: 0f 10                 mov $r15 0x10
00002155: 89 00 18 02           mov $r9 0x21800
00002159: fa 9f 00              iowr I[$r9] $r15
0000215c: fb 61                 mpopret $r6

0000215e: 89 b8 13 00        C  mov $r9 0x13b8
00002162: bf 9f                 ld b32 $r15 D[$r9]
00002164: 89 b4 13 00           mov $r9 0x13b4
00002168: bf 99                 ld b32 $r9 D[$r9]
0000216a: a6 f9                 cmp b32 $r15 $r9
0000216c: f4 0b 07              bra e 0x2173
0000216f: 7e c9 1f 00           lcall 0x1fc9
00002173: f8 00               B ret

00002175: f9 12              C  mpush $r1
00002177: 0f 40                 mov $r15 0x40
00002179: 89 00 14 02           mov $r9 0x21400
0000217d: fa 9f 00              iowr I[$r9] $r15
00002180: 81 00 00 01           mov $r1 0x10000
00002184: bd 04                 clear b32 $r0
00002186: 3e 8e 21 00           lbra 0x218e
0000218a: 7e 5e 21 00         B lcall 0x215e
0000218e: ff 10 9f            B iord $r9 I[$r1+$r0*0x4]
00002191: f0 94 20              and $r9 0x20
00002194: f4 1b f6              bra ne 0x218a
00002197: 0f 40                 mov $r15 0x40
00002199: 89 00 1a 02           mov $r9 0x21a00
0000219d: fa 9f 00              iowr I[$r9] $r15
000021a0: fb 11                 mpopret $r1

000021a2: f9 82              C  mpush $r8
000021a4: 7e 75 21 00           lcall 0x2175
000021a8: 89 24 00 00           mov $r9 0x24
000021ac: bf 9a                 ld b32 $r10 D[$r9]
000021ae: 88 24 03 00           mov $r8 0x324
000021b2: 84 5c 00 00           mov $r4 0x5c
000021b6: bd 34                 clear b32 $r3
000021b8: 7e 14 01 00           lcall 0x114
000021bc: 8a 00 d3 01           mov $r10 0x1d300
000021c0: 4b fe 06              mov $r11 0x6fe
000021c3: 7e 10 00 00           lcall 0x10
000021c7: 89 00 10 00           mov $r9 0x1000
000021cb: 98 9b 03              ld b32 $r11 D[$r9+0xc]
000021ce: 8a 00 c1 01           mov $r10 0x1c100
000021d2: d7 ff ff ff 7f        mov $r7 0x7fffffff
000021d7: d6 00 00 00 7c        mov $r6 0x7c000000
000021dc: f0 b3 00              sethi $r11 0x0
000021df: 7e 10 00 00           lcall 0x10
000021e3: 8a 00 c6 01           mov $r10 0x1c600
000021e7: bd b4                 clear b32 $r11
000021e9: 7e 10 00 00           lcall 0x10
000021ed: 8a 00 c5 01           mov $r10 0x1c500
000021f1: 8b 00 10 03           mov $r11 0x31000
000021f5: 7e 10 00 00           lcall 0x10
000021f9: 3e 3e 22 00           lbra 0x223e
000021fd: bf 49               B ld b32 $r9 D[$r4]
000021ff: b0 96 00              cmp b32 $r9 0x0
00002202: f4 1e 0b              bra l 0x220d
00002205: 82 8c 44 40           mov $r2 0x40448c
00002209: 3e 11 22 00           lbra 0x2211
0000220d: 82 88 44 40         B mov $r2 0x404488
00002211: ff 97 04            B and $r0 $r9 $r7
00002214: ff 26 55              or $r5 $r2 $r6
00002217: b0 06 1f            B cmp b32 $r0 0x1f
0000221a: f4 0c 0f              bra a 0x2229
0000221d: 94 09 1a              shl b32 $r9 $r0 0x1a
00002220: 01 01                 mov $r1 0x1
00002222: ff 92 a5              or $r10 $r9 $r2
00002225: 3e 30 22 00           lbra 0x2230
00002229: 92 00 20            B sub b32 $r0 $r0 0x20
0000222c: b2 5a                 mov b32 $r10 $r5
0000222e: bd 14                 clear b32 $r1
00002230: 7e 7a 00 00         B lcall 0x7a
00002234: b3 10 00 e3           bra b32 $r1 0x0 e 0x2217
00002238: 90 33 01              add b32 $r3 $r3 0x1
0000223b: 90 44 04              add b32 $r4 $r4 0x4
0000223e: bf 89               B ld b32 $r9 D[$r8]
00002240: a6 39                 cmp b32 $r3 $r9
00002242: f4 08 bb              bra b 0x21fd
00002245: 8a 00 c5 01           mov $r10 0x1c500
00002249: 8b 00 10 05           mov $r11 0x51000
0000224d: 7e 10 00 00           lcall 0x10
00002251: 8d 00 c5 01           mov $r13 0x1c500
00002255: bd e4                 clear b32 $r14
00002257: 8f 00 00 04           mov $r15 0x40000
0000225b: ff de 9f            B iord $r9 I[$r13+$r14*0x4]
0000225e: fd 9f 04              and $r9 $r15
00002261: f4 1b fa              bra ne 0x225b
00002264: 7e 75 21 00           lcall 0x2175
00002268: bd f4                 clear b32 $r15
0000226a: 89 00 0c 01           mov $r9 0x10c00
0000226e: fa 9f 00              iowr I[$r9] $r15
00002271: 0f 10                 mov $r15 0x10
00002273: 89 00 00 02           mov $r9 0x20000
00002277: fa 9f 00              iowr I[$r9] $r15
0000227a: fb 81                 mpopret $r8

0000227c: 7e 5e 21 00        CB lcall 0x215e
00002280: 8a 5c a7 24           mov $r10 0x24a75c
00002284: 7e 97 02 00           lcall 0x297
00002288: c4 a9 10              and $r9 $r10 0x10
0000228b: f4 0b f1              bra e 0x227c
0000228e: c4 a9 07              and $r9 $r10 0x7
00002291: f4 1b eb              bra ne 0x227c
00002294: f8 00                 ret

00002296: f9 52              C  mpush $r5
00002298: 81 c8 14 00           mov $r1 0x14c8
0000229c: b3 a0 00 4d           bra b32 $r10 0x0 e 0x22e9
000022a0: b2 14                 mov b32 $r4 $r1
000022a2: bd 34                 clear b32 $r3
000022a4: 82 40 43 50           mov $r2 0x504340
000022a8: 85 a0 14 00           mov $r5 0x14a0
000022ac: 3e da 22 00           lbra 0x22da
000022b0: 7e 5e 21 00         B lcall 0x215e
000022b4: b2 1a               B mov b32 $r10 $r1
000022b6: 7e 97 02 00           lcall 0x297
000022ba: f0 a4 10              and $r10 0x10
000022bd: f4 1b f3              bra ne 0x22b0
000022c0: 90 00 01              add b32 $r0 $r0 0x1
000022c3: b8 11 00 08 00        add b32 $r1 $r1 0x800
000022c8: bf 49               B ld b32 $r9 D[$r4]
000022ca: a6 09                 cmp b32 $r0 $r9
000022cc: f4 08 e8              bra b 0x22b4
000022cf: 90 33 01              add b32 $r3 $r3 0x1
000022d2: b8 22 00 80 00        add b32 $r2 $r2 0x8000
000022d7: 90 44 04              add b32 $r4 $r4 0x4
000022da: bf 59               B ld b32 $r9 D[$r5]
000022dc: a6 39                 cmp b32 $r3 $r9
000022de: f4 18 4a              bra ae 0x2328
000022e1: b2 21                 mov b32 $r1 $r2
000022e3: bd 04                 clear b32 $r0
000022e5: 3e c8 22 00           lbra 0x22c8
000022e9: 89 a0 14 00         B mov $r9 0x14a0
000022ed: bf 9b                 ld b32 $r11 D[$r9]
000022ef: 92 bb 01              sub b32 $r11 $r11 0x1
000022f2: 7e 2b 03 00           lcall 0x32b
000022f6: bc 1a b8              ld b32 $r11 D[$r1+$r10*0x4]
000022f9: b2 a0                 mov b32 $r0 $r10
000022fb: bd a4                 clear b32 $r10
000022fd: b6 04 04              shl b32 $r0 0x4
00002300: 92 bb 01              sub b32 $r11 $r11 0x1
00002303: 7e 2b 03 00           lcall 0x32b
00002307: 89 40 43 50           mov $r9 0x504340
0000230b: bc 0a 00              add b32 $r0 $r0 $r10
0000230e: b6 04 0b              shl b32 $r0 0xb
00002311: bc 09 00              add b32 $r0 $r0 $r9
00002314: 3e 1c 23 00           lbra 0x231c
00002318: 7e 5e 21 00         B lcall 0x215e
0000231c: b2 0a               B mov b32 $r10 $r0
0000231e: 7e 97 02 00           lcall 0x297
00002322: f0 a4 10              and $r10 0x10
00002325: f4 1b f3              bra ne 0x2318
00002328: df 00 00 00 10      B mov $r15 0x10000000
0000232d: 89 00 1a 02           mov $r9 0x21a00
00002331: fa 9f 00              iowr I[$r9] $r15
00002334: fb 51                 mpopret $r5

00002336: 8a 38 22 12        C  mov $r10 0x122238
0000233a: 8b 3e 00 0e           mov $r11 0xe003e
0000233e: bd c4                 clear b32 $r12
00002340: 0d 01                 mov $r13 0x1
00002342: 7e 2f 02 00           lcall 0x22f
00002346: 3e 4e 23 00           lbra 0x234e
0000234a: 7e 5e 21 00         B lcall 0x215e
0000234e: 8a 38 22 12         B mov $r10 0x122238
00002352: 7e 97 02 00           lcall 0x297
00002356: b3 a4 00 f4           bra b32 $r10 0x0 ne 0x234a
0000235a: f8 00                 ret

0000235c: f9 02              C  mpush $r0
0000235e: 8a 30 22 12           mov $r10 0x122230
00002362: 8b 3e 00 0e           mov $r11 0xe003e
00002366: bd c4                 clear b32 $r12
00002368: 0d 01                 mov $r13 0x1
0000236a: 80 3e 00 0e           mov $r0 0xe003e
0000236e: 7e 2f 02 00           lcall 0x22f
00002372: 3e 7a 23 00           lbra 0x237a
00002376: 7e 5e 21 00         B lcall 0x215e
0000237a: 8a 34 22 12         B mov $r10 0x122234
0000237e: 7e 97 02 00           lcall 0x297
00002382: a6 a0                 cmp b32 $r10 $r0
00002384: f4 1b f2              bra ne 0x2376
00002387: 8a fc 19 12           mov $r10 0x1219fc
0000238b: 8b ce e7 0f           mov $r11 0xfe7ce
0000238f: 7e 37 02 00           lcall 0x237
00002393: 8a fc 09 12           mov $r10 0x1209fc
00002397: db ce e7 0f 01        mov $r11 0x10fe7ce
0000239c: 7e 37 02 00           lcall 0x237
000023a0: 8a fc 11 12           mov $r10 0x1211fc
000023a4: db ce e7 0f 02        mov $r11 0x20fe7ce
000023a9: 7e 37 02 00           lcall 0x237
000023ad: fb 01                 mpopret $r0

000023af: 7e 5c 23 00        C  lcall 0x235c
000023b3: 0f 10                 mov $r15 0x10
000023b5: 89 00 85 01           mov $r9 0x18500
000023b9: fa 9f 00              iowr I[$r9] $r15
000023bc: 8a 14 a6 41           mov $r10 0x41a614
000023c0: 4b 20 08              mov $r11 0x820
000023c3: 7e 37 02 00           lcall 0x237
000023c7: bd f4                 clear b32 $r15
000023c9: 89 00 16 00           mov $r9 0x1600
000023cd: a0 9f                 st b32 D[$r9] $r15
000023cf: 4f 10 01              mov $r15 0x110
000023d2: 89 00 85 01           mov $r9 0x18500
000023d6: fa 9f 00              iowr I[$r9] $r15
000023d9: 8a 14 a6 41           mov $r10 0x41a614
000023dd: 4b 20 0a              mov $r11 0xa20
000023e0: 7e 37 02 00           lcall 0x237
000023e4: 7e 36 23 00           lcall 0x2336
000023e8: f8 00                 ret

000023ea: 0a 08              C  mov $r10 0x8
000023ec: 7e af 23 00           lcall 0x23af
000023f0: 4f 00 01              mov $r15 0x100
000023f3: 89 00 00 02           mov $r9 0x20000
000023f7: fa 9f 00              iowr I[$r9] $r15
000023fa: f8 00                 ret

000023fc: f9 12              C  mpush $r1
000023fe: 8f 00 00 01           mov $r15 0x10000
00002402: 89 00 14 02           mov $r9 0x21400
00002406: fa 9f 00              iowr I[$r9] $r15
00002409: 81 00 00 01           mov $r1 0x10000
0000240d: bd 04                 clear b32 $r0
0000240f: 7e 5e 21 00         B lcall 0x215e
00002413: ff 10 9f              iord $r9 I[$r1+$r0*0x4]
00002416: f1 94 00 01           and $r9 0x100
0000241a: f4 0b f5              bra e 0x240f
0000241d: 8f 00 00 01           mov $r15 0x10000
00002421: 89 00 1a 02           mov $r9 0x21a00
00002425: fa 9f 00              iowr I[$r9] $r15
00002428: fb 11                 mpopret $r1

0000242a: f9 62              C  mpush $r6
0000242c: df 00 00 00 02        mov $r15 0x2000000
00002431: b2 a5                 mov b32 $r5 $r10
00002433: b2 b3                 mov b32 $r3 $r11
00002435: 89 00 12 02           mov $r9 0x21200
00002439: fa 9f 00              iowr I[$r9] $r15
0000243c: bd 94                 clear b32 $r9
0000243e: 8e 00 04 02           mov $r14 0x20400
00002442: ff e9 ef              iord $r14 I[$r14+$r9*0x4]
00002445: 89 0c 16 00           mov $r9 0x160c
00002449: bf 9f                 ld b32 $r15 D[$r9]
0000244b: 89 14 16 00           mov $r9 0x1614
0000244f: 8a 00 05 01           mov $r10 0x10500
00002453: a0 9e                 st b32 D[$r9] $r14
00002455: b6 f5 08              shr b32 $r15 0x8
00002458: bd b4                 clear b32 $r11
0000245a: bc ef 20              add b32 $r2 $r14 $r15
0000245d: bd 14                 clear b32 $r1
0000245f: 7e 10 00 00           lcall 0x10
00002463: 80 10 28 50           mov $r0 0x502810
00002467: 86 a0 14 00           mov $r6 0x14a0
0000246b: 84 08 16 00           mov $r4 0x1608
0000246f: 3e 9d 24 00           lbra 0x249d
00002473: 7e 37 02 00         B lcall 0x237
00002477: b8 0a 10 03 02        sub b32 $r10 $r0 0x310
0000247c: b2 3b                 mov b32 $r11 $r3
0000247e: 7e 37 02 00           lcall 0x237
00002482: b8 0a 0c 03 02        sub b32 $r10 $r0 0x30c
00002487: b2 5b                 mov b32 $r11 $r5
00002489: 7e 37 02 00           lcall 0x237
0000248d: bf 49                 ld b32 $r9 D[$r4]
0000248f: 90 11 01              add b32 $r1 $r1 0x1
00002492: b8 00 00 80 00        add b32 $r0 $r0 0x8000
00002497: b6 95 08              shr b32 $r9 0x8
0000249a: bc 29 20              add b32 $r2 $r2 $r9
0000249d: bf 69               B ld b32 $r9 D[$r6]
0000249f: b2 0a                 mov b32 $r10 $r0
000024a1: b2 2b                 mov b32 $r11 $r2
000024a3: a6 19                 cmp b32 $r1 $r9
000024a5: f4 08 ce              bra b 0x2473
000024a8: 7e fc 23 00           lcall 0x23fc
000024ac: 0f 01                 mov $r15 0x1
000024ae: 89 00 00 02           mov $r9 0x20000
000024b2: fa 9f 00              iowr I[$r9] $r15
000024b5: df 00 00 00 02        mov $r15 0x2000000
000024ba: b8 99 00 18 00        add b32 $r9 $r9 0x1800
000024bf: fa 9f 00              iowr I[$r9] $r15
000024c2: fb 61                 mpopret $r6

000024c4: 89 00 0e 00        C  mov $r9 0xe00
000024c8: 98 9b 0a              ld b32 $r11 D[$r9+0x28]
000024cb: f9 02                 mpush $r0
000024cd: b2 a0                 mov b32 $r0 $r10
000024cf: 0a 28                 mov $r10 0x28
000024d1: 7e c5 0c 00           lcall 0xcc5
000024d5: 7e fc 23 00           lcall 0x23fc
000024d9: 89 0c 13 00           mov $r9 0x130c
000024dd: bf 99                 ld b32 $r9 D[$r9]
000024df: 92 99 01              sub b32 $r9 $r9 0x1
000024e2: b0 96 01              cmp b32 $r9 0x1
000024e5: f4 0c 2d              bra a 0x2512
000024e8: b2 0b                 mov b32 $r11 $r0
000024ea: 8a 14 a8 41           mov $r10 0x41a814
000024ee: 7e 37 02 00           lcall 0x237
000024f2: 89 fc 12 00           mov $r9 0x12fc
000024f6: bf 9b                 ld b32 $r11 D[$r9]
000024f8: 0a 26                 mov $r10 0x26
000024fa: 7e c5 0c 00           lcall 0xcc5
000024fe: 7e fc 23 00           lcall 0x23fc
00002502: 89 00 13 00           mov $r9 0x1300
00002506: bf 9b                 ld b32 $r11 D[$r9]
00002508: 0a 23                 mov $r10 0x23
0000250a: 7e c5 0c 00           lcall 0xcc5
0000250e: 7e fc 23 00           lcall 0x23fc
00002512: fb 01               B mpopret $r0

00002514: 8f 04 16 00        C  mov $r15 0x1604
00002518: bf ff                 ld b32 $r15 D[$r15]
0000251a: f4 30 cc              add $sp -0x34
0000251d: f9 72                 mpush $r7
0000251f: fe 49 01              mov $r9 $sp
00002522: 90 99 50              add b32 $r9 $r9 0x50
00002525: a0 9f                 st b32 D[$r9] $r15
00002527: 4f 00 08              mov $r15 0x800
0000252a: 89 00 12 02           mov $r9 0x21200
0000252e: fa 9f 00              iowr I[$r9] $r15
00002531: 89 24 00 00           mov $r9 0x24
00002535: bf 9a                 ld b32 $r10 D[$r9]
00002537: 85 94 12 00           mov $r5 0x1294
0000253b: fe 46 01              mov $r6 $sp
0000253e: b2 57                 mov b32 $r7 $r5
00002540: 7e 14 01 00           lcall 0x114
00002544: 0a 02                 mov $r10 0x2
00002546: 7e 7a 09 00           lcall 0x97a
0000254a: b2 a4                 mov b32 $r4 $r10
0000254c: 0a 0c                 mov $r10 0xc
0000254e: 7e 7a 09 00           lcall 0x97a
00002552: b2 a1                 mov b32 $r1 $r10
00002554: 0a 1a                 mov $r10 0x1a
00002556: 7e 7a 09 00           lcall 0x97a
0000255a: b2 a3                 mov b32 $r3 $r10
0000255c: 0a 1b                 mov $r10 0x1b
0000255e: 7e 7a 09 00           lcall 0x97a
00002562: b2 a0                 mov b32 $r0 $r10
00002564: 0a 0f                 mov $r10 0xf
00002566: 7e 7a 09 00           lcall 0x97a
0000256a: b2 a2                 mov b32 $r2 $r10
0000256c: 0a 0d                 mov $r10 0xd
0000256e: 7e 7a 09 00           lcall 0x97a
00002572: 89 00 10 00           mov $r9 0x1000
00002576: bc 14 10              add b32 $r1 $r1 $r4
00002579: bc 03 00              add b32 $r0 $r0 $r3
0000257c: bc a2 20              add b32 $r2 $r10 $r2
0000257f: bc 01 00              add b32 $r0 $r0 $r1
00002582: c7 aa e8              extr $r10 $r10 0x8:0xf
00002585: bc 20 20              add b32 $r2 $r2 $r0
00002588: b6 a4 10              shl b32 $r10 0x10
0000258b: b5 92 39              st b32 D[$r9+0xe4] $r2
0000258e: c7 11 e8              extr $r1 $r1 0x8:0xf
00002591: e7 00 e8 01           extr $r0 $r0 0x8:0x17
00002595: b6 14 10              shl b32 $r1 0x10
00002598: fd 0a 05              or $r0 $r10
0000259b: b5 91 3a              st b32 D[$r9+0xe8] $r1
0000259e: b5 90 3b              st b32 D[$r9+0xec] $r0
000025a1: 89 98 12 00           mov $r9 0x1298
000025a5: 8a 00 a8 41           mov $r10 0x41a800
000025a9: a0 92                 st b32 D[$r9] $r2
000025ab: bd b4                 clear b32 $r11
000025ad: a0 52                 st b32 D[$r5] $r2
000025af: 7e 37 02 00           lcall 0x237
000025b3: 0a 25                 mov $r10 0x25
000025b5: bd b4                 clear b32 $r11
000025b7: 90 66 20              add b32 $r6 $r6 0x20
000025ba: 7e c5 0c 00           lcall 0xcc5
000025be: b2 63                 mov b32 $r3 $r6
000025c0: 7e fc 23 00           lcall 0x23fc
000025c4: bd 14                 clear b32 $r1
000025c6: 80 00 28 50           mov $r0 0x502800
000025ca: 84 a0 14 00           mov $r4 0x14a0
000025ce: 3e ec 25 00           lbra 0x25ec
000025d2: b2 0a               B mov b32 $r10 $r0
000025d4: 7e 97 02 00           lcall 0x297
000025d8: bf 79                 ld b32 $r9 D[$r7]
000025da: a0 3a                 st b32 D[$r3] $r10
000025dc: 90 11 01              add b32 $r1 $r1 0x1
000025df: b8 00 00 80 00        add b32 $r0 $r0 0x8000
000025e4: bc a9 a0              add b32 $r10 $r10 $r9
000025e7: 90 33 04              add b32 $r3 $r3 0x4
000025ea: a0 7a                 st b32 D[$r7] $r10
000025ec: bf 49               B ld b32 $r9 D[$r4]
000025ee: a6 19                 cmp b32 $r1 $r9
000025f0: f4 08 e2              bra b 0x25d2
000025f3: 8a 00 a8 41           mov $r10 0x41a800
000025f7: bd b4                 clear b32 $r11
000025f9: 7e 37 02 00           lcall 0x237
000025fd: 8a 00 05 01           mov $r10 0x10500
00002601: bd b4                 clear b32 $r11
00002603: b6 25 08              shr b32 $r2 0x8
00002606: 7e 10 00 00           lcall 0x10
0000260a: bd 14                 clear b32 $r1
0000260c: 80 00 25 50           mov $r0 0x502500
00002610: 83 a0 14 00           mov $r3 0x14a0
00002614: 3e 3c 26 00           lbra 0x263c
00002618: b2 0a               B mov b32 $r10 $r0
0000261a: b2 2b                 mov b32 $r11 $r2
0000261c: 7e 37 02 00           lcall 0x237
00002620: 90 0a 04              add b32 $r10 $r0 0x4
00002623: 0b 27                 mov $r11 0x27
00002625: 7e 37 02 00           lcall 0x237
00002629: bf 69                 ld b32 $r9 D[$r6]
0000262b: 90 11 01              add b32 $r1 $r1 0x1
0000262e: b8 00 00 80 00        add b32 $r0 $r0 0x8000
00002633: 90 66 04              add b32 $r6 $r6 0x4
00002636: b6 95 08              shr b32 $r9 0x8
00002639: bc 29 20              add b32 $r2 $r2 $r9
0000263c: bf 39               B ld b32 $r9 D[$r3]
0000263e: a6 19                 cmp b32 $r1 $r9
00002640: f4 08 d8              bra b 0x2618
00002643: 7e fc 23 00           lcall 0x23fc
00002647: 89 94 12 00           mov $r9 0x1294
0000264b: bf 9e                 ld b32 $r14 D[$r9]
0000264d: 89 00 0e 00           mov $r9 0xe00
00002651: bd f4                 clear b32 $r15
00002653: b5 9e 0c              st b32 D[$r9+0x30] $r14
00002656: 89 00 0c 01           mov $r9 0x10c00
0000265a: fa 9f 00              iowr I[$r9] $r15
0000265d: 89 00 00 02           mov $r9 0x20000
00002661: fa 9e 00              iowr I[$r9] $r14
00002664: 4f 00 08              mov $r15 0x800
00002667: b8 99 00 18 00        add b32 $r9 $r9 0x1800
0000266c: fa 9f 00              iowr I[$r9] $r15
0000266f: fe 49 01              mov $r9 $sp
00002672: 90 99 50              add b32 $r9 $r9 0x50
00002675: bf 9f                 ld b32 $r15 D[$r9]
00002677: 89 04 16 00           mov $r9 0x1604
0000267b: bf 99                 ld b32 $r9 D[$r9]
0000267d: a6 f9                 cmp b32 $r15 $r9
0000267f: f4 0b 07              bra e 0x2686
00002682: 7e 47 07 00           lcall 0x747
00002686: fb 75 34            B mpopaddret $r7 0x34

00002689: f9 02              C  mpush $r0
0000268b: 80 08 13 00           mov $r0 0x1308
0000268f: bf 0b                 ld b32 $r11 D[$r0]
00002691: 0a 19                 mov $r10 0x19
00002693: 7e c5 0c 00           lcall 0xcc5
00002697: 7e fc 23 00           lcall 0x23fc
0000269b: bf 09                 ld b32 $r9 D[$r0]
0000269d: b3 94 02 32           bra b32 $r9 0x2 ne 0x26cf
000026a1: 89 ec 12 00           mov $r9 0x12ec
000026a5: bf 9b                 ld b32 $r11 D[$r9]
000026a7: 8a 14 a8 41           mov $r10 0x41a814
000026ab: 7e 37 02 00           lcall 0x237
000026af: 89 f0 12 00           mov $r9 0x12f0
000026b3: bf 9b                 ld b32 $r11 D[$r9]
000026b5: 0a 17                 mov $r10 0x17
000026b7: 7e c5 0c 00           lcall 0xcc5
000026bb: 7e fc 23 00           lcall 0x23fc
000026bf: 89 f4 12 00           mov $r9 0x12f4
000026c3: bf 9b                 ld b32 $r11 D[$r9]
000026c5: 0a 22                 mov $r10 0x22
000026c7: 7e c5 0c 00           lcall 0xcc5
000026cb: 7e fc 23 00           lcall 0x23fc
000026cf: fb 01               B mpopret $r0

000026d1: 4f 00 04           C  mov $r15 0x400
000026d4: 89 00 14 02           mov $r9 0x21400
000026d8: fa 9f 00              iowr I[$r9] $r15
000026db: 8a 08 ac 10           mov $r10 0x10ac08
000026df: 7e 97 02 00           lcall 0x297
000026e3: 89 00 00 10           mov $r9 0x100000
000026e7: fd a9 04              and $r10 $r9
000026ea: f4 0b 17              bra e 0x2701
000026ed: 0a 0f                 mov $r10 0xf
000026ef: bd b4                 clear b32 $r11
000026f1: 7e c5 0c 00           lcall 0xcc5
000026f5: 7e fc 23 00           lcall 0x23fc
000026f9: 0f 01                 mov $r15 0x1
000026fb: 89 dc 12 00           mov $r9 0x12dc
000026ff: a0 9f                 st b32 D[$r9] $r15
00002701: 0f 01               B mov $r15 0x1
00002703: 89 00 00 02           mov $r9 0x20000
00002707: fa 9f 00              iowr I[$r9] $r15
0000270a: 4f 00 04              mov $r15 0x400
0000270d: b8 99 00 1a 00        add b32 $r9 $r9 0x1a00
00002712: fa 9f 00              iowr I[$r9] $r15
00002715: f8 00                 ret

00002717: 4f 00 01           C  mov $r15 0x100
0000271a: 89 00 14 02           mov $r9 0x21400
0000271e: fa 9f 00              iowr I[$r9] $r15
00002721: 0a 0d                 mov $r10 0xd
00002723: bd b4                 clear b32 $r11
00002725: 7e c5 0c 00           lcall 0xcc5
00002729: 7e fc 23 00           lcall 0x23fc
0000272d: 89 d8 12 00           mov $r9 0x12d8
00002731: 0f 01                 mov $r15 0x1
00002733: a0 9f                 st b32 D[$r9] $r15
00002735: 89 00 00 02           mov $r9 0x20000
00002739: fa 9f 00              iowr I[$r9] $r15
0000273c: 4f 00 01              mov $r15 0x100
0000273f: b8 99 00 1a 00        add b32 $r9 $r9 0x1a00
00002744: fa 9f 00              iowr I[$r9] $r15
00002747: f8 00                 ret

00002749: f9 12              C  mpush $r1
0000274b: 8a 00 39 02           mov $r10 0x23900
0000274f: 7e 44 00 00           lcall 0x44
00002753: 89 18 00 00           mov $r9 0x18
00002757: a0 9a                 st b32 D[$r9] $r10
00002759: d9 ff 00 00 ff        mov $r9 0xff0000ff
0000275e: fd a9 04              and $r10 $r9
00002761: 89 1c 00 00           mov $r9 0x1c
00002765: f1 a5 00 0a           or $r10 0xa00
00002769: b2 ab                 mov b32 $r11 $r10
0000276b: a0 9a                 st b32 D[$r9] $r10
0000276d: 8a 00 39 02           mov $r10 0x23900
00002771: 7e 10 00 00           lcall 0x10
00002775: 8d 00 90 01           mov $r13 0x19000
00002779: bd e4                 clear b32 $r14
0000277b: 0f ff                 mov $r15 -0x1
0000277d: ff de 9f            B iord $r9 I[$r13+$r14*0x4]
00002780: a6 9f                 cmp b32 $r9 $r15
00002782: f4 1b fb              bra ne 0x277d
00002785: 00 ff                 mov $r0 -0x1
00002787: 8a 40 a6 41         B mov $r10 0x41a640
0000278b: 7e 97 02 00           lcall 0x297
0000278f: a6 a0                 cmp b32 $r10 $r0
00002791: f4 1b f6              bra ne 0x2787
00002794: 8a 00 39 02           mov $r10 0x23900
00002798: 7e 44 00 00           lcall 0x44
0000279c: 89 18 00 00           mov $r9 0x18
000027a0: a0 9a                 st b32 D[$r9] $r10
000027a2: d9 ff 0f 00 ff        mov $r9 0xff000fff
000027a7: fd a9 04              and $r10 $r9
000027aa: 89 1c 00 00           mov $r9 0x1c
000027ae: f1 a5 00 a0           or $r10 0xa000
000027b2: b2 ab                 mov b32 $r11 $r10
000027b4: a0 9a                 st b32 D[$r9] $r10
000027b6: 8a 00 39 02           mov $r10 0x23900
000027ba: 7e 10 00 00           lcall 0x10
000027be: 4f 80 00              mov $r15 0x80
000027c1: 89 00 1a 02           mov $r9 0x21a00
000027c5: fa 9f 00              iowr I[$r9] $r15
000027c8: 4f 00 08              mov $r15 0x800
000027cb: b8 99 00 06 02        sub b32 $r9 $r9 0x600
000027d0: fa 9f 00              iowr I[$r9] $r15
000027d3: 8a 04 26 02           mov $r10 0x22604
000027d7: 7e 97 02 00           lcall 0x297
000027db: c4 a1 01              and $r1 $r10 0x1
000027de: 8a 04 03 50           mov $r10 0x500304
000027e2: 7e 97 02 00           lcall 0x297
000027e6: b2 a0                 mov b32 $r0 $r10
000027e8: 8a 00 39 02           mov $r10 0x23900
000027ec: 7e 44 00 00           lcall 0x44
000027f0: 89 18 00 00           mov $r9 0x18
000027f4: a0 9a                 st b32 D[$r9] $r10
000027f6: d9 ff ff 00 ff        mov $r9 0xff00ffff
000027fb: fd a9 04              and $r10 $r9
000027fe: 89 00 00 09           mov $r9 0x90000
00002802: fd a9 05              or $r10 $r9
00002805: 89 1c 00 00           mov $r9 0x1c
00002809: b2 ab                 mov b32 $r11 $r10
0000280b: a0 9a                 st b32 D[$r9] $r10
0000280d: 8a 00 39 02           mov $r10 0x23900
00002811: 7e 10 00 00           lcall 0x10
00002815: b3 14 00 15           bra b32 $r1 0x0 ne 0x282a
00002819: 0b fe                 mov $r11 -0x2
0000281b: 8a 04 83 41           mov $r10 0x418304
0000281f: ff 0b b4              and $r11 $r0 $r11
00002822: bd c4                 clear b32 $r12
00002824: 0d 01                 mov $r13 0x1
00002826: 7e 2f 02 00           lcall 0x22f
0000282a: 8a 00 39 02         B mov $r10 0x23900
0000282e: 7e 44 00 00           lcall 0x44
00002832: 89 18 00 00           mov $r9 0x18
00002836: a0 9a                 st b32 D[$r9] $r10
00002838: d9 ff ff ff 00        mov $r9 0xffffff
0000283d: fd a9 04              and $r10 $r9
00002840: 89 55 aa 09           mov $r9 0x9aa55
00002844: a6 a9                 cmp b32 $r10 $r9
00002846: f4 0b 0d              bra e 0x2853
00002849: 7e 8b 0b 00           lcall 0xb8b
0000284d: 0a 25                 mov $r10 0x25
0000284f: 7e c0 05 00           lcall 0x5c0
00002853: 7e 0c 0e 00         B lcall 0xe0c
00002857: b2 a0                 mov b32 $r0 $r10
00002859: 8a 00 39 02           mov $r10 0x23900
0000285d: 7e 44 00 00           lcall 0x44
00002861: 89 18 00 00           mov $r9 0x18
00002865: a0 9a                 st b32 D[$r9] $r10
00002867: d9 ff ff 0f ff        mov $r9 0xff0fffff
0000286c: fd a9 04              and $r10 $r9
0000286f: d9 00 00 90 00        mov $r9 0x900000
00002874: fd a9 05              or $r10 $r9
00002877: 89 1c 00 00           mov $r9 0x1c
0000287b: b2 ab                 mov b32 $r11 $r10
0000287d: a0 9a                 st b32 D[$r9] $r10
0000287f: 8a 00 39 02           mov $r10 0x23900
00002883: 7e 10 00 00           lcall 0x10
00002887: b3 14 00 15           bra b32 $r1 0x0 ne 0x289c
0000288b: 0b ef                 mov $r11 -0x11
0000288d: 8a 00 a8 1f           mov $r10 0x1fa800
00002891: ff 0b b4              and $r11 $r0 $r11
00002894: bd c4                 clear b32 $r12
00002896: 0d 01                 mov $r13 0x1
00002898: 7e 2f 02 00           lcall 0x22f
0000289c: 8a 00 39 02         B mov $r10 0x23900
000028a0: 7e 44 00 00           lcall 0x44
000028a4: 89 18 00 00           mov $r9 0x18
000028a8: a0 9a                 st b32 D[$r9] $r10
000028aa: d9 ff ff ff 00        mov $r9 0xffffff
000028af: fd a9 04              and $r10 $r9
000028b2: d9 55 aa 99 00        mov $r9 0x99aa55
000028b7: a6 a9                 cmp b32 $r10 $r9
000028b9: f4 0b 0d              bra e 0x28c6
000028bc: 7e 8b 0b 00           lcall 0xb8b
000028c0: 0a 26                 mov $r10 0x26
000028c2: 7e c0 05 00           lcall 0x5c0
000028c6: 4f 00 08            B mov $r15 0x800
000028c9: 89 00 1a 02           mov $r9 0x21a00
000028cd: fa 9f 00              iowr I[$r9] $r15
000028d0: 4f 00 10              mov $r15 0x1000
000028d3: fa 9f 00              iowr I[$r9] $r15
000028d6: 89 18 00 00           mov $r9 0x18
000028da: bf 9f                 ld b32 $r15 D[$r9]
000028dc: d9 00 00 00 ff        mov $r9 0xff000000
000028e1: 8a 00 39 02           mov $r10 0x23900
000028e5: fd f9 04              and $r15 $r9
000028e8: 89 1c 00 00           mov $r9 0x1c
000028ec: b2 fb                 mov b32 $r11 $r15
000028ee: a0 9f                 st b32 D[$r9] $r15
000028f0: 7e 10 00 00           lcall 0x10
000028f4: 7e 5e 21 00           lcall 0x215e
000028f8: bd f4                 clear b32 $r15
000028fa: 89 ec 09 00           mov $r9 0x9ec
000028fe: a0 9f                 st b32 D[$r9] $r15
00002900: fb 11                 mpopret $r1

00002902: 7e 8b 0b 00        C  lcall 0xb8b
00002906: 7e 49 27 00           lcall 0x2749
0000290a: f8 00                 ret

0000290c: 8f 00 00 20        C  mov $r15 0x200000
00002910: 89 00 14 02           mov $r9 0x21400
00002914: fa 9f 00              iowr I[$r9] $r15
00002917: 3e 1f 29 00           lbra 0x291f
0000291b: 7e 5e 21 00         B lcall 0x215e
0000291f: 8a 70 41 40         B mov $r10 0x404170
00002923: 7e 97 02 00           lcall 0x297
00002927: f0 a4 10              and $r10 0x10
0000292a: f4 1b f1              bra ne 0x291b
0000292d: 8f 00 00 20           mov $r15 0x200000
00002931: 89 00 1a 02           mov $r9 0x21a00
00002935: fa 9f 00              iowr I[$r9] $r15
00002938: f8 00                 ret

0000293a: f9 02              C  mpush $r0
0000293c: b2 b0                 mov b32 $r0 $r11
0000293e: c4 ab 03              and $r11 $r10 0x3
00002941: 8a 70 41 40           mov $r10 0x404170
00002945: f0 b5 10              or $r11 0x10
00002948: 7e 37 02 00           lcall 0x237
0000294c: b3 04 01 1a           bra b32 $r0 0x1 ne 0x2966
00002950: 3e 58 29 00           lbra 0x2958
00002954: 7e 5e 21 00         B lcall 0x215e
00002958: 8a 70 41 40         B mov $r10 0x404170
0000295c: 7e 97 02 00           lcall 0x297
00002960: f0 a4 10              and $r10 0x10
00002963: f4 1b f1              bra ne 0x2954
00002966: fb 01               B mpopret $r0
00002968: 8f 00 00 04           mov $r15 0x40000
0000296c: 89 00 13 02           mov $r9 0x21300
00002970: fa 9f 00              iowr I[$r9] $r15
00002973: bd a4                 clear b32 $r10
00002975: 0b 01                 mov $r11 0x1
00002977: 7e 3a 29 00           lcall 0x293a
0000297b: 8f 00 00 04           mov $r15 0x40000
0000297f: 89 00 19 02           mov $r9 0x21900
00002983: fa 9f 00              iowr I[$r9] $r15
00002986: f8 00                 ret

00002988: b2 ab              C  mov b32 $r11 $r10
0000298a: 4f 80 00              mov $r15 0x80
0000298d: 89 00 13 02           mov $r9 0x21300
00002991: fa 9f 00              iowr I[$r9] $r15
00002994: bd a4                 clear b32 $r10
00002996: 7e 3a 29 00           lcall 0x293a
0000299a: 4f 80 00              mov $r15 0x80
0000299d: 89 00 19 02           mov $r9 0x21900
000029a1: fa 9f 00              iowr I[$r9] $r15
000029a4: f8 00                 ret

000029a6: 8f 00 00 02        C  mov $r15 0x20000
000029aa: 89 00 13 02           mov $r9 0x21300
000029ae: fa 9f 00              iowr I[$r9] $r15
000029b1: 0a 01                 mov $r10 0x1
000029b3: b2 ab                 mov b32 $r11 $r10
000029b5: 7e 3a 29 00           lcall 0x293a
000029b9: 8f 00 00 02           mov $r15 0x20000
000029bd: 89 00 19 02           mov $r9 0x21900
000029c1: fa 9f 00              iowr I[$r9] $r15
000029c4: f8 00                 ret

000029c6: b2 ab              C  mov b32 $r11 $r10
000029c8: 8f 00 00 01           mov $r15 0x10000
000029cc: 89 00 13 02           mov $r9 0x21300
000029d0: fa 9f 00              iowr I[$r9] $r15
000029d3: 0a 02                 mov $r10 0x2
000029d5: 7e 3a 29 00           lcall 0x293a
000029d9: 8f 00 00 01           mov $r15 0x10000
000029dd: 89 00 19 02           mov $r9 0x21900
000029e1: fa 9f 00              iowr I[$r9] $r15
000029e4: f8 00                 ret

000029e6: 8f 04 16 00        C  mov $r15 0x1604
000029ea: bf ff                 ld b32 $r15 D[$r15]
000029ec: f4 30 cc              add $sp -0x34
000029ef: f9 62                 mpush $r6
000029f1: fe 49 01              mov $r9 $sp
000029f4: 90 99 4c              add b32 $r9 $r9 0x4c
000029f7: b2 b6                 mov b32 $r6 $r11
000029f9: a0 9f                 st b32 D[$r9] $r15
000029fb: 4f 00 04              mov $r15 0x400
000029fe: 89 00 12 02           mov $r9 0x21200
00002a02: fa 9f 00              iowr I[$r9] $r15
00002a05: 89 24 00 00           mov $r9 0x24
00002a09: bf 9a                 ld b32 $r10 D[$r9]
00002a0b: bd 94                 clear b32 $r9
00002a0d: 80 8c 12 00           mov $r0 0x128c
00002a11: a0 09                 st b32 D[$r0] $r9
00002a13: 7e 14 01 00           lcall 0x114
00002a17: 0a 01                 mov $r10 0x1
00002a19: 7e c6 29 00           lcall 0x29c6
00002a1d: 0a 01                 mov $r10 0x1
00002a1f: b2 ac                 mov b32 $r12 $r10
00002a21: b2 ab                 mov b32 $r11 $r10
00002a23: 7e f5 0c 00           lcall 0xcf5
00002a27: 7e 0c 29 00           lcall 0x290c
00002a2b: bd a4                 clear b32 $r10
00002a2d: 7e 88 29 00           lcall 0x2988
00002a31: 8a 00 a8 41           mov $r10 0x41a800
00002a35: bd b4                 clear b32 $r11
00002a37: 7e 37 02 00           lcall 0x237
00002a3b: 0a 16                 mov $r10 0x16
00002a3d: bd b4                 clear b32 $r11
00002a3f: b2 04                 mov b32 $r4 $r0
00002a41: 7e c5 0c 00           lcall 0xcc5
00002a45: fe 43 01              mov $r3 $sp
00002a48: 7e fc 23 00           lcall 0x23fc
00002a4c: 90 33 1c              add b32 $r3 $r3 0x1c
00002a4f: bd 24                 clear b32 $r2
00002a51: b2 31                 mov b32 $r1 $r3
00002a53: 80 00 28 50           mov $r0 0x502800
00002a57: 85 a0 14 00           mov $r5 0x14a0
00002a5b: 3e 82 2a 00           lbra 0x2a82
00002a5f: b2 0a               B mov b32 $r10 $r0
00002a61: 7e 97 02 00           lcall 0x297
00002a65: bf 49                 ld b32 $r9 D[$r4]
00002a67: b6 a5 08              shr b32 $r10 0x8
00002a6a: 90 22 01              add b32 $r2 $r2 0x1
00002a6d: 90 aa 01              add b32 $r10 $r10 0x1
00002a70: b8 00 00 80 00        add b32 $r0 $r0 0x8000
00002a75: b6 a4 08              shl b32 $r10 0x8
00002a78: a0 1a                 st b32 D[$r1] $r10
00002a7a: bc a9 a0              add b32 $r10 $r10 $r9
00002a7d: 90 11 04              add b32 $r1 $r1 0x4
00002a80: a0 4a                 st b32 D[$r4] $r10
00002a82: bf 59               B ld b32 $r9 D[$r5]
00002a84: a6 29                 cmp b32 $r2 $r9
00002a86: f4 08 d9              bra b 0x2a5f
00002a89: 8a 00 a8 41           mov $r10 0x41a800
00002a8d: bd b4                 clear b32 $r11
00002a8f: 7e 37 02 00           lcall 0x237
00002a93: 8a 00 05 01           mov $r10 0x10500
00002a97: bd b4                 clear b32 $r11
00002a99: bd 24                 clear b32 $r2
00002a9b: 7e 10 00 00           lcall 0x10
00002a9f: bd 14                 clear b32 $r1
00002aa1: 80 00 25 50           mov $r0 0x502500
00002aa5: 84 a0 14 00           mov $r4 0x14a0
00002aa9: 3e d1 2a 00           lbra 0x2ad1
00002aad: b2 0a               B mov b32 $r10 $r0
00002aaf: b2 2b                 mov b32 $r11 $r2
00002ab1: 7e 37 02 00           lcall 0x237
00002ab5: 90 0a 04              add b32 $r10 $r0 0x4
00002ab8: 0b 18                 mov $r11 0x18
00002aba: 7e 37 02 00           lcall 0x237
00002abe: bf 39                 ld b32 $r9 D[$r3]
00002ac0: 90 11 01              add b32 $r1 $r1 0x1
00002ac3: b8 00 00 80 00        add b32 $r0 $r0 0x8000
00002ac8: 90 33 04              add b32 $r3 $r3 0x4
00002acb: b6 95 08              shr b32 $r9 0x8
00002ace: bc 29 20              add b32 $r2 $r2 $r9
00002ad1: bf 49               B ld b32 $r9 D[$r4]
00002ad3: a6 19                 cmp b32 $r1 $r9
00002ad5: f4 08 d8              bra b 0x2aad
00002ad8: 7e fc 23 00           lcall 0x23fc
00002adc: 8f 8c 12 00           mov $r15 0x128c
00002ae0: bf f9                 ld b32 $r9 D[$r15]
00002ae2: a6 69                 cmp b32 $r6 $r9
00002ae4: f4 0d 05              bra be 0x2ae9
00002ae7: a0 f6                 st b32 D[$r15] $r6
00002ae9: 8f 8c 12 00         B mov $r15 0x128c
00002aed: bf f9                 ld b32 $r9 D[$r15]
00002aef: b3 94 00 09           bra b32 $r9 0x0 ne 0x2af8
00002af3: 49 00 01              mov $r9 0x100
00002af6: a0 f9                 st b32 D[$r15] $r9
00002af8: 89 8c 12 00         B mov $r9 0x128c
00002afc: bf 9f                 ld b32 $r15 D[$r9]
00002afe: 89 00 0e 00           mov $r9 0xe00
00002b02: b5 9f 09              st b32 D[$r9+0x24] $r15
00002b05: 89 00 00 02           mov $r9 0x20000
00002b09: fa 9f 00              iowr I[$r9] $r15
00002b0c: bd a4                 clear b32 $r10
00002b0e: 7e c6 29 00           lcall 0x29c6
00002b12: 0a 01                 mov $r10 0x1
00002b14: b2 ab                 mov b32 $r11 $r10
00002b16: b2 ac                 mov b32 $r12 $r10
00002b18: 7e 7b 0c 00           lcall 0xc7b
00002b1c: 7e 0c 29 00           lcall 0x290c
00002b20: bd a4                 clear b32 $r10
00002b22: 7e 88 29 00           lcall 0x2988
00002b26: bd f4                 clear b32 $r15
00002b28: 89 00 0c 01           mov $r9 0x10c00
00002b2c: fa 9f 00              iowr I[$r9] $r15
00002b2f: 4f 00 04              mov $r15 0x400
00002b32: 89 00 18 02           mov $r9 0x21800
00002b36: fa 9f 00              iowr I[$r9] $r15
00002b39: fe 49 01              mov $r9 $sp
00002b3c: 90 99 4c              add b32 $r9 $r9 0x4c
00002b3f: bf 9f                 ld b32 $r15 D[$r9]
00002b41: 89 04 16 00           mov $r9 0x1604
00002b45: bf 99                 ld b32 $r9 D[$r9]
00002b47: a6 f9                 cmp b32 $r15 $r9
00002b49: f4 0b 07              bra e 0x2b50
00002b4c: 7e 47 07 00           lcall 0x747
00002b50: fb 65 34            B mpopaddret $r6 0x34

00002b53: f9 02              C  mpush $r0
00002b55: 7e 68 07 00           lcall 0x768
00002b59: b3 a4 00 0e           bra b32 $r10 0x0 ne 0x2b67
00002b5d: 89 20 00 00           mov $r9 0x20
00002b61: bf 99                 ld b32 $r9 D[$r9]
00002b63: b3 94 00 3e           bra b32 $r9 0x0 ne 0x2ba1
00002b67: 0a 01               B mov $r10 0x1
00002b69: 7e c6 29 00           lcall 0x29c6
00002b6d: 0a 01                 mov $r10 0x1
00002b6f: b2 ab                 mov b32 $r11 $r10
00002b71: b2 ac                 mov b32 $r12 $r10
00002b73: 7e f5 0c 00           lcall 0xcf5
00002b77: 7e 0c 29 00           lcall 0x290c
00002b7b: 89 ec 09 00           mov $r9 0x9ec
00002b7f: 00 01                 mov $r0 0x1
00002b81: a0 90                 st b32 D[$r9] $r0
00002b83: 7e 02 29 00           lcall 0x2902
00002b87: 0a 08                 mov $r10 0x8
00002b89: 7e af 23 00           lcall 0x23af
00002b8d: b2 0a                 mov b32 $r10 $r0
00002b8f: b2 0b                 mov b32 $r11 $r0
00002b91: b2 0c                 mov b32 $r12 $r0
00002b93: 7e 7b 0c 00           lcall 0xc7b
00002b97: 7e 0c 29 00           lcall 0x290c
00002b9b: bd a4                 clear b32 $r10
00002b9d: 7e 88 29 00           lcall 0x2988
00002ba1: fb 01               B mpopret $r0

00002ba3: 0f 01              C  mov $r15 0x1
00002ba5: 89 00 12 02           mov $r9 0x21200
00002ba9: fa 9f 00              iowr I[$r9] $r15
00002bac: bd e4                 clear b32 $r14
00002bae: 89 6c 13 00           mov $r9 0x136c
00002bb2: a0 9e                 st b32 D[$r9] $r14
00002bb4: 4f 00 0b              mov $r15 0xb00
00002bb7: 89 70 13 00           mov $r9 0x1370
00002bbb: a0 9e                 st b32 D[$r9] $r14
00002bbd: ff fe ff              iord $r15 I[$r15+$r14*0x4]
00002bc0: 49 00 0c              mov $r9 0xc00
00002bc3: ff 9e 9f              iord $r9 I[$r9+$r14*0x4]
00002bc6: fd 9f 06              xor $r9 $r15
00002bc9: 8f 04 16 00           mov $r15 0x1604
00002bcd: a0 f9                 st b32 D[$r15] $r9
00002bcf: 7e 3d 18 00           lcall 0x183d
00002bd3: 7e f7 0e 00           lcall 0xef7
00002bd7: 7e 26 0a 00           lcall 0xa26
00002bdb: 7e 9b 18 00           lcall 0x189b
00002bdf: 7e 6e 18 00           lcall 0x186e
00002be3: 7e 53 2b 00           lcall 0x2b53
00002be7: 89 d4 12 00           mov $r9 0x12d4
00002beb: bf 9a                 ld b32 $r10 D[$r9]
00002bed: 89 e8 02 04           mov $r9 0x402e8
00002bf1: bd c4                 clear b32 $r12
00002bf3: 0d 01                 mov $r13 0x1
00002bf5: bc a9 a0              add b32 $r10 $r10 $r9
00002bf8: bd b4                 clear b32 $r11
00002bfa: b6 a4 02              shl b32 $r10 0x2
00002bfd: 7e 2f 02 00           lcall 0x22f
00002c01: 8a 00 8d 02           mov $r10 0x28d00
00002c05: db 33 33 33 33        mov $r11 0x33333333
00002c0a: 7e 10 00 00           lcall 0x10
00002c0e: 0f 01                 mov $r15 0x1
00002c10: 89 00 00 02           mov $r9 0x20000
00002c14: fa 9f 00              iowr I[$r9] $r15
00002c17: f8 00                 ret

00002c19: f9 12              C  mpush $r1
00002c1b: 4f 00 40              mov $r15 0x4000
00002c1e: 89 00 13 02           mov $r9 0x21300
00002c22: fa 9f 00              iowr I[$r9] $r15
00002c25: 81 00 00 01           mov $r1 0x10000
00002c29: bd 04                 clear b32 $r0
00002c2b: 7e 5e 21 00         B lcall 0x215e
00002c2f: ff 10 9f              iord $r9 I[$r1+$r0*0x4]
00002c32: f0 94 04              and $r9 0x4
00002c35: f4 1b f6              bra ne 0x2c2b
00002c38: 4f 00 40              mov $r15 0x4000
00002c3b: 89 00 19 02           mov $r9 0x21900
00002c3f: fa 9f 00              iowr I[$r9] $r15
00002c42: fb 11                 mpopret $r1

00002c44: b2 ab              C  mov b32 $r11 $r10
00002c46: 8f 00 80 00           mov $r15 0x8000
00002c4a: 89 00 13 02           mov $r9 0x21300
00002c4e: fa 9f 00              iowr I[$r9] $r15
00002c51: 8a fc 47 02           mov $r10 0x247fc
00002c55: 7e 10 00 00           lcall 0x10
00002c59: 8a fc 4a 02           mov $r10 0x24afc
00002c5d: 0b 01                 mov $r11 0x1
00002c5f: 7e 10 00 00           lcall 0x10
00002c63: 7e 19 2c 00           lcall 0x2c19
00002c67: 8a fc 46 02           mov $r10 0x246fc
00002c6b: bd b4                 clear b32 $r11
00002c6d: 7e 10 00 00           lcall 0x10
00002c71: 8a fc 4a 02           mov $r10 0x24afc
00002c75: 0b 05                 mov $r11 0x5
00002c77: 7e 10 00 00           lcall 0x10
00002c7b: 7e 19 2c 00           lcall 0x2c19
00002c7f: 8f 00 80 00           mov $r15 0x8000
00002c83: 89 00 19 02           mov $r9 0x21900
00002c87: fa 9f 00              iowr I[$r9] $r15
00002c8a: f8 00                 ret

00002c8c: b2 ab              C  mov b32 $r11 $r10
00002c8e: 4f 00 20              mov $r15 0x2000
00002c91: 89 00 13 02           mov $r9 0x21300
00002c95: fa 9f 00              iowr I[$r9] $r15
00002c98: 8a fc 47 02           mov $r10 0x247fc
00002c9c: 7e 10 00 00           lcall 0x10
00002ca0: 8a fc 4a 02           mov $r10 0x24afc
00002ca4: 0b 01                 mov $r11 0x1
00002ca6: 7e 10 00 00           lcall 0x10
00002caa: 7e 19 2c 00           lcall 0x2c19
00002cae: 8a fc 46 02           mov $r10 0x246fc
00002cb2: 0b ff                 mov $r11 -0x1
00002cb4: 7e 10 00 00           lcall 0x10
00002cb8: 8a fc 4a 02           mov $r10 0x24afc
00002cbc: 0b 02                 mov $r11 0x2
00002cbe: 7e 10 00 00           lcall 0x10
00002cc2: 4f 00 20              mov $r15 0x2000
00002cc5: 89 00 19 02           mov $r9 0x21900
00002cc9: fa 9f 00              iowr I[$r9] $r15
00002ccc: f8 00                 ret

00002cce: 4f 00 01           C  mov $r15 0x100
00002cd1: 89 00 12 02           mov $r9 0x21200
00002cd5: fa 9f 00              iowr I[$r9] $r15
00002cd8: bd a4                 clear b32 $r10
00002cda: 7e c6 29 00           lcall 0x29c6
00002cde: 0a 01                 mov $r10 0x1
00002ce0: b2 ac                 mov b32 $r12 $r10
00002ce2: b2 ab                 mov b32 $r11 $r10
00002ce4: 7e f5 0c 00           lcall 0xcf5
00002ce8: 7e 0c 29 00           lcall 0x290c
00002cec: bd a4                 clear b32 $r10
00002cee: 7e 88 29 00           lcall 0x2988
00002cf2: 8a 00 a8 41           mov $r10 0x41a800
00002cf6: bd b4                 clear b32 $r11
00002cf8: 7e 37 02 00           lcall 0x237
00002cfc: bd b4                 clear b32 $r11
00002cfe: 0a 11                 mov $r10 0x11
00002d00: 7e c5 0c 00           lcall 0xcc5
00002d04: 7e d1 0e 00           lcall 0xed1
00002d08: 0a 01                 mov $r10 0x1
00002d0a: 7e 15 04 00           lcall 0x415
00002d0e: 7e 19 2c 00           lcall 0x2c19
00002d12: bd a4                 clear b32 $r10
00002d14: 7e 8c 2c 00           lcall 0x2c8c
00002d18: 7e 19 2c 00           lcall 0x2c19
00002d1c: 0b 01                 mov $r11 0x1
00002d1e: 0a 0f                 mov $r10 0xf
00002d20: 7e ed 03 00           lcall 0x3ed
00002d24: 7e 19 2c 00           lcall 0x2c19
00002d28: bd a4                 clear b32 $r10
00002d2a: 7e 44 2c 00           lcall 0x2c44
00002d2e: 7e 19 2c 00           lcall 0x2c19
00002d32: 0a 0f                 mov $r10 0xf
00002d34: bd b4                 clear b32 $r11
00002d36: 7e ed 03 00           lcall 0x3ed
00002d3a: 7e 19 2c 00           lcall 0x2c19
00002d3e: 0b 01                 mov $r11 0x1
00002d40: 0a 03                 mov $r10 0x3
00002d42: 7e ed 03 00           lcall 0x3ed
00002d46: 7e 19 2c 00           lcall 0x2c19
00002d4a: bd a4                 clear b32 $r10
00002d4c: 7e 15 04 00           lcall 0x415
00002d50: 7e 19 2c 00           lcall 0x2c19
00002d54: 7e fc 23 00           lcall 0x23fc
00002d58: 0a 08                 mov $r10 0x8
00002d5a: 7e af 23 00           lcall 0x23af
00002d5e: bd a4                 clear b32 $r10
00002d60: 7e c6 29 00           lcall 0x29c6
00002d64: 0a 01                 mov $r10 0x1
00002d66: b2 ab                 mov b32 $r11 $r10
00002d68: b2 ac                 mov b32 $r12 $r10
00002d6a: 7e 7b 0c 00           lcall 0xc7b
00002d6e: 7e 0c 29 00           lcall 0x290c
00002d72: bd a4                 clear b32 $r10
00002d74: 7e 88 29 00           lcall 0x2988
00002d78: 7e fc 23 00           lcall 0x23fc
00002d7c: 0f 01                 mov $r15 0x1
00002d7e: 89 00 00 02           mov $r9 0x20000
00002d82: fa 9f 00              iowr I[$r9] $r15
00002d85: 4f 00 01              mov $r15 0x100
00002d88: b8 99 00 18 00        add b32 $r9 $r9 0x1800
00002d8d: fa 9f 00              iowr I[$r9] $r15
00002d90: f8 00                 ret

00002d92: f9 52              C  mpush $r5
00002d94: b2 a5                 mov b32 $r5 $r10
00002d96: b2 b4                 mov b32 $r4 $r11
00002d98: b2 c3                 mov b32 $r3 $r12
00002d9a: bd 14                 clear b32 $r1
00002d9c: bd 04                 clear b32 $r0
00002d9e: 3e d3 2d 00           lbra 0x2dd3
00002da2: 7e 5e 21 00         B lcall 0x215e
00002da6: b2 2a               B mov b32 $r10 $r2
00002da8: 7e 97 02 00           lcall 0x297
00002dac: b3 a4 00 f6           bra b32 $r10 0x0 ne 0x2da2
00002db0: 3e bc 2d 00           lbra 0x2dbc
00002db4: 7e 5e 21 00         B lcall 0x215e
00002db8: 3e bf 2d 00           lbra 0x2dbf
00002dbc: bc 04 20            B add b32 $r2 $r0 $r4
00002dbf: b2 2a               B mov b32 $r10 $r2
00002dc1: 7e 97 02 00           lcall 0x297
00002dc5: f0 a4 07              and $r10 0x7
00002dc8: f4 1b ec              bra ne 0x2db4
00002dcb: 90 11 01              add b32 $r1 $r1 0x1
00002dce: b8 00 00 02 00        add b32 $r0 $r0 0x200
00002dd3: a6 13               B cmp b32 $r1 $r3
00002dd5: f4 18 0a              bra ae 0x2ddf
00002dd8: bc 05 20              add b32 $r2 $r0 $r5
00002ddb: 3e a6 2d 00           lbra 0x2da6
00002ddf: fb 51               B mpopret $r5

00002de1: f9 42              C  mpush $r4
00002de3: 4f 00 02              mov $r15 0x200
00002de6: b2 d2                 mov b32 $r2 $r13
00002de8: b2 b3                 mov b32 $r3 $r11
00002dea: b2 c4                 mov b32 $r4 $r12
00002dec: b4 d0 06              ld b32 $r13 D[$sp+0x18]
00002def: 89 00 13 02           mov $r9 0x21300
00002df3: fa 9f 00              iowr I[$r9] $r15
00002df6: 0f 01                 mov $r15 0x1
00002df8: b3 d0 02 3a           bra b32 $r13 0x2 e 0x2e32
00002dfc: b3 d0 01 0a           bra b32 $r13 0x1 e 0x2e06
00002e00: bd f4                 clear b32 $r15
00002e02: 3e 32 2e 00           lbra 0x2e32
00002e06: b3 e4 00 0d         B bra b32 $r14 0x0 ne 0x2e13
00002e0a: df 02 00 00 80        mov $r15 0x80000002
00002e0f: 3e 32 2e 00           lbra 0x2e32
00002e13: b3 e4 03 0d         B bra b32 $r14 0x3 ne 0x2e20
00002e17: df 03 00 00 80        mov $r15 0x80000003
00002e1c: 3e 32 2e 00           lbra 0x2e32
00002e20: b3 e4 02 0d         B bra b32 $r14 0x2 ne 0x2e2d
00002e24: df 04 00 00 80        mov $r15 0x80000004
00002e29: 3e 32 2e 00           lbra 0x2e32
00002e2d: df 00 00 00 80      B mov $r15 0x80000000
00002e32: 89 00 88 02         B mov $r9 0x28800
00002e36: fa 9f 00              iowr I[$r9] $r15
00002e39: fe a7 00              mov $xdbase $r10
00002e3c: bd 94                 clear b32 $r9
00002e3e: fe 9b 00              mov $xtargets $r9
00002e41: 4a 00 43              mov $r10 0x4300
00002e44: bd b4                 clear b32 $r11
00002e46: 7e 10 00 00           lcall 0x10
00002e4a: 4f 00 48              mov $r15 0x4800
00002e4d: bd 94                 clear b32 $r9
00002e4f: ff f9 9f              iord $r9 I[$r15+$r9*0x4]
00002e52: bd 04                 clear b32 $r0
00002e54: b2 f1                 mov b32 $r1 $r15
00002e56: 3e 61 2e 00           lbra 0x2e61
00002e5a: 7e 5e 21 00         B lcall 0x215e
00002e5e: ff 10 9f              iord $r9 I[$r1+$r0*0x4]
00002e61: 95 9f 18            B shr b32 $r15 $r9 0x18
00002e64: c7 99 f0              extr $r9 $r9 0x10:0x17
00002e67: bc 9f 90              add b32 $r9 $r9 $r15
00002e6a: b3 90 04 f0           bra b32 $r9 0x4 e 0x2e5a
00002e6e: b4 90 07              ld b32 $r9 D[$sp+0x1c]
00002e71: 94 4c 10              shl b32 $r12 $r4 0x10
00002e74: b3 94 01 0e           bra b32 $r9 0x1 ne 0x2e82
00002e78: ff 2c 95              or $r9 $r2 $r12
00002e7b: fa 39 05              xdld $r3 $r9
00002e7e: 3e 88 2e 00           lbra 0x2e88
00002e82: ff 2c 95            B or $r9 $r2 $r12
00002e85: fa 39 06              xdst $r3 $r9
00002e88: b4 90 08            B ld b32 $r9 D[$sp+0x20]
00002e8b: b3 94 02 20           bra b32 $r9 0x2 ne 0x2eab
00002e8f: 3e 9b 2e 00           lbra 0x2e9b
00002e93: 7e 5e 21 00         B lcall 0x215e
00002e97: 3e a0 2e 00           lbra 0x2ea0
00002e9b: 41 00 48            B mov $r1 0x4800
00002e9e: bd 04                 clear b32 $r0
00002ea0: ff 10 9f            B iord $r9 I[$r1+$r0*0x4]
00002ea3: f0 94 02              and $r9 0x2
00002ea6: f4 1b ed              bra ne 0x2e93
00002ea9: f8 03                 xdwait
00002eab: bd f4               B clear b32 $r15
00002ead: 89 00 88 02           mov $r9 0x28800
00002eb1: fa 9f 00              iowr I[$r9] $r15
00002eb4: 4f 00 02              mov $r15 0x200
00002eb7: b8 99 00 6f 02        sub b32 $r9 $r9 0x6f00
00002ebc: fa 9f 00              iowr I[$r9] $r15
00002ebf: fb 41                 mpopret $r4

00002ec1: f9 02              C  mpush $r0
00002ec3: 0f 04                 mov $r15 0x4
00002ec5: f4 30 f4              add $sp -0xc
00002ec8: b2 a0                 mov b32 $r0 $r10
00002eca: 89 00 13 02           mov $r9 0x21300
00002ece: fa 9f 00              iowr I[$r9] $r15
00002ed1: 09 02                 mov $r9 0x2
00002ed3: b0 91 00              st b32 D[$sp] $r9
00002ed6: 09 01                 mov $r9 0x1
00002ed8: b0 a1 02              st b32 D[$sp+0x8] $r10
00002edb: bd b4                 clear b32 $r11
00002edd: b0 91 01              st b32 D[$sp+0x4] $r9
00002ee0: bd a4                 clear b32 $r10
00002ee2: 0c 06                 mov $r12 0x6
00002ee4: 8d 00 0a 00           mov $r13 0xa00
00002ee8: bd e4                 clear b32 $r14
00002eea: 7e e1 2d 00           lcall 0x2de1
00002eee: bd b4                 clear b32 $r11
00002ef0: 89 00 0e 00         B mov $r9 0xe00
00002ef4: 8d 00 0a 00           mov $r13 0xa00
00002ef8: bc b9 f0              add b32 $r15 $r11 $r9
00002efb: bc bd 90              add b32 $r9 $r11 $r13
00002efe: bf 99                 ld b32 $r9 D[$r9]
00002f00: 90 bb 04              add b32 $r11 $r11 0x4
00002f03: a0 f9                 st b32 D[$r15] $r9
00002f05: b3 be 00 01 eb        bra b32 $r11 0x100 ne 0x2ef0
00002f0a: 09 02                 mov $r9 0x2
00002f0c: b0 91 00              st b32 D[$sp] $r9
00002f0f: 09 01                 mov $r9 0x1
00002f11: bd e4                 clear b32 $r14
00002f13: b0 91 01              st b32 D[$sp+0x4] $r9
00002f16: b0 01 02              st b32 D[$sp+0x8] $r0
00002f19: bd a4                 clear b32 $r10
00002f1b: 0c 06                 mov $r12 0x6
00002f1d: 7e e1 2d 00           lcall 0x2de1
00002f21: 89 00 0a 00           mov $r9 0xa00
00002f25: 8f 00 0f 00           mov $r15 0xf00
00002f29: 8e 00 0b 00           mov $r14 0xb00
00002f2d: bf 9d               B ld b32 $r13 D[$r9]
00002f2f: 90 99 04              add b32 $r9 $r9 0x4
00002f32: a0 fd                 st b32 D[$r15] $r13
00002f34: 90 ff 04              add b32 $r15 $r15 0x4
00002f37: a6 9e                 cmp b32 $r9 $r14
00002f39: f4 1b f4              bra ne 0x2f2d
00002f3c: 0f 04                 mov $r15 0x4
00002f3e: 89 00 19 02           mov $r9 0x21900
00002f42: fa 9f 00              iowr I[$r9] $r15
00002f45: f4 30 0c              add $sp 0xc
00002f48: fb 01                 mpopret $r0

00002f4a: f9 02              C  mpush $r0
00002f4c: 0f 08                 mov $r15 0x8
00002f4e: f4 30 f4              add $sp -0xc
00002f51: b2 a0                 mov b32 $r0 $r10
00002f53: 89 00 13 02           mov $r9 0x21300
00002f57: fa 9f 00              iowr I[$r9] $r15
00002f5a: bd e4                 clear b32 $r14
00002f5c: 89 00 0a 00         B mov $r9 0xa00
00002f60: 8d 00 0e 00           mov $r13 0xe00
00002f64: bc e9 f0              add b32 $r15 $r14 $r9
00002f67: bc ed 90              add b32 $r9 $r14 $r13
00002f6a: bf 99                 ld b32 $r9 D[$r9]
00002f6c: 90 ee 04              add b32 $r14 $r14 0x4
00002f6f: a0 f9                 st b32 D[$r15] $r9
00002f71: b3 ee 00 01 eb        bra b32 $r14 0x100 ne 0x2f5c
00002f76: 09 02                 mov $r9 0x2
00002f78: bd e4                 clear b32 $r14
00002f7a: b0 91 01              st b32 D[$sp+0x4] $r9
00002f7d: b0 91 00              st b32 D[$sp] $r9
00002f80: b0 01 02              st b32 D[$sp+0x8] $r0
00002f83: bd a4                 clear b32 $r10
00002f85: bd b4                 clear b32 $r11
00002f87: 0c 06                 mov $r12 0x6
00002f89: 8d 00 0a 00           mov $r13 0xa00
00002f8d: 7e e1 2d 00           lcall 0x2de1
00002f91: 89 00 0f 00           mov $r9 0xf00
00002f95: 8f 00 0a 00           mov $r15 0xa00
00002f99: 8e 00 10 00           mov $r14 0x1000
00002f9d: bf 9d               B ld b32 $r13 D[$r9]
00002f9f: 90 99 04              add b32 $r9 $r9 0x4
00002fa2: a0 fd                 st b32 D[$r15] $r13
00002fa4: 90 ff 04              add b32 $r15 $r15 0x4
00002fa7: a6 9e                 cmp b32 $r9 $r14
00002fa9: f4 1b f4              bra ne 0x2f9d
00002fac: 09 02                 mov $r9 0x2
00002fae: b0 01 02              st b32 D[$sp+0x8] $r0
00002fb1: b0 91 01              st b32 D[$sp+0x4] $r9
00002fb4: b0 91 00              st b32 D[$sp] $r9
00002fb7: bd a4                 clear b32 $r10
00002fb9: 4b 00 01              mov $r11 0x100
00002fbc: 0c 06                 mov $r12 0x6
00002fbe: 8d 00 0a 00           mov $r13 0xa00
00002fc2: bd e4                 clear b32 $r14
00002fc4: 7e e1 2d 00           lcall 0x2de1
00002fc8: 0f 08                 mov $r15 0x8
00002fca: 89 00 19 02           mov $r9 0x21900
00002fce: fa 9f 00              iowr I[$r9] $r15
00002fd1: f4 30 0c              add $sp 0xc
00002fd4: fb 01                 mpopret $r0

00002fd6: f9 02              C  mpush $r0
00002fd8: 0f 01                 mov $r15 0x1
00002fda: f4 30 f4              add $sp -0xc
00002fdd: b2 a0                 mov b32 $r0 $r10
00002fdf: 89 00 13 02           mov $r9 0x21300
00002fe3: fa 9f 00              iowr I[$r9] $r15
00002fe6: 09 02                 mov $r9 0x2
00002fe8: b0 91 00              st b32 D[$sp] $r9
00002feb: 09 01                 mov $r9 0x1
00002fed: b0 a1 02              st b32 D[$sp+0x8] $r10
00002ff0: bd e4                 clear b32 $r14
00002ff2: b0 91 01              st b32 D[$sp+0x4] $r9
00002ff5: bd a4                 clear b32 $r10
00002ff7: 4b 00 02              mov $r11 0x200
00002ffa: 0c 06                 mov $r12 0x6
00002ffc: 8d 00 0a 00           mov $r13 0xa00
00003000: 7e e1 2d 00           lcall 0x2de1
00003004: bd e4                 clear b32 $r14
00003006: 89 00 10 00         B mov $r9 0x1000
0000300a: 8d 00 0a 00           mov $r13 0xa00
0000300e: bc e9 f0              add b32 $r15 $r14 $r9
00003011: bc ed 90              add b32 $r9 $r14 $r13
00003014: bf 99                 ld b32 $r9 D[$r9]
00003016: 90 ee 04              add b32 $r14 $r14 0x4
00003019: a0 f9                 st b32 D[$r15] $r9
0000301b: b3 ee 00 01 eb        bra b32 $r14 0x100 ne 0x3006
00003020: 09 02                 mov $r9 0x2
00003022: b0 91 00              st b32 D[$sp] $r9
00003025: 09 01                 mov $r9 0x1
00003027: bd e4                 clear b32 $r14
00003029: b0 91 01              st b32 D[$sp+0x4] $r9
0000302c: b0 01 02              st b32 D[$sp+0x8] $r0
0000302f: bd a4                 clear b32 $r10
00003031: 4b 00 03              mov $r11 0x300
00003034: 0c 06                 mov $r12 0x6
00003036: 7e e1 2d 00           lcall 0x2de1
0000303a: 89 00 0a 00           mov $r9 0xa00
0000303e: 8f 00 11 00           mov $r15 0x1100
00003042: 8e 00 0b 00           mov $r14 0xb00
00003046: bf 9d               B ld b32 $r13 D[$r9]
00003048: 90 99 04              add b32 $r9 $r9 0x4
0000304b: a0 fd                 st b32 D[$r15] $r13
0000304d: 90 ff 04              add b32 $r15 $r15 0x4
00003050: a6 9e                 cmp b32 $r9 $r14
00003052: f4 1b f4              bra ne 0x3046
00003055: 0f 01                 mov $r15 0x1
00003057: 89 00 19 02           mov $r9 0x21900
0000305b: fa 9f 00              iowr I[$r9] $r15
0000305e: f4 30 0c              add $sp 0xc
00003061: fb 01                 mpopret $r0

00003063: f9 02              C  mpush $r0
00003065: 0f 02                 mov $r15 0x2
00003067: f4 30 f4              add $sp -0xc
0000306a: b2 a0                 mov b32 $r0 $r10
0000306c: 89 00 13 02           mov $r9 0x21300
00003070: fa 9f 00              iowr I[$r9] $r15
00003073: bd e4                 clear b32 $r14
00003075: 89 00 0a 00         B mov $r9 0xa00
00003079: 8d 00 10 00           mov $r13 0x1000
0000307d: bc e9 f0              add b32 $r15 $r14 $r9
00003080: bc ed 90              add b32 $r9 $r14 $r13
00003083: bf 99                 ld b32 $r9 D[$r9]
00003085: 90 ee 04              add b32 $r14 $r14 0x4
00003088: a0 f9                 st b32 D[$r15] $r9
0000308a: b3 ee 00 01 eb        bra b32 $r14 0x100 ne 0x3075
0000308f: 09 02                 mov $r9 0x2
00003091: bd e4                 clear b32 $r14
00003093: b0 91 01              st b32 D[$sp+0x4] $r9
00003096: b0 91 00              st b32 D[$sp] $r9
00003099: b0 01 02              st b32 D[$sp+0x8] $r0
0000309c: bd a4                 clear b32 $r10
0000309e: 4b 00 02              mov $r11 0x200
000030a1: 0c 06                 mov $r12 0x6
000030a3: 8d 00 0a 00           mov $r13 0xa00
000030a7: 7e e1 2d 00           lcall 0x2de1
000030ab: 89 00 11 00           mov $r9 0x1100
000030af: 8f 00 0a 00           mov $r15 0xa00
000030b3: 8e 00 12 00           mov $r14 0x1200
000030b7: bf 9d               B ld b32 $r13 D[$r9]
000030b9: 90 99 04              add b32 $r9 $r9 0x4
000030bc: a0 fd                 st b32 D[$r15] $r13
000030be: 90 ff 04              add b32 $r15 $r15 0x4
000030c1: a6 9e                 cmp b32 $r9 $r14
000030c3: f4 1b f4              bra ne 0x30b7
000030c6: b0 01 02              st b32 D[$sp+0x8] $r0
000030c9: bd a4                 clear b32 $r10
000030cb: 00 02                 mov $r0 0x2
000030cd: 4b 00 03              mov $r11 0x300
000030d0: b0 01 00              st b32 D[$sp] $r0
000030d3: b0 01 01              st b32 D[$sp+0x4] $r0
000030d6: 0c 06                 mov $r12 0x6
000030d8: 8d 00 0a 00           mov $r13 0xa00
000030dc: bd e4                 clear b32 $r14
000030de: 7e e1 2d 00           lcall 0x2de1
000030e2: 89 00 19 02           mov $r9 0x21900
000030e6: fa 90 00              iowr I[$r9] $r0
000030e9: f4 30 0c              add $sp 0xc
000030ec: fb 01                 mpopret $r0
000030ee: f9 12                 mpush $r1
000030f0: 81 ac 12 00           mov $r1 0x12ac
000030f4: bf 19                 ld b32 $r9 D[$r1]
000030f6: f4 30 f4              add $sp -0xc
000030f9: b3 94 00 36           bra b32 $r9 0x0 ne 0x312f
000030fd: 89 a4 12 00           mov $r9 0x12a4
00003101: bf 9b                 ld b32 $r11 D[$r9]
00003103: 89 a0 12 00           mov $r9 0x12a0
00003107: bf 9f                 ld b32 $r15 D[$r9]
00003109: 09 02                 mov $r9 0x2
0000310b: 00 01                 mov $r0 0x1
0000310d: b0 91 02              st b32 D[$sp+0x8] $r9
00003110: b6 b5 06              shr b32 $r11 0x6
00003113: b0 91 00              st b32 D[$sp] $r9
00003116: bc bf b0              add b32 $r11 $r11 $r15
00003119: b0 01 01              st b32 D[$sp+0x4] $r0
0000311c: b6 b4 08              shl b32 $r11 0x8
0000311f: bd a4                 clear b32 $r10
00003121: 0c 06                 mov $r12 0x6
00003123: 8d 00 0a 00           mov $r13 0xa00
00003127: bd e4                 clear b32 $r14
00003129: 7e e1 2d 00           lcall 0x2de1
0000312d: a0 10                 st b32 D[$r1] $r0
0000312f: 89 a4 12 00         B mov $r9 0x12a4
00003133: bf 9f                 ld b32 $r15 D[$r9]
00003135: 8d 00 0a 00           mov $r13 0xa00
00003139: c4 fe 3f              and $r14 $r15 0x3f
0000313c: 94 e9 02              shl b32 $r9 $r14 0x2
0000313f: bc 9d 90              add b32 $r9 $r9 $r13
00003142: bf 9a                 ld b32 $r10 D[$r9]
00003144: b3 e4 00 0a           bra b32 $r14 0x0 ne 0x314e
00003148: 89 ac 12 00           mov $r9 0x12ac
0000314c: a0 9e                 st b32 D[$r9] $r14
0000314e: 92 ff 01            B sub b32 $r15 $r15 0x1
00003151: 89 a4 12 00           mov $r9 0x12a4
00003155: f4 30 0c              add $sp 0xc
00003158: a0 9f                 st b32 D[$r9] $r15
0000315a: fb 11                 mpopret $r1

0000315c: 89 a4 12 00        C  mov $r9 0x12a4
00003160: bf 9b                 ld b32 $r11 D[$r9]
00003162: 89 a0 12 00           mov $r9 0x12a0
00003166: bf 9f                 ld b32 $r15 D[$r9]
00003168: 09 02                 mov $r9 0x2
0000316a: f4 30 f4              add $sp -0xc
0000316d: bd e4                 clear b32 $r14
0000316f: b0 91 02              st b32 D[$sp+0x8] $r9
00003172: b0 91 00              st b32 D[$sp] $r9
00003175: b0 91 01              st b32 D[$sp+0x4] $r9
00003178: 92 bb 01              sub b32 $r11 $r11 0x1
0000317b: bd a4                 clear b32 $r10
0000317d: b6 b5 06              shr b32 $r11 0x6
00003180: 0c 06                 mov $r12 0x6
00003182: bc bf b0              add b32 $r11 $r11 $r15
00003185: 8d 00 0a 00           mov $r13 0xa00
00003189: b6 b4 08              shl b32 $r11 0x8
0000318c: 7e e1 2d 00           lcall 0x2de1
00003190: 89 00 0a 00           mov $r9 0xa00
00003194: bd e4                 clear b32 $r14
00003196: 8f 00 0b 00           mov $r15 0xb00
0000319a: a0 9e               B st b32 D[$r9] $r14
0000319c: 90 99 04              add b32 $r9 $r9 0x4
0000319f: a6 9f                 cmp b32 $r9 $r15
000031a1: f4 1b f9              bra ne 0x319a
000031a4: f4 30 0c              add $sp 0xc
000031a7: f8 00                 ret
000031a9: 89 a4 12 00           mov $r9 0x12a4
000031ad: bf 9f                 ld b32 $r15 D[$r9]
000031af: 90 fe 01              add b32 $r14 $r15 0x1
000031b2: f0 f4 3f              and $r15 0x3f
000031b5: a0 9e                 st b32 D[$r9] $r14
000031b7: b6 f4 02              shl b32 $r15 0x2
000031ba: 89 00 0a 00           mov $r9 0xa00
000031be: bc f9 f0              add b32 $r15 $r15 $r9
000031c1: a0 fa                 st b32 D[$r15] $r10
000031c3: f0 e4 3f              and $r14 0x3f
000031c6: f4 1b 07              bra ne 0x31cd
000031c9: 7e 5c 31 00           lcall 0x315c
000031cd: f8 00               B ret

000031cf: f9 12              C  mpush $r1
000031d1: 4f 00 01              mov $r15 0x100
000031d4: 89 00 13 02           mov $r9 0x21300
000031d8: fa 9f 00              iowr I[$r9] $r15
000031db: 81 00 00 01           mov $r1 0x10000
000031df: bd 04                 clear b32 $r0
000031e1: 3e e9 31 00           lbra 0x31e9
000031e5: 7e 5e 21 00         B lcall 0x215e
000031e9: ff 10 9f            B iord $r9 I[$r1+$r0*0x4]
000031ec: f1 94 00 10           and $r9 0x1000
000031f0: f4 1b f5              bra ne 0x31e5
000031f3: 4f 00 01              mov $r15 0x100
000031f6: 89 00 19 02           mov $r9 0x21900
000031fa: fa 9f 00              iowr I[$r9] $r15
000031fd: fb 11                 mpopret $r1

000031ff: f9 52              C  mpush $r5
00003201: b2 a0                 mov b32 $r0 $r10
00003203: f4 30 f4              add $sp -0xc
00003206: b2 b1                 mov b32 $r1 $r11
00003208: b2 c2                 mov b32 $r2 $r12
0000320a: 7e 53 1f 00           lcall 0x1f53
0000320e: 09 01                 mov $r9 0x1
00003210: b3 a9 00 a2 00        bra b32 $r10 0x0 e 0x32b2
00003215: b2 1b                 mov b32 $r11 $r1
00003217: b2 2c                 mov b32 $r12 $r2
00003219: 0a 01                 mov $r10 0x1
0000321b: 7e da 1e 00           lcall 0x1eda
0000321f: b2 1b                 mov b32 $r11 $r1
00003221: b2 a5                 mov b32 $r5 $r10
00003223: b2 2c                 mov b32 $r12 $r2
00003225: 0a 02                 mov $r10 0x2
00003227: 7e da 1e 00           lcall 0x1eda
0000322b: e7 01 a2 01           extr $r1 $r0 0x2:0xf
0000322f: b2 a4                 mov b32 $r4 $r10
00003231: c7 0f 70              extr $r15 $r0 0x10:0x13
00003234: f4 0b 0b              bra e 0x323f
00003237: b3 f4 01 1f           bra b32 $r15 0x1 ne 0x3256
0000323b: 3e 49 32 00           lbra 0x3249
0000323f: 89 54 14 00         B mov $r9 0x1454
00003243: a0 9f                 st b32 D[$r9] $r15
00003245: 3e 5c 32 00           lbra 0x325c
00003249: 95 09 14            B shr b32 $r9 $r0 0x14
0000324c: 90 99 01              add b32 $r9 $r9 0x1
0000324f: 94 93 08              shl b32 $r3 $r9 0x8
00003252: 3e 5e 32 00           lbra 0x325e
00003256: 0a 11               B mov $r10 0x11
00003258: 7e c0 05 00           lcall 0x5c0
0000325c: bd 34               B clear b32 $r3
0000325e: 09 01               B mov $r9 0x1
00003260: 00 02                 mov $r0 0x2
00003262: bd a4                 clear b32 $r10
00003264: b2 3b                 mov b32 $r11 $r3
00003266: 0c 06                 mov $r12 0x6
00003268: 8d 00 0a 00           mov $r13 0xa00
0000326c: bd e4                 clear b32 $r14
0000326e: b0 91 01              st b32 D[$sp+0x4] $r9
00003271: b0 01 00              st b32 D[$sp] $r0
00003274: b0 01 02              st b32 D[$sp+0x8] $r0
00003277: 7e e1 2d 00           lcall 0x2de1
0000327b: 89 00 0a 00           mov $r9 0xa00
0000327f: 94 1f 02              shl b32 $r15 $r1 0x2
00003282: bc f9 f0              add b32 $r15 $r15 $r9
00003285: bf f1                 ld b32 $r1 D[$r15]
00003287: b2 9d                 mov b32 $r13 $r9
00003289: b2 3b                 mov b32 $r11 $r3
0000328b: bd a4                 clear b32 $r10
0000328d: 0c 06                 mov $r12 0x6
0000328f: bd e4                 clear b32 $r14
00003291: ff 45 24              and $r2 $r4 $r5
00003294: b9 49 00              not b32 $r9 $r4
00003297: fd 91 04              and $r9 $r1
0000329a: fd 92 05              or $r9 $r2
0000329d: a0 f9                 st b32 D[$r15] $r9
0000329f: b0 01 02              st b32 D[$sp+0x8] $r0
000032a2: b0 01 00              st b32 D[$sp] $r0
000032a5: b0 01 01              st b32 D[$sp+0x4] $r0
000032a8: 7e e1 2d 00           lcall 0x2de1
000032ac: 7e cf 31 00           lcall 0x31cf
000032b0: bd 94                 clear b32 $r9
000032b2: b2 9a               B mov b32 $r10 $r9
000032b4: f4 30 0c              add $sp 0xc
000032b7: fb 51                 mpopret $r5

000032b9: f9 22              C  mpush $r2
000032bb: b2 c0                 mov b32 $r0 $r12
000032bd: b2 a1                 mov b32 $r1 $r10
000032bf: b2 b2                 mov b32 $r2 $r11
000032c1: 7e cf 31 00           lcall 0x31cf
000032c5: b2 1b                 mov b32 $r11 $r1
000032c7: 8a 00 81 02           mov $r10 0x28100
000032cb: 7e 10 00 00           lcall 0x10
000032cf: b2 2b                 mov b32 $r11 $r2
000032d1: 8a 00 8e 02           mov $r10 0x28e00
000032d5: 7e 10 00 00           lcall 0x10
000032d9: b2 0b                 mov b32 $r11 $r0
000032db: 8a 00 8f 02           mov $r10 0x28f00
000032df: 7e 10 00 00           lcall 0x10
000032e3: fb 21                 mpopret $r2

000032e5: bd f4              C  clear b32 $r15
000032e7: 89 00 81 02           mov $r9 0x28100
000032eb: ff 9f 9f              iord $r9 I[$r9+$r15*0x4]
000032ee: 89 00 8e 02           mov $r9 0x28e00
000032f2: ff 9f 9f              iord $r9 I[$r9+$r15*0x4]
000032f5: 89 fc 12 00           mov $r9 0x12fc
000032f9: bf 9a                 ld b32 $r10 D[$r9]
000032fb: 89 00 13 00           mov $r9 0x1300
000032ff: bf 9b                 ld b32 $r11 D[$r9]
00003301: 89 04 13 00           mov $r9 0x1304
00003305: bf 9c                 ld b32 $r12 D[$r9]
00003307: 7e b9 32 00           lcall 0x32b9
0000330b: 0a 01                 mov $r10 0x1
0000330d: 7e e3 00 00           lcall 0xe3
00003311: 0a 0b                 mov $r10 0xb
00003313: 0b 3f                 mov $r11 0x3f
00003315: 7e c4 00 00           lcall 0xc4
00003319: 89 00 10 00           mov $r9 0x1000
0000331d: 98 9b 3a              ld b32 $r11 D[$r9+0xe8]
00003320: 0a 10                 mov $r10 0x10
00003322: c7 bb f0              extr $r11 $r11 0x10:0x17
00003325: 7e c4 00 00           lcall 0xc4
00003329: 89 88 06 00           mov $r9 0x688
0000332d: bf 9d                 ld b32 $r13 D[$r9]
0000332f: 0a 1a                 mov $r10 0x1a
00003331: 0b 02                 mov $r11 0x2
00003333: 8c 64 06 00           mov $r12 0x664
00003337: 7e e1 07 00           lcall 0x7e1
0000333b: 7e 75 21 00           lcall 0x2175
0000333f: 89 e0 12 00           mov $r9 0x12e0
00003343: bf 9a                 ld b32 $r10 D[$r9]
00003345: 89 e4 12 00           mov $r9 0x12e4
00003349: bf 9b                 ld b32 $r11 D[$r9]
0000334b: 89 e8 12 00           mov $r9 0x12e8
0000334f: bf 9c                 ld b32 $r12 D[$r9]
00003351: 7e b9 32 00           lcall 0x32b9
00003355: f8 00                 ret

00003357: f9 12              C  mpush $r1
00003359: 0a 65                 mov $r10 0x65
0000335b: bd b4                 clear b32 $r11
0000335d: 7e c5 0c 00           lcall 0xcc5
00003361: 89 fc 12 00           mov $r9 0x12fc
00003365: bf 9a                 ld b32 $r10 D[$r9]
00003367: 89 00 13 00           mov $r9 0x1300
0000336b: bf 9b                 ld b32 $r11 D[$r9]
0000336d: 89 04 13 00           mov $r9 0x1304
00003371: bf 9c                 ld b32 $r12 D[$r9]
00003373: 81 00 10 00           mov $r1 0x1000
00003377: 7e b9 32 00           lcall 0x32b9
0000337b: 0a 01                 mov $r10 0x1
0000337d: 7e e3 00 00           lcall 0xe3
00003381: 0b 0c                 mov $r11 0xc
00003383: 0a 0b                 mov $r10 0xb
00003385: 7e c4 00 00           lcall 0xc4
00003389: 98 10 3a              ld b32 $r0 D[$r1+0xe8]
0000338c: 0a 02                 mov $r10 0x2
0000338e: 7e 7a 09 00           lcall 0x97a
00003392: 95 ab 08              shr b32 $r11 $r10 0x8
00003395: f1 04 ff ff           and $r0 0xffff
00003399: 0a 10                 mov $r10 0x10
0000339b: bc b0 b0              add b32 $r11 $r11 $r0
0000339e: 7e c4 00 00           lcall 0xc4
000033a2: 89 60 06 00           mov $r9 0x660
000033a6: bf 9d                 ld b32 $r13 D[$r9]
000033a8: 8c 30 06 00           mov $r12 0x630
000033ac: 0a 0c                 mov $r10 0xc
000033ae: 0b 02                 mov $r11 0x2
000033b0: 7e e1 07 00           lcall 0x7e1
000033b4: 89 a4 14 00           mov $r9 0x14a4
000033b8: bf 99                 ld b32 $r9 D[$r9]
000033ba: 0a 0b                 mov $r10 0xb
000033bc: bc 99 b0              add b32 $r11 $r9 $r9
000033bf: bc b9 b0              add b32 $r11 $r11 $r9
000033c2: b6 b4 02              shl b32 $r11 0x2
000033c5: 7e c4 00 00           lcall 0xc4
000033c9: 98 10 3b              ld b32 $r0 D[$r1+0xec]
000033cc: 0a 0d                 mov $r10 0xd
000033ce: 7e 7a 09 00           lcall 0x97a
000033d2: 95 ab 08              shr b32 $r11 $r10 0x8
000033d5: f1 04 ff ff           and $r0 0xffff
000033d9: 0a 10                 mov $r10 0x10
000033db: bc b0 b0              add b32 $r11 $r11 $r0
000033de: 7e c4 00 00           lcall 0xc4
000033e2: 89 8c 08 00           mov $r9 0x88c
000033e6: bf 9d                 ld b32 $r13 D[$r9]
000033e8: 8c 5c 08 00           mov $r12 0x85c
000033ec: 0a 0f                 mov $r10 0xf
000033ee: 0b 02                 mov $r11 0x2
000033f0: 7e e1 07 00           lcall 0x7e1
000033f4: 0b 02                 mov $r11 0x2
000033f6: 0a 0b                 mov $r10 0xb
000033f8: 7e c4 00 00           lcall 0xc4
000033fc: 98 10 3a              ld b32 $r0 D[$r1+0xe8]
000033ff: 0a 1a                 mov $r10 0x1a
00003401: 7e 7a 09 00           lcall 0x97a
00003405: 95 ab 08              shr b32 $r11 $r10 0x8
00003408: c7 00 f0              extr $r0 $r0 0x10:0x17
0000340b: 0a 10                 mov $r10 0x10
0000340d: bc b0 b0              add b32 $r11 $r11 $r0
00003410: 7e c4 00 00           lcall 0xc4
00003414: 89 94 06 00           mov $r9 0x694
00003418: bf 9d                 ld b32 $r13 D[$r9]
0000341a: 0a 1b                 mov $r10 0x1b
0000341c: 0b 02                 mov $r11 0x2
0000341e: 8c 8c 06 00           mov $r12 0x68c
00003422: 7e e1 07 00           lcall 0x7e1
00003426: 7e 75 21 00           lcall 0x2175
0000342a: 89 e0 12 00           mov $r9 0x12e0
0000342e: bf 9a                 ld b32 $r10 D[$r9]
00003430: 89 e4 12 00           mov $r9 0x12e4
00003434: bf 9b                 ld b32 $r11 D[$r9]
00003436: 89 e8 12 00           mov $r9 0x12e8
0000343a: bf 9c                 ld b32 $r12 D[$r9]
0000343c: 7e b9 32 00           lcall 0x32b9
00003440: 7e fc 23 00           lcall 0x23fc
00003444: fb 11                 mpopret $r1

00003446: f9 02              C  mpush $r0
00003448: df 00 00 80 00        mov $r15 0x800000
0000344d: 89 00 14 02           mov $r9 0x21400
00003451: fa 9f 00              iowr I[$r9] $r15
00003454: 89 0c 13 00           mov $r9 0x130c
00003458: bf 99                 ld b32 $r9 D[$r9]
0000345a: b3 94 02 08           bra b32 $r9 0x2 ne 0x3462
0000345e: 7e 7c 22 00           lcall 0x227c
00003462: 89 0c 13 00         B mov $r9 0x130c
00003466: bf 99                 ld b32 $r9 D[$r9]
00003468: 92 99 01              sub b32 $r9 $r9 0x1
0000346b: b0 96 01              cmp b32 $r9 0x1
0000346e: f5 0c 82 00           bra a 0x34f0
00003472: 89 fc 12 00           mov $r9 0x12fc
00003476: bf 9a                 ld b32 $r10 D[$r9]
00003478: 89 00 13 00           mov $r9 0x1300
0000347c: bf 9b                 ld b32 $r11 D[$r9]
0000347e: 89 04 13 00           mov $r9 0x1304
00003482: bf 9c                 ld b32 $r12 D[$r9]
00003484: 7e b9 32 00           lcall 0x32b9
00003488: bd a4                 clear b32 $r10
0000348a: 7e e3 00 00           lcall 0xe3
0000348e: 89 00 10 00           mov $r9 0x1000
00003492: 98 90 3a              ld b32 $r0 D[$r9+0xe8]
00003495: 0a 0f                 mov $r10 0xf
00003497: c7 00 f0              extr $r0 $r0 0x10:0x17
0000349a: b2 0b                 mov b32 $r11 $r0
0000349c: 7e c4 00 00           lcall 0xc4
000034a0: 89 88 06 00           mov $r9 0x688
000034a4: bf 9d                 ld b32 $r13 D[$r9]
000034a6: 8c 64 06 00           mov $r12 0x664
000034aa: 0b 02                 mov $r11 0x2
000034ac: 0a 1a                 mov $r10 0x1a
000034ae: 7e e1 07 00           lcall 0x7e1
000034b2: 0a 1a                 mov $r10 0x1a
000034b4: 7e 7a 09 00           lcall 0x97a
000034b8: 95 ab 08              shr b32 $r11 $r10 0x8
000034bb: 0a 0f                 mov $r10 0xf
000034bd: bc b0 b0              add b32 $r11 $r11 $r0
000034c0: 7e c4 00 00           lcall 0xc4
000034c4: 89 94 06 00           mov $r9 0x694
000034c8: bf 9d                 ld b32 $r13 D[$r9]
000034ca: 0a 1b                 mov $r10 0x1b
000034cc: 0b 02                 mov $r11 0x2
000034ce: 8c 8c 06 00           mov $r12 0x68c
000034d2: 7e e1 07 00           lcall 0x7e1
000034d6: 7e 75 21 00           lcall 0x2175
000034da: 89 e0 12 00           mov $r9 0x12e0
000034de: bf 9a                 ld b32 $r10 D[$r9]
000034e0: 89 e4 12 00           mov $r9 0x12e4
000034e4: bf 9b                 ld b32 $r11 D[$r9]
000034e6: 89 e8 12 00           mov $r9 0x12e8
000034ea: bf 9c                 ld b32 $r12 D[$r9]
000034ec: 7e b9 32 00           lcall 0x32b9
000034f0: df 00 00 80 00      B mov $r15 0x800000
000034f5: 89 00 1a 02           mov $r9 0x21a00
000034f9: fa 9f 00              iowr I[$r9] $r15
000034fc: fb 01                 mpopret $r0

000034fe: f9 02              C  mpush $r0
00003500: df 00 00 00 04        mov $r15 0x4000000
00003505: 89 00 14 02           mov $r9 0x21400
00003509: fa 9f 00              iowr I[$r9] $r15
0000350c: 89 0c 13 00           mov $r9 0x130c
00003510: bf 99                 ld b32 $r9 D[$r9]
00003512: 92 99 01              sub b32 $r9 $r9 0x1
00003515: b0 96 01              cmp b32 $r9 0x1
00003518: f5 0c 25 01           bra a 0x363d
0000351c: 89 fc 12 00           mov $r9 0x12fc
00003520: bf 9a                 ld b32 $r10 D[$r9]
00003522: 89 00 13 00           mov $r9 0x1300
00003526: bf 9b                 ld b32 $r11 D[$r9]
00003528: 89 04 13 00           mov $r9 0x1304
0000352c: bf 9c                 ld b32 $r12 D[$r9]
0000352e: 80 00 10 00           mov $r0 0x1000
00003532: 7e b9 32 00           lcall 0x32b9
00003536: 0a 01                 mov $r10 0x1
00003538: 7e e3 00 00           lcall 0xe3
0000353c: 0a 0b                 mov $r10 0xb
0000353e: 4b 4d 03              mov $r11 0x34d
00003541: 7e c4 00 00           lcall 0xc4
00003545: 98 0b 3a              ld b32 $r11 D[$r0+0xe8]
00003548: 0a 10                 mov $r10 0x10
0000354a: f0 b3 00              sethi $r11 0x0
0000354d: 7e c4 00 00           lcall 0xc4
00003551: 89 2c 06 00           mov $r9 0x62c
00003555: bf 9d                 ld b32 $r13 D[$r9]
00003557: 8c 2c 04 00           mov $r12 0x42c
0000355b: 0a 02                 mov $r10 0x2
0000355d: b2 ab                 mov b32 $r11 $r10
0000355f: 7e e1 07 00           lcall 0x7e1
00003563: 0a 0b                 mov $r10 0xb
00003565: 0b 3f                 mov $r11 0x3f
00003567: 7e c4 00 00           lcall 0xc4
0000356b: 98 0b 3a              ld b32 $r11 D[$r0+0xe8]
0000356e: 0a 10                 mov $r10 0x10
00003570: c7 bb f0              extr $r11 $r11 0x10:0x17
00003573: 7e c4 00 00           lcall 0xc4
00003577: 89 88 06 00           mov $r9 0x688
0000357b: bf 9d                 ld b32 $r13 D[$r9]
0000357d: 8c 64 06 00           mov $r12 0x664
00003581: 0a 1a                 mov $r10 0x1a
00003583: 0b 02                 mov $r11 0x2
00003585: 7e e1 07 00           lcall 0x7e1
00003589: 89 a4 14 00           mov $r9 0x14a4
0000358d: bf 9a                 ld b32 $r10 D[$r9]
0000358f: 4b 22 03              mov $r11 0x322
00003592: 7e ce 77 00           lcall 0x77ce
00003596: 89 ac 14 00           mov $r9 0x14ac
0000359a: bf 9f                 ld b32 $r15 D[$r9]
0000359c: 89 b0 14 00           mov $r9 0x14b0
000035a0: bf 9e                 ld b32 $r14 D[$r9]
000035a2: bc ff 90              add b32 $r9 $r15 $r15
000035a5: bc 9f 90              add b32 $r9 $r9 $r15
000035a8: bc a9 a0              add b32 $r10 $r10 $r9
000035ab: 90 aa 03              add b32 $r10 $r10 0x3
000035ae: 94 eb 02              shl b32 $r11 $r14 0x2
000035b1: bc be b0              add b32 $r11 $r11 $r14
000035b4: bc ab b0              add b32 $r11 $r10 $r11
000035b7: 0a 0b                 mov $r10 0xb
000035b9: 7e c4 00 00           lcall 0xc4
000035bd: 98 0b 3b              ld b32 $r11 D[$r0+0xec]
000035c0: 0a 10                 mov $r10 0x10
000035c2: f0 b3 00              sethi $r11 0x0
000035c5: 7e c4 00 00           lcall 0xc4
000035c9: 89 48 08 00           mov $r9 0x848
000035cd: bf 9d                 ld b32 $r13 D[$r9]
000035cf: 0a 0d                 mov $r10 0xd
000035d1: 0b 01                 mov $r11 0x1
000035d3: 8c 98 06 00           mov $r12 0x698
000035d7: 7e e1 07 00           lcall 0x7e1
000035db: 89 58 08 00           mov $r9 0x858
000035df: bf 9d                 ld b32 $r13 D[$r9]
000035e1: 0a 0e                 mov $r10 0xe
000035e3: 0b 03                 mov $r11 0x3
000035e5: 8c 4c 08 00           mov $r12 0x84c
000035e9: 7e e1 07 00           lcall 0x7e1
000035ed: 89 b0 08 00           mov $r9 0x8b0
000035f1: bf 9d                 ld b32 $r13 D[$r9]
000035f3: 0a 16                 mov $r10 0x16
000035f5: 0b 03                 mov $r11 0x3
000035f7: 8c a8 08 00           mov $r12 0x8a8
000035fb: 7e e1 07 00           lcall 0x7e1
000035ff: 89 c0 08 00           mov $r9 0x8c0
00003603: bf 9d                 ld b32 $r13 D[$r9]
00003605: 0a 18                 mov $r10 0x18
00003607: 0b 03                 mov $r11 0x3
00003609: 8c b4 08 00           mov $r12 0x8b4
0000360d: 7e e1 07 00           lcall 0x7e1
00003611: 89 a4 08 00           mov $r9 0x8a4
00003615: bf 9d                 ld b32 $r13 D[$r9]
00003617: 0a 17                 mov $r10 0x17
00003619: 0b 04                 mov $r11 0x4
0000361b: 8c 90 08 00           mov $r12 0x890
0000361f: 7e e1 07 00           lcall 0x7e1
00003623: 7e 75 21 00           lcall 0x2175
00003627: 89 e0 12 00           mov $r9 0x12e0
0000362b: bf 9a                 ld b32 $r10 D[$r9]
0000362d: 89 e4 12 00           mov $r9 0x12e4
00003631: bf 9b                 ld b32 $r11 D[$r9]
00003633: 89 e8 12 00           mov $r9 0x12e8
00003637: bf 9c                 ld b32 $r12 D[$r9]
00003639: 7e b9 32 00           lcall 0x32b9
0000363d: df 00 00 00 04      B mov $r15 0x4000000
00003642: 89 00 1a 02           mov $r9 0x21a00
00003646: fa 9f 00              iowr I[$r9] $r15
00003649: fb 01                 mpopret $r0

0000364b: f9 12              C  mpush $r1
0000364d: df 00 00 00 02        mov $r15 0x2000000
00003652: 89 00 14 02           mov $r9 0x21400
00003656: fa 9f 00              iowr I[$r9] $r15
00003659: 89 0c 13 00           mov $r9 0x130c
0000365d: bf 99                 ld b32 $r9 D[$r9]
0000365f: b3 94 02 54           bra b32 $r9 0x2 ne 0x36b3
00003663: 80 a4 14 00           mov $r0 0x14a4
00003667: bf 0b                 ld b32 $r11 D[$r0]
00003669: 8a 00 60 24           mov $r10 0x246000
0000366d: 0c 01                 mov $r12 0x1
0000366f: 7e 63 03 00           lcall 0x363
00003673: bf 0c                 ld b32 $r12 D[$r0]
00003675: 8a 14 60 24           mov $r10 0x246014
00003679: 8b 10 60 24           mov $r11 0x246010
0000367d: 7e 92 2d 00           lcall 0x2d92
00003681: bf 0b                 ld b32 $r11 D[$r0]
00003683: 8a 00 60 24           mov $r10 0x246000
00003687: bd c4                 clear b32 $r12
00003689: 7e 63 03 00           lcall 0x363
0000368d: 0b 01                 mov $r11 0x1
0000368f: 8a 00 80 24           mov $r10 0x248000
00003693: b2 bc                 mov b32 $r12 $r11
00003695: 7e 63 03 00           lcall 0x363
00003699: 8a 14 80 24           mov $r10 0x248014
0000369d: 8b 10 80 24           mov $r11 0x248010
000036a1: 0c 01                 mov $r12 0x1
000036a3: 7e 92 2d 00           lcall 0x2d92
000036a7: 8a 00 80 24           mov $r10 0x248000
000036ab: 0b 01                 mov $r11 0x1
000036ad: bd c4                 clear b32 $r12
000036af: 7e 63 03 00           lcall 0x363
000036b3: 89 0c 13 00         B mov $r9 0x130c
000036b7: bf 99                 ld b32 $r9 D[$r9]
000036b9: 92 99 01              sub b32 $r9 $r9 0x1
000036bc: b0 96 01              cmp b32 $r9 0x1
000036bf: f5 0c 14 01           bra a 0x37d3
000036c3: 7e 19 2c 00           lcall 0x2c19
000036c7: 89 fc 12 00           mov $r9 0x12fc
000036cb: bf 9a                 ld b32 $r10 D[$r9]
000036cd: 89 00 13 00           mov $r9 0x1300
000036d1: bf 9b                 ld b32 $r11 D[$r9]
000036d3: 89 04 13 00           mov $r9 0x1304
000036d7: bf 9c                 ld b32 $r12 D[$r9]
000036d9: 81 00 10 00           mov $r1 0x1000
000036dd: 7e b9 32 00           lcall 0x32b9
000036e1: bd a4                 clear b32 $r10
000036e3: 7e e3 00 00           lcall 0xe3
000036e7: 98 10 3a              ld b32 $r0 D[$r1+0xe8]
000036ea: 0a 0f                 mov $r10 0xf
000036ec: f1 04 ff ff           and $r0 0xffff
000036f0: b2 0b                 mov b32 $r11 $r0
000036f2: 7e c4 00 00           lcall 0xc4
000036f6: 89 2c 06 00           mov $r9 0x62c
000036fa: bf 9d                 ld b32 $r13 D[$r9]
000036fc: 8c 2c 04 00           mov $r12 0x42c
00003700: 0a 02                 mov $r10 0x2
00003702: b2 ab                 mov b32 $r11 $r10
00003704: 7e e1 07 00           lcall 0x7e1
00003708: 0a 02                 mov $r10 0x2
0000370a: 7e 7a 09 00           lcall 0x97a
0000370e: 95 ab 08              shr b32 $r11 $r10 0x8
00003711: 0a 0f                 mov $r10 0xf
00003713: bc b0 b0              add b32 $r11 $r11 $r0
00003716: 7e c4 00 00           lcall 0xc4
0000371a: 89 60 06 00           mov $r9 0x660
0000371e: bf 9d                 ld b32 $r13 D[$r9]
00003720: 8c 30 06 00           mov $r12 0x630
00003724: 0a 0c                 mov $r10 0xc
00003726: 0b 02                 mov $r11 0x2
00003728: 7e e1 07 00           lcall 0x7e1
0000372c: 98 10 3b              ld b32 $r0 D[$r1+0xec]
0000372f: 0a 0f                 mov $r10 0xf
00003731: f1 04 ff ff           and $r0 0xffff
00003735: b2 0b                 mov b32 $r11 $r0
00003737: 7e c4 00 00           lcall 0xc4
0000373b: 89 48 08 00           mov $r9 0x848
0000373f: bf 9d                 ld b32 $r13 D[$r9]
00003741: 0a 0d                 mov $r10 0xd
00003743: 0b 01                 mov $r11 0x1
00003745: 8c 98 06 00           mov $r12 0x698
00003749: 7e e1 07 00           lcall 0x7e1
0000374d: 89 58 08 00           mov $r9 0x858
00003751: bf 9d                 ld b32 $r13 D[$r9]
00003753: 0a 0e                 mov $r10 0xe
00003755: 0b 03                 mov $r11 0x3
00003757: 8c 4c 08 00           mov $r12 0x84c
0000375b: 7e e1 07 00           lcall 0x7e1
0000375f: 89 b0 08 00           mov $r9 0x8b0
00003763: bf 9d                 ld b32 $r13 D[$r9]
00003765: 0a 16                 mov $r10 0x16
00003767: 0b 03                 mov $r11 0x3
00003769: 8c a8 08 00           mov $r12 0x8a8
0000376d: 7e e1 07 00           lcall 0x7e1
00003771: 89 c0 08 00           mov $r9 0x8c0
00003775: bf 9d                 ld b32 $r13 D[$r9]
00003777: 0a 18                 mov $r10 0x18
00003779: 0b 03                 mov $r11 0x3
0000377b: 8c b4 08 00           mov $r12 0x8b4
0000377f: 7e e1 07 00           lcall 0x7e1
00003783: 89 a4 08 00           mov $r9 0x8a4
00003787: bf 9d                 ld b32 $r13 D[$r9]
00003789: 8c 90 08 00           mov $r12 0x890
0000378d: 0b 04                 mov $r11 0x4
0000378f: 0a 17                 mov $r10 0x17
00003791: 7e e1 07 00           lcall 0x7e1
00003795: 0a 0d                 mov $r10 0xd
00003797: 7e 7a 09 00           lcall 0x97a
0000379b: 95 ab 08              shr b32 $r11 $r10 0x8
0000379e: 0a 0f                 mov $r10 0xf
000037a0: bc b0 b0              add b32 $r11 $r11 $r0
000037a3: 7e c4 00 00           lcall 0xc4
000037a7: 89 8c 08 00           mov $r9 0x88c
000037ab: bf 9d                 ld b32 $r13 D[$r9]
000037ad: 0a 0f                 mov $r10 0xf
000037af: 0b 02                 mov $r11 0x2
000037b1: 8c 5c 08 00           mov $r12 0x85c
000037b5: 7e e1 07 00           lcall 0x7e1
000037b9: 7e 75 21 00           lcall 0x2175
000037bd: 89 e0 12 00           mov $r9 0x12e0
000037c1: bf 9a                 ld b32 $r10 D[$r9]
000037c3: 89 e4 12 00           mov $r9 0x12e4
000037c7: bf 9b                 ld b32 $r11 D[$r9]
000037c9: 89 e8 12 00           mov $r9 0x12e8
000037cd: bf 9c                 ld b32 $r12 D[$r9]
000037cf: 7e b9 32 00           lcall 0x32b9
000037d3: df 00 00 00 02      B mov $r15 0x2000000
000037d8: 89 00 1a 02           mov $r9 0x21a00
000037dc: fa 9f 00              iowr I[$r9] $r15
000037df: fb 11                 mpopret $r1

000037e1: f9 32              C  mpush $r3
000037e3: 8f 00 00 08           mov $r15 0x80000
000037e7: f4 30 f4              add $sp -0xc
000037ea: 89 00 14 02           mov $r9 0x21400
000037ee: fa 9f 00              iowr I[$r9] $r15
000037f1: bd f4                 clear b32 $r15
000037f3: b8 99 00 6d 00        add b32 $r9 $r9 0x6d00
000037f8: ff 9f 3f              iord $r3 I[$r9+$r15*0x4]
000037fb: b8 99 00 0d 00        add b32 $r9 $r9 0xd00
00003800: ff 9f 2f              iord $r2 I[$r9+$r15*0x4]
00003803: b8 99 00 01 00        add b32 $r9 $r9 0x100
00003808: ff 9f 1f              iord $r1 I[$r9+$r15*0x4]
0000380b: 8d 00 de 02           mov $r13 0x2de00
0000380f: ff df df              iord $r13 I[$r13+$r15*0x4]
00003812: 89 00 0e 00           mov $r9 0xe00
00003816: 98 9e 33              ld b32 $r14 D[$r9+0xcc]
00003819: 98 9c 32              ld b32 $r12 D[$r9+0xc8]
0000381c: 89 ec 12 00           mov $r9 0x12ec
00003820: bf 9f                 ld b32 $r15 D[$r9]
00003822: 89 ff ff 01           mov $r9 0x1ffff
00003826: fd e9 04              and $r14 $r9
00003829: 89 64 14 00           mov $r9 0x1464
0000382d: b6 c5 08              shr b32 $r12 0x8
00003830: 95 e0 08              shr b32 $r0 $r14 0x8
00003833: b6 e4 18              shl b32 $r14 0x18
00003836: ff ec a5              or $r10 $r14 $r12
00003839: a0 9a                 st b32 D[$r9] $r10
0000383b: 89 68 14 00           mov $r9 0x1468
0000383f: c4 fb 3f              and $r11 $r15 0x3f
00003842: f0 d4 3f              and $r13 0x3f
00003845: b6 b4 10              shl b32 $r11 0x10
00003848: b6 d4 18              shl b32 $r13 0x18
0000384b: a0 90                 st b32 D[$r9] $r0
0000384d: 90 ff 40              add b32 $r15 $r15 0x40
00003850: 89 6c 14 00           mov $r9 0x146c
00003854: f0 f4 ff              and $r15 0xff
00003857: fd fb 05              or $r15 $r11
0000385a: ff fd c5              or $r12 $r15 $r13
0000385d: a0 9c                 st b32 D[$r9] $r12
0000385f: b3 a0 00 31           bra b32 $r10 0x0 e 0x3890
00003863: b2 0b                 mov b32 $r11 $r0
00003865: 7e b9 32 00           lcall 0x32b9
00003869: 09 02                 mov $r9 0x2
0000386b: b0 91 01              st b32 D[$sp+0x4] $r9
0000386e: b0 91 00              st b32 D[$sp] $r9
00003871: 09 01                 mov $r9 0x1
00003873: bd a4                 clear b32 $r10
00003875: bd b4                 clear b32 $r11
00003877: 0c 05                 mov $r12 0x5
00003879: 8d 00 0c 00           mov $r13 0xc00
0000387d: bd e4                 clear b32 $r14
0000387f: b0 91 02              st b32 D[$sp+0x8] $r9
00003882: 7e e1 2d 00           lcall 0x2de1
00003886: b2 3a                 mov b32 $r10 $r3
00003888: b2 2b                 mov b32 $r11 $r2
0000388a: b2 1c                 mov b32 $r12 $r1
0000388c: 7e b9 32 00           lcall 0x32b9
00003890: 8f 00 00 08         B mov $r15 0x80000
00003894: 89 00 1a 02           mov $r9 0x21a00
00003898: fa 9f 00              iowr I[$r9] $r15
0000389b: f4 30 0c              add $sp 0xc
0000389e: fb 31                 mpopret $r3

000038a0: f9 62              C  mpush $r6
000038a2: 8f 00 00 04           mov $r15 0x40000
000038a6: f4 30 f4              add $sp -0xc
000038a9: 89 00 14 02           mov $r9 0x21400
000038ad: fa 9f 00              iowr I[$r9] $r15
000038b0: bd c4                 clear b32 $r12
000038b2: b8 99 00 6d 00        add b32 $r9 $r9 0x6d00
000038b7: ff 9c 4f              iord $r4 I[$r9+$r12*0x4]
000038ba: b8 99 00 0d 00        add b32 $r9 $r9 0xd00
000038bf: ff 9c 3f              iord $r3 I[$r9+$r12*0x4]
000038c2: b8 99 00 01 00        add b32 $r9 $r9 0x100
000038c7: ff 9c 2f              iord $r2 I[$r9+$r12*0x4]
000038ca: 8e 00 de 02           mov $r14 0x2de00
000038ce: ff ec ef              iord $r14 I[$r14+$r12*0x4]
000038d1: 89 ec 12 00           mov $r9 0x12ec
000038d5: 81 00 0e 00           mov $r1 0xe00
000038d9: bf 9f                 ld b32 $r15 D[$r9]
000038db: 98 19 33              ld b32 $r9 D[$r1+0xcc]
000038de: 98 1d 32              ld b32 $r13 D[$r1+0xc8]
000038e1: 85 ff ff 01           mov $r5 0x1ffff
000038e5: c4 fb 3f              and $r11 $r15 0x3f
000038e8: fd 95 04              and $r9 $r5
000038eb: 95 90 08              shr b32 $r0 $r9 0x8
000038ee: b6 94 18              shl b32 $r9 0x18
000038f1: b6 d5 08              shr b32 $r13 0x8
000038f4: ff 9d a5              or $r10 $r9 $r13
000038f7: 89 64 14 00           mov $r9 0x1464
000038fb: a0 9a                 st b32 D[$r9] $r10
000038fd: 89 68 14 00           mov $r9 0x1468
00003901: f0 e4 3f              and $r14 0x3f
00003904: b6 b4 10              shl b32 $r11 0x10
00003907: b6 e4 18              shl b32 $r14 0x18
0000390a: 86 5c 14 00           mov $r6 0x145c
0000390e: a0 90                 st b32 D[$r9] $r0
00003910: a0 6c                 st b32 D[$r6] $r12
00003912: 90 ff 40              add b32 $r15 $r15 0x40
00003915: 89 6c 14 00           mov $r9 0x146c
00003919: f0 f4 ff              and $r15 0xff
0000391c: fd fb 05              or $r15 $r11
0000391f: ff fe c5              or $r12 $r15 $r14
00003922: a0 9c                 st b32 D[$r9] $r12
00003924: b3 a0 00 5a           bra b32 $r10 0x0 e 0x397e
00003928: b2 0b                 mov b32 $r11 $r0
0000392a: 7e b9 32 00           lcall 0x32b9
0000392e: 09 02                 mov $r9 0x2
00003930: b0 91 02              st b32 D[$sp+0x8] $r9
00003933: b0 91 00              st b32 D[$sp] $r9
00003936: 09 01                 mov $r9 0x1
00003938: 8d 00 0c 00           mov $r13 0xc00
0000393c: bd e4                 clear b32 $r14
0000393e: b0 91 01              st b32 D[$sp+0x4] $r9
00003941: bd a4                 clear b32 $r10
00003943: bd b4                 clear b32 $r11
00003945: 0c 05                 mov $r12 0x5
00003947: 7e e1 2d 00           lcall 0x2de1
0000394b: b2 4a                 mov b32 $r10 $r4
0000394d: b2 3b                 mov b32 $r11 $r3
0000394f: b2 2c                 mov b32 $r12 $r2
00003951: 7e b9 32 00           lcall 0x32b9
00003955: 8f 00 0c 00           mov $r15 0xc00
00003959: 98 ff 0c              ld b32 $r15 D[$r15+0x30]
0000395c: 89 80 14 00           mov $r9 0x1480
00003960: bf 1d                 ld b32 $r13 D[$r1]
00003962: a0 9f                 st b32 D[$r9] $r15
00003964: 98 19 3a              ld b32 $r9 D[$r1+0xe8]
00003967: b6 d5 08              shr b32 $r13 0x8
0000396a: 8f 60 14 00           mov $r15 0x1460
0000396e: fd 95 04              and $r9 $r5
00003971: 95 9e 08              shr b32 $r14 $r9 0x8
00003974: b6 94 18              shl b32 $r9 0x18
00003977: a0 fe                 st b32 D[$r15] $r14
00003979: fd 9d 05              or $r9 $r13
0000397c: a0 69                 st b32 D[$r6] $r9
0000397e: 8f 00 00 04         B mov $r15 0x40000
00003982: 89 00 1a 02           mov $r9 0x21a00
00003986: fa 9f 00              iowr I[$r9] $r15
00003989: f4 30 0c              add $sp 0xc
0000398c: fb 61                 mpopret $r6

0000398e: f9 72              C  mpush $r7
00003990: d9 00 00 00 80        mov $r9 0x80000000
00003995: f4 30 f4              add $sp -0xc
00003998: b2 a2                 mov b32 $r2 $r10
0000399a: 8f 00 12 02           mov $r15 0x21200
0000399e: fa f9 00              iowr I[$r15] $r9
000039a1: 89 f0 13 00           mov $r9 0x13f0
000039a5: bf 9c                 ld b32 $r12 D[$r9]
000039a7: b3 c0 00 16           bra b32 $r12 0x0 e 0x39bd
000039ab: df 00 00 00 80        mov $r15 0x80000000
000039b0: 89 00 18 02           mov $r9 0x21800
000039b4: fa 9f 00              iowr I[$r9] $r15
000039b7: bd a4                 clear b32 $r10
000039b9: 3e 57 3b 00           lbra 0x3b57
000039bd: 8d 00 0e 00         B mov $r13 0xe00
000039c1: d9 ff ff ff 00        mov $r9 0xffffff
000039c6: 98 df 28              ld b32 $r15 D[$r13+0xa0]
000039c9: a6 a9                 cmp b32 $r10 $r9
000039cb: f4 0d 27              bra be 0x39f2
000039ce: df 00 00 00 80        mov $r15 0x80000000
000039d3: 89 00 18 02           mov $r9 0x21800
000039d7: fa 9f 00              iowr I[$r9] $r15
000039da: 0f 01                 mov $r15 0x1
000039dc: b8 99 00 0a 02        sub b32 $r9 $r9 0xa00
000039e1: fa 9f 00              iowr I[$r9] $r15
000039e4: b8 99 00 01 00        add b32 $r9 $r9 0x100
000039e9: fa 9a 00              iowr I[$r9] $r10
000039ec: 0a 01                 mov $r10 0x1
000039ee: 3e 57 3b 00           lbra 0x3b57
000039f2: c4 f9 03            B and $r9 $r15 0x3
000039f5: b3 99 01 29 01        bra b32 $r9 0x1 e 0x3b1e
000039fa: b0 96 01              cmp b32 $r9 0x1
000039fd: f5 08 4c 01           bra b 0x3b49
00003a01: b3 9d 02 3c 01        bra b32 $r9 0x2 ne 0x3b3d
00003a06: 89 00 81 02           mov $r9 0x28100
00003a0a: ff 9c 7f              iord $r7 I[$r9+$r12*0x4]
00003a0d: b8 99 00 0d 00        add b32 $r9 $r9 0xd00
00003a12: ff 9c 6f              iord $r6 I[$r9+$r12*0x4]
00003a15: b8 99 00 01 00        add b32 $r9 $r9 0x100
00003a1a: ff 9c 5f              iord $r5 I[$r9+$r12*0x4]
00003a1d: 98 df 29              ld b32 $r15 D[$r13+0xa4]
00003a20: 98 de 2a              ld b32 $r14 D[$r13+0xa8]
00003a23: c7 a0 e5              extr $r0 $r10 0x5:0xc
00003a26: 95 a1 0d              shr b32 $r1 $r10 0xd
00003a29: c4 f9 ff              and $r9 $r15 0xff
00003a2c: b6 e4 18              shl b32 $r14 0x18
00003a2f: b6 f5 08              shr b32 $r15 0x8
00003a32: fd ef 05              or $r14 $r15
00003a35: bc 09 00              add b32 $r0 $r0 $r9
00003a38: bc 1e 10              add b32 $r1 $r1 $r14
00003a3b: 7e cf 31 00           lcall 0x31cf
00003a3f: 89 ec 12 00           mov $r9 0x12ec
00003a43: bf 99                 ld b32 $r9 D[$r9]
00003a45: 95 0a 08              shr b32 $r10 $r0 0x8
00003a48: bd b4                 clear b32 $r11
00003a4a: bc 1a a0              add b32 $r10 $r1 $r10
00003a4d: 90 9c 40              add b32 $r12 $r9 0x40
00003a50: f0 94 3f              and $r9 0x3f
00003a53: b6 94 10              shl b32 $r9 0x10
00003a56: f0 c4 ff              and $r12 0xff
00003a59: ff 9c c5              or $r12 $r9 $r12
00003a5c: 7e b9 32 00           lcall 0x32b9
00003a60: c4 03 ff              and $r3 $r0 0xff
00003a63: 95 39 01              shr b32 $r9 $r3 0x1
00003a66: fd 93 05              or $r9 $r3
00003a69: 95 24 02              shr b32 $r4 $r2 0x2
00003a6c: 95 9f 02              shr b32 $r15 $r9 0x2
00003a6f: fd f9 05              or $r15 $r9
00003a72: 95 f9 04              shr b32 $r9 $r15 0x4
00003a75: fd 9f 05              or $r9 $r15
00003a78: 90 9c 01              add b32 $r12 $r9 0x1
00003a7b: b3 c0 10 47           bra b32 $r12 0x10 e 0x3ac2
00003a7f: b0 c6 10              cmp b32 $r12 0x10
00003a82: f4 0c 1f              bra a 0x3aa1
00003a85: b3 c0 04 3d           bra b32 $r12 0x4 e 0x3ac2
00003a89: b0 c6 04              cmp b32 $r12 0x4
00003a8c: f4 0c 0d              bra a 0x3a99
00003a8f: b0 96 01              cmp b32 $r9 0x1
00003a92: f4 0c 44              bra a 0x3ad6
00003a95: 3e c2 3a 00           lbra 0x3ac2
00003a99: b3 c4 08 3d         B bra b32 $r12 0x8 ne 0x3ad6
00003a9d: 3e c2 3a 00           lbra 0x3ac2
00003aa1: b3 c0 40 27         B bra b32 $r12 0x40 e 0x3ac8
00003aa5: b1 c6 40 00           cmp b32 $r12 0x40
00003aa9: f4 0c 0b              bra a 0x3ab4
00003aac: b3 c4 20 2a           bra b32 $r12 0x20 ne 0x3ad6
00003ab0: 3e c2 3a 00           lbra 0x3ac2
00003ab4: b3 ca 80 00 1a      B bra b32 $r12 0x80 e 0x3ace
00003ab9: b3 ce 00 01 1d        bra b32 $r12 0x100 ne 0x3ad6
00003abe: 3e d4 3a 00           lbra 0x3ad4
00003ac2: 0c 03               B mov $r12 0x3
00003ac4: 3e d6 3a 00           lbra 0x3ad6
00003ac8: 0c 04               B mov $r12 0x4
00003aca: 3e d6 3a 00           lbra 0x3ad6
00003ace: 0c 05               B mov $r12 0x5
00003ad0: 3e d6 3a 00           lbra 0x3ad6
00003ad4: 0c 06               B mov $r12 0x6
00003ad6: 8d 00 0a 00         B mov $r13 0xa00
00003ada: bd e4                 clear b32 $r14
00003adc: 01 02                 mov $r1 0x2
00003ade: 00 01                 mov $r0 0x1
00003ae0: bd a4                 clear b32 $r10
00003ae2: b0 01 01              st b32 D[$sp+0x4] $r0
00003ae5: b2 3b                 mov b32 $r11 $r3
00003ae7: b0 11 00              st b32 D[$sp] $r1
00003aea: b0 11 02              st b32 D[$sp+0x8] $r1
00003aed: 7e e1 2d 00           lcall 0x2de1
00003af1: b2 7a                 mov b32 $r10 $r7
00003af3: b2 6b                 mov b32 $r11 $r6
00003af5: b2 5c                 mov b32 $r12 $r5
00003af7: 7e b9 32 00           lcall 0x32b9
00003afb: 8f 00 0a 00           mov $r15 0xa00
00003aff: c4 39 fc              and $r9 $r3 0xfc
00003b02: bc 9f 90              add b32 $r9 $r9 $r15
00003b05: bf 9f                 ld b32 $r15 D[$r9]
00003b07: c4 49 1f              and $r9 $r4 0x1f
00003b0a: bb 09 04              shl b32 $r0 $r9
00003b0d: fd 0f 04              and $r0 $r15
00003b10: f4 1b 39              bra ne 0x3b49
00003b13: 89 00 0e 02           mov $r9 0x20e00
00003b17: fa 91 00              iowr I[$r9] $r1
00003b1a: 3e 31 3b 00           lbra 0x3b31
00003b1e: 0f 02               B mov $r15 0x2
00003b20: 89 00 06 02           mov $r9 0x20600
00003b24: fa 9f 00              iowr I[$r9] $r15
00003b27: 0f 03                 mov $r15 0x3
00003b29: b8 99 00 08 00        add b32 $r9 $r9 0x800
00003b2e: fa 9f 00              iowr I[$r9] $r15
00003b31: b8 99 00 01 00      B add b32 $r9 $r9 0x100
00003b36: fa 92 00              iowr I[$r9] $r2
00003b39: 3e 43 3b 00           lbra 0x3b43
00003b3d: 0a 46               B mov $r10 0x46
00003b3f: 7e c0 05 00           lcall 0x5c0
00003b43: 0a 01               B mov $r10 0x1
00003b45: 3e 4b 3b 00           lbra 0x3b4b
00003b49: bd a4               B clear b32 $r10
00003b4b: df 00 00 00 80      B mov $r15 0x80000000
00003b50: 89 00 18 02           mov $r9 0x21800
00003b54: fa 9f 00              iowr I[$r9] $r15
00003b57: f4 30 0c            B add $sp 0xc
00003b5a: fb 71                 mpopret $r7

00003b5c: f9 32              C  mpush $r3
00003b5e: 89 24 00 00           mov $r9 0x24
00003b62: b2 a3                 mov b32 $r3 $r10
00003b64: bf 9a                 ld b32 $r10 D[$r9]
00003b66: b2 c0                 mov b32 $r0 $r12
00003b68: b2 b1                 mov b32 $r1 $r11
00003b6a: 7e 14 01 00           lcall 0x114
00003b6e: b3 04 00 0e           bra b32 $r0 0x0 ne 0x3b7c
00003b72: 0a 06                 mov $r10 0x6
00003b74: 7e 91 07 00           lcall 0x791
00003b78: 3e de 3b 00           lbra 0x3bde
00003b7c: 0a 07               B mov $r10 0x7
00003b7e: 7e 91 07 00           lcall 0x791
00003b82: b3 04 01 5c           bra b32 $r0 0x1 ne 0x3bde
00003b86: 89 f8 13 00           mov $r9 0x13f8
00003b8a: bf 9b                 ld b32 $r11 D[$r9]
00003b8c: 8a ac 88 41           mov $r10 0x4188ac
00003b90: 7e 37 02 00           lcall 0x237
00003b94: 89 fc 13 00           mov $r9 0x13fc
00003b98: bf 9b                 ld b32 $r11 D[$r9]
00003b9a: 8a 80 88 41           mov $r10 0x418880
00003b9e: 7e 37 02 00           lcall 0x237
00003ba2: 89 00 14 00           mov $r9 0x1400
00003ba6: bf 9b                 ld b32 $r11 D[$r9]
00003ba8: 8a 98 88 41           mov $r10 0x418898
00003bac: 7e 37 02 00           lcall 0x237
00003bb0: 89 04 14 00           mov $r9 0x1404
00003bb4: bf 9b                 ld b32 $r11 D[$r9]
00003bb6: 8a 9c 88 41           mov $r10 0x41889c
00003bba: 7e 37 02 00           lcall 0x237
00003bbe: 89 08 14 00           mov $r9 0x1408
00003bc2: bf 9b                 ld b32 $r11 D[$r9]
00003bc4: 8a a0 88 41           mov $r10 0x4188a0
00003bc8: 7e 37 02 00           lcall 0x237
00003bcc: 89 0c 14 00           mov $r9 0x140c
00003bd0: bf 9b                 ld b32 $r11 D[$r9]
00003bd2: 8a bc 88 41           mov $r10 0x4188bc
00003bd6: 7e 37 02 00           lcall 0x237
00003bda: 3e 32 3c 00           lbra 0x3c32
00003bde: 8a ac 88 41         B mov $r10 0x4188ac
00003be2: 7e 97 02 00           lcall 0x297
00003be6: 89 f8 13 00           mov $r9 0x13f8
00003bea: a0 9a                 st b32 D[$r9] $r10
00003bec: 8a 80 88 41           mov $r10 0x418880
00003bf0: 7e 97 02 00           lcall 0x297
00003bf4: 89 fc 13 00           mov $r9 0x13fc
00003bf8: a0 9a                 st b32 D[$r9] $r10
00003bfa: 8a 98 88 41           mov $r10 0x418898
00003bfe: 7e 97 02 00           lcall 0x297
00003c02: 89 00 14 00           mov $r9 0x1400
00003c06: a0 9a                 st b32 D[$r9] $r10
00003c08: 8a 9c 88 41           mov $r10 0x41889c
00003c0c: 7e 97 02 00           lcall 0x297
00003c10: 89 04 14 00           mov $r9 0x1404
00003c14: a0 9a                 st b32 D[$r9] $r10
00003c16: 8a a0 88 41           mov $r10 0x4188a0
00003c1a: 7e 97 02 00           lcall 0x297
00003c1e: 89 08 14 00           mov $r9 0x1408
00003c22: a0 9a                 st b32 D[$r9] $r10
00003c24: 8a bc 88 41           mov $r10 0x4188bc
00003c28: 7e 97 02 00           lcall 0x297
00003c2c: 89 0c 14 00           mov $r9 0x140c
00003c30: a0 9a                 st b32 D[$r9] $r10
00003c32: 8a 54 41 40         B mov $r10 0x404154
00003c36: 7e 97 02 00           lcall 0x297
00003c3a: bd b4                 clear b32 $r11
00003c3c: b2 a2                 mov b32 $r2 $r10
00003c3e: 8a 54 41 40           mov $r10 0x404154
00003c42: 7e 37 02 00           lcall 0x237
00003c46: 7e cf 31 00           lcall 0x31cf
00003c4a: 8a 00 8e 02           mov $r10 0x28e00
00003c4e: bd b4                 clear b32 $r11
00003c50: 7e 10 00 00           lcall 0x10
00003c54: 8a 00 8f 02           mov $r10 0x28f00
00003c58: 0b 40                 mov $r11 0x40
00003c5a: 7e 10 00 00           lcall 0x10
00003c5e: 8a 00 89 02           mov $r10 0x28900
00003c62: bd b4                 clear b32 $r11
00003c64: 7e 10 00 00           lcall 0x10
00003c68: 89 10 16 00           mov $r9 0x1610
00003c6c: bf 9b                 ld b32 $r11 D[$r9]
00003c6e: 8a 00 83 02           mov $r10 0x28300
00003c72: 7e 10 00 00           lcall 0x10
00003c76: 8a 00 84 02           mov $r10 0x28400
00003c7a: 0b 07                 mov $r11 0x7
00003c7c: 7e 10 00 00           lcall 0x10
00003c80: 7e cf 31 00           lcall 0x31cf
00003c84: b2 3a                 mov b32 $r10 $r3
00003c86: b2 1b                 mov b32 $r11 $r1
00003c88: 7e c5 0c 00           lcall 0xcc5
00003c8c: 89 14 16 00           mov $r9 0x1614
00003c90: bf 9a                 ld b32 $r10 D[$r9]
00003c92: 0c 40                 mov $r12 0x40
00003c94: bd b4                 clear b32 $r11
00003c96: 7e b9 32 00           lcall 0x32b9
00003c9a: b2 0a                 mov b32 $r10 $r0
00003c9c: 7e e3 00 00           lcall 0xe3
00003ca0: 0a 0f                 mov $r10 0xf
00003ca2: bd b4                 clear b32 $r11
00003ca4: 7e c4 00 00           lcall 0xc4
00003ca8: 0a 10                 mov $r10 0x10
00003caa: bd b4                 clear b32 $r11
00003cac: 7e c4 00 00           lcall 0xc4
00003cb0: 92 19 01              sub b32 $r9 $r1 0x1
00003cb3: b0 96 01              cmp b32 $r9 0x1
00003cb6: f4 0c 34              bra a 0x3cea
00003cb9: b3 04 01 0d           bra b32 $r0 0x1 ne 0x3cc6
00003cbd: 0a 0b                 mov $r10 0xb
00003cbf: 4b 88 00              mov $r11 0x88
00003cc2: 7e c4 00 00           lcall 0xc4
00003cc6: 89 e0 09 00         B mov $r9 0x9e0
00003cca: bf 9d                 ld b32 $r13 D[$r9]
00003ccc: 0a 01                 mov $r10 0x1
00003cce: 8c c4 08 00           mov $r12 0x8c4
00003cd2: b2 ab                 mov b32 $r11 $r10
00003cd4: 7e e1 07 00           lcall 0x7e1
00003cd8: 89 e4 09 00           mov $r9 0x9e4
00003cdc: bf 9d                 ld b32 $r13 D[$r9]
00003cde: 0a 01                 mov $r10 0x1
00003ce0: 0b 04                 mov $r11 0x4
00003ce2: 8c 44 09 00           mov $r12 0x944
00003ce6: 7e e1 07 00           lcall 0x7e1
00003cea: 7e 75 21 00         B lcall 0x2175
00003cee: 7e fc 23 00           lcall 0x23fc
00003cf2: 0a 01                 mov $r10 0x1
00003cf4: 7e 91 07 00           lcall 0x791
00003cf8: 7e cf 31 00           lcall 0x31cf
00003cfc: 8a 00 84 02           mov $r10 0x28400
00003d00: 0b 05                 mov $r11 0x5
00003d02: 7e 10 00 00           lcall 0x10
00003d06: 7e cf 31 00           lcall 0x31cf
00003d0a: b2 2b                 mov b32 $r11 $r2
00003d0c: 8a 54 41 40           mov $r10 0x404154
00003d10: 7e 37 02 00           lcall 0x237
00003d14: 7e cf 31 00           lcall 0x31cf
00003d18: 0f 01                 mov $r15 0x1
00003d1a: 89 00 00 02           mov $r9 0x20000
00003d1e: fa 9f 00              iowr I[$r9] $r15
00003d21: bd f4                 clear b32 $r15
00003d23: 89 00 0c 01           mov $r9 0x10c00
00003d27: fa 9f 00              iowr I[$r9] $r15
00003d2a: fb 31                 mpopret $r3

00003d2c: df 00 00 00 04     C  mov $r15 0x4000000
00003d31: 89 00 12 02           mov $r9 0x21200
00003d35: fa 9f 00              iowr I[$r9] $r15
00003d38: bd c4                 clear b32 $r12
00003d3a: 7e 5c 3b 00           lcall 0x3b5c
00003d3e: df 00 00 00 04        mov $r15 0x4000000
00003d43: 89 00 18 02           mov $r9 0x21800
00003d47: fa 9f 00              iowr I[$r9] $r15
00003d4a: f8 00                 ret

00003d4c: f9 12              C  mpush $r1
00003d4e: df 00 00 00 08        mov $r15 0x8000000
00003d53: b2 a1                 mov b32 $r1 $r10
00003d55: b2 b0                 mov b32 $r0 $r11
00003d57: 89 00 12 02           mov $r9 0x21200
00003d5b: fa 9f 00              iowr I[$r9] $r15
00003d5e: b3 b4 02 08           bra b32 $r11 0x2 ne 0x3d66
00003d62: 7e 53 2b 00           lcall 0x2b53
00003d66: b2 1a               B mov b32 $r10 $r1
00003d68: b2 0b                 mov b32 $r11 $r0
00003d6a: 0c 01                 mov $r12 0x1
00003d6c: 7e 5c 3b 00           lcall 0x3b5c
00003d70: df 00 00 00 08        mov $r15 0x8000000
00003d75: 89 00 18 02           mov $r9 0x21800
00003d79: fa 9f 00              iowr I[$r9] $r15
00003d7c: fb 11                 mpopret $r1

00003d7e: f9 22              C  mpush $r2
00003d80: 4f 00 40              mov $r15 0x4000
00003d83: 89 00 14 02           mov $r9 0x21400
00003d87: fa 9f 00              iowr I[$r9] $r15
00003d8a: 7e cf 31 00           lcall 0x31cf
00003d8e: bd 94                 clear b32 $r9
00003d90: 82 00 81 02           mov $r2 0x28100
00003d94: ff 29 2f              iord $r2 I[$r2+$r9*0x4]
00003d97: 81 00 8e 02           mov $r1 0x28e00
00003d9b: ff 19 1f              iord $r1 I[$r1+$r9*0x4]
00003d9e: 80 00 8f 02           mov $r0 0x28f00
00003da2: ff 09 0f              iord $r0 I[$r0+$r9*0x4]
00003da5: 89 e0 12 00           mov $r9 0x12e0
00003da9: bf 9a                 ld b32 $r10 D[$r9]
00003dab: 89 e4 12 00           mov $r9 0x12e4
00003daf: bf 9b                 ld b32 $r11 D[$r9]
00003db1: 89 e8 12 00           mov $r9 0x12e8
00003db5: bf 9c                 ld b32 $r12 D[$r9]
00003db7: 7e b9 32 00           lcall 0x32b9
00003dbb: 7e cf 31 00           lcall 0x31cf
00003dbf: 8a 00 84 02           mov $r10 0x28400
00003dc3: 4b 05 02              mov $r11 0x205
00003dc6: 7e 10 00 00           lcall 0x10
00003dca: 7e cf 31 00           lcall 0x31cf
00003dce: b2 2a                 mov b32 $r10 $r2
00003dd0: b2 1b                 mov b32 $r11 $r1
00003dd2: b2 0c                 mov b32 $r12 $r0
00003dd4: 7e b9 32 00           lcall 0x32b9
00003dd8: 4f 00 40              mov $r15 0x4000
00003ddb: 89 00 1a 02           mov $r9 0x21a00
00003ddf: fa 9f 00              iowr I[$r9] $r15
00003de2: fb 21                 mpopret $r2

00003de4: f9 82              C  mpush $r8
00003de6: 8f 00 00 10           mov $r15 0x100000
00003dea: 89 00 13 02           mov $r9 0x21300
00003dee: fa 9f 00              iowr I[$r9] $r15
00003df1: 8f 00 00 20           mov $r15 0x200000
00003df5: fa 9f 00              iowr I[$r9] $r15
00003df8: fe 4e 01              mov $r14 $sp
00003dfb: b8 99 00 06 00        add b32 $r9 $r9 0x600
00003e00: fa 9f 00              iowr I[$r9] $r15
00003e03: 89 d0 13 00           mov $r9 0x13d0
00003e07: bf 9a                 ld b32 $r10 D[$r9]
00003e09: 89 d4 13 00           mov $r9 0x13d4
00003e0d: bf 9b                 ld b32 $r11 D[$r9]
00003e0f: b8 ee 00 02 02        sub b32 $r14 $r14 0x200
00003e14: 49 00 fe              mov $r9 -0x200
00003e17: 4c c0 00              mov $r12 0xc0
00003e1a: ff e9 44              and $r4 $r14 $r9
00003e1d: 7e b9 32 00           lcall 0x32b9
00003e21: b8 45 00 01 00        add b32 $r5 $r4 0x100
00003e26: 4f 11 11              mov $r15 0x1111
00003e29: 89 00 07 02           mov $r9 0x20700
00003e2d: fa 9f 00              iowr I[$r9] $r15
00003e30: 89 cc 13 00           mov $r9 0x13cc
00003e34: bf 9f                 ld b32 $r15 D[$r9]
00003e36: 89 00 07 02           mov $r9 0x20700
00003e3a: fa 9f 00              iowr I[$r9] $r15
00003e3d: 89 d0 13 00           mov $r9 0x13d0
00003e41: bf 9f                 ld b32 $r15 D[$r9]
00003e43: 89 00 07 02           mov $r9 0x20700
00003e47: fa 9f 00              iowr I[$r9] $r15
00003e4a: 89 d4 13 00           mov $r9 0x13d4
00003e4e: bf 9f                 ld b32 $r15 D[$r9]
00003e50: 89 00 07 02           mov $r9 0x20700
00003e54: fa 9f 00              iowr I[$r9] $r15
00003e57: 89 d8 13 00           mov $r9 0x13d8
00003e5b: bf 9f                 ld b32 $r15 D[$r9]
00003e5d: 89 00 07 02           mov $r9 0x20700
00003e61: fa 9f 00              iowr I[$r9] $r15
00003e64: 89 dc 13 00           mov $r9 0x13dc
00003e68: bf 9f                 ld b32 $r15 D[$r9]
00003e6a: 89 00 07 02           mov $r9 0x20700
00003e6e: fa 9f 00              iowr I[$r9] $r15
00003e71: bd f4                 clear b32 $r15
00003e73: b8 99 00 7a 02        sub b32 $r9 $r9 0x7a00
00003e78: fa 9f 00              iowr I[$r9] $r15
00003e7b: 4f 12 11              mov $r15 0x1112
00003e7e: b8 99 00 7a 00        add b32 $r9 $r9 0x7a00
00003e83: fa 9f 00              iowr I[$r9] $r15
00003e86: 49 00 01              mov $r9 0x100
00003e89: fe 9b 00              mov $xtargets $r9
00003e8c: bd 94                 clear b32 $r9
00003e8e: fe 97 00              mov $xdbase $r9
00003e91: 8e 00 00 06           mov $r14 0x60000
00003e95: ff 4e f5              or $r15 $r4 $r14
00003e98: fa 9f 05              xdld $r9 $r15
00003e9b: f8 03                 xdwait
00003e9d: bd 34                 clear b32 $r3
00003e9f: b2 5a                 mov b32 $r10 $r5
00003ea1: bd f4                 clear b32 $r15
00003ea3: 88 cc 13 00           mov $r8 0x13cc
00003ea7: bd 74                 clear b32 $r7
00003ea9: 3d 64                 clear b8 $r6
00003eab: 3e ac 3f 00           lbra 0x3fac
00003eaf: b8 f2 00 01 00      B add b32 $r2 $r15 0x100
00003eb4: a6 29                 cmp b32 $r2 $r9
00003eb6: f4 18 0d              bra ae 0x3ec3
00003eb9: 8b 00 00 06           mov $r11 0x60000
00003ebd: ff ab 95              or $r9 $r10 $r11
00003ec0: fa 29 05              xdld $r2 $r9
00003ec3: b3 34 00 0a         B bra b32 $r3 0x0 ne 0x3ecd
00003ec7: b2 4a                 mov b32 $r10 $r4
00003ec9: 3e cf 3e 00           lbra 0x3ecf
00003ecd: b2 5a               B mov b32 $r10 $r5
00003ecf: bf 89               B ld b32 $r9 D[$r8]
00003ed1: bc 9f 02              sub b32 $r0 $r9 $r15
00003ed4: b1 06 ff 00           cmp b32 $r0 0xff
00003ed8: f5 0c 9a 00           bra a 0x3f72
00003edc: b9 09 00              not b32 $r9 $r0
00003edf: bc a0 b0              add b32 $r11 $r10 $r0
00003ee2: b8 9c 01 01 00        add b32 $r12 $r9 0x101
00003ee7: b9 b9 01              neg b32 $r9 $r11
00003eea: f0 94 03              and $r9 0x3
00003eed: a6 9c                 cmp b32 $r9 $r12
00003eef: f4 0d 05              bra be 0x3ef4
00003ef2: b2 c9                 mov b32 $r9 $r12
00003ef4: b3 94 00 0a         B bra b32 $r9 0x0 ne 0x3efe
00003ef8: b2 0d                 mov b32 $r13 $r0
00003efa: 3e 15 3f 00           lbra 0x3f15
00003efe: b2 0d               B mov b32 $r13 $r0
00003f00: bd f4                 clear b32 $r15
00003f02: 3c b6 f9            B st b8 D[$r11+$r15] $r6
00003f05: 90 dd 01              add b32 $r13 $r13 0x1
00003f08: 90 ff 01              add b32 $r15 $r15 0x1
00003f0b: a6 f9                 cmp b32 $r15 $r9
00003f0d: f4 08 f5              bra b 0x3f02
00003f10: a6 9c                 cmp b32 $r9 $r12
00003f12: f4 0b 39              bra e 0x3f4b
00003f15: bc c9 12            B sub b32 $r1 $r12 $r9
00003f18: 95 1e 02              shr b32 $r14 $r1 0x2
00003f1b: 94 ec 02              shl b32 $r12 $r14 0x2
00003f1e: f4 0b 1d              bra e 0x3f3b
00003f21: bc b9 90              add b32 $r9 $r11 $r9
00003f24: bd f4                 clear b32 $r15
00003f26: a0 97               B st b32 D[$r9] $r7
00003f28: 90 ff 01              add b32 $r15 $r15 0x1
00003f2b: 90 99 04              add b32 $r9 $r9 0x4
00003f2e: a6 fe                 cmp b32 $r15 $r14
00003f30: f4 08 f6              bra b 0x3f26
00003f33: bc dc d0              add b32 $r13 $r13 $r12
00003f36: a6 c1                 cmp b32 $r12 $r1
00003f38: f4 0b 13              bra e 0x3f4b
00003f3b: bc ad 90            B add b32 $r9 $r10 $r13
00003f3e: 20 96               B st b8 D[$r9] $r6
00003f40: 90 dd 01              add b32 $r13 $r13 0x1
00003f43: 90 99 01              add b32 $r9 $r9 0x1
00003f46: b3 de 00 01 f8        bra b32 $r13 0x100 ne 0x3f3e
00003f4b: 90 09 03            B add b32 $r9 $r0 0x3
00003f4e: b2 af                 mov b32 $r15 $r10
00003f50: b6 95 02              shr b32 $r9 0x2
00003f53: b6 94 02              shl b32 $r9 0x2
00003f56: bc a9 d0              add b32 $r13 $r10 $r9
00003f59: 3e 69 3f 00           lbra 0x3f69
00003f5d: bf f9               B ld b32 $r9 D[$r15]
00003f5f: 8e 00 8c 01           mov $r14 0x18c00
00003f63: fa e9 00              iowr I[$r14] $r9
00003f66: 90 ff 04              add b32 $r15 $r15 0x4
00003f69: a6 fd               B cmp b32 $r15 $r13
00003f6b: f4 1b f2              bra ne 0x3f5d
00003f6e: 3e a5 3f 00           lbra 0x3fa5
00003f72: 49 00 8c            B mov $r9 -0x7400
00003f75: f0 93 01              sethi $r9 0x10000
00003f78: 0d 40                 mov $r13 0x40
00003f7a: b2 7f                 mov b32 $r15 $r7
00003f7c: b2 ac                 mov b32 $r12 $r10
00003f7e: b2 7b                 mov b32 $r11 $r7
00003f80: b2 7e                 mov b32 $r14 $r7
00003f82: 98 cb 00            B ld b32 $r11 D[$r12]
00003f85: 98 ce 01              ld b32 $r14 D[$r12+0x4]
00003f88: 90 ff 04              add b32 $r15 $r15 0x4
00003f8b: fa 9b 00              iowr I[$r9] $r11
00003f8e: 98 cb 02              ld b32 $r11 D[$r12+0x8]
00003f91: fa 9e 00              iowr I[$r9] $r14
00003f94: 98 ce 03              ld b32 $r14 D[$r12+0xc]
00003f97: 90 cc 10              add b32 $r12 $r12 0x10
00003f9a: fa 9b 00              iowr I[$r9] $r11
00003f9d: a6 fd                 cmp b32 $r15 $r13
00003f9f: fa 9e 00              iowr I[$r9] $r14
00003fa2: f4 1e e0              bra l 0x3f82
00003fa5: f0 36 01            B xor $r3 0x1
00003fa8: f8 03                 xdwait
00003faa: b2 2f                 mov b32 $r15 $r2
00003fac: bf 89               B ld b32 $r9 D[$r8]
00003fae: a6 f9                 cmp b32 $r15 $r9
00003fb0: f5 08 ff fe           bra b 0x3eaf
00003fb4: bd 94                 clear b32 $r9
00003fb6: 80 00 8d 01           mov $r0 0x18d00
00003fba: ff 09 0f              iord $r0 I[$r0+$r9*0x4]
00003fbd: 89 00 07 02           mov $r9 0x20700
00003fc1: fa 90 00              iowr I[$r9] $r0
00003fc4: 89 d8 13 00           mov $r9 0x13d8
00003fc8: bf 9a                 ld b32 $r10 D[$r9]
00003fca: 89 dc 13 00           mov $r9 0x13dc
00003fce: bf 9b                 ld b32 $r11 D[$r9]
00003fd0: 4c c0 00              mov $r12 0xc0
00003fd3: 7e b9 32 00           lcall 0x32b9
00003fd7: 49 00 20              mov $r9 0x2000
00003fda: fe 9b 00              mov $xtargets $r9
00003fdd: bd 94                 clear b32 $r9
00003fdf: fe 97 00              mov $xdbase $r9
00003fe2: 4f 22 22              mov $r15 0x2222
00003fe5: 89 00 07 02           mov $r9 0x20700
00003fe9: fa 9f 00              iowr I[$r9] $r15
00003fec: bd 94                 clear b32 $r9
00003fee: a0 40                 st b32 D[$r4] $r0
00003ff0: fa 94 06              xdst $r9 $r4
00003ff3: f8 03                 xdwait
00003ff5: 7e cf 31 00           lcall 0x31cf
00003ff9: 0f 01                 mov $r15 0x1
00003ffb: 89 00 00 02           mov $r9 0x20000
00003fff: fa 9f 00              iowr I[$r9] $r15
00004002: 8f 00 00 10           mov $r15 0x100000
00004006: b8 99 00 19 00        add b32 $r9 $r9 0x1900
0000400b: fa 9f 00              iowr I[$r9] $r15
0000400e: fb 81                 mpopret $r8

00004010: f9 12              C  mpush $r1
00004012: 0f 04                 mov $r15 0x4
00004014: 89 00 15 02           mov $r9 0x21500
00004018: fa 9f 00              iowr I[$r9] $r15
0000401b: 81 00 00 01           mov $r1 0x10000
0000401f: bd 04                 clear b32 $r0
00004021: 3e 29 40 00           lbra 0x4029
00004025: 7e 5e 21 00         B lcall 0x215e
00004029: ff 10 9f            B iord $r9 I[$r1+$r0*0x4]
0000402c: f0 94 10              and $r9 0x10
0000402f: f4 0b f6              bra e 0x4025
00004032: 0f 04                 mov $r15 0x4
00004034: 89 00 1b 02           mov $r9 0x21b00
00004038: fa 9f 00              iowr I[$r9] $r15
0000403b: fb 11                 mpopret $r1

0000403d: f9 12              C  mpush $r1
0000403f: 4f 00 40              mov $r15 0x4000
00004042: b2 b0                 mov b32 $r0 $r11
00004044: 89 00 12 02           mov $r9 0x21200
00004048: fa 9f 00              iowr I[$r9] $r15
0000404b: 89 c4 12 00           mov $r9 0x12c4
0000404f: bf 99                 ld b32 $r9 D[$r9]
00004051: b3 94 01 11           bra b32 $r9 0x1 ne 0x4062
00004055: 89 00 18 02           mov $r9 0x21800
00004059: fa 9f 00              iowr I[$r9] $r15
0000405c: 01 64                 mov $r1 0x64
0000405e: 3e 9c 41 00           lbra 0x419c
00004062: 8a 44 01 40         B mov $r10 0x400144
00004066: 4b 00 01              mov $r11 0x100
00004069: 7e 37 02 00           lcall 0x237
0000406d: bd b4                 clear b32 $r11
0000406f: 0a 04                 mov $r10 0x4
00004071: 7e c5 0c 00           lcall 0xcc5
00004075: 0a 01                 mov $r10 0x1
00004077: 7e c6 29 00           lcall 0x29c6
0000407b: 8a 14 96 40           mov $r10 0x409614
0000407f: 4b 15 01              mov $r11 0x115
00004082: 7e 37 02 00           lcall 0x237
00004086: 8a 14 a6 41           mov $r10 0x41a614
0000408a: 4b 26 0a              mov $r11 0xa26
0000408d: 7e 37 02 00           lcall 0x237
00004091: 7e 9d 0c 00           lcall 0xc9d
00004095: bd f4                 clear b32 $r15
00004097: 89 00 23 02           mov $r9 0x22300
0000409b: ff 9f 9f              iord $r9 I[$r9+$r15*0x4]
0000409e: f0 94 10              and $r9 0x10
000040a1: f4 0b 09              bra e 0x40aa
000040a4: bd 14                 clear b32 $r1
000040a6: 3e d9 40 00           lbra 0x40d9
000040aa: 0f 08               B mov $r15 0x8
000040ac: 89 00 02 03           mov $r9 0x30200
000040b0: fa 9f 00              iowr I[$r9] $r15
000040b3: bd 14                 clear b32 $r1
000040b5: 8e 00 00 03           mov $r14 0x30000
000040b9: bd f4                 clear b32 $r15
000040bb: 3e c2 40 00           lbra 0x40c2
000040bf: 90 11 01            B add b32 $r1 $r1 0x1
000040c2: ff ef 9f            B iord $r9 I[$r14+$r15*0x4]
000040c5: f1 94 00 80           and $r9 0x8000
000040c9: 73 90 00 2a           bra b16 $r9 0x0 e 0x40f3
000040cd: a6 10                 cmp b32 $r1 $r0
000040cf: f4 08 f0              bra b 0x40bf
000040d2: 3e f3 40 00           lbra 0x40f3
000040d6: 90 11 01            B add b32 $r1 $r1 0x1
000040d9: 8a 84 03 40         B mov $r10 0x400384
000040dd: 7e 97 02 00           lcall 0x297
000040e1: c7 aa 4c              extr $r10 $r10 0xc:0xe
000040e4: b3 a4 07 f2           bra b32 $r10 0x7 ne 0x40d6
000040e8: 3e f3 40 00           lbra 0x40f3
000040ec: 90 11 01            B add b32 $r1 $r1 0x1
000040ef: 3e f9 40 00           lbra 0x40f9
000040f3: 8e 00 00 01         B mov $r14 0x10000
000040f7: bd f4                 clear b32 $r15
000040f9: ff ef 9f            B iord $r9 I[$r14+$r15*0x4]
000040fc: f1 94 00 02           and $r9 0x200
00004100: f4 0b 23              bra e 0x4123
00004103: 89 d4 12 00         B mov $r9 0x12d4
00004107: bf 9a                 ld b32 $r10 D[$r9]
00004109: b2 90                 mov b32 $r0 $r9
0000410b: 89 e8 02 04           mov $r9 0x402e8
0000410f: 0b 01                 mov $r11 0x1
00004111: bc a9 a0              add b32 $r10 $r10 $r9
00004114: bd c4                 clear b32 $r12
00004116: b6 a4 02              shl b32 $r10 0x2
00004119: b2 bd                 mov b32 $r13 $r11
0000411b: 7e 2f 02 00           lcall 0x22f
0000411f: 3e 2c 41 00           lbra 0x412c
00004123: a6 10               B cmp b32 $r1 $r0
00004125: f4 08 c7              bra b 0x40ec
00004128: 3e 03 41 00           lbra 0x4103
0000412c: bf 0a               B ld b32 $r10 D[$r0]
0000412e: 89 f0 02 04           mov $r9 0x402f0
00004132: bc a9 a0              add b32 $r10 $r10 $r9
00004135: b6 a4 02              shl b32 $r10 0x2
00004138: 7e 97 02 00           lcall 0x297
0000413c: f0 a4 01              and $r10 0x1
0000413f: f4 0b ed              bra e 0x412c
00004142: bd f4                 clear b32 $r15
00004144: 89 00 0c 01           mov $r9 0x10c00
00004148: fa 9f 00              iowr I[$r9] $r15
0000414b: 89 c4 12 00           mov $r9 0x12c4
0000414f: 00 01                 mov $r0 0x1
00004151: 0a 05                 mov $r10 0x5
00004153: b2 0b                 mov b32 $r11 $r0
00004155: a0 90                 st b32 D[$r9] $r0
00004157: 89 bc 12 00           mov $r9 0x12bc
0000415b: a0 9f                 st b32 D[$r9] $r15
0000415d: 7e 17 0d 00           lcall 0xd17
00004161: 7e a6 29 00           lcall 0x29a6
00004165: 8a 14 96 40           mov $r10 0x409614
00004169: 0b 05                 mov $r11 0x5
0000416b: 7e 37 02 00           lcall 0x237
0000416f: 8a 14 a6 41           mov $r10 0x41a614
00004173: 4b 06 08              mov $r11 0x806
00004176: 7e 37 02 00           lcall 0x237
0000417a: b2 0b                 mov b32 $r11 $r0
0000417c: 0a 06                 mov $r10 0x6
0000417e: 7e 17 0d 00           lcall 0xd17
00004182: 7e 10 40 00           lcall 0x4010
00004186: 8f 00 80 00           mov $r15 0x8000
0000418a: 89 00 1a 02           mov $r9 0x21a00
0000418e: fa 9f 00              iowr I[$r9] $r15
00004191: 4f 00 40              mov $r15 0x4000
00004194: b8 99 00 02 02        sub b32 $r9 $r9 0x200
00004199: fa 9f 00              iowr I[$r9] $r15
0000419c: b2 1a               B mov b32 $r10 $r1
0000419e: fb 11                 mpopret $r1

000041a0: f9 12              C  mpush $r1
000041a2: 81 00 84 02           mov $r1 0x28400
000041a6: bd 04                 clear b32 $r0
000041a8: 7e 5e 21 00         B lcall 0x215e
000041ac: ff 10 9f              iord $r9 I[$r1+$r0*0x4]
000041af: f0 94 1f              and $r9 0x1f
000041b2: f4 1b f6              bra ne 0x41a8
000041b5: fb 11                 mpopret $r1

000041b7: f9 32              C  mpush $r3
000041b9: b2 a2                 mov b32 $r2 $r10
000041bb: b2 b0                 mov b32 $r0 $r11
000041bd: b2 c3                 mov b32 $r3 $r12
000041bf: 7e 53 1f 00           lcall 0x1f53
000041c3: 09 01                 mov $r9 0x1
000041c5: b3 a0 00 5a           bra b32 $r10 0x0 e 0x421f
000041c9: b2 0b                 mov b32 $r11 $r0
000041cb: b2 3c                 mov b32 $r12 $r3
000041cd: 0a 01                 mov $r10 0x1
000041cf: 7e da 1e 00           lcall 0x1eda
000041d3: b2 0b                 mov b32 $r11 $r0
000041d5: b2 3c                 mov b32 $r12 $r3
000041d7: b2 a1                 mov b32 $r1 $r10
000041d9: 0a 02                 mov $r10 0x2
000041db: 7e da 1e 00           lcall 0x1eda
000041df: b2 a0                 mov b32 $r0 $r10
000041e1: 7e cf 31 00           lcall 0x31cf
000041e5: b2 1b                 mov b32 $r11 $r1
000041e7: 8a 00 89 02           mov $r10 0x28900
000041eb: 7e 10 00 00           lcall 0x10
000041ef: b2 0b                 mov b32 $r11 $r0
000041f1: 8a 00 83 02           mov $r10 0x28300
000041f5: 7e 10 00 00           lcall 0x10
000041f9: b3 20 0c 08           bra b32 $r2 0xc e 0x4201
000041fd: b3 24 0a 0e           bra b32 $r2 0xa ne 0x420b
00004201: 0a 31               B mov $r10 0x31
00004203: 7e c0 05 00           lcall 0x5c0
00004207: 3e 15 42 00           lbra 0x4215
0000420b: b2 2b               B mov b32 $r11 $r2
0000420d: 8a 00 84 02           mov $r10 0x28400
00004211: 7e 10 00 00           lcall 0x10
00004215: 7e a0 41 00         B lcall 0x41a0
00004219: 7e cf 31 00           lcall 0x31cf
0000421d: bd 94                 clear b32 $r9
0000421f: b2 9a               B mov b32 $r10 $r9
00004221: fb 31                 mpopret $r3

00004223: f9 72              C  mpush $r7
00004225: d9 00 00 00 80        mov $r9 0x80000000
0000422a: f4 30 f4              add $sp -0xc
0000422d: b2 a2                 mov b32 $r2 $r10
0000422f: 8f 00 14 02           mov $r15 0x21400
00004233: fa f9 00              iowr I[$r15] $r9
00004236: 89 f0 13 00           mov $r9 0x13f0
0000423a: bf 9f                 ld b32 $r15 D[$r9]
0000423c: b3 fd 00 32 01        bra b32 $r15 0x0 ne 0x436e
00004241: 89 00 de 02           mov $r9 0x2de00
00004245: ff 9f 9f              iord $r9 I[$r9+$r15*0x4]
00004248: f0 94 3f              and $r9 0x3f
0000424b: f5 0b 23 01           bra e 0x436e
0000424f: 89 1c 14 00           mov $r9 0x141c
00004253: bf 99                 ld b32 $r9 D[$r9]
00004255: b3 94 00 0f           bra b32 $r9 0x0 ne 0x4264
00004259: 89 20 14 00           mov $r9 0x1420
0000425d: bf 99                 ld b32 $r9 D[$r9]
0000425f: b3 99 00 0f 01        bra b32 $r9 0x0 e 0x436e
00004264: 89 28 14 00         B mov $r9 0x1428
00004268: bf 9c                 ld b32 $r12 D[$r9]
0000426a: b3 c0 00 16           bra b32 $r12 0x0 e 0x4280
0000426e: df 00 00 00 80        mov $r15 0x80000000
00004273: 89 00 1a 02           mov $r9 0x21a00
00004277: fa 9f 00              iowr I[$r9] $r15
0000427a: 0f 04                 mov $r15 0x4
0000427c: 3e 8e 43 00           lbra 0x438e
00004280: d9 ff ff ff 00      B mov $r9 0xffffff
00004285: a6 29                 cmp b32 $r2 $r9
00004287: f4 0d 15              bra be 0x429c
0000428a: df 00 00 00 80        mov $r15 0x80000000
0000428f: 89 00 1a 02           mov $r9 0x21a00
00004293: fa 9f 00              iowr I[$r9] $r15
00004296: 0f 05                 mov $r15 0x5
00004298: 3e 8e 43 00           lbra 0x438e
0000429c: 89 00 81 02         B mov $r9 0x28100
000042a0: ff 9c 7f              iord $r7 I[$r9+$r12*0x4]
000042a3: b8 99 00 0d 00        add b32 $r9 $r9 0xd00
000042a8: ff 9c 6f              iord $r6 I[$r9+$r12*0x4]
000042ab: b8 99 00 01 00        add b32 $r9 $r9 0x100
000042b0: ff 9c 5f              iord $r5 I[$r9+$r12*0x4]
000042b3: 89 14 14 00           mov $r9 0x1414
000042b7: bf 9d                 ld b32 $r13 D[$r9]
000042b9: 89 18 14 00           mov $r9 0x1418
000042bd: bf 99                 ld b32 $r9 D[$r9]
000042bf: 8f 24 14 00           mov $r15 0x1424
000042c3: bf f0                 ld b32 $r0 D[$r15]
000042c5: 95 df 08              shr b32 $r15 $r13 0x8
000042c8: 95 9b 08              shr b32 $r11 $r9 0x8
000042cb: b6 94 18              shl b32 $r9 0x18
000042ce: fd 9f 05              or $r9 $r15
000042d1: 95 2f 0d              shr b32 $r15 $r2 0xd
000042d4: 95 24 02              shr b32 $r4 $r2 0x2
000042d7: bc f9 e0              add b32 $r14 $r15 $r9
000042da: 95 2f 05              shr b32 $r15 $r2 0x5
000042dd: a6 e9                 cmp b32 $r14 $r9
000042df: f4 18 06              bra ae 0x42e5
000042e2: 90 bb 01              add b32 $r11 $r11 0x1
000042e5: c4 f9 ff            B and $r9 $r15 0xff
000042e8: c4 df ff              and $r15 $r13 0xff
000042eb: bc 9f f0              add b32 $r15 $r9 $r15
000042ee: 95 f9 08              shr b32 $r9 $r15 0x8
000042f1: bc 9e 10              add b32 $r1 $r9 $r14
000042f4: a6 1e                 cmp b32 $r1 $r14
000042f6: f4 18 06              bra ae 0x42fc
000042f9: 90 bb 01              add b32 $r11 $r11 0x1
000042fc: 89 34 14 00         B mov $r9 0x1434
00004300: bf 99                 ld b32 $r9 D[$r9]
00004302: c4 f3 ff              and $r3 $r15 0xff
00004305: b3 90 00 0f           bra b32 $r9 0x0 e 0x4314
00004309: 89 30 14 00           mov $r9 0x1430
0000430d: bf 99                 ld b32 $r9 D[$r9]
0000430f: a6 91                 cmp b32 $r9 $r1
00004311: f4 0b 43              bra e 0x4354
00004314: b2 1a               B mov b32 $r10 $r1
00004316: 4c c0 00              mov $r12 0xc0
00004319: 7e b9 32 00           lcall 0x32b9
0000431d: 7e cf 31 00           lcall 0x31cf
00004321: 09 02                 mov $r9 0x2
00004323: b2 0e                 mov b32 $r14 $r0
00004325: bd a4                 clear b32 $r10
00004327: 00 01                 mov $r0 0x1
00004329: b2 3b                 mov b32 $r11 $r3
0000432b: 0c 06                 mov $r12 0x6
0000432d: b0 91 02              st b32 D[$sp+0x8] $r9
00004330: b0 01 00              st b32 D[$sp] $r0
00004333: b0 01 01              st b32 D[$sp+0x4] $r0
00004336: 8d 00 0b 00           mov $r13 0xb00
0000433a: 7e e1 2d 00           lcall 0x2de1
0000433e: 89 34 14 00           mov $r9 0x1434
00004342: a0 90                 st b32 D[$r9] $r0
00004344: 89 30 14 00           mov $r9 0x1430
00004348: b2 7a                 mov b32 $r10 $r7
0000434a: b2 6b                 mov b32 $r11 $r6
0000434c: b2 5c                 mov b32 $r12 $r5
0000434e: a0 91                 st b32 D[$r9] $r1
00004350: 7e b9 32 00           lcall 0x32b9
00004354: 8f 00 0b 00         B mov $r15 0xb00
00004358: c4 39 fc              and $r9 $r3 0xfc
0000435b: bc 9f 90              add b32 $r9 $r9 $r15
0000435e: bf 9e                 ld b32 $r14 D[$r9]
00004360: c4 4f 1f              and $r15 $r4 0x1f
00004363: 09 01                 mov $r9 0x1
00004365: bb 9f 04              shl b32 $r9 $r15
00004368: fd 9e 04              and $r9 $r14
0000436b: f4 0b 15              bra e 0x4380
0000436e: df 00 00 00 80      B mov $r15 0x80000000
00004373: 89 00 1a 02           mov $r9 0x21a00
00004377: fa 9f 00              iowr I[$r9] $r15
0000437a: bd a4                 clear b32 $r10
0000437c: 3e a0 43 00           lbra 0x43a0
00004380: df 00 00 00 80      B mov $r15 0x80000000
00004385: 89 00 1a 02           mov $r9 0x21a00
00004389: fa 9f 00              iowr I[$r9] $r15
0000438c: 0f 06                 mov $r15 0x6
0000438e: b8 99 00 0c 02      B sub b32 $r9 $r9 0xc00
00004393: fa 9f 00              iowr I[$r9] $r15
00004396: b8 99 00 01 00        add b32 $r9 $r9 0x100
0000439b: fa 92 00              iowr I[$r9] $r2
0000439e: 0a 01                 mov $r10 0x1
000043a0: f4 30 0c            B add $sp 0xc
000043a3: fb 71                 mpopret $r7

000043a5: f9 32              C  mpush $r3
000043a7: b2 b0                 mov b32 $r0 $r11
000043a9: b2 c3                 mov b32 $r3 $r12
000043ab: b2 a2                 mov b32 $r2 $r10
000043ad: 7e 8e 39 00           lcall 0x398e
000043b1: b3 a0 01 44           bra b32 $r10 0x1 e 0x43f5
000043b5: b2 2a                 mov b32 $r10 $r2
000043b7: 7e 23 42 00           lcall 0x4223
000043bb: b3 a0 01 3a           bra b32 $r10 0x1 e 0x43f5
000043bf: b2 0b                 mov b32 $r11 $r0
000043c1: b2 3c                 mov b32 $r12 $r3
000043c3: 0a 01                 mov $r10 0x1
000043c5: 7e da 1e 00           lcall 0x1eda
000043c9: b2 0b                 mov b32 $r11 $r0
000043cb: b2 3c                 mov b32 $r12 $r3
000043cd: b2 a1                 mov b32 $r1 $r10
000043cf: 0a 02                 mov $r10 0x2
000043d1: 7e da 1e 00           lcall 0x1eda
000043d5: b2 a0                 mov b32 $r0 $r10
000043d7: b2 2a                 mov b32 $r10 $r2
000043d9: 7e 97 02 00           lcall 0x297
000043dd: ff 01 14              and $r1 $r0 $r1
000043e0: b9 00 00              not b32 $r0 $r0
000043e3: fd 0a 04              and $r0 $r10
000043e6: b2 2a                 mov b32 $r10 $r2
000043e8: ff 01 b5              or $r11 $r0 $r1
000043eb: 7e 37 02 00           lcall 0x237
000043ef: bd a4                 clear b32 $r10
000043f1: 3e f7 43 00           lbra 0x43f7
000043f5: 0a 01               B mov $r10 0x1
000043f7: fb 31               B mpopret $r3

000043f9: f9 22              C  mpush $r2
000043fb: b2 b2                 mov b32 $r2 $r11
000043fd: b2 c1                 mov b32 $r1 $r12
000043ff: b2 a0                 mov b32 $r0 $r10
00004401: 7e 8e 39 00           lcall 0x398e
00004405: b3 a0 01 26           bra b32 $r10 0x1 e 0x442b
00004409: b2 0a                 mov b32 $r10 $r0
0000440b: 7e 23 42 00           lcall 0x4223
0000440f: b3 a0 01 1c           bra b32 $r10 0x1 e 0x442b
00004413: b2 1c                 mov b32 $r12 $r1
00004415: b2 2b                 mov b32 $r11 $r2
00004417: 0a 01                 mov $r10 0x1
00004419: 7e da 1e 00           lcall 0x1eda
0000441d: b2 ab                 mov b32 $r11 $r10
0000441f: b2 0a                 mov b32 $r10 $r0
00004421: 7e 37 02 00           lcall 0x237
00004425: bd a4                 clear b32 $r10
00004427: 3e 2d 44 00           lbra 0x442d
0000442b: 0a 01               B mov $r10 0x1
0000442d: fb 21               B mpopret $r2

0000442f: f9 22              C  mpush $r2
00004431: b2 b1                 mov b32 $r1 $r11
00004433: b2 c2                 mov b32 $r2 $r12
00004435: b2 a0                 mov b32 $r0 $r10
00004437: 7e 8e 39 00           lcall 0x398e
0000443b: b3 a0 01 26           bra b32 $r10 0x1 e 0x4461
0000443f: b2 0a                 mov b32 $r10 $r0
00004441: 7e 23 42 00           lcall 0x4223
00004445: b3 a0 01 1c           bra b32 $r10 0x1 e 0x4461
00004449: b2 0a                 mov b32 $r10 $r0
0000444b: 7e 97 02 00           lcall 0x297
0000444f: b2 1c                 mov b32 $r12 $r1
00004451: b2 ab                 mov b32 $r11 $r10
00004453: b2 2d                 mov b32 $r13 $r2
00004455: 0a 01                 mov $r10 0x1
00004457: 7e 5f 1e 00           lcall 0x1e5f
0000445b: bd a4                 clear b32 $r10
0000445d: 3e 63 44 00           lbra 0x4463
00004461: 0a 01               B mov $r10 0x1
00004463: fb 21               B mpopret $r2

00004465: f9 02              C  mpush $r0
00004467: b2 a0                 mov b32 $r0 $r10
00004469: 8a 20 60 40           mov $r10 0x406020
0000446d: 7e 97 02 00           lcall 0x297
00004471: b3 00 00 0f           bra b32 $r0 0x0 e 0x4480
00004475: 89 00 00 20           mov $r9 0x200000
00004479: ff a9 b5              or $r11 $r10 $r9
0000447c: 3e 87 44 00           lbra 0x4487
00004480: 89 ff ff df         B mov $r9 -0x200001
00004484: ff a9 b4              and $r11 $r10 $r9
00004487: 8a 20 60 40         B mov $r10 0x406020
0000448b: 7e 37 02 00           lcall 0x237
0000448f: fb 01                 mpopret $r0

00004491: f9 22              C  mpush $r2
00004493: 4f 00 20              mov $r15 0x2000
00004496: 89 00 12 02           mov $r9 0x21200
0000449a: fa 9f 00              iowr I[$r9] $r15
0000449d: 8a 04 07 40           mov $r10 0x400704
000044a1: 7e 97 02 00           lcall 0x297
000044a5: 8f 80 10 10           mov $r15 0x101080
000044a9: b2 a9                 mov b32 $r9 $r10
000044ab: c7 aa 50              extr $r10 $r10 0x10:0x12
000044ae: e4 90 fc 3f           and $r0 $r9 0x3ffc
000044b2: bc af a0              add b32 $r10 $r10 $r15
000044b5: c7 92 16              extr $r2 $r9 0x16:0x16
000044b8: b6 a4 02              shl b32 $r10 0x2
000044bb: 7e 97 02 00           lcall 0x297
000044bf: e4 a1 ff ff           and $r1 $r10 0xffff
000044c3: 8a 08 07 40           mov $r10 0x400708
000044c7: 7e 97 02 00           lcall 0x297
000044cb: 89 40 a1 00           mov $r9 0xa140
000044cf: a6 19                 cmp b32 $r1 $r9
000044d1: f5 0b a6 00           bra e 0x4577
000044d5: a6 19                 cmp b32 $r1 $r9
000044d7: f4 0c 12              bra a 0x44e9
000044da: b8 99 13 11 02        sub b32 $r9 $r9 0x1113
000044df: a6 19                 cmp b32 $r1 $r9
000044e1: f5 1b 43 01           bra ne 0x4624
000044e5: 3e a7 45 00           lbra 0x45a7
000044e9: 89 97 c9 00         B mov $r9 0xc997
000044ed: a6 19                 cmp b32 $r1 $r9
000044ef: f4 0b 10              bra e 0x44ff
000044f2: 90 99 29              add b32 $r9 $r9 0x29
000044f5: a6 19                 cmp b32 $r1 $r9
000044f7: f5 1b 2d 01           bra ne 0x4624
000044fb: 3e 37 45 00           lbra 0x4537
000044ff: b3 0b 0c 23 f9 00   B bra b32 $r0 0x230c e 0x45f8
00004505: b1 06 0c 23           cmp b32 $r0 0x230c
00004509: f4 0c 19              bra a 0x4522
0000450c: b3 0b 04 23 d4 00     bra b32 $r0 0x2304 e 0x45e0
00004512: b3 0b 08 23 da 00     bra b32 $r0 0x2308 e 0x45ec
00004518: b3 0f 00 23 0c 01     bra b32 $r0 0x2300 ne 0x4624
0000451e: 3e d4 45 00           lbra 0x45d4
00004522: b3 0b 14 23 f6 00   B bra b32 $r0 0x2314 e 0x4618
00004528: b3 0a 20 23 47        bra b32 $r0 0x2320 e 0x456f
0000452d: b3 0f 10 23 f7 00     bra b32 $r0 0x2310 ne 0x4624
00004533: 3e 0c 46 00           lbra 0x460c
00004537: b3 0b 0c 05 c1 00   B bra b32 $r0 0x50c e 0x45f8
0000453d: b1 06 0c 05           cmp b32 $r0 0x50c
00004541: f4 0c 19              bra a 0x455a
00004544: b3 0b 04 05 9c 00     bra b32 $r0 0x504 e 0x45e0
0000454a: b3 0b 08 05 a2 00     bra b32 $r0 0x508 e 0x45ec
00004550: b3 0f 00 05 d4 00     bra b32 $r0 0x500 ne 0x4624
00004556: 3e d4 45 00           lbra 0x45d4
0000455a: b3 0b 14 05 be 00   B bra b32 $r0 0x514 e 0x4618
00004560: b3 0a 20 05 0f        bra b32 $r0 0x520 e 0x456f
00004565: b3 0f 10 05 bf 00     bra b32 $r0 0x510 ne 0x4624
0000456b: 3e 0c 46 00           lbra 0x460c
0000456f: 7e 65 44 00         B lcall 0x4465
00004573: 3e 33 46 00           lbra 0x4633
00004577: b3 0a 08 02 75      B bra b32 $r0 0x208 e 0x45ec
0000457c: b1 06 08 02           cmp b32 $r0 0x208
00004580: f4 0c 12              bra a 0x4592
00004583: b3 0a 00 02 51        bra b32 $r0 0x200 e 0x45d4
00004588: b3 0f 04 02 9c 00     bra b32 $r0 0x204 ne 0x4624
0000458e: 3e e0 45 00           lbra 0x45e0
00004592: b3 0a 10 02 7a      B bra b32 $r0 0x210 e 0x460c
00004597: b3 0b 14 02 81 00     bra b32 $r0 0x214 e 0x4618
0000459d: b3 0f 0c 02 87 00     bra b32 $r0 0x20c ne 0x4624
000045a3: 3e f8 45 00           lbra 0x45f8
000045a7: b3 0a e8 08 45      B bra b32 $r0 0x8e8 e 0x45ec
000045ac: b1 06 e8 08           cmp b32 $r0 0x8e8
000045b0: f4 0c 11              bra a 0x45c1
000045b3: b3 0a e0 08 21        bra b32 $r0 0x8e0 e 0x45d4
000045b8: b3 0e e4 08 6c        bra b32 $r0 0x8e4 ne 0x4624
000045bd: 3e e0 45 00           lbra 0x45e0
000045c1: b3 0a f0 08 4b      B bra b32 $r0 0x8f0 e 0x460c
000045c6: b3 0a f4 08 52        bra b32 $r0 0x8f4 e 0x4618
000045cb: b3 0e ec 08 59        bra b32 $r0 0x8ec ne 0x4624
000045d0: 3e f8 45 00           lbra 0x45f8
000045d4: b2 1b               B mov b32 $r11 $r1
000045d6: b2 2c                 mov b32 $r12 $r2
000045d8: 7e 2f 44 00           lcall 0x442f
000045dc: 3e 20 46 00           lbra 0x4620
000045e0: b2 1b               B mov b32 $r11 $r1
000045e2: b2 2c                 mov b32 $r12 $r2
000045e4: 7e f9 43 00           lcall 0x43f9
000045e8: 3e 20 46 00           lbra 0x4620
000045ec: b2 1b               B mov b32 $r11 $r1
000045ee: b2 2c                 mov b32 $r12 $r2
000045f0: 7e b7 41 00           lcall 0x41b7
000045f4: 3e 20 46 00           lbra 0x4620
000045f8: 89 28 00 00         B mov $r9 0x28
000045fc: bf 9b                 ld b32 $r11 D[$r9]
000045fe: 0a 01                 mov $r10 0x1
00004600: b2 1c                 mov b32 $r12 $r1
00004602: b2 2d                 mov b32 $r13 $r2
00004604: 7e 5f 1e 00           lcall 0x1e5f
00004608: 3e 33 46 00           lbra 0x4633
0000460c: b2 1b               B mov b32 $r11 $r1
0000460e: b2 2c                 mov b32 $r12 $r2
00004610: 7e a5 43 00           lcall 0x43a5
00004614: 3e 20 46 00           lbra 0x4620
00004618: b2 1b               B mov b32 $r11 $r1
0000461a: b2 2c                 mov b32 $r12 $r2
0000461c: 7e ff 31 00           lcall 0x31ff
00004620: b3 a0 00 13         B bra b32 $r10 0x0 e 0x4633
00004624: 8f 00 00 02         B mov $r15 0x20000
00004628: 89 00 07 03           mov $r9 0x30700
0000462c: fa 9f 00              iowr I[$r9] $r15
0000462f: 3e 4a 46 00           lbra 0x464a
00004633: bd a4               B clear b32 $r10
00004635: 0b 01                 mov $r11 0x1
00004637: b2 1c                 mov b32 $r12 $r1
00004639: b2 2d                 mov b32 $r13 $r2
0000463b: 7e 5f 1e 00           lcall 0x1e5f
0000463f: 8a 44 01 40           mov $r10 0x400144
00004643: 4b 00 01              mov $r11 0x100
00004646: 7e 37 02 00           lcall 0x237
0000464a: 4f 00 20            B mov $r15 0x2000
0000464d: 89 00 18 02           mov $r9 0x21800
00004651: fa 9f 00              iowr I[$r9] $r15
00004654: fb 21                 mpopret $r2

00004656: f9 52              C  mpush $r5
00004658: df 00 00 00 40        mov $r15 0x40000000
0000465d: 89 00 12 02           mov $r9 0x21200
00004661: fa 9f 00              iowr I[$r9] $r15
00004664: 85 c4 12 00           mov $r5 0x12c4
00004668: 84 fc 15 00           mov $r4 0x15fc
0000466c: 80 f8 15 00           mov $r0 0x15f8
00004670: 83 b8 15 00           mov $r3 0x15b8
00004674: 82 ff 0f ff           mov $r2 -0xf001
00004678: 81 02 00 01           mov $r1 0x10002
0000467c: 3e bc 46 00           lbra 0x46bc
00004680: bf 09               B ld b32 $r9 D[$r0]
00004682: bf 0f                 ld b32 $r15 D[$r0]
00004684: bf 0e                 ld b32 $r14 D[$r0]
00004686: 8d b8 15 00           mov $r13 0x15b8
0000468a: f0 94 07              and $r9 0x7
0000468d: b6 94 03              shl b32 $r9 0x3
00004690: bc 9d 90              add b32 $r9 $r9 $r13
00004693: 90 ee 01              add b32 $r14 $r14 0x1
00004696: bf 9d                 ld b32 $r13 D[$r9]
00004698: a0 0e                 st b32 D[$r0] $r14
0000469a: bf 09                 ld b32 $r9 D[$r0]
0000469c: f0 f4 07              and $r15 0x7
0000469f: bc ff f0              add b32 $r15 $r15 $r15
000046a2: 90 ff 01              add b32 $r15 $r15 0x1
000046a5: bc 3f b8              ld b32 $r11 D[$r3+$r15*0x4]
000046a8: b3 94 10 06           bra b32 $r9 0x10 ne 0x46ae
000046ac: a0 0c                 st b32 D[$r0] $r12
000046ae: ff d2 94            B and $r9 $r13 $r2
000046b1: a6 91                 cmp b32 $r9 $r1
000046b3: f4 1b 21              bra ne 0x46d4
000046b6: b2 1a                 mov b32 $r10 $r1
000046b8: 7e 91 44 00           lcall 0x4491
000046bc: bf 59               B ld b32 $r9 D[$r5]
000046be: b3 90 00 14           bra b32 $r9 0x0 e 0x46d2
000046c2: 89 fc 15 00           mov $r9 0x15fc
000046c6: bf 99                 ld b32 $r9 D[$r9]
000046c8: 89 f8 15 00           mov $r9 0x15f8
000046cc: bf 99                 ld b32 $r9 D[$r9]
000046ce: 3e dd 46 00           lbra 0x46dd
000046d2: bd c4               B clear b32 $r12
000046d4: bf 4f               B ld b32 $r15 D[$r4]
000046d6: bf 09                 ld b32 $r9 D[$r0]
000046d8: a6 f9                 cmp b32 $r15 $r9
000046da: f4 1b a6              bra ne 0x4680
000046dd: df 00 00 00 40      B mov $r15 0x40000000
000046e2: 89 00 18 02           mov $r9 0x21800
000046e6: fa 9f 00              iowr I[$r9] $r15
000046e9: fb 51                 mpopret $r5

000046eb: 89 fc 15 00        C  mov $r9 0x15fc
000046ef: bf 9f                 ld b32 $r15 D[$r9]
000046f1: 89 f8 15 00           mov $r9 0x15f8
000046f5: bf 99                 ld b32 $r9 D[$r9]
000046f7: a6 f9                 cmp b32 $r15 $r9
000046f9: f4 0b 07              bra e 0x4700
000046fc: 7e 56 46 00           lcall 0x4656
00004700: f8 00               B ret

00004702: f9 22              C  mpush $r2
00004704: b2 a0                 mov b32 $r0 $r10
00004706: 82 00 00 03           mov $r2 0x30000
0000470a: bd 14                 clear b32 $r1
0000470c: 3e 18 47 00           lbra 0x4718
00004710: 7e 5e 21 00         B lcall 0x215e
00004714: 7e eb 46 00           lcall 0x46eb
00004718: ff 21 9f            B iord $r9 I[$r2+$r1*0x4]
0000471b: e4 9f 00 20           and $r15 $r9 0x2000
0000471f: f4 1b f1              bra ne 0x4710
00004722: 89 c0 12 00           mov $r9 0x12c0
00004726: a0 9f                 st b32 D[$r9] $r15
00004728: b3 00 00 0c           bra b32 $r0 0x0 e 0x4734
0000472c: 0f 01                 mov $r15 0x1
0000472e: 89 b8 12 00           mov $r9 0x12b8
00004732: a0 9f                 st b32 D[$r9] $r15
00004734: 0f 20               B mov $r15 0x20
00004736: 89 00 19 02           mov $r9 0x21900
0000473a: fa 9f 00              iowr I[$r9] $r15
0000473d: fb 21                 mpopret $r2

0000473f: f9 02              C  mpush $r0
00004741: b2 a0                 mov b32 $r0 $r10
00004743: b2 ba                 mov b32 $r10 $r11
00004745: 7e 82 0e 00           lcall 0xe82
00004749: b2 0a                 mov b32 $r10 $r0
0000474b: 7e 02 47 00           lcall 0x4702
0000474f: fb 01                 mpopret $r0

00004751: f9 22              C  mpush $r2
00004753: df 00 00 00 40        mov $r15 0x40000000
00004758: 89 00 13 02           mov $r9 0x21300
0000475c: fa 9f 00              iowr I[$r9] $r15
0000475f: 82 c8 12 00           mov $r2 0x12c8
00004763: 81 00 2a 02           mov $r1 0x22a00
00004767: d0 00 00 17 28        mov $r0 0x28170000
0000476c: 3e 7b 47 00           lbra 0x477b
00004770: fa 10 00            B iowr I[$r1] $r0
00004773: 7e 5e 21 00           lcall 0x215e
00004777: 7e eb 46 00           lcall 0x46eb
0000477b: bf 29               B ld b32 $r9 D[$r2]
0000477d: b3 94 00 f3           bra b32 $r9 0x0 ne 0x4770
00004781: df 00 00 00 40        mov $r15 0x40000000
00004786: 89 00 19 02           mov $r9 0x21900
0000478a: fa 9f 00              iowr I[$r9] $r15
0000478d: fb 21                 mpopret $r2

0000478f: f9 02              C  mpush $r0
00004791: bd 94                 clear b32 $r9
00004793: 8f 00 3c 02           mov $r15 0x23c00
00004797: ff f9 ff              iord $r15 I[$r15+$r9*0x4]
0000479a: 8e bc 13 00           mov $r14 0x13bc
0000479e: 90 ff 01              add b32 $r15 $r15 0x1
000047a1: a0 ef                 st b32 D[$r14] $r15
000047a3: 09 ff                 mov $r9 -0x1
000047a5: a6 f9                 cmp b32 $r15 $r9
000047a7: f4 1b 07              bra ne 0x47ae
000047aa: 09 01                 mov $r9 0x1
000047ac: a0 e9                 st b32 D[$r14] $r9
000047ae: 80 bc 13 00         B mov $r0 0x13bc
000047b2: bf 0b                 ld b32 $r11 D[$r0]
000047b4: 8a 00 3c 02           mov $r10 0x23c00
000047b8: 7e 10 00 00           lcall 0x10
000047bc: bf 0a                 ld b32 $r10 D[$r0]
000047be: fb 01                 mpopret $r0

000047c0: f9 02              C  mpush $r0
000047c2: b2 a0                 mov b32 $r0 $r10
000047c4: 0a 03                 mov $r10 0x3
000047c6: b3 00 00 06           bra b32 $r0 0x0 e 0x47cc
000047ca: 0a 05                 mov $r10 0x5
000047cc: 7e 91 07 00         B lcall 0x791
000047d0: 89 14 13 00           mov $r9 0x1314
000047d4: bf 9a                 ld b32 $r10 D[$r9]
000047d6: 89 18 13 00           mov $r9 0x1318
000047da: bf 9b                 ld b32 $r11 D[$r9]
000047dc: 89 1c 13 00           mov $r9 0x131c
000047e0: bf 9c                 ld b32 $r12 D[$r9]
000047e2: 7e b9 32 00           lcall 0x32b9
000047e6: df 00 00 16 29        mov $r15 0x29160000
000047eb: 89 00 2a 02           mov $r9 0x22a00
000047ef: fa 9f 00              iowr I[$r9] $r15
000047f2: 0a 04                 mov $r10 0x4
000047f4: 7e 5b 04 00           lcall 0x45b
000047f8: df 00 00 13 2c        mov $r15 0x2c130000
000047fd: 89 00 2a 02           mov $r9 0x22a00
00004801: fa 9f 00              iowr I[$r9] $r15
00004804: 8a 20 44 02           mov $r10 0x24420
00004808: bd b4                 clear b32 $r11
0000480a: 7e 10 00 00           lcall 0x10
0000480e: 7e 19 2c 00           lcall 0x2c19
00004812: 0a 0f                 mov $r10 0xf
00004814: bd b4                 clear b32 $r11
00004816: 7e ed 03 00           lcall 0x3ed
0000481a: 7e 19 2c 00           lcall 0x2c19
0000481e: 0a 04                 mov $r10 0x4
00004820: 0b 01                 mov $r11 0x1
00004822: 7e ed 03 00           lcall 0x3ed
00004826: 7e 19 2c 00           lcall 0x2c19
0000482a: 7e d1 0e 00           lcall 0xed1
0000482e: 0a 01                 mov $r10 0x1
00004830: 7e 15 04 00           lcall 0x415
00004834: 7e 19 2c 00           lcall 0x2c19
00004838: b3 04 00 0e           bra b32 $r0 0x0 ne 0x4846
0000483c: bd a4                 clear b32 $r10
0000483e: 7e 45 04 00           lcall 0x445
00004842: 3e 4c 48 00           lbra 0x484c
00004846: bd a4               B clear b32 $r10
00004848: 7e 2f 04 00           lcall 0x42f
0000484c: 7e 19 2c 00         B lcall 0x2c19
00004850: 0a 0f                 mov $r10 0xf
00004852: bd b4                 clear b32 $r11
00004854: 7e ed 03 00           lcall 0x3ed
00004858: 7e 19 2c 00           lcall 0x2c19
0000485c: 0a 03                 mov $r10 0x3
0000485e: 0b 01                 mov $r11 0x1
00004860: 7e ed 03 00           lcall 0x3ed
00004864: 7e 19 2c 00           lcall 0x2c19
00004868: df 00 00 16 29        mov $r15 0x29160000
0000486d: 89 00 2a 02           mov $r9 0x22a00
00004871: fa 9f 00              iowr I[$r9] $r15
00004874: 0a 02                 mov $r10 0x2
00004876: 7e 5b 04 00           lcall 0x45b
0000487a: fb 01                 mpopret $r0

0000487c: f9 22              C  mpush $r2
0000487e: 4f 00 10              mov $r15 0x1000
00004881: b2 a1                 mov b32 $r1 $r10
00004883: b2 b0                 mov b32 $r0 $r11
00004885: 89 00 13 02           mov $r9 0x21300
00004889: fa 9f 00              iowr I[$r9] $r15
0000488c: 7e d1 0e 00           lcall 0xed1
00004890: 0a 01                 mov $r10 0x1
00004892: 7e 15 04 00           lcall 0x415
00004896: 7e 19 2c 00           lcall 0x2c19
0000489a: bd b4                 clear b32 $r11
0000489c: 0a 0f                 mov $r10 0xf
0000489e: 7e ed 03 00           lcall 0x3ed
000048a2: 7e 19 2c 00           lcall 0x2c19
000048a6: 0b 01                 mov $r11 0x1
000048a8: b2 0a                 mov b32 $r10 $r0
000048aa: 7e ed 03 00           lcall 0x3ed
000048ae: 7e 19 2c 00           lcall 0x2c19
000048b2: bd a4                 clear b32 $r10
000048b4: 7e 8c 2c 00           lcall 0x2c8c
000048b8: 7e 19 2c 00           lcall 0x2c19
000048bc: 0a 0f                 mov $r10 0xf
000048be: bd b4                 clear b32 $r11
000048c0: 7e ed 03 00           lcall 0x3ed
000048c4: 7e 19 2c 00           lcall 0x2c19
000048c8: 0a 03                 mov $r10 0x3
000048ca: 0b 01                 mov $r11 0x1
000048cc: 7e ed 03 00           lcall 0x3ed
000048d0: 7e 19 2c 00           lcall 0x2c19
000048d4: bd a4                 clear b32 $r10
000048d6: 7e 15 04 00           lcall 0x415
000048da: 7e 19 2c 00           lcall 0x2c19
000048de: b3 00 04 61           bra b32 $r0 0x4 e 0x493f
000048e2: b2 1a                 mov b32 $r10 $r1
000048e4: bd 04                 clear b32 $r0
000048e6: 8b 00 44 02           mov $r11 0x24400
000048ea: 4c 04 01              mov $r12 0x104
000048ed: bd 24                 clear b32 $r2
000048ef: 81 20 44 02           mov $r1 0x24420
000048f3: ff b2 df            B iord $r13 I[$r11+$r2*0x4]
000048f6: 8f 00 10 00           mov $r15 0x1000
000048fa: 95 c9 02              shr b32 $r9 $r12 0x2
000048fd: b6 94 02              shl b32 $r9 0x2
00004900: bc 9f 90              add b32 $r9 $r9 $r15
00004903: b3 d0 00 2d           bra b32 $r13 0x0 e 0x4930
00004907: a0 9a                 st b32 D[$r9] $r10
00004909: b6 d4 02              shl b32 $r13 0x2
0000490c: 95 df 08              shr b32 $r15 $r13 0x8
0000490f: 90 f9 01              add b32 $r9 $r15 0x1
00004912: b6 94 08              shl b32 $r9 0x8
00004915: 90 ae 01              add b32 $r14 $r10 0x1
00004918: bc 09 00              add b32 $r0 $r0 $r9
0000491b: bc ef a0              add b32 $r10 $r14 $r15
0000491e: 90 c9 04              add b32 $r9 $r12 0x4
00004921: 8f 00 10 00           mov $r15 0x1000
00004925: b6 95 02              shr b32 $r9 0x2
00004928: b6 94 02              shl b32 $r9 0x2
0000492b: bc 9f 90              add b32 $r9 $r9 $r15
0000492e: a0 9d                 st b32 D[$r9] $r13
00004930: 90 bb 04            B add b32 $r11 $r11 0x4
00004933: 90 cc 08              add b32 $r12 $r12 0x8
00004936: a6 b1                 cmp b32 $r11 $r1
00004938: f4 1b bb              bra ne 0x48f3
0000493b: 3e 98 49 00           lbra 0x4998
0000493f: b2 1a               B mov b32 $r10 $r1
00004941: bd 04                 clear b32 $r0
00004943: 8b 00 44 02           mov $r11 0x24400
00004947: 4c a4 00              mov $r12 0xa4
0000494a: bd 24                 clear b32 $r2
0000494c: 81 20 44 02           mov $r1 0x24420
00004950: ff b2 df            B iord $r13 I[$r11+$r2*0x4]
00004953: 8f 00 10 00           mov $r15 0x1000
00004957: 95 c9 02              shr b32 $r9 $r12 0x2
0000495a: b6 94 02              shl b32 $r9 0x2
0000495d: bc 9f 90              add b32 $r9 $r9 $r15
00004960: b3 d0 00 2d           bra b32 $r13 0x0 e 0x498d
00004964: a0 9a                 st b32 D[$r9] $r10
00004966: b6 d4 02              shl b32 $r13 0x2
00004969: 95 df 08              shr b32 $r15 $r13 0x8
0000496c: 90 f9 01              add b32 $r9 $r15 0x1
0000496f: b6 94 08              shl b32 $r9 0x8
00004972: 90 ae 01              add b32 $r14 $r10 0x1
00004975: bc 09 00              add b32 $r0 $r0 $r9
00004978: bc ef a0              add b32 $r10 $r14 $r15
0000497b: 90 c9 04              add b32 $r9 $r12 0x4
0000497e: 8f 00 10 00           mov $r15 0x1000
00004982: b6 95 02              shr b32 $r9 0x2
00004985: b6 94 02              shl b32 $r9 0x2
00004988: bc 9f 90              add b32 $r9 $r9 $r15
0000498b: a0 9d                 st b32 D[$r9] $r13
0000498d: 90 bb 04            B add b32 $r11 $r11 0x4
00004990: 90 cc 08              add b32 $r12 $r12 0x8
00004993: a6 b1                 cmp b32 $r11 $r1
00004995: f4 1b bb              bra ne 0x4950
00004998: 4f 00 10            B mov $r15 0x1000
0000499b: 89 00 19 02           mov $r9 0x21900
0000499f: fa 9f 00              iowr I[$r9] $r15
000049a2: b2 0a                 mov b32 $r10 $r0
000049a4: fb 21                 mpopret $r2

000049a6: 8f 04 16 00        C  mov $r15 0x1604
000049aa: bf ff                 ld b32 $r15 D[$r15]
000049ac: f4 30 cc              add $sp -0x34
000049af: f9 82                 mpush $r8
000049b1: fe 49 01              mov $r9 $sp
000049b4: 90 99 54              add b32 $r9 $r9 0x54
000049b7: b2 b8                 mov b32 $r8 $r11
000049b9: a0 9f                 st b32 D[$r9] $r15
000049bb: 4f 00 02              mov $r15 0x200
000049be: 89 00 12 02           mov $r9 0x21200
000049c2: fa 9f 00              iowr I[$r9] $r15
000049c5: 89 24 00 00           mov $r9 0x24
000049c9: bf 9a                 ld b32 $r10 D[$r9]
000049cb: 81 80 12 00           mov $r1 0x1280
000049cf: 7e 14 01 00           lcall 0x114
000049d3: 0a 01                 mov $r10 0x1
000049d5: 7e c6 29 00           lcall 0x29c6
000049d9: 0a 01                 mov $r10 0x1
000049db: b2 ab                 mov b32 $r11 $r10
000049dd: b2 ac                 mov b32 $r12 $r10
000049df: 7e f5 0c 00           lcall 0xcf5
000049e3: 7e 0c 29 00           lcall 0x290c
000049e7: bd a4                 clear b32 $r10
000049e9: 7e 88 29 00           lcall 0x2988
000049ed: 0a 01                 mov $r10 0x1
000049ef: 7e 7a 09 00           lcall 0x97a
000049f3: 89 84 12 00           mov $r9 0x1284
000049f7: a0 1a                 st b32 D[$r1] $r10
000049f9: a0 9a                 st b32 D[$r9] $r10
000049fb: 8f 00 20 02           mov $r15 0x22000
000049ff: bd 94                 clear b32 $r9
00004a01: ff f9 ff              iord $r15 I[$r15+$r9*0x4]
00004a04: 80 00 10 00           mov $r0 0x1000
00004a08: 98 09 01              ld b32 $r9 D[$r0+0x4]
00004a0b: bd a4                 clear b32 $r10
00004a0d: 0b 03                 mov $r11 0x3
00004a0f: 0c 01                 mov $r12 0x1
00004a11: f0 94 20              and $r9 0x20
00004a14: fd f9 05              or $r15 $r9
00004a17: b5 0f 01              st b32 D[$r0+0x4] $r15
00004a1a: 7e 7c 48 00           lcall 0x487c
00004a1e: bf 1f                 ld b32 $r15 D[$r1]
00004a20: 89 88 12 00           mov $r9 0x1288
00004a24: 8e 00 80 02           mov $r14 0x28000
00004a28: a0 9a                 st b32 D[$r9] $r10
00004a2a: bc af a0              add b32 $r10 $r10 $r15
00004a2d: 8f 28 80 02           mov $r15 0x28028
00004a31: a0 0a                 st b32 D[$r0] $r10
00004a33: dd 34 80 fd ff      B mov $r13 0xfffd8034
00004a38: bc ed 90              add b32 $r9 $r14 $r13
00004a3b: bf 99                 ld b32 $r9 D[$r9]
00004a3d: f0 94 07              and $r9 0x7
00004a40: b6 94 04              shl b32 $r9 0x4
00004a43: f0 95 08              or $r9 0x8
00004a46: fa e9 00              iowr I[$r14] $r9
00004a49: 90 ee 04              add b32 $r14 $r14 0x4
00004a4c: a6 ef                 cmp b32 $r14 $r15
00004a4e: f4 1b e5              bra ne 0x4a33
00004a51: 80 a0 14 00           mov $r0 0x14a0
00004a55: bf 09                 ld b32 $r9 D[$r0]
00004a57: 81 80 12 00           mov $r1 0x1280
00004a5b: b2 06                 mov b32 $r6 $r0
00004a5d: b2 15                 mov b32 $r5 $r1
00004a5f: b6 94 09              shl b32 $r9 0x9
00004a62: b8 99 00 04 00        add b32 $r9 $r9 0x400
00004a67: bc 9a 90              add b32 $r9 $r9 $r10
00004a6a: a0 19                 st b32 D[$r1] $r9
00004a6c: 7e 75 21 00           lcall 0x2175
00004a70: bf 09                 ld b32 $r9 D[$r0]
00004a72: 8f 84 12 00           mov $r15 0x1284
00004a76: bf ff                 ld b32 $r15 D[$r15]
00004a78: 8e 00 10 00           mov $r14 0x1000
00004a7c: 90 99 02              add b32 $r9 $r9 0x2
00004a7f: b6 94 01              shl b32 $r9 0x1
00004a82: b5 ef 04              st b32 D[$r14+0x10] $r15
00004a85: f1 94 fe ff           and $r9 0xfffe
00004a89: c7 ff e8              extr $r15 $r15 0x8:0xf
00004a8c: b6 f4 10              shl b32 $r15 0x10
00004a8f: fd 9f 05              or $r9 $r15
00004a92: b5 e9 03              st b32 D[$r14+0xc] $r9
00004a95: 89 88 12 00           mov $r9 0x1288
00004a99: bf 99                 ld b32 $r9 D[$r9]
00004a9b: 8a 00 a8 41           mov $r10 0x41a800
00004a9f: bd b4                 clear b32 $r11
00004aa1: bf 13                 ld b32 $r3 D[$r1]
00004aa3: b5 e9 05              st b32 D[$r14+0x14] $r9
00004aa6: 7e 37 02 00           lcall 0x237
00004aaa: 0a 10                 mov $r10 0x10
00004aac: bd b4                 clear b32 $r11
00004aae: fe 44 01              mov $r4 $sp
00004ab1: 7e c5 0c 00           lcall 0xcc5
00004ab5: 90 44 24              add b32 $r4 $r4 0x24
00004ab8: 7e fc 23 00           lcall 0x23fc
00004abc: bd 24                 clear b32 $r2
00004abe: b2 41                 mov b32 $r1 $r4
00004ac0: 80 00 28 50           mov $r0 0x502800
00004ac4: 3e e2 4a 00           lbra 0x4ae2
00004ac8: b2 0a               B mov b32 $r10 $r0
00004aca: 7e 97 02 00           lcall 0x297
00004ace: bf 59                 ld b32 $r9 D[$r5]
00004ad0: a0 1a                 st b32 D[$r1] $r10
00004ad2: 90 22 01              add b32 $r2 $r2 0x1
00004ad5: b8 00 00 80 00        add b32 $r0 $r0 0x8000
00004ada: bc a9 a0              add b32 $r10 $r10 $r9
00004add: 90 11 04              add b32 $r1 $r1 0x4
00004ae0: a0 5a                 st b32 D[$r5] $r10
00004ae2: bf 69               B ld b32 $r9 D[$r6]
00004ae4: 8d 80 12 00           mov $r13 0x1280
00004ae8: a6 29                 cmp b32 $r2 $r9
00004aea: f4 08 de              bra b 0x4ac8
00004aed: bf de                 ld b32 $r14 D[$r13]
00004aef: bc 99 f0              add b32 $r15 $r9 $r9
00004af2: bc f9 f0              add b32 $r15 $r15 $r9
00004af5: 90 ff 01              add b32 $r15 $r15 0x1
00004af8: 94 f9 08              shl b32 $r9 $r15 0x8
00004afb: bc 9e 90              add b32 $r9 $r9 $r14
00004afe: a0 d9                 st b32 D[$r13] $r9
00004b00: 89 00 00 01           mov $r9 0x10000
00004b04: b6 e5 08              shr b32 $r14 0x8
00004b07: f0 f4 ff              and $r15 0xff
00004b0a: e4 ed ff ff           and $r13 $r14 0xffff
00004b0e: b6 f4 10              shl b32 $r15 0x10
00004b11: fd fd 05              or $r15 $r13
00004b14: fd d9 05              or $r13 $r9
00004b17: 89 00 10 00           mov $r9 0x1000
00004b1b: b5 9d 3c              st b32 D[$r9+0xf0] $r13
00004b1e: 89 00 0e 00           mov $r9 0xe00
00004b22: 80 a0 12 00           mov $r0 0x12a0
00004b26: 8a 00 a8 41           mov $r10 0x41a800
00004b2a: a0 0e                 st b32 D[$r0] $r14
00004b2c: bd b4                 clear b32 $r11
00004b2e: b5 9f 3b              st b32 D[$r9+0xec] $r15
00004b31: 7e 37 02 00           lcall 0x237
00004b35: b2 07                 mov b32 $r7 $r0
00004b37: 8a 00 05 01           mov $r10 0x10500
00004b3b: bd b4                 clear b32 $r11
00004b3d: b6 35 08              shr b32 $r3 0x8
00004b40: 7e 10 00 00           lcall 0x10
00004b44: bd 14                 clear b32 $r1
00004b46: bd 24                 clear b32 $r2
00004b48: 80 10 28 50           mov $r0 0x502810
00004b4c: 86 a0 14 00           mov $r6 0x14a0
00004b50: 85 00 00 03           mov $r5 0x30000
00004b54: 3e 99 4b 00           lbra 0x4b99
00004b58: bf 7b               B ld b32 $r11 D[$r7]
00004b5a: b2 0a                 mov b32 $r10 $r0
00004b5c: 90 11 01              add b32 $r1 $r1 0x1
00004b5f: 90 bb 01              add b32 $r11 $r11 0x1
00004b62: bc b2 b0              add b32 $r11 $r11 $r2
00004b65: f1 b4 ff ff           and $r11 0xffff
00004b69: fd b5 05              or $r11 $r5
00004b6c: 7e 37 02 00           lcall 0x237
00004b70: b8 0a 10 03 02        sub b32 $r10 $r0 0x310
00004b75: b2 3b                 mov b32 $r11 $r3
00004b77: 7e 37 02 00           lcall 0x237
00004b7b: b8 0a 0c 03 02        sub b32 $r10 $r0 0x30c
00004b80: 0b 14                 mov $r11 0x14
00004b82: 7e 37 02 00           lcall 0x237
00004b86: bf 49                 ld b32 $r9 D[$r4]
00004b88: 90 22 03              add b32 $r2 $r2 0x3
00004b8b: b8 00 00 80 00        add b32 $r0 $r0 0x8000
00004b90: 90 44 04              add b32 $r4 $r4 0x4
00004b93: b6 95 08              shr b32 $r9 0x8
00004b96: bc 39 30              add b32 $r3 $r3 $r9
00004b99: bf 69               B ld b32 $r9 D[$r6]
00004b9b: a6 19                 cmp b32 $r1 $r9
00004b9d: f4 08 bb              bra b 0x4b58
00004ba0: 7e fc 23 00           lcall 0x23fc
00004ba4: 8f 80 12 00           mov $r15 0x1280
00004ba8: bf f9                 ld b32 $r9 D[$r15]
00004baa: a6 89                 cmp b32 $r8 $r9
00004bac: f4 0d 05              bra be 0x4bb1
00004baf: a0 f8                 st b32 D[$r15] $r8
00004bb1: 89 80 12 00         B mov $r9 0x1280
00004bb5: bf 99                 ld b32 $r9 D[$r9]
00004bb7: 8f 00 0e 00           mov $r15 0xe00
00004bbb: 0a 02                 mov $r10 0x2
00004bbd: b5 f9 01              st b32 D[$r15+0x4] $r9
00004bc0: 89 a0 14 00           mov $r9 0x14a0
00004bc4: bf 99                 ld b32 $r9 D[$r9]
00004bc6: b5 f9 02              st b32 D[$r15+0x8] $r9
00004bc9: 89 a4 14 00           mov $r9 0x14a4
00004bcd: bf 99                 ld b32 $r9 D[$r9]
00004bcf: b5 f9 0d              st b32 D[$r15+0x34] $r9
00004bd2: 7e 5b 04 00           lcall 0x45b
00004bd6: bd a4                 clear b32 $r10
00004bd8: 7e c6 29 00           lcall 0x29c6
00004bdc: 0a 01                 mov $r10 0x1
00004bde: b2 ab                 mov b32 $r11 $r10
00004be0: b2 ac                 mov b32 $r12 $r10
00004be2: 7e 7b 0c 00           lcall 0xc7b
00004be6: 7e 0c 29 00           lcall 0x290c
00004bea: bd a4                 clear b32 $r10
00004bec: 7e 88 29 00           lcall 0x2988
00004bf0: bd f4                 clear b32 $r15
00004bf2: 89 00 0c 01           mov $r9 0x10c00
00004bf6: fa 9f 00              iowr I[$r9] $r15
00004bf9: 89 80 12 00           mov $r9 0x1280
00004bfd: bf 9f                 ld b32 $r15 D[$r9]
00004bff: 89 00 00 02           mov $r9 0x20000
00004c03: fa 9f 00              iowr I[$r9] $r15
00004c06: 4f 00 02              mov $r15 0x200
00004c09: b8 99 00 18 00        add b32 $r9 $r9 0x1800
00004c0e: fa 9f 00              iowr I[$r9] $r15
00004c11: fe 49 01              mov $r9 $sp
00004c14: 90 99 54              add b32 $r9 $r9 0x54
00004c17: bf 9f                 ld b32 $r15 D[$r9]
00004c19: 89 04 16 00           mov $r9 0x1604
00004c1d: bf 99                 ld b32 $r9 D[$r9]
00004c1f: a6 f9                 cmp b32 $r15 $r9
00004c21: f4 0b 07              bra e 0x4c28
00004c24: 7e 47 07 00           lcall 0x747
00004c28: fb 85 34            B mpopaddret $r8 0x34

00004c2b: 8f 04 16 00        C  mov $r15 0x1604
00004c2f: bf ff                 ld b32 $r15 D[$r15]
00004c31: f4 30 cc              add $sp -0x34
00004c34: f9 72                 mpush $r7
00004c36: fe 49 01              mov $r9 $sp
00004c39: 90 99 50              add b32 $r9 $r9 0x50
00004c3c: b2 b7                 mov b32 $r7 $r11
00004c3e: a0 9f                 st b32 D[$r9] $r15
00004c40: 0f 08                 mov $r15 0x8
00004c42: 89 00 14 02           mov $r9 0x21400
00004c46: fa 9f 00              iowr I[$r9] $r15
00004c49: 89 80 12 00           mov $r9 0x1280
00004c4d: bf 9f                 ld b32 $r15 D[$r9]
00004c4f: 89 24 00 00           mov $r9 0x24
00004c53: bf 9a                 ld b32 $r10 D[$r9]
00004c55: 82 9c 12 00           mov $r2 0x129c
00004c59: b8 ff 00 10 00        add b32 $r15 $r15 0x1000
00004c5e: a0 2f                 st b32 D[$r2] $r15
00004c60: 7e 14 01 00           lcall 0x114
00004c64: bd 14                 clear b32 $r1
00004c66: 0a 01                 mov $r10 0x1
00004c68: a0 21                 st b32 D[$r2] $r1
00004c6a: 7e c6 29 00           lcall 0x29c6
00004c6e: 0a 01                 mov $r10 0x1
00004c70: b2 ab                 mov b32 $r11 $r10
00004c72: b2 ac                 mov b32 $r12 $r10
00004c74: 7e f5 0c 00           lcall 0xcf5
00004c78: 0b 04                 mov $r11 0x4
00004c7a: 0c 01                 mov $r12 0x1
00004c7c: a0 21                 st b32 D[$r2] $r1
00004c7e: bd a4                 clear b32 $r10
00004c80: 7e 7c 48 00           lcall 0x487c
00004c84: 89 b4 12 00           mov $r9 0x12b4
00004c88: b2 a0                 mov b32 $r0 $r10
00004c8a: a0 91                 st b32 D[$r9] $r1
00004c8c: 0a 02                 mov $r10 0x2
00004c8e: 7e 5b 04 00           lcall 0x45b
00004c92: bf 29                 ld b32 $r9 D[$r2]
00004c94: 8f 00 80 02           mov $r15 0x28000
00004c98: 8e 28 80 02           mov $r14 0x28028
00004c9c: bc 09 00              add b32 $r0 $r0 $r9
00004c9f: 89 00 10 00           mov $r9 0x1000
00004ca3: a0 20                 st b32 D[$r2] $r0
00004ca5: b5 90 25              st b32 D[$r9+0x94] $r0
00004ca8: dd 34 80 fd ff      B mov $r13 0xfffd8034
00004cad: bc fd 90              add b32 $r9 $r15 $r13
00004cb0: bf 99                 ld b32 $r9 D[$r9]
00004cb2: f0 94 07              and $r9 0x7
00004cb5: b6 94 04              shl b32 $r9 0x4
00004cb8: f0 95 08              or $r9 0x8
00004cbb: fa f9 00              iowr I[$r15] $r9
00004cbe: 90 ff 04              add b32 $r15 $r15 0x4
00004cc1: a6 fe                 cmp b32 $r15 $r14
00004cc3: f4 1b e5              bra ne 0x4ca8
00004cc6: 8a 00 a8 41           mov $r10 0x41a800
00004cca: bd b4                 clear b32 $r11
00004ccc: 7e 37 02 00           lcall 0x237
00004cd0: 0a 1a                 mov $r10 0x1a
00004cd2: bd b4                 clear b32 $r11
00004cd4: 7e c5 0c 00           lcall 0xcc5
00004cd8: 7e fc 23 00           lcall 0x23fc
00004cdc: 89 9c 12 00           mov $r9 0x129c
00004ce0: fe 4a 01              mov $r10 $sp
00004ce3: b2 96                 mov b32 $r6 $r9
00004ce5: 90 aa 20              add b32 $r10 $r10 0x20
00004ce8: bf 94                 ld b32 $r4 D[$r9]
00004cea: b2 a3                 mov b32 $r3 $r10
00004cec: bd b4                 clear b32 $r11
00004cee: 0c 30                 mov $r12 0x30
00004cf0: b2 32                 mov b32 $r2 $r3
00004cf2: 7e e8 77 00           lcall 0x77e8
00004cf6: bd 14                 clear b32 $r1
00004cf8: 80 00 28 50           mov $r0 0x502800
00004cfc: 85 a0 14 00           mov $r5 0x14a0
00004d00: 3e 1e 4d 00           lbra 0x4d1e
00004d04: b2 0a               B mov b32 $r10 $r0
00004d06: 7e 97 02 00           lcall 0x297
00004d0a: bf 69                 ld b32 $r9 D[$r6]
00004d0c: a0 2a                 st b32 D[$r2] $r10
00004d0e: 90 11 01              add b32 $r1 $r1 0x1
00004d11: b8 00 00 80 00        add b32 $r0 $r0 0x8000
00004d16: bc a9 a0              add b32 $r10 $r10 $r9
00004d19: 90 22 04              add b32 $r2 $r2 0x4
00004d1c: a0 6a                 st b32 D[$r6] $r10
00004d1e: bf 59               B ld b32 $r9 D[$r5]
00004d20: a6 19                 cmp b32 $r1 $r9
00004d22: f4 08 e2              bra b 0x4d04
00004d25: 8a 00 a8 41           mov $r10 0x41a800
00004d29: bd b4                 clear b32 $r11
00004d2b: 7e 37 02 00           lcall 0x237
00004d2f: 95 42 08              shr b32 $r2 $r4 0x8
00004d32: 8a 00 05 01           mov $r10 0x10500
00004d36: bd b4                 clear b32 $r11
00004d38: bd 14                 clear b32 $r1
00004d3a: 7e 10 00 00           lcall 0x10
00004d3e: 80 00 25 50           mov $r0 0x502500
00004d42: 84 a0 14 00           mov $r4 0x14a0
00004d46: 3e 6e 4d 00           lbra 0x4d6e
00004d4a: b2 0a               B mov b32 $r10 $r0
00004d4c: b2 2b                 mov b32 $r11 $r2
00004d4e: 7e 37 02 00           lcall 0x237
00004d52: 90 0a 04              add b32 $r10 $r0 0x4
00004d55: 0b 1d                 mov $r11 0x1d
00004d57: 7e 37 02 00           lcall 0x237
00004d5b: bf 39                 ld b32 $r9 D[$r3]
00004d5d: 90 11 01              add b32 $r1 $r1 0x1
00004d60: b8 00 00 80 00        add b32 $r0 $r0 0x8000
00004d65: 90 33 04              add b32 $r3 $r3 0x4
00004d68: b6 95 08              shr b32 $r9 0x8
00004d6b: bc 29 20              add b32 $r2 $r2 $r9
00004d6e: bf 49               B ld b32 $r9 D[$r4]
00004d70: a6 19                 cmp b32 $r1 $r9
00004d72: f4 08 d8              bra b 0x4d4a
00004d75: 8f 9c 12 00           mov $r15 0x129c
00004d79: bf f9                 ld b32 $r9 D[$r15]
00004d7b: a6 79                 cmp b32 $r7 $r9
00004d7d: f4 0d 05              bra be 0x4d82
00004d80: a0 f7                 st b32 D[$r15] $r7
00004d82: 8f 9c 12 00         B mov $r15 0x129c
00004d86: bf ff                 ld b32 $r15 D[$r15]
00004d88: 89 00 0e 00           mov $r9 0xe00
00004d8c: 0a 01                 mov $r10 0x1
00004d8e: b2 ab                 mov b32 $r11 $r10
00004d90: b2 ac                 mov b32 $r12 $r10
00004d92: b5 9f 1b              st b32 D[$r9+0x6c] $r15
00004d95: 7e 7b 0c 00           lcall 0xc7b
00004d99: bd a4                 clear b32 $r10
00004d9b: 7e 88 29 00           lcall 0x2988
00004d9f: bd f4                 clear b32 $r15
00004da1: 89 00 0c 01           mov $r9 0x10c00
00004da5: fa 9f 00              iowr I[$r9] $r15
00004da8: 89 9c 12 00           mov $r9 0x129c
00004dac: bf 9f                 ld b32 $r15 D[$r9]
00004dae: 89 00 00 02           mov $r9 0x20000
00004db2: fa 9f 00              iowr I[$r9] $r15
00004db5: 0f 08                 mov $r15 0x8
00004db7: b8 99 00 1a 00        add b32 $r9 $r9 0x1a00
00004dbc: fa 9f 00              iowr I[$r9] $r15
00004dbf: fe 49 01              mov $r9 $sp
00004dc2: 90 99 50              add b32 $r9 $r9 0x50
00004dc5: bf 9f                 ld b32 $r15 D[$r9]
00004dc7: 89 04 16 00           mov $r9 0x1604
00004dcb: bf 99                 ld b32 $r9 D[$r9]
00004dcd: a6 f9                 cmp b32 $r15 $r9
00004dcf: f4 0b 07              bra e 0x4dd6
00004dd2: 7e 47 07 00           lcall 0x747
00004dd6: fb 75 34            B mpopaddret $r7 0x34

00004dd9: f4 30 f8           C  add $sp -0x8
00004ddc: bd f4                 clear b32 $r15
00004dde: f9 82                 mpush $r8
00004de0: 89 00 de 02           mov $r9 0x2de00
00004de4: f4 30 f4              add $sp -0xc
00004de7: b2 b5                 mov b32 $r5 $r11
00004de9: b2 c7                 mov b32 $r7 $r12
00004deb: ff 9f ef              iord $r14 I[$r9+$r15*0x4]
00004dee: 0f 20                 mov $r15 0x20
00004df0: 89 00 12 02           mov $r9 0x21200
00004df4: fa 9f 00              iowr I[$r9] $r15
00004df7: 95 b9 1f              shr b32 $r9 $r11 0x1f
00004dfa: b3 9d 01 66 04        bra b32 $r9 0x1 ne 0x5260
00004dff: d9 ff ff ff 0f        mov $r9 0xfffffff
00004e04: ff b9 14              and $r1 $r11 $r9
00004e07: c7 b9 3c              extr $r9 $r11 0x1c:0x1d
00004e0a: b0 91 0d              st b32 D[$sp+0x34] $r9
00004e0d: b3 c4 02 1c           bra b32 $r12 0x2 ne 0x4e29
00004e11: d9 ff ff ff 3f        mov $r9 0x3fffffff
00004e16: 8f 00 2e 02           mov $r15 0x22e00
00004e1a: ff b9 94              and $r9 $r11 $r9
00004e1d: fa f9 00              iowr I[$r15] $r9
00004e20: 0f 03                 mov $r15 0x3
00004e22: 89 00 2f 02           mov $r9 0x22f00
00004e26: fa 9f 00              iowr I[$r9] $r15
00004e29: c4 e9 3f            B and $r9 $r14 0x3f
00004e2c: 8a 00 8e 02           mov $r10 0x28e00
00004e30: 94 96 18              shl b32 $r6 $r9 0x18
00004e33: bd b4                 clear b32 $r11
00004e35: 7e 10 00 00           lcall 0x10
00004e39: 8a 00 8f 02           mov $r10 0x28f00
00004e3d: c5 68 40              or $r8 $r6 0x40
00004e40: b2 8b                 mov b32 $r11 $r8
00004e42: 7e 10 00 00           lcall 0x10
00004e46: 8a 00 89 02           mov $r10 0x28900
00004e4a: bd b4                 clear b32 $r11
00004e4c: 7e 10 00 00           lcall 0x10
00004e50: d0 00 00 00 90        mov $r0 0x90000000
00004e55: 89 00 c1 02           mov $r9 0x2c100
00004e59: ff 10 05              or $r0 $r1 $r0
00004e5c: fa 90 00              iowr I[$r9] $r0
00004e5f: 8a 00 83 02           mov $r10 0x28300
00004e63: b2 0b                 mov b32 $r11 $r0
00004e65: 7e 10 00 00           lcall 0x10
00004e69: 8a 00 84 02           mov $r10 0x28400
00004e6d: 0b 07                 mov $r11 0x7
00004e6f: 7e 10 00 00           lcall 0x10
00004e73: 7e a0 41 00           lcall 0x41a0
00004e77: b2 8c                 mov b32 $r12 $r8
00004e79: bd a4                 clear b32 $r10
00004e7b: bd b4                 clear b32 $r11
00004e7d: 7e b9 32 00           lcall 0x32b9
00004e81: b4 e0 0d              ld b32 $r14 D[$sp+0x34]
00004e84: 09 01                 mov $r9 0x1
00004e86: b0 91 01              st b32 D[$sp+0x4] $r9
00004e89: b0 91 00              st b32 D[$sp] $r9
00004e8c: 09 02                 mov $r9 0x2
00004e8e: b6 14 04              shl b32 $r1 0x4
00004e91: b0 91 02              st b32 D[$sp+0x8] $r9
00004e94: b2 1a                 mov b32 $r10 $r1
00004e96: b0 11 0c              st b32 D[$sp+0x30] $r1
00004e99: 0c 06                 mov $r12 0x6
00004e9b: 8d 00 0a 00           mov $r13 0xa00
00004e9f: 4b 00 02              mov $r11 0x200
00004ea2: 7e e1 2d 00           lcall 0x2de1
00004ea6: 89 00 0a 00           mov $r9 0xa00
00004eaa: 98 9e 04              ld b32 $r14 D[$r9+0x10]
00004ead: bf 9d                 ld b32 $r13 D[$r9]
00004eaf: 98 9c 05              ld b32 $r12 D[$r9+0x14]
00004eb2: 98 9a 06              ld b32 $r10 D[$r9+0x18]
00004eb5: 98 9f 01              ld b32 $r15 D[$r9+0x4]
00004eb8: 49 00 f0              mov $r9 -0x1000
00004ebb: fd d9 04              and $r13 $r9
00004ebe: fd e9 04              and $r14 $r9
00004ec1: 89 e0 12 00           mov $r9 0x12e0
00004ec5: b6 c4 18              shl b32 $r12 0x18
00004ec8: b6 e5 08              shr b32 $r14 0x8
00004ecb: fd ec 05              or $r14 $r12
00004ece: a0 9e                 st b32 D[$r9] $r14
00004ed0: 89 e4 12 00           mov $r9 0x12e4
00004ed4: bd e4                 clear b32 $r14
00004ed6: a0 9e                 st b32 D[$r9] $r14
00004ed8: 89 48 14 00           mov $r9 0x1448
00004edc: b6 f4 18              shl b32 $r15 0x18
00004edf: b6 d5 08              shr b32 $r13 0x8
00004ee2: fd df 05              or $r13 $r15
00004ee5: a0 9d                 st b32 D[$r9] $r13
00004ee7: 89 ec 12 00           mov $r9 0x12ec
00004eeb: 90 ab 40              add b32 $r11 $r10 0x40
00004eee: a0 9a                 st b32 D[$r9] $r10
00004ef0: f0 b4 ff              and $r11 0xff
00004ef3: 89 e8 12 00           mov $r9 0x12e8
00004ef7: c4 af 3f              and $r15 $r10 0x3f
00004efa: b6 f4 10              shl b32 $r15 0x10
00004efd: fd fb 05              or $r15 $r11
00004f00: fd f6 05              or $r15 $r6
00004f03: 8a 00 8e 02           mov $r10 0x28e00
00004f07: a0 9f                 st b32 D[$r9] $r15
00004f09: bd b4                 clear b32 $r11
00004f0b: 7e 10 00 00           lcall 0x10
00004f0f: 8a 00 89 02           mov $r10 0x28900
00004f13: bd b4                 clear b32 $r11
00004f15: 7e 10 00 00           lcall 0x10
00004f19: 89 00 c1 02           mov $r9 0x2c100
00004f1d: fa 95 00              iowr I[$r9] $r5
00004f20: 8a 00 83 02           mov $r10 0x28300
00004f24: b2 5b                 mov b32 $r11 $r5
00004f26: 80 98 0a 00           mov $r0 0xa98
00004f2a: 7e 10 00 00           lcall 0x10
00004f2e: bd 34                 clear b32 $r3
00004f30: 04 20                 mov $r4 0x20
00004f32: 3e 8b 4f 00           lbra 0x4f8b
00004f36: bd 24               B clear b32 $r2
00004f38: bf 0f               B ld b32 $r15 D[$r0]
00004f3a: 09 01                 mov $r9 0x1
00004f3c: bb 92 04              shl b32 $r9 $r2
00004f3f: fd 9f 04              and $r9 $r15
00004f42: f4 0b 35              bra e 0x4f77
00004f45: c4 19 3f              and $r9 $r1 0x3f
00004f48: b6 94 10              shl b32 $r9 0x10
00004f4b: fd 96 05              or $r9 $r6
00004f4e: 90 1b 40              add b32 $r11 $r1 0x40
00004f51: 8a 00 8f 02           mov $r10 0x28f00
00004f55: f0 b4 ff              and $r11 0xff
00004f58: ff 9b b5              or $r11 $r9 $r11
00004f5b: 7e 10 00 00           lcall 0x10
00004f5f: 8a 00 84 02           mov $r10 0x28400
00004f63: 0b 07                 mov $r11 0x7
00004f65: 7e 10 00 00           lcall 0x10
00004f69: 7e a0 41 00           lcall 0x41a0
00004f6d: 89 00 c0 02           mov $r9 0x2c000
00004f71: fa 95 00              iowr I[$r9] $r5
00004f74: 90 33 01              add b32 $r3 $r3 0x1
00004f77: 90 11 01            B add b32 $r1 $r1 0x1
00004f7a: 90 22 01              add b32 $r2 $r2 0x1
00004f7d: b3 24 20 bb           bra b32 $r2 0x20 ne 0x4f38
00004f81: 90 44 20            B add b32 $r4 $r4 0x20
00004f84: 90 00 04              add b32 $r0 $r0 0x4
00004f87: b3 40 60 53           bra b32 $r4 0x60 e 0x4fda
00004f8b: 92 41 20            B sub b32 $r1 $r4 0x20
00004f8e: b3 74 04 a8           bra b32 $r7 0x4 ne 0x4f36
00004f92: bd 24                 clear b32 $r2
00004f94: bf 0f               B ld b32 $r15 D[$r0]
00004f96: 09 01                 mov $r9 0x1
00004f98: bb 92 04              shl b32 $r9 $r2
00004f9b: 90 22 01              add b32 $r2 $r2 0x1
00004f9e: fd 9f 04              and $r9 $r15
00004fa1: f4 0b 2e              bra e 0x4fcf
00004fa4: c4 19 3f              and $r9 $r1 0x3f
00004fa7: b6 94 10              shl b32 $r9 0x10
00004faa: fd 96 05              or $r9 $r6
00004fad: 8a 00 8f 02           mov $r10 0x28f00
00004fb1: 90 1b 40              add b32 $r11 $r1 0x40
00004fb4: f0 b4 ff              and $r11 0xff
00004fb7: ff 9b b5              or $r11 $r9 $r11
00004fba: 7e 10 00 00           lcall 0x10
00004fbe: 8a 00 84 02           mov $r10 0x28400
00004fc2: 0b 07                 mov $r11 0x7
00004fc4: 90 33 01              add b32 $r3 $r3 0x1
00004fc7: 7e 10 00 00           lcall 0x10
00004fcb: 7e a0 41 00           lcall 0x41a0
00004fcf: 90 11 01            B add b32 $r1 $r1 0x1
00004fd2: b3 24 20 c2           bra b32 $r2 0x20 ne 0x4f94
00004fd6: 3e 81 4f 00           lbra 0x4f81
00004fda: b3 34 00 75         B bra b32 $r3 0x0 ne 0x504f
00004fde: b3 74 04 39           bra b32 $r7 0x4 ne 0x5017
00004fe2: bd 14                 clear b32 $r1
00004fe4: c4 19 3f            B and $r9 $r1 0x3f
00004fe7: b6 94 10              shl b32 $r9 0x10
00004fea: fd 96 05              or $r9 $r6
00004fed: 90 1b 40              add b32 $r11 $r1 0x40
00004ff0: 8a 00 8f 02           mov $r10 0x28f00
00004ff4: f0 b4 ff              and $r11 0xff
00004ff7: ff 9b b5              or $r11 $r9 $r11
00004ffa: 7e 10 00 00           lcall 0x10
00004ffe: 8a 00 84 02           mov $r10 0x28400
00005002: 0b 07                 mov $r11 0x7
00005004: 90 11 01              add b32 $r1 $r1 0x1
00005007: 7e 10 00 00           lcall 0x10
0000500b: 7e a0 41 00           lcall 0x41a0
0000500f: b3 14 40 d5           bra b32 $r1 0x40 ne 0x4fe4
00005013: 3e 4f 50 00           lbra 0x504f
00005017: bd 14               B clear b32 $r1
00005019: 82 00 c0 02           mov $r2 0x2c000
0000501d: c4 19 3f            B and $r9 $r1 0x3f
00005020: b6 94 10              shl b32 $r9 0x10
00005023: fd 96 05              or $r9 $r6
00005026: 90 1b 40              add b32 $r11 $r1 0x40
00005029: 8a 00 8f 02           mov $r10 0x28f00
0000502d: f0 b4 ff              and $r11 0xff
00005030: ff 9b b5              or $r11 $r9 $r11
00005033: 7e 10 00 00           lcall 0x10
00005037: 8a 00 84 02           mov $r10 0x28400
0000503b: 0b 07                 mov $r11 0x7
0000503d: 7e 10 00 00           lcall 0x10
00005041: 7e a0 41 00           lcall 0x41a0
00005045: fa 25 00              iowr I[$r2] $r5
00005048: 90 11 01              add b32 $r1 $r1 0x1
0000504b: b3 14 40 d2           bra b32 $r1 0x40 ne 0x501d
0000504f: 7e cf 31 00         B lcall 0x31cf
00005053: 8a 00 8e 02           mov $r10 0x28e00
00005057: bd b4                 clear b32 $r11
00005059: 7e 10 00 00           lcall 0x10
0000505d: b3 7d 01 03 02        bra b32 $r7 0x1 ne 0x5260
00005062: 7e 8f 47 00           lcall 0x478f
00005066: 89 f0 13 00           mov $r9 0x13f0
0000506a: bf 9f                 ld b32 $r15 D[$r9]
0000506c: 89 c0 13 00           mov $r9 0x13c0
00005070: a0 9a                 st b32 D[$r9] $r10
00005072: b3 f0 00 0c           bra b32 $r15 0x0 e 0x507e
00005076: bd f4                 clear b32 $r15
00005078: 89 f4 13 00           mov $r9 0x13f4
0000507c: a0 9f                 st b32 D[$r9] $r15
0000507e: 8f c0 13 00         B mov $r15 0x13c0
00005082: bf ff                 ld b32 $r15 D[$r15]
00005084: 89 00 0e 00           mov $r9 0xe00
00005088: 0a 01                 mov $r10 0x1
0000508a: 81 00 0a 00           mov $r1 0xa00
0000508e: b5 9f 3c              st b32 D[$r9+0xf0] $r15
00005091: 7e 70 10 00           lcall 0x1070
00005095: b2 8c                 mov b32 $r12 $r8
00005097: bd a4                 clear b32 $r10
00005099: bd b4                 clear b32 $r11
0000509b: 7e b9 32 00           lcall 0x32b9
0000509f: b4 e0 0d              ld b32 $r14 D[$sp+0x34]
000050a2: b4 a0 0c              ld b32 $r10 D[$sp+0x30]
000050a5: 03 01                 mov $r3 0x1
000050a7: 02 02                 mov $r2 0x2
000050a9: b2 1d                 mov b32 $r13 $r1
000050ab: b0 31 00              st b32 D[$sp] $r3
000050ae: b0 31 01              st b32 D[$sp+0x4] $r3
000050b1: b0 21 02              st b32 D[$sp+0x8] $r2
000050b4: 4b 00 02              mov $r11 0x200
000050b7: 0c 06                 mov $r12 0x6
000050b9: 7e e1 2d 00           lcall 0x2de1
000050bd: 98 1e 04              ld b32 $r14 D[$r1+0x10]
000050c0: bf 1d                 ld b32 $r13 D[$r1]
000050c2: 98 1b 05              ld b32 $r11 D[$r1+0x14]
000050c5: 98 1f 06              ld b32 $r15 D[$r1+0x18]
000050c8: 98 1c 01              ld b32 $r12 D[$r1+0x4]
000050cb: 49 00 f0              mov $r9 -0x1000
000050ce: fd d9 04              and $r13 $r9
000050d1: fd e9 04              and $r14 $r9
000050d4: 89 e0 12 00           mov $r9 0x12e0
000050d8: b6 b4 18              shl b32 $r11 0x18
000050db: b6 e5 08              shr b32 $r14 0x8
000050de: fd eb 05              or $r14 $r11
000050e1: a0 9e                 st b32 D[$r9] $r14
000050e3: 89 e4 12 00           mov $r9 0x12e4
000050e7: b2 ea                 mov b32 $r10 $r14
000050e9: bd e4                 clear b32 $r14
000050eb: a0 9e                 st b32 D[$r9] $r14
000050ed: 89 48 14 00           mov $r9 0x1448
000050f1: 84 ec 12 00           mov $r4 0x12ec
000050f5: 90 f0 40              add b32 $r0 $r15 0x40
000050f8: a0 4f                 st b32 D[$r4] $r15
000050fa: f0 04 ff              and $r0 0xff
000050fd: b6 c4 18              shl b32 $r12 0x18
00005100: b6 d5 08              shr b32 $r13 0x8
00005103: f0 f4 3f              and $r15 0x3f
00005106: fd dc 05              or $r13 $r12
00005109: b6 f4 10              shl b32 $r15 0x10
0000510c: a0 9d                 st b32 D[$r9] $r13
0000510e: fd f0 05              or $r15 $r0
00005111: 89 e8 12 00           mov $r9 0x12e8
00005115: fd f6 05              or $r15 $r6
00005118: bd b4                 clear b32 $r11
0000511a: b2 fc                 mov b32 $r12 $r15
0000511c: a0 9f                 st b32 D[$r9] $r15
0000511e: 7e b9 32 00           lcall 0x32b9
00005122: b2 1d                 mov b32 $r13 $r1
00005124: bd a4                 clear b32 $r10
00005126: bd b4                 clear b32 $r11
00005128: 0c 06                 mov $r12 0x6
0000512a: bd e4                 clear b32 $r14
0000512c: b0 31 01              st b32 D[$sp+0x4] $r3
0000512f: b0 21 02              st b32 D[$sp+0x8] $r2
00005132: b0 21 00              st b32 D[$sp] $r2
00005135: 7e e1 2d 00           lcall 0x2de1
00005139: 7e cf 31 00           lcall 0x31cf
0000513d: 98 19 1f              ld b32 $r9 D[$r1+0x7c]
00005140: 98 1f 1e              ld b32 $r15 D[$r1+0x78]
00005143: bf 4e                 ld b32 $r14 D[$r4]
00005145: b6 95 08              shr b32 $r9 0x8
00005148: e7 fc 08 01           extr $r12 $r15 0x8:0x10
0000514c: b6 f4 18              shl b32 $r15 0x18
0000514f: fd f9 05              or $r15 $r9
00005152: 89 38 14 00           mov $r9 0x1438
00005156: a0 9f                 st b32 D[$r9] $r15
00005158: 89 3c 14 00           mov $r9 0x143c
0000515c: a0 9c                 st b32 D[$r9] $r12
0000515e: 89 40 14 00           mov $r9 0x1440
00005162: 90 ed 40              add b32 $r13 $r14 0x40
00005165: df b2 ee ff c0        mov $r15 0xc0ffeeb2
0000516a: f0 d4 ff              and $r13 0xff
0000516d: f0 e4 3f              and $r14 0x3f
00005170: b6 e4 10              shl b32 $r14 0x10
00005173: fd ed 05              or $r14 $r13
00005176: fd e6 05              or $r14 $r6
00005179: a0 9e                 st b32 D[$r9] $r14
0000517b: 89 00 0a 02           mov $r9 0x20a00
0000517f: fa 9f 00              iowr I[$r9] $r15
00005182: 89 38 14 00           mov $r9 0x1438
00005186: bf 9f                 ld b32 $r15 D[$r9]
00005188: 89 00 0a 02           mov $r9 0x20a00
0000518c: fa 9f 00              iowr I[$r9] $r15
0000518f: 89 3c 14 00           mov $r9 0x143c
00005193: bf 9f                 ld b32 $r15 D[$r9]
00005195: 89 00 0a 02           mov $r9 0x20a00
00005199: fa 9f 00              iowr I[$r9] $r15
0000519c: fa 9e 00              iowr I[$r9] $r14
0000519f: 89 00 0a 00           mov $r9 0xa00
000051a3: 98 99 03              ld b32 $r9 D[$r9+0xc]
000051a6: 8f 44 14 00           mov $r15 0x1444
000051aa: f0 94 3f              and $r9 0x3f
000051ad: a0 f9                 st b32 D[$r15] $r9
000051af: 8f 00 0a 02           mov $r15 0x20a00
000051b3: fa f9 00              iowr I[$r15] $r9
000051b6: b3 94 21 28           bra b32 $r9 0x21 ne 0x51de
000051ba: 8f 38 14 00           mov $r15 0x1438
000051be: bf ff                 ld b32 $r15 D[$r15]
000051c0: 89 e0 12 00           mov $r9 0x12e0
000051c4: a0 9f                 st b32 D[$r9] $r15
000051c6: 8f 3c 14 00           mov $r15 0x143c
000051ca: bf ff                 ld b32 $r15 D[$r15]
000051cc: 89 e4 12 00           mov $r9 0x12e4
000051d0: a0 9f                 st b32 D[$r9] $r15
000051d2: 8f 40 14 00           mov $r15 0x1440
000051d6: bf ff                 ld b32 $r15 D[$r15]
000051d8: 89 e8 12 00           mov $r9 0x12e8
000051dc: a0 9f                 st b32 D[$r9] $r15
000051de: 89 e8 12 00         B mov $r9 0x12e8
000051e2: 80 e0 12 00           mov $r0 0x12e0
000051e6: bf 9c                 ld b32 $r12 D[$r9]
000051e8: 81 e4 12 00           mov $r1 0x12e4
000051ec: bf 0a                 ld b32 $r10 D[$r0]
000051ee: bf 1b                 ld b32 $r11 D[$r1]
000051f0: 7e b9 32 00           lcall 0x32b9
000051f4: 8e 00 0e 00           mov $r14 0xe00
000051f8: 98 ef 03              ld b32 $r15 D[$r14+0xc]
000051fb: d9 de c0 0d 60        mov $r9 0x600dc0de
00005200: b5 e9 3f              st b32 D[$r14+0xfc] $r9
00005203: d9 00 00 fe ca        mov $r9 0xcafe0000
00005208: f1 f4 ff ff           and $r15 0xffff
0000520c: fd f9 05              or $r15 $r9
0000520f: d9 11 ce ad de        mov $r9 0xdeadce11
00005214: 0a 02                 mov $r10 0x2
00005216: b5 e9 40              st b32 D[$r14+0x100] $r9
00005219: d9 0c b0 ce fa        mov $r9 0xfaceb00c
0000521e: b5 ef 03              st b32 D[$r14+0xc] $r15
00005221: b5 e9 7f              st b32 D[$r14+0x1fc] $r9
00005224: 7e 4a 2f 00           lcall 0x2f4a
00005228: 7e cf 31 00           lcall 0x31cf
0000522c: 8a 00 84 02           mov $r10 0x28400
00005230: 0b 05                 mov $r11 0x5
00005232: 7e 10 00 00           lcall 0x10
00005236: 89 ec 12 00           mov $r9 0x12ec
0000523a: bf 9b                 ld b32 $r11 D[$r9]
0000523c: 8a 14 a8 41           mov $r10 0x41a814
00005240: 7e 37 02 00           lcall 0x237
00005244: bf 0b                 ld b32 $r11 D[$r0]
00005246: 0a 13                 mov $r10 0x13
00005248: 7e c5 0c 00           lcall 0xcc5
0000524c: 7e fc 23 00           lcall 0x23fc
00005250: bf 1b                 ld b32 $r11 D[$r1]
00005252: 0a 1e                 mov $r10 0x1e
00005254: 7e c5 0c 00           lcall 0xcc5
00005258: 7e fc 23 00           lcall 0x23fc
0000525c: 7e cf 31 00           lcall 0x31cf
00005260: 0f 20               B mov $r15 0x20
00005262: 89 00 18 02           mov $r9 0x21800
00005266: fa 9f 00              iowr I[$r9] $r15
00005269: f4 30 0c              add $sp 0xc
0000526c: fb 85 08              mpopaddret $r8 0x8

0000526f: 89 00 0e 00        C  mov $r9 0xe00
00005273: 98 9e 1e              ld b32 $r14 D[$r9+0x78]
00005276: 98 9d 1f              ld b32 $r13 D[$r9+0x7c]
00005279: 89 ec 12 00           mov $r9 0x12ec
0000527d: bf 9f                 ld b32 $r15 D[$r9]
0000527f: f9 02                 mpush $r0
00005281: b6 d5 08              shr b32 $r13 0x8
00005284: e7 e0 08 01           extr $r0 $r14 0x8:0x10
00005288: 90 f9 40              add b32 $r9 $r15 0x40
0000528b: f0 94 ff              and $r9 0xff
0000528e: f0 f4 3f              and $r15 0x3f
00005291: b6 f4 10              shl b32 $r15 0x10
00005294: fd f9 05              or $r15 $r9
00005297: 89 38 14 00           mov $r9 0x1438
0000529b: b6 e4 18              shl b32 $r14 0x18
0000529e: fd ed 05              or $r14 $r13
000052a1: a0 9e                 st b32 D[$r9] $r14
000052a3: 89 3c 14 00           mov $r9 0x143c
000052a7: a0 90                 st b32 D[$r9] $r0
000052a9: 89 40 14 00           mov $r9 0x1440
000052ad: f4 30 f4              add $sp -0xc
000052b0: f0 b4 3f              and $r11 0x3f
000052b3: b6 b4 18              shl b32 $r11 0x18
000052b6: fd fb 05              or $r15 $r11
000052b9: a0 9f                 st b32 D[$r9] $r15
000052bb: 89 00 0a 02           mov $r9 0x20a00
000052bf: fa 9e 00              iowr I[$r9] $r14
000052c2: fa 90 00              iowr I[$r9] $r0
000052c5: fa 9f 00              iowr I[$r9] $r15
000052c8: 89 e0 12 00           mov $r9 0x12e0
000052cc: a0 9e                 st b32 D[$r9] $r14
000052ce: 89 e4 12 00           mov $r9 0x12e4
000052d2: a0 90                 st b32 D[$r9] $r0
000052d4: 89 e8 12 00           mov $r9 0x12e8
000052d8: b2 fc                 mov b32 $r12 $r15
000052da: a0 9f                 st b32 D[$r9] $r15
000052dc: b2 ea                 mov b32 $r10 $r14
000052de: b2 0b                 mov b32 $r11 $r0
000052e0: 7e b9 32 00           lcall 0x32b9
000052e4: 09 02                 mov $r9 0x2
000052e6: bd b4                 clear b32 $r11
000052e8: 8d 00 0a 00           mov $r13 0xa00
000052ec: bd e4                 clear b32 $r14
000052ee: bd a4                 clear b32 $r10
000052f0: 0c 06                 mov $r12 0x6
000052f2: b0 91 02              st b32 D[$sp+0x8] $r9
000052f5: b0 91 00              st b32 D[$sp] $r9
000052f8: 09 01                 mov $r9 0x1
000052fa: b0 91 01              st b32 D[$sp+0x4] $r9
000052fd: 7e e1 2d 00           lcall 0x2de1
00005301: 7e cf 31 00           lcall 0x31cf
00005305: 89 00 0e 00           mov $r9 0xe00
00005309: 98 9d 06              ld b32 $r13 D[$r9+0x18]
0000530c: 8f 00 0a 00           mov $r15 0xa00
00005310: 98 9e 08              ld b32 $r14 D[$r9+0x20]
00005313: bd b4                 clear b32 $r11
00005315: b5 fd 06              st b32 D[$r15+0x18] $r13
00005318: 98 9d 18              ld b32 $r13 D[$r9+0x60]
0000531b: b5 fe 08              st b32 D[$r15+0x20] $r14
0000531e: 98 9e 0b              ld b32 $r14 D[$r9+0x2c]
00005321: b5 fd 18              st b32 D[$r15+0x60] $r13
00005324: 98 9d 25              ld b32 $r13 D[$r9+0x94]
00005327: b5 fe 0b              st b32 D[$r15+0x2c] $r14
0000532a: 98 9e 2d              ld b32 $r14 D[$r9+0xb4]
0000532d: b5 fd 25              st b32 D[$r15+0x94] $r13
00005330: 98 9d 2c              ld b32 $r13 D[$r9+0xb0]
00005333: b5 fe 2d              st b32 D[$r15+0xb4] $r14
00005336: 98 9e 1a              ld b32 $r14 D[$r9+0x68]
00005339: b5 fd 2c              st b32 D[$r15+0xb0] $r13
0000533c: 98 9d 19              ld b32 $r13 D[$r9+0x64]
0000533f: b5 fe 1a              st b32 D[$r15+0x68] $r14
00005342: 98 9e 1f              ld b32 $r14 D[$r9+0x7c]
00005345: b5 fd 19              st b32 D[$r15+0x64] $r13
00005348: 98 9d 1e              ld b32 $r13 D[$r9+0x78]
0000534b: b5 fe 1f              st b32 D[$r15+0x7c] $r14
0000534e: 98 9e 29              ld b32 $r14 D[$r9+0xa4]
00005351: b5 fd 1e              st b32 D[$r15+0x78] $r13
00005354: 98 9d 2a              ld b32 $r13 D[$r9+0xa8]
00005357: 98 99 05              ld b32 $r9 D[$r9+0x14]
0000535a: b5 fe 29              st b32 D[$r15+0xa4] $r14
0000535d: b5 fd 2a              st b32 D[$r15+0xa8] $r13
00005360: b5 f9 05              st b32 D[$r15+0x14] $r9
00005363: 8d 00 0a 00         B mov $r13 0xa00
00005367: bc bd 90              add b32 $r9 $r11 $r13
0000536a: bf 99                 ld b32 $r9 D[$r9]
0000536c: 8e 00 0e 00           mov $r14 0xe00
00005370: bc be f0              add b32 $r15 $r11 $r14
00005373: 90 bb 04              add b32 $r11 $r11 0x4
00005376: a0 f9                 st b32 D[$r15] $r9
00005378: b3 be 00 01 eb        bra b32 $r11 0x100 ne 0x5363
0000537d: 09 02                 mov $r9 0x2
0000537f: b0 91 02              st b32 D[$sp+0x8] $r9
00005382: b0 91 00              st b32 D[$sp] $r9
00005385: 09 01                 mov $r9 0x1
00005387: bd e4                 clear b32 $r14
00005389: b0 91 01              st b32 D[$sp+0x4] $r9
0000538c: bd a4                 clear b32 $r10
0000538e: 0c 06                 mov $r12 0x6
00005390: 7e e1 2d 00           lcall 0x2de1
00005394: 89 00 0a 00           mov $r9 0xa00
00005398: 8f 00 0f 00           mov $r15 0xf00
0000539c: 8e 00 0b 00           mov $r14 0xb00
000053a0: bf 9d               B ld b32 $r13 D[$r9]
000053a2: 90 99 04              add b32 $r9 $r9 0x4
000053a5: a0 fd                 st b32 D[$r15] $r13
000053a7: 90 ff 04              add b32 $r15 $r15 0x4
000053aa: a6 9e                 cmp b32 $r9 $r14
000053ac: f4 1b f4              bra ne 0x53a0
000053af: f4 30 0c              add $sp 0xc
000053b2: fb 01                 mpopret $r0

000053b4: b3 a0 00 17        C  bra b32 $r10 0x0 e 0x53cb
000053b8: 89 c0 13 00           mov $r9 0x13c0
000053bc: bf 9f                 ld b32 $r15 D[$r9]
000053be: 89 00 2e 02           mov $r9 0x22e00
000053c2: fa 9f 00              iowr I[$r9] $r15
000053c5: 0f 08                 mov $r15 0x8
000053c7: 3e 73 54 00           lbra 0x5473
000053cb: b3 b4 02 58         B bra b32 $r11 0x2 ne 0x5423
000053cf: b3 c4 01 17           bra b32 $r12 0x1 ne 0x53e6
000053d3: 89 c0 13 00           mov $r9 0x13c0
000053d7: bf 9f                 ld b32 $r15 D[$r9]
000053d9: 89 00 2e 02           mov $r9 0x22e00
000053dd: fa 9f 00              iowr I[$r9] $r15
000053e0: 0f 10                 mov $r15 0x10
000053e2: 3e 73 54 00           lbra 0x5473
000053e6: b3 d4 01 17         B bra b32 $r13 0x1 ne 0x53fd
000053ea: 89 c0 13 00           mov $r9 0x13c0
000053ee: bf 9f                 ld b32 $r15 D[$r9]
000053f0: 89 00 2e 02           mov $r9 0x22e00
000053f4: fa 9f 00              iowr I[$r9] $r15
000053f7: 0f 0e                 mov $r15 0xe
000053f9: 3e 73 54 00           lbra 0x5473
000053fd: 8f c0 13 00         B mov $r15 0x13c0
00005401: b3 d4 02 13           bra b32 $r13 0x2 ne 0x5414
00005405: bf ff                 ld b32 $r15 D[$r15]
00005407: 89 00 2e 02           mov $r9 0x22e00
0000540b: fa 9f 00              iowr I[$r9] $r15
0000540e: 0f 11                 mov $r15 0x11
00005410: 3e 73 54 00           lbra 0x5473
00005414: bf ff               B ld b32 $r15 D[$r15]
00005416: 89 00 2e 02           mov $r9 0x22e00
0000541a: fa 9f 00              iowr I[$r9] $r15
0000541d: 0f 09                 mov $r15 0x9
0000541f: 3e 73 54 00           lbra 0x5473
00005423: b3 c4 01 17         B bra b32 $r12 0x1 ne 0x543a
00005427: 89 c0 13 00           mov $r9 0x13c0
0000542b: bf 9f                 ld b32 $r15 D[$r9]
0000542d: 89 00 2e 02           mov $r9 0x22e00
00005431: fa 9f 00              iowr I[$r9] $r15
00005434: 0f 12                 mov $r15 0x12
00005436: 3e 73 54 00           lbra 0x5473
0000543a: b3 d4 01 17         B bra b32 $r13 0x1 ne 0x5451
0000543e: 89 c0 13 00           mov $r9 0x13c0
00005442: bf 9f                 ld b32 $r15 D[$r9]
00005444: 89 00 2e 02           mov $r9 0x22e00
00005448: fa 9f 00              iowr I[$r9] $r15
0000544b: 0f 05                 mov $r15 0x5
0000544d: 3e 73 54 00           lbra 0x5473
00005451: 8f c0 13 00         B mov $r15 0x13c0
00005455: b3 d4 02 13           bra b32 $r13 0x2 ne 0x5468
00005459: bf ff                 ld b32 $r15 D[$r15]
0000545b: 89 00 2e 02           mov $r9 0x22e00
0000545f: fa 9f 00              iowr I[$r9] $r15
00005462: 0f 13                 mov $r15 0x13
00005464: 3e 73 54 00           lbra 0x5473
00005468: bf ff               B ld b32 $r15 D[$r15]
0000546a: 89 00 2e 02           mov $r9 0x22e00
0000546e: fa 9f 00              iowr I[$r9] $r15
00005471: 0f 0a                 mov $r15 0xa
00005473: b8 99 00 01 00      B add b32 $r9 $r9 0x100
00005478: fa 9f 00              iowr I[$r9] $r15
0000547b: f8 00                 ret

0000547d: 8e 00 0e 00        C  mov $r14 0xe00
00005481: 98 ef 23              ld b32 $r15 D[$r14+0x8c]
00005484: c4 f9 10              and $r9 $r15 0x10
00005487: f4 0b 23              bra e 0x54aa
0000548a: 09 ef                 mov $r9 -0x11
0000548c: ff f9 94              and $r9 $r15 $r9
0000548f: b5 e9 23              st b32 D[$r14+0x8c] $r9
00005492: 89 00 09 02           mov $r9 0x20900
00005496: fa 9a 00              iowr I[$r9] $r10
00005499: b8 99 00 06 00        add b32 $r9 $r9 0x600
0000549e: fa 9b 00              iowr I[$r9] $r11
000054a1: 0f 02                 mov $r15 0x2
000054a3: 89 00 07 03           mov $r9 0x30700
000054a7: fa 9f 00              iowr I[$r9] $r15
000054aa: f8 00               B ret

000054ac: f9 02              C  mpush $r0
000054ae: df 00 00 0a 35        mov $r15 0x350a0000
000054b3: b2 a0                 mov b32 $r0 $r10
000054b5: 89 00 2a 02           mov $r9 0x22a00
000054b9: fa 9f 00              iowr I[$r9] $r15
000054bc: 0f 0e                 mov $r15 0xe
000054be: b8 99 00 7e 02        sub b32 $r9 $r9 0x7e00
000054c3: fa 9f 00              iowr I[$r9] $r15
000054c6: 7e 68 07 00           lcall 0x768
000054ca: b3 04 01 12           bra b32 $r0 0x1 ne 0x54dc
000054ce: b3 a4 00 18           bra b32 $r10 0x0 ne 0x54e6
000054d2: 89 20 00 00           mov $r9 0x20
000054d6: bf 99                 ld b32 $r9 D[$r9]
000054d8: b3 90 00 0e           bra b32 $r9 0x0 e 0x54e6
000054dc: 89 ec 09 00         B mov $r9 0x9ec
000054e0: bf 99                 ld b32 $r9 D[$r9]
000054e2: b3 94 01 2e           bra b32 $r9 0x1 ne 0x5510
000054e6: 89 10 14 00         B mov $r9 0x1410
000054ea: bf 9e                 ld b32 $r14 D[$r9]
000054ec: 0f 01                 mov $r15 0x1
000054ee: 89 ec 09 00           mov $r9 0x9ec
000054f2: a0 9f                 st b32 D[$r9] $r15
000054f4: b3 e4 00 08           bra b32 $r14 0x0 ne 0x54fc
000054f8: 7e 8b 0b 00           lcall 0xb8b
000054fc: 89 dc 12 00         B mov $r9 0x12dc
00005500: bf 99                 ld b32 $r9 D[$r9]
00005502: b3 94 00 0e           bra b32 $r9 0x0 ne 0x5510
00005506: 8a e8 81 41           mov $r10 0x4181e8
0000550a: 0b 0c                 mov $r11 0xc
0000550c: 7e 37 02 00           lcall 0x237
00005510: b2 0a               B mov b32 $r10 $r0
00005512: 7e 91 0d 00           lcall 0xd91
00005516: fb 01                 mpopret $r0

00005518: f9 22              C  mpush $r2
0000551a: df 00 00 0a 35        mov $r15 0x350a0000
0000551f: 89 00 2a 02           mov $r9 0x22a00
00005523: fa 9f 00              iowr I[$r9] $r15
00005526: 7e 96 22 00           lcall 0x2296
0000552a: 89 ec 09 00           mov $r9 0x9ec
0000552e: bf 99                 ld b32 $r9 D[$r9]
00005530: b3 94 01 49           bra b32 $r9 0x1 ne 0x5579
00005534: 89 10 14 00           mov $r9 0x1410
00005538: bf 99                 ld b32 $r9 D[$r9]
0000553a: b3 94 00 08           bra b32 $r9 0x0 ne 0x5542
0000553e: 7e 49 27 00           lcall 0x2749
00005542: 89 dc 12 00         B mov $r9 0x12dc
00005546: bf 99                 ld b32 $r9 D[$r9]
00005548: b3 94 00 31           bra b32 $r9 0x0 ne 0x5579
0000554c: bd 14                 clear b32 $r1
0000554e: 80 e8 01 50           mov $r0 0x5001e8
00005552: 82 a0 14 00           mov $r2 0x14a0
00005556: 3e 72 55 00           lbra 0x5572
0000555a: 7e 5e 21 00         B lcall 0x215e
0000555e: b2 0a               B mov b32 $r10 $r0
00005560: 7e 97 02 00           lcall 0x297
00005564: c7 aa 22              extr $r10 $r10 0x2:0x3
00005567: f4 1b f3              bra ne 0x555a
0000556a: 90 11 01              add b32 $r1 $r1 0x1
0000556d: b8 00 00 80 00        add b32 $r0 $r0 0x8000
00005572: bf 29               B ld b32 $r9 D[$r2]
00005574: a6 19                 cmp b32 $r1 $r9
00005576: f4 08 e8              bra b 0x555e
00005579: fb 21               B mpopret $r2

0000557b: f9 42              C  mpush $r4
0000557d: b2 a2                 mov b32 $r2 $r10
0000557f: b2 b4                 mov b32 $r4 $r11
00005581: 8a 30 a0 10         B mov $r10 0x10a030
00005585: 7e 97 02 00           lcall 0x297
00005589: b2 a0                 mov b32 $r0 $r10
0000558b: 8a 2c a0 10           mov $r10 0x10a02c
0000558f: 7e 97 02 00           lcall 0x297
00005593: b2 a3                 mov b32 $r3 $r10
00005595: 8a 30 a0 10           mov $r10 0x10a030
00005599: 7e 97 02 00           lcall 0x297
0000559d: b2 a1                 mov b32 $r1 $r10
0000559f: a6 a0                 cmp b32 $r10 $r0
000055a1: f4 1b e0              bra ne 0x5581
000055a4: 90 20 01              add b32 $r0 $r2 0x1
000055a7: b0 06 1f              cmp b32 $r0 0x1f
000055aa: f4 0d 0d              bra be 0x55b7
000055ad: 0a 27                 mov $r10 0x27
000055af: 7e c0 05 00           lcall 0x5c0
000055b3: 3e f2 55 00           lbra 0x55f2
000055b7: b0 26 1f            B cmp b32 $r2 0x1f
000055ba: f4 0c 1c              bra a 0x55d6
000055bd: 89 00 12 00           mov $r9 0x1200
000055c1: 95 3e 05              shr b32 $r14 $r3 0x5
000055c4: 94 2f 02              shl b32 $r15 $r2 0x2
000055c7: bc f9 f0              add b32 $r15 $r15 $r9
000055ca: 94 a9 1b              shl b32 $r9 $r10 0x1b
000055cd: fd 9e 05              or $r9 $r14
000055d0: a0 f9                 st b32 D[$r15] $r9
000055d2: 3e dc 55 00           lbra 0x55dc
000055d6: 0a 27               B mov $r10 0x27
000055d8: 7e c0 05 00           lcall 0x5c0
000055dc: 8e 00 12 00         B mov $r14 0x1200
000055e0: 94 09 02              shl b32 $r9 $r0 0x2
000055e3: e7 1f e5 02           extr $r15 $r1 0x5:0x1c
000055e7: bc 9e 90              add b32 $r9 $r9 $r14
000055ea: 94 4e 18              shl b32 $r14 $r4 0x18
000055ed: fd fe 05              or $r15 $r14
000055f0: a0 9f                 st b32 D[$r9] $r15
000055f2: fb 41               B mpopret $r4

000055f4: 8f 00 12 00        C  mov $r15 0x1200
000055f8: bd 94                 clear b32 $r9
000055fa: b5 f9 0f              st b32 D[$r15+0x3c] $r9
000055fd: b5 f9 06              st b32 D[$r15+0x18] $r9
00005600: b5 f9 07              st b32 D[$r15+0x1c] $r9
00005603: b5 f9 08              st b32 D[$r15+0x20] $r9
00005606: b5 f9 09              st b32 D[$r15+0x24] $r9
00005609: b5 f9 0a              st b32 D[$r15+0x28] $r9
0000560c: b5 f9 0b              st b32 D[$r15+0x2c] $r9
0000560f: b5 f9 0c              st b32 D[$r15+0x30] $r9
00005612: b5 f9 0d              st b32 D[$r15+0x34] $r9
00005615: b5 f9 0e              st b32 D[$r15+0x38] $r9
00005618: f8 00                 ret

0000561a: f9 42              C  mpush $r4
0000561c: b2 a0                 mov b32 $r0 $r10
0000561e: f4 30 f4              add $sp -0xc
00005621: 7e cf 31 00           lcall 0x31cf
00005625: bd f4                 clear b32 $r15
00005627: 89 00 81 02           mov $r9 0x28100
0000562b: ff 9f 4f              iord $r4 I[$r9+$r15*0x4]
0000562e: b8 99 00 0d 00        add b32 $r9 $r9 0xd00
00005633: ff 9f 3f              iord $r3 I[$r9+$r15*0x4]
00005636: b8 99 00 01 00        add b32 $r9 $r9 0x100
0000563b: ff 9f 2f              iord $r2 I[$r9+$r15*0x4]
0000563e: b8 99 00 49 00        add b32 $r9 $r9 0x4900
00005643: bc 09 00              add b32 $r0 $r0 $r9
00005646: 94 0a 06              shl b32 $r10 $r0 0x6
00005649: 7e 97 02 00           lcall 0x297
0000564d: 89 b8 14 00           mov $r9 0x14b8
00005651: d0 ff ff ff 7f        mov $r0 0x7fffffff
00005656: ff a0 14              and $r1 $r10 $r0
00005659: bf 9a                 ld b32 $r10 D[$r9]
0000565b: 89 bc 14 00           mov $r9 0x14bc
0000565f: bf 9b                 ld b32 $r11 D[$r9]
00005661: 89 c0 14 00           mov $r9 0x14c0
00005665: bf 9c                 ld b32 $r12 D[$r9]
00005667: 7e b9 32 00           lcall 0x32b9
0000566b: 0a 28                 mov $r10 0x28
0000566d: a6 10                 cmp b32 $r1 $r0
0000566f: f4 0b 2b              bra e 0x569a
00005672: 94 1b 07              shl b32 $r11 $r1 0x7
00005675: 95 19 19              shr b32 $r9 $r1 0x19
00005678: 0a 29                 mov $r10 0x29
0000567a: f4 1b 20              bra ne 0x569a
0000567d: 09 02                 mov $r9 0x2
0000567f: bd a4                 clear b32 $r10
00005681: b0 91 02              st b32 D[$sp+0x8] $r9
00005684: b0 91 00              st b32 D[$sp] $r9
00005687: b0 91 01              st b32 D[$sp+0x4] $r9
0000568a: 0c 05                 mov $r12 0x5
0000568c: 8d 00 12 00           mov $r13 0x1200
00005690: bd e4                 clear b32 $r14
00005692: 7e e1 2d 00           lcall 0x2de1
00005696: 3e 9e 56 00           lbra 0x569e
0000569a: 7e c0 05 00         B lcall 0x5c0
0000569e: b2 4a               B mov b32 $r10 $r4
000056a0: b2 3b                 mov b32 $r11 $r3
000056a2: b2 2c                 mov b32 $r12 $r2
000056a4: 7e b9 32 00           lcall 0x32b9
000056a8: f4 30 0c              add $sp 0xc
000056ab: fb 41                 mpopret $r4

000056ad: 89 00 d8 02        C  mov $r9 0x2d800
000056b1: f9 42                 mpush $r4
000056b3: b2 a1                 mov b32 $r1 $r10
000056b5: bc 19 10              add b32 $r1 $r1 $r9
000056b8: 94 14 06              shl b32 $r4 $r1 0x6
000056bb: b2 4a                 mov b32 $r10 $r4
000056bd: 7e 97 02 00           lcall 0x297
000056c1: 89 00 28 fd           mov $r9 -0x2d800
000056c5: bc 19 10              add b32 $r1 $r1 $r9
000056c8: d9 04 00 b6 00        mov $r9 0xb60004
000056cd: b2 a0                 mov b32 $r0 $r10
000056cf: 90 a2 01              add b32 $r2 $r10 0x1
000056d2: 94 1a 06              shl b32 $r10 $r1 0x6
000056d5: bc a9 a0              add b32 $r10 $r10 $r9
000056d8: 7e 97 02 00           lcall 0x297
000056dc: b2 a3                 mov b32 $r3 $r10
000056de: a6 20                 cmp b32 $r2 $r0
000056e0: f4 18 0d              bra ae 0x56ed
000056e3: 0a 28                 mov $r10 0x28
000056e5: 7e c0 05 00           lcall 0x5c0
000056e9: 3e fa 56 00           lbra 0x56fa
000056ed: 89 c4 14 00         B mov $r9 0x14c4
000056f1: bf 99                 ld b32 $r9 D[$r9]
000056f3: a6 29                 cmp b32 $r2 $r9
000056f5: f4 08 05              bra b 0x56fa
000056f8: bd 24                 clear b32 $r2
000056fa: a6 23               B cmp b32 $r2 $r3
000056fc: f4 1b 0d              bra ne 0x5709
000056ff: 0a 30                 mov $r10 0x30
00005701: 7e c0 05 00           lcall 0x5c0
00005705: 3e 1b 57 00           lbra 0x571b
00005709: b2 1a               B mov b32 $r10 $r1
0000570b: 7e 1a 56 00           lcall 0x561a
0000570f: 7e f4 55 00           lcall 0x55f4
00005713: b2 4a                 mov b32 $r10 $r4
00005715: b2 2b                 mov b32 $r11 $r2
00005717: 7e 37 02 00           lcall 0x237
0000571b: bd f4               B clear b32 $r15
0000571d: 89 00 12 00           mov $r9 0x1200
00005721: b5 9f 02              st b32 D[$r9+0x8] $r15
00005724: fb 41                 mpopret $r4

00005726: f9 62              C  mpush $r6
00005728: 8f 00 00 10           mov $r15 0x100000
0000572c: b2 a2                 mov b32 $r2 $r10
0000572e: b2 b5                 mov b32 $r5 $r11
00005730: b2 c4                 mov b32 $r4 $r12
00005732: 89 00 14 02           mov $r9 0x21400
00005736: fa 9f 00              iowr I[$r9] $r15
00005739: 83 00 0e 00           mov $r3 0xe00
0000573d: 98 39 2d              ld b32 $r9 D[$r3+0xb4]
00005740: 98 3c 2c              ld b32 $r12 D[$r3+0xb0]
00005743: 98 3b 2b              ld b32 $r11 D[$r3+0xac]
00005746: 90 df 40              add b32 $r15 $r13 0x40
00005749: b6 95 08              shr b32 $r9 0x8
0000574c: e7 c1 08 01           extr $r1 $r12 0x8:0x10
00005750: b6 c4 18              shl b32 $r12 0x18
00005753: fd c9 05              or $r12 $r9
00005756: 89 b8 14 00           mov $r9 0x14b8
0000575a: a0 9c                 st b32 D[$r9] $r12
0000575c: 89 bc 14 00           mov $r9 0x14bc
00005760: f0 f4 ff              and $r15 0xff
00005763: f1 b4 ff ff           and $r11 0xffff
00005767: 94 ea 06              shl b32 $r10 $r14 0x6
0000576a: a0 91                 st b32 D[$r9] $r1
0000576c: f0 d4 3f              and $r13 0x3f
0000576f: 89 c0 14 00           mov $r9 0x14c0
00005773: b6 d4 10              shl b32 $r13 0x10
00005776: f0 e4 3f              and $r14 0x3f
00005779: fd df 05              or $r13 $r15
0000577c: b6 e4 18              shl b32 $r14 0x18
0000577f: fd de 05              or $r13 $r14
00005782: 80 c4 14 00           mov $r0 0x14c4
00005786: a0 9d                 st b32 D[$r9] $r13
00005788: d6 04 00 b6 00        mov $r6 0xb60004
0000578d: a0 0b                 st b32 D[$r0] $r11
0000578f: bc a6 a0              add b32 $r10 $r10 $r6
00005792: 7e 97 02 00           lcall 0x297
00005796: bf 0f                 ld b32 $r15 D[$r0]
00005798: b6 a5 1f              shr b32 $r10 0x1f
0000579b: 89 b4 14 00           mov $r9 0x14b4
0000579f: a0 9a                 st b32 D[$r9] $r10
000057a1: b3 f0 00 64           bra b32 $r15 0x0 e 0x5805
000057a5: b3 a0 00 60           bra b32 $r10 0x0 e 0x5805
000057a9: b3 24 00 2e           bra b32 $r2 0x0 ne 0x57d7
000057ad: 89 00 12 00           mov $r9 0x1200
000057b1: 98 9f 04              ld b32 $r15 D[$r9+0x10]
000057b4: 98 96 05              ld b32 $r6 D[$r9+0x14]
000057b7: b5 92 0f              st b32 D[$r9+0x3c] $r2
000057ba: b5 92 04              st b32 D[$r9+0x10] $r2
000057bd: b5 9f 02              st b32 D[$r9+0x8] $r15
000057c0: b5 96 03              st b32 D[$r9+0xc] $r6
000057c3: b5 92 05              st b32 D[$r9+0x14] $r2
000057c6: b5 92 0c              st b32 D[$r9+0x30] $r2
000057c9: b5 92 0d              st b32 D[$r9+0x34] $r2
000057cc: b5 92 0e              st b32 D[$r9+0x38] $r2
000057cf: 0a 06                 mov $r10 0x6
000057d1: 0b 01                 mov $r11 0x1
000057d3: 3e 01 58 00           lbra 0x5801
000057d7: b3 24 01 2e         B bra b32 $r2 0x1 ne 0x5805
000057db: 98 39 42              ld b32 $r9 D[$r3+0x108]
000057de: 98 33 41              ld b32 $r3 D[$r3+0x104]
000057e1: 8f 00 12 00           mov $r15 0x1200
000057e5: 0a 0c                 mov $r10 0xc
000057e7: b5 f9 1f              st b32 D[$r15+0x7c] $r9
000057ea: bd 94                 clear b32 $r9
000057ec: b5 f4 04              st b32 D[$r15+0x10] $r4
000057ef: a0 f9                 st b32 D[$r15] $r9
000057f1: b5 f5 05              st b32 D[$r15+0x14] $r5
000057f4: d9 ef be 0d 60        mov $r9 0x600dbeef
000057f9: b5 f3 1e              st b32 D[$r15+0x78] $r3
000057fc: b5 f9 01              st b32 D[$r15+0x4] $r9
000057ff: 0b 04                 mov $r11 0x4
00005801: 7e 7b 55 00         B lcall 0x557b
00005805: 8f 00 00 10         B mov $r15 0x100000
00005809: 89 00 1a 02           mov $r9 0x21a00
0000580d: fa 9f 00              iowr I[$r9] $r15
00005810: fb 61                 mpopret $r6

00005812: b3 a4 01 3c        C  bra b32 $r10 0x1 ne 0x584e
00005816: df 00 00 0e 31        mov $r15 0x310e0000
0000581b: 89 00 2a 02           mov $r9 0x22a00
0000581f: fa 9f 00              iowr I[$r9] $r15
00005822: 89 14 13 00           mov $r9 0x1314
00005826: bf 9b                 ld b32 $r11 D[$r9]
00005828: 0a 1c                 mov $r10 0x1c
0000582a: 7e c5 0c 00           lcall 0xcc5
0000582e: 7e fc 23 00           lcall 0x23fc
00005832: 89 1c 13 00           mov $r9 0x131c
00005836: bf 9b                 ld b32 $r11 D[$r9]
00005838: 0a 1f                 mov $r10 0x1f
0000583a: 7e c5 0c 00           lcall 0xcc5
0000583e: 7e fc 23 00           lcall 0x23fc
00005842: df 00 00 08 37        mov $r15 0x37080000
00005847: 89 00 2a 02           mov $r9 0x22a00
0000584b: fa 9f 00              iowr I[$r9] $r15
0000584e: f8 00               B ret

00005850: 8f 04 16 00        C  mov $r15 0x1604
00005854: bf ff                 ld b32 $r15 D[$r15]
00005856: f4 30 b8              add $sp -0x48
00005859: f9 82                 mpush $r8
0000585b: f4 30 f4              add $sp -0xc
0000585e: fe 49 01              mov $r9 $sp
00005861: 90 99 74              add b32 $r9 $r9 0x74
00005864: b2 a0                 mov b32 $r0 $r10
00005866: a0 9f                 st b32 D[$r9] $r15
00005868: b0 b1 0c              st b32 D[$sp+0x30] $r11
0000586b: 8f 00 00 08           mov $r15 0x80000
0000586f: 89 00 12 02           mov $r9 0x21200
00005873: fa 9f 00              iowr I[$r9] $r15
00005876: df 00 00 80 00        mov $r15 0x800000
0000587b: b8 99 00 18 00        add b32 $r9 $r9 0x1800
00005880: fa 9f 00              iowr I[$r9] $r15
00005883: df 00 00 08 37        mov $r15 0x37080000
00005888: fa 9f 00              iowr I[$r9] $r15
0000588b: 7e 68 07 00           lcall 0x768
0000588f: 7e 51 47 00           lcall 0x4751
00005893: 0f 08                 mov $r15 0x8
00005895: 89 00 ac 01           mov $r9 0x1ac00
00005899: fa 9f 00              iowr I[$r9] $r15
0000589c: bd f4                 clear b32 $r15
0000589e: 89 00 de 02           mov $r9 0x2de00
000058a2: ff 9f 9f              iord $r9 I[$r9+$r15*0x4]
000058a5: f0 94 3f              and $r9 0x3f
000058a8: df 00 00 09 36        mov $r15 0x36090000
000058ad: b0 91 0e              st b32 D[$sp+0x38] $r9
000058b0: 89 00 2a 02           mov $r9 0x22a00
000058b4: fa 9f 00              iowr I[$r9] $r15
000058b7: b4 b0 0c              ld b32 $r11 D[$sp+0x30]
000058ba: b2 0a                 mov b32 $r10 $r0
000058bc: 0c 02                 mov $r12 0x2
000058be: 7e d9 4d 00           lcall 0x4dd9
000058c2: df 00 00 08 37        mov $r15 0x37080000
000058c7: 89 00 2a 02           mov $r9 0x22a00
000058cb: fa 9f 00              iowr I[$r9] $r15
000058ce: 89 e0 12 00           mov $r9 0x12e0
000058d2: bf 9a                 ld b32 $r10 D[$r9]
000058d4: 89 e4 12 00           mov $r9 0x12e4
000058d8: bf 9b                 ld b32 $r11 D[$r9]
000058da: 89 e8 12 00           mov $r9 0x12e8
000058de: bf 9c                 ld b32 $r12 D[$r9]
000058e0: 7e b9 32 00           lcall 0x32b9
000058e4: df 00 00 0d 32        mov $r15 0x320d0000
000058e9: 89 00 2a 02           mov $r9 0x22a00
000058ed: fa 9f 00              iowr I[$r9] $r15
000058f0: 0a 02                 mov $r10 0x2
000058f2: 7e c1 2e 00           lcall 0x2ec1
000058f6: 7e cf 31 00           lcall 0x31cf
000058fa: df 00 00 08 37        mov $r15 0x37080000
000058ff: 89 00 2a 02           mov $r9 0x22a00
00005903: fa 9f 00              iowr I[$r9] $r15
00005906: df b1 ee ff c0        mov $r15 0xc0ffeeb1
0000590b: b8 99 00 20 02        sub b32 $r9 $r9 0x2000
00005910: fa 9f 00              iowr I[$r9] $r15
00005913: 89 00 0e 00           mov $r9 0xe00
00005917: 98 99 03              ld b32 $r9 D[$r9+0xc]
0000591a: 8f 44 14 00           mov $r15 0x1444
0000591e: f0 94 3f              and $r9 0x3f
00005921: a0 f9                 st b32 D[$r15] $r9
00005923: 8f 00 0a 02           mov $r15 0x20a00
00005927: fa f9 00              iowr I[$r15] $r9
0000592a: b3 90 21 0a           bra b32 $r9 0x21 e 0x5934
0000592e: bd 34                 clear b32 $r3
00005930: 3e 4f 59 00           lbra 0x594f
00005934: d9 00 00 14 2b      B mov $r9 0x2b140000
00005939: 8f 00 2a 02           mov $r15 0x22a00
0000593d: fa f9 00              iowr I[$r15] $r9
00005940: 89 ec 12 00           mov $r9 0x12ec
00005944: b4 b0 0e              ld b32 $r11 D[$sp+0x38]
00005947: bf 9a                 ld b32 $r10 D[$r9]
00005949: 03 01                 mov $r3 0x1
0000594b: 7e 6f 52 00           lcall 0x526f
0000594f: df 00 00 0e 31      B mov $r15 0x310e0000
00005954: 89 00 2a 02           mov $r9 0x22a00
00005958: fa 9f 00              iowr I[$r9] $r15
0000595b: 89 ec 12 00           mov $r9 0x12ec
0000595f: bf 9b                 ld b32 $r11 D[$r9]
00005961: 8a 14 a8 41           mov $r10 0x41a814
00005965: 7e 37 02 00           lcall 0x237
00005969: 89 e0 12 00           mov $r9 0x12e0
0000596d: bf 9b                 ld b32 $r11 D[$r9]
0000596f: 0a 13                 mov $r10 0x13
00005971: 7e c5 0c 00           lcall 0xcc5
00005975: 7e fc 23 00           lcall 0x23fc
00005979: 89 e4 12 00           mov $r9 0x12e4
0000597d: bf 9b                 ld b32 $r11 D[$r9]
0000597f: 0a 1e                 mov $r10 0x1e
00005981: 7e c5 0c 00           lcall 0xcc5
00005985: 7e fc 23 00           lcall 0x23fc
00005989: 89 24 13 00           mov $r9 0x1324
0000598d: bf 99                 ld b32 $r9 D[$r9]
0000598f: b3 94 00 17           bra b32 $r9 0x0 ne 0x59a6
00005993: 8a 00 a8 41           mov $r10 0x41a800
00005997: bd b4                 clear b32 $r11
00005999: 7e 37 02 00           lcall 0x237
0000599d: b4 b0 0c              ld b32 $r11 D[$sp+0x30]
000059a0: 0a 6c                 mov $r10 0x6c
000059a2: 7e c5 0c 00           lcall 0xcc5
000059a6: 0a 02               B mov $r10 0x2
000059a8: 7e d6 2f 00           lcall 0x2fd6
000059ac: df 00 00 11 2e        mov $r15 0x2e110000
000059b1: 89 00 2a 02           mov $r9 0x22a00
000059b5: fa 9f 00              iowr I[$r9] $r15
000059b8: 89 ec 12 00           mov $r9 0x12ec
000059bc: b4 b0 0e              ld b32 $r11 D[$sp+0x38]
000059bf: bf 9a                 ld b32 $r10 D[$r9]
000059c1: 7e 42 1a 00           lcall 0x1a42
000059c5: 89 0c 13 00           mov $r9 0x130c
000059c9: bf 99                 ld b32 $r9 D[$r9]
000059cb: 92 99 01              sub b32 $r9 $r9 0x1
000059ce: b0 96 01              cmp b32 $r9 0x1
000059d1: f4 0c 07              bra a 0x59d8
000059d4: 7e e5 32 00           lcall 0x32e5
000059d8: bd a4               B clear b32 $r10
000059da: 7e c6 29 00           lcall 0x29c6
000059de: b4 e0 0c              ld b32 $r14 D[$sp+0x30]
000059e1: d9 ff ff ff 0f        mov $r9 0xfffffff
000059e6: 0a 01                 mov $r10 0x1
000059e8: b2 ab                 mov b32 $r11 $r10
000059ea: fd e9 04              and $r14 $r9
000059ed: b2 ac                 mov b32 $r12 $r10
000059ef: b0 e1 0f              st b32 D[$sp+0x3c] $r14
000059f2: 7e f5 0c 00           lcall 0xcf5
000059f6: 7e 16 0e 00           lcall 0xe16
000059fa: b2 a1                 mov b32 $r1 $r10
000059fc: 7e ac 54 00           lcall 0x54ac
00005a00: 89 24 00 00           mov $r9 0x24
00005a04: bf 9a                 ld b32 $r10 D[$r9]
00005a06: 7e 14 01 00           lcall 0x114
00005a0a: 89 00 0e 00           mov $r9 0xe00
00005a0e: 98 9d 22              ld b32 $r13 D[$r9+0x88]
00005a11: 98 9f 38              ld b32 $r15 D[$r9+0xe0]
00005a14: 89 24 13 00           mov $r9 0x1324
00005a18: bd e4                 clear b32 $r14
00005a1a: a0 9e                 st b32 D[$r9] $r14
00005a1c: c7 d9 64              extr $r9 $r13 0x4:0x7
00005a1f: b0 91 0d              st b32 D[$sp+0x34] $r9
00005a22: f0 f4 01              and $r15 0x1
00005a25: c4 d4 0f              and $r4 $r13 0xf
00005a28: b3 f0 00 0a           bra b32 $r15 0x0 e 0x5a32
00005a2c: 0a 35                 mov $r10 0x35
00005a2e: 7e c0 05 00           lcall 0x5c0
00005a32: 89 a0 14 00         B mov $r9 0x14a0
00005a36: bf 9f                 ld b32 $r15 D[$r9]
00005a38: 89 00 0e 00           mov $r9 0xe00
00005a3c: 98 99 02              ld b32 $r9 D[$r9+0x8]
00005a3f: a6 f9                 cmp b32 $r15 $r9
00005a41: f4 0b 09              bra e 0x5a4a
00005a44: 0a 32                 mov $r10 0x32
00005a46: 7e c0 05 00           lcall 0x5c0
00005a4a: 89 84 12 00         B mov $r9 0x1284
00005a4e: bf 9f                 ld b32 $r15 D[$r9]
00005a50: 89 00 10 00           mov $r9 0x1000
00005a54: 98 99 04              ld b32 $r9 D[$r9+0x10]
00005a57: a6 f9                 cmp b32 $r15 $r9
00005a59: f4 0b 09              bra e 0x5a62
00005a5c: 0a 40                 mov $r10 0x40
00005a5e: 7e c0 05 00           lcall 0x5c0
00005a62: 89 88 12 00         B mov $r9 0x1288
00005a66: bf 9f                 ld b32 $r15 D[$r9]
00005a68: 89 00 10 00           mov $r9 0x1000
00005a6c: 98 99 05              ld b32 $r9 D[$r9+0x14]
00005a6f: a6 f9                 cmp b32 $r15 $r9
00005a71: f4 0b 09              bra e 0x5a7a
00005a74: 0a 38                 mov $r10 0x38
00005a76: 7e c0 05 00           lcall 0x5c0
00005a7a: d9 00 00 08 37      B mov $r9 0x37080000
00005a7f: 8f 00 2a 02           mov $r15 0x22a00
00005a83: fa f9 00              iowr I[$r15] $r9
00005a86: 80 00 0e 00           mov $r0 0xe00
00005a8a: 98 09 3d              ld b32 $r9 D[$r0+0xf4]
00005a8d: b3 94 00 53           bra b32 $r9 0x0 ne 0x5ae0
00005a91: 98 09 3e              ld b32 $r9 D[$r0+0xf8]
00005a94: b3 94 00 4c           bra b32 $r9 0x0 ne 0x5ae0
00005a98: 7e 8f 47 00           lcall 0x478f
00005a9c: 89 c0 13 00           mov $r9 0x13c0
00005aa0: b5 0a 3c              st b32 D[$r0+0xf0] $r10
00005aa3: a0 9a                 st b32 D[$r9] $r10
00005aa5: df 00 00 0f 30        mov $r15 0x300f0000
00005aaa: 89 00 2a 02           mov $r9 0x22a00
00005aae: fa 9f 00              iowr I[$r9] $r15
00005ab1: 0a 01                 mov $r10 0x1
00005ab3: 7e 70 10 00           lcall 0x1070
00005ab7: df 00 00 08 37        mov $r15 0x37080000
00005abc: 89 00 2a 02           mov $r9 0x22a00
00005ac0: fa 9f 00              iowr I[$r9] $r15
00005ac3: 89 c0 13 00           mov $r9 0x13c0
00005ac7: bf 9f                 ld b32 $r15 D[$r9]
00005ac9: 89 00 2e 02           mov $r9 0x22e00
00005acd: fa 9f 00              iowr I[$r9] $r15
00005ad0: 0f 0c                 mov $r15 0xc
00005ad2: b8 99 00 01 00        add b32 $r9 $r9 0x100
00005ad7: fa 9f 00              iowr I[$r9] $r15
00005ada: 03 01                 mov $r3 0x1
00005adc: 3e ed 5a 00           lbra 0x5aed
00005ae0: 8f 00 0e 00         B mov $r15 0xe00
00005ae4: 98 ff 3c              ld b32 $r15 D[$r15+0xf0]
00005ae7: 89 c0 13 00           mov $r9 0x13c0
00005aeb: a0 9f                 st b32 D[$r9] $r15
00005aed: df 00 00 10 2f      B mov $r15 0x2f100000
00005af2: 89 00 2a 02           mov $r9 0x22a00
00005af6: fa 9f 00              iowr I[$r9] $r15
00005af9: 89 c0 13 00           mov $r9 0x13c0
00005afd: b4 b0 0f              ld b32 $r11 D[$sp+0x3c]
00005b00: bf 9c                 ld b32 $r12 D[$r9]
00005b02: b4 e0 0e              ld b32 $r14 D[$sp+0x38]
00005b05: 89 ec 12 00           mov $r9 0x12ec
00005b09: bf 9d                 ld b32 $r13 D[$r9]
00005b0b: 0a 01                 mov $r10 0x1
00005b0d: 7e 26 57 00           lcall 0x5726
00005b11: df 00 00 08 37        mov $r15 0x37080000
00005b16: 89 00 2a 02           mov $r9 0x22a00
00005b1a: fa 9f 00              iowr I[$r9] $r15
00005b1d: df 00 00 0f 30        mov $r15 0x300f0000
00005b22: fa 9f 00              iowr I[$r9] $r15
00005b25: 8f 00 0e 00           mov $r15 0xe00
00005b29: 98 f9 20              ld b32 $r9 D[$r15+0x80]
00005b2c: 98 fe 0e              ld b32 $r14 D[$r15+0x38]
00005b2f: 8f 20 13 00           mov $r15 0x1320
00005b33: f0 94 03              and $r9 0x3
00005b36: f0 e4 ff              and $r14 0xff
00005b39: a0 f9                 st b32 D[$r15] $r9
00005b3b: 89 30 00 00           mov $r9 0x30
00005b3f: a0 9e                 st b32 D[$r9] $r14
00005b41: 7e a0 38 00           lcall 0x38a0
00005b45: df 00 00 08 37        mov $r15 0x37080000
00005b4a: 89 00 2a 02           mov $r9 0x22a00
00005b4e: fa 9f 00              iowr I[$r9] $r15
00005b51: 8a b8 41 40           mov $r10 0x4041b8
00005b55: 7e 97 02 00           lcall 0x297
00005b59: 89 00 0e 00           mov $r9 0xe00
00005b5d: 98 99 23              ld b32 $r9 D[$r9+0x8c]
00005b60: f0 94 03              and $r9 0x3
00005b63: b3 94 01 0e           bra b32 $r9 0x1 ne 0x5b71
00005b67: b3 44 01 0a           bra b32 $r4 0x1 ne 0x5b71
00005b6b: 89 24 13 00           mov $r9 0x1324
00005b6f: a0 94                 st b32 D[$r9] $r4
00005b71: df 01 ee ff c0      B mov $r15 0xc0ffee01
00005b76: 89 00 0a 02           mov $r9 0x20a00
00005b7a: fa 9f 00              iowr I[$r9] $r15
00005b7d: 89 24 13 00           mov $r9 0x1324
00005b81: bf 9f                 ld b32 $r15 D[$r9]
00005b83: 89 00 0a 02           mov $r9 0x20a00
00005b87: fa 9f 00              iowr I[$r9] $r15
00005b8a: 8a 60 01 40           mov $r10 0x400160
00005b8e: 7e 97 02 00           lcall 0x297
00005b92: b4 b0 0e              ld b32 $r11 D[$sp+0x38]
00005b95: d9 ff ff 0f fc        mov $r9 0xfc0fffff
00005b9a: fd a9 04              and $r10 $r9
00005b9d: b6 b4 14              shl b32 $r11 0x14
00005ba0: ff ab b5              or $r11 $r10 $r11
00005ba3: 8a 60 01 40           mov $r10 0x400160
00005ba7: 7e 37 02 00           lcall 0x237
00005bab: 7e 0c 29 00           lcall 0x290c
00005baf: b2 1a                 mov b32 $r10 $r1
00005bb1: 7e 18 55 00           lcall 0x5518
00005bb5: df 00 00 08 37        mov $r15 0x37080000
00005bba: 89 00 2a 02           mov $r9 0x22a00
00005bbe: fa 9f 00              iowr I[$r9] $r15
00005bc1: 0f 08                 mov $r15 0x8
00005bc3: b8 99 00 7e 02        sub b32 $r9 $r9 0x7e00
00005bc8: fa 9f 00              iowr I[$r9] $r15
00005bcb: 8a 84 03 40         B mov $r10 0x400384
00005bcf: 7e 97 02 00           lcall 0x297
00005bd3: b2 a0                 mov b32 $r0 $r10
00005bd5: 7e 5e 21 00           lcall 0x215e
00005bd9: c7 00 4c              extr $r0 $r0 0xc:0xe
00005bdc: f4 1b ef              bra ne 0x5bcb
00005bdf: 89 24 13 00           mov $r9 0x1324
00005be3: bf 99                 ld b32 $r9 D[$r9]
00005be5: b3 94 00 0a           bra b32 $r9 0x0 ne 0x5bef
00005be9: 0a 08                 mov $r10 0x8
00005beb: 7e af 23 00           lcall 0x23af
00005bef: 89 c0 13 00         B mov $r9 0x13c0
00005bf3: bf 9f                 ld b32 $r15 D[$r9]
00005bf5: 89 00 dd 02           mov $r9 0x2dd00
00005bf9: fa 9f 00              iowr I[$r9] $r15
00005bfc: bd a4                 clear b32 $r10
00005bfe: 7e 88 29 00           lcall 0x2988
00005c02: b3 44 01 21           bra b32 $r4 0x1 ne 0x5c23
00005c06: 89 c0 13 00           mov $r9 0x13c0
00005c0a: bf 9f                 ld b32 $r15 D[$r9]
00005c0c: 89 00 2e 02           mov $r9 0x22e00
00005c10: fa 9f 00              iowr I[$r9] $r15
00005c13: 0f 14                 mov $r15 0x14
00005c15: b8 99 00 01 00        add b32 $r9 $r9 0x100
00005c1a: fa 9f 00              iowr I[$r9] $r15
00005c1d: 0f 0a                 mov $r15 0xa
00005c1f: 3e 7d 5c 00           lbra 0x5c7d
00005c23: b4 e0 0d            B ld b32 $r14 D[$sp+0x34]
00005c26: b3 e4 01 21           bra b32 $r14 0x1 ne 0x5c47
00005c2a: 89 c0 13 00           mov $r9 0x13c0
00005c2e: bf 9f                 ld b32 $r15 D[$r9]
00005c30: 89 00 2e 02           mov $r9 0x22e00
00005c34: fa 9f 00              iowr I[$r9] $r15
00005c37: 0f 0f                 mov $r15 0xf
00005c39: b8 99 00 01 00        add b32 $r9 $r9 0x100
00005c3e: fa 9f 00              iowr I[$r9] $r15
00005c41: 0f 0c                 mov $r15 0xc
00005c43: 3e 7d 5c 00           lbra 0x5c7d
00005c47: 8f c0 13 00         B mov $r15 0x13c0
00005c4b: b3 e4 02 1d           bra b32 $r14 0x2 ne 0x5c68
00005c4f: bf ff                 ld b32 $r15 D[$r15]
00005c51: 89 00 2e 02           mov $r9 0x22e00
00005c55: fa 9f 00              iowr I[$r9] $r15
00005c58: 0f 15                 mov $r15 0x15
00005c5a: b8 99 00 01 00        add b32 $r9 $r9 0x100
00005c5f: fa 9f 00              iowr I[$r9] $r15
00005c62: 0f 0b                 mov $r15 0xb
00005c64: 3e 7d 5c 00           lbra 0x5c7d
00005c68: bf ff               B ld b32 $r15 D[$r15]
00005c6a: 89 00 2e 02           mov $r9 0x22e00
00005c6e: fa 9f 00              iowr I[$r9] $r15
00005c71: 0f 0b                 mov $r15 0xb
00005c73: b8 99 00 01 00        add b32 $r9 $r9 0x100
00005c78: fa 9f 00              iowr I[$r9] $r15
00005c7b: 0f 09                 mov $r15 0x9
00005c7d: 89 00 ac 01         B mov $r9 0x1ac00
00005c81: fa 9f 00              iowr I[$r9] $r15
00005c84: df 00 00 12 2d        mov $r15 0x2d120000
00005c89: 89 00 2a 02           mov $r9 0x22a00
00005c8d: fa 9f 00              iowr I[$r9] $r15
00005c90: 89 ec 12 00           mov $r9 0x12ec
00005c94: b4 b0 0e              ld b32 $r11 D[$sp+0x38]
00005c97: bf 9a                 ld b32 $r10 D[$r9]
00005c99: 7e df 16 00           lcall 0x16df
00005c9d: df 00 00 08 37        mov $r15 0x37080000
00005ca2: 89 00 2a 02           mov $r9 0x22a00
00005ca6: fa 9f 00              iowr I[$r9] $r15
00005ca9: b3 4d 01 4e 01        bra b32 $r4 0x1 ne 0x5df7
00005cae: 89 5c 14 00           mov $r9 0x145c
00005cb2: bf 99                 ld b32 $r9 D[$r9]
00005cb4: b3 99 00 02 01        bra b32 $r9 0x0 e 0x5db6
00005cb9: 89 30 00 00           mov $r9 0x30
00005cbd: bf 99                 ld b32 $r9 D[$r9]
00005cbf: b3 9d 03 f7 00        bra b32 $r9 0x3 ne 0x5db6
00005cc4: df 00 00 0f 30        mov $r15 0x300f0000
00005cc9: 89 00 2a 02           mov $r9 0x22a00
00005ccd: fa 9f 00              iowr I[$r9] $r15
00005cd0: 82 00 0c 00           mov $r2 0xc00
00005cd4: 98 2e 04              ld b32 $r14 D[$r2+0x10]
00005cd7: 89 00 0e 00           mov $r9 0xe00
00005cdb: 8f 74 14 00           mov $r15 0x1474
00005cdf: 98 9d 0e              ld b32 $r13 D[$r9+0x38]
00005ce2: 89 5c 14 00           mov $r9 0x145c
00005ce6: a0 fe                 st b32 D[$r15] $r14
00005ce8: bf 9f                 ld b32 $r15 D[$r9]
00005cea: 89 60 14 00           mov $r9 0x1460
00005cee: bf 99                 ld b32 $r9 D[$r9]
00005cf0: bf 22                 ld b32 $r2 D[$r2]
00005cf2: b2 eb                 mov b32 $r11 $r14
00005cf4: c7 dd e8              extr $r13 $r13 0x8:0xf
00005cf7: 95 9e 10              shr b32 $r14 $r9 0x10
00005cfa: f1 94 ff ff           and $r9 0xffff
00005cfe: 95 fc 10              shr b32 $r12 $r15 0x10
00005d01: fe 40 01              mov $r0 $sp
00005d04: f1 f4 ff ff           and $r15 0xffff
00005d08: 90 00 64              add b32 $r0 $r0 0x64
00005d0b: b5 09 02              st b32 D[$r0+0x8] $r9
00005d0e: 89 84 14 00           mov $r9 0x1484
00005d12: b2 da                 mov b32 $r10 $r13
00005d14: a0 9d                 st b32 D[$r9] $r13
00005d16: b5 0c 01              st b32 D[$r0+0x4] $r12
00005d19: b5 0e 03              st b32 D[$r0+0xc] $r14
00005d1c: a0 0f                 st b32 D[$r0] $r15
00005d1e: 81 78 14 00           mov $r1 0x1478
00005d22: a0 12                 st b32 D[$r1] $r2
00005d24: 7e ce 77 00           lcall 0x77ce
00005d28: bc a2 e0              add b32 $r14 $r10 $r2
00005d2b: 95 e9 18              shr b32 $r9 $r14 0x18
00005d2e: fe 4f 01              mov $r15 $sp
00005d31: b6 e5 08              shr b32 $r14 0x8
00005d34: 90 ff 54              add b32 $r15 $r15 0x54
00005d37: b5 f9 01              st b32 D[$r15+0x4] $r9
00005d3a: e4 e9 ff ff           and $r9 $r14 0xffff
00005d3e: a0 f9                 st b32 D[$r15] $r9
00005d40: bd 94                 clear b32 $r9
00005d42: b5 f9 02              st b32 D[$r15+0x8] $r9
00005d45: b5 f9 03              st b32 D[$r15+0xc] $r9
00005d48: 89 70 14 00           mov $r9 0x1470
00005d4c: b2 0b                 mov b32 $r11 $r0
00005d4e: b2 fc                 mov b32 $r12 $r15
00005d50: a0 9e                 st b32 D[$r9] $r14
00005d52: fe 40 01              mov $r0 $sp
00005d55: 90 00 44              add b32 $r0 $r0 0x44
00005d58: b2 0a                 mov b32 $r10 $r0
00005d5a: 7e 21 10 00           lcall 0x1021
00005d5e: 98 0f 01              ld b32 $r15 D[$r0+0x4]
00005d61: bf 0d                 ld b32 $r13 D[$r0]
00005d63: 89 ec 12 00           mov $r9 0x12ec
00005d67: bf 99                 ld b32 $r9 D[$r9]
00005d69: b6 f4 10              shl b32 $r15 0x10
00005d6c: ff fd 25              or $r2 $r15 $r13
00005d6f: 98 0e 03              ld b32 $r14 D[$r0+0xc]
00005d72: 90 9f 40              add b32 $r15 $r9 0x40
00005d75: f0 f4 ff              and $r15 0xff
00005d78: f0 94 3f              and $r9 0x3f
00005d7b: b6 94 10              shl b32 $r9 0x10
00005d7e: fd 9f 05              or $r9 $r15
00005d81: b4 f0 0e              ld b32 $r15 D[$sp+0x38]
00005d84: 98 0c 02              ld b32 $r12 D[$r0+0x8]
00005d87: b6 e4 10              shl b32 $r14 0x10
00005d8a: 0a 02                 mov $r10 0x2
00005d8c: b6 f4 18              shl b32 $r15 0x18
00005d8f: ff ec 15              or $r1 $r14 $r12
00005d92: ff 9f 05              or $r0 $r9 $r15
00005d95: 7e 70 10 00           lcall 0x1070
00005d99: 8e 94 14 00           mov $r14 0x1494
00005d9d: bf e9                 ld b32 $r9 D[$r14]
00005d9f: 4f 00 ff              mov $r15 -0x100
00005da2: 03 01                 mov $r3 0x1
00005da4: ff 9f f4              and $r15 $r9 $r15
00005da7: 10 99 01              add b8 $r9 $r9 0x1
00005daa: f0 94 ff              and $r9 0xff
00005dad: fd 9f 05              or $r9 $r15
00005db0: a0 e9                 st b32 D[$r14] $r9
00005db2: 3e e5 5d 00           lbra 0x5de5
00005db6: 8f 00 0e 00         B mov $r15 0xe00
00005dba: 89 ec 12 00           mov $r9 0x12ec
00005dbe: 98 fe 19              ld b32 $r14 D[$r15+0x64]
00005dc1: bf 99                 ld b32 $r9 D[$r9]
00005dc3: 98 f2 1a              ld b32 $r2 D[$r15+0x68]
00005dc6: 8f ff ff 01           mov $r15 0x1ffff
00005dca: ff ef 14              and $r1 $r14 $r15
00005dcd: 90 9f 40              add b32 $r15 $r9 0x40
00005dd0: f0 f4 ff              and $r15 0xff
00005dd3: f0 94 3f              and $r9 0x3f
00005dd6: b6 94 10              shl b32 $r9 0x10
00005dd9: fd 9f 05              or $r9 $r15
00005ddc: b4 f0 0e              ld b32 $r15 D[$sp+0x38]
00005ddf: b6 f4 18              shl b32 $r15 0x18
00005de2: ff 9f 05              or $r0 $r9 $r15
00005de5: 89 14 13 00         B mov $r9 0x1314
00005de9: a0 92                 st b32 D[$r9] $r2
00005deb: 89 18 13 00           mov $r9 0x1318
00005def: a0 91                 st b32 D[$r9] $r1
00005df1: 89 1c 13 00           mov $r9 0x131c
00005df5: a0 90                 st b32 D[$r9] $r0
00005df7: 8e 00 0e 00         B mov $r14 0xe00
00005dfb: 98 e9 03              ld b32 $r9 D[$r14+0xc]
00005dfe: 8f 00 00 ff           mov $r15 -0x10000
00005e02: fd 9f 04              and $r9 $r15
00005e05: df 00 00 fe ca        mov $r15 0xcafe0000
00005e0a: a6 9f                 cmp b32 $r9 $r15
00005e0c: f4 1b 2a              bra ne 0x5e36
00005e0f: 98 ef 3f              ld b32 $r15 D[$r14+0xfc]
00005e12: d9 de c0 0d 60        mov $r9 0x600dc0de
00005e17: a6 f9                 cmp b32 $r15 $r9
00005e19: f4 1b 1d              bra ne 0x5e36
00005e1c: 98 ef 40              ld b32 $r15 D[$r14+0x100]
00005e1f: d9 11 ce ad de        mov $r9 0xdeadce11
00005e24: a6 f9                 cmp b32 $r15 $r9
00005e26: f4 1b 10              bra ne 0x5e36
00005e29: 98 ef 7f              ld b32 $r15 D[$r14+0x1fc]
00005e2c: d9 0c b0 ce fa        mov $r9 0xfaceb00c
00005e31: a6 f9                 cmp b32 $r15 $r9
00005e33: f4 0b 21              bra e 0x5e54
00005e36: 0a 01               B mov $r10 0x1
00005e38: 7e 91 07 00           lcall 0x791
00005e3c: 0a 15                 mov $r10 0x15
00005e3e: 7e c0 05 00           lcall 0x5c0
00005e42: 0f 02                 mov $r15 0x2
00005e44: 89 00 00 02           mov $r9 0x20000
00005e48: fa 9f 00              iowr I[$r9] $r15
00005e4b: df e0 0d dc ba        mov $r15 0xbadc0de0
00005e50: 3e 0c 5f 00           lbra 0x5f0c
00005e54: df 00 00 04 3b      B mov $r15 0x3b040000
00005e59: 89 00 2a 02           mov $r9 0x22a00
00005e5d: fa 9f 00              iowr I[$r9] $r15
00005e60: 89 24 13 00           mov $r9 0x1324
00005e64: bf 99                 ld b32 $r9 D[$r9]
00005e66: b3 94 00 08           bra b32 $r9 0x0 ne 0x5e6e
00005e6a: 7e fc 23 00           lcall 0x23fc
00005e6e: 80 ec 12 00         B mov $r0 0x12ec
00005e72: bf 0a                 ld b32 $r10 D[$r0]
00005e74: 7e c4 24 00           lcall 0x24c4
00005e78: bf 0a                 ld b32 $r10 D[$r0]
00005e7a: 7e 89 26 00           lcall 0x2689
00005e7e: 89 24 13 00           mov $r9 0x1324
00005e82: bf 99                 ld b32 $r9 D[$r9]
00005e84: b3 94 00 0a           bra b32 $r9 0x0 ne 0x5e8e
00005e88: b2 4a                 mov b32 $r10 $r4
00005e8a: 7e 12 58 00           lcall 0x5812
00005e8e: 0a 07               B mov $r10 0x7
00005e90: bd b4                 clear b32 $r11
00005e92: 7e 17 0d 00           lcall 0xd17
00005e96: 89 24 13 00           mov $r9 0x1324
00005e9a: bf 99                 ld b32 $r9 D[$r9]
00005e9c: b3 94 00 17           bra b32 $r9 0x0 ne 0x5eb3
00005ea0: 8a 00 a8 41           mov $r10 0x41a800
00005ea4: bd b4                 clear b32 $r11
00005ea6: 7e 37 02 00           lcall 0x237
00005eaa: b4 b0 0c              ld b32 $r11 D[$sp+0x30]
00005ead: 0a 02                 mov $r10 0x2
00005eaf: 7e c5 0c 00           lcall 0xcc5
00005eb3: 8e 00 10 00         B mov $r14 0x1000
00005eb7: 98 e9 01              ld b32 $r9 D[$r14+0x4]
00005eba: 8f 00 00 ff           mov $r15 -0x10000
00005ebe: fd 9f 04              and $r9 $r15
00005ec1: df 00 00 11 ca        mov $r15 0xca110000
00005ec6: a6 9f                 cmp b32 $r9 $r15
00005ec8: f4 1b 2a              bra ne 0x5ef2
00005ecb: 98 ef 3f              ld b32 $r15 D[$r14+0xfc]
00005ece: d9 ab ec 0b ad        mov $r9 0xad0becab
00005ed3: a6 f9                 cmp b32 $r15 $r9
00005ed5: f4 1b 1d              bra ne 0x5ef2
00005ed8: 98 ef 40              ld b32 $r15 D[$r14+0x100]
00005edb: d9 da 00 eb 1c        mov $r9 0x1ceb00da
00005ee0: a6 f9                 cmp b32 $r15 $r9
00005ee2: f4 1b 10              bra ne 0x5ef2
00005ee5: 98 ef 7f              ld b32 $r15 D[$r14+0x1fc]
00005ee8: d9 ef be 0d f0        mov $r9 0xf00dbeef
00005eed: a6 f9                 cmp b32 $r15 $r9
00005eef: f4 0b 33              bra e 0x5f22
00005ef2: 0a 01               B mov $r10 0x1
00005ef4: 7e 91 07 00           lcall 0x791
00005ef8: 0a 15                 mov $r10 0x15
00005efa: 7e c0 05 00           lcall 0x5c0
00005efe: 0f 02                 mov $r15 0x2
00005f00: 89 00 00 02           mov $r9 0x20000
00005f04: fa 9f 00              iowr I[$r9] $r15
00005f07: df e1 0d dc ba        mov $r15 0xbadc0de1
00005f0c: b8 99 00 0e 00      B add b32 $r9 $r9 0xe00
00005f11: fa 9f 00              iowr I[$r9] $r15
00005f14: df 00 00 00 3f        mov $r15 0x3f000000
00005f19: b8 99 00 1c 00        add b32 $r9 $r9 0x1c00
00005f1e: 3e 79 64 00           lbra 0x6479
00005f22: 89 24 00 00         B mov $r9 0x24
00005f26: bf 9a                 ld b32 $r10 D[$r9]
00005f28: 7e 14 01 00           lcall 0x114
00005f2c: 0a 04                 mov $r10 0x4
00005f2e: 7e 91 07 00           lcall 0x791
00005f32: 89 24 13 00           mov $r9 0x1324
00005f36: bf 99                 ld b32 $r9 D[$r9]
00005f38: b3 94 00 16           bra b32 $r9 0x0 ne 0x5f4e
00005f3c: df 00 00 16 29        mov $r15 0x29160000
00005f41: 89 00 2a 02           mov $r9 0x22a00
00005f45: fa 9f 00              iowr I[$r9] $r15
00005f48: 0a 02                 mov $r10 0x2
00005f4a: 7e 5b 04 00           lcall 0x45b
00005f4e: df 00 00 01 3e      B mov $r15 0x3e010000
00005f53: 89 00 2a 02           mov $r9 0x22a00
00005f57: fa 9f 00              iowr I[$r9] $r15
00005f5a: 89 24 13 00           mov $r9 0x1324
00005f5e: bf 99                 ld b32 $r9 D[$r9]
00005f60: b3 94 00 18           bra b32 $r9 0x0 ne 0x5f78
00005f64: 7e d1 0e 00           lcall 0xed1
00005f68: 0a 01                 mov $r10 0x1
00005f6a: 7e 15 04 00           lcall 0x415
00005f6e: 7e 19 2c 00           lcall 0x2c19
00005f72: bd a4                 clear b32 $r10
00005f74: 7e 2f 04 00           lcall 0x42f
00005f78: 0a 01               B mov $r10 0x1
00005f7a: 7e e3 00 00           lcall 0xe3
00005f7e: 7e 75 21 00           lcall 0x2175
00005f82: 0a 0b                 mov $r10 0xb
00005f84: 4b f2 00              mov $r11 0xf2
00005f87: 7e c4 00 00           lcall 0xc4
00005f8b: 89 00 10 00           mov $r9 0x1000
00005f8f: 98 9b 03              ld b32 $r11 D[$r9+0xc]
00005f92: 0a 10                 mov $r10 0x10
00005f94: f0 b3 00              sethi $r11 0x0
00005f97: 7e c4 00 00           lcall 0xc4
00005f9b: 89 24 13 00           mov $r9 0x1324
00005f9f: bf 99                 ld b32 $r9 D[$r9]
00005fa1: 8a b8 41 40           mov $r10 0x4041b8
00005fa5: b0 96 00              cmp b32 $r9 0x0
00005fa8: f0 0c 0b              xbit $r0 $flags z
00005fab: 7e 97 02 00           lcall 0x297
00005faf: 89 00 0e 00           mov $r9 0xe00
00005fb3: 98 99 22              ld b32 $r9 D[$r9+0x88]
00005fb6: f0 94 0f              and $r9 0xf
00005fb9: b0 91 10              st b32 D[$sp+0x40] $r9
00005fbc: b3 00 00 3a           bra b32 $r0 0x0 e 0x5ff6
00005fc0: 89 bc 03 00           mov $r9 0x3bc
00005fc4: bf 9d                 ld b32 $r13 D[$r9]
00005fc6: 0a 01                 mov $r10 0x1
00005fc8: 8c 28 03 00           mov $r12 0x328
00005fcc: b2 ab                 mov b32 $r11 $r10
00005fce: 7e e1 07 00           lcall 0x7e1
00005fd2: 89 08 04 00           mov $r9 0x408
00005fd6: bf 9d                 ld b32 $r13 D[$r9]
00005fd8: 0a 01                 mov $r10 0x1
00005fda: 0b 03                 mov $r11 0x3
00005fdc: 8c c0 03 00           mov $r12 0x3c0
00005fe0: 7e e1 07 00           lcall 0x7e1
00005fe4: 89 28 04 00           mov $r9 0x428
00005fe8: bf 9d                 ld b32 $r13 D[$r9]
00005fea: 0a 15                 mov $r10 0x15
00005fec: 0b 04                 mov $r11 0x4
00005fee: 8c 1c 04 00           mov $r12 0x41c
00005ff2: 7e e1 07 00           lcall 0x7e1
00005ff6: 7e 75 21 00         B lcall 0x2175
00005ffa: b3 00 00 17           bra b32 $r0 0x0 e 0x6011
00005ffe: 89 0c 13 00           mov $r9 0x130c
00006002: bf 99                 ld b32 $r9 D[$r9]
00006004: 92 99 01              sub b32 $r9 $r9 0x1
00006007: b0 96 01              cmp b32 $r9 0x1
0000600a: f4 0c 07              bra a 0x6011
0000600d: 7e fe 34 00           lcall 0x34fe
00006011: df 00 00 02 3d      B mov $r15 0x3d020000
00006016: 89 00 2a 02           mov $r9 0x22a00
0000601a: fa 9f 00              iowr I[$r9] $r15
0000601d: 7e 19 2c 00           lcall 0x2c19
00006021: 89 24 13 00           mov $r9 0x1324
00006025: bf 99                 ld b32 $r9 D[$r9]
00006027: b3 94 00 11           bra b32 $r9 0x0 ne 0x6038
0000602b: b4 f0 10              ld b32 $r15 D[$sp+0x40]
0000602e: b3 f4 01 0a           bra b32 $r15 0x1 ne 0x6038
00006032: b2 fa                 mov b32 $r10 $r15
00006034: 7e c0 47 00           lcall 0x47c0
00006038: 89 e0 12 00         B mov $r9 0x12e0
0000603c: bf 9a                 ld b32 $r10 D[$r9]
0000603e: 89 e4 12 00           mov $r9 0x12e4
00006042: bf 9b                 ld b32 $r11 D[$r9]
00006044: 89 e8 12 00           mov $r9 0x12e8
00006048: bf 9c                 ld b32 $r12 D[$r9]
0000604a: 7e b9 32 00           lcall 0x32b9
0000604e: df 00 00 08 37        mov $r15 0x37080000
00006053: 89 00 2a 02           mov $r9 0x22a00
00006057: fa 9f 00              iowr I[$r9] $r15
0000605a: 8e 00 0e 00           mov $r14 0xe00
0000605e: 98 e9 3e              ld b32 $r9 D[$r14+0xf8]
00006061: 8f 24 13 00           mov $r15 0x1324
00006065: bf ff                 ld b32 $r15 D[$r15]
00006067: 90 99 01              add b32 $r9 $r9 0x1
0000606a: b5 e9 3e              st b32 D[$r14+0xf8] $r9
0000606d: b3 f4 00 0e           bra b32 $r15 0x0 ne 0x607b
00006071: bd a4                 clear b32 $r10
00006073: 7e 15 04 00           lcall 0x415
00006077: 7e 19 2c 00           lcall 0x2c19
0000607b: 7e 51 07 00         B lcall 0x751
0000607f: df 00 00 04 3b        mov $r15 0x3b040000
00006084: 89 00 2a 02           mov $r9 0x22a00
00006088: fa 9f 00              iowr I[$r9] $r15
0000608b: 89 24 13 00           mov $r9 0x1324
0000608f: bf 99                 ld b32 $r9 D[$r9]
00006091: b3 94 00 08           bra b32 $r9 0x0 ne 0x6099
00006095: 7e fc 23 00           lcall 0x23fc
00006099: df 00 00 08 37      B mov $r15 0x37080000
0000609e: 89 00 2a 02           mov $r9 0x22a00
000060a2: fa 9f 00              iowr I[$r9] $r15
000060a5: bd a4                 clear b32 $r10
000060a7: 7e c6 29 00           lcall 0x29c6
000060ab: 0a 01                 mov $r10 0x1
000060ad: b2 ab                 mov b32 $r11 $r10
000060af: b2 ac                 mov b32 $r12 $r10
000060b1: 7e 7b 0c 00           lcall 0xc7b
000060b5: 7e 0c 29 00           lcall 0x290c
000060b9: bd a4                 clear b32 $r10
000060bb: 7e 88 29 00           lcall 0x2988
000060bf: 89 c0 13 00           mov $r9 0x13c0
000060c3: bf 9f                 ld b32 $r15 D[$r9]
000060c5: 89 00 2e 02           mov $r9 0x22e00
000060c9: fa 9f 00              iowr I[$r9] $r15
000060cc: 0f 04                 mov $r15 0x4
000060ce: b8 99 00 01 00        add b32 $r9 $r9 0x100
000060d3: fa 9f 00              iowr I[$r9] $r15
000060d6: 0f 08                 mov $r15 0x8
000060d8: 89 00 ac 01           mov $r9 0x1ac00
000060dc: fa 9f 00              iowr I[$r9] $r15
000060df: df 00 00 0b 34        mov $r15 0x340b0000
000060e4: b8 99 00 7e 00        add b32 $r9 $r9 0x7e00
000060e9: fa 9f 00              iowr I[$r9] $r15
000060ec: 89 0c 13 00           mov $r9 0x130c
000060f0: bf 99                 ld b32 $r9 D[$r9]
000060f2: 92 99 01              sub b32 $r9 $r9 0x1
000060f5: b0 96 01              cmp b32 $r9 0x1
000060f8: f4 0c 3f              bra a 0x6137
000060fb: 7e 0c 29 00           lcall 0x290c
000060ff: bd a4                 clear b32 $r10
00006101: 7e c6 29 00           lcall 0x29c6
00006105: 0a 01                 mov $r10 0x1
00006107: b2 ab                 mov b32 $r11 $r10
00006109: b2 ac                 mov b32 $r12 $r10
0000610b: 7e f5 0c 00           lcall 0xcf5
0000610f: 7e 0c 29 00           lcall 0x290c
00006113: df 00 00 11 2e        mov $r15 0x2e110000
00006118: 89 00 2a 02           mov $r9 0x22a00
0000611c: fa 9f 00              iowr I[$r9] $r15
0000611f: 7e 57 33 00           lcall 0x3357
00006123: 0a 01                 mov $r10 0x1
00006125: b2 ab                 mov b32 $r11 $r10
00006127: b2 ac                 mov b32 $r12 $r10
00006129: 7e 7b 0c 00           lcall 0xc7b
0000612d: 7e 0c 29 00           lcall 0x290c
00006131: bd a4                 clear b32 $r10
00006133: 7e 88 29 00           lcall 0x2988
00006137: 89 00 0e 00         B mov $r9 0xe00
0000613b: 98 95 04              ld b32 $r5 D[$r9+0x10]
0000613e: b3 59 00 2b 01        bra b32 $r5 0x0 e 0x6269
00006143: 0f 0d                 mov $r15 0xd
00006145: 89 00 ac 01           mov $r9 0x1ac00
00006149: fa 9f 00              iowr I[$r9] $r15
0000614c: 89 00 0e 00           mov $r9 0xe00
00006150: 98 9f 05              ld b32 $r15 D[$r9+0x14]
00006153: 98 90 06              ld b32 $r0 D[$r9+0x18]
00006156: 89 ec 12 00           mov $r9 0x12ec
0000615a: bf 9c                 ld b32 $r12 D[$r9]
0000615c: b6 f5 08              shr b32 $r15 0x8
0000615f: bd b4                 clear b32 $r11
00006161: b6 04 18              shl b32 $r0 0x18
00006164: 90 c9 40              add b32 $r9 $r12 0x40
00006167: f0 94 ff              and $r9 0xff
0000616a: f0 c4 3f              and $r12 0x3f
0000616d: b6 c4 10              shl b32 $r12 0x10
00006170: fd c9 05              or $r12 $r9
00006173: 94 59 03              shl b32 $r9 $r5 0x3
00006176: 90 99 ff              add b32 $r9 $r9 0xff
00006179: 95 97 08              shr b32 $r7 $r9 0x8
0000617c: b4 90 0e              ld b32 $r9 D[$sp+0x38]
0000617f: fd 0f 05              or $r0 $r15
00006182: b2 0a                 mov b32 $r10 $r0
00006184: b6 94 18              shl b32 $r9 0x18
00006187: fd c9 05              or $r12 $r9
0000618a: 7e b9 32 00           lcall 0x32b9
0000618e: df b4 ee ff c0        mov $r15 0xc0ffeeb4
00006193: 89 00 0a 02           mov $r9 0x20a00
00006197: fa 9f 00              iowr I[$r9] $r15
0000619a: fa 90 00              iowr I[$r9] $r0
0000619d: bd 44                 clear b32 $r4
0000619f: bd 34                 clear b32 $r3
000061a1: 08 02                 mov $r8 0x2
000061a3: 86 00 0a 02           mov $r6 0x20a00
000061a7: 3e 09 62 00           lbra 0x6209
000061ab: 09 01               B mov $r9 0x1
000061ad: b0 81 00              st b32 D[$sp] $r8
000061b0: b0 91 01              st b32 D[$sp+0x4] $r9
000061b3: b0 81 02              st b32 D[$sp+0x8] $r8
000061b6: bd a4                 clear b32 $r10
000061b8: 94 3b 08              shl b32 $r11 $r3 0x8
000061bb: 0c 06                 mov $r12 0x6
000061bd: 8d 00 0a 00           mov $r13 0xa00
000061c1: bd e4                 clear b32 $r14
000061c3: 81 00 0a 00           mov $r1 0xa00
000061c7: 7e e1 2d 00           lcall 0x2de1
000061cb: bf 10               B ld b32 $r0 D[$r1]
000061cd: 98 12 01              ld b32 $r2 D[$r1+0x4]
000061d0: b2 0a                 mov b32 $r10 $r0
000061d2: 7e 23 42 00           lcall 0x4223
000061d6: b3 a0 00 0e           bra b32 $r10 0x0 e 0x61e4
000061da: 0a 23                 mov $r10 0x23
000061dc: 7e c0 05 00           lcall 0x5c0
000061e0: 3e f5 61 00           lbra 0x61f5
000061e4: fa 60 00            B iowr I[$r6] $r0
000061e7: fa 62 00              iowr I[$r6] $r2
000061ea: b2 0a                 mov b32 $r10 $r0
000061ec: b2 2b                 mov b32 $r11 $r2
000061ee: 90 44 01              add b32 $r4 $r4 0x1
000061f1: 7e 37 02 00           lcall 0x237
000061f5: a6 45               B cmp b32 $r4 $r5
000061f7: f4 0b 17              bra e 0x620e
000061fa: 90 11 08              add b32 $r1 $r1 0x8
000061fd: 8e 00 0b 00           mov $r14 0xb00
00006201: a6 1e                 cmp b32 $r1 $r14
00006203: f4 1b c8              bra ne 0x61cb
00006206: 90 33 01              add b32 $r3 $r3 0x1
00006209: a6 37               B cmp b32 $r3 $r7
0000620b: f4 08 a0              bra b 0x61ab
0000620e: 89 e0 12 00         B mov $r9 0x12e0
00006212: bf 9a                 ld b32 $r10 D[$r9]
00006214: 89 e4 12 00           mov $r9 0x12e4
00006218: bf 9b                 ld b32 $r11 D[$r9]
0000621a: 89 e8 12 00           mov $r9 0x12e8
0000621e: bf 9c                 ld b32 $r12 D[$r9]
00006220: 7e b9 32 00           lcall 0x32b9
00006224: bd f4                 clear b32 $r15
00006226: 89 00 0e 00           mov $r9 0xe00
0000622a: 8a fc 09 12           mov $r10 0x1209fc
0000622e: b5 9f 04              st b32 D[$r9+0x10] $r15
00006231: db ce e7 0f 01        mov $r11 0x10fe7ce
00006236: 7e 37 02 00           lcall 0x237
0000623a: 8a fc 11 12           mov $r10 0x1211fc
0000623e: db ce e7 0f 02        mov $r11 0x20fe7ce
00006243: 7e 37 02 00           lcall 0x237
00006247: 89 c0 13 00           mov $r9 0x13c0
0000624b: bf 9f                 ld b32 $r15 D[$r9]
0000624d: 89 00 2e 02           mov $r9 0x22e00
00006251: fa 9f 00              iowr I[$r9] $r15
00006254: 0f 0d                 mov $r15 0xd
00006256: b8 99 00 01 00        add b32 $r9 $r9 0x100
0000625b: fa 9f 00              iowr I[$r9] $r15
0000625e: 0f 08                 mov $r15 0x8
00006260: 89 00 ac 01           mov $r9 0x1ac00
00006264: fa 9f 00              iowr I[$r9] $r15
00006267: 03 01                 mov $r3 0x1
00006269: df 00 00 08 37      B mov $r15 0x37080000
0000626e: 89 00 2a 02           mov $r9 0x22a00
00006272: fa 9f 00              iowr I[$r9] $r15
00006275: 89 5c 14 00           mov $r9 0x145c
00006279: bf 99                 ld b32 $r9 D[$r9]
0000627b: b3 99 00 89 00        bra b32 $r9 0x0 e 0x6304
00006280: 89 20 13 00           mov $r9 0x1320
00006284: bf 99                 ld b32 $r9 D[$r9]
00006286: b3 94 01 7e           bra b32 $r9 0x1 ne 0x6304
0000628a: 89 30 00 00           mov $r9 0x30
0000628e: bf 99                 ld b32 $r9 D[$r9]
00006290: b3 94 01 74           bra b32 $r9 0x1 ne 0x6304
00006294: df 00 00 0f 30        mov $r15 0x300f0000
00006299: 89 00 2a 02           mov $r9 0x22a00
0000629d: fa 9f 00              iowr I[$r9] $r15
000062a0: 7e f8 10 00           lcall 0x10f8
000062a4: 89 84 14 00           mov $r9 0x1484
000062a8: a0 9a                 st b32 D[$r9] $r10
000062aa: 09 ff                 mov $r9 -0x1
000062ac: a6 a9                 cmp b32 $r10 $r9
000062ae: f4 0b 3b              bra e 0x62e9
000062b1: 8d 00 0e 00           mov $r13 0xe00
000062b5: 98 de 0e              ld b32 $r14 D[$r13+0x38]
000062b8: 8f ff 00 ff           mov $r15 -0xff01
000062bc: 94 a9 08              shl b32 $r9 $r10 0x8
000062bf: f1 94 ff ff           and $r9 0xffff
000062c3: fd ef 04              and $r14 $r15
000062c6: fd 9e 05              or $r9 $r14
000062c9: 0a 02                 mov $r10 0x2
000062cb: b5 d9 0e              st b32 D[$r13+0x38] $r9
000062ce: 7e 70 10 00           lcall 0x1070
000062d2: 8d 94 14 00           mov $r13 0x1494
000062d6: bf df                 ld b32 $r15 D[$r13]
000062d8: 4e 00 ff              mov $r14 -0x100
000062db: 10 f9 01              add b8 $r9 $r15 0x1
000062de: fd fe 04              and $r15 $r14
000062e1: f0 94 ff              and $r9 0xff
000062e4: fd 9f 05              or $r9 $r15
000062e7: a0 d9                 st b32 D[$r13] $r9
000062e9: b4 a0 0f            B ld b32 $r10 D[$sp+0x3c]
000062ec: 7e 96 11 00           lcall 0x1196
000062f0: df 00 00 08 37        mov $r15 0x37080000
000062f5: 89 00 2a 02           mov $r9 0x22a00
000062f9: fa 9f 00              iowr I[$r9] $r15
000062fc: 03 01                 mov $r3 0x1
000062fe: b2 30                 mov b32 $r0 $r3
00006300: 3e 06 63 00           lbra 0x6306
00006304: bd 04               B clear b32 $r0
00006306: b4 f0 10            B ld b32 $r15 D[$sp+0x40]
00006309: b3 f0 00 0e           bra b32 $r15 0x0 e 0x6317
0000630d: b3 f0 01 28           bra b32 $r15 0x1 e 0x6335
00006311: bd d4                 clear b32 $r13
00006313: 3e 58 63 00           lbra 0x6358
00006317: 89 94 14 00         B mov $r9 0x1494
0000631b: 98 9f 02              ld b32 $r15 D[$r9+0x8]
0000631e: de ff ff ff 00        mov $r14 0xffffff
00006323: bd d4                 clear b32 $r13
00006325: ff fe e4              and $r14 $r15 $r14
00006328: b6 f5 18              shr b32 $r15 0x18
0000632b: 90 ff 01              add b32 $r15 $r15 0x1
0000632e: b6 f4 18              shl b32 $r15 0x18
00006331: 3e 52 63 00           lbra 0x6352
00006335: 89 94 14 00         B mov $r9 0x1494
00006339: 98 9f 02              ld b32 $r15 D[$r9+0x8]
0000633c: 8e ff 00 ff           mov $r14 -0xff01
00006340: 0d 02                 mov $r13 0x2
00006342: ff fe e4              and $r14 $r15 $r14
00006345: f1 f4 00 ff           and $r15 0xff00
00006349: b8 ff 00 01 00        add b32 $r15 $r15 0x100
0000634e: f1 f4 ff ff           and $r15 0xffff
00006352: fd fe 05            B or $r15 $r14
00006355: b5 9f 02              st b32 D[$r9+0x8] $r15
00006358: b4 90 0d            B ld b32 $r9 D[$sp+0x34]
0000635b: b3 90 01 0e           bra b32 $r9 0x1 e 0x6369
0000635f: b3 90 02 0a           bra b32 $r9 0x2 e 0x6369
00006363: bd b4                 clear b32 $r11
00006365: 3e 6c 63 00           lbra 0x636c
00006369: b4 b0 0d            B ld b32 $r11 D[$sp+0x34]
0000636c: 94 d9 04            B shl b32 $r9 $r13 0x4
0000636f: f0 95 01              or $r9 0x1
00006372: f0 b4 03              and $r11 0x3
00006375: 8a b4 41 40           mov $r10 0x4041b4
00006379: b6 b4 08              shl b32 $r11 0x8
0000637c: ff 9b b5              or $r11 $r9 $r11
0000637f: 7e 37 02 00           lcall 0x237
00006383: b3 30 00 16           bra b32 $r3 0x0 e 0x6399
00006387: df 00 00 0d 32        mov $r15 0x320d0000
0000638c: 89 00 2a 02           mov $r9 0x22a00
00006390: fa 9f 00              iowr I[$r9] $r15
00006393: 0a 02                 mov $r10 0x2
00006395: 7e 4a 2f 00           lcall 0x2f4a
00006399: b3 00 00 14         B bra b32 $r0 0x0 e 0x63ad
0000639d: df 00 00 0f 30        mov $r15 0x300f0000
000063a2: 89 00 2a 02           mov $r9 0x22a00
000063a6: fa 9f 00              iowr I[$r9] $r15
000063a9: 7e e1 37 00           lcall 0x37e1
000063ad: df 00 00 08 37      B mov $r15 0x37080000
000063b2: 89 00 2a 02           mov $r9 0x22a00
000063b6: fa 9f 00              iowr I[$r9] $r15
000063b9: b4 e0 0c              ld b32 $r14 D[$sp+0x30]
000063bc: 89 4c 14 00           mov $r9 0x144c
000063c0: 0f 01                 mov $r15 0x1
000063c2: a0 9e                 st b32 D[$r9] $r14
000063c4: 89 50 14 00           mov $r9 0x1450
000063c8: a0 9f                 st b32 D[$r9] $r15
000063ca: 89 54 14 00           mov $r9 0x1454
000063ce: a0 9f                 st b32 D[$r9] $r15
000063d0: bd f4                 clear b32 $r15
000063d2: 89 00 ac 01           mov $r9 0x1ac00
000063d6: fa 9f 00              iowr I[$r9] $r15
000063d9: 89 c4 14 00           mov $r9 0x14c4
000063dd: bf 99                 ld b32 $r9 D[$r9]
000063df: b3 90 00 35           bra b32 $r9 0x0 e 0x6414
000063e3: 89 b4 14 00           mov $r9 0x14b4
000063e7: bf 99                 ld b32 $r9 D[$r9]
000063e9: b3 90 00 2b           bra b32 $r9 0x0 e 0x6414
000063ed: df 00 00 10 2f        mov $r15 0x2f100000
000063f2: 89 00 2a 02           mov $r9 0x22a00
000063f6: fa 9f 00              iowr I[$r9] $r15
000063f9: 0b 05                 mov $r11 0x5
000063fb: 0a 0e                 mov $r10 0xe
000063fd: 7e 7b 55 00           lcall 0x557b
00006401: b4 a0 0e              ld b32 $r10 D[$sp+0x38]
00006404: 7e ad 56 00           lcall 0x56ad
00006408: df 00 00 08 37        mov $r15 0x37080000
0000640d: 89 00 2a 02           mov $r9 0x22a00
00006411: fa 9f 00              iowr I[$r9] $r15
00006414: bd f4               B clear b32 $r15
00006416: 89 00 0c 01           mov $r9 0x10c00
0000641a: fa 9f 00              iowr I[$r9] $r15
0000641d: 0a 01                 mov $r10 0x1
0000641f: 7e 91 07 00           lcall 0x791
00006423: 89 f0 09 00           mov $r9 0x9f0
00006427: bd f4                 clear b32 $r15
00006429: a0 9f                 st b32 D[$r9] $r15
0000642b: 89 94 14 00           mov $r9 0x1494
0000642f: bf 9f                 ld b32 $r15 D[$r9]
00006431: 89 00 0a 02           mov $r9 0x20a00
00006435: fa 9f 00              iowr I[$r9] $r15
00006438: 89 94 14 00           mov $r9 0x1494
0000643c: 98 9f 01              ld b32 $r15 D[$r9+0x4]
0000643f: 89 00 0b 02           mov $r9 0x20b00
00006443: fa 9f 00              iowr I[$r9] $r15
00006446: 89 94 14 00           mov $r9 0x1494
0000644a: 98 9f 02              ld b32 $r15 D[$r9+0x8]
0000644d: 89 00 0c 02           mov $r9 0x20c00
00006451: fa 9f 00              iowr I[$r9] $r15
00006454: 89 00 0c 00           mov $r9 0xc00
00006458: 98 9f 0d              ld b32 $r15 D[$r9+0x34]
0000645b: 89 00 0d 02           mov $r9 0x20d00
0000645f: fa 9f 00              iowr I[$r9] $r15
00006462: 7e 75 21 00           lcall 0x2175
00006466: 0f 04                 mov $r15 0x4
00006468: 89 00 00 02           mov $r9 0x20000
0000646c: fa 9f 00              iowr I[$r9] $r15
0000646f: df 00 00 00 3f        mov $r15 0x3f000000
00006474: b8 99 00 2a 00        add b32 $r9 $r9 0x2a00
00006479: fa 9f 00            B iowr I[$r9] $r15
0000647c: df 00 00 00 80        mov $r15 0x80000000
00006481: fa 9f 00              iowr I[$r9] $r15
00006484: 8f 00 00 08           mov $r15 0x80000
00006488: b8 99 00 12 02        sub b32 $r9 $r9 0x1200
0000648d: fa 9f 00              iowr I[$r9] $r15
00006490: fe 49 01              mov $r9 $sp
00006493: 90 99 74              add b32 $r9 $r9 0x74
00006496: bf 9f                 ld b32 $r15 D[$r9]
00006498: 89 04 16 00           mov $r9 0x1604
0000649c: bf 99                 ld b32 $r9 D[$r9]
0000649e: a6 f9                 cmp b32 $r15 $r9
000064a0: f4 0b 07              bra e 0x64a7
000064a3: 7e 47 07 00           lcall 0x747
000064a7: f4 30 0c            B add $sp 0xc
000064aa: fb 85 48              mpopaddret $r8 0x48

000064ad: 8f 04 16 00        C  mov $r15 0x1604
000064b1: bf ff                 ld b32 $r15 D[$r15]
000064b3: f4 30 c8              add $sp -0x38
000064b6: f9 82                 mpush $r8
000064b8: f4 30 f4              add $sp -0xc
000064bb: fe 49 01              mov $r9 $sp
000064be: 90 99 64              add b32 $r9 $r9 0x64
000064c1: b2 b0                 mov b32 $r0 $r11
000064c3: a0 9f                 st b32 D[$r9] $r15
000064c5: b2 c7                 mov b32 $r7 $r12
000064c7: b2 d5                 mov b32 $r5 $r13
000064c9: 8f 00 00 04           mov $r15 0x40000
000064cd: 89 00 12 02           mov $r9 0x21200
000064d1: fa 9f 00              iowr I[$r9] $r15
000064d4: 8f 00 00 40           mov $r15 0x400000
000064d8: b8 99 00 18 00        add b32 $r9 $r9 0x1800
000064dd: fa 9f 00              iowr I[$r9] $r15
000064e0: df 00 00 08 37        mov $r15 0x37080000
000064e5: fa 9f 00              iowr I[$r9] $r15
000064e8: 7e 51 47 00           lcall 0x4751
000064ec: 0f 01                 mov $r15 0x1
000064ee: 89 00 ac 01           mov $r9 0x1ac00
000064f2: fa 9f 00              iowr I[$r9] $r15
000064f5: d9 ff ff ff 3f        mov $r9 0x3fffffff
000064fa: ff 09 94              and $r9 $r0 $r9
000064fd: b0 91 0c              st b32 D[$sp+0x30] $r9
00006500: d9 ff ff ff 0f        mov $r9 0xfffffff
00006505: bd f4                 clear b32 $r15
00006507: ff 09 34              and $r3 $r0 $r9
0000650a: 89 00 de 02           mov $r9 0x2de00
0000650e: ff 9f 9f              iord $r9 I[$r9+$r15*0x4]
00006511: c4 96 3f              and $r6 $r9 0x3f
00006514: b3 59 00 fd 0a        bra b32 $r5 0x0 e 0x7011
00006519: 89 00 05 02           mov $r9 0x20500
0000651d: ff 9f 9f              iord $r9 I[$r9+$r15*0x4]
00006520: 8e c4 13 00           mov $r14 0x13c4
00006524: b3 94 0f 0c           bra b32 $r9 0xf ne 0x6530
00006528: 09 01                 mov $r9 0x1
0000652a: a0 e9                 st b32 D[$r14] $r9
0000652c: 3e 32 65 00           lbra 0x6532
00006530: a0 ef               B st b32 D[$r14] $r15
00006532: bd f4               B clear b32 $r15
00006534: 89 00 08 02           mov $r9 0x20800
00006538: ff 9f 9f              iord $r9 I[$r9+$r15*0x4]
0000653b: 8e c8 13 00           mov $r14 0x13c8
0000653f: b3 94 0f 0c           bra b32 $r9 0xf ne 0x654b
00006543: 09 01                 mov $r9 0x1
00006545: a0 e9                 st b32 D[$r14] $r9
00006547: 3e 5d 65 00           lbra 0x655d
0000654b: a0 ef               B st b32 D[$r14] $r15
0000654d: 3e 5d 65 00           lbra 0x655d
00006551: 89 4c 14 00         B mov $r9 0x144c
00006555: bf 99                 ld b32 $r9 D[$r9]
00006557: a6 90                 cmp b32 $r9 $r0
00006559: f5 0b 13 01           bra e 0x666c
0000655d: df 00 00 18 27      B mov $r15 0x27180000
00006562: 89 00 2a 02           mov $r9 0x22a00
00006566: fa 9f 00              iowr I[$r9] $r15
00006569: bd a4                 clear b32 $r10
0000656b: 94 62 18              shl b32 $r2 $r6 0x18
0000656e: bd b4                 clear b32 $r11
00006570: c5 2c 40              or $r12 $r2 0x40
00006573: 7e b9 32 00           lcall 0x32b9
00006577: 09 01                 mov $r9 0x1
00006579: b0 91 01              st b32 D[$sp+0x4] $r9
0000657c: b0 91 00              st b32 D[$sp] $r9
0000657f: 09 02                 mov $r9 0x2
00006581: c7 0e 3c              extr $r14 $r0 0x1c:0x1d
00006584: 94 3a 04              shl b32 $r10 $r3 0x4
00006587: b0 91 02              st b32 D[$sp+0x8] $r9
0000658a: 8d 00 0a 00           mov $r13 0xa00
0000658e: 4b 00 02              mov $r11 0x200
00006591: 0c 06                 mov $r12 0x6
00006593: 7e e1 2d 00           lcall 0x2de1
00006597: 89 00 0a 00           mov $r9 0xa00
0000659b: 98 9e 04              ld b32 $r14 D[$r9+0x10]
0000659e: bf 9d                 ld b32 $r13 D[$r9]
000065a0: 98 9c 05              ld b32 $r12 D[$r9+0x14]
000065a3: 98 91 06              ld b32 $r1 D[$r9+0x18]
000065a6: 98 9f 01              ld b32 $r15 D[$r9+0x4]
000065a9: 49 00 f0              mov $r9 -0x1000
000065ac: fd d9 04              and $r13 $r9
000065af: fd e9 04              and $r14 $r9
000065b2: 89 e0 12 00           mov $r9 0x12e0
000065b6: b6 c4 18              shl b32 $r12 0x18
000065b9: b6 e5 08              shr b32 $r14 0x8
000065bc: fd ec 05              or $r14 $r12
000065bf: a0 9e                 st b32 D[$r9] $r14
000065c1: 89 e4 12 00           mov $r9 0x12e4
000065c5: bd 04                 clear b32 $r0
000065c7: a0 90                 st b32 D[$r9] $r0
000065c9: 89 48 14 00           mov $r9 0x1448
000065cd: b6 f4 18              shl b32 $r15 0x18
000065d0: b6 d5 08              shr b32 $r13 0x8
000065d3: fd df 05              or $r13 $r15
000065d6: a0 9d                 st b32 D[$r9] $r13
000065d8: 89 ec 12 00           mov $r9 0x12ec
000065dc: 90 1b 40              add b32 $r11 $r1 0x40
000065df: a0 91                 st b32 D[$r9] $r1
000065e1: f0 b4 ff              and $r11 0xff
000065e4: 89 e8 12 00           mov $r9 0x12e8
000065e8: c4 1f 3f              and $r15 $r1 0x3f
000065eb: b6 f4 10              shl b32 $r15 0x10
000065ee: fd fb 05              or $r15 $r11
000065f1: fd f2 05              or $r15 $r2
000065f4: b2 ea                 mov b32 $r10 $r14
000065f6: b2 fc                 mov b32 $r12 $r15
000065f8: a0 9f                 st b32 D[$r9] $r15
000065fa: bd b4                 clear b32 $r11
000065fc: 7e b9 32 00           lcall 0x32b9
00006600: 89 50 14 00           mov $r9 0x1450
00006604: a0 90                 st b32 D[$r9] $r0
00006606: 89 4c 14 00           mov $r9 0x144c
0000660a: a0 90                 st b32 D[$r9] $r0
0000660c: 89 54 14 00           mov $r9 0x1454
00006610: df 00 00 0d 32        mov $r15 0x320d0000
00006615: a0 90                 st b32 D[$r9] $r0
00006617: 89 00 2a 02           mov $r9 0x22a00
0000661b: fa 9f 00              iowr I[$r9] $r15
0000661e: 0a 02                 mov $r10 0x2
00006620: 7e c1 2e 00           lcall 0x2ec1
00006624: 7e cf 31 00           lcall 0x31cf
00006628: df b0 ee ff c0        mov $r15 0xc0ffeeb0
0000662d: 89 00 0a 02           mov $r9 0x20a00
00006631: fa 9f 00              iowr I[$r9] $r15
00006634: 89 00 0e 00           mov $r9 0xe00
00006638: 98 9f 03              ld b32 $r15 D[$r9+0xc]
0000663b: 89 44 14 00           mov $r9 0x1444
0000663f: f0 f4 3f              and $r15 0x3f
00006642: a0 9f                 st b32 D[$r9] $r15
00006644: 89 00 0a 02           mov $r9 0x20a00
00006648: fa 9f 00              iowr I[$r9] $r15
0000664b: 01 01                 mov $r1 0x1
0000664d: b3 fd 21 9d 00        bra b32 $r15 0x21 ne 0x66ea
00006652: d9 00 00 14 2b        mov $r9 0x2b140000
00006657: 8f 00 2a 02           mov $r15 0x22a00
0000665b: fa f9 00              iowr I[$r15] $r9
0000665e: 89 ec 12 00           mov $r9 0x12ec
00006662: b2 6b                 mov b32 $r11 $r6
00006664: bf 9a                 ld b32 $r10 D[$r9]
00006666: 01 01                 mov $r1 0x1
00006668: 3e e0 66 00           lbra 0x66e0
0000666c: 89 e0 12 00         B mov $r9 0x12e0
00006670: bf 9a                 ld b32 $r10 D[$r9]
00006672: 89 e4 12 00           mov $r9 0x12e4
00006676: bf 9b                 ld b32 $r11 D[$r9]
00006678: 89 e8 12 00           mov $r9 0x12e8
0000667c: bf 9c                 ld b32 $r12 D[$r9]
0000667e: 7e b9 32 00           lcall 0x32b9
00006682: 89 54 14 00           mov $r9 0x1454
00006686: bf 99                 ld b32 $r9 D[$r9]
00006688: b3 94 00 60           bra b32 $r9 0x0 ne 0x66e8
0000668c: df 00 00 0d 32        mov $r15 0x320d0000
00006691: 89 00 2a 02           mov $r9 0x22a00
00006695: fa 9f 00              iowr I[$r9] $r15
00006698: 0a 02                 mov $r10 0x2
0000669a: 7e c1 2e 00           lcall 0x2ec1
0000669e: 7e cf 31 00           lcall 0x31cf
000066a2: df b0 ee ff c0        mov $r15 0xc0ffeeb0
000066a7: 89 00 0a 02           mov $r9 0x20a00
000066ab: fa 9f 00              iowr I[$r9] $r15
000066ae: 89 00 0e 00           mov $r9 0xe00
000066b2: 98 99 03              ld b32 $r9 D[$r9+0xc]
000066b5: 8f 44 14 00           mov $r15 0x1444
000066b9: f0 94 3f              and $r9 0x3f
000066bc: a0 f9                 st b32 D[$r15] $r9
000066be: 8f 00 0a 02           mov $r15 0x20a00
000066c2: fa f9 00              iowr I[$r15] $r9
000066c5: b3 94 21 23           bra b32 $r9 0x21 ne 0x66e8
000066c9: d9 00 00 14 2b        mov $r9 0x2b140000
000066ce: b8 ff 00 20 00        add b32 $r15 $r15 0x2000
000066d3: fa f9 00              iowr I[$r15] $r9
000066d6: 89 ec 12 00           mov $r9 0x12ec
000066da: bf 9a                 ld b32 $r10 D[$r9]
000066dc: b2 6b                 mov b32 $r11 $r6
000066de: bd 14                 clear b32 $r1
000066e0: 7e 6f 52 00         B lcall 0x526f
000066e4: 3e ea 66 00           lbra 0x66ea
000066e8: bd 14               B clear b32 $r1
000066ea: df 00 00 08 37      B mov $r15 0x37080000
000066ef: 89 00 2a 02           mov $r9 0x22a00
000066f3: fa 9f 00              iowr I[$r9] $r15
000066f6: bd f4                 clear b32 $r15
000066f8: 89 00 0e 00           mov $r9 0xe00
000066fc: b5 9f 38              st b32 D[$r9+0xe0] $r15
000066ff: df 00 00 0f 30        mov $r15 0x300f0000
00006704: 89 00 2a 02           mov $r9 0x22a00
00006708: fa 9f 00              iowr I[$r9] $r15
0000670b: 7e a0 38 00           lcall 0x38a0
0000670f: 8f 00 0e 00           mov $r15 0xe00
00006713: 98 f9 20              ld b32 $r9 D[$r15+0x80]
00006716: 98 fe 0e              ld b32 $r14 D[$r15+0x38]
00006719: 8f 20 13 00           mov $r15 0x1320
0000671d: f0 94 03              and $r9 0x3
00006720: a0 f9                 st b32 D[$r15] $r9
00006722: 89 30 00 00           mov $r9 0x30
00006726: f0 e4 ff              and $r14 0xff
00006729: df 00 00 08 37        mov $r15 0x37080000
0000672e: a0 9e                 st b32 D[$r9] $r14
00006730: 89 00 2a 02           mov $r9 0x22a00
00006734: fa 9f 00              iowr I[$r9] $r15
00006737: 89 94 14 00           mov $r9 0x1494
0000673b: bf 9f                 ld b32 $r15 D[$r9]
0000673d: 89 00 0a 02           mov $r9 0x20a00
00006741: fa 9f 00              iowr I[$r9] $r15
00006744: 89 94 14 00           mov $r9 0x1494
00006748: 98 9f 01              ld b32 $r15 D[$r9+0x4]
0000674b: 89 00 0b 02           mov $r9 0x20b00
0000674f: fa 9f 00              iowr I[$r9] $r15
00006752: 89 94 14 00           mov $r9 0x1494
00006756: 98 9f 02              ld b32 $r15 D[$r9+0x8]
00006759: 89 00 0c 02           mov $r9 0x20c00
0000675d: fa 9f 00              iowr I[$r9] $r15
00006760: 89 00 0e 00           mov $r9 0xe00
00006764: 98 99 23              ld b32 $r9 D[$r9+0x8c]
00006767: 8f 24 13 00           mov $r15 0x1324
0000676b: f0 94 03              and $r9 0x3
0000676e: b3 90 01 06           bra b32 $r9 0x1 e 0x6774
00006772: bd 94                 clear b32 $r9
00006774: a0 f9               B st b32 D[$r15] $r9
00006776: 8a b8 41 40           mov $r10 0x4041b8
0000677a: 7e 97 02 00           lcall 0x297
0000677e: 89 00 0e 00           mov $r9 0xe00
00006782: 98 9e 20              ld b32 $r14 D[$r9+0x80]
00006785: 98 9d 21              ld b32 $r13 D[$r9+0x84]
00006788: 98 99 3c              ld b32 $r9 D[$r9+0xf0]
0000678b: 8f c0 13 00           mov $r15 0x13c0
0000678f: f0 e4 03              and $r14 0x3
00006792: f0 d4 03              and $r13 0x3
00006795: a0 f9                 st b32 D[$r15] $r9
00006797: 89 5c 14 00           mov $r9 0x145c
0000679b: bf 99                 ld b32 $r9 D[$r9]
0000679d: 8f 20 13 00           mov $r15 0x1320
000067a1: a0 fe                 st b32 D[$r15] $r14
000067a3: b0 e6 01              cmp b32 $r14 0x1
000067a6: f0 0c 0b              xbit $r0 $flags z
000067a9: b3 90 00 14           bra b32 $r9 0x0 e 0x67bd
000067ad: 89 30 00 00           mov $r9 0x30
000067b1: bf 99                 ld b32 $r9 D[$r9]
000067b3: b3 90 02 0a           bra b32 $r9 0x2 e 0x67bd
000067b7: bd 94                 clear b32 $r9
000067b9: bd 04                 clear b32 $r0
000067bb: a0 f9                 st b32 D[$r15] $r9
000067bd: b3 d4 01 0b         B bra b32 $r13 0x1 ne 0x67c8
000067c1: f0 05 02              or $r0 0x2
000067c4: 3e cf 67 00           lbra 0x67cf
000067c8: b3 d4 02 07         B bra b32 $r13 0x2 ne 0x67cf
000067cc: f0 05 04              or $r0 0x4
000067cf: df 00 00 10 2f      B mov $r15 0x2f100000
000067d4: 89 00 2a 02           mov $r9 0x22a00
000067d8: fa 9f 00              iowr I[$r9] $r15
000067db: 89 c0 13 00           mov $r9 0x13c0
000067df: bf 9c                 ld b32 $r12 D[$r9]
000067e1: 89 ec 12 00           mov $r9 0x12ec
000067e5: bf 9d                 ld b32 $r13 D[$r9]
000067e7: b2 3b                 mov b32 $r11 $r3
000067e9: bd a4                 clear b32 $r10
000067eb: b2 6e                 mov b32 $r14 $r6
000067ed: 7e 26 57 00           lcall 0x5726
000067f1: b3 54 00 0c           bra b32 $r5 0x0 ne 0x67fd
000067f5: 0a 05                 mov $r10 0x5
000067f7: bd b4                 clear b32 $r11
000067f9: 7e 17 0d 00           lcall 0xd17
000067fd: 0f 02               B mov $r15 0x2
000067ff: 89 00 ac 01           mov $r9 0x1ac00
00006803: fa 9f 00              iowr I[$r9] $r15
00006806: df 00 00 03 3c        mov $r15 0x3c030000
0000680b: b8 99 00 7e 00        add b32 $r9 $r9 0x7e00
00006810: fa 9f 00              iowr I[$r9] $r15
00006813: b2 0a                 mov b32 $r10 $r0
00006815: 7e 82 0e 00           lcall 0xe82
00006819: b3 14 01 3e           bra b32 $r1 0x1 ne 0x6857
0000681d: df 00 00 0e 31        mov $r15 0x310e0000
00006822: 89 00 2a 02           mov $r9 0x22a00
00006826: fa 9f 00              iowr I[$r9] $r15
00006829: 89 ec 12 00           mov $r9 0x12ec
0000682d: bf 9b                 ld b32 $r11 D[$r9]
0000682f: 8a 14 a8 41           mov $r10 0x41a814
00006833: 7e 37 02 00           lcall 0x237
00006837: 89 e0 12 00           mov $r9 0x12e0
0000683b: bf 9b                 ld b32 $r11 D[$r9]
0000683d: 0a 13                 mov $r10 0x13
0000683f: 7e c5 0c 00           lcall 0xcc5
00006843: 7e fc 23 00           lcall 0x23fc
00006847: 89 e4 12 00           mov $r9 0x12e4
0000684b: bf 9b                 ld b32 $r11 D[$r9]
0000684d: 0a 1e                 mov $r10 0x1e
0000684f: 7e c5 0c 00           lcall 0xcc5
00006853: 7e fc 23 00           lcall 0x23fc
00006857: b3 54 00 0c         B bra b32 $r5 0x0 ne 0x6863
0000685b: 0a 6b                 mov $r10 0x6b
0000685d: bd b4                 clear b32 $r11
0000685f: 7e c5 0c 00           lcall 0xcc5
00006863: df 00 00 08 37      B mov $r15 0x37080000
00006868: 89 00 2a 02           mov $r9 0x22a00
0000686c: fa 9f 00              iowr I[$r9] $r15
0000686f: df 00 00 03 3c        mov $r15 0x3c030000
00006874: fa 9f 00              iowr I[$r9] $r15
00006877: b0 56 00              cmp b32 $r5 0x0
0000687a: f0 ac 0b              xbit $r10 $flags z
0000687d: 7e 02 47 00           lcall 0x4702
00006881: 7e 51 47 00           lcall 0x4751
00006885: bd f4                 clear b32 $r15
00006887: 89 00 00 03           mov $r9 0x30000
0000688b: ff 9f 9f              iord $r9 I[$r9+$r15*0x4]
0000688e: 8f c4 14 00           mov $r15 0x14c4
00006892: bf fe                 ld b32 $r14 D[$r15]
00006894: c7 90 06              extr $r0 $r9 0x6:0x6
00006897: 94 0f 08              shl b32 $r15 $r0 0x8
0000689a: c7 93 3c              extr $r3 $r9 0x1c:0x1d
0000689d: 95 94 1e              shr b32 $r4 $r9 0x1e
000068a0: 94 49 04              shl b32 $r9 $r4 0x4
000068a3: fd 93 05              or $r9 $r3
000068a6: fd 9f 05              or $r9 $r15
000068a9: 8f 00 0e 00           mov $r15 0xe00
000068ad: b5 f9 22              st b32 D[$r15+0x88] $r9
000068b0: b3 e0 00 52           bra b32 $r14 0x0 e 0x6902
000068b4: 89 b4 14 00           mov $r9 0x14b4
000068b8: bf 99                 ld b32 $r9 D[$r9]
000068ba: b3 90 00 48           bra b32 $r9 0x0 e 0x6902
000068be: df 00 00 10 2f        mov $r15 0x2f100000
000068c3: 89 00 2a 02           mov $r9 0x22a00
000068c7: fa 9f 00              iowr I[$r9] $r15
000068ca: b3 34 01 0c           bra b32 $r3 0x1 ne 0x68d6
000068ce: 0a 08                 mov $r10 0x8
000068d0: 0b 0b                 mov $r11 0xb
000068d2: 3e f2 68 00           lbra 0x68f2
000068d6: b3 44 01 0c         B bra b32 $r4 0x1 ne 0x68e2
000068da: 0a 08                 mov $r10 0x8
000068dc: 0b 0c                 mov $r11 0xc
000068de: 3e f2 68 00           lbra 0x68f2
000068e2: b3 44 02 0c         B bra b32 $r4 0x2 ne 0x68ee
000068e6: 0a 08                 mov $r10 0x8
000068e8: 0b 0d                 mov $r11 0xd
000068ea: 3e f2 68 00           lbra 0x68f2
000068ee: 0a 08               B mov $r10 0x8
000068f0: 0b 0a                 mov $r11 0xa
000068f2: 7e 7b 55 00         B lcall 0x557b
000068f6: df 00 00 08 37        mov $r15 0x37080000
000068fb: 89 00 2a 02           mov $r9 0x22a00
000068ff: fa 9f 00              iowr I[$r9] $r15
00006902: 0f 05               B mov $r15 0x5
00006904: b3 30 01 2e           bra b32 $r3 0x1 e 0x6932
00006908: b3 44 01 12           bra b32 $r4 0x1 ne 0x691a
0000690c: bd f4                 clear b32 $r15
0000690e: 89 24 13 00           mov $r9 0x1324
00006912: a0 9f                 st b32 D[$r9] $r15
00006914: 0f 07                 mov $r15 0x7
00006916: 3e 32 69 00           lbra 0x6932
0000691a: 8f 24 13 00         B mov $r15 0x1324
0000691e: b3 44 02 0e           bra b32 $r4 0x2 ne 0x692c
00006922: bd 94                 clear b32 $r9
00006924: a0 f9                 st b32 D[$r15] $r9
00006926: 0f 06                 mov $r15 0x6
00006928: 3e 32 69 00           lbra 0x6932
0000692c: bd 94               B clear b32 $r9
0000692e: a0 f9                 st b32 D[$r15] $r9
00006930: 0f 04                 mov $r15 0x4
00006932: 89 00 ac 01         B mov $r9 0x1ac00
00006936: fa 9f 00              iowr I[$r9] $r15
00006939: df 00 ee ff c0        mov $r15 0xc0ffee00
0000693e: 89 00 0a 02           mov $r9 0x20a00
00006942: fa 9f 00              iowr I[$r9] $r15
00006945: 89 24 13 00           mov $r9 0x1324
00006949: bf 9f                 ld b32 $r15 D[$r9]
0000694b: 89 00 0a 02           mov $r9 0x20a00
0000694f: fa 9f 00              iowr I[$r9] $r15
00006952: 0f 01                 mov $r15 0x1
00006954: b3 04 00 06           bra b32 $r0 0x0 ne 0x695a
00006958: bd f4                 clear b32 $r15
0000695a: 89 00 dc 02         B mov $r9 0x2dc00
0000695e: fa 9f 00              iowr I[$r9] $r15
00006961: 89 5c 14 00           mov $r9 0x145c
00006965: bf 99                 ld b32 $r9 D[$r9]
00006967: b3 90 00 69           bra b32 $r9 0x0 e 0x69d0
0000696b: b3 34 00 65           bra b32 $r3 0x0 ne 0x69d0
0000696f: 89 30 00 00           mov $r9 0x30
00006973: bf 99                 ld b32 $r9 D[$r9]
00006975: b3 94 02 5b           bra b32 $r9 0x2 ne 0x69d0
00006979: df 00 00 0f 30        mov $r15 0x300f0000
0000697e: 89 00 2a 02           mov $r9 0x22a00
00006982: fa 9f 00              iowr I[$r9] $r15
00006985: 0a 01                 mov $r10 0x1
00006987: 7e 70 10 00           lcall 0x1070
0000698b: 89 00 0e 00           mov $r9 0xe00
0000698f: 8d 94 14 00           mov $r13 0x1494
00006993: 98 9a 0e              ld b32 $r10 D[$r9+0x38]
00006996: bf d9                 ld b32 $r9 D[$r13]
00006998: 8f 84 14 00           mov $r15 0x1484
0000699c: 8e ff 00 ff           mov $r14 -0xff01
000069a0: c7 aa e8              extr $r10 $r10 0x8:0xf
000069a3: ff 9e e4              and $r14 $r9 $r14
000069a6: f1 94 00 ff           and $r9 0xff00
000069aa: b8 99 00 01 00        add b32 $r9 $r9 0x100
000069af: f1 94 ff ff           and $r9 0xffff
000069b3: fd 9e 05              or $r9 $r14
000069b6: a0 fa                 st b32 D[$r15] $r10
000069b8: a0 d9                 st b32 D[$r13] $r9
000069ba: 7e 8e 10 00           lcall 0x108e
000069be: df 00 00 08 37        mov $r15 0x37080000
000069c3: 89 00 2a 02           mov $r9 0x22a00
000069c7: fa 9f 00              iowr I[$r9] $r15
000069ca: 08 01                 mov $r8 0x1
000069cc: 3e d2 69 00           lbra 0x69d2
000069d0: bd 84               B clear b32 $r8
000069d2: df 00 00 11 2e      B mov $r15 0x2e110000
000069d7: 89 00 2a 02           mov $r9 0x22a00
000069db: fa 9f 00              iowr I[$r9] $r15
000069de: 89 00 0e 00           mov $r9 0xe00
000069e2: 98 9f 0a              ld b32 $r15 D[$r9+0x28]
000069e5: 89 10 13 00           mov $r9 0x1310
000069e9: c7 fe 43              extr $r14 $r15 0x3:0x5
000069ec: f0 f4 07              and $r15 0x7
000069ef: a0 9e                 st b32 D[$r9] $r14
000069f1: 89 0c 13 00           mov $r9 0x130c
000069f5: a0 9f                 st b32 D[$r9] $r15
000069f7: df 00 00 08 37        mov $r15 0x37080000
000069fc: 89 00 2a 02           mov $r9 0x22a00
00006a00: fa 9f 00              iowr I[$r9] $r15
00006a03: bd a4                 clear b32 $r10
00006a05: 7e c6 29 00           lcall 0x29c6
00006a09: 0a 01                 mov $r10 0x1
00006a0b: b2 ab                 mov b32 $r11 $r10
00006a0d: b2 ac                 mov b32 $r12 $r10
00006a0f: 7e f5 0c 00           lcall 0xcf5
00006a13: 7e 0c 29 00           lcall 0x290c
00006a17: bd a4                 clear b32 $r10
00006a19: 7e 88 29 00           lcall 0x2988
00006a1d: b3 44 02 3d           bra b32 $r4 0x2 ne 0x6a5a
00006a21: 8a c4 9a 41           mov $r10 0x419ac4
00006a25: bd b4                 clear b32 $r11
00006a27: bd 14                 clear b32 $r1
00006a29: 7e 37 02 00           lcall 0x237
00006a2d: 80 34 43 50           mov $r0 0x504334
00006a31: 82 a0 14 00           mov $r2 0x14a0
00006a35: 3e 53 6a 00           lbra 0x6a53
00006a39: b2 0a               B mov b32 $r10 $r0
00006a3b: 7e 97 02 00           lcall 0x297
00006a3f: 90 11 01              add b32 $r1 $r1 0x1
00006a42: c6 ab 01              xor $r11 $r10 0x1
00006a45: b8 0a 00 28 02        sub b32 $r10 $r0 0x2800
00006a4a: b8 00 00 80 00        add b32 $r0 $r0 0x8000
00006a4f: 7e 37 02 00           lcall 0x237
00006a53: bf 29               B ld b32 $r9 D[$r2]
00006a55: a6 19                 cmp b32 $r1 $r9
00006a57: f4 08 e2              bra b 0x6a39
00006a5a: 89 24 00 00         B mov $r9 0x24
00006a5e: bf 9a                 ld b32 $r10 D[$r9]
00006a60: 7e 14 01 00           lcall 0x114
00006a64: b2 5a                 mov b32 $r10 $r5
00006a66: b2 7b                 mov b32 $r11 $r7
00006a68: b2 3c                 mov b32 $r12 $r3
00006a6a: b2 4d                 mov b32 $r13 $r4
00006a6c: 7e b4 53 00           lcall 0x53b4
00006a70: 89 24 13 00           mov $r9 0x1324
00006a74: bf 99                 ld b32 $r9 D[$r9]
00006a76: b3 9d 00 19 01        bra b32 $r9 0x0 ne 0x6b8f
00006a7b: b3 3d 01 14 01        bra b32 $r3 0x1 ne 0x6b8f
00006a80: 89 5c 14 00           mov $r9 0x145c
00006a84: bf 99                 ld b32 $r9 D[$r9]
00006a86: b3 99 00 cb 00        bra b32 $r9 0x0 e 0x6b51
00006a8b: 89 30 00 00           mov $r9 0x30
00006a8f: bf 99                 ld b32 $r9 D[$r9]
00006a91: b3 9d 02 c0 00        bra b32 $r9 0x2 ne 0x6b51
00006a96: df 00 00 0f 30        mov $r15 0x300f0000
00006a9b: 89 00 2a 02           mov $r9 0x22a00
00006a9f: fa 9f 00              iowr I[$r9] $r15
00006aa2: 82 00 0c 00           mov $r2 0xc00
00006aa6: 98 29 04              ld b32 $r9 D[$r2+0x10]
00006aa9: 8f 74 14 00           mov $r15 0x1474
00006aad: bf 22                 ld b32 $r2 D[$r2]
00006aaf: fe 40 01              mov $r0 $sp
00006ab2: a0 f9                 st b32 D[$r15] $r9
00006ab4: 89 00 0e 00           mov $r9 0xe00
00006ab8: 98 9d 0e              ld b32 $r13 D[$r9+0x38]
00006abb: 89 5c 14 00           mov $r9 0x145c
00006abf: bf fb                 ld b32 $r11 D[$r15]
00006ac1: bf 9f                 ld b32 $r15 D[$r9]
00006ac3: 89 60 14 00           mov $r9 0x1460
00006ac7: bf 99                 ld b32 $r9 D[$r9]
00006ac9: 90 00 54              add b32 $r0 $r0 0x54
00006acc: c7 dd e8              extr $r13 $r13 0x8:0xf
00006acf: 95 fc 10              shr b32 $r12 $r15 0x10
00006ad2: 95 9e 10              shr b32 $r14 $r9 0x10
00006ad5: f1 94 ff ff           and $r9 0xffff
00006ad9: f1 f4 ff ff           and $r15 0xffff
00006add: b5 09 02              st b32 D[$r0+0x8] $r9
00006ae0: 89 84 14 00           mov $r9 0x1484
00006ae4: b5 0e 03              st b32 D[$r0+0xc] $r14
00006ae7: a0 9d                 st b32 D[$r9] $r13
00006ae9: b2 da                 mov b32 $r10 $r13
00006aeb: b5 0c 01              st b32 D[$r0+0x4] $r12
00006aee: a0 0f                 st b32 D[$r0] $r15
00006af0: 81 78 14 00           mov $r1 0x1478
00006af4: a0 12                 st b32 D[$r1] $r2
00006af6: 7e ce 77 00           lcall 0x77ce
00006afa: bc a2 a0              add b32 $r10 $r10 $r2
00006afd: 95 a9 18              shr b32 $r9 $r10 0x18
00006b00: fe 4f 01              mov $r15 $sp
00006b03: b6 a5 08              shr b32 $r10 0x8
00006b06: 90 ff 44              add b32 $r15 $r15 0x44
00006b09: b5 f9 01              st b32 D[$r15+0x4] $r9
00006b0c: e4 a9 ff ff           and $r9 $r10 0xffff
00006b10: a0 f9                 st b32 D[$r15] $r9
00006b12: bd 94                 clear b32 $r9
00006b14: b5 f9 02              st b32 D[$r15+0x8] $r9
00006b17: b5 f9 03              st b32 D[$r15+0xc] $r9
00006b1a: 89 70 14 00           mov $r9 0x1470
00006b1e: b2 fc                 mov b32 $r12 $r15
00006b20: a0 9a                 st b32 D[$r9] $r10
00006b22: b2 0b                 mov b32 $r11 $r0
00006b24: fe 40 01              mov $r0 $sp
00006b27: 90 00 34              add b32 $r0 $r0 0x34
00006b2a: b2 0a                 mov b32 $r10 $r0
00006b2c: 7e 21 10 00           lcall 0x1021
00006b30: 98 0c 02              ld b32 $r12 D[$r0+0x8]
00006b33: 98 0f 01              ld b32 $r15 D[$r0+0x4]
00006b36: bf 0d                 ld b32 $r13 D[$r0]
00006b38: 98 0e 03              ld b32 $r14 D[$r0+0xc]
00006b3b: 89 ec 12 00           mov $r9 0x12ec
00006b3f: b6 f4 10              shl b32 $r15 0x10
00006b42: bf 99                 ld b32 $r9 D[$r9]
00006b44: b6 e4 10              shl b32 $r14 0x10
00006b47: ff fd d5              or $r13 $r15 $r13
00006b4a: fd ec 05              or $r14 $r12
00006b4d: 3e 68 6b 00           lbra 0x6b68
00006b51: 8f 00 0e 00         B mov $r15 0xe00
00006b55: 89 ec 12 00           mov $r9 0x12ec
00006b59: 98 fe 19              ld b32 $r14 D[$r15+0x64]
00006b5c: bf 99                 ld b32 $r9 D[$r9]
00006b5e: 98 fd 1a              ld b32 $r13 D[$r15+0x68]
00006b61: 8f ff ff 01           mov $r15 0x1ffff
00006b65: fd ef 04              and $r14 $r15
00006b68: 90 9f 40            B add b32 $r15 $r9 0x40
00006b6b: f0 94 3f              and $r9 0x3f
00006b6e: f0 f4 ff              and $r15 0xff
00006b71: b6 94 10              shl b32 $r9 0x10
00006b74: fd 9f 05              or $r9 $r15
00006b77: 94 6f 18              shl b32 $r15 $r6 0x18
00006b7a: ff 9f f5              or $r15 $r9 $r15
00006b7d: 89 14 13 00           mov $r9 0x1314
00006b81: a0 9d                 st b32 D[$r9] $r13
00006b83: 89 18 13 00           mov $r9 0x1318
00006b87: a0 9e                 st b32 D[$r9] $r14
00006b89: 89 1c 13 00           mov $r9 0x131c
00006b8d: a0 9f                 st b32 D[$r9] $r15
00006b8f: df 00 00 11 2e      B mov $r15 0x2e110000
00006b94: 89 00 2a 02           mov $r9 0x22a00
00006b98: fa 9f 00              iowr I[$r9] $r15
00006b9b: 89 ec 12 00           mov $r9 0x12ec
00006b9f: bf 9a                 ld b32 $r10 D[$r9]
00006ba1: b2 6b                 mov b32 $r11 $r6
00006ba3: 7e f6 19 00           lcall 0x19f6
00006ba7: df 00 00 12 2d        mov $r15 0x2d120000
00006bac: 89 00 2a 02           mov $r9 0x22a00
00006bb0: fa 9f 00              iowr I[$r9] $r15
00006bb3: 89 ec 12 00           mov $r9 0x12ec
00006bb7: bf 9a                 ld b32 $r10 D[$r9]
00006bb9: b2 6b                 mov b32 $r11 $r6
00006bbb: 7e df 16 00           lcall 0x16df
00006bbf: 89 08 13 00           mov $r9 0x1308
00006bc3: bf 99                 ld b32 $r9 D[$r9]
00006bc5: b3 90 00 14           bra b32 $r9 0x0 e 0x6bd9
00006bc9: b3 50 00 10           bra b32 $r5 0x0 e 0x6bd9
00006bcd: 8f 00 0e 00           mov $r15 0xe00
00006bd1: bd 94                 clear b32 $r9
00006bd3: b5 f9 08              st b32 D[$r15+0x20] $r9
00006bd6: b5 f9 07              st b32 D[$r15+0x1c] $r9
00006bd9: df 00 00 0e 31      B mov $r15 0x310e0000
00006bde: 89 00 2a 02           mov $r9 0x22a00
00006be2: fa 9f 00              iowr I[$r9] $r15
00006be5: b3 54 00 08           bra b32 $r5 0x0 ne 0x6bed
00006be9: 7e fc 23 00           lcall 0x23fc
00006bed: 80 ec 12 00         B mov $r0 0x12ec
00006bf1: bf 0a                 ld b32 $r10 D[$r0]
00006bf3: 7e c4 24 00           lcall 0x24c4
00006bf7: bf 0a                 ld b32 $r10 D[$r0]
00006bf9: 7e 89 26 00           lcall 0x2689
00006bfd: df 00 00 08 37        mov $r15 0x37080000
00006c02: 89 00 2a 02           mov $r9 0x22a00
00006c06: fa 9f 00              iowr I[$r9] $r15
00006c09: 89 24 13 00           mov $r9 0x1324
00006c0d: bf 99                 ld b32 $r9 D[$r9]
00006c0f: b3 94 00 0a           bra b32 $r9 0x0 ne 0x6c19
00006c13: b2 3a                 mov b32 $r10 $r3
00006c15: 7e 12 58 00           lcall 0x5812
00006c19: b3 54 00 0c         B bra b32 $r5 0x0 ne 0x6c25
00006c1d: 0a 06                 mov $r10 0x6
00006c1f: bd b4                 clear b32 $r11
00006c21: 7e 17 0d 00           lcall 0xd17
00006c25: 89 24 13 00         B mov $r9 0x1324
00006c29: bf 99                 ld b32 $r9 D[$r9]
00006c2b: b3 94 00 22           bra b32 $r9 0x0 ne 0x6c4d
00006c2f: 8a 00 a8 41           mov $r10 0x41a800
00006c33: bd b4                 clear b32 $r11
00006c35: 7e 37 02 00           lcall 0x237
00006c39: 0a 01                 mov $r10 0x1
00006c3b: b3 70 02 0c           bra b32 $r7 0x2 e 0x6c47
00006c3f: 0a 09                 mov $r10 0x9
00006c41: b3 54 00 06           bra b32 $r5 0x0 ne 0x6c47
00006c45: 0a 08                 mov $r10 0x8
00006c47: b2 3b               B mov b32 $r11 $r3
00006c49: 7e c5 0c 00           lcall 0xcc5
00006c4d: df 00 00 01 3e      B mov $r15 0x3e010000
00006c52: 89 00 2a 02           mov $r9 0x22a00
00006c56: fa 9f 00              iowr I[$r9] $r15
00006c59: 89 24 00 00           mov $r9 0x24
00006c5d: bf 9a                 ld b32 $r10 D[$r9]
00006c5f: 7e 14 01 00           lcall 0x114
00006c63: 0a 02                 mov $r10 0x2
00006c65: 7e 91 07 00           lcall 0x791
00006c69: 89 24 13 00           mov $r9 0x1324
00006c6d: bf 99                 ld b32 $r9 D[$r9]
00006c6f: b3 94 00 18           bra b32 $r9 0x0 ne 0x6c87
00006c73: 7e d1 0e 00           lcall 0xed1
00006c77: 0a 01                 mov $r10 0x1
00006c79: 7e 15 04 00           lcall 0x415
00006c7d: 7e 19 2c 00           lcall 0x2c19
00006c81: bd a4                 clear b32 $r10
00006c83: 7e 45 04 00           lcall 0x445
00006c87: bd a4               B clear b32 $r10
00006c89: 7e e3 00 00           lcall 0xe3
00006c8d: 7e 75 21 00           lcall 0x2175
00006c91: 89 00 10 00           mov $r9 0x1000
00006c95: 98 9b 03              ld b32 $r11 D[$r9+0xc]
00006c98: 0a 0f                 mov $r10 0xf
00006c9a: f0 b3 00              sethi $r11 0x0
00006c9d: 7e c4 00 00           lcall 0xc4
00006ca1: 89 24 13 00           mov $r9 0x1324
00006ca5: bf 99                 ld b32 $r9 D[$r9]
00006ca7: b3 99 00 79 03        bra b32 $r9 0x0 e 0x7020
00006cac: bd 04                 clear b32 $r0
00006cae: 7e 75 21 00         B lcall 0x2175
00006cb2: b3 00 00 1b           bra b32 $r0 0x0 e 0x6ccd
00006cb6: 89 0c 13 00           mov $r9 0x130c
00006cba: bf 99                 ld b32 $r9 D[$r9]
00006cbc: 92 99 01              sub b32 $r9 $r9 0x1
00006cbf: b0 96 01              cmp b32 $r9 0x1
00006cc2: f4 0c 0b              bra a 0x6ccd
00006cc5: 7e 4b 36 00           lcall 0x364b
00006cc9: 7e 73 19 00           lcall 0x1973
00006ccd: df 00 00 02 3d      B mov $r15 0x3d020000
00006cd2: 89 00 2a 02           mov $r9 0x22a00
00006cd6: fa 9f 00              iowr I[$r9] $r15
00006cd9: 7e 19 2c 00           lcall 0x2c19
00006cdd: 89 24 13 00           mov $r9 0x1324
00006ce1: bf 99                 ld b32 $r9 D[$r9]
00006ce3: b3 94 00 0e           bra b32 $r9 0x0 ne 0x6cf1
00006ce7: b3 34 01 0a           bra b32 $r3 0x1 ne 0x6cf1
00006ceb: bd a4                 clear b32 $r10
00006ced: 7e c0 47 00           lcall 0x47c0
00006cf1: 89 e0 12 00         B mov $r9 0x12e0
00006cf5: bf 9a                 ld b32 $r10 D[$r9]
00006cf7: 89 e4 12 00           mov $r9 0x12e4
00006cfb: bf 9b                 ld b32 $r11 D[$r9]
00006cfd: 89 e8 12 00           mov $r9 0x12e8
00006d01: bf 9c                 ld b32 $r12 D[$r9]
00006d03: 7e b9 32 00           lcall 0x32b9
00006d07: df 00 00 08 37        mov $r15 0x37080000
00006d0c: 89 00 2a 02           mov $r9 0x22a00
00006d10: fa 9f 00              iowr I[$r9] $r15
00006d13: 8c 00 0e 00           mov $r12 0xe00
00006d17: 98 cf 3d              ld b32 $r15 D[$r12+0xf4]
00006d1a: 8d 00 10 00           mov $r13 0x1000
00006d1e: 98 d9 01              ld b32 $r9 D[$r13+0x4]
00006d21: b0 36 01              cmp b32 $r3 0x1
00006d24: f0 ec 0b              xbit $r14 $flags z
00006d27: 90 ff 01              add b32 $r15 $r15 0x1
00006d2a: f1 94 df ff           and $r9 0xffdf
00006d2e: b6 e4 05              shl b32 $r14 0x5
00006d31: b5 cf 3d              st b32 D[$r12+0xf4] $r15
00006d34: df 00 00 11 ca        mov $r15 0xca110000
00006d39: fd 9f 05              or $r9 $r15
00006d3c: fd 9e 05              or $r9 $r14
00006d3f: b5 d9 01              st b32 D[$r13+0x4] $r9
00006d42: d9 ab ec 0b ad        mov $r9 0xad0becab
00006d47: b5 d9 3f              st b32 D[$r13+0xfc] $r9
00006d4a: d9 da 00 eb 1c        mov $r9 0x1ceb00da
00006d4f: b5 d9 40              st b32 D[$r13+0x100] $r9
00006d52: d9 ef be 0d f0        mov $r9 0xf00dbeef
00006d57: b5 d9 7f              st b32 D[$r13+0x1fc] $r9
00006d5a: b3 44 02 13           bra b32 $r4 0x2 ne 0x6d6d
00006d5e: 98 c9 37              ld b32 $r9 D[$r12+0xdc]
00006d61: bd f4                 clear b32 $r15
00006d63: 90 99 01              add b32 $r9 $r9 0x1
00006d66: b5 c9 37              st b32 D[$r12+0xdc] $r9
00006d69: 3e 7f 6d 00           lbra 0x6d7f
00006d6d: 0f 01               B mov $r15 0x1
00006d6f: a6 4f                 cmp b32 $r4 $r15
00006d71: f4 1b 0e              bra ne 0x6d7f
00006d74: 98 c9 35              ld b32 $r9 D[$r12+0xd4]
00006d77: bd f4                 clear b32 $r15
00006d79: 90 99 01              add b32 $r9 $r9 0x1
00006d7c: b5 c9 35              st b32 D[$r12+0xd4] $r9
00006d7f: b3 34 01 28         B bra b32 $r3 0x1 ne 0x6da7
00006d83: 8e 00 0e 00           mov $r14 0xe00
00006d87: 98 ef 36              ld b32 $r15 D[$r14+0xd8]
00006d8a: 8d 94 14 00           mov $r13 0x1494
00006d8e: 98 d9 02              ld b32 $r9 D[$r13+0x8]
00006d91: 90 ff 01              add b32 $r15 $r15 0x1
00006d94: b5 ef 36              st b32 D[$r14+0xd8] $r15
00006d97: 4f 00 ff              mov $r15 -0x100
00006d9a: ff 9f f4              and $r15 $r9 $r15
00006d9d: 10 99 01              add b8 $r9 $r9 0x1
00006da0: f0 94 ff              and $r9 0xff
00006da3: 3e d3 6d 00           lbra 0x6dd3
00006da7: b3 f0 00 32         B bra b32 $r15 0x0 e 0x6dd9
00006dab: 8e 00 0e 00           mov $r14 0xe00
00006daf: 98 ef 34              ld b32 $r15 D[$r14+0xd0]
00006db2: 8d 94 14 00           mov $r13 0x1494
00006db6: 98 d9 02              ld b32 $r9 D[$r13+0x8]
00006db9: 90 ff 01              add b32 $r15 $r15 0x1
00006dbc: b5 ef 34              st b32 D[$r14+0xd0] $r15
00006dbf: df ff ff 00 ff        mov $r15 0xff00ffff
00006dc4: ff 9f f4              and $r15 $r9 $r15
00006dc7: c7 99 f0              extr $r9 $r9 0x10:0x17
00006dca: 90 99 01              add b32 $r9 $r9 0x1
00006dcd: f0 94 ff              and $r9 0xff
00006dd0: b6 94 10              shl b32 $r9 0x10
00006dd3: fd 9f 05            B or $r9 $r15
00006dd6: b5 d9 02              st b32 D[$r13+0x8] $r9
00006dd9: 89 5c 14 00         B mov $r9 0x145c
00006ddd: bf 99                 ld b32 $r9 D[$r9]
00006ddf: b3 90 00 43           bra b32 $r9 0x0 e 0x6e22
00006de3: 89 30 00 00           mov $r9 0x30
00006de7: bf 99                 ld b32 $r9 D[$r9]
00006de9: b3 94 02 39           bra b32 $r9 0x2 ne 0x6e22
00006ded: b3 34 01 35           bra b32 $r3 0x1 ne 0x6e22
00006df1: df 00 00 0f 30        mov $r15 0x300f0000
00006df6: 89 00 2a 02           mov $r9 0x22a00
00006dfa: fa 9f 00              iowr I[$r9] $r15
00006dfd: 0a 03                 mov $r10 0x3
00006dff: 7e 70 10 00           lcall 0x1070
00006e03: 8d 94 14 00           mov $r13 0x1494
00006e07: bf de                 ld b32 $r14 D[$r13]
00006e09: df ff ff 00 ff        mov $r15 0xff00ffff
00006e0e: c7 e9 f0              extr $r9 $r14 0x10:0x17
00006e11: fd ef 04              and $r14 $r15
00006e14: 90 99 01              add b32 $r9 $r9 0x1
00006e17: f0 94 ff              and $r9 0xff
00006e1a: b6 94 10              shl b32 $r9 0x10
00006e1d: fd 9e 05              or $r9 $r14
00006e20: a0 d9                 st b32 D[$r13] $r9
00006e22: b3 80 00 14         B bra b32 $r8 0x0 e 0x6e36
00006e26: df 00 00 0f 30        mov $r15 0x300f0000
00006e2b: 89 00 2a 02           mov $r9 0x22a00
00006e2f: fa 9f 00              iowr I[$r9] $r15
00006e32: 7e e1 37 00           lcall 0x37e1
00006e36: df 00 00 0c 33      B mov $r15 0x330c0000
00006e3b: 89 00 2a 02           mov $r9 0x22a00
00006e3f: fa 9f 00              iowr I[$r9] $r15
00006e42: 0a 01                 mov $r10 0x1
00006e44: 7e 63 30 00           lcall 0x3063
00006e48: df 00 00 0d 32        mov $r15 0x320d0000
00006e4d: 89 00 2a 02           mov $r9 0x22a00
00006e51: fa 9f 00              iowr I[$r9] $r15
00006e54: 0a 02                 mov $r10 0x2
00006e56: 7e 4a 2f 00           lcall 0x2f4a
00006e5a: b3 00 00 17           bra b32 $r0 0x0 e 0x6e71
00006e5e: 89 0c 13 00           mov $r9 0x130c
00006e62: bf 99                 ld b32 $r9 D[$r9]
00006e64: 92 99 01              sub b32 $r9 $r9 0x1
00006e67: b0 96 01              cmp b32 $r9 0x1
00006e6a: f4 0c 07              bra a 0x6e71
00006e6d: 7e 46 34 00           lcall 0x3446
00006e71: 89 24 00 00         B mov $r9 0x24
00006e75: bf 9a                 ld b32 $r10 D[$r9]
00006e77: 7e 14 01 00           lcall 0x114
00006e7b: 0a 01                 mov $r10 0x1
00006e7d: 7e 91 07 00           lcall 0x791
00006e81: b3 54 00 0c           bra b32 $r5 0x0 ne 0x6e8d
00006e85: 7e 7e 3d 00           lcall 0x3d7e
00006e89: 3e a7 6e 00           lbra 0x6ea7
00006e8d: df 00 00 19 26      B mov $r15 0x26190000
00006e92: 89 00 2a 02           mov $r9 0x22a00
00006e96: fa 9f 00              iowr I[$r9] $r15
00006e99: 8a 00 84 02           mov $r10 0x28400
00006e9d: 0b 05                 mov $r11 0x5
00006e9f: 7e 10 00 00           lcall 0x10
00006ea3: 7e cf 31 00           lcall 0x31cf
00006ea7: df 00 00 19 26      B mov $r15 0x26190000
00006eac: 89 00 2a 02           mov $r9 0x22a00
00006eb0: fa 9f 00              iowr I[$r9] $r15
00006eb3: 8a 00 84 02           mov $r10 0x28400
00006eb7: 4b 0b 01              mov $r11 0x10b
00006eba: 7e 10 00 00           lcall 0x10
00006ebe: 7e cf 31 00           lcall 0x31cf
00006ec2: df 00 00 04 3b        mov $r15 0x3b040000
00006ec7: 89 00 2a 02           mov $r9 0x22a00
00006ecb: fa 9f 00              iowr I[$r9] $r15
00006ece: 89 24 13 00           mov $r9 0x1324
00006ed2: bf 99                 ld b32 $r9 D[$r9]
00006ed4: b3 94 00 08           bra b32 $r9 0x0 ne 0x6edc
00006ed8: 7e fc 23 00           lcall 0x23fc
00006edc: df 00 00 08 37      B mov $r15 0x37080000
00006ee1: 89 00 2a 02           mov $r9 0x22a00
00006ee5: fa 9f 00              iowr I[$r9] $r15
00006ee8: b3 74 00 49           bra b32 $r7 0x0 ne 0x6f31
00006eec: 89 24 13 00           mov $r9 0x1324
00006ef0: bf 99                 ld b32 $r9 D[$r9]
00006ef2: b3 94 00 0e           bra b32 $r9 0x0 ne 0x6f00
00006ef6: bd a4                 clear b32 $r10
00006ef8: 7e 15 04 00           lcall 0x415
00006efc: 7e 19 2c 00           lcall 0x2c19
00006f00: bd a4               B clear b32 $r10
00006f02: 7e c6 29 00           lcall 0x29c6
00006f06: 0a 01                 mov $r10 0x1
00006f08: b2 ab                 mov b32 $r11 $r10
00006f0a: b2 ac                 mov b32 $r12 $r10
00006f0c: 7e 7b 0c 00           lcall 0xc7b
00006f10: 7e 0c 29 00           lcall 0x290c
00006f14: bd a4                 clear b32 $r10
00006f16: 7e 88 29 00           lcall 0x2988
00006f1a: 89 c0 13 00           mov $r9 0x13c0
00006f1e: bf 9f                 ld b32 $r15 D[$r9]
00006f20: 89 00 2e 02           mov $r9 0x22e00
00006f24: fa 9f 00              iowr I[$r9] $r15
00006f27: 0f 04                 mov $r15 0x4
00006f29: b8 99 00 01 00        add b32 $r9 $r9 0x100
00006f2e: fa 9f 00              iowr I[$r9] $r15
00006f31: bd f4               B clear b32 $r15
00006f33: 89 00 0c 01           mov $r9 0x10c00
00006f37: fa 9f 00              iowr I[$r9] $r15
00006f3a: 89 c4 14 00           mov $r9 0x14c4
00006f3e: bf 99                 ld b32 $r9 D[$r9]
00006f40: b3 90 00 34           bra b32 $r9 0x0 e 0x6f74
00006f44: 89 b4 14 00           mov $r9 0x14b4
00006f48: bf 99                 ld b32 $r9 D[$r9]
00006f4a: b3 90 00 2a           bra b32 $r9 0x0 e 0x6f74
00006f4e: df 00 00 10 2f        mov $r15 0x2f100000
00006f53: 89 00 2a 02           mov $r9 0x22a00
00006f57: fa 9f 00              iowr I[$r9] $r15
00006f5a: 0b 03                 mov $r11 0x3
00006f5c: 0a 0a                 mov $r10 0xa
00006f5e: 7e 7b 55 00           lcall 0x557b
00006f62: b2 6a                 mov b32 $r10 $r6
00006f64: 7e ad 56 00           lcall 0x56ad
00006f68: df 00 00 08 37        mov $r15 0x37080000
00006f6d: 89 00 2a 02           mov $r9 0x22a00
00006f71: fa 9f 00              iowr I[$r9] $r15
00006f74: b4 a0 0c            B ld b32 $r10 D[$sp+0x30]
00006f77: b2 6b                 mov b32 $r11 $r6
00006f79: 7e 7d 54 00           lcall 0x547d
00006f7d: bd f4                 clear b32 $r15
00006f7f: 89 00 ac 01           mov $r9 0x1ac00
00006f83: fa 9f 00              iowr I[$r9] $r15
00006f86: 89 94 14 00           mov $r9 0x1494
00006f8a: bf 9f                 ld b32 $r15 D[$r9]
00006f8c: 89 00 0a 02           mov $r9 0x20a00
00006f90: fa 9f 00              iowr I[$r9] $r15
00006f93: 89 94 14 00           mov $r9 0x1494
00006f97: 98 9f 01              ld b32 $r15 D[$r9+0x4]
00006f9a: 89 00 0b 02           mov $r9 0x20b00
00006f9e: fa 9f 00              iowr I[$r9] $r15
00006fa1: 89 94 14 00           mov $r9 0x1494
00006fa5: 98 9f 02              ld b32 $r15 D[$r9+0x8]
00006fa8: 89 00 0c 02           mov $r9 0x20c00
00006fac: fa 9f 00              iowr I[$r9] $r15
00006faf: 89 00 c0 02           mov $r9 0x2c000
00006fb3: b4 f0 0c              ld b32 $r15 D[$sp+0x30]
00006fb6: fa 9f 00              iowr I[$r9] $r15
00006fb9: bd f4                 clear b32 $r15
00006fbb: 89 bc 12 00           mov $r9 0x12bc
00006fbf: a0 9f                 st b32 D[$r9] $r15
00006fc1: 8f 00 80 00           mov $r15 0x8000
00006fc5: 89 00 1a 02           mov $r9 0x21a00
00006fc9: fa 9f 00              iowr I[$r9] $r15
00006fcc: 7e 75 21 00           lcall 0x2175
00006fd0: 0f 01                 mov $r15 0x1
00006fd2: 89 00 00 02           mov $r9 0x20000
00006fd6: fa 9f 00              iowr I[$r9] $r15
00006fd9: df 00 00 00 3f        mov $r15 0x3f000000
00006fde: b8 99 00 2a 00        add b32 $r9 $r9 0x2a00
00006fe3: fa 9f 00              iowr I[$r9] $r15
00006fe6: df 00 00 00 40        mov $r15 0x40000000
00006feb: fa 9f 00              iowr I[$r9] $r15
00006fee: 8f 00 00 04           mov $r15 0x40000
00006ff2: b8 99 00 12 02        sub b32 $r9 $r9 0x1200
00006ff7: fa 9f 00              iowr I[$r9] $r15
00006ffa: fe 49 01              mov $r9 $sp
00006ffd: 90 99 64              add b32 $r9 $r9 0x64
00007000: bf 9f                 ld b32 $r15 D[$r9]
00007002: 89 04 16 00           mov $r9 0x1604
00007006: bf 99                 ld b32 $r9 D[$r9]
00007008: a6 f9                 cmp b32 $r15 $r9
0000700a: f4 0b 56              bra e 0x7060
0000700d: 3e 5c 70 00           lbra 0x705c
00007011: 89 50 14 00         B mov $r9 0x1450
00007015: bf 99                 ld b32 $r9 D[$r9]
00007017: b3 99 00 46 f5        bra b32 $r9 0x0 e 0x655d
0000701c: 3e 51 65 00           lbra 0x6551
00007020: 89 bc 03 00         B mov $r9 0x3bc
00007024: bf 9d                 ld b32 $r13 D[$r9]
00007026: 0a 01                 mov $r10 0x1
00007028: 8c 28 03 00           mov $r12 0x328
0000702c: b2 ab                 mov b32 $r11 $r10
0000702e: 7e e1 07 00           lcall 0x7e1
00007032: 89 08 04 00           mov $r9 0x408
00007036: bf 9d                 ld b32 $r13 D[$r9]
00007038: 0a 01                 mov $r10 0x1
0000703a: 0b 03                 mov $r11 0x3
0000703c: 8c c0 03 00           mov $r12 0x3c0
00007040: 7e e1 07 00           lcall 0x7e1
00007044: 89 28 04 00           mov $r9 0x428
00007048: bf 9d                 ld b32 $r13 D[$r9]
0000704a: 0a 15                 mov $r10 0x15
0000704c: 0b 04                 mov $r11 0x4
0000704e: 8c 1c 04 00           mov $r12 0x41c
00007052: 00 01                 mov $r0 0x1
00007054: 7e e1 07 00           lcall 0x7e1
00007058: 3e ae 6c 00           lbra 0x6cae
0000705c: 7e 47 07 00         B lcall 0x747
00007060: f4 30 0c            B add $sp 0xc
00007063: fb 85 38              mpopaddret $r8 0x38

00007066: f9 22              C  mpush $r2
00007068: 4f 00 10              mov $r15 0x1000
0000706b: 89 00 12 02           mov $r9 0x21200
0000706f: fa 9f 00              iowr I[$r9] $r15
00007072: bd c4                 clear b32 $r12
00007074: 0d 01                 mov $r13 0x1
00007076: 7e ad 64 00           lcall 0x64ad
0000707a: 82 70 13 00           mov $r2 0x1370
0000707e: 8d 6c 13 00           mov $r13 0x136c
00007082: bd 14                 clear b32 $r1
00007084: 80 ff 0f ff           mov $r0 -0xf001
00007088: 8a 00 00 01           mov $r10 0x10000
0000708c: 8b 00 c3 02           mov $r11 0x2c300
00007090: 0c 01                 mov $r12 0x1
00007092: 3e d0 70 00           lbra 0x70d0
00007096: bf d9               B ld b32 $r9 D[$r13]
00007098: bf df                 ld b32 $r15 D[$r13]
0000709a: bf df                 ld b32 $r15 D[$r13]
0000709c: 8e 2c 13 00           mov $r14 0x132c
000070a0: f0 94 07              and $r9 0x7
000070a3: b6 94 03              shl b32 $r9 0x3
000070a6: bc 9e 90              add b32 $r9 $r9 $r14
000070a9: 90 ff 01              add b32 $r15 $r15 0x1
000070ac: bf 9e                 ld b32 $r14 D[$r9]
000070ae: a0 df                 st b32 D[$r13] $r15
000070b0: bf d9                 ld b32 $r9 D[$r13]
000070b2: fd e0 04              and $r14 $r0
000070b5: b3 94 10 06           bra b32 $r9 0x10 ne 0x70bb
000070b9: a0 d1                 st b32 D[$r13] $r1
000070bb: a6 ea               B cmp b32 $r14 $r10
000070bd: f4 0b 10              bra e 0x70cd
000070c0: 0f 02                 mov $r15 0x2
000070c2: 89 00 00 02           mov $r9 0x20000
000070c6: fa 9f 00              iowr I[$r9] $r15
000070c9: 3e d9 70 00           lbra 0x70d9
000070cd: fa bc 00            B iowr I[$r11] $r12
000070d0: bf 2f               B ld b32 $r15 D[$r2]
000070d2: bf d9                 ld b32 $r9 D[$r13]
000070d4: a6 f9                 cmp b32 $r15 $r9
000070d6: f4 1b c0              bra ne 0x7096
000070d9: 4f 00 10            B mov $r15 0x1000
000070dc: 89 00 18 02           mov $r9 0x21800
000070e0: fa 9f 00              iowr I[$r9] $r15
000070e3: fb 21                 mpopret $r2

000070e5: f9 22              C  mpush $r2
000070e7: 8f 00 00 01           mov $r15 0x10000
000070eb: 89 00 12 02           mov $r9 0x21200
000070ef: fa 9f 00              iowr I[$r9] $r15
000070f2: 82 00 c0 02           mov $r2 0x2c000
000070f6: bd f4                 clear b32 $r15
000070f8: ff 2f bf              iord $r11 I[$r2+$r15*0x4]
000070fb: 89 00 c1 02           mov $r9 0x2c100
000070ff: ff 9f 1f              iord $r1 I[$r9+$r15*0x4]
00007102: 95 10 1f              shr b32 $r0 $r1 0x1f
00007105: b8 99 00 1d 00        add b32 $r9 $r9 0x1d00
0000710a: ff 9f 9f              iord $r9 I[$r9+$r15*0x4]
0000710d: 95 b9 1f              shr b32 $r9 $r11 0x1f
00007110: f5 0b dc 00           bra e 0x71ec
00007114: d9 ff ff ff 3f        mov $r9 0x3fffffff
00007119: ff 19 f4              and $r15 $r1 $r9
0000711c: ff b9 94              and $r9 $r11 $r9
0000711f: b3 00 00 6b           bra b32 $r0 0x0 e 0x718a
00007123: a6 9f                 cmp b32 $r9 $r15
00007125: f4 0b 3d              bra e 0x7162
00007128: 89 f0 13 00           mov $r9 0x13f0
0000712c: bf 99                 ld b32 $r9 D[$r9]
0000712e: b3 94 00 0e           bra b32 $r9 0x0 ne 0x713c
00007132: bd a4                 clear b32 $r10
00007134: 0c 02                 mov $r12 0x2
00007136: bd d4                 clear b32 $r13
00007138: 7e ad 64 00           lcall 0x64ad
0000713c: 89 00 c0 02         B mov $r9 0x2c000
00007140: fa 91 00              iowr I[$r9] $r1
00007143: 89 f0 13 00           mov $r9 0x13f0
00007147: bf 90                 ld b32 $r0 D[$r9]
00007149: b3 0d 00 0a 01        bra b32 $r0 0x0 ne 0x7253
0000714e: b2 1b                 mov b32 $r11 $r1
00007150: bd a4                 clear b32 $r10
00007152: 0c 02                 mov $r12 0x2
00007154: 7e 50 58 00           lcall 0x5850
00007158: 89 b8 12 00           mov $r9 0x12b8
0000715c: a0 90                 st b32 D[$r9] $r0
0000715e: 3e 53 72 00           lbra 0x7253
00007162: bd f4               B clear b32 $r15
00007164: 89 00 dc 02           mov $r9 0x2dc00
00007168: fa 9f 00              iowr I[$r9] $r15
0000716b: 8a b4 41 40           mov $r10 0x4041b4
0000716f: 0b 01                 mov $r11 0x1
00007171: 7e 37 02 00           lcall 0x237
00007175: 89 bc 12 00           mov $r9 0x12bc
00007179: 0f 01                 mov $r15 0x1
0000717b: a0 9f                 st b32 D[$r9] $r15
0000717d: b8 ff ff 7f 00        add b32 $r15 $r15 0x7fff
00007182: 89 00 14 02           mov $r9 0x21400
00007186: 3e 50 72 00           lbra 0x7250
0000718a: a6 9f               B cmp b32 $r9 $r15
0000718c: f5 1b c7 00           bra ne 0x7253
00007190: 89 f0 13 00           mov $r9 0x13f0
00007194: bf 92                 ld b32 $r2 D[$r9]
00007196: b3 24 00 18           bra b32 $r2 0x0 ne 0x71ae
0000719a: bd a4                 clear b32 $r10
0000719c: bd c4                 clear b32 $r12
0000719e: bd d4                 clear b32 $r13
000071a0: 7e ad 64 00           lcall 0x64ad
000071a4: 89 b8 12 00           mov $r9 0x12b8
000071a8: a0 92                 st b32 D[$r9] $r2
000071aa: 3e e1 71 00           lbra 0x71e1
000071ae: bd a4               B clear b32 $r10
000071b0: bd b4                 clear b32 $r11
000071b2: 7e 3f 47 00           lcall 0x473f
000071b6: 89 00 00 03           mov $r9 0x30000
000071ba: ff 90 9f              iord $r9 I[$r9+$r0*0x4]
000071bd: 0f 01                 mov $r15 0x1
000071bf: f0 94 40              and $r9 0x40
000071c2: f4 1b 05              bra ne 0x71c7
000071c5: bd f4                 clear b32 $r15
000071c7: 89 00 dc 02         B mov $r9 0x2dc00
000071cb: fa 9f 00              iowr I[$r9] $r15
000071ce: bd f4                 clear b32 $r15
000071d0: 89 bc 12 00           mov $r9 0x12bc
000071d4: a0 9f                 st b32 D[$r9] $r15
000071d6: 8f 00 80 00           mov $r15 0x8000
000071da: 89 00 1a 02           mov $r9 0x21a00
000071de: fa 9f 00              iowr I[$r9] $r15
000071e1: 89 00 c0 02         B mov $r9 0x2c000
000071e5: fa 91 00              iowr I[$r9] $r1
000071e8: 3e 53 72 00           lbra 0x7253
000071ec: b3 00 00 5e         B bra b32 $r0 0x0 e 0x724a
000071f0: 7e 51 47 00           lcall 0x4751
000071f4: 09 01                 mov $r9 0x1
000071f6: 8f b8 12 00           mov $r15 0x12b8
000071fa: a0 f9                 st b32 D[$r15] $r9
000071fc: fa 21 00              iowr I[$r2] $r1
000071ff: 89 f0 13 00           mov $r9 0x13f0
00007203: bf 90                 ld b32 $r0 D[$r9]
00007205: 82 b8 12 00           mov $r2 0x12b8
00007209: b3 04 00 14           bra b32 $r0 0x0 ne 0x721d
0000720d: b2 1b                 mov b32 $r11 $r1
0000720f: bd a4                 clear b32 $r10
00007211: 0c 01                 mov $r12 0x1
00007213: 7e 50 58 00           lcall 0x5850
00007217: a0 20                 st b32 D[$r2] $r0
00007219: 3e 4a 72 00           lbra 0x724a
0000721d: 8f f4 13 00         B mov $r15 0x13f4
00007221: bf f9                 ld b32 $r9 D[$r15]
00007223: 0b 01                 mov $r11 0x1
00007225: 8a b4 41 40           mov $r10 0x4041b4
00007229: bc 9b 90              add b32 $r9 $r9 $r11
0000722c: a0 f9                 st b32 D[$r15] $r9
0000722e: 7e 37 02 00           lcall 0x237
00007232: bd 94                 clear b32 $r9
00007234: a0 29                 st b32 D[$r2] $r9
00007236: 89 bc 12 00           mov $r9 0x12bc
0000723a: 0f 01                 mov $r15 0x1
0000723c: a0 9f                 st b32 D[$r9] $r15
0000723e: b8 ff ff 7f 00        add b32 $r15 $r15 0x7fff
00007243: 89 00 14 02           mov $r9 0x21400
00007247: fa 9f 00              iowr I[$r9] $r15
0000724a: bd f4               B clear b32 $r15
0000724c: 89 00 dc 02           mov $r9 0x2dc00
00007250: fa 9f 00            B iowr I[$r9] $r15
00007253: 8f 00 00 01         B mov $r15 0x10000
00007257: 89 00 18 02           mov $r9 0x21800
0000725b: fa 9f 00              iowr I[$r9] $r15
0000725e: fb 21                 mpopret $r2

00007260: f4 30 f8           C  add $sp -0x8
00007263: f9 12                 mpush $r1
00007265: 81 04 16 00           mov $r1 0x1604
00007269: bf 19                 ld b32 $r9 D[$r1]
0000726b: b2 ac                 mov b32 $r12 $r10
0000726d: fe 40 01              mov $r0 $sp
00007270: fe 4a 01              mov $r10 $sp
00007273: 90 00 0c              add b32 $r0 $r0 0xc
00007276: 90 aa 08              add b32 $r10 $r10 0x8
00007279: a0 09                 st b32 D[$r0] $r9
0000727b: 4b ff 00              mov $r11 0xff
0000727e: 7e e8 77 00           lcall 0x77e8
00007282: bf 0f                 ld b32 $r15 D[$r0]
00007284: bf 19                 ld b32 $r9 D[$r1]
00007286: a6 f9                 cmp b32 $r15 $r9
00007288: f4 0b 07              bra e 0x728f
0000728b: 7e 47 07 00           lcall 0x747
0000728f: fb 15 08            B mpopaddret $r1 0x8

00007292: f9 12              C  mpush $r1
00007294: 0f 08                 mov $r15 0x8
00007296: 89 00 12 02           mov $r9 0x21200
0000729a: fa 9f 00              iowr I[$r9] $r15
0000729d: 89 70 13 00           mov $r9 0x1370
000072a1: 8c 6c 13 00           mov $r12 0x136c
000072a5: bf 9e                 ld b32 $r14 D[$r9]
000072a7: bf cf                 ld b32 $r15 D[$r12]
000072a9: bd b4                 clear b32 $r11
000072ab: 89 c0 12 00           mov $r9 0x12c0
000072af: a0 9b                 st b32 D[$r9] $r11
000072b1: a6 ef                 cmp b32 $r14 $r15
000072b3: f5 0b 89 04           bra e 0x773c
000072b7: bf c9                 ld b32 $r9 D[$r12]
000072b9: bf cf                 ld b32 $r15 D[$r12]
000072bb: bf ce                 ld b32 $r14 D[$r12]
000072bd: 8d 2c 13 00           mov $r13 0x132c
000072c1: f0 94 07              and $r9 0x7
000072c4: b6 94 03              shl b32 $r9 0x3
000072c7: 90 ee 01              add b32 $r14 $r14 0x1
000072ca: bc 9d 90              add b32 $r9 $r9 $r13
000072cd: bf 9a                 ld b32 $r10 D[$r9]
000072cf: a0 ce                 st b32 D[$r12] $r14
000072d1: bf ce                 ld b32 $r14 D[$r12]
000072d3: f0 f4 07              and $r15 0x7
000072d6: bc ff f0              add b32 $r15 $r15 $r15
000072d9: 90 ff 01              add b32 $r15 $r15 0x1
000072dc: bc df d8              ld b32 $r13 D[$r13+$r15*0x4]
000072df: b3 e4 10 06           bra b32 $r14 0x10 ne 0x72e5
000072e3: a0 cb                 st b32 D[$r12] $r11
000072e5: 89 ff 0f ff         B mov $r9 -0xf001
000072e9: fd a9 04              and $r10 $r9
000072ec: b3 a9 25 c3 02        bra b32 $r10 0x25 e 0x75af
000072f1: b0 a6 25              cmp b32 $r10 0x25
000072f4: f5 0c be 00           bra a 0x73b2
000072f8: b0 a6 14              cmp b32 $r10 0x14
000072fb: f4 0c 6f              bra a 0x736a
000072fe: b0 a6 13              cmp b32 $r10 0x13
00007301: f5 18 37 04           bra ae 0x7738
00007305: b3 a9 09 d0 01        bra b32 $r10 0x9 e 0x74d5
0000730a: b0 a6 09              cmp b32 $r10 0x9
0000730d: f4 0c 2f              bra a 0x733c
00007310: b3 a9 02 83 01        bra b32 $r10 0x2 e 0x7493
00007315: b0 a6 02              cmp b32 $r10 0x2
00007318: f4 0c 11              bra a 0x7329
0000731b: b3 a9 00 1d 04        bra b32 $r10 0x0 e 0x7738
00007320: b3 ad 01 12 04        bra b32 $r10 0x1 ne 0x7732
00007325: 3e 89 74 00           lbra 0x7489
00007329: b3 a9 06 5c 02      B bra b32 $r10 0x6 e 0x7585
0000732e: b3 a9 08 7b 01        bra b32 $r10 0x8 e 0x74a9
00007333: b3 ad 03 ff 03        bra b32 $r10 0x3 ne 0x7732
00007338: 3e f1 74 00           lbra 0x74f1
0000733c: b3 a9 0e 87 02      B bra b32 $r10 0xe e 0x75c3
00007341: b0 a6 0e              cmp b32 $r10 0xe
00007344: f4 0c 11              bra a 0x7355
00007347: b3 a9 0c 9f 02        bra b32 $r10 0xc e 0x75e6
0000734c: b3 ad 0d e6 03        bra b32 $r10 0xd ne 0x7732
00007351: 3e d6 75 00           lbra 0x75d6
00007355: b3 a9 10 3a 02      B bra b32 $r10 0x10 e 0x758f
0000735a: b0 a6 10              cmp b32 $r10 0x10
0000735d: f5 08 81 02           bra b 0x75de
00007361: b3 ad 11 d1 03        bra b32 $r10 0x11 ne 0x7732
00007366: 3e b9 75 00           lbra 0x75b9
0000736a: b3 a9 1b a5 02      B bra b32 $r10 0x1b e 0x760f
0000736f: b0 a6 1b              cmp b32 $r10 0x1b
00007372: f4 0c 1f              bra a 0x7391
00007375: b0 a6 19              cmp b32 $r10 0x19
00007378: f5 0c 21 02           bra a 0x7599
0000737c: b0 a6 17              cmp b32 $r10 0x17
0000737f: f5 18 b9 03           bra ae 0x7738
00007383: b3 a9 15 ae 01        bra b32 $r10 0x15 e 0x7531
00007388: b3 ad 16 aa 03        bra b32 $r10 0x16 ne 0x7732
0000738d: 3e a5 75 00           lbra 0x75a5
00007391: b3 a9 21 30 01      B bra b32 $r10 0x21 e 0x74c1
00007396: b0 a6 21              cmp b32 $r10 0x21
00007399: f4 0c 0e              bra a 0x73a7
0000739c: b0 a6 1f              cmp b32 $r10 0x1f
0000739f: f5 0c 93 03           bra a 0x7732
000073a3: 3e 38 77 00           lbra 0x7738
000073a7: b0 a6 23            B cmp b32 $r10 0x23
000073aa: f5 0d 8e 03           bra be 0x7738
000073ae: 3e cb 75 00           lbra 0x75cb
000073b2: b3 a9 55 79 01      B bra b32 $r10 0x55 e 0x752b
000073b7: b1 a6 55 00           cmp b32 $r10 0x55
000073bb: f4 0c 5d              bra a 0x7418
000073be: b3 a9 31 65 02        bra b32 $r10 0x31 e 0x7623
000073c3: b0 a6 31              cmp b32 $r10 0x31
000073c6: f4 0c 24              bra a 0x73ea
000073c9: b3 a9 2a b2 01        bra b32 $r10 0x2a e 0x757b
000073ce: b0 a6 2a              cmp b32 $r10 0x2a
000073d1: f5 08 67 03           bra b 0x7738
000073d5: b3 a9 2f 95 01        bra b32 $r10 0x2f e 0x756a
000073da: b0 a6 2f              cmp b32 $r10 0x2f
000073dd: f5 0c 3a 02           bra a 0x7617
000073e1: b3 ad 2e 51 03        bra b32 $r10 0x2e ne 0x7732
000073e6: 3e 57 75 00           lbra 0x7557
000073ea: b3 a9 34 59 02      B bra b32 $r10 0x34 e 0x7643
000073ef: b0 a6 34              cmp b32 $r10 0x34
000073f2: f4 0c 11              bra a 0x7403
000073f5: b3 a9 32 38 02        bra b32 $r10 0x32 e 0x762d
000073fa: b3 ad 33 38 03        bra b32 $r10 0x33 ne 0x7732
000073ff: 3e 37 76 00           lbra 0x7637
00007403: b3 a9 36 62 02      B bra b32 $r10 0x36 e 0x7665
00007408: b0 a6 36              cmp b32 $r10 0x36
0000740b: f5 08 42 02           bra b 0x764d
0000740f: b3 ad 54 23 03        bra b32 $r10 0x54 ne 0x7732
00007414: 3e 23 75 00           lbra 0x7523
00007418: b1 a6 64 00         B cmp b32 $r10 0x64
0000741c: f4 0c 33              bra a 0x744f
0000741f: b1 a6 62 00           cmp b32 $r10 0x62
00007423: f5 18 15 03           bra ae 0x7738
00007427: b3 a9 58 10 01        bra b32 $r10 0x58 e 0x7537
0000742c: b1 a6 58 00           cmp b32 $r10 0x58
00007430: f4 0c 11              bra a 0x7441
00007433: b3 a9 56 0c 01        bra b32 $r10 0x56 e 0x753f
00007438: b3 ad 57 fa 02        bra b32 $r10 0x57 ne 0x7732
0000743d: 3e 4f 75 00           lbra 0x754f
00007441: b3 a9 59 06 01      B bra b32 $r10 0x59 e 0x7547
00007446: b3 ad 60 ec 02        bra b32 $r10 0x60 ne 0x7732
0000744b: 3e f9 74 00           lbra 0x74f9
0000744f: b3 a9 70 d9 02      B bra b32 $r10 0x70 e 0x7728
00007454: b1 a6 70 00           cmp b32 $r10 0x70
00007458: f4 0c 11              bra a 0x7469
0000745b: b3 a9 69 94 02        bra b32 $r10 0x69 e 0x76ef
00007460: b3 ad 6a d2 02        bra b32 $r10 0x6a ne 0x7732
00007465: 3e 0c 77 00           lbra 0x770c
00007469: 89 01 00 01         B mov $r9 0x10001
0000746d: a6 a9                 cmp b32 $r10 $r9
0000746f: f5 0b c9 02           bra e 0x7738
00007473: 90 99 03              add b32 $r9 $r9 0x3
00007476: a6 a9                 cmp b32 $r10 $r9
00007478: f5 0b 98 00           bra e 0x7510
0000747c: 92 99 04              sub b32 $r9 $r9 0x4
0000747f: a6 a9                 cmp b32 $r10 $r9
00007481: f5 1b b1 02           bra ne 0x7732
00007485: 3e e1 76 00           lbra 0x76e1
00007489: b2 db               B mov b32 $r11 $r13
0000748b: 0a 01                 mov $r10 0x1
0000748d: 0c 02                 mov $r12 0x2
0000748f: 3e af 74 00           lbra 0x74af
00007493: 80 b8 12 00         B mov $r0 0x12b8
00007497: 0c 01                 mov $r12 0x1
00007499: b2 db                 mov b32 $r11 $r13
0000749b: a0 0c                 st b32 D[$r0] $r12
0000749d: 7e 50 58 00           lcall 0x5850
000074a1: bd 94                 clear b32 $r9
000074a3: a0 09                 st b32 D[$r0] $r9
000074a5: 3e 38 77 00           lbra 0x7738
000074a9: b2 db               B mov b32 $r11 $r13
000074ab: 0a 08                 mov $r10 0x8
000074ad: bd c4                 clear b32 $r12
000074af: bd d4               B clear b32 $r13
000074b1: 7e ad 64 00           lcall 0x64ad
000074b5: bd f4                 clear b32 $r15
000074b7: 89 b8 12 00           mov $r9 0x12b8
000074bb: a0 9f                 st b32 D[$r9] $r15
000074bd: 3e 38 77 00           lbra 0x7738
000074c1: 89 24 00 00         B mov $r9 0x24
000074c5: b2 db                 mov b32 $r11 $r13
000074c7: a0 9d                 st b32 D[$r9] $r13
000074c9: 7e c5 0c 00           lcall 0xcc5
000074cd: 7e fc 23 00           lcall 0x23fc
000074d1: 3e 38 77 00           lbra 0x7738
000074d5: 81 b8 12 00         B mov $r1 0x12b8
000074d9: 00 01                 mov $r0 0x1
000074db: b2 db                 mov b32 $r11 $r13
000074dd: a0 10                 st b32 D[$r1] $r0
000074df: 7e 66 70 00           lcall 0x7066
000074e3: 89 2c 14 00           mov $r9 0x142c
000074e7: a0 90                 st b32 D[$r9] $r0
000074e9: bd 94                 clear b32 $r9
000074eb: a0 19                 st b32 D[$r1] $r9
000074ed: 3e 38 77 00           lbra 0x7738
000074f1: b2 db               B mov b32 $r11 $r13
000074f3: 0c 01                 mov $r12 0x1
000074f5: 3e ff 74 00           lbra 0x74ff
000074f9: b2 db               B mov b32 $r11 $r13
000074fb: 0a 60                 mov $r10 0x60
000074fd: 0c 04                 mov $r12 0x4
000074ff: 7e d9 4d 00         B lcall 0x4dd9
00007503: 0f 10                 mov $r15 0x10
00007505: 89 00 00 02         B mov $r9 0x20000
00007509: fa 9f 00            B iowr I[$r9] $r15
0000750c: 3e 38 77 00           lbra 0x7738
00007510: 8f c8 12 00         B mov $r15 0x12c8
00007514: 09 01                 mov $r9 0x1
00007516: a0 f9                 st b32 D[$r15] $r9
00007518: 8f 00 01 02           mov $r15 0x20100
0000751c: fa f9 00              iowr I[$r15] $r9
0000751f: 3e 38 77 00           lbra 0x7738
00007523: 89 cc 13 00         B mov $r9 0x13cc
00007527: 3e 2f 75 00           lbra 0x752f
0000752b: 89 d0 13 00         B mov $r9 0x13d0
0000752f: a0 9d               B st b32 D[$r9] $r13
00007531: 0f 01               B mov $r15 0x1
00007533: 3e 05 75 00           lbra 0x7505
00007537: 89 d4 13 00         B mov $r9 0x13d4
0000753b: 3e 2f 75 00           lbra 0x752f
0000753f: 89 d8 13 00         B mov $r9 0x13d8
00007543: 3e 2f 75 00           lbra 0x752f
00007547: 89 dc 13 00         B mov $r9 0x13dc
0000754b: 3e 2f 75 00           lbra 0x752f
0000754f: 7e e4 3d 00         B lcall 0x3de4
00007553: 3e 38 77 00           lbra 0x7738
00007557: 89 e8 13 00         B mov $r9 0x13e8
0000755b: a0 9d                 st b32 D[$r9] $r13
0000755d: 0a 37                 mov $r10 0x37
0000755f: b0 d6 01              cmp b32 $r13 0x1
00007562: f5 0c d2 01           bra a 0x7734
00007566: 3e 31 75 00           lbra 0x7531
0000756a: 89 e8 13 00         B mov $r9 0x13e8
0000756e: bf 9f                 ld b32 $r15 D[$r9]
00007570: 89 e0 13 00           mov $r9 0x13e0
00007574: bc 9d f9              st b32 D[$r9+$r15*0x4] $r13
00007577: 3e 31 75 00           lbra 0x7531
0000757b: b2 db               B mov b32 $r11 $r13
0000757d: 7e a2 21 00           lcall 0x21a2
00007581: 3e 38 77 00           lbra 0x7738
00007585: b2 db               B mov b32 $r11 $r13
00007587: 7e ea 23 00           lcall 0x23ea
0000758b: 3e 38 77 00           lbra 0x7738
0000758f: b2 db               B mov b32 $r11 $r13
00007591: 7e a6 49 00           lcall 0x49a6
00007595: 3e 38 77 00           lbra 0x7738
00007599: b2 db               B mov b32 $r11 $r13
0000759b: 0a 1a                 mov $r10 0x1a
0000759d: 7e 2b 4c 00           lcall 0x4c2b
000075a1: 3e 38 77 00           lbra 0x7738
000075a5: b2 db               B mov b32 $r11 $r13
000075a7: 7e e6 29 00           lcall 0x29e6
000075ab: 3e 38 77 00           lbra 0x7738
000075af: b2 db               B mov b32 $r11 $r13
000075b1: 7e 14 25 00           lcall 0x2514
000075b5: 3e 38 77 00           lbra 0x7738
000075b9: b2 db               B mov b32 $r11 $r13
000075bb: 7e ce 2c 00           lcall 0x2cce
000075bf: 3e 38 77 00           lbra 0x7738
000075c3: 7e 19 0c 00         B lcall 0xc19
000075c7: 3e 38 77 00           lbra 0x7738
000075cb: 89 00 de 02         B mov $r9 0x2de00
000075cf: fa 9d 00              iowr I[$r9] $r13
000075d2: 3e 31 75 00           lbra 0x7531
000075d6: 7e 17 27 00         B lcall 0x2717
000075da: 3e 38 77 00           lbra 0x7738
000075de: 7e d1 26 00         B lcall 0x26d1
000075e2: 3e 38 77 00           lbra 0x7738
000075e6: df 00 00 00 10      B mov $r15 0x10000000
000075eb: 89 00 12 02           mov $r9 0x21200
000075ef: fa 9f 00              iowr I[$r9] $r15
000075f2: 89 f0 13 00           mov $r9 0x13f0
000075f6: 0f 01                 mov $r15 0x1
000075f8: a0 9f                 st b32 D[$r9] $r15
000075fa: 89 00 00 02           mov $r9 0x20000
000075fe: fa 9f 00              iowr I[$r9] $r15
00007601: df 00 00 00 10        mov $r15 0x10000000
00007606: b8 99 00 18 00        add b32 $r9 $r9 0x1800
0000760b: 3e 09 75 00           lbra 0x7509
0000760f: 7e 1a 1e 00         B lcall 0x1e1a
00007613: 3e 38 77 00           lbra 0x7738
00007617: b2 db               B mov b32 $r11 $r13
00007619: 0a 30                 mov $r10 0x30
0000761b: 7e ec 1b 00           lcall 0x1bec
0000761f: 3e 38 77 00           lbra 0x7738
00007623: b2 db               B mov b32 $r11 $r13
00007625: 7e 31 1c 00           lcall 0x1c31
00007629: 3e 38 77 00           lbra 0x7738
0000762d: b2 db               B mov b32 $r11 $r13
0000762f: 7e 2a 24 00           lcall 0x242a
00007633: 3e 38 77 00           lbra 0x7738
00007637: b2 db               B mov b32 $r11 $r13
00007639: 0a 33                 mov $r10 0x33
0000763b: 7e 2c 3d 00           lcall 0x3d2c
0000763f: 3e 38 77 00           lbra 0x7738
00007643: b2 db               B mov b32 $r11 $r13
00007645: 7e 4c 3d 00           lcall 0x3d4c
00007649: 3e 38 77 00           lbra 0x7738
0000764d: b2 db               B mov b32 $r11 $r13
0000764f: 0a 35                 mov $r10 0x35
00007651: 7e c5 0c 00           lcall 0xcc5
00007655: 7e f7 0e 00           lcall 0xef7
00007659: 7e fc 23 00           lcall 0x23fc
0000765d: 7e 9b 18 00           lcall 0x189b
00007661: 3e 31 75 00           lbra 0x7531
00007665: 89 24 00 00         B mov $r9 0x24
00007669: bf 9a                 ld b32 $r10 D[$r9]
0000766b: 7e 14 01 00           lcall 0x114
0000766f: 7e 26 0a 00           lcall 0xa26
00007673: bd f4                 clear b32 $r15
00007675: 89 00 0c 01           mov $r9 0x10c00
00007679: fa 9f 00              iowr I[$r9] $r15
0000767c: 89 ec 09 00           mov $r9 0x9ec
00007680: 00 01                 mov $r0 0x1
00007682: a0 90                 st b32 D[$r9] $r0
00007684: 89 f0 09 00           mov $r9 0x9f0
00007688: a0 90                 st b32 D[$r9] $r0
0000768a: 7e 69 0a 00           lcall 0xa69
0000768e: 89 24 00 00           mov $r9 0x24
00007692: bf 9b                 ld b32 $r11 D[$r9]
00007694: 0a 21                 mov $r10 0x21
00007696: 7e c5 0c 00           lcall 0xcc5
0000769a: 7e fc 23 00           lcall 0x23fc
0000769e: 0a 36                 mov $r10 0x36
000076a0: bd b4                 clear b32 $r11
000076a2: 7e a6 49 00           lcall 0x49a6
000076a6: 0a 36                 mov $r10 0x36
000076a8: bd b4                 clear b32 $r11
000076aa: 7e 2b 4c 00           lcall 0x4c2b
000076ae: 0a 36                 mov $r10 0x36
000076b0: bd b4                 clear b32 $r11
000076b2: 7e e6 29 00           lcall 0x29e6
000076b6: 0a 36                 mov $r10 0x36
000076b8: bd b4                 clear b32 $r11
000076ba: 7e 14 25 00           lcall 0x2514
000076be: b2 0b                 mov b32 $r11 $r0
000076c0: 0a 36                 mov $r10 0x36
000076c2: 7e ec 1b 00           lcall 0x1bec
000076c6: 89 14 16 00           mov $r9 0x1614
000076ca: bf 9f                 ld b32 $r15 D[$r9]
000076cc: 89 00 04 02           mov $r9 0x20400
000076d0: fa 9f 00              iowr I[$r9] $r15
000076d3: 0a 32                 mov $r10 0x32
000076d5: bd b4                 clear b32 $r11
000076d7: 7e 2a 24 00           lcall 0x242a
000076db: 0f 36                 mov $r15 0x36
000076dd: 3e 05 75 00           lbra 0x7505
000076e1: 7e e5 70 00         B lcall 0x70e5
000076e5: 0f 01                 mov $r15 0x1
000076e7: 89 00 c3 02           mov $r9 0x2c300
000076eb: 3e 09 75 00           lbra 0x7509
000076ef: 89 cc 12 00         B mov $r9 0x12cc
000076f3: b2 db                 mov b32 $r11 $r13
000076f5: 00 01                 mov $r0 0x1
000076f7: a0 90                 st b32 D[$r9] $r0
000076f9: 7e c5 0c 00           lcall 0xcc5
000076fd: 7e fc 23 00           lcall 0x23fc
00007701: 89 00 01 02           mov $r9 0x20100
00007705: fa 90 00              iowr I[$r9] $r0
00007708: 3e 38 77 00           lbra 0x7738
0000770c: bd f4               B clear b32 $r15
0000770e: 89 cc 12 00           mov $r9 0x12cc
00007712: b2 db                 mov b32 $r11 $r13
00007714: a0 9f                 st b32 D[$r9] $r15
00007716: 7e c5 0c 00           lcall 0xcc5
0000771a: 7e fc 23 00           lcall 0x23fc
0000771e: 0f 01                 mov $r15 0x1
00007720: 89 00 01 02           mov $r9 0x20100
00007724: 3e 09 75 00           lbra 0x7509
00007728: b2 da               B mov b32 $r10 $r13
0000772a: 7e 60 72 00           lcall 0x7260
0000772e: 3e 38 77 00           lbra 0x7738
00007732: 0a 09               B mov $r10 0x9
00007734: 7e c0 05 00         B lcall 0x5c0
00007738: 7e 10 40 00         B lcall 0x4010
0000773c: 0f 08               B mov $r15 0x8
0000773e: 89 00 18 02           mov $r9 0x21800
00007742: fa 9f 00              iowr I[$r9] $r15
00007745: fb 11                 mpopret $r1

00007747: f9 82              C  mpush $r8
00007749: 80 c4 12 00           mov $r0 0x12c4
0000774d: 7e a3 2b 00           lcall 0x2ba3
00007751: 87 d4 12 00           mov $r7 0x12d4
00007755: 88 d0 12 00           mov $r8 0x12d0
00007759: 86 70 13 00           mov $r6 0x1370
0000775d: 85 6c 13 00           mov $r5 0x136c
00007761: 84 b8 13 00           mov $r4 0x13b8
00007765: 83 b4 13 00           mov $r3 0x13b4
00007769: 82 fc 15 00           mov $r2 0x15fc
0000776d: 81 f8 15 00           mov $r1 0x15f8
00007771: 3e bb 77 00           lbra 0x77bb
00007775: f4 28 02            B sleep $p2
00007778: 8e 00 87 01           mov $r14 0x18700
0000777c: bd f4                 clear b32 $r15
0000777e: ff ef 9f              iord $r9 I[$r14+$r15*0x4]
00007781: c7 9f 90              extr $r15 $r9 0x10:0x14
00007784: a0 89                 st b32 D[$r8] $r9
00007786: a0 7f                 st b32 D[$r7] $r15
00007788: 7e c9 1f 00           lcall 0x1fc9
0000778c: bf 09                 ld b32 $r9 D[$r0]
0000778e: b3 94 00 2d           bra b32 $r9 0x0 ne 0x77bb
00007792: 7e 56 46 00           lcall 0x4656
00007796: 7e 92 72 00           lcall 0x7292
0000779a: f4 31 02              bset $flags $p2
0000779d: bf 6f                 ld b32 $r15 D[$r6]
0000779f: bf 59                 ld b32 $r9 D[$r5]
000077a1: a6 f9                 cmp b32 $r15 $r9
000077a3: f4 1b 15              bra ne 0x77b8
000077a6: bf 4f                 ld b32 $r15 D[$r4]
000077a8: bf 39                 ld b32 $r9 D[$r3]
000077aa: a6 f9                 cmp b32 $r15 $r9
000077ac: f4 1b 0c              bra ne 0x77b8
000077af: bf 2f                 ld b32 $r15 D[$r2]
000077b1: bf 19                 ld b32 $r9 D[$r1]
000077b3: a6 f9                 cmp b32 $r15 $r9
000077b5: f4 0b 06              bra e 0x77bb
000077b8: f4 32 02            B bclr $flags $p2
000077bb: bf 09               B ld b32 $r9 D[$r0]
000077bd: b3 90 00 b8           bra b32 $r9 0x0 e 0x7775
000077c1: 0f 01                 mov $r15 0x1
000077c3: 89 00 18 02           mov $r9 0x21800
000077c7: fa 9f 00              iowr I[$r9] $r15
000077ca: bd a4                 clear b32 $r10
000077cc: fb 81                 mpopret $r8

000077ce: 95 af 10           C  shr b32 $r15 $r10 0x10
000077d1: 95 b9 10              shr b32 $r9 $r11 0x10
000077d4: ff a9 91              muls $r9 $r10 $r9
000077d7: ff ba a0              mulu $r10 $r11 $r10
000077da: fd bf 01              muls $r11 $r15
000077dd: bc b9 b0              add b32 $r11 $r11 $r9
000077e0: b6 b4 10              shl b32 $r11 0x10
000077e3: bc ba a0              add b32 $r10 $r11 $r10
000077e6: f8 00                 ret

000077e8: b3 c0 00 11        C  bra b32 $r12 0x0 e 0x77f9
000077ec: bd 94                 clear b32 $r9
000077ee: 3c ab 99            B st b8 D[$r10+$r9] $r11
000077f1: 90 99 01              add b32 $r9 $r9 0x1
000077f4: a6 9c                 cmp b32 $r9 $r12
000077f6: f4 1b f8              bra ne 0x77ee
000077f9: f8 00               B ret
