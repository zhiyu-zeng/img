/* fecs_structured.c — 由 cfstruct.py 从 fecs_inst.asm 结构化转译。
 * 结构: lcall 目标提为 C 函数; 干净前向区间折叠为 if/else; 循环回边保留 goto。
 * 栈语义: CALL() 宏在 C 调用前后 dummy push/pop, 保持 Falcon 的 SP 布局。
 * 语义未经运行验证; 与 fecs_inst.c(平铺保真版) 互为对照。
 */
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
typedef uint8_t u8; typedef uint16_t u16; typedef uint32_t u32; typedef uint64_t u64;
static u32 r[16]; static u32 sp; static u8 p[8]; static u32 falcon_flags;
#define r0 r[0]
#define r1 r[1]
#define r2 r[2]
#define r3 r[3]
#define r4 r[4]
#define r5 r[5]
#define r6 r[6]
#define r7 r[7]
#define r8 r[8]
#define r9 r[9]
#define r10 r[10]
#define r11 r[11]
#define r12 r[12]
#define r13 r[13]
#define r14 r[14]
#define r15 r[15]
static u8 dmem[65536];
static u32 sr_flags_ie;
static u32 sr_iv0;
static u32 sr_xdbase;
static u32 sr_xtargets;
static u32 d32(u32 a){ u32 v; __builtin_memcpy(&v,&dmem[a&0xffff],4); return v; }
static void s32(u32 a, u32 v){ __builtin_memcpy(&dmem[a&0xffff],&v,4); }
static u8 d8(u32 a){ return dmem[a&0xffff]; }
static void s8(u32 a, u8 v){ dmem[a&0xffff]=v; }
static u16 d16(u32 a){ u16 v; __builtin_memcpy(&v,&dmem[a&0xffff],2); return v; }
static void s16(u32 a, u16 v){ __builtin_memcpy(&dmem[a&0xffff],&v,2); }
static u32 xdld(u32 a){ (void)a; return 0; }  /* TODO: X 空间读 */
static void xdst(u32 a, u32 v){ (void)a; (void)v; }  /* TODO: X 空间写 */
static void push32(u32 v){ sp -= 4; s32(sp, v); }
static u32 pop32(void){ u32 v = d32(sp); sp += 4; return v; }
static u32 iord(u32 port){ (void)port; return 0; }  /* TODO: I/O 读 */
static void iowr(u32 port, u32 v){ (void)port; (void)v; }  /* TODO: I/O 写 */
#define iowrs iowr
#define INT_ENABLE(n) do{ sr_flags_ie |= (1u << (n)); }while(0)
#define XDWAIT()   do{ }while(0)
#define XWAIT()    do{ }while(0)
#define DMWAIT()   do{ }while(0)
#define SETFZ(v) (falcon_flags = (falcon_flags & ~1u) | (((v)==0)?1u:0u))
#define FZ(f) ((f)&1u)
#define FC(f) (((f)>>1)&1u)
static void fc_cmp(u32 a, u32 b){ falcon_flags &= ~3u; SETFZ(a-b); if(a<b) falcon_flags |= 2u; }
static void fc_xbit(u32 v){ falcon_flags &= ~1u; SETFZ(v); }
static void intr_sleep(u8 *f){ while(!*f){ } *f = 0; }
static u32 falcon_muls(u32 a, u32 b){ return (u32)(((int64_t)(int32_t)a*(int32_t)b)>>32); }
static u32 falcon_mulu(u32 a, u32 b){ return (u32)(((u64)a*b)>>32); }
#define UNKNOWN(msg) do{ fprintf(stderr, "UNKNOWN: %s\n", msg); abort(); }while(0)
#define CALL(fn) do{ push32(0u); (fn)(); pop32(); }while(0)  /* 保持 Falcon 栈布局 */

static void sub_0(void);
static void sub_10(void);
static void sub_44(void);
static void sub_7a(void);
static void sub_c4(void);
static void sub_e3(void);
static void sub_fb(void);
static void sub_114(void);
static void sub_150(void);
static void sub_1ac(void);
static void sub_22f(void);
static void sub_237(void);
static void sub_28f(void);
static void sub_297(void);
static void sub_32b(void);
static void sub_363(void);
static void sub_39f(void);
static void sub_3ed(void);
static void sub_415(void);
static void sub_42f(void);
static void sub_445(void);
static void sub_45b(void);
static void sub_59b(void);
static void sub_5ae(void);
static void sub_5c0(void);
static void sub_60b(void);
static void sub_681(void);
static void sub_6f7(void);
static void sub_747(void);
static void sub_751(void);
static void sub_768(void);
static void sub_791(void);
static void sub_7e1(void);
static void sub_97a(void);
static void sub_a26(void);
static void sub_a69(void);
static void sub_a8e(void);
static void sub_b8b(void);
static void sub_c19(void);
static void sub_c53(void);
static void sub_c7b(void);
static void sub_c9d(void);
static void sub_cc5(void);
static void sub_cf5(void);
static void sub_d17(void);
static void sub_d91(void);
static void sub_e0c(void);
static void sub_e16(void);
static void sub_e82(void);
static void sub_ed1(void);
static void sub_ef7(void);
static void sub_1021(void);
static void sub_1070(void);
static void sub_108e(void);
static void sub_10f8(void);
static void sub_1196(void);
static void sub_16df(void);
static void sub_1748(void);
static void sub_17c7(void);
static void sub_183d(void);
static void sub_186e(void);
static void sub_189b(void);
static void sub_1973(void);
static void sub_19f6(void);
static void sub_1a42(void);
static void sub_1bec(void);
static void sub_1c31(void);
static void sub_1c96(void);
static void sub_1d12(void);
static void sub_1d81(void);
static void sub_1e1a(void);
static void sub_1e5f(void);
static void sub_1eda(void);
static void sub_1f53(void);
static void sub_1f80(void);
static void sub_1fc9(void);
static void sub_215e(void);
static void sub_2175(void);
static void sub_21a2(void);
static void sub_227c(void);
static void sub_2296(void);
static void sub_2336(void);
static void sub_235c(void);
static void sub_23af(void);
static void sub_23ea(void);
static void sub_23fc(void);
static void sub_242a(void);
static void sub_24c4(void);
static void sub_2514(void);
static void sub_2689(void);
static void sub_26d1(void);
static void sub_2717(void);
static void sub_2749(void);
static void sub_2902(void);
static void sub_290c(void);
static void sub_293a(void);
static void sub_2988(void);
static void sub_29a6(void);
static void sub_29c6(void);
static void sub_29e6(void);
static void sub_2b53(void);
static void sub_2ba3(void);
static void sub_2c19(void);
static void sub_2c44(void);
static void sub_2c8c(void);
static void sub_2cce(void);
static void sub_2d92(void);
static void sub_2de1(void);
static void sub_2ec1(void);
static void sub_2f4a(void);
static void sub_2fd6(void);
static void sub_3063(void);
static void sub_315c(void);
static void sub_31cf(void);
static void sub_31ff(void);
static void sub_32b9(void);
static void sub_32e5(void);
static void sub_3357(void);
static void sub_3446(void);
static void sub_34fe(void);
static void sub_364b(void);
static void sub_37e1(void);
static void sub_38a0(void);
static void sub_398e(void);
static void sub_3b5c(void);
static void sub_3d2c(void);
static void sub_3d4c(void);
static void sub_3d7e(void);
static void sub_3de4(void);
static void sub_4010(void);
static void sub_403d(void);
static void sub_41a0(void);
static void sub_41b7(void);
static void sub_4223(void);
static void sub_43a5(void);
static void sub_43f9(void);
static void sub_442f(void);
static void sub_4465(void);
static void sub_4491(void);
static void sub_4656(void);
static void sub_46eb(void);
static void sub_4702(void);
static void sub_473f(void);
static void sub_4751(void);
static void sub_478f(void);
static void sub_47c0(void);
static void sub_487c(void);
static void sub_49a6(void);
static void sub_4c2b(void);
static void sub_4dd9(void);
static void sub_526f(void);
static void sub_53b4(void);
static void sub_547d(void);
static void sub_54ac(void);
static void sub_5518(void);
static void sub_557b(void);
static void sub_55f4(void);
static void sub_561a(void);
static void sub_56ad(void);
static void sub_5726(void);
static void sub_5812(void);
static void sub_5850(void);
static void sub_64ad(void);
static void sub_7066(void);
static void sub_70e5(void);
static void sub_7260(void);
static void sub_7292(void);
static void sub_7747(void);
static void sub_77ce(void);
static void sub_77e8(void);


/* ==== sub_0  (被调用 0 次) ==== */
static void sub_0(void) {
    L_0:; /* 0x0 */
    r0 = 0x2800u;
    sp = r0;
    r10 = 0;
    CALL(sub_7747);
    return;
}

/* ==== sub_10  (被调用 99 次) ==== */
static void sub_10(void) {
    L_10:; /* 0x10 */
    r9 = 0x2cu;
    r9 = d32(r9);
    if (!(r9 != 0x0u)) {
        L_1a:; /* 0x1a */
        r15 = 0xfu;
        r9 = 0x9400u;
        iowrs(r9, r15);
        r15 = 0x1u;
        r9 = 0x2cu;
        s32(r9, r15);
        iowrs(r10, r11);
        r15 = 0;
        r9 = 0x9400u;
        iowrs(r9, r15);
        r9 = 0x2cu;
        s32(r9, r15);
        return;
    }
    L_3f:; /* 0x3f */
    iowrs(r10, r11);
    return;
}

/* ==== sub_44  (被调用 10 次) ==== */
static void sub_44(void) {
    L_44:; /* 0x44 */
    r9 = 0x2cu;
    r9 = d32(r9);
    if (!(r9 != 0x0u)) {
        L_4e:; /* 0x4e */
        r15 = 0xfu;
        r9 = 0x9400u;
        iowrs(r9, r15);
        r15 = 0x1u;
        r9 = 0x2cu;
        s32(r9, r15);
        r15 = 0;
        r10 = iord(r10+r15*0x4);
        r9 = 0x9400u;
        iowrs(r9, r15);
        r9 = 0x2cu;
        s32(r9, r15);
        return;
    }
    L_73:; /* 0x73 */
    r9 = 0;
    r10 = iord(r10+r9*0x4);
    return;
}

/* ==== sub_7a  (被调用 4 次) ==== */
static void sub_7a(void) {
    L_7a:; /* 0x7a */
    r15 = 0xfu;
    r9 = 0x9400u;
    iowrs(r9, r15);
    r15 = 0x1u;
    r9 = 0x2cu;
    r14 = 0x1c500u;
    s32(r9, r15);
    r9 = 0x1328u;
    r15 = d32(r9);
    goto L_9f;
    L_99:; /* 0x99 */
    r9 = iord(r14+r15*0x4);
    r15 = r9 & 0x1fu;
    L_9f:; /* 0x9f */
    if (!(r15 == 0x0u)) {
        L_a3:; /* 0xa3 */
        r9 = 0x1c800u;
        iowr(r9, r10);
        r9 = 0x1328u;
        r15 = r15 - 0x1u;
        s32(r9, r15);
        r15 = 0;
        r9 = 0x9400u;
        iowrs(r9, r15);
        r9 = 0x2cu;
        s32(r9, r15);
        return;
    }
    goto L_99;  /* 重复引用 */
}

/* ==== sub_c4  (被调用 39 次) ==== */
static void sub_c4(void) {
    L_c4:; /* 0xc4 */
    r9 = 0x3ffffffu;
    r11 &= r9;
    r9 = 0x80000000u;
    r10 &= 0x1fu;
    r10 <<= 0x1au;
    r10 |= r11;
    r10 |= r9;
    CALL(sub_7a);
    return;
}

/* ==== sub_e3  (被调用 8 次) ==== */
static void sub_e3(void) {
    L_e3:; /* 0xe3 */
    r10 &= 0x1u;
    r10 <<= 0x10u;
    r11 = 0x40001000u;
    r11 = r10 | r11;
    r10 = 0x1c500u;
    CALL(sub_10);
    return;
}

/* ==== sub_fb  (被调用 1 次) ==== */
static void sub_fb(void) {
    L_fb:; /* 0xfb */
    r9 = 0;
    r15 = 0x9000u;
    r10 = iord(r15+r9*0x4);
    r9 = r10 & 0x1u;
    if (!(r9 == 0x1u)) {
        L_10b:; /* 0x10b */
        r10 = 0;
        return;
    }
    L_10f:; /* 0x10f */
    r10 = (r10 >> 4) & 0x3u;
    return;
}

/* ==== sub_114  (被调用 12 次) ==== */
static void sub_114(void) {
    L_114:; /* 0x114 */
    if (!(r10 == 0x0u)) {
        L_118:; /* 0x118 */
        r15 = 0x80000000u;
        r9 = 0x3fffffffu;
        r9 = r10 & r9;
        r9 |= r15;
        r15 = 0x10c00u;
        iowr(r15, r9);
        L_12f:; /* 0x12f */
        return;
    }
    goto L_12f;  /* 重复引用 */
}

/* ==== sub_150  (被调用 1 次) ==== */
static void sub_150(void) {
    L_150:; /* 0x150 */
    r15 = 0x10u;
    r9 = 0x21500u;
    iowr(r9, r15);
    r9 = 0x3fffffcu;
    r10 &= r9;
    r9 = 0x80000000u;
    r10 |= r9;
    r11 &= 0x1u;
    r11 <<= 0x1au;
    r11 = r10 | r11;
    r10 = 0x1ca00u;
    CALL(sub_10);
    r14 = 0x1ca00u;
    r15 = 0;
    L_180:; /* 0x180 */
    r9 = iord(r14+r15*0x4);
    r9 >>= 0x1fu;
    if (!(r9 == 0x1u)) {
        L_18a:; /* 0x18a */
        r14 = 0x1ca00u;
        r15 = 0;
        L_190:; /* 0x190 */
        r9 = iord(r14+r15*0x4);
        r9 = (r9 >> 27) & 0x3u;
        if (!!FZ(falcon_flags)) {
            L_199:; /* 0x199 */
            r10 = 0x1cb00u;
            CALL(sub_44);
            r15 = 0x10u;
            r9 = 0x21b00u;
            iowr(r9, r15);
            return;
        }
        goto L_190;  /* 重复引用 */
        goto L_190;  /* 重复引用 */
        goto L_199;  /* 重复引用 */
    }
    goto L_180;  /* 重复引用 */
}

/* ==== sub_1ac  (被调用 2 次) ==== */
static void sub_1ac(void) {
    L_1ac:; /* 0x1ac */
    for (int i = 4; i >= 0; i--) push32(r[i]);
    r15 = 0x8u;
    r1 = r10;
    r3 = r12;
    r4 = r13;
    r2 = r14;
    r9 = 0x21500u;
    iowr(r9, r15);
    r10 = 0x1cc00u;
    fc_cmp(r13, 0x1u);
    fc_xbit(r0);
    CALL(sub_10);
    r9 = 0x3fffffcu;
    r1 &= r9;
    r9 = 0x80000000u;
    r0 = r0 + 0x2u;
    r1 |= r9;
    r3 &= 0x1u;
    r2 &= 0x1u;
    r0 &= 0x3u;
    r2 <<= 0x1au;
    r0 <<= 0x1du;
    r1 |= r3;
    r10 = 0x1ca00u;
    r1 |= r2;
    r11 = r1 | r0;
    CALL(sub_10);
    r14 = 0x1ca00u;
    r15 = 0;
    L_206:; /* 0x206 */
    r9 = iord(r14+r15*0x4);
    r9 >>= 0x1fu;
    if (!(r9 == 0x1u)) {
        L_210:; /* 0x210 */
        if (!(r4 != 0x1u)) {
            L_214:; /* 0x214 */
            r14 = 0x1ca00u;
            r15 = 0;
            L_21a:; /* 0x21a */
            r9 = iord(r14+r15*0x4);
            r9 = (r9 >> 27) & 0x3u;
            if ((r9 != 0x2u)) goto L_21a;
            L_224:; /* 0x224 */
            r15 = 0x8u;
            r9 = 0x21b00u;
            iowr(r9, r15);
            for (int i = 0; i <= 4; i++) r[i] = pop32();
            return;
            goto L_21a;  /* 重复引用 */
        }
        goto L_224;  /* 重复引用 */
        goto L_214;  /* 重复引用 */
        goto L_21a;  /* 重复引用 */
        goto L_224;  /* 重复引用 */
    }
    goto L_206;  /* 重复引用 */
}

/* ==== sub_22f  (被调用 15 次) ==== */
static void sub_22f(void) {
    L_22f:; /* 0x22f */
    r14 = 0;
    CALL(sub_1ac);
    return;
}

/* ==== sub_237  (被调用 79 次) ==== */
static void sub_237(void) {
    L_237:; /* 0x237 */
    for (int i = 0; i >= 0; i--) push32(r[i]);
    r15 = 0x8u;
    r0 = r10;
    r9 = 0x21500u;
    iowr(r9, r15);
    r10 = 0x1cc00u;
    CALL(sub_10);
    r9 = 0x3fffffcu;
    r10 = 0x1ca00u;
    r0 &= r9;
    r11 = 0xe4000000u;
    r11 = r0 | r11;
    CALL(sub_10);
    r14 = 0x1ca00u;
    r15 = 0;
    L_26a:; /* 0x26a */
    r9 = iord(r14+r15*0x4);
    r9 >>= 0x1fu;
    if (!(r9 == 0x1u)) {
        L_274:; /* 0x274 */
        r14 = 0x1ca00u;
        r15 = 0;
        L_27a:; /* 0x27a */
        r9 = iord(r14+r15*0x4);
        r9 = (r9 >> 27) & 0x3u;
        if (!(r9 != 0x2u)) {
            L_284:; /* 0x284 */
            r15 = 0x8u;
            r9 = 0x21b00u;
            iowr(r9, r15);
            for (int i = 0; i <= 0; i++) r[i] = pop32();
            return;
        }
        goto L_27a;  /* 重复引用 */
        goto L_27a;  /* 重复引用 */
        goto L_284;  /* 重复引用 */
    }
    goto L_26a;  /* 重复引用 */
}

/* ==== sub_28f  (被调用 27 次) ==== */
static void sub_28f(void) {
    L_28f:; /* 0x28f */
    r14 = 0x1u;
    CALL(sub_1ac);
    return;
}

/* ==== sub_297  (被调用 71 次) ==== */
static void sub_297(void) {
    L_297:; /* 0x297 */
    r11 = 0x1u;
    CALL(sub_150);
    return;
}

/* ==== sub_32b  (被调用 2 次) ==== */
static void sub_32b(void) {
    L_32b:; /* 0x32b */
    r9 = 0;
    r15 = 0xb00u;
    r13 = iord(r15+r9*0x4);
    r15 = 0xc00u;
    r14 = iord(r15+r9*0x4);
    fc_cmp(r10, r11);
    if (!(FC(falcon_flags) || FZ(falcon_flags))) {
        L_33e:; /* 0x33e */
        r9 = r10 + 0x1u;
        r15 = r9 - r11;
        goto L_34e;
        L_348:; /* 0x348 */
        r9 = r11 - r10;
        r15 = r9 + 0x1u;
        L_34e:; /* 0x34e */
        r9 = r14 ^ r13;
        r9 = r9 % r15;
        fc_cmp(r10, r11);
        if (!(FC(falcon_flags) || FZ(falcon_flags))) {
            L_359:; /* 0x359 */
            r10 = r9 + r11;
            return;
        }
        L_35e:; /* 0x35e */
        r10 = r9 + r10;
        return;
    }
    goto L_348;  /* 重复引用 */
}

/* ==== sub_363  (被调用 4 次) ==== */
static void sub_363(void) {
    L_363:; /* 0x363 */
    for (int i = 4; i >= 0; i--) push32(r[i]);
    fc_cmp(r12, 0x0u);
    fc_xbit(r4);
    r4 ^= 0x1u;
    r0 = r10;
    r2 = r11;
    r1 = 0;
    r3 = -0x2u;
    goto L_396;
    L_37a:; /* 0x37a */
    CALL(sub_297);
    r1 = r1 + 0x1u;
    r11 = r10 & r3;
    r12 = 0;
    r10 = r0;
    r11 = r4 | r11;
    r0 = r0 + 0x200u;
    r13 = 0;
    CALL(sub_28f);
    L_396:; /* 0x396 */
    r10 = r0;
    fc_cmp(r1, r2);
    if (!FC(falcon_flags)) {
        L_39d:; /* 0x39d */
        for (int i = 0; i <= 4; i++) r[i] = pop32();
        return;
    }
    goto L_37a;  /* 重复引用 */
}

/* ==== sub_39f  (被调用 4 次) ==== */
static void sub_39f(void) {
    L_39f:; /* 0x39f */
    for (int i = 8; i >= 0; i--) push32(r[i]);
    r3 = r10;
    r7 = r11;
    r6 = r12;
    r5 = r13;
    r4 = r14;
    r8 = d32(sp+0x28);
    r2 = 0;
    goto L_3de;
    L_3b4:; /* 0x3b4 */
    r9 = r8 >> r0;
    r9 &= 0x1u;
    if (!!FZ(falcon_flags)) {
        L_3bd:; /* 0x3bd */
        r10 = r1;
        r11 = r5;
        r12 = 0;
        r13 = r4;
        CALL(sub_28f);
        L_3c9:; /* 0x3c9 */
        r0 = r0 + 0x1u;
        r1 = r1 + 0x200u;
        L_3d1:; /* 0x3d1 */
        fc_cmp(r0, r6);
        if (!FC(falcon_flags)) {
            L_3d6:; /* 0x3d6 */
            r2 = r2 + 0x1u;
            r3 = r3 + 0x4000u;
            L_3de:; /* 0x3de */
            fc_cmp(r2, r7);
            if (!!FC(falcon_flags)) {
                goto L_3b4;  /* 重复引用 */
                goto L_3bd;  /* 重复引用 */
                goto L_3c9;  /* 重复引用 */
                goto L_3d1;  /* 重复引用 */
                goto L_3d6;  /* 重复引用 */
                L_3e3:; /* 0x3e3 */
                r1 = r3;
                r0 = 0;
                goto L_3d1;
                L_3eb:; /* 0x3eb */
                for (int i = 0; i <= 8; i++) r[i] = pop32();
                return;
            }
            goto L_3eb;  /* 重复引用 */
        }
        goto L_3b4;  /* 重复引用 */
    }
    goto L_3c9;  /* 重复引用 */
}

/* ==== sub_3ed  (被调用 11 次) ==== */
static void sub_3ed(void) {
    L_3ed:; /* 0x3ed */
    for (int i = 0; i >= 0; i--) push32(r[i]);
    r0 = r11;
    r11 = r10;
    r10 = 0x24ffcu;
    CALL(sub_10);
    if (!(r0 == 0x0u)) {
        L_3ff:; /* 0x3ff */
        r10 = 0x24afcu;
        r11 = 0xau;
        goto L_40f;
        L_409:; /* 0x409 */
        r10 = 0x24afcu;
        r11 = 0xbu;
        L_40f:; /* 0x40f */
        CALL(sub_10);
        for (int i = 0; i <= 0; i++) r[i] = pop32();
        return;
    }
    goto L_409;  /* 重复引用 */
}

/* ==== sub_415  (被调用 9 次) ==== */
static void sub_415(void) {
    L_415:; /* 0x415 */
    if (!(r10 == 0x0u)) {
        L_419:; /* 0x419 */
        r10 = 0x24afcu;
        r11 = 0xcu;
        goto L_429;
        L_423:; /* 0x423 */
        r10 = 0x24afcu;
        r11 = 0xdu;
        L_429:; /* 0x429 */
        CALL(sub_10);
        return;
    }
    goto L_423;  /* 重复引用 */
}

/* ==== sub_42f  (被调用 2 次) ==== */
static void sub_42f(void) {
    L_42f:; /* 0x42f */
    r11 = r10;
    r10 = 0x247fcu;
    CALL(sub_10);
    r10 = 0x24afcu;
    r11 = 0x4u;
    CALL(sub_10);
    return;
}

/* ==== sub_445  (被调用 2 次) ==== */
static void sub_445(void) {
    L_445:; /* 0x445 */
    r11 = r10;
    r10 = 0x247fcu;
    CALL(sub_10);
    r10 = 0x24afcu;
    r11 = 0x3u;
    CALL(sub_10);
    return;
}

/* ==== sub_45b  (被调用 5 次) ==== */
static void sub_45b(void) {
    L_45b:; /* 0x45b */
    for (int i = 7; i >= 0; i--) push32(r[i]);
    r15 = 0x40000000u;
    r9 = 0x21400u;
    iowr(r9, r15);
    if (!(r10 != 0x2u)) {
        L_46e:; /* 0x46e */
        r15 = 0x12b4u;
        r9 = d32(r15);
        if (!(r9 != 0x1u)) {
            L_479:; /* 0x479 */
            goto L_581;
            L_47d:; /* 0x47d */
            r7 = r15;
            r4 = 0;
            r2 = 0x24200u;
            r3 = 0xa4u;
            r5 = 0x1000u;
            r6 = 0x2u;
            L_48e:; /* 0x48e */
            r9 = r3 >> 0x2u;
            r15 = r9 << 0x2u;
            r9 = 0x1000u;
            r15 = r15 + r9;
            r9 = r3 + 0x4u;
            r9 >>= 0x2u;
            r1 = r9 << 0x2u;
            r9 = 0x1000u;
            r1 = r1 + r9;
            r9 = d32(r5+0x4);
            r10 = r2;
            r3 = r3 + 0x8u;
            r9 &= 0x1fu;
            fc_cmp(r4, r9);
            if (!!FC(falcon_flags)) {
                L_4bc:; /* 0x4bc */
                r9 = d32(r15);
                r0 = d32(r5+0x98);
                r1 = d32(r1);
                s32(r7, r6);
                r4 = r4 + 0x1u;
                r0 &= 0xffffu;
                r0 = r0 + r9;
                r11 = r0;
                CALL(sub_10);
                r10 = r2 + 0x100u;
                r11 = r0;
                CALL(sub_10);
                r10 = r2 + 0x200u;
                r1 >>= 0x2u;
                r2 = r2 + 0x4u;
                r11 = r1;
                CALL(sub_10);
                goto L_48e;
                L_4f5:; /* 0x4f5 */
                r7 = r15;
                r4 = 0;
                r2 = 0x24200u;
                r3 = 0x104u;
                r5 = 0x1000u;
                r6 = 0x1u;
                L_506:; /* 0x506 */
                r9 = r3 >> 0x2u;
                r15 = r9 << 0x2u;
                r9 = 0x1000u;
                r15 = r15 + r9;
                r9 = r3 + 0x4u;
                r9 >>= 0x2u;
                r1 = r9 << 0x2u;
                r9 = 0x1000u;
                r1 = r1 + r9;
                r9 = d32(r5+0x4);
                r10 = r2;
                r3 = r3 + 0x8u;
                r9 &= 0x1fu;
                fc_cmp(r4, r9);
                if (!!FC(falcon_flags)) {
                    L_533:; /* 0x533 */
                    r0 = d32(r5+0xc);
                    r15 = d32(r15);
                    r1 = d32(r1);
                    s32(r7, r6);
                    r9 = r0 & 0xffffu;
                    r0 = (r0 >> 16) & 0xffu;
                    r0 = r0 + r9;
                    r0 = r0 + r15;
                    r11 = r0;
                    CALL(sub_10);
                    r10 = r2 + 0x100u;
                    r11 = r0;
                    CALL(sub_10);
                    r10 = r2 + 0x200u;
                    r1 >>= 0x2u;
                    r4 = r4 + 0x1u;
                    r11 = r1;
                    r2 = r2 + 0x4u;
                    CALL(sub_10);
                    goto L_506;
                    L_572:; /* 0x572 */
                    if (!(r10 != 0x4u)) {
                        goto L_47d;  /* 重复引用 */
                        goto L_48e;  /* 重复引用 */
                        goto L_4bc;  /* 重复引用 */
                        L_576:; /* 0x576 */
                        r15 = 0x12b4u;
                        r9 = d32(r15);
                        if ((r9 != 0x2u)) goto L_47d;
                        L_581:; /* 0x581 */
                        r15 = 0x40000000u;
                        r9 = 0x21a00u;
                        iowr(r9, r15);
                        for (int i = 0; i <= 7; i++) r[i] = pop32();
                        return;
                    }
                    goto L_581;  /* 重复引用 */
                }
                goto L_581;  /* 重复引用 */
            }
            goto L_581;  /* 重复引用 */
        }
        goto L_4f5;  /* 重复引用 */
        goto L_479;  /* 重复引用 */
        goto L_4f5;  /* 重复引用 */
        goto L_506;  /* 重复引用 */
        goto L_533;  /* 重复引用 */
    }
    goto L_572;  /* 重复引用 */
}

/* ==== sub_59b  (被调用 1 次) ==== */
static void sub_59b(void) {
    L_59b:; /* 0x59b */
    r10 = r10 - 0x1u;
    fc_cmp(r10, 0x1u);
    if (!(!FC(falcon_flags) && !FZ(falcon_flags))) {
        L_5a4:; /* 0x5a4 */
        r10 = 0xcu;
        r11 = 0;
        CALL(sub_c4);
        L_5ac:; /* 0x5ac */
        return;
    }
    goto L_5ac;  /* 重复引用 */
}

/* ==== sub_5ae  (被调用 1 次) ==== */
static void sub_5ae(void) {
    L_5ae:; /* 0x5ae */
    if (!(r10 == 0x2u)) {
        L_5b2:; /* 0x5b2 */
        if ((r10 != 0x4u)) goto L_5be;
        L_5b6:; /* 0x5b6 */
        r10 = 0xau;
        r11 = 0;
        CALL(sub_c4);
        L_5be:; /* 0x5be */
        return;
    }
    goto L_5b6;  /* 重复引用 */
}

/* ==== sub_5c0  (被调用 30 次) ==== */
static void sub_5c0(void) {
    L_5c0:; /* 0x5c0 */
    r14 = 0x20600u;
    r15 = 0;
    r9 = iord(r14+r15*0x4);
    if (!(r9 == 0x0u)) {
        L_5cd:; /* 0x5cd */
        if (!(r10 != 0x18u)) {
            L_5d1:; /* 0x5d1 */
            r9 = iord(r14+r15*0x4);
            if ((r9 != 0x17u)) goto L_5df;
            L_5d8:; /* 0x5d8 */
            r9 = 0x20600u;
            iowr(r9, r10);
            L_5df:; /* 0x5df */
            r9 = 0x1u;
            r15 = 0x30700u;
            iowr(r15, r9);
            r9 = r10 - 0x48u;
            fc_cmp(r9, 0x1u);
            if (!(FC(falcon_flags) || FZ(falcon_flags))) {
                L_5f1:; /* 0x5f1 */
                if ((r10 != 0x24u)) goto L_5f9;
                L_5f5:; /* 0x5f5 */
                return;
                L_5f9:; /* 0x5f9 */
                r14 = 0x30600u;
                r15 = 0;
                L_5ff:; /* 0x5ff */
                r9 = iord(r14+r15*0x4);
                r9 &= 0x1u;
                if (!(r9 == 0x1u)) {
                    L_609:; /* 0x609 */
                    return;
                }
                goto L_5ff;  /* 重复引用 */
                goto L_5ff;  /* 重复引用 */
                goto L_609;  /* 重复引用 */
            }
            goto L_5f5;  /* 重复引用 */
        }
        goto L_5df;  /* 重复引用 */
        goto L_5d1;  /* 重复引用 */
    }
    goto L_5d8;  /* 重复引用 */
}

/* ==== sub_60b  (被调用 3 次) ==== */
static void sub_60b(void) {
    L_60b:; /* 0x60b */
    r15 = 0x2u;
    r9 = 0x21200u;
    iowr(r9, r15);
    r14 = 0x1370u;
    r13 = 0x136cu;
    r15 = d32(r14);
    r9 = d32(r13);
    r9 ^= r15;
    r9 &= 0x7u;
    if (!!FZ(falcon_flags)) {
        L_629:; /* 0x629 */
        r15 = d32(r14);
        r9 = d32(r13);
        r15 = (r15 >> 3) & 0x1u;
        r9 = (r9 >> 3) & 0x1u;
        fc_cmp(r15, r9);
        if (!FZ(falcon_flags)) {
            L_638:; /* 0x638 */
            r10 = 0x10u;
            CALL(sub_5c0);
            goto L_676;
            L_642:; /* 0x642 */
            r13 = 0x1370u;
            r9 = d32(r13);
            r15 = d32(r13);
            r14 = d32(r13);
            r12 = 0x132cu;
            r9 &= 0x7u;
            r9 <<= 0x3u;
            r14 = r14 + 0x1u;
            r9 = r9 + r12;
            s32(r9, r10);
            s32(r13, r14);
            r14 = d32(r13);
            r15 &= 0x7u;
            r15 = r15 + r15;
            r15 = r15 + 0x1u;
            s32(r12+r15*0x4, r11);
            if (!(r14 != 0x10u)) {
                L_672:; /* 0x672 */
                r9 = 0;
                s32(r13, r9);
                L_676:; /* 0x676 */
                r15 = 0x2u;
                r9 = 0x21800u;
                iowr(r9, r15);
                return;
            }
            goto L_676;  /* 重复引用 */
        }
        goto L_642;  /* 重复引用 */
        goto L_638;  /* 重复引用 */
    }
    goto L_642;  /* 重复引用 */
}

/* ==== sub_681  (被调用 4 次) ==== */
static void sub_681(void) {
    L_681:; /* 0x681 */
    r15 = 0x4u;
    r9 = 0x21200u;
    iowr(r9, r15);
    r14 = 0x13b8u;
    r13 = 0x13b4u;
    r15 = d32(r14);
    r9 = d32(r13);
    r9 ^= r15;
    r9 &= 0x7u;
    if (!!FZ(falcon_flags)) {
        L_69f:; /* 0x69f */
        r15 = d32(r14);
        r9 = d32(r13);
        r15 = (r15 >> 3) & 0x1u;
        r9 = (r9 >> 3) & 0x1u;
        fc_cmp(r15, r9);
        if (!FZ(falcon_flags)) {
            L_6ae:; /* 0x6ae */
            r10 = 0x12u;
            CALL(sub_5c0);
            goto L_6ec;
            L_6b8:; /* 0x6b8 */
            r13 = 0x13b8u;
            r9 = d32(r13);
            r15 = d32(r13);
            r14 = d32(r13);
            r12 = 0x1374u;
            r9 &= 0x7u;
            r9 <<= 0x3u;
            r14 = r14 + 0x1u;
            r9 = r9 + r12;
            s32(r9, r10);
            s32(r13, r14);
            r14 = d32(r13);
            r15 &= 0x7u;
            r15 = r15 + r15;
            r15 = r15 + 0x1u;
            s32(r12+r15*0x4, r11);
            if (!(r14 != 0x10u)) {
                L_6e8:; /* 0x6e8 */
                r9 = 0;
                s32(r13, r9);
                L_6ec:; /* 0x6ec */
                r15 = 0x4u;
                r9 = 0x21800u;
                iowr(r9, r15);
                return;
            }
            goto L_6ec;  /* 重复引用 */
        }
        goto L_6b8;  /* 重复引用 */
        goto L_6ae;  /* 重复引用 */
    }
    goto L_6b8;  /* 重复引用 */
}

/* ==== sub_6f7  (被调用 1 次) ==== */
static void sub_6f7(void) {
    L_6f7:; /* 0x6f7 */
    r9 = 0;
    r14 = 0x1a400u;
    r14 = iord(r14+r9*0x4);
    r15 = 0x1a500u;
    r15 = iord(r15+r9*0x4);
    r9 = 0x20e00u;
    iowr(r9, r14);
    r9 = r9 + 0x100u;
    iowr(r9, r15);
    r10 = 0x20u;
    r14 >>= 0x1fu;
    if (!(r14 != 0x1u)) {
        L_71f:; /* 0x71f */
        r15 = 0;
        r9 = 0x9200u;
        r9 = iord(r9+r15*0x4);
        r15 = 0x20c00u;
        iowr(r15, r9);
        r15 = 0;
        r9 = 0x9300u;
        r9 = iord(r9+r15*0x4);
        r15 = 0x20d00u;
        iowr(r15, r9);
        r10 = 0x22u;
        L_741:; /* 0x741 */
        CALL(sub_5c0);
        return;
    }
    goto L_741;  /* 重复引用 */
}

/* ==== sub_747  (被调用 7 次) ==== */
static void sub_747(void) {
    L_747:; /* 0x747 */
    r10 = 0x24u;
    CALL(sub_5c0);
    return;
}

/* ==== sub_751  (被调用 1 次) ==== */
static void sub_751(void) {
    L_751:; /* 0x751 */
    r15 = 0x10000u;
    r9 = 0;
    r9 = iord(r15+r9*0x4);
    r9 &= r15;
    if (!FZ(falcon_flags)) {
        L_760:; /* 0x760 */
        r10 = 0x21u;
        CALL(sub_5c0);
        L_766:; /* 0x766 */
        return;
    }
    goto L_766;  /* 重复引用 */
}

/* ==== sub_768  (被调用 4 次) ==== */
static void sub_768(void) {
    L_768:; /* 0x768 */
    r15 = 0;
    r9 = 0x9000u;
    r9 = iord(r9+r15*0x4);
    r10 = r9 & 0x1u;
    if (!(r10 != 0x1u)) {
        L_778:; /* 0x778 */
        r9 = (r9 >> 4) & 0x3u;
        if (!(r9 == 0x2u)) {
            L_77f:; /* 0x77f */
            if (!(r9 == 0x0u)) {
                L_783:; /* 0x783 */
                r10 = 0x50u;
                CALL(sub_5c0);
                r10 = 0;
                return;
            }
            L_78d:; /* 0x78d */
            r10 = 0;
            L_78f:; /* 0x78f */
            return;
            goto L_783;  /* 重复引用 */
        }
        goto L_78f;  /* 重复引用 */
        goto L_77f;  /* 重复引用 */
        goto L_783;  /* 重复引用 */
    }
    goto L_78d;  /* 重复引用 */
}

/* ==== sub_791  (被调用 10 次) ==== */
static void sub_791(void) {
    L_791:; /* 0x791 */
    for (int i = 0; i >= 0; i--) push32(r[i]);
    r0 = r10;
    CALL(sub_fb);
    if (!(r0 == 0x5u)) {
        L_79d:; /* 0x79d */
        fc_cmp(r0, 0x5u);
        if (!(!FC(falcon_flags) && !FZ(falcon_flags))) {
            L_7a3:; /* 0x7a3 */
            if (!(r0 != 0x2u)) {
                L_7a7:; /* 0x7a7 */
                goto L_7b9;
                L_7ab:; /* 0x7ab */
                if (!(r0 == 0x6u)) {
                    L_7af:; /* 0x7af */
                    if ((r0 == 0x7u)) goto L_7b9;
                    L_7b3:; /* 0x7b3 */
                    r11 = 0;
                    goto L_7c9;
                    L_7b9:; /* 0x7b9 */
                    r9 = r10 & 0x3u;
                    r15 = r9 << 0xcu;
                    r9 <<= 0x4u;
                    r9 |= r15;
                    r11 = r9 | 0x303u;
                    L_7c9:; /* 0x7c9 */
                    if (!(r10 != 0x0u)) {
                        L_7cd:; /* 0x7cd */
                        r9 = 0x20u;
                        r9 = d32(r9);
                        if ((r9 != 0x0u)) goto L_7df;
                        L_7d7:; /* 0x7d7 */
                        r10 = 0x28b00u;
                        CALL(sub_10);
                        L_7df:; /* 0x7df */
                        for (int i = 0; i <= 0; i++) r[i] = pop32();
                        return;
                    }
                    goto L_7d7;  /* 重复引用 */
                }
                goto L_7b9;  /* 重复引用 */
            }
            goto L_7b3;  /* 重复引用 */
            goto L_7a7;  /* 重复引用 */
        }
        goto L_7ab;  /* 重复引用 */
        goto L_7a3;  /* 重复引用 */
        goto L_7a7;  /* 重复引用 */
        goto L_7ab;  /* 重复引用 */
        goto L_7af;  /* 重复引用 */
        goto L_7b3;  /* 重复引用 */
    }
    goto L_7b9;  /* 重复引用 */
}

/* ==== sub_7e1  (被调用 29 次) ==== */
static void sub_7e1(void) {
    L_7e1:; /* 0x7e1 */
    sp += -0x8u;
    r15 = 0x10u;
    for (int i = 8; i >= 0; i--) push32(r[i]);
    r9 = 0x21300u;
    r1 = r10;
    s32(sp+0x28, r11);
    r2 = r12;
    s32(sp+0x24, r13);
    iowr(r9, r15);
    r9 = 0x14a4u;
    r9 = d32(r9);
    r15 = 0x1u;
    r9 = r15 << r9;
    r0 = r9 - 0x1u;
    if (!(r10 == 0xdu)) {
        L_80b:; /* 0x80b */
        if ((r10 != 0xfu)) goto L_822;
        L_80f:; /* 0x80f */
        r10 = 0x9u;
        r11 = 0x80000u;
        CALL(sub_c4);
        r10 = 0xeu;
        r11 = 0x4000u;
        goto L_835;
        L_822:; /* 0x822 */
        if (!(r10 != 0xeu)) {
            L_826:; /* 0x826 */
            r11 = 0x91800u;
            r10 = 0x9u;
            CALL(sub_c4);
            r10 = r1;
            r11 = 0x200u;
            L_835:; /* 0x835 */
            CALL(sub_c4);
            r11 = r0;
            r10 = 0xdu;
            goto L_8a6;
            L_841:; /* 0x841 */
            if (!(r10 != 0x16u)) {
                L_845:; /* 0x845 */
                r10 = 0x9u;
                r11 = 0x240000u;
                CALL(sub_c4);
                r10 = 0xeu;
                r11 = 0x4000u;
                CALL(sub_c4);
                r9 = 0x14a8u;
                r10 = 0xdu;
                r11 = d32(r9);
                r5 = 0x3u;
                goto L_88f;
                L_866:; /* 0x866 */
                if (!(r10 != 0x17u)) {
                    L_86a:; /* 0x86a */
                    r9 = 0x14b0u;
                    r0 = d32(r9);
                    r10 = 0x9u;
                    r11 = 0x50000u;
                    r5 = 0x3u;
                    r0 = r15 << r0;
                    CALL(sub_c4);
                    r10 = 0xeu;
                    r11 = 0x2000u;
                    CALL(sub_c4);
                    r0 = r0 - 0x1u;
                    r10 = 0xdu;
                    r11 = r0;
                    L_88f:; /* 0x88f */
                    CALL(sub_c4);
                    goto L_8ac;
                    L_897:; /* 0x897 */
                    if (!(r10 == 0x14u)) {
                        L_89b:; /* 0x89b */
                        r5 = 0;
                        goto L_8ac;
                        L_8a1:; /* 0x8a1 */
                        r10 = 0xeu;
                        r11 = 0x200u;
                        L_8a6:; /* 0x8a6 */
                        CALL(sub_c4);
                        r5 = 0x3u;
                        L_8ac:; /* 0x8ac */
                        r10 = d32(sp+0x28);
                        CALL(sub_59b);
                        if (!(r1 == 0x14u)) {
                            L_8b7:; /* 0x8b7 */
                            r1 = r2;
                            r0 = 0;
                            goto L_95f;
                            L_8bf:; /* 0x8bf */
                            r7 = r2;
                            r6 = 0;
                            goto L_943;
                            L_8c7:; /* 0x8c7 */
                            r9 = d32(r7);
                            r4 = 0;
                            r8 = r5 | r9;
                            L_8ce:; /* 0x8ce */
                            r9 = 0x20800u;
                            iowr(r9, r4);
                            r3 = 0;
                            r9 = r4 << 0x2u;
                            r2 = 0;
                            r0 = r9 & 0x1fu;
                            r1 = r9 >> 0x5u;
                            L_8e2:; /* 0x8e2 */
                            fc_cmp(r1, 0x1u);
                            if (!(FC(falcon_flags) || FZ(falcon_flags))) {
                                L_8e8:; /* 0x8e8 */
                                r10 = 0x37u;
                                CALL(sub_5c0);
                                goto L_911;
                                L_8f2:; /* 0x8f2 */
                                r15 = 0x13e0u;
                                r9 = d32(r15+r1*0x4);
                                r9 >>= r0;
                                r0 = r0 + 0x1u;
                                r9 &= 0x1u;
                                r9 <<= r3;
                                r2 |= r9;
                                if (!(r0 != 0x20u)) {
                                    L_90c:; /* 0x90c */
                                    r1 = r1 + 0x1u;
                                    r0 = 0;
                                    L_911:; /* 0x911 */
                                    r3 = r3 + 0x1u;
                                    if (!(r3 != 0x4u)) {
                                        L_918:; /* 0x918 */
                                        if (!(r2 == 0x0u)) {
                                            L_91c:; /* 0x91c */
                                            r11 = r2;
                                            r10 = 0xdu;
                                            CALL(sub_c4);
                                            r10 = 0x9u;
                                            r11 = r4 << 0xdu;
                                            r11 >>= 0x2u;
                                            CALL(sub_c4);
                                            r10 = r8;
                                            CALL(sub_7a);
                                            L_936:; /* 0x936 */
                                            r4 = r4 + 0x1u;
                                            if (!(r4 != 0xcu)) {
                                                L_93d:; /* 0x93d */
                                                r6 = r6 + 0x1u;
                                                r7 = r7 + 0x4u;
                                                L_943:; /* 0x943 */
                                                r9 = d32(sp+0x24);
                                                fc_cmp(r6, r9);
                                                if (!FC(falcon_flags)) {
                                                    L_94c:; /* 0x94c */
                                                    goto L_967;
                                                    L_950:; /* 0x950 */
                                                    r10 = d32(r1);
                                                    r0 = r0 + 0x1u;
                                                    r1 = r1 + 0x4u;
                                                    r10 = r5 | r10;
                                                    CALL(sub_7a);
                                                    L_95f:; /* 0x95f */
                                                    r15 = d32(sp+0x24);
                                                    fc_cmp(r0, r15);
                                                    if (FC(falcon_flags)) goto L_950;
                                                    L_967:; /* 0x967 */
                                                    r10 = d32(sp+0x28);
                                                    CALL(sub_5ae);
                                                    r15 = 0x10u;
                                                    r9 = 0x21900u;
                                                    iowr(r9, r15);
                                                    for (int i = 0; i <= 8; i++) r[i] = pop32();
                                                    sp += 0x8;
                                                    return;
                                                }
                                                goto L_8c7;  /* 重复引用 */
                                            }
                                            goto L_8ce;  /* 重复引用 */
                                        }
                                        goto L_936;  /* 重复引用 */
                                        goto L_91c;  /* 重复引用 */
                                        goto L_936;  /* 重复引用 */
                                        goto L_93d;  /* 重复引用 */
                                    }
                                    goto L_8e2;  /* 重复引用 */
                                }
                                goto L_911;  /* 重复引用 */
                            }
                            goto L_8f2;  /* 重复引用 */
                            goto L_950;  /* 重复引用 */
                            goto L_95f;  /* 重复引用 */
                        }
                        goto L_8bf;  /* 重复引用 */
                    }
                    goto L_8a1;  /* 重复引用 */
                }
                goto L_897;  /* 重复引用 */
            }
            goto L_866;  /* 重复引用 */
        }
        goto L_841;  /* 重复引用 */
        goto L_822;  /* 重复引用 */
        goto L_826;  /* 重复引用 */
        goto L_841;  /* 重复引用 */
        goto L_845;  /* 重复引用 */
        goto L_866;  /* 重复引用 */
        goto L_86a;  /* 重复引用 */
        goto L_88f;  /* 重复引用 */
        goto L_897;  /* 重复引用 */
        goto L_89b;  /* 重复引用 */
        goto L_8a1;  /* 重复引用 */
    }
    goto L_80f;  /* 重复引用 */
}

/* ==== sub_97a  (被调用 13 次) ==== */
static void sub_97a(void) {
    L_97a:; /* 0x97a */
    for (int i = 0; i >= 0; i--) push32(r[i]);
    r9 = r10;
    r10 = 0x3c8u;
    if (!(r9 == 0x1u)) {
        L_986:; /* 0x986 */
        r10 = 0xd34u;
        if (!(r9 == 0x2u)) {
            L_98e:; /* 0x98e */
            r10 = 0x30u;
            if (!(r9 == 0xcu)) {
                L_995:; /* 0x995 */
                r10 = 0xfcu;
                if (!(r9 == 0x1au)) {
                    L_99c:; /* 0x99c */
                    if (!(r9 == 0x1bu)) {
                        L_9a1:; /* 0x9a1 */
                        if (!(r9 != 0xdu)) {
                            L_9a5:; /* 0x9a5 */
                            r9 = 0x14a4u;
                            r0 = d32(r9);
                            r11 = 0x318u;
                            r10 = r0;
                            CALL(sub_77ce);
                            r9 = 0x14acu;
                            r15 = d32(r9);
                            r9 = 0x14b0u;
                            r14 = d32(r9);
                            r9 = r0 << 0x3u;
                            r0 = r0 + r0;
                            r0 = r0 + r9;
                            r9 = r15 + r15;
                            r9 = r9 + r15;
                            r9 <<= 0x2u;
                            r0 = r0 + r10;
                            r0 <<= 0x2u;
                            r0 = r0 + 0xcu;
                            r0 = r0 + r9;
                            r9 = r14 << 0x2u;
                            r9 = r9 + r14;
                            r9 <<= 0x2u;
                            r10 = r0 + r9;
                            goto L_a11;
                            L_9ee:; /* 0x9ee */
                            if (!(r9 != 0xfu)) {
                                L_9f2:; /* 0x9f2 */
                                r9 = 0x14a4u;
                                r9 = d32(r9);
                                r15 = r9 + r9;
                                r15 = r15 + r9;
                                r10 = r15 << 0x4u;
                                goto L_a11;
                                L_a05:; /* 0xa05 */
                                r10 = 0x40u;
                                CALL(sub_5c0);
                                r10 = 0;
                                goto L_a1e;
                                L_a11:; /* 0xa11 */
                                if ((r10 == 0x0u)) goto L_a1e;
                                L_a15:; /* 0xa15 */
                                r9 = r10 >> 0x8u;
                                r9 = r9 + 0x1u;
                                r10 = r9 << 0x8u;
                                L_a1e:; /* 0xa1e */
                                for (int i = 0; i <= 0; i++) r[i] = pop32();
                                return;
                            }
                            goto L_a05;  /* 重复引用 */
                        }
                        goto L_9ee;  /* 重复引用 */
                        goto L_9a5;  /* 重复引用 */
                        goto L_9ee;  /* 重复引用 */
                        goto L_9f2;  /* 重复引用 */
                        goto L_a05;  /* 重复引用 */
                        goto L_a11;  /* 重复引用 */
                    }
                    L_a20:; /* 0xa20 */
                    r10 = 0x8u;
                    goto L_a15;
                    CALL(sub_a26);  /* 跨函数进入(尾调用近似) */
                    return;
                    goto L_9a1;  /* 重复引用 */
                    goto L_9a5;  /* 重复引用 */
                    goto L_9ee;  /* 重复引用 */
                    goto L_9f2;  /* 重复引用 */
                    goto L_a05;  /* 重复引用 */
                    goto L_a11;  /* 重复引用 */
                    goto L_a20;  /* 重复引用 */
                }
                goto L_a15;  /* 重复引用 */
                goto L_99c;  /* 重复引用 */
                goto L_9a1;  /* 重复引用 */
                goto L_9a5;  /* 重复引用 */
                goto L_9ee;  /* 重复引用 */
                goto L_9f2;  /* 重复引用 */
                goto L_a05;  /* 重复引用 */
                goto L_a11;  /* 重复引用 */
                goto L_a20;  /* 重复引用 */
            }
            goto L_a15;  /* 重复引用 */
            goto L_995;  /* 重复引用 */
            goto L_99c;  /* 重复引用 */
            goto L_9a1;  /* 重复引用 */
            goto L_9a5;  /* 重复引用 */
            goto L_9ee;  /* 重复引用 */
            goto L_9f2;  /* 重复引用 */
            goto L_a05;  /* 重复引用 */
            goto L_a11;  /* 重复引用 */
            goto L_a20;  /* 重复引用 */
        }
        goto L_a15;  /* 重复引用 */
        goto L_98e;  /* 重复引用 */
        goto L_995;  /* 重复引用 */
        goto L_99c;  /* 重复引用 */
        goto L_9a1;  /* 重复引用 */
        goto L_9a5;  /* 重复引用 */
        goto L_9ee;  /* 重复引用 */
        goto L_9f2;  /* 重复引用 */
        goto L_a05;  /* 重复引用 */
        goto L_a11;  /* 重复引用 */
        goto L_a20;  /* 重复引用 */
    }
    goto L_a15;  /* 重复引用 */
}

/* ==== sub_a26  (被调用 2 次) ==== */
static void sub_a26(void) {
    L_a26:; /* 0xa26 */
    for (int i = 3; i >= 0; i--) push32(r[i]);
    r15 = 0x1u;
    r9 = 0x21500u;
    iowr(r9, r15);
    r1 = 0;
    r0 = 0x502800u;
    r3 = 0x14a0u;
    r2 = 0x87654321u;
    goto L_a57;
    L_a44:; /* 0xa44 */
    r10 = r0;
    CALL(sub_297);
    fc_cmp(r10, r2);
    if (!!FZ(falcon_flags)) {
        L_a4f:; /* 0xa4f */
        r1 = r1 + 0x1u;
        r0 = r0 + 0x8000u;
        L_a57:; /* 0xa57 */
        r9 = d32(r3);
        fc_cmp(r1, r9);
        if (!FC(falcon_flags)) {
            L_a5e:; /* 0xa5e */
            r15 = 0x1u;
            r9 = 0x21b00u;
            iowr(r9, r15);
            for (int i = 0; i <= 3; i++) r[i] = pop32();
            return;
        }
        goto L_a44;  /* 重复引用 */
    }
    goto L_a44;  /* 重复引用 */
}

/* ==== sub_a69  (被调用 1 次) ==== */
static void sub_a69(void) {
    L_a69:; /* 0xa69 */
    r15 = 0x2u;
    r9 = 0x21500u;
    iowr(r9, r15);
    L_a72:; /* 0xa72 */
    r10 = 0x825808u;
    CALL(sub_297);
    r10 &= 0x2u;
    if (!FZ(falcon_flags)) {
        L_a81:; /* 0xa81 */
        r15 = 0x2u;
        r9 = 0x21b00u;
        iowr(r9, r15);
        return;
    }
    goto L_a72;  /* 重复引用 */
}

/* ==== sub_a8e  (被调用 1 次) ==== */
static void sub_a8e(void) {
    L_a8e:; /* 0xa8e */
    for (int i = 6; i >= 0; i--) push32(r[i]);
    r2 = 0;
    r1 = 0x502608u;
    r0 = 0;
    r4 = 0x14a0u;
    r3 = 0;
    goto L_abe;
    L_aa2:; /* 0xaa2 */
    CALL(sub_297);
    r15 = 0x14c4u;
    r9 = r0 + r15;
    r10 &= 0x1fu;
    r15 = 0x14f4u;
    s32(r9, r10);
    r2 = r2 + 0x1u;
    r9 = r0 + r15;
    s32(r9, r3);
    L_abe:; /* 0xabe */
    r9 = d32(r4);
    r10 = r1;
    r0 = r0 + 0x4u;
    r1 = r1 + 0x8000u;
    fc_cmp(r2, r9);
    if (!FC(falcon_flags)) {
        L_acf:; /* 0xacf */
        r5 = 0x14f8u;
        r3 = 0;
        r2 = r5;
        r1 = 0x500c3cu;
        r4 = 0x14a0u;
        goto L_b07;
        L_ae3:; /* 0xae3 */
        r10 = r0;
        r0 = r0 + 0x4u;
        CALL(sub_297);
        if (!(r10 == 0x0u)) {
            L_af0:; /* 0xaf0 */
            r9 = d32(r2);
            r9 = r9 + 0x1u;
            s32(r2, r9);
            L_af7:; /* 0xaf7 */
            fc_cmp(r0, r1);
            if (!!FZ(falcon_flags)) {
                L_afc:; /* 0xafc */
                r3 = r3 + 0x1u;
                r1 = r1 + 0x8000u;
                r2 = r2 + 0x4u;
                L_b07:; /* 0xb07 */
                r9 = d32(r4);
                fc_cmp(r3, r9);
                if (!FC(falcon_flags)) {
                    L_b0e:; /* 0xb0e */
                    r1 = 0;
                    r4 = 0x500c30u;
                    r6 = 0x14a0u;
                    goto L_b62;
                    L_b1c:; /* 0xb1c */
                    r0 = r1 - 0xcu;
                    goto L_ae3;
                    L_b23:; /* 0xb23 */
                    r10 = r3;
                    CALL(sub_297);
                    r9 = r10 & 0xffu;
                    if (!FZ(falcon_flags)) {
                        L_b2f:; /* 0xb2f */
                        r10 = r9;
                        r15 = 0;
                        L_b33:; /* 0xb33 */
                        r9 = r10 - 0x1u;
                        r15 = r15 + 0x1u;
                        r10 &= r9;
                        if (!!FZ(falcon_flags)) {
                            L_b3f:; /* 0xb3f */
                            s32(r0, r15);
                            goto L_b47;
                            L_b45:; /* 0xb45 */
                            s32(r0, r9);
                            L_b47:; /* 0xb47 */
                            r2 = r2 + 0x1u;
                            r0 = r0 + 0x4u;
                            r3 = r3 + 0x4u;
                            L_b50:; /* 0xb50 */
                            r9 = d32(r5);
                            fc_cmp(r2, r9);
                            if (!FC(falcon_flags)) {
                                L_b57:; /* 0xb57 */
                                r1 = r1 + 0x1u;
                                r4 = r4 + 0x8000u;
                                r5 = r5 + 0x4u;
                                L_b62:; /* 0xb62 */
                                r9 = d32(r6);
                                fc_cmp(r1, r9);
                                if (!!FC(falcon_flags)) {
                                    goto L_b23;  /* 重复引用 */
                                    goto L_b2f;  /* 重复引用 */
                                    goto L_b33;  /* 重复引用 */
                                    goto L_b3f;  /* 重复引用 */
                                    goto L_b45;  /* 重复引用 */
                                    goto L_b47;  /* 重复引用 */
                                    goto L_b50;  /* 重复引用 */
                                    goto L_b57;  /* 重复引用 */
                                    L_b69:; /* 0xb69 */
                                    r9 = r1 + r1;
                                    r9 = r9 + r1;
                                    r3 = r4;
                                    r0 = r9 << 0x2u;
                                    r2 = 0;
                                    r9 = 0x1528u;
                                    r0 = r0 + r9;
                                    goto L_b50;
                                    L_b81:; /* 0xb81 */
                                    r15 = 0;
                                    r9 = 0x12b4u;
                                    s32(r9, r15);
                                    for (int i = 0; i <= 6; i++) r[i] = pop32();
                                    return;
                                }
                                goto L_b81;  /* 重复引用 */
                            }
                            goto L_b23;  /* 重复引用 */
                        }
                        goto L_b33;  /* 重复引用 */
                        goto L_b33;  /* 重复引用 */
                        goto L_b3f;  /* 重复引用 */
                    }
                    goto L_b45;  /* 重复引用 */
                    goto L_b23;  /* 重复引用 */
                    goto L_b2f;  /* 重复引用 */
                    goto L_b33;  /* 重复引用 */
                    goto L_b3f;  /* 重复引用 */
                    goto L_b45;  /* 重复引用 */
                    goto L_b47;  /* 重复引用 */
                    goto L_b50;  /* 重复引用 */
                    goto L_b57;  /* 重复引用 */
                    goto L_b62;  /* 重复引用 */
                    goto L_b69;  /* 重复引用 */
                    goto L_b81;  /* 重复引用 */
                }
                goto L_b1c;  /* 重复引用 */
            }
            goto L_ae3;  /* 重复引用 */
        }
        goto L_af7;  /* 重复引用 */
        goto L_ae3;  /* 重复引用 */
        goto L_af0;  /* 重复引用 */
        goto L_af7;  /* 重复引用 */
        goto L_afc;  /* 重复引用 */
        goto L_b07;  /* 重复引用 */
        goto L_b0e;  /* 重复引用 */
        goto L_b1c;  /* 重复引用 */
        goto L_b23;  /* 重复引用 */
        goto L_b2f;  /* 重复引用 */
        goto L_b33;  /* 重复引用 */
        goto L_b3f;  /* 重复引用 */
        goto L_b45;  /* 重复引用 */
        goto L_b47;  /* 重复引用 */
        goto L_b50;  /* 重复引用 */
        goto L_b57;  /* 重复引用 */
        goto L_b62;  /* 重复引用 */
        goto L_b69;  /* 重复引用 */
        goto L_b81;  /* 重复引用 */
    }
    goto L_aa2;  /* 重复引用 */
}

/* ==== sub_b8b  (被调用 4 次) ==== */
static void sub_b8b(void) {
    L_b8b:; /* 0xb8b */
    for (int i = 1; i >= 0; i--) push32(r[i]);
    r15 = 0x80u;
    r9 = 0x21400u;
    iowr(r9, r15);
    r10 = 0x23900u;
    CALL(sub_44);
    r15 = 0xff000000u;
    r9 = r10;
    r9 &= r15;
    r9 |= 0x5u;
    r0 = 0x18u;
    r11 = r9;
    s32(r0, r10);
    r1 = 0x1cu;
    r10 = 0x23900u;
    s32(r1, r9);
    CALL(sub_10);
    r10 = 0x419da8u;
    r11 = 0x11u;
    r12 = 0;
    r13 = 0x1u;
    CALL(sub_22f);
    r10 = 0x41a0acu;
    r11 = 0x3fu;
    r12 = 0;
    r13 = 0x1u;
    CALL(sub_22f);
    r12 = 0;
    r13 = 0x1u;
    r10 = 0x41a928u;
    r11 = 0x11u;
    CALL(sub_22f);
    r11 = 0x11u;
    r10 = 0x24afcu;
    CALL(sub_10);
    r10 = 0x23900u;
    CALL(sub_44);
    r9 = 0xff00000fu;
    s32(r0, r10);
    r11 = r10;
    r10 = 0x23900u;
    r11 &= r9;
    r11 |= 0x50u;
    s32(r1, r11);
    CALL(sub_10);
    for (int i = 0; i <= 1; i++) r[i] = pop32();
    return;
}

/* ==== sub_c19  (被调用 1 次) ==== */
static void sub_c19(void) {
    L_c19:; /* 0xc19 */
    r15 = 0x200u;
    r9 = 0x21400u;
    iowr(r9, r15);
    r10 = 0x10ac08u;
    CALL(sub_297);
    r9 = 0x100000u;
    r10 &= r9;
    if (!FZ(falcon_flags)) {
        L_c35:; /* 0xc35 */
        r15 = 0x1u;
        r9 = 0x1410u;
        s32(r9, r15);
        L_c3d:; /* 0xc3d */
        r15 = 0x1u;
        r9 = 0x20000u;
        iowr(r9, r15);
        r15 = 0x200u;
        r9 = r9 + 0x1a00u;
        iowr(r9, r15);
        return;
    }
    goto L_c3d;  /* 重复引用 */
}

/* ==== sub_c53  (被调用 2 次) ==== */
static void sub_c53(void) {
    L_c53:; /* 0xc53 */
    fc_cmp(r10, 0x0u);
    fc_xbit(r14);
    r14 ^= 0x1u;
    if (!(r11 != 0x1u)) {
        L_c60:; /* 0xc60 */
        r15 = r14 << 0x4u;
        r9 = 0x22300u;
        iowr(r9, r15);
        L_c6a:; /* 0xc6a */
        if (!(r12 != 0x1u)) {
            L_c6e:; /* 0xc6e */
            r11 = r14 << 0x4u;
            r10 = 0x41a88cu;
            CALL(sub_237);
            L_c79:; /* 0xc79 */
            return;
        }
        goto L_c79;  /* 重复引用 */
    }
    goto L_c6a;  /* 重复引用 */
}

/* ==== sub_c7b  (被调用 8 次) ==== */
static void sub_c7b(void) {
    L_c7b:; /* 0xc7b */
    r14 = r11;
    r13 = r12;
    r15 = 0x20u;
    r9 = 0x21400u;
    iowr(r9, r15);
    r11 = r10;
    r12 = r14;
    r10 = 0;
    CALL(sub_c53);
    r15 = 0x20u;
    r9 = 0x21a00u;
    iowr(r9, r15);
    return;
}

/* ==== sub_c9d  (被调用 1 次) ==== */
static void sub_c9d(void) {
    L_c9d:; /* 0xc9d */
    r15 = 0x20000u;
    r9 = 0x21400u;
    iowr(r9, r15);
    r14 = 0x10000u;
    r15 = 0;
    L_cae:; /* 0xcae */
    r9 = iord(r14+r15*0x4);
    r9 &= 0x200u;
    if (!FZ(falcon_flags)) {
        L_cb8:; /* 0xcb8 */
        r15 = 0x20000u;
        r9 = 0x21a00u;
        iowr(r9, r15);
        return;
    }
    goto L_cae;  /* 重复引用 */
}

/* ==== sub_cc5  (被调用 33 次) ==== */
static void sub_cc5(void) {
    L_cc5:; /* 0xcc5 */
    for (int i = 1; i >= 0; i--) push32(r[i]);
    r1 = r10;
    r0 = r11;
    r10 = 0x10500u;
    r11 = 0;
    CALL(sub_10);
    r10 = 0x10504u;
    r11 = 0;
    CALL(sub_10);
    r11 = r0;
    r10 = 0x41a500u;
    CALL(sub_237);
    r11 = r1;
    r10 = 0x41a504u;
    CALL(sub_237);
    for (int i = 0; i <= 1; i++) r[i] = pop32();
    return;
}

/* ==== sub_cf5  (被调用 8 次) ==== */
static void sub_cf5(void) {
    L_cf5:; /* 0xcf5 */
    r14 = r11;
    r13 = r12;
    r15 = 0x10u;
    r9 = 0x21400u;
    iowr(r9, r15);
    r11 = r10;
    r12 = r14;
    r10 = 0x1u;
    CALL(sub_c53);
    r15 = 0x10u;
    r9 = 0x21a00u;
    iowr(r9, r15);
    return;
}

/* ==== sub_d17  (被调用 5 次) ==== */
static void sub_d17(void) {
    L_d17:; /* 0xd17 */
    r15 = 0;
    r9 = 0x19100u;
    r9 = iord(r9+r15*0x4);
    r9 &= 0x3u;
    if (!FZ(falcon_flags)) {
        L_d26:; /* 0xd26 */
        if (!(r11 != 0x0u)) {
            L_d2a:; /* 0xd2a */
            r9 = 0x13c4u;
            r15 = 0x20500u;
            r14 = d32(r9);
            goto L_d4e;
            L_d38:; /* 0xd38 */
            if (!(r11 == 0x1u)) {
                L_d3c:; /* 0xd3c */
                r15 = 0;
                r14 = 0;
                goto L_d4e;
                L_d44:; /* 0xd44 */
                r9 = 0x13c8u;
                r14 = d32(r9);
                r15 = 0x20800u;
                L_d4e:; /* 0xd4e */
                r9 = 0;
                r9 = iord(r15+r9*0x4);
                if (!(r9 == 0xeu)) {
                    L_d57:; /* 0xd57 */
                    if (!(r14 == 0x0u)) {
                        L_d5b:; /* 0xd5b */
                        iowr(r15, r10);
                        r13 = 0;
                        L_d60:; /* 0xd60 */
                        r9 = iord(r15+r13*0x4);
                        if (!(r9 == 0x0u)) {
                            L_d67:; /* 0xd67 */
                            r9 = iord(r15+r13*0x4);
                            if ((r9 != 0xeu)) goto L_d60;
                            L_d6e:; /* 0xd6e */
                            r9 = 0;
                            r9 = iord(r15+r9*0x4);
                            if ((r9 != 0xeu)) goto L_d79;
                            L_d77:; /* 0xd77 */
                            r14 = 0;
                            L_d79:; /* 0xd79 */
                            if (!(r11 != 0x0u)) {
                                L_d7d:; /* 0xd7d */
                                r9 = 0x13c4u;
                                s32(r9, r14);
                                return;
                            }
                            L_d85:; /* 0xd85 */
                            if (!(r11 != 0x1u)) {
                                L_d89:; /* 0xd89 */
                                r9 = 0x13c8u;
                                s32(r9, r14);
                                L_d8f:; /* 0xd8f */
                                return;
                            }
                            goto L_d8f;  /* 重复引用 */
                        }
                        goto L_d6e;  /* 重复引用 */
                        goto L_d60;  /* 重复引用 */
                        goto L_d67;  /* 重复引用 */
                        goto L_d6e;  /* 重复引用 */
                    }
                    goto L_d79;  /* 重复引用 */
                    goto L_d5b;  /* 重复引用 */
                    goto L_d60;  /* 重复引用 */
                    goto L_d67;  /* 重复引用 */
                    goto L_d6e;  /* 重复引用 */
                }
                goto L_d77;  /* 重复引用 */
            }
            goto L_d44;  /* 重复引用 */
        }
        goto L_d38;  /* 重复引用 */
        goto L_d2a;  /* 重复引用 */
        goto L_d38;  /* 重复引用 */
        goto L_d3c;  /* 重复引用 */
        goto L_d44;  /* 重复引用 */
        goto L_d4e;  /* 重复引用 */
        goto L_d57;  /* 重复引用 */
        goto L_d5b;  /* 重复引用 */
        goto L_d60;  /* 重复引用 */
        goto L_d67;  /* 重复引用 */
        goto L_d6e;  /* 重复引用 */
        goto L_d77;  /* 重复引用 */
        goto L_d79;  /* 重复引用 */
        goto L_d7d;  /* 重复引用 */
        goto L_d85;  /* 重复引用 */
        goto L_d89;  /* 重复引用 */
    }
    goto L_d8f;  /* 重复引用 */
}

/* ==== sub_d91  (被调用 1 次) ==== */
static void sub_d91(void) {
    L_d91:; /* 0xd91 */
    for (int i = 5; i >= 0; i--) push32(r[i]);
    r15 = 0x10000000u;
    r9 = 0x21400u;
    iowr(r9, r15);
    if (!(r10 == 0x0u)) {
        L_da3:; /* 0xda3 */
        r4 = 0x14c8u;
        r3 = 0;
        r2 = 0x504340u;
        r5 = 0x14a0u;
        goto L_ddb;
        L_db5:; /* 0xdb5 */
        r0 = r0 + 0x1u;
        r12 = 0;
        r13 = r11;
        CALL(sub_22f);
        L_dc0:; /* 0xdc0 */
        r9 = d32(r4);
        r10 = r1;
        r11 = 0x1u;
        r1 = r1 + 0x800u;
        fc_cmp(r0, r9);
        if (!FC(falcon_flags)) {
            L_dd0:; /* 0xdd0 */
            r3 = r3 + r11;
            r2 = r2 + 0x8000u;
            r4 = r4 + 0x4u;
            L_ddb:; /* 0xddb */
            r9 = d32(r5);
            fc_cmp(r3, r9);
            if (!!FC(falcon_flags)) {
                goto L_db5;  /* 重复引用 */
                goto L_dc0;  /* 重复引用 */
                goto L_dd0;  /* 重复引用 */
                L_de2:; /* 0xde2 */
                r1 = r2;
                r0 = 0;
                goto L_dc0;
                L_dea:; /* 0xdea */
                r11 = 0x1u;
                r10 = 0x419b40u;
                r12 = 0;
                r13 = r11;
                CALL(sub_22f);
                L_df8:; /* 0xdf8 */
                for (int i = 0; i <= 5; i++) r[i] = pop32();
                return;
            }
            goto L_df8;  /* 重复引用 */
        }
        goto L_db5;  /* 重复引用 */
        goto L_db5;  /* 重复引用 */
        goto L_dc0;  /* 重复引用 */
        goto L_dd0;  /* 重复引用 */
        goto L_ddb;  /* 重复引用 */
        goto L_de2;  /* 重复引用 */
    }
    goto L_dea;  /* 重复引用 */
}

/* ==== sub_e0c  (被调用 2 次) ==== */
static void sub_e0c(void) {
    L_e0c:; /* 0xe0c */
    r10 = 0x1fa800u;
    CALL(sub_297);
    return;
}

/* ==== sub_e16  (被调用 2 次) ==== */
static void sub_e16(void) {
    L_e16:; /* 0xe16 */
    for (int i = 2; i >= 0; i--) push32(r[i]);
    r9 = 0x1000u;
    r15 = 0x21400u;
    iowr(r15, r9);
    CALL(sub_e0c);
    r10 &= 0x10u;
    if (!!FZ(falcon_flags)) {
        L_e2c:; /* 0xe2c */
        r1 = 0;
        r0 = 0x500304u;
        r2 = 0x14a0u;
        goto L_e66;
        L_e3a:; /* 0xe3a */
        r15 = 0x1000u;
        r9 = 0x21a00u;
        iowr(r9, r15);
        r10 = 0x1u;
        goto L_e80;
        L_e4a:; /* 0xe4a */
        CALL(sub_297);
        r1 = r1 + 0x1u;
        r10 &= 0x1u;
        if (!(r10 != 0x1u)) {
            L_e58:; /* 0xe58 */
            r15 = 0x1000u;
            r9 = 0x21a00u;
            iowr(r9, r15);
            goto L_e80;
            L_e66:; /* 0xe66 */
            r9 = d32(r2);
            r10 = r0;
            r0 = r0 + 0x8000u;
            fc_cmp(r1, r9);
            if (!FC(falcon_flags)) {
                L_e74:; /* 0xe74 */
                r15 = 0x1000u;
                r9 = 0x21a00u;
                iowr(r9, r15);
                r10 = 0;
                L_e80:; /* 0xe80 */
                for (int i = 0; i <= 2; i++) r[i] = pop32();
                return;
            }
            goto L_e4a;  /* 重复引用 */
        }
        goto L_e66;  /* 重复引用 */
        goto L_e4a;  /* 重复引用 */
        goto L_e58;  /* 重复引用 */
        goto L_e66;  /* 重复引用 */
        goto L_e74;  /* 重复引用 */
    }
    goto L_e3a;  /* 重复引用 */
}

/* ==== sub_e82  (被调用 2 次) ==== */
static void sub_e82(void) {
    L_e82:; /* 0xe82 */
    r15 = 0x20u;
    r9 = 0x21300u;
    iowr(r9, r15);
    r15 = 0x4u;
    r14 = r10 & 0x1u;
    if (!FZ(falcon_flags)) {
        L_e93:; /* 0xe93 */
        r15 = 0x104u;
        L_e96:; /* 0xe96 */
        r9 = r10 & 0x2u;
        if (!FZ(falcon_flags)) {
            L_e9c:; /* 0xe9c */
            r15 |= 0x1000u;
            goto L_eae;
            L_ea4:; /* 0xea4 */
            r9 = r10 & 0x4u;
            if (!FZ(falcon_flags)) {
                L_eaa:; /* 0xeaa */
                r15 |= 0x2000u;
                L_eae:; /* 0xeae */
                r9 = 0x30200u;
                iowr(r9, r15);
                r15 = 0x1u;
                r9 = 0x12c0u;
                s32(r9, r15);
                if (!(r14 == 0x0u)) {
                    L_ec1:; /* 0xec1 */
                    CALL(sub_e16);
                    if (!(r10 == 0x0u)) {
                        L_ec9:; /* 0xec9 */
                        r10 = 0x19u;
                        CALL(sub_5c0);
                        L_ecf:; /* 0xecf */
                        return;
                    }
                    goto L_ecf;  /* 重复引用 */
                    goto L_ec9;  /* 重复引用 */
                }
                goto L_ecf;  /* 重复引用 */
            }
            goto L_eae;  /* 重复引用 */
        }
        goto L_ea4;  /* 重复引用 */
    }
    goto L_e96;  /* 重复引用 */
}

/* ==== sub_ed1  (被调用 6 次) ==== */
static void sub_ed1(void) {
    L_ed1:; /* 0xed1 */
    r14 = 0x22100u;
    r9 = 0;
    r15 = iord(r14+r9*0x4);
    r9 = (r15 >> 8) & 0x1u;
    if (!FZ(falcon_flags)) {
        L_ee0:; /* 0xee0 */
        r9 = -0x101u;
        r9 = r15 & r9;
        iowr(r14, r9);
        r15 = 0;
        L_eeb:; /* 0xeeb */
        r9 = iord(r14+r15*0x4);
        r9 &= 0x100u;
        if (!FZ(falcon_flags)) goto L_eeb;
        L_ef5:; /* 0xef5 */
        return;
        goto L_eeb;  /* 重复引用 */
    }
    goto L_ef5;  /* 重复引用 */
}

/* ==== sub_ef7  (被调用 2 次) ==== */
static void sub_ef7(void) {
    L_ef7:; /* 0xef7 */
    for (int i = 0; i >= 0; i--) push32(r[i]);
    r9 = 0;
    r15 = 0x18700u;
    r15 = iord(r15+r9*0x4);
    r9 = 0x12d0u;
    r14 = (r15 >> 16) & 0x1fu;
    s32(r9, r15);
    r9 = 0x12d4u;
    r10 = 0x1c000u;
    s32(r9, r14);
    r11 = 0;
    CALL(sub_10);
    r11 = 0;
    r10 = 0x1c100u;
    CALL(sub_10);
    CALL(sub_ed1);
    r10 = 0x409604u;
    CALL(sub_297);
    r9 = 0x14a0u;
    r10 &= 0x1fu;
    s32(r9, r10);
    r10 = 0x409604u;
    CALL(sub_297);
    r9 = 0x14a4u;
    r10 = (r10 >> 16) & 0x1fu;
    s32(r9, r10);
    r10 = 0x2243cu;
    CALL(sub_297);
    r0 = r10;
    r10 = 0x820c14u;
    CALL(sub_297);
    r0 &= 0x1fu;
    r9 = 0x1u;
    r9 <<= r0;
    r9 = r9 - 0x1u;
    r14 = 0;
    r15 = r9 ^ r10;
    r9 = 0x14a8u;
    s32(r9, r15);
    goto L_f80;
    L_f78:; /* 0xf78 */
    r14 = r9;
    r9 = r15 - 0x1u;
    r15 &= r9;
    L_f80:; /* 0xf80 */
    r9 = r14 + 0x1u;
    if (!(r15 != 0x0u)) {
        L_f87:; /* 0xf87 */
        r9 = 0x14acu;
        r10 = 0x12006cu;
        s32(r9, r14);
        CALL(sub_297);
        r9 = 0x14a0u;
        r15 = d32(r9);
        r10 &= 0x1fu;
        r9 = 0x14b0u;
        r0 = 0x1u;
        s32(r9, r10);
        r0 <<= r15;
        r10 = 0x10300u;
        r0 = r0 - 0x1u;
        r11 = r0;
        CALL(sub_10);
        r11 = r0;
        r10 = 0x10400u;
        CALL(sub_10);
        r11 = r0;
        r10 = 0x10304u;
        CALL(sub_10);
        r11 = r0;
        r10 = 0x10404u;
        CALL(sub_10);
        CALL(sub_a8e);
        for (int i = 0; i <= 0; i++) r[i] = pop32();
        return;
    }
    goto L_f78;  /* 重复引用 */
}

/* ==== sub_1021  (被调用 2 次) ==== */
static void sub_1021(void) {
    L_1021:; /* 0x1021 */
    for (int i = 2; i >= 0; i--) push32(r[i]);
    r15 = d32(r12+0x4);
    r0 = d32(r12);
    r1 = d32(r11);
    r9 = d32(r11+0x4);
    r2 = d32(r11+0xc);
    r13 = d32(r12+0xc);
    r14 = d32(r12+0x8);
    r12 = d32(r11+0x8);
    r0 = r0 + r1;
    r15 = r15 + r9;
    r9 = r0 >> 0x10u;
    r0 = (r0 & 0xffffu) | ((u32)0x0u << 16); /* 待复核 */
    r15 = r15 + r9;
    r9 = r15 >> 0x10u;
    r13 = r13 + r2;
    r14 = r14 + r12;
    s32(r10, r0);
    r14 = r14 + r9;
    r15 = (r15 & 0xffffu) | ((u32)0x0u << 16); /* 待复核 */
    r9 = r14 >> 0x10u;
    s32(r10+0x4, r15);
    r13 = r13 + r9;
    r14 = (r14 & 0xffffu) | ((u32)0x0u << 16); /* 待复核 */
    r13 = (r13 & 0xffffu) | ((u32)0x0u << 16); /* 待复核 */
    s32(r10+0x8, r14);
    s32(r10+0xc, r13);
    for (int i = 0; i <= 2; i++) r[i] = pop32();
    return;
}

/* ==== sub_1070  (被调用 6 次) ==== */
static void sub_1070(void) {
    L_1070:; /* 0x1070 */
    r13 = 0xe00u;
    r14 = d32(r13+0x38);
    r9 = 0x30u;
    r15 = r10 & 0xffu;
    s32(r9, r10);
    r9 = -0x100u;
    r14 &= r9;
    r15 |= r14;
    s32(r13+0x38, r15);
    return;
}

/* ==== sub_108e  (被调用 1 次) ==== */
static void sub_108e(void) {
    L_108e:; /* 0x108e */
    r13 = 0x1494u;
    r9 = d32(r13+0x4);
    r14 = 0xff00ffffu;
    r15 = 0x1480u;
    r15 = d32(r15);
    r14 = r9 & r14;
    r9 = (r9 >> 16) & 0xffu;
    r9 = r9 + 0x1u;
    r9 &= 0xffu;
    r9 <<= 0x10u;
    r9 |= r14;
    r14 = 0;
    s32(r13+0x4, r9);
    r9 = 0;
    goto L_10f0;
    L_10bd:; /* 0x10bd */
    fc_cmp(r14, r10);
    if (!!FZ(falcon_flags)) {
        L_10c2:; /* 0x10c2 */
        r15 = 0xc34u;
        r9 <<= 0x2u;
        r9 = r9 + r15;
        r14 = d32(r9);
        r15 = 0x1u;
        r15 <<= r13;
        r15 |= r14;
        s32(r9, r15);
        return;
    }
    L_10da:; /* 0x10da */
    r14 = r14 + 0x1u;
    fc_cmp(r14, r15);
    if (!(!FC(falcon_flags) && !FZ(falcon_flags))) {
        L_10e2:; /* 0x10e2 */
        r13 = r13 + 0x1u;
        if (!(r13 != 0x20u)) {
            L_10e9:; /* 0x10e9 */
            r9 = r9 + 0x1u;
            if ((r9 == 0x4u)) goto L_10f6;
            L_10f0:; /* 0x10f0 */
            r13 = 0;
            goto L_10bd;
            L_10f6:; /* 0x10f6 */
            return;
        }
        goto L_10bd;  /* 重复引用 */
        goto L_10e9;  /* 重复引用 */
    }
    goto L_10f6;  /* 重复引用 */
}

/* ==== sub_10f8  (被调用 1 次) ==== */
static void sub_10f8(void) {
    L_10f8:; /* 0x10f8 */
    for (int i = 2; i >= 0; i--) push32(r[i]);
    r9 = 0x1480u;
    r13 = 0xc34u;
    r0 = d32(r9);
    r10 = 0;
    r15 = 0xdu;
    r2 = 0x1u;
    r1 = 0xc44u;
    goto L_116c;
    L_1112:; /* 0x1112 */
    r12 = r2 << r14;
    r14 = r14 + 0x1u;
    r9 = r12 & r11;
    if (!FZ(falcon_flags)) {
        L_111e:; /* 0x111e */
        r13 = 0x1494u;
        r14 = d32(r13+0x4);
        r9 = ~r12;
        r15 <<= 0x2u;
        r9 &= r11;
        r12 = 0xc00u;
        r15 = r15 + r12;
        s32(r15, r9);
        r9 = r14 & 0xff00u;
        r15 = -0xff01u;
        r9 = r9 + 0x100u;
        r14 &= r15;
        r9 &= 0xffffu;
        r9 |= r14;
        s32(r13+0x4, r9);
        goto L_1194;
        L_1155:; /* 0x1155 */
        r10 = r10 + 0x1u;
        fc_cmp(r10, r0);
        if (!(!FC(falcon_flags) && !FZ(falcon_flags))) {
            L_115d:; /* 0x115d */
            if (!(r14 != 0x20u)) {
                L_1161:; /* 0x1161 */
                r13 = r13 + 0x4u;
                r15 = r15 + 0x1u;
                fc_cmp(r13, r1);
                if (FZ(falcon_flags)) goto L_1174;
                L_116c:; /* 0x116c */
                r11 = d32(r13);
                r14 = 0;
                goto L_1112;
                L_1174:; /* 0x1174 */
                r9 = 0x1494u;
                r15 = d32(r9+0x4);
                r14 = 0xffffffu;
                r10 = -0x1u;
                r14 = r15 & r14;
                r15 >>= 0x18u;
                r15 = r15 + 0x1u;
                r15 <<= 0x18u;
                r15 |= r14;
                s32(r9+0x4, r15);
                L_1194:; /* 0x1194 */
                for (int i = 0; i <= 2; i++) r[i] = pop32();
                return;
            }
            goto L_1112;  /* 重复引用 */
            goto L_1161;  /* 重复引用 */
        }
        goto L_1174;  /* 重复引用 */
    }
    goto L_1155;  /* 重复引用 */
}

/* ==== sub_1196  (被调用 1 次) ==== */
static void sub_1196(void) {
    L_1196:; /* 0x1196 */
    sp += -0x4cu;
    r11 = r10;
    for (int i = 8; i >= 0; i--) push32(r[i]);
    r15 = 0xc0ffeec0u;
    r9 = 0x20a00u;
    iowr(r9, r15);
    r9 = 0x1484u;
    r10 = d32(r9);
    r9 = 0x20a00u;
    iowr(r9, r10);
    r9 = 0xe00u;
    r15 = d32(r9+0x38);
    r9 = 0x1488u;
    r14 = d32(r9);
    r9 = 0x30u;
    r1 = r15 & 0xffu;
    s32(r9, r1);
    fc_cmp(r14, r1);
    if (!!FZ(falcon_flags)) {
        L_11d1:; /* 0x11d1 */
        r9 = 0x148cu;
        r9 = d32(r9);
        fc_cmp(r9, r11);
        if (!!FZ(falcon_flags)) {
            L_11dc:; /* 0x11dc */
            r9 = 0x1490u;
            r9 = d32(r9);
            fc_cmp(r9, r10);
            if (FZ(falcon_flags)) goto L_16dc;
            L_11e8:; /* 0x11e8 */
            r15 = 0xc00u;
            r2 = d32(r15);
            r9 = 0x1478u;
            r14 = 0xe00u;
            r12 = d32(r14+0xe8);
            s32(r9, r2);
            r2 = d32(r15+0x10);
            r9 = 0x1474u;
            r13 = d32(r14);
            r12 <<= 0x18u;
            s32(r9, r2);
            r2 = d32(r15+0x30);
            r9 = 0x1480u;
            r13 >>= 0x8u;
            r8 = d32(r14+0xc4);
            s32(r9, r2);
            r9 = 0x1488u;
            s32(r9, r1);
            r9 = 0x148cu;
            s32(r9, r11);
            r9 = 0x1490u;
            s32(r9, r10);
            r9 = 0x145cu;
            r2 = r12 | r13;
            s32(r9, r2);
            r9 = d32(r14+0x9c);
            r4 = d32(r15+0x1c);
            r6 = d32(r15+0x60);
            r7 = d32(r15+0xc);
            s32(sp+0x28, r9);
            r9 = d32(r14+0xb8);
            s32(sp+0x64, r9);
            r9 = d32(r14+0xbc);
            s32(sp+0x24, r9);
            r9 = d32(r14+0xc0);
            r14 = d32(r14+0x98);
            s32(sp+0x68, r9);
            s32(sp+0x6c, r14);
            r14 = d32(r15+0x4);
            r9 = d32(r15+0x8);
            s32(sp+0x3c, r14);
            r14 = d32(r15+0x14);
            s32(sp+0x40, r9);
            r9 = d32(r15+0x18);
            s32(sp+0x44, r14);
            s32(sp+0x48, r9);
            r14 = d32(r15+0x20);
            r9 = d32(r15+0x24);
            r0 = d32(r15+0x28);
            r5 = d32(r15+0x5c);
            s32(sp+0x4c, r14);
            r14 = d32(r15+0x2c);
            s32(sp+0x50, r9);
            r3 = d32(r15+0x58);
            s32(sp+0x54, r14);
            if (!(r4 != 0x200u)) {
                L_1292:; /* 0x1292 */
                r4 = 0;
                L_1294:; /* 0x1294 */
                if (!(r0 != 0x200u)) {
                    L_1299:; /* 0x1299 */
                    r0 = 0;
                    L_129b:; /* 0x129b */
                    r9 = 0x1474u;
                    r11 = d32(r9);
                    CALL(sub_77ce);
                    r9 = 0x1470u;
                    s32(r9, r10);
                    r12 = 0x1494u;
                    if (!(r1 != 0x2u)) {
                        L_12b3:; /* 0x12b3 */
                        r13 = d32(r12+0x4);
                        r9 = r10 + r6;
                        r9 >>= 0x8u;
                        r15 = r10 + r7;
                        r1 = r9 + r2;
                        r14 = r13 + 0x1u;
                        r15 >>= 0x8u;
                        r14 &= 0xffu;
                        r9 = -0x100u;
                        r2 = r15 + r2;
                        r13 &= r9;
                        r14 |= r13;
                        s32(r12+0x4, r14);
                        goto L_1315;
                        L_12de:; /* 0x12de */
                        r9 = d32(sp+0x68);
                        r15 = r8 << 0x18u;
                        r14 = d32(r12);
                        r3 = r5;
                        r9 >>= 0x8u;
                        r2 = r15 | r9;
                        r15 = d32(sp+0x28);
                        r9 = d32(sp+0x6c);
                        r0 = r4;
                        r15 <<= 0x18u;
                        r9 >>= 0x8u;
                        r1 = r15 | r9;
                        r9 = r14 >> 0x18u;
                        r15 = 0xffffffu;
                        r9 = r9 + 0x1u;
                        r14 &= r15;
                        r9 <<= 0x18u;
                        r9 |= r14;
                        s32(r12, r9);
                        L_1315:; /* 0x1315 */
                        r10 = 0x408070u;
                        r11 = r1;
                        r12 = 0;
                        r13 = 0;
                        CALL(sub_28f);
                        r11 = r3 & 0x7fffu;
                        r10 = 0x408074u;
                        r12 = 0;
                        r13 = 0;
                        CALL(sub_28f);
                        r11 = r1;
                        r10 = 0x419034u;
                        r12 = 0;
                        r13 = 0;
                        CALL(sub_28f);
                        r10 = 0x40800cu;
                        r11 = r2;
                        r12 = 0;
                        r13 = 0;
                        CALL(sub_28f);
                        r0 &= 0x3ffu;
                        r10 = 0x408010u;
                        r12 = 0;
                        r13 = 0;
                        r11 = 0x8007d800u;
                        r11 = r0 | r11;
                        CALL(sub_28f);
                        r11 = r2;
                        r10 = 0x419004u;
                        r12 = 0;
                        r13 = 0;
                        CALL(sub_28f);
                        r13 = 0;
                        r11 = r0;
                        r10 = 0x419008u;
                        r12 = 0;
                        CALL(sub_28f);
                        r9 = 0x14a0u;
                        r13 = d32(r9);
                        r15 = 0x14c8u;
                        r3 = 0;
                        r14 = r13 << 0x2u;
                        r14 = r14 + r15;
                        goto L_13a1;
                        L_1399:; /* 0x1399 */
                        r9 = d32(r15);
                        r15 = r15 + 0x4u;
                        r3 = r3 + r9;
                        L_13a1:; /* 0x13a1 */
                        fc_cmp(r15, r14);
                        if (!!FZ(falcon_flags)) {
                            L_13a6:; /* 0x13a6 */
                            r9 = 0x147cu;
                            r9 = d32(r9);
                            if (!(r9 != 0x0u)) {
                                L_13b0:; /* 0x13b0 */
                                r11 = r3;
                                goto L_13bf;
                                L_13b6:; /* 0x13b6 */
                                r9 = r13 + r13;
                                r9 = r9 + r13;
                                r11 = r9 + r9;
                                L_13bf:; /* 0x13bf */
                                r9 = 0x30u;
                                r9 = d32(r9);
                                if (!(r9 != 0x2u)) {
                                    L_13c9:; /* 0x13c9 */
                                    r10 = d32(sp+0x4c);
                                    r10 <<= 0x5u;
                                    CALL(sub_77ce);
                                    r5 = r10;
                                    r10 = d32(sp+0x50);
                                    r11 = r3;
                                    r10 <<= 0x5u;
                                    CALL(sub_77ce);
                                    r9 = 0x1470u;
                                    r2 = d32(sp+0x40);
                                    r9 = d32(r9);
                                    r15 = 0x145cu;
                                    r15 = d32(r15);
                                    r4 = r10;
                                    r9 = r2 + r9;
                                    r9 >>= 0x8u;
                                    r9 = r9 + r15;
                                    r2 = r9 >> 0x4u;
                                    goto L_142b;
                                    L_1402:; /* 0x1402 */
                                    r10 = d32(sp+0x44);
                                    r10 <<= 0x5u;
                                    CALL(sub_77ce);
                                    r5 = r10;
                                    r10 = d32(sp+0x48);
                                    r11 = r3;
                                    r10 <<= 0x5u;
                                    CALL(sub_77ce);
                                    r15 = d32(sp+0x24);
                                    r9 = d32(sp+0x64);
                                    r4 = r10;
                                    r15 <<= 0x14u;
                                    r9 >>= 0xcu;
                                    r2 = r15 | r9;
                                    L_142b:; /* 0x142b */
                                    r1 = 0x80000000u;
                                    r10 = 0x418810u;
                                    r12 = 0;
                                    r13 = 0;
                                    r0 = 0xfffffffu;
                                    r0 = r2 & r0;
                                    r11 = r0 | r1;
                                    CALL(sub_28f);
                                    r9 = 0x10000000u;
                                    r10 = 0x419848u;
                                    r0 |= r9;
                                    r12 = 0;
                                    r13 = 0;
                                    r11 = r0;
                                    CALL(sub_28f);
                                    r11 = r0;
                                    r10 = 0x419c2cu;
                                    r12 = 0;
                                    r13 = 0;
                                    CALL(sub_28f);
                                    r11 = r2;
                                    r10 = 0x419e00u;
                                    r12 = 0;
                                    r13 = 0;
                                    CALL(sub_28f);
                                    r9 = -0x80u;
                                    r11 = r4 + r5;
                                    r10 = 0x419e04u;
                                    r11 &= r9;
                                    r12 = 0;
                                    r11 = r11 + 0x80u;
                                    r13 = 0;
                                    r11 = (r11 >> 7) & 0x1fffffu;
                                    r11 |= r1;
                                    CALL(sub_28f);
                                    r9 = 0x30u;
                                    r9 = d32(r9);
                                    if (!(r9 == 0x2u)) {
                                        L_14a1:; /* 0x14a1 */
                                        r9 = d32(sp+0x44);
                                        r1 = d32(sp+0x48);
                                        s32(sp+0x34, r9);
                                        s32(sp+0x38, r1);
                                        r11 = r9;
                                        goto L_14c2;
                                        L_14b3:; /* 0x14b3 */
                                        r1 = d32(sp+0x50);
                                        r14 = d32(sp+0x4c);
                                        r11 = d32(sp+0x44);
                                        s32(sp+0x38, r1);
                                        s32(sp+0x34, r14);
                                        L_14c2:; /* 0x14c2 */
                                        r10 = 0x405830u;
                                        r12 = 0;
                                        r13 = 0;
                                        r0 = 0x3fffffu;
                                        r11 &= r0;
                                        CALL(sub_28f);
                                        r11 = d32(sp+0x38);
                                        r10 = 0x40585cu;
                                        r12 = 0;
                                        r13 = 0;
                                        r11 = (r11 & 0xffffu) | ((u32)0x0u << 16); /* 待复核 */
                                        CALL(sub_28f);
                                        r11 = d32(sp+0x38);
                                        r12 = 0;
                                        r13 = 0;
                                        r10 = 0x4064c4u;
                                        r11 <<= 0xeu;
                                        r11 |= 0xffffu;
                                        CALL(sub_28f);
                                        r10 = r1;
                                        r11 = r3;
                                        CALL(sub_77ce);
                                        r15 = 0x14f8u;
                                        r2 = 0;
                                        r9 = 0x418ea0u;
                                        r14 = 0x5030c0u;
                                        s32(sp+0x30, r10);
                                        s32(sp+0x60, r15);
                                        s32(sp+0x2c, r2);
                                        r6 = 0;
                                        s32(sp+0x5c, r9);
                                        s32(sp+0x58, r14);
                                        goto L_1609;
                                        L_1528:; /* 0x1528 */
                                        r15 = 0x147cu;
                                        r9 = d32(r15);
                                        r0 = d32(r5);
                                        r7 = r7 + 0x1u;
                                        r5 = r5 + 0x4u;
                                        if (!(r9 != 0x0u)) {
                                            L_153a:; /* 0x153a */
                                            r4 = r0;
                                            L_153c:; /* 0x153c */
                                            r10 = r4;
                                            CALL(sub_77ce);
                                            r2 = r10;
                                            r10 = d32(sp+0x38);
                                            r11 = r0;
                                            CALL(sub_77ce);
                                            r9 = 0x3fffffu;
                                            r1 = r10;
                                            r11 = r2 & r9;
                                            r10 = r3;
                                            r12 = 0;
                                            r13 = 0;
                                            CALL(sub_28f);
                                            r11 = d32(sp+0x30);
                                            r14 = 0x3fffffu;
                                            r12 = 0;
                                            r13 = 0;
                                            r11 &= r14;
                                            r10 = r3 + 0x34u;
                                            CALL(sub_28f);
                                            r11 = d32(sp+0x44);
                                            r10 = r4;
                                            CALL(sub_77ce);
                                            r15 = 0x3fffffu;
                                            r12 = 0;
                                            r0 = r10 & r15;
                                            r13 = 0;
                                            r10 = r3 + 0x30u;
                                            r11 = r0;
                                            CALL(sub_28f);
                                            r10 = r3 + 0x24u;
                                            r11 = r1 & 0xffffu;
                                            r12 = 0;
                                            r13 = 0;
                                            CALL(sub_28f);
                                            r11 = d32(sp+0x2c);
                                            r9 = 0x3fffffu;
                                            r10 = r3 + 0x38u;
                                            r12 = 0;
                                            r11 &= r9;
                                            r13 = 0;
                                            CALL(sub_28f);
                                            r14 = d32(sp+0x30);
                                            r15 = d32(sp+0x2c);
                                            r10 = r8;
                                            r11 = r0;
                                            r14 = r14 + r2;
                                            r15 = r15 + r1;
                                            s32(sp+0x30, r14);
                                            s32(sp+0x2c, r15);
                                            r3 = r3 + 0x200u;
                                            r8 = r8 + 0x4u;
                                            r12 = 0;
                                            r13 = 0;
                                            CALL(sub_28f);
                                            L_15dc:; /* 0x15dc */
                                            r2 = d32(sp+0x60);
                                            r11 = d32(sp+0x34);
                                            r4 = 0x2u;
                                            r9 = d32(r2);
                                            fc_cmp(r7, r9);
                                            if (!FC(falcon_flags)) {
                                                L_15ec:; /* 0x15ec */
                                                r9 = d32(sp+0x5c);
                                                r14 = d32(sp+0x58);
                                                r2 = r2 + 0x4u;
                                                r6 = r6 + 0x1u;
                                                r9 = r9 + 0xcu;
                                                r14 = r14 + 0x8000u;
                                                s32(sp+0x5c, r9);
                                                s32(sp+0x58, r14);
                                                s32(sp+0x60, r2);
                                                L_1609:; /* 0x1609 */
                                                r15 = 0x14a0u;
                                                r9 = d32(r15);
                                                fc_cmp(r6, r9);
                                                if (!!FC(falcon_flags)) {
                                                    goto L_1528;  /* 重复引用 */
                                                    goto L_153a;  /* 重复引用 */
                                                    goto L_153c;  /* 重复引用 */
                                                    goto L_15dc;  /* 重复引用 */
                                                    goto L_15ec;  /* 重复引用 */
                                                    L_1614:; /* 0x1614 */
                                                    r9 = r6 + r6;
                                                    r2 = 0x1528u;
                                                    r9 = r9 + r6;
                                                    r3 = d32(sp+0x58);
                                                    r5 = r9 << 0x2u;
                                                    r8 = d32(sp+0x5c);
                                                    r5 = r5 + r2;
                                                    r7 = 0;
                                                    goto L_15dc;
                                                    L_1630:; /* 0x1630 */
                                                    r9 = 0x30u;
                                                    r9 = d32(r9);
                                                    if (!(r9 != 0x2u)) {
                                                        L_163a:; /* 0x163a */
                                                        r3 = d32(sp+0x54);
                                                        r2 = 0;
                                                        r1 = 0;
                                                        r0 = 0x5001d8u;
                                                        r6 = 0x14a0u;
                                                        r5 = 0x1470u;
                                                        r4 = 0x145cu;
                                                        r3 &= 0xffffu;
                                                        goto L_168b;
                                                        L_1659:; /* 0x1659 */
                                                        r11 = d32(r5);
                                                        r9 = d32(r4);
                                                        r14 = d32(sp+0x3c);
                                                        r2 = r2 + 0x1u;
                                                        r11 = r14 + r11;
                                                        r11 >>= 0x8u;
                                                        r11 = r11 + r9;
                                                        r11 = r11 + r1;
                                                        CALL(sub_28f);
                                                        r15 = d32(sp+0x54);
                                                        r10 = r0 + 0x4u;
                                                        r11 = r3;
                                                        r0 = r0 + 0x8000u;
                                                        r1 = r1 + r15;
                                                        r12 = 0;
                                                        r13 = 0;
                                                        CALL(sub_28f);
                                                        L_168b:; /* 0x168b */
                                                        r9 = d32(r6);
                                                        r10 = r0;
                                                        r12 = 0;
                                                        r13 = 0;
                                                        fc_cmp(r2, r9);
                                                        if (FC(falcon_flags)) goto L_1659;
                                                        L_1698:; /* 0x1698 */
                                                        r10 = 0x4181e4u;
                                                        r11 = 0x100u;
                                                        r12 = 0;
                                                        r13 = 0;
                                                        CALL(sub_28f);
                                                        r12 = 0;
                                                        r13 = 0;
                                                        r10 = 0x41befcu;
                                                        r11 = 0x100u;
                                                        CALL(sub_28f);
                                                        r10 = 0x1219fcu;
                                                        r11 = 0xfe7ceu;
                                                        CALL(sub_237);
                                                        r10 = 0x1209fcu;
                                                        r11 = 0x10fe7ceu;
                                                        CALL(sub_237);
                                                        r10 = 0x1211fcu;
                                                        r11 = 0x20fe7ceu;
                                                        CALL(sub_237);
                                                        L_16dc:; /* 0x16dc */
                                                        for (int i = 0; i <= 8; i++) r[i] = pop32();
                                                        sp += 0x4c;
                                                        return;
                                                        goto L_1659;  /* 重复引用 */
                                                        goto L_168b;  /* 重复引用 */
                                                    }
                                                    goto L_1698;  /* 重复引用 */
                                                }
                                                goto L_1630;  /* 重复引用 */
                                            }
                                            goto L_1528;  /* 重复引用 */
                                        }
                                        goto L_153c;  /* 重复引用 */
                                    }
                                    goto L_14b3;  /* 重复引用 */
                                }
                                goto L_1402;  /* 重复引用 */
                            }
                            goto L_13b6;  /* 重复引用 */
                            goto L_13b0;  /* 重复引用 */
                            goto L_13b6;  /* 重复引用 */
                            goto L_13bf;  /* 重复引用 */
                            goto L_13c9;  /* 重复引用 */
                            goto L_1402;  /* 重复引用 */
                            goto L_142b;  /* 重复引用 */
                            goto L_14a1;  /* 重复引用 */
                            goto L_14b3;  /* 重复引用 */
                            goto L_14c2;  /* 重复引用 */
                            goto L_1528;  /* 重复引用 */
                            goto L_153a;  /* 重复引用 */
                            goto L_153c;  /* 重复引用 */
                            goto L_15dc;  /* 重复引用 */
                            goto L_15ec;  /* 重复引用 */
                            goto L_1609;  /* 重复引用 */
                            goto L_1614;  /* 重复引用 */
                            goto L_1630;  /* 重复引用 */
                            goto L_163a;  /* 重复引用 */
                            goto L_1659;  /* 重复引用 */
                            goto L_168b;  /* 重复引用 */
                            goto L_1698;  /* 重复引用 */
                        }
                        goto L_1399;  /* 重复引用 */
                    }
                    goto L_12de;  /* 重复引用 */
                }
                goto L_129b;  /* 重复引用 */
            }
            goto L_1294;  /* 重复引用 */
        }
        goto L_11e8;  /* 重复引用 */
        goto L_11dc;  /* 重复引用 */
    }
    goto L_11e8;  /* 重复引用 */
}

/* ==== sub_16df  (被调用 2 次) ==== */
static void sub_16df(void) {
    L_16df:; /* 0x16df */
    r15 = 0x400000u;
    r9 = 0x21400u;
    iowr(r9, r15);
    r14 = 0xe00u;
    r9 = d32(r14+0x1c);
    r15 = 0x1308u;
    r9 &= 0x7u;
    s32(r15, r9);
    if (!(r9 != 0x2u)) {
        L_16fe:; /* 0x16fe */
        r12 = d32(r14+0x60);
        r14 = d32(r14+0x20);
        r9 = 0x12f0u;
        r15 = 0x1ffffu;
        r12 &= r15;
        s32(r9, r14);
        r9 = 0x12ecu;
        r9 = d32(r9);
        r15 = 0x12f4u;
        r13 = r11 & 0x3fu;
        s32(r15, r12);
        r14 = r9 & 0x3fu;
        r13 <<= 0x18u;
        r14 <<= 0x10u;
        r9 = r9 + 0x40u;
        r15 = 0x12f8u;
        r9 &= 0xffu;
        r9 |= r14;
        r9 |= r13;
        s32(r15, r9);
        L_173b:; /* 0x173b */
        r15 = 0x400000u;
        r9 = 0x21a00u;
        iowr(r9, r15);
        return;
    }
    goto L_173b;  /* 重复引用 */
}

/* ==== sub_1748  (被调用 1 次) ==== */
static void sub_1748(void) {
    L_1748:; /* 0x1748 */
    for (int i = 0; i >= 0; i--) push32(r[i]);
    r13 = 0x20100u;
    r14 = 0;
    r15 = iord(r13+r14*0x4);
    r9 = 0x12b0u;
    s32(r9, r15);
    iowr(r13, r14);
    CALL(sub_768);
    r0 = r10;
    r10 = 0x820434u;
    CALL(sub_297);
    r9 = 0x12b0u;
    r15 = d32(r9);
    r10 &= 0x1u;
    r9 = 0x20u;
    s32(r9, r10);
    if (!(r15 == 0x0u)) {
        L_177e:; /* 0x177e */
        if (!(r0 != 0x0u)) {
            L_1782:; /* 0x1782 */
            r15 = 0x1u;
            r9 = 0x13ecu;
            s32(r9, r15);
            goto L_17c5;
            L_178e:; /* 0x178e */
            if (!(r0 != 0x1u)) {
                L_1792:; /* 0x1792 */
                r9 = 0;
                r11 = 0x25400u;
                r11 = iord(r11+r9*0x4);
                r9 = -0x400u;
                r10 = 0x254fcu;
                r11 &= r9;
                r11 |= 0x3cfu;
                CALL(sub_10);
                r10 = 0x21f00u;
                CALL(sub_44);
                r9 = -0x10u;
                r11 = r10 & r9;
                r10 = 0x21f00u;
                r11 |= 0xcu;
                CALL(sub_10);
                L_17c5:; /* 0x17c5 */
                for (int i = 0; i <= 0; i++) r[i] = pop32();
                return;
            }
            goto L_17c5;  /* 重复引用 */
        }
        goto L_178e;  /* 重复引用 */
        goto L_1782;  /* 重复引用 */
    }
    goto L_178e;  /* 重复引用 */
}

/* ==== sub_17c7  (被调用 1 次) ==== */
static void sub_17c7(void) {
    L_17c7:; /* 0x17c7 */
    r10 = 0x1200u;
    r11 = 0x2u;
    CALL(sub_10);
    r9 = 0x1c65u;
    sr_iv0 = r9;
    r10 = 0x700u;
    r11 = 0;
    CALL(sub_10);
    r10 = 0x400u;
    r11 = 0xcf05u;
    CALL(sub_10);
    r10 = 0x300u;
    r11 = 0x4u;
    CALL(sub_10);
    r15 = 0x2003u;
    r9 = 0x10100u;
    iowr(r9, r15);
    r15 = 0x2004u;
    r9 = r9 + 0x4u;
    iowr(r9, r15);
    r15 = 0x200bu;
    r9 = r9 + 0x4u;
    iowr(r9, r15);
    r15 = 0x2013u;
    r9 = r9 + 0x10u;
    iowr(r9, r15);
    r15 = 0x203du;
    r9 = r9 - 0xcu;
    iowr(r9, r15);
    r15 = 0x200cu;
    r9 = r9 + 0x10u;
    iowr(r9, r15);
    r15 = 0x202du;
    r9 = 0x30540u;
    iowr(r9, r15);
    INT_ENABLE(0);
    p[2] = 1;
    return;
}

/* ==== sub_183d  (被调用 1 次) ==== */
static void sub_183d(void) {
    L_183d:; /* 0x183d */
    r15 = 0x5u;
    r9 = 0x2100u;
    iowr(r9, r15);
    r15 = -0x1u;
    r9 = 0x30900u;
    iowr(r9, r15);
    CALL(sub_1748);
    r15 = 0;
    r9 = 0x9400u;
    iowrs(r9, r15);
    r9 = 0x2cu;
    s32(r9, r15);
    r9 = 0x2c200u;
    iowr(r9, r15);
    CALL(sub_17c7);
    return;
}

/* ==== sub_186e  (被调用 1 次) ==== */
static void sub_186e(void) {
    L_186e:; /* 0x186e */
    r15 = 0;
    r9 = 0x20600u;
    r10 = iord(r9+r15*0x4);
    r9 = 0x13ecu;
    if (!(r10 != 0x17u)) {
        L_187f:; /* 0x187f */
        r9 = d32(r9);
        if (!(r9 != 0x1u)) {
            L_1885:; /* 0x1885 */
            r10 = 0x18u;
            L_1887:; /* 0x1887 */
            CALL(sub_5c0);
            return;
        }
        goto L_1887;  /* 重复引用 */
        goto L_1885;  /* 重复引用 */
        goto L_1887;  /* 重复引用 */
    }
    L_188d:; /* 0x188d */
    r9 = d32(r9);
    if (!(r9 != 0x1u)) {
        L_1893:; /* 0x1893 */
        r10 = 0x16u;
        CALL(sub_5c0);
        L_1899:; /* 0x1899 */
        return;
    }
    goto L_1899;  /* 重复引用 */
}

/* ==== sub_189b  (被调用 2 次) ==== */
static void sub_189b(void) {
    L_189b:; /* 0x189b */
    for (int i = 6; i >= 0; i--) push32(r[i]);
    r3 = 0xa00u;
    r0 = 0;
    r4 = r3;
    r5 = 0;
    r2 = 0x1u;
    r1 = 0x502618u;
    r6 = 0x14a0u;
    goto L_18dc;
    L_18b5:; /* 0x18b5 */
    CALL(sub_297);
    r10 = (r10 >> 13) & 0x1u;
    s32(r4, r10);
    if (!(r0 != 0x0u)) {
        L_18c2:; /* 0x18c2 */
        r2 = 0x1u;
        goto L_18cf;
        L_18c8:; /* 0x18c8 */
        fc_cmp(r10, r5);
        if (!FZ(falcon_flags)) {
            L_18cd:; /* 0x18cd */
            r2 = 0;
            L_18cf:; /* 0x18cf */
            r0 = r0 + 0x1u;
            r1 = r1 + 0x8000u;
            r4 = r4 + 0x4u;
            r5 = r10;
            L_18dc:; /* 0x18dc */
            r9 = d32(r6);
            r10 = r1;
            fc_cmp(r0, r9);
            if (!FC(falcon_flags)) {
                L_18e5:; /* 0x18e5 */
                if (!(r2 != 0x0u)) {
                    L_18e9:; /* 0x18e9 */
                    r1 = 0;
                    r0 = 0x501b34u;
                    r5 = 0x14a0u;
                    r4 = 0x9fffffffu;
                    r2 = 0x80000000u;
                    goto L_1968;
                    L_1901:; /* 0x1901 */
                    r1 = 0;
                    r0 = 0x501b34u;
                    r5 = 0x14a0u;
                    r4 = 0x9fffffffu;
                    r2 = 0x7fffffffu;
                    L_1915:; /* 0x1915 */
                    r9 = d32(r5);
                    r10 = r0;
                    fc_cmp(r1, r9);
                    if (!!FC(falcon_flags)) {
                        L_191e:; /* 0x191e */
                        CALL(sub_297);
                        r9 = d32(r3);
                        r11 = r10 & r4;
                        r1 = r1 + 0x1u;
                        r10 = r0;
                        r9 <<= 0x1du;
                        r3 = r3 + 0x4u;
                        r11 |= r9;
                        r0 = r0 + 0x8000u;
                        r11 &= r2;
                        CALL(sub_237);
                        goto L_1915;
                        L_1945:; /* 0x1945 */
                        CALL(sub_297);
                        r11 = d32(r3);
                        r10 &= r4;
                        r1 = r1 + 0x1u;
                        r3 = r3 + 0x4u;
                        r11 <<= 0x1du;
                        r11 |= r2;
                        r11 |= r10;
                        r10 = r0;
                        r0 = r0 + 0x8000u;
                        CALL(sub_237);
                        L_1968:; /* 0x1968 */
                        r9 = d32(r5);
                        r10 = r0;
                        fc_cmp(r1, r9);
                        if (FC(falcon_flags)) goto L_1945;
                        L_1971:; /* 0x1971 */
                        for (int i = 0; i <= 6; i++) r[i] = pop32();
                        return;
                    }
                    goto L_1971;  /* 重复引用 */
                    goto L_1945;  /* 重复引用 */
                    goto L_1968;  /* 重复引用 */
                }
                goto L_1901;  /* 重复引用 */
                goto L_18e9;  /* 重复引用 */
                goto L_1901;  /* 重复引用 */
                goto L_1915;  /* 重复引用 */
                goto L_191e;  /* 重复引用 */
                goto L_1945;  /* 重复引用 */
                goto L_1968;  /* 重复引用 */
                goto L_1971;  /* 重复引用 */
            }
            goto L_18b5;  /* 重复引用 */
        }
        goto L_18cf;  /* 重复引用 */
    }
    goto L_18c8;  /* 重复引用 */
}

/* ==== sub_1973  (被调用 1 次) ==== */
static void sub_1973(void) {
    L_1973:; /* 0x1973 */
    for (int i = 2; i >= 0; i--) push32(r[i]);
    r15 = 0x1000000u;
    sp += -0x4u;
    r9 = 0x21400u;
    iowr(r9, r15);
    r9 = 0x130cu;
    r9 = d32(r9);
    if (!(r9 != 0x2u)) {
        L_198e:; /* 0x198e */
        r2 = 0x3ff0u;
        r10 = 0x26009cu;
        r11 = 0x1u;
        r12 = 0x16u;
        r13 = 0;
        r14 = 0;
        s32(sp, r2);
        CALL(sub_39f);
        r1 = 0x14a4u;
        r11 = d32(r1);
        r0 = 0;
        r10 = 0x20009cu;
        r12 = 0xcu;
        r13 = 0;
        r14 = 0;
        s32(sp, r0);
        CALL(sub_39f);
        r10 = 0x26006cu;
        r11 = 0x1u;
        r12 = 0x16u;
        r13 = -0x1u;
        r14 = 0;
        s32(sp, r2);
        CALL(sub_39f);
        r11 = d32(r1);
        s32(sp, r0);
        r10 = 0x20006cu;
        r12 = 0xcu;
        r13 = -0x1u;
        r14 = 0;
        CALL(sub_39f);
        L_19e3:; /* 0x19e3 */
        r15 = 0x1000000u;
        r9 = 0x21a00u;
        iowr(r9, r15);
        sp += 0x4u;
        for (int i = 0; i <= 2; i++) r[i] = pop32();
        return;
    }
    goto L_19e3;  /* 重复引用 */
}

/* ==== sub_19f6  (被调用 1 次) ==== */
static void sub_19f6(void) {
    L_19f6:; /* 0x19f6 */
    r9 = 0x130cu;
    r9 = d32(r9);
    r9 = r9 - 0x1u;
    fc_cmp(r9, 0x1u);
    if (!(!FC(falcon_flags) && !FZ(falcon_flags))) {
        L_1a05:; /* 0x1a05 */
        r15 = 0xe00u;
        r14 = d32(r15+0x94);
        r15 = d32(r15+0x2c);
        r9 = 0x12fcu;
        r13 = r11 & 0x3fu;
        r13 <<= 0x18u;
        s32(r9, r15);
        r9 = 0x1ffffu;
        r15 = r10 & 0x3fu;
        r14 &= r9;
        r15 <<= 0x10u;
        r9 = 0x1300u;
        s32(r9, r14);
        r9 = r10 + 0x40u;
        r9 &= 0xffu;
        r9 |= r15;
        r15 = 0x1304u;
        r9 |= r13;
        s32(r15, r9);
        L_1a40:; /* 0x1a40 */
        return;
    }
    goto L_1a40;  /* 重复引用 */
}

/* ==== sub_1a42  (被调用 1 次) ==== */
static void sub_1a42(void) {
    L_1a42:; /* 0x1a42 */
    r12 = 0xe00u;
    r9 = d32(r12+0x28);
    r15 = 0x1310u;
    r14 = (r9 >> 3) & 0x7u;
    r9 &= 0x7u;
    s32(r15, r14);
    r15 = 0x130cu;
    s32(r15, r9);
    r9 = r9 - 0x1u;
    fc_cmp(r9, 0x1u);
    if (!(!FC(falcon_flags) && !FZ(falcon_flags))) {
        L_1a64:; /* 0x1a64 */
        r15 = d32(r12+0x94);
        r12 = d32(r12+0x2c);
        r9 = 0x12fcu;
        r14 = r10 & 0x3fu;
        r13 = r11 & 0x3fu;
        s32(r9, r12);
        r9 = 0x1ffffu;
        r15 &= r9;
        r9 = 0x1300u;
        r14 <<= 0x10u;
        s32(r9, r15);
        r13 <<= 0x18u;
        r9 = r10 + 0x40u;
        r15 = 0x1304u;
        r9 &= 0xffu;
        r9 |= r14;
        r9 |= r13;
        s32(r15, r9);
        L_1a9b:; /* 0x1a9b */
        return;
    }
    goto L_1a9b;  /* 重复引用 */
}

/* ==== sub_1bec  (被调用 2 次) ==== */
static void sub_1bec(void) {
    L_1bec:; /* 0x1bec */
    r15 = 0x800000u;
    r9 = 0x21200u;
    iowr(r9, r15);
    r9 = 0x14a0u;
    r9 = d32(r9);
    r15 = 0x160cu;
    r14 = 0x300u;
    s32(r15, r14);
    r15 = r9 << 0xcu;
    r9 <<= 0x8u;
    r9 = r9 + r15;
    r15 = 0x1608u;
    r9 = r9 + r14;
    r14 = 0x1100u;
    s32(r15, r14);
    r15 = 0x20000u;
    iowr(r15, r9);
    r15 = 0x800000u;
    r9 = 0x21800u;
    iowr(r9, r15);
    return;
}

/* ==== sub_1c31  (被调用 1 次) ==== */
static void sub_1c31(void) {
    L_1c31:; /* 0x1c31 */
    r15 = 0x1000000u;
    r9 = 0x21200u;
    iowr(r9, r15);
    r15 = 0;
    r9 = r9 - 0xe00u;
    r9 = iord(r9+r15*0x4);
    r15 = 0x1610u;
    s32(r15, r9);
    r15 = 0x1u;
    r9 = 0x20000u;
    iowr(r9, r15);
    r15 = 0x1000000u;
    r9 = r9 + 0x1800u;
    iowr(r9, r15);
    return;
}

/* ==== sub_1c96  (被调用 2 次) ==== */
static void sub_1c96(void) {
    L_1c96:; /* 0x1c96 */
    r15 = 0x20000000u;
    r9 = 0x21200u;
    iowr(r9, r15);
    r14 = 0x15fcu;
    r13 = 0x15f8u;
    r15 = d32(r14);
    r9 = d32(r13);
    r9 ^= r15;
    r9 &= 0x7u;
    if (!!FZ(falcon_flags)) {
        L_1cb7:; /* 0x1cb7 */
        r15 = d32(r14);
        r9 = d32(r13);
        r15 = (r15 >> 3) & 0x1u;
        r9 = (r9 >> 3) & 0x1u;
        fc_cmp(r15, r9);
        if (!FZ(falcon_flags)) {
            L_1cc6:; /* 0x1cc6 */
            r10 = 0x13u;
            CALL(sub_5c0);
            goto L_1d04;
            L_1cd0:; /* 0x1cd0 */
            r13 = 0x15fcu;
            r9 = d32(r13);
            r15 = d32(r13);
            r14 = d32(r13);
            r12 = 0x15b8u;
            r9 &= 0x7u;
            r9 <<= 0x3u;
            r14 = r14 + 0x1u;
            r9 = r9 + r12;
            s32(r9, r10);
            s32(r13, r14);
            r14 = d32(r13);
            r15 &= 0x7u;
            r15 = r15 + r15;
            r15 = r15 + 0x1u;
            s32(r12+r15*0x4, r11);
            if (!(r14 != 0x10u)) {
                L_1d00:; /* 0x1d00 */
                r9 = 0;
                s32(r13, r9);
                L_1d04:; /* 0x1d04 */
                r15 = 0x20000000u;
                r9 = 0x21800u;
                iowr(r9, r15);
                return;
            }
            goto L_1d04;  /* 重复引用 */
        }
        goto L_1cd0;  /* 重复引用 */
        goto L_1cc6;  /* 重复引用 */
    }
    goto L_1cd0;  /* 重复引用 */
}

/* ==== sub_1d12  (被调用 1 次) ==== */
static void sub_1d12(void) {
    L_1d12:; /* 0x1d12 */
    r9 = -0xf001u;
    r14 = r10;
    r15 = r10 & r9;
    r13 = r11;
    fc_cmp(r15, 0x3au);
    if (!(!FC(falcon_flags) && !FZ(falcon_flags))) {
        L_1d23:; /* 0x1d23 */
        fc_cmp(r15, 0x38u);
        if (!!FC(falcon_flags)) {
            L_1d29:; /* 0x1d29 */
            if (!(r15 == 0x4u)) {
                L_1d2d:; /* 0x1d2d */
                fc_cmp(r15, 0x4u);
                if (!FC(falcon_flags)) {
                    L_1d33:; /* 0x1d33 */
                    r9 = r15 - 0x2cu;
                    fc_cmp(r9, 0x1u);
                    if (!(!FC(falcon_flags) && !FZ(falcon_flags))) {
                        L_1d3c:; /* 0x1d3c */
                        goto L_1d67;
                        L_1d40:; /* 0x1d40 */
                        r9 = 0x10002u;
                        fc_cmp(r15, r9);
                        if (!FZ(falcon_flags)) {
                            L_1d49:; /* 0x1d49 */
                            fc_cmp(r15, r9);
                            if (!(!FC(falcon_flags) && !FZ(falcon_flags))) {
                                L_1d4e:; /* 0x1d4e */
                                if (!(r15 != 0x3cu)) {
                                    L_1d52:; /* 0x1d52 */
                                    goto L_1d67;
                                    L_1d56:; /* 0x1d56 */
                                    r9 = 0x10003u;
                                    fc_cmp(r15, r9);
                                    if (!FZ(falcon_flags)) {
                                        L_1d5f:; /* 0x1d5f */
                                        r9 = r9 + 0x4u;
                                        fc_cmp(r15, r9);
                                        if (!FZ(falcon_flags)) goto L_1d77;
                                        L_1d67:; /* 0x1d67 */
                                        r10 = r14;
                                        r11 = r13;
                                        CALL(sub_681);
                                        return;
                                    }
                                    goto L_1d67;  /* 重复引用 */
                                }
                                L_1d77:; /* 0x1d77 */
                                r10 = r14;
                                r11 = r13;
                                CALL(sub_60b);
                                return;
                                goto L_1d52;  /* 重复引用 */
                            }
                            goto L_1d56;  /* 重复引用 */
                            goto L_1d4e;  /* 重复引用 */
                            goto L_1d52;  /* 重复引用 */
                            goto L_1d56;  /* 重复引用 */
                            goto L_1d5f;  /* 重复引用 */
                        }
                        L_1d71:; /* 0x1d71 */
                        CALL(sub_1c96);
                        return;
                    }
                    goto L_1d77;  /* 重复引用 */
                    goto L_1d3c;  /* 重复引用 */
                }
                goto L_1d77;  /* 重复引用 */
                goto L_1d33;  /* 重复引用 */
                goto L_1d3c;  /* 重复引用 */
            }
            goto L_1d67;  /* 重复引用 */
            goto L_1d2d;  /* 重复引用 */
            goto L_1d33;  /* 重复引用 */
            goto L_1d3c;  /* 重复引用 */
        }
        goto L_1d67;  /* 重复引用 */
        goto L_1d29;  /* 重复引用 */
        goto L_1d2d;  /* 重复引用 */
        goto L_1d33;  /* 重复引用 */
        goto L_1d3c;  /* 重复引用 */
    }
    goto L_1d40;  /* 重复引用 */
}

/* ==== sub_1d81  (被调用 1 次) ==== */
static void sub_1d81(void) {
    L_1d81:; /* 0x1d81 */
    for (int i = 1; i >= 0; i--) push32(r[i]);
    r15 = 0;
    r9 = 0x200u;
    r1 = iord(r9+r15*0x4);
    r9 = r1 & 0x4u;
    if (!FZ(falcon_flags)) {
        L_1d91:; /* 0x1d91 */
        r10 = 0x1a00u;
        r10 = iord(r10+r15*0x4);
        r11 = 0x1900u;
        r11 = iord(r11+r15*0x4);
        CALL(sub_1d12);
        r15 = 0x1u;
        r9 = 0x1d00u;
        iowr(r9, r15);
        L_1da9:; /* 0x1da9 */
        r9 = r1 >> 0x8u;
        r0 = r9 & 0xffu;
        if (!FZ(falcon_flags)) {
            L_1db2:; /* 0x1db2 */
            r9 &= 0x1u;
            if (!FZ(falcon_flags)) {
                L_1db8:; /* 0x1db8 */
                r10 = 0x10000u;
                r11 = 0;
                CALL(sub_60b);
                L_1dc2:; /* 0x1dc2 */
                r9 = r0 & 0x2u;
                if (!FZ(falcon_flags)) {
                    L_1dc8:; /* 0x1dc8 */
                    r10 = 0x4u;
                    r11 = 0;
                    CALL(sub_681);
                    L_1dd0:; /* 0x1dd0 */
                    r9 = r0 & 0x8u;
                    if (!FZ(falcon_flags)) {
                        L_1dd6:; /* 0x1dd6 */
                        CALL(sub_6f7);
                        L_1dda:; /* 0x1dda */
                        r9 = r0 & 0x4u;
                        if (!FZ(falcon_flags)) {
                            L_1de0:; /* 0x1de0 */
                            r10 = 0x10002u;
                            r11 = 0x1u;
                            CALL(sub_1c96);
                            L_1dea:; /* 0x1dea */
                            r9 = r0 & 0x80u;
                            if (!(r9 == 0x0u)) {
                                L_1df1:; /* 0x1df1 */
                                r10 = 0x10003u;
                                r11 = 0;
                                CALL(sub_681);
                                L_1dfb:; /* 0x1dfb */
                                r9 = r0 & 0x40u;
                                if (!FZ(falcon_flags)) {
                                    L_1e01:; /* 0x1e01 */
                                    r10 = 0x10007u;
                                    r11 = 0;
                                    CALL(sub_681);
                                    L_1e0b:; /* 0x1e0b */
                                    r9 = 0x10d00u;
                                    iowr(r9, r0);
                                    L_1e12:; /* 0x1e12 */
                                    r9 = 0x100u;
                                    iowr(r9, r1);
                                    for (int i = 0; i <= 1; i++) r[i] = pop32();
                                    return;
                                }
                                goto L_1e0b;  /* 重复引用 */
                            }
                            goto L_1dfb;  /* 重复引用 */
                        }
                        goto L_1dea;  /* 重复引用 */
                    }
                    goto L_1dda;  /* 重复引用 */
                }
                goto L_1dd0;  /* 重复引用 */
            }
            goto L_1dc2;  /* 重复引用 */
            goto L_1db8;  /* 重复引用 */
            goto L_1dc2;  /* 重复引用 */
            goto L_1dc8;  /* 重复引用 */
            goto L_1dd0;  /* 重复引用 */
            goto L_1dd6;  /* 重复引用 */
            goto L_1dda;  /* 重复引用 */
            goto L_1de0;  /* 重复引用 */
            goto L_1dea;  /* 重复引用 */
            goto L_1df1;  /* 重复引用 */
            goto L_1dfb;  /* 重复引用 */
            goto L_1e01;  /* 重复引用 */
            goto L_1e0b;  /* 重复引用 */
        }
        goto L_1e12;  /* 重复引用 */
    }
    goto L_1da9;  /* 重复引用 */
}

/* ==== sub_1e1a  (被调用 1 次) ==== */
static void sub_1e1a(void) {
    L_1e1a:; /* 0x1e1a */
    r10 = 0x17e26cu;
    CALL(sub_297);
    r12 = 0;
    r11 = r10 | 0x4u;
    r13 = 0x1u;
    r10 = 0x17e26cu;
    CALL(sub_22f);
    return;
}

/* ==== sub_1e5f  (被调用 3 次) ==== */
static void sub_1e5f(void) {
    L_1e5f:; /* 0x1e5f */
    for (int i = 0; i >= 0; i--) push32(r[i]);
    r9 = 0xa140u;
    fc_cmp(r12, r9);
    if (!FZ(falcon_flags)) {
        L_1e6a:; /* 0x1e6a */
        fc_cmp(r12, r9);
        if (!(!FC(falcon_flags) && !FZ(falcon_flags))) {
            L_1e6f:; /* 0x1e6f */
            r9 = r9 - 0x1113u;
            goto L_1e84;
            L_1e78:; /* 0x1e78 */
            r9 = 0xc997u;
            fc_cmp(r12, r9);
            if (!FZ(falcon_flags)) {
                L_1e81:; /* 0x1e81 */
                r9 = r9 + 0x29u;
                L_1e84:; /* 0x1e84 */
                fc_cmp(r12, r9);
                if (!FZ(falcon_flags)) {
                    L_1e89:; /* 0x1e89 */
                    r0 = 0;
                    goto L_1eb3;
                    L_1e8f:; /* 0x1e8f */
                    r14 = r12 & 0xffffu;
                    r15 = r10 + 0xd00u;
                    r13 &= 0x1u;
                    r15 &= 0xfffu;
                    r13 <<= 0x1du;
                    r15 <<= 0x10u;
                    r9 = 0x80000000u;
                    r14 |= r9;
                    r14 |= r15;
                    r0 = r14 | r13;
                    L_1eb3:; /* 0x1eb3 */
                    r10 = 0x40448cu;
                    CALL(sub_237);
                    r11 = r0;
                    r10 = 0x404488u;
                    r0 = 0x80000000u;
                    CALL(sub_237);
                    L_1eca:; /* 0x1eca */
                    r10 = 0x404488u;
                    CALL(sub_297);
                    r10 &= r0;
                    if (!!FZ(falcon_flags)) {
                        L_1ed8:; /* 0x1ed8 */
                        for (int i = 0; i <= 0; i++) r[i] = pop32();
                        return;
                    }
                    goto L_1eca;  /* 重复引用 */
                }
                goto L_1e8f;  /* 重复引用 */
            }
            goto L_1e8f;  /* 重复引用 */
        }
        goto L_1e78;  /* 重复引用 */
        goto L_1e6f;  /* 重复引用 */
        goto L_1e78;  /* 重复引用 */
        goto L_1e81;  /* 重复引用 */
        goto L_1e84;  /* 重复引用 */
        goto L_1e89;  /* 重复引用 */
    }
    goto L_1e8f;  /* 重复引用 */
}

/* ==== sub_1eda  (被调用 7 次) ==== */
static void sub_1eda(void) {
    L_1eda:; /* 0x1eda */
    for (int i = 0; i >= 0; i--) push32(r[i]);
    r9 = 0xa140u;
    fc_cmp(r11, r9);
    if (!FZ(falcon_flags)) {
        L_1ee5:; /* 0x1ee5 */
        fc_cmp(r11, r9);
        if (!(!FC(falcon_flags) && !FZ(falcon_flags))) {
            L_1eea:; /* 0x1eea */
            r9 = r9 - 0x1113u;
            goto L_1eff;
            L_1ef3:; /* 0x1ef3 */
            r9 = 0xc997u;
            fc_cmp(r11, r9);
            if (!FZ(falcon_flags)) {
                L_1efc:; /* 0x1efc */
                r9 = r9 + 0x29u;
                L_1eff:; /* 0x1eff */
                fc_cmp(r11, r9);
                if (!FZ(falcon_flags)) {
                    L_1f04:; /* 0x1f04 */
                    r11 = 0;
                    goto L_1f2e;
                    L_1f0a:; /* 0x1f0a */
                    r14 = r11 & 0xffffu;
                    r13 = r12 & 0x1u;
                    r15 = r10 + 0xd00u;
                    r13 <<= 0x1du;
                    r15 &= 0xfffu;
                    r9 = 0x40000000u;
                    r15 <<= 0x10u;
                    r14 |= r9;
                    r14 |= r13;
                    r11 = r14 | r15;
                    L_1f2e:; /* 0x1f2e */
                    r10 = 0x404488u;
                    r0 = 0x40000000u;
                    CALL(sub_237);
                    L_1f3b:; /* 0x1f3b */
                    r10 = 0x404488u;
                    CALL(sub_297);
                    r10 &= r0;
                    if (!!FZ(falcon_flags)) {
                        L_1f49:; /* 0x1f49 */
                        r10 = 0x40448cu;
                        CALL(sub_297);
                        for (int i = 0; i <= 0; i++) r[i] = pop32();
                        return;
                    }
                    goto L_1f3b;  /* 重复引用 */
                }
                goto L_1f0a;  /* 重复引用 */
            }
            goto L_1f0a;  /* 重复引用 */
        }
        goto L_1ef3;  /* 重复引用 */
        goto L_1eea;  /* 重复引用 */
        goto L_1ef3;  /* 重复引用 */
        goto L_1efc;  /* 重复引用 */
        goto L_1eff;  /* 重复引用 */
        goto L_1f04;  /* 重复引用 */
    }
    goto L_1f0a;  /* 重复引用 */
}

/* ==== sub_1f53  (被调用 2 次) ==== */
static void sub_1f53(void) {
    L_1f53:; /* 0x1f53 */
    r9 = 0x13f0u;
    r9 = d32(r9);
    r10 = 0x1u;
    if (!(r9 != 0x0u)) {
        L_1f5f:; /* 0x1f5f */
        r9 = 0xe00u;
        r14 = d32(r9+0x3c);
        r15 = 0x3cu;
        r9 = 0x20600u;
        r10 = (r14 >> 3) & 0x1u;
        iowr(r9, r15);
        iowr(r9, r14);
        if (!(r10 != 0x0u)) {
            L_1f79:; /* 0x1f79 */
            r15 = 0x2u;
            iowr(r9, r15);
            L_1f7e:; /* 0x1f7e */
            return;
        }
        goto L_1f7e;  /* 重复引用 */
        goto L_1f79;  /* 重复引用 */
    }
    goto L_1f7e;  /* 重复引用 */
}

/* ==== sub_1f80  (被调用 1 次) ==== */
static void sub_1f80(void) {
    L_1f80:; /* 0x1f80 */
    r11 = 0x40000000u;
    r10 = 0x504448u;
    CALL(sub_237);
    r10 = 0x504448u;
    CALL(sub_297);
    r9 = 0xffffffu;
    r10 &= r9;
    r10 = r10 + 0x10u;
    r10 &= 0x3fu;
    r11 = 0x80000000u;
    r11 = r10 | r11;
    r10 = 0x419c48u;
    CALL(sub_237);
    r10 = 0x4041c4u;
    r11 = 0x3000u;
    CALL(sub_237);
    r15 = 0x8u;
    r9 = 0x2c300u;
    iowr(r9, r15);
    return;
}

/* ==== sub_1fc9  (被调用 2 次) ==== */
static void sub_1fc9(void) {
    L_1fc9:; /* 0x1fc9 */
    for (int i = 6; i >= 0; i--) push32(r[i]);
    r15 = 0x10u;
    r9 = 0x21200u;
    iowr(r9, r15);
    r5 = 0x12c4u;
    r6 = 0x13b8u;
    r1 = 0x13b4u;
    r4 = 0x1374u;
    r3 = -0xf001u;
    r2 = 0x10007u;
    goto L_2131;
    L_1ff0:; /* 0x1ff0 */
    r9 = d32(r1);
    r15 = d32(r1);
    r14 = d32(r1);
    r12 = 0x1374u;
    r9 &= 0x7u;
    r9 <<= 0x3u;
    r9 = r9 + r12;
    r14 = r14 + 0x1u;
    r10 = d32(r9);
    s32(r1, r14);
    r9 = d32(r1);
    r15 &= 0x7u;
    r15 = r15 + r15;
    r15 = r15 + 0x1u;
    r0 = d32(r4+r15*0x4);
    if (!(r9 != 0x10u)) {
        L_201c:; /* 0x201c */
        s32(r1, r13);
        L_201e:; /* 0x201e */
        r10 &= r3;
        if (!(r10 == 0x38u)) {
            L_2025:; /* 0x2025 */
            fc_cmp(r10, 0x38u);
            if (!(!FC(falcon_flags) && !FZ(falcon_flags))) {
                L_202b:; /* 0x202b */
                if (!(r10 == 0x2cu)) {
                    L_2030:; /* 0x2030 */
                    if (!(r10 == 0x2du)) {
                        L_2035:; /* 0x2035 */
                        if (!(r10 != 0x4u)) {
                            L_203a:; /* 0x203a */
                            goto L_2056;
                            L_203e:; /* 0x203e */
                            if (!(r10 == 0x3au)) {
                                L_2042:; /* 0x2042 */
                                fc_cmp(r10, 0x3au);
                                if (!FC(falcon_flags)) {
                                    L_2048:; /* 0x2048 */
                                    if (!(r10 == 0x3cu)) {
                                        L_204c:; /* 0x204c */
                                        fc_cmp(r10, r2);
                                        if (!!FZ(falcon_flags)) {
                                            L_2052:; /* 0x2052 */
                                            goto L_20bf;
                                            L_2056:; /* 0x2056 */
                                            r11 = r0;
                                            CALL(sub_403d);
                                            fc_cmp(r10, r0);
                                            if (!!FZ(falcon_flags)) {
                                                L_2061:; /* 0x2061 */
                                                goto L_2109;
                                                L_2065:; /* 0x2065 */
                                                r9 = 0x12b8u;
                                                r9 = d32(r9);
                                                if (!(r9 != 0x0u)) {
                                                    L_206f:; /* 0x206f */
                                                    r15 = 0x12c8u;
                                                    r9 = 0x1u;
                                                    s32(r15, r9);
                                                    r15 = 0x20100u;
                                                    iowr(r15, r9);
                                                    goto L_2131;
                                                    L_2082:; /* 0x2082 */
                                                    r11 = r0;
                                                    r10 = 0x10004u;
                                                    CALL(sub_60b);
                                                    goto L_2131;
                                                    L_2090:; /* 0x2090 */
                                                    r15 = 0;
                                                    r9 = 0x12c8u;
                                                    s32(r9, r15);
                                                    goto L_20b9;
                                                    L_209c:; /* 0x209c */
                                                    r15 = 0xe00u;
                                                    r9 = d32(r15+0xf0);
                                                    fc_cmp(r0, r9);
                                                    if (!!FZ(falcon_flags)) {
                                                        L_20a8:; /* 0x20a8 */
                                                        r9 = d32(r15+0x8c);
                                                        r9 |= 0x10u;
                                                        s32(r15+0x8c, r9);
                                                        goto L_20b9;
                                                        L_20b5:; /* 0x20b5 */
                                                        CALL(sub_3d7e);
                                                        L_20b9:; /* 0x20b9 */
                                                        r15 = 0x1u;
                                                        goto L_212a;
                                                        L_20bf:; /* 0x20bf */
                                                        r11 = r0;
                                                        r10 = r2;
                                                        CALL(sub_1f80);
                                                        goto L_2131;
                                                        L_20cb:; /* 0x20cb */
                                                        r9 = 0x142cu;
                                                        r9 = d32(r9);
                                                        if (!(r9 != 0x0u)) {
                                                            L_20d5:; /* 0x20d5 */
                                                            r14 = 0x141cu;
                                                            r9 = d32(r14);
                                                            if (!(r9 != 0x0u)) {
                                                                L_20df:; /* 0x20df */
                                                                r9 = 0x1414u;
                                                                r15 = 0x1u;
                                                                s32(r9, r0);
                                                                s32(r14, r15);
                                                                goto L_212a;
                                                                L_20ed:; /* 0x20ed */
                                                                r9 = 0x142cu;
                                                                r9 = d32(r9);
                                                                if (!(r9 != 0x0u)) {
                                                                    L_20f7:; /* 0x20f7 */
                                                                    r13 = 0x1420u;
                                                                    r9 = d32(r13);
                                                                    if ((r9 == 0x0u)) goto L_210f;
                                                                    L_2101:; /* 0x2101 */
                                                                    r15 = 0x1u;
                                                                    r9 = 0x1428u;
                                                                    s32(r9, r15);
                                                                    L_2109:; /* 0x2109 */
                                                                    r15 = 0x2u;
                                                                    goto L_212a;
                                                                    L_210f:; /* 0x210f */
                                                                    r15 = 0x1418u;
                                                                    r9 = 0x3fffffffu;
                                                                    r9 = r0 & r9;
                                                                    r14 = r0 >> 0x1eu;
                                                                    s32(r15, r9);
                                                                    r9 = 0x1424u;
                                                                    r15 = 0x1u;
                                                                    s32(r9, r14);
                                                                    s32(r13, r15);
                                                                    L_212a:; /* 0x212a */
                                                                    r9 = 0x20100u;
                                                                    iowr(r9, r15);
                                                                    L_2131:; /* 0x2131 */
                                                                    r9 = d32(r5);
                                                                    if (!(r9 == 0x0u)) {
                                                                        L_2137:; /* 0x2137 */
                                                                        r15 = 0x13b8u;
                                                                        r9 = 0x13b4u;
                                                                        L_213f:; /* 0x213f */
                                                                        r14 = d32(r15);
                                                                        r14 = d32(r9);
                                                                        goto L_213f;
                                                                        L_2147:; /* 0x2147 */
                                                                        r13 = 0;
                                                                        L_2149:; /* 0x2149 */
                                                                        r15 = d32(r6);
                                                                        r9 = d32(r1);
                                                                        fc_cmp(r15, r9);
                                                                        if (!!FZ(falcon_flags)) {
                                                                            L_2153:; /* 0x2153 */
                                                                            r15 = 0x10u;
                                                                            r9 = 0x21800u;
                                                                            iowr(r9, r15);
                                                                            for (int i = 0; i <= 6; i++) r[i] = pop32();
                                                                            return;
                                                                        }
                                                                        goto L_1ff0;  /* 重复引用 */
                                                                        goto L_213f;  /* 重复引用 */
                                                                    }
                                                                    goto L_2147;  /* 重复引用 */
                                                                    goto L_210f;  /* 重复引用 */
                                                                }
                                                                goto L_2101;  /* 重复引用 */
                                                            }
                                                            goto L_2101;  /* 重复引用 */
                                                            goto L_20df;  /* 重复引用 */
                                                        }
                                                        goto L_2101;  /* 重复引用 */
                                                    }
                                                    goto L_20b9;  /* 重复引用 */
                                                }
                                                goto L_2082;  /* 重复引用 */
                                            }
                                            goto L_20b9;  /* 重复引用 */
                                            goto L_20bf;  /* 重复引用 */
                                        }
                                        goto L_2149;  /* 重复引用 */
                                        goto L_2052;  /* 重复引用 */
                                        goto L_20bf;  /* 重复引用 */
                                    }
                                    goto L_20b5;  /* 重复引用 */
                                    goto L_204c;  /* 重复引用 */
                                    goto L_2052;  /* 重复引用 */
                                    goto L_20b5;  /* 重复引用 */
                                    goto L_20bf;  /* 重复引用 */
                                }
                                goto L_2090;  /* 重复引用 */
                                goto L_2048;  /* 重复引用 */
                                goto L_204c;  /* 重复引用 */
                                goto L_2052;  /* 重复引用 */
                                goto L_2090;  /* 重复引用 */
                                goto L_20b5;  /* 重复引用 */
                                goto L_20bf;  /* 重复引用 */
                            }
                            goto L_209c;  /* 重复引用 */
                            goto L_2056;  /* 重复引用 */
                            goto L_2061;  /* 重复引用 */
                        }
                        goto L_2149;  /* 重复引用 */
                        goto L_203a;  /* 重复引用 */
                        goto L_2056;  /* 重复引用 */
                        goto L_2061;  /* 重复引用 */
                    }
                    goto L_20ed;  /* 重复引用 */
                    goto L_2035;  /* 重复引用 */
                    goto L_203a;  /* 重复引用 */
                    goto L_2056;  /* 重复引用 */
                    goto L_2061;  /* 重复引用 */
                    goto L_20ed;  /* 重复引用 */
                    goto L_20f7;  /* 重复引用 */
                    goto L_210f;  /* 重复引用 */
                }
                goto L_20cb;  /* 重复引用 */
                goto L_2030;  /* 重复引用 */
                goto L_2035;  /* 重复引用 */
                goto L_203a;  /* 重复引用 */
                goto L_2056;  /* 重复引用 */
                goto L_2061;  /* 重复引用 */
                goto L_20cb;  /* 重复引用 */
                goto L_20d5;  /* 重复引用 */
                goto L_20df;  /* 重复引用 */
                goto L_20ed;  /* 重复引用 */
                goto L_20f7;  /* 重复引用 */
                goto L_2101;  /* 重复引用 */
                goto L_2109;  /* 重复引用 */
                goto L_210f;  /* 重复引用 */
            }
            goto L_203e;  /* 重复引用 */
            goto L_202b;  /* 重复引用 */
            goto L_2030;  /* 重复引用 */
            goto L_2035;  /* 重复引用 */
            goto L_203a;  /* 重复引用 */
            goto L_203e;  /* 重复引用 */
            goto L_2042;  /* 重复引用 */
            goto L_2048;  /* 重复引用 */
            goto L_204c;  /* 重复引用 */
            goto L_2052;  /* 重复引用 */
            goto L_2056;  /* 重复引用 */
            goto L_2061;  /* 重复引用 */
            goto L_2090;  /* 重复引用 */
            goto L_209c;  /* 重复引用 */
            goto L_20a8;  /* 重复引用 */
            goto L_20b5;  /* 重复引用 */
            goto L_20b9;  /* 重复引用 */
            goto L_20bf;  /* 重复引用 */
            goto L_20cb;  /* 重复引用 */
            goto L_20d5;  /* 重复引用 */
            goto L_20df;  /* 重复引用 */
            goto L_20ed;  /* 重复引用 */
            goto L_20f7;  /* 重复引用 */
            goto L_2101;  /* 重复引用 */
            goto L_2109;  /* 重复引用 */
            goto L_210f;  /* 重复引用 */
            goto L_212a;  /* 重复引用 */
        }
        goto L_2065;  /* 重复引用 */
    }
    goto L_201e;  /* 重复引用 */
}

/* ==== sub_215e  (被调用 22 次) ==== */
static void sub_215e(void) {
    L_215e:; /* 0x215e */
    r9 = 0x13b8u;
    r15 = d32(r9);
    r9 = 0x13b4u;
    r9 = d32(r9);
    fc_cmp(r15, r9);
    if (!FZ(falcon_flags)) {
        L_216f:; /* 0x216f */
        CALL(sub_1fc9);
        L_2173:; /* 0x2173 */
        return;
    }
    goto L_2173;  /* 重复引用 */
}

/* ==== sub_2175  (被调用 15 次) ==== */
static void sub_2175(void) {
    L_2175:; /* 0x2175 */
    for (int i = 1; i >= 0; i--) push32(r[i]);
    r15 = 0x40u;
    r9 = 0x21400u;
    iowr(r9, r15);
    r1 = 0x10000u;
    r0 = 0;
    goto L_218e;
    L_218a:; /* 0x218a */
    CALL(sub_215e);
    L_218e:; /* 0x218e */
    r9 = iord(r1+r0*0x4);
    r9 &= 0x20u;
    if (!!FZ(falcon_flags)) {
        L_2197:; /* 0x2197 */
        r15 = 0x40u;
        r9 = 0x21a00u;
        iowr(r9, r15);
        for (int i = 0; i <= 1; i++) r[i] = pop32();
        return;
    }
    goto L_218a;  /* 重复引用 */
}

/* ==== sub_21a2  (被调用 1 次) ==== */
static void sub_21a2(void) {
    L_21a2:; /* 0x21a2 */
    for (int i = 8; i >= 0; i--) push32(r[i]);
    CALL(sub_2175);
    r9 = 0x24u;
    r10 = d32(r9);
    r8 = 0x324u;
    r4 = 0x5cu;
    r3 = 0;
    CALL(sub_114);
    r10 = 0x1d300u;
    r11 = 0x6feu;
    CALL(sub_10);
    r9 = 0x1000u;
    r11 = d32(r9+0xc);
    r10 = 0x1c100u;
    r7 = 0x7fffffffu;
    r6 = 0x7c000000u;
    r11 = (r11 & 0xffffu) | ((u32)0x0u << 16); /* 待复核 */
    CALL(sub_10);
    r10 = 0x1c600u;
    r11 = 0;
    CALL(sub_10);
    r10 = 0x1c500u;
    r11 = 0x31000u;
    CALL(sub_10);
    goto L_223e;
    L_21fd:; /* 0x21fd */
    r9 = d32(r4);
    fc_cmp(r9, 0x0u);
    if (!FC(falcon_flags)) {
        L_2205:; /* 0x2205 */
        r2 = 0x40448cu;
        goto L_2211;
        L_220d:; /* 0x220d */
        r2 = 0x404488u;
        L_2211:; /* 0x2211 */
        r0 = r9 & r7;
        r5 = r2 | r6;
        L_2217:; /* 0x2217 */
        fc_cmp(r0, 0x1fu);
        if (!(!FC(falcon_flags) && !FZ(falcon_flags))) {
            L_221d:; /* 0x221d */
            r9 = r0 << 0x1au;
            r1 = 0x1u;
            r10 = r9 | r2;
            goto L_2230;
            L_2229:; /* 0x2229 */
            r0 = r0 - 0x20u;
            r10 = r5;
            r1 = 0;
            L_2230:; /* 0x2230 */
            CALL(sub_7a);
            if (!(r1 == 0x0u)) {
                L_2238:; /* 0x2238 */
                r3 = r3 + 0x1u;
                r4 = r4 + 0x4u;
                L_223e:; /* 0x223e */
                r9 = d32(r8);
                fc_cmp(r3, r9);
                if (!FC(falcon_flags)) {
                    L_2245:; /* 0x2245 */
                    r10 = 0x1c500u;
                    r11 = 0x51000u;
                    CALL(sub_10);
                    r13 = 0x1c500u;
                    r14 = 0;
                    r15 = 0x40000u;
                    L_225b:; /* 0x225b */
                    r9 = iord(r13+r14*0x4);
                    r9 &= r15;
                    if (!!FZ(falcon_flags)) {
                        L_2264:; /* 0x2264 */
                        CALL(sub_2175);
                        r15 = 0;
                        r9 = 0x10c00u;
                        iowr(r9, r15);
                        r15 = 0x10u;
                        r9 = 0x20000u;
                        iowr(r9, r15);
                        for (int i = 0; i <= 8; i++) r[i] = pop32();
                        return;
                    }
                    goto L_225b;  /* 重复引用 */
                    goto L_225b;  /* 重复引用 */
                    goto L_2264;  /* 重复引用 */
                }
                goto L_21fd;  /* 重复引用 */
            }
            goto L_2217;  /* 重复引用 */
        }
        goto L_2229;  /* 重复引用 */
    }
    goto L_220d;  /* 重复引用 */
}

/* ==== sub_227c  (被调用 1 次) ==== */
static void sub_227c(void) {
    L_227c:; /* 0x227c */
    CALL(sub_215e);
    r10 = 0x24a75cu;
    CALL(sub_297);
    r9 = r10 & 0x10u;
    if (!FZ(falcon_flags)) {
        L_228e:; /* 0x228e */
        r9 = r10 & 0x7u;
        if (!!FZ(falcon_flags)) {
            L_2294:; /* 0x2294 */
            return;
        }
        goto L_227c;  /* 重复引用 */
        goto L_2294;  /* 重复引用 */
    }
    goto L_227c;  /* 重复引用 */
}

/* ==== sub_2296  (被调用 1 次) ==== */
static void sub_2296(void) {
    L_2296:; /* 0x2296 */
    for (int i = 5; i >= 0; i--) push32(r[i]);
    r1 = 0x14c8u;
    if (!(r10 == 0x0u)) {
        L_22a0:; /* 0x22a0 */
        r4 = r1;
        r3 = 0;
        r2 = 0x504340u;
        r5 = 0x14a0u;
        goto L_22da;
        L_22b0:; /* 0x22b0 */
        CALL(sub_215e);
        L_22b4:; /* 0x22b4 */
        r10 = r1;
        CALL(sub_297);
        r10 &= 0x10u;
        if (!!FZ(falcon_flags)) {
            L_22c0:; /* 0x22c0 */
            r0 = r0 + 0x1u;
            r1 = r1 + 0x800u;
            L_22c8:; /* 0x22c8 */
            r9 = d32(r4);
            fc_cmp(r0, r9);
            if (!FC(falcon_flags)) {
                L_22cf:; /* 0x22cf */
                r3 = r3 + 0x1u;
                r2 = r2 + 0x8000u;
                r4 = r4 + 0x4u;
                L_22da:; /* 0x22da */
                r9 = d32(r5);
                fc_cmp(r3, r9);
                if (!!FC(falcon_flags)) {
                    goto L_22b0;  /* 重复引用 */
                    goto L_22b4;  /* 重复引用 */
                    goto L_22c0;  /* 重复引用 */
                    goto L_22c8;  /* 重复引用 */
                    goto L_22cf;  /* 重复引用 */
                    L_22e1:; /* 0x22e1 */
                    r1 = r2;
                    r0 = 0;
                    goto L_22c8;
                    L_22e9:; /* 0x22e9 */
                    r9 = 0x14a0u;
                    r11 = d32(r9);
                    r11 = r11 - 0x1u;
                    CALL(sub_32b);
                    r11 = d32(r1+r10*0x4);
                    r0 = r10;
                    r10 = 0;
                    r0 <<= 0x4u;
                    r11 = r11 - 0x1u;
                    CALL(sub_32b);
                    r9 = 0x504340u;
                    r0 = r0 + r10;
                    r0 <<= 0xbu;
                    r0 = r0 + r9;
                    goto L_231c;
                    L_2318:; /* 0x2318 */
                    CALL(sub_215e);
                    L_231c:; /* 0x231c */
                    r10 = r0;
                    CALL(sub_297);
                    r10 &= 0x10u;
                    if (!FZ(falcon_flags)) goto L_2318;
                    L_2328:; /* 0x2328 */
                    r15 = 0x10000000u;
                    r9 = 0x21a00u;
                    iowr(r9, r15);
                    for (int i = 0; i <= 5; i++) r[i] = pop32();
                    return;
                }
                goto L_2328;  /* 重复引用 */
            }
            goto L_22b4;  /* 重复引用 */
        }
        goto L_22b0;  /* 重复引用 */
        goto L_22b0;  /* 重复引用 */
        goto L_22b4;  /* 重复引用 */
        goto L_22c0;  /* 重复引用 */
        goto L_22c8;  /* 重复引用 */
        goto L_22cf;  /* 重复引用 */
        goto L_22da;  /* 重复引用 */
        goto L_22e1;  /* 重复引用 */
    }
    goto L_22e9;  /* 重复引用 */
}

/* ==== sub_2336  (被调用 1 次) ==== */
static void sub_2336(void) {
    L_2336:; /* 0x2336 */
    r10 = 0x122238u;
    r11 = 0xe003eu;
    r12 = 0;
    r13 = 0x1u;
    CALL(sub_22f);
    goto L_234e;
    L_234a:; /* 0x234a */
    CALL(sub_215e);
    L_234e:; /* 0x234e */
    r10 = 0x122238u;
    CALL(sub_297);
    if (!(r10 != 0x0u)) {
        L_235a:; /* 0x235a */
        return;
    }
    goto L_234a;  /* 重复引用 */
}

/* ==== sub_235c  (被调用 1 次) ==== */
static void sub_235c(void) {
    L_235c:; /* 0x235c */
    for (int i = 0; i >= 0; i--) push32(r[i]);
    r10 = 0x122230u;
    r11 = 0xe003eu;
    r12 = 0;
    r13 = 0x1u;
    r0 = 0xe003eu;
    CALL(sub_22f);
    goto L_237a;
    L_2376:; /* 0x2376 */
    CALL(sub_215e);
    L_237a:; /* 0x237a */
    r10 = 0x122234u;
    CALL(sub_297);
    fc_cmp(r10, r0);
    if (!!FZ(falcon_flags)) {
        L_2387:; /* 0x2387 */
        r10 = 0x1219fcu;
        r11 = 0xfe7ceu;
        CALL(sub_237);
        r10 = 0x1209fcu;
        r11 = 0x10fe7ceu;
        CALL(sub_237);
        r10 = 0x1211fcu;
        r11 = 0x20fe7ceu;
        CALL(sub_237);
        for (int i = 0; i <= 0; i++) r[i] = pop32();
        return;
    }
    goto L_2376;  /* 重复引用 */
}

/* ==== sub_23af  (被调用 4 次) ==== */
static void sub_23af(void) {
    L_23af:; /* 0x23af */
    CALL(sub_235c);
    r15 = 0x10u;
    r9 = 0x18500u;
    iowr(r9, r15);
    r10 = 0x41a614u;
    r11 = 0x820u;
    CALL(sub_237);
    r15 = 0;
    r9 = 0x1600u;
    s32(r9, r15);
    r15 = 0x110u;
    r9 = 0x18500u;
    iowr(r9, r15);
    r10 = 0x41a614u;
    r11 = 0xa20u;
    CALL(sub_237);
    CALL(sub_2336);
    return;
}

/* ==== sub_23ea  (被调用 1 次) ==== */
static void sub_23ea(void) {
    L_23ea:; /* 0x23ea */
    r10 = 0x8u;
    CALL(sub_23af);
    r15 = 0x100u;
    r9 = 0x20000u;
    iowr(r9, r15);
    return;
}

/* ==== sub_23fc  (被调用 37 次) ==== */
static void sub_23fc(void) {
    L_23fc:; /* 0x23fc */
    for (int i = 1; i >= 0; i--) push32(r[i]);
    r15 = 0x10000u;
    r9 = 0x21400u;
    iowr(r9, r15);
    r1 = 0x10000u;
    r0 = 0;
    L_240f:; /* 0x240f */
    CALL(sub_215e);
    r9 = iord(r1+r0*0x4);
    r9 &= 0x100u;
    if (!FZ(falcon_flags)) {
        L_241d:; /* 0x241d */
        r15 = 0x10000u;
        r9 = 0x21a00u;
        iowr(r9, r15);
        for (int i = 0; i <= 1; i++) r[i] = pop32();
        return;
    }
    goto L_240f;  /* 重复引用 */
}

/* ==== sub_242a  (被调用 2 次) ==== */
static void sub_242a(void) {
    L_242a:; /* 0x242a */
    for (int i = 6; i >= 0; i--) push32(r[i]);
    r15 = 0x2000000u;
    r5 = r10;
    r3 = r11;
    r9 = 0x21200u;
    iowr(r9, r15);
    r9 = 0;
    r14 = 0x20400u;
    r14 = iord(r14+r9*0x4);
    r9 = 0x160cu;
    r15 = d32(r9);
    r9 = 0x1614u;
    r10 = 0x10500u;
    s32(r9, r14);
    r15 >>= 0x8u;
    r11 = 0;
    r2 = r14 + r15;
    r1 = 0;
    CALL(sub_10);
    r0 = 0x502810u;
    r6 = 0x14a0u;
    r4 = 0x1608u;
    goto L_249d;
    L_2473:; /* 0x2473 */
    CALL(sub_237);
    r10 = r0 - 0x310u;
    r11 = r3;
    CALL(sub_237);
    r10 = r0 - 0x30cu;
    r11 = r5;
    CALL(sub_237);
    r9 = d32(r4);
    r1 = r1 + 0x1u;
    r0 = r0 + 0x8000u;
    r9 >>= 0x8u;
    r2 = r2 + r9;
    L_249d:; /* 0x249d */
    r9 = d32(r6);
    r10 = r0;
    r11 = r2;
    fc_cmp(r1, r9);
    if (!FC(falcon_flags)) {
        L_24a8:; /* 0x24a8 */
        CALL(sub_23fc);
        r15 = 0x1u;
        r9 = 0x20000u;
        iowr(r9, r15);
        r15 = 0x2000000u;
        r9 = r9 + 0x1800u;
        iowr(r9, r15);
        for (int i = 0; i <= 6; i++) r[i] = pop32();
        return;
    }
    goto L_2473;  /* 重复引用 */
}

/* ==== sub_24c4  (被调用 2 次) ==== */
static void sub_24c4(void) {
    L_24c4:; /* 0x24c4 */
    r9 = 0xe00u;
    r11 = d32(r9+0x28);
    for (int i = 0; i >= 0; i--) push32(r[i]);
    r0 = r10;
    r10 = 0x28u;
    CALL(sub_cc5);
    CALL(sub_23fc);
    r9 = 0x130cu;
    r9 = d32(r9);
    r9 = r9 - 0x1u;
    fc_cmp(r9, 0x1u);
    if (!(!FC(falcon_flags) && !FZ(falcon_flags))) {
        L_24e8:; /* 0x24e8 */
        r11 = r0;
        r10 = 0x41a814u;
        CALL(sub_237);
        r9 = 0x12fcu;
        r11 = d32(r9);
        r10 = 0x26u;
        CALL(sub_cc5);
        CALL(sub_23fc);
        r9 = 0x1300u;
        r11 = d32(r9);
        r10 = 0x23u;
        CALL(sub_cc5);
        CALL(sub_23fc);
        L_2512:; /* 0x2512 */
        for (int i = 0; i <= 0; i++) r[i] = pop32();
        return;
    }
    goto L_2512;  /* 重复引用 */
}

/* ==== sub_2514  (被调用 2 次) ==== */
static void sub_2514(void) {
    L_2514:; /* 0x2514 */
    r15 = 0x1604u;
    r15 = d32(r15);
    sp += -0x34u;
    for (int i = 7; i >= 0; i--) push32(r[i]);
    r9 = sp;
    r9 = r9 + 0x50u;
    s32(r9, r15);
    r15 = 0x800u;
    r9 = 0x21200u;
    iowr(r9, r15);
    r9 = 0x24u;
    r10 = d32(r9);
    r5 = 0x1294u;
    r6 = sp;
    r7 = r5;
    CALL(sub_114);
    r10 = 0x2u;
    CALL(sub_97a);
    r4 = r10;
    r10 = 0xcu;
    CALL(sub_97a);
    r1 = r10;
    r10 = 0x1au;
    CALL(sub_97a);
    r3 = r10;
    r10 = 0x1bu;
    CALL(sub_97a);
    r0 = r10;
    r10 = 0xfu;
    CALL(sub_97a);
    r2 = r10;
    r10 = 0xdu;
    CALL(sub_97a);
    r9 = 0x1000u;
    r1 = r1 + r4;
    r0 = r0 + r3;
    r2 = r10 + r2;
    r0 = r0 + r1;
    r10 = (r10 >> 8) & 0xffu;
    r2 = r2 + r0;
    r10 <<= 0x10u;
    s32(r9+0xe4, r2);
    r1 = (r1 >> 8) & 0xffu;
    r0 = (r0 >> 8) & 0xffffu;
    r1 <<= 0x10u;
    r0 |= r10;
    s32(r9+0xe8, r1);
    s32(r9+0xec, r0);
    r9 = 0x1298u;
    r10 = 0x41a800u;
    s32(r9, r2);
    r11 = 0;
    s32(r5, r2);
    CALL(sub_237);
    r10 = 0x25u;
    r11 = 0;
    r6 = r6 + 0x20u;
    CALL(sub_cc5);
    r3 = r6;
    CALL(sub_23fc);
    r1 = 0;
    r0 = 0x502800u;
    r4 = 0x14a0u;
    goto L_25ec;
    L_25d2:; /* 0x25d2 */
    r10 = r0;
    CALL(sub_297);
    r9 = d32(r7);
    s32(r3, r10);
    r1 = r1 + 0x1u;
    r0 = r0 + 0x8000u;
    r10 = r10 + r9;
    r3 = r3 + 0x4u;
    s32(r7, r10);
    L_25ec:; /* 0x25ec */
    r9 = d32(r4);
    fc_cmp(r1, r9);
    if (!FC(falcon_flags)) {
        L_25f3:; /* 0x25f3 */
        r10 = 0x41a800u;
        r11 = 0;
        CALL(sub_237);
        r10 = 0x10500u;
        r11 = 0;
        r2 >>= 0x8u;
        CALL(sub_10);
        r1 = 0;
        r0 = 0x502500u;
        r3 = 0x14a0u;
        goto L_263c;
        L_2618:; /* 0x2618 */
        r10 = r0;
        r11 = r2;
        CALL(sub_237);
        r10 = r0 + 0x4u;
        r11 = 0x27u;
        CALL(sub_237);
        r9 = d32(r6);
        r1 = r1 + 0x1u;
        r0 = r0 + 0x8000u;
        r6 = r6 + 0x4u;
        r9 >>= 0x8u;
        r2 = r2 + r9;
        L_263c:; /* 0x263c */
        r9 = d32(r3);
        fc_cmp(r1, r9);
        if (!FC(falcon_flags)) {
            L_2643:; /* 0x2643 */
            CALL(sub_23fc);
            r9 = 0x1294u;
            r14 = d32(r9);
            r9 = 0xe00u;
            r15 = 0;
            s32(r9+0x30, r14);
            r9 = 0x10c00u;
            iowr(r9, r15);
            r9 = 0x20000u;
            iowr(r9, r14);
            r15 = 0x800u;
            r9 = r9 + 0x1800u;
            iowr(r9, r15);
            r9 = sp;
            r9 = r9 + 0x50u;
            r15 = d32(r9);
            r9 = 0x1604u;
            r9 = d32(r9);
            fc_cmp(r15, r9);
            if (!FZ(falcon_flags)) {
                L_2682:; /* 0x2682 */
                CALL(sub_747);
                L_2686:; /* 0x2686 */
                for (int i = 0; i <= 7; i++) r[i] = pop32();
                sp += 0x34;
                return;
            }
            goto L_2686;  /* 重复引用 */
            goto L_2682;  /* 重复引用 */
            goto L_2686;  /* 重复引用 */
        }
        goto L_2618;  /* 重复引用 */
        goto L_2618;  /* 重复引用 */
        goto L_263c;  /* 重复引用 */
        goto L_2643;  /* 重复引用 */
        goto L_2682;  /* 重复引用 */
        goto L_2686;  /* 重复引用 */
    }
    goto L_25d2;  /* 重复引用 */
}

/* ==== sub_2689  (被调用 2 次) ==== */
static void sub_2689(void) {
    L_2689:; /* 0x2689 */
    for (int i = 0; i >= 0; i--) push32(r[i]);
    r0 = 0x1308u;
    r11 = d32(r0);
    r10 = 0x19u;
    CALL(sub_cc5);
    CALL(sub_23fc);
    r9 = d32(r0);
    if (!(r9 != 0x2u)) {
        L_26a1:; /* 0x26a1 */
        r9 = 0x12ecu;
        r11 = d32(r9);
        r10 = 0x41a814u;
        CALL(sub_237);
        r9 = 0x12f0u;
        r11 = d32(r9);
        r10 = 0x17u;
        CALL(sub_cc5);
        CALL(sub_23fc);
        r9 = 0x12f4u;
        r11 = d32(r9);
        r10 = 0x22u;
        CALL(sub_cc5);
        CALL(sub_23fc);
        L_26cf:; /* 0x26cf */
        for (int i = 0; i <= 0; i++) r[i] = pop32();
        return;
    }
    goto L_26cf;  /* 重复引用 */
}

/* ==== sub_26d1  (被调用 1 次) ==== */
static void sub_26d1(void) {
    L_26d1:; /* 0x26d1 */
    r15 = 0x400u;
    r9 = 0x21400u;
    iowr(r9, r15);
    r10 = 0x10ac08u;
    CALL(sub_297);
    r9 = 0x100000u;
    r10 &= r9;
    if (!FZ(falcon_flags)) {
        L_26ed:; /* 0x26ed */
        r10 = 0xfu;
        r11 = 0;
        CALL(sub_cc5);
        CALL(sub_23fc);
        r15 = 0x1u;
        r9 = 0x12dcu;
        s32(r9, r15);
        L_2701:; /* 0x2701 */
        r15 = 0x1u;
        r9 = 0x20000u;
        iowr(r9, r15);
        r15 = 0x400u;
        r9 = r9 + 0x1a00u;
        iowr(r9, r15);
        return;
    }
    goto L_2701;  /* 重复引用 */
}

/* ==== sub_2717  (被调用 1 次) ==== */
static void sub_2717(void) {
    L_2717:; /* 0x2717 */
    r15 = 0x100u;
    r9 = 0x21400u;
    iowr(r9, r15);
    r10 = 0xdu;
    r11 = 0;
    CALL(sub_cc5);
    CALL(sub_23fc);
    r9 = 0x12d8u;
    r15 = 0x1u;
    s32(r9, r15);
    r9 = 0x20000u;
    iowr(r9, r15);
    r15 = 0x100u;
    r9 = r9 + 0x1a00u;
    iowr(r9, r15);
    return;
}

/* ==== sub_2749  (被调用 2 次) ==== */
static void sub_2749(void) {
    L_2749:; /* 0x2749 */
    for (int i = 1; i >= 0; i--) push32(r[i]);
    r10 = 0x23900u;
    CALL(sub_44);
    r9 = 0x18u;
    s32(r9, r10);
    r9 = 0xff0000ffu;
    r10 &= r9;
    r9 = 0x1cu;
    r10 |= 0xa00u;
    r11 = r10;
    s32(r9, r10);
    r10 = 0x23900u;
    CALL(sub_10);
    r13 = 0x19000u;
    r14 = 0;
    r15 = -0x1u;
    L_277d:; /* 0x277d */
    r9 = iord(r13+r14*0x4);
    fc_cmp(r9, r15);
    if (!!FZ(falcon_flags)) {
        L_2785:; /* 0x2785 */
        r0 = -0x1u;
        L_2787:; /* 0x2787 */
        r10 = 0x41a640u;
        CALL(sub_297);
        fc_cmp(r10, r0);
        if (!!FZ(falcon_flags)) {
            L_2794:; /* 0x2794 */
            r10 = 0x23900u;
            CALL(sub_44);
            r9 = 0x18u;
            s32(r9, r10);
            r9 = 0xff000fffu;
            r10 &= r9;
            r9 = 0x1cu;
            r10 |= 0xa000u;
            r11 = r10;
            s32(r9, r10);
            r10 = 0x23900u;
            CALL(sub_10);
            r15 = 0x80u;
            r9 = 0x21a00u;
            iowr(r9, r15);
            r15 = 0x800u;
            r9 = r9 - 0x600u;
            iowr(r9, r15);
            r10 = 0x22604u;
            CALL(sub_297);
            r1 = r10 & 0x1u;
            r10 = 0x500304u;
            CALL(sub_297);
            r0 = r10;
            r10 = 0x23900u;
            CALL(sub_44);
            r9 = 0x18u;
            s32(r9, r10);
            r9 = 0xff00ffffu;
            r10 &= r9;
            r9 = 0x90000u;
            r10 |= r9;
            r9 = 0x1cu;
            r11 = r10;
            s32(r9, r10);
            r10 = 0x23900u;
            CALL(sub_10);
            if (!(r1 != 0x0u)) {
                L_2819:; /* 0x2819 */
                r11 = -0x2u;
                r10 = 0x418304u;
                r11 = r0 & r11;
                r12 = 0;
                r13 = 0x1u;
                CALL(sub_22f);
                L_282a:; /* 0x282a */
                r10 = 0x23900u;
                CALL(sub_44);
                r9 = 0x18u;
                s32(r9, r10);
                r9 = 0xffffffu;
                r10 &= r9;
                r9 = 0x9aa55u;
                fc_cmp(r10, r9);
                if (!FZ(falcon_flags)) {
                    L_2849:; /* 0x2849 */
                    CALL(sub_b8b);
                    r10 = 0x25u;
                    CALL(sub_5c0);
                    L_2853:; /* 0x2853 */
                    CALL(sub_e0c);
                    r0 = r10;
                    r10 = 0x23900u;
                    CALL(sub_44);
                    r9 = 0x18u;
                    s32(r9, r10);
                    r9 = 0xff0fffffu;
                    r10 &= r9;
                    r9 = 0x900000u;
                    r10 |= r9;
                    r9 = 0x1cu;
                    r11 = r10;
                    s32(r9, r10);
                    r10 = 0x23900u;
                    CALL(sub_10);
                    if (!(r1 != 0x0u)) {
                        L_288b:; /* 0x288b */
                        r11 = -0x11u;
                        r10 = 0x1fa800u;
                        r11 = r0 & r11;
                        r12 = 0;
                        r13 = 0x1u;
                        CALL(sub_22f);
                        L_289c:; /* 0x289c */
                        r10 = 0x23900u;
                        CALL(sub_44);
                        r9 = 0x18u;
                        s32(r9, r10);
                        r9 = 0xffffffu;
                        r10 &= r9;
                        r9 = 0x99aa55u;
                        fc_cmp(r10, r9);
                        if (!FZ(falcon_flags)) {
                            L_28bc:; /* 0x28bc */
                            CALL(sub_b8b);
                            r10 = 0x26u;
                            CALL(sub_5c0);
                            L_28c6:; /* 0x28c6 */
                            r15 = 0x800u;
                            r9 = 0x21a00u;
                            iowr(r9, r15);
                            r15 = 0x1000u;
                            iowr(r9, r15);
                            r9 = 0x18u;
                            r15 = d32(r9);
                            r9 = 0xff000000u;
                            r10 = 0x23900u;
                            r15 &= r9;
                            r9 = 0x1cu;
                            r11 = r15;
                            s32(r9, r15);
                            CALL(sub_10);
                            CALL(sub_215e);
                            r15 = 0;
                            r9 = 0x9ecu;
                            s32(r9, r15);
                            for (int i = 0; i <= 1; i++) r[i] = pop32();
                            return;
                        }
                        goto L_28c6;  /* 重复引用 */
                    }
                    goto L_289c;  /* 重复引用 */
                }
                goto L_2853;  /* 重复引用 */
            }
            goto L_282a;  /* 重复引用 */
            goto L_2819;  /* 重复引用 */
            goto L_282a;  /* 重复引用 */
            goto L_2849;  /* 重复引用 */
            goto L_2853;  /* 重复引用 */
            goto L_288b;  /* 重复引用 */
            goto L_289c;  /* 重复引用 */
            goto L_28bc;  /* 重复引用 */
            goto L_28c6;  /* 重复引用 */
        }
        goto L_2787;  /* 重复引用 */
        goto L_2787;  /* 重复引用 */
        goto L_2794;  /* 重复引用 */
        goto L_2819;  /* 重复引用 */
        goto L_282a;  /* 重复引用 */
        goto L_2849;  /* 重复引用 */
        goto L_2853;  /* 重复引用 */
        goto L_288b;  /* 重复引用 */
        goto L_289c;  /* 重复引用 */
        goto L_28bc;  /* 重复引用 */
        goto L_28c6;  /* 重复引用 */
    }
    goto L_277d;  /* 重复引用 */
}

/* ==== sub_2902  (被调用 1 次) ==== */
static void sub_2902(void) {
    L_2902:; /* 0x2902 */
    CALL(sub_b8b);
    CALL(sub_2749);
    return;
}

/* ==== sub_290c  (被调用 15 次) ==== */
static void sub_290c(void) {
    L_290c:; /* 0x290c */
    r15 = 0x200000u;
    r9 = 0x21400u;
    iowr(r9, r15);
    goto L_291f;
    L_291b:; /* 0x291b */
    CALL(sub_215e);
    L_291f:; /* 0x291f */
    r10 = 0x404170u;
    CALL(sub_297);
    r10 &= 0x10u;
    if (!!FZ(falcon_flags)) {
        L_292d:; /* 0x292d */
        r15 = 0x200000u;
        r9 = 0x21a00u;
        iowr(r9, r15);
        return;
    }
    goto L_291b;  /* 重复引用 */
}

/* ==== sub_293a  (被调用 4 次) ==== */
static void sub_293a(void) {
    L_293a:; /* 0x293a */
    for (int i = 0; i >= 0; i--) push32(r[i]);
    r0 = r11;
    r11 = r10 & 0x3u;
    r10 = 0x404170u;
    r11 |= 0x10u;
    CALL(sub_237);
    if (!(r0 != 0x1u)) {
        L_2950:; /* 0x2950 */
        goto L_2958;
        L_2954:; /* 0x2954 */
        CALL(sub_215e);
        L_2958:; /* 0x2958 */
        r10 = 0x404170u;
        CALL(sub_297);
        r10 &= 0x10u;
        if (!FZ(falcon_flags)) goto L_2954;
        L_2966:; /* 0x2966 */
        for (int i = 0; i <= 0; i++) r[i] = pop32();
        return;
        goto L_2954;  /* 重复引用 */
        goto L_2958;  /* 重复引用 */
    }
    goto L_2966;  /* 重复引用 */
}

/* ==== sub_2988  (被调用 13 次) ==== */
static void sub_2988(void) {
    L_2988:; /* 0x2988 */
    r11 = r10;
    r15 = 0x80u;
    r9 = 0x21300u;
    iowr(r9, r15);
    r10 = 0;
    CALL(sub_293a);
    r15 = 0x80u;
    r9 = 0x21900u;
    iowr(r9, r15);
    return;
}

/* ==== sub_29a6  (被调用 1 次) ==== */
static void sub_29a6(void) {
    L_29a6:; /* 0x29a6 */
    r15 = 0x20000u;
    r9 = 0x21300u;
    iowr(r9, r15);
    r10 = 0x1u;
    r11 = r10;
    CALL(sub_293a);
    r15 = 0x20000u;
    r9 = 0x21900u;
    iowr(r9, r15);
    return;
}

/* ==== sub_29c6  (被调用 14 次) ==== */
static void sub_29c6(void) {
    L_29c6:; /* 0x29c6 */
    r11 = r10;
    r15 = 0x10000u;
    r9 = 0x21300u;
    iowr(r9, r15);
    r10 = 0x2u;
    CALL(sub_293a);
    r15 = 0x10000u;
    r9 = 0x21900u;
    iowr(r9, r15);
    return;
}

/* ==== sub_29e6  (被调用 2 次) ==== */
static void sub_29e6(void) {
    L_29e6:; /* 0x29e6 */
    r15 = 0x1604u;
    r15 = d32(r15);
    sp += -0x34u;
    for (int i = 6; i >= 0; i--) push32(r[i]);
    r9 = sp;
    r9 = r9 + 0x4cu;
    r6 = r11;
    s32(r9, r15);
    r15 = 0x400u;
    r9 = 0x21200u;
    iowr(r9, r15);
    r9 = 0x24u;
    r10 = d32(r9);
    r9 = 0;
    r0 = 0x128cu;
    s32(r0, r9);
    CALL(sub_114);
    r10 = 0x1u;
    CALL(sub_29c6);
    r10 = 0x1u;
    r12 = r10;
    r11 = r10;
    CALL(sub_cf5);
    CALL(sub_290c);
    r10 = 0;
    CALL(sub_2988);
    r10 = 0x41a800u;
    r11 = 0;
    CALL(sub_237);
    r10 = 0x16u;
    r11 = 0;
    r4 = r0;
    CALL(sub_cc5);
    r3 = sp;
    CALL(sub_23fc);
    r3 = r3 + 0x1cu;
    r2 = 0;
    r1 = r3;
    r0 = 0x502800u;
    r5 = 0x14a0u;
    goto L_2a82;
    L_2a5f:; /* 0x2a5f */
    r10 = r0;
    CALL(sub_297);
    r9 = d32(r4);
    r10 >>= 0x8u;
    r2 = r2 + 0x1u;
    r10 = r10 + 0x1u;
    r0 = r0 + 0x8000u;
    r10 <<= 0x8u;
    s32(r1, r10);
    r10 = r10 + r9;
    r1 = r1 + 0x4u;
    s32(r4, r10);
    L_2a82:; /* 0x2a82 */
    r9 = d32(r5);
    fc_cmp(r2, r9);
    if (!FC(falcon_flags)) {
        L_2a89:; /* 0x2a89 */
        r10 = 0x41a800u;
        r11 = 0;
        CALL(sub_237);
        r10 = 0x10500u;
        r11 = 0;
        r2 = 0;
        CALL(sub_10);
        r1 = 0;
        r0 = 0x502500u;
        r4 = 0x14a0u;
        goto L_2ad1;
        L_2aad:; /* 0x2aad */
        r10 = r0;
        r11 = r2;
        CALL(sub_237);
        r10 = r0 + 0x4u;
        r11 = 0x18u;
        CALL(sub_237);
        r9 = d32(r3);
        r1 = r1 + 0x1u;
        r0 = r0 + 0x8000u;
        r3 = r3 + 0x4u;
        r9 >>= 0x8u;
        r2 = r2 + r9;
        L_2ad1:; /* 0x2ad1 */
        r9 = d32(r4);
        fc_cmp(r1, r9);
        if (!FC(falcon_flags)) {
            L_2ad8:; /* 0x2ad8 */
            CALL(sub_23fc);
            r15 = 0x128cu;
            r9 = d32(r15);
            fc_cmp(r6, r9);
            if (!(FC(falcon_flags) || FZ(falcon_flags))) {
                L_2ae7:; /* 0x2ae7 */
                s32(r15, r6);
                L_2ae9:; /* 0x2ae9 */
                r15 = 0x128cu;
                r9 = d32(r15);
                if (!(r9 != 0x0u)) {
                    L_2af3:; /* 0x2af3 */
                    r9 = 0x100u;
                    s32(r15, r9);
                    L_2af8:; /* 0x2af8 */
                    r9 = 0x128cu;
                    r15 = d32(r9);
                    r9 = 0xe00u;
                    s32(r9+0x24, r15);
                    r9 = 0x20000u;
                    iowr(r9, r15);
                    r10 = 0;
                    CALL(sub_29c6);
                    r10 = 0x1u;
                    r11 = r10;
                    r12 = r10;
                    CALL(sub_c7b);
                    CALL(sub_290c);
                    r10 = 0;
                    CALL(sub_2988);
                    r15 = 0;
                    r9 = 0x10c00u;
                    iowr(r9, r15);
                    r15 = 0x400u;
                    r9 = 0x21800u;
                    iowr(r9, r15);
                    r9 = sp;
                    r9 = r9 + 0x4cu;
                    r15 = d32(r9);
                    r9 = 0x1604u;
                    r9 = d32(r9);
                    fc_cmp(r15, r9);
                    if (!FZ(falcon_flags)) {
                        L_2b4c:; /* 0x2b4c */
                        CALL(sub_747);
                        L_2b50:; /* 0x2b50 */
                        for (int i = 0; i <= 6; i++) r[i] = pop32();
                        sp += 0x34;
                        return;
                    }
                    goto L_2b50;  /* 重复引用 */
                }
                goto L_2af8;  /* 重复引用 */
            }
            goto L_2ae9;  /* 重复引用 */
            goto L_2ae7;  /* 重复引用 */
            goto L_2ae9;  /* 重复引用 */
            goto L_2af3;  /* 重复引用 */
            goto L_2af8;  /* 重复引用 */
            goto L_2b4c;  /* 重复引用 */
            goto L_2b50;  /* 重复引用 */
        }
        goto L_2aad;  /* 重复引用 */
        goto L_2aad;  /* 重复引用 */
        goto L_2ad1;  /* 重复引用 */
        goto L_2ad8;  /* 重复引用 */
        goto L_2ae7;  /* 重复引用 */
        goto L_2ae9;  /* 重复引用 */
        goto L_2af3;  /* 重复引用 */
        goto L_2af8;  /* 重复引用 */
        goto L_2b4c;  /* 重复引用 */
        goto L_2b50;  /* 重复引用 */
    }
    goto L_2a5f;  /* 重复引用 */
}

/* ==== sub_2b53  (被调用 2 次) ==== */
static void sub_2b53(void) {
    L_2b53:; /* 0x2b53 */
    for (int i = 0; i >= 0; i--) push32(r[i]);
    CALL(sub_768);
    if (!(r10 != 0x0u)) {
        L_2b5d:; /* 0x2b5d */
        r9 = 0x20u;
        r9 = d32(r9);
        if ((r9 != 0x0u)) goto L_2ba1;
        L_2b67:; /* 0x2b67 */
        r10 = 0x1u;
        CALL(sub_29c6);
        r10 = 0x1u;
        r11 = r10;
        r12 = r10;
        CALL(sub_cf5);
        CALL(sub_290c);
        r9 = 0x9ecu;
        r0 = 0x1u;
        s32(r9, r0);
        CALL(sub_2902);
        r10 = 0x8u;
        CALL(sub_23af);
        r10 = r0;
        r11 = r0;
        r12 = r0;
        CALL(sub_c7b);
        CALL(sub_290c);
        r10 = 0;
        CALL(sub_2988);
        L_2ba1:; /* 0x2ba1 */
        for (int i = 0; i <= 0; i++) r[i] = pop32();
        return;
    }
    goto L_2b67;  /* 重复引用 */
}

/* ==== sub_2ba3  (被调用 1 次) ==== */
static void sub_2ba3(void) {
    L_2ba3:; /* 0x2ba3 */
    r15 = 0x1u;
    r9 = 0x21200u;
    iowr(r9, r15);
    r14 = 0;
    r9 = 0x136cu;
    s32(r9, r14);
    r15 = 0xb00u;
    r9 = 0x1370u;
    s32(r9, r14);
    r15 = iord(r15+r14*0x4);
    r9 = 0xc00u;
    r9 = iord(r9+r14*0x4);
    r9 ^= r15;
    r15 = 0x1604u;
    s32(r15, r9);
    CALL(sub_183d);
    CALL(sub_ef7);
    CALL(sub_a26);
    CALL(sub_189b);
    CALL(sub_186e);
    CALL(sub_2b53);
    r9 = 0x12d4u;
    r10 = d32(r9);
    r9 = 0x402e8u;
    r12 = 0;
    r13 = 0x1u;
    r10 = r10 + r9;
    r11 = 0;
    r10 <<= 0x2u;
    CALL(sub_22f);
    r10 = 0x28d00u;
    r11 = 0x33333333u;
    CALL(sub_10);
    r15 = 0x1u;
    r9 = 0x20000u;
    iowr(r9, r15);
    return;
}

/* ==== sub_2c19  (被调用 31 次) ==== */
static void sub_2c19(void) {
    L_2c19:; /* 0x2c19 */
    for (int i = 1; i >= 0; i--) push32(r[i]);
    r15 = 0x4000u;
    r9 = 0x21300u;
    iowr(r9, r15);
    r1 = 0x10000u;
    r0 = 0;
    L_2c2b:; /* 0x2c2b */
    CALL(sub_215e);
    r9 = iord(r1+r0*0x4);
    r9 &= 0x4u;
    if (!!FZ(falcon_flags)) {
        L_2c38:; /* 0x2c38 */
        r15 = 0x4000u;
        r9 = 0x21900u;
        iowr(r9, r15);
        for (int i = 0; i <= 1; i++) r[i] = pop32();
        return;
    }
    goto L_2c2b;  /* 重复引用 */
}

/* ==== sub_2c44  (被调用 1 次) ==== */
static void sub_2c44(void) {
    L_2c44:; /* 0x2c44 */
    r11 = r10;
    r15 = 0x8000u;
    r9 = 0x21300u;
    iowr(r9, r15);
    r10 = 0x247fcu;
    CALL(sub_10);
    r10 = 0x24afcu;
    r11 = 0x1u;
    CALL(sub_10);
    CALL(sub_2c19);
    r10 = 0x246fcu;
    r11 = 0;
    CALL(sub_10);
    r10 = 0x24afcu;
    r11 = 0x5u;
    CALL(sub_10);
    CALL(sub_2c19);
    r15 = 0x8000u;
    r9 = 0x21900u;
    iowr(r9, r15);
    return;
}

/* ==== sub_2c8c  (被调用 2 次) ==== */
static void sub_2c8c(void) {
    L_2c8c:; /* 0x2c8c */
    r11 = r10;
    r15 = 0x2000u;
    r9 = 0x21300u;
    iowr(r9, r15);
    r10 = 0x247fcu;
    CALL(sub_10);
    r10 = 0x24afcu;
    r11 = 0x1u;
    CALL(sub_10);
    CALL(sub_2c19);
    r10 = 0x246fcu;
    r11 = -0x1u;
    CALL(sub_10);
    r10 = 0x24afcu;
    r11 = 0x2u;
    CALL(sub_10);
    r15 = 0x2000u;
    r9 = 0x21900u;
    iowr(r9, r15);
    return;
}

/* ==== sub_2cce  (被调用 1 次) ==== */
static void sub_2cce(void) {
    L_2cce:; /* 0x2cce */
    r15 = 0x100u;
    r9 = 0x21200u;
    iowr(r9, r15);
    r10 = 0;
    CALL(sub_29c6);
    r10 = 0x1u;
    r12 = r10;
    r11 = r10;
    CALL(sub_cf5);
    CALL(sub_290c);
    r10 = 0;
    CALL(sub_2988);
    r10 = 0x41a800u;
    r11 = 0;
    CALL(sub_237);
    r11 = 0;
    r10 = 0x11u;
    CALL(sub_cc5);
    CALL(sub_ed1);
    r10 = 0x1u;
    CALL(sub_415);
    CALL(sub_2c19);
    r10 = 0;
    CALL(sub_2c8c);
    CALL(sub_2c19);
    r11 = 0x1u;
    r10 = 0xfu;
    CALL(sub_3ed);
    CALL(sub_2c19);
    r10 = 0;
    CALL(sub_2c44);
    CALL(sub_2c19);
    r10 = 0xfu;
    r11 = 0;
    CALL(sub_3ed);
    CALL(sub_2c19);
    r11 = 0x1u;
    r10 = 0x3u;
    CALL(sub_3ed);
    CALL(sub_2c19);
    r10 = 0;
    CALL(sub_415);
    CALL(sub_2c19);
    CALL(sub_23fc);
    r10 = 0x8u;
    CALL(sub_23af);
    r10 = 0;
    CALL(sub_29c6);
    r10 = 0x1u;
    r11 = r10;
    r12 = r10;
    CALL(sub_c7b);
    CALL(sub_290c);
    r10 = 0;
    CALL(sub_2988);
    CALL(sub_23fc);
    r15 = 0x1u;
    r9 = 0x20000u;
    iowr(r9, r15);
    r15 = 0x100u;
    r9 = r9 + 0x1800u;
    iowr(r9, r15);
    return;
}

/* ==== sub_2d92  (被调用 2 次) ==== */
static void sub_2d92(void) {
    L_2d92:; /* 0x2d92 */
    for (int i = 5; i >= 0; i--) push32(r[i]);
    r5 = r10;
    r4 = r11;
    r3 = r12;
    r1 = 0;
    r0 = 0;
    goto L_2dd3;
    L_2da2:; /* 0x2da2 */
    CALL(sub_215e);
    L_2da6:; /* 0x2da6 */
    r10 = r2;
    CALL(sub_297);
    if (!(r10 != 0x0u)) {
        L_2db0:; /* 0x2db0 */
        goto L_2dbc;
        L_2db4:; /* 0x2db4 */
        CALL(sub_215e);
        goto L_2dbf;
        L_2dbc:; /* 0x2dbc */
        r2 = r0 + r4;
        L_2dbf:; /* 0x2dbf */
        r10 = r2;
        CALL(sub_297);
        r10 &= 0x7u;
        if (!!FZ(falcon_flags)) {
            L_2dcb:; /* 0x2dcb */
            r1 = r1 + 0x1u;
            r0 = r0 + 0x200u;
            L_2dd3:; /* 0x2dd3 */
            fc_cmp(r1, r3);
            if (!!FC(falcon_flags)) {
                goto L_2da2;  /* 重复引用 */
                goto L_2da6;  /* 重复引用 */
                goto L_2db0;  /* 重复引用 */
                goto L_2db4;  /* 重复引用 */
                goto L_2dbc;  /* 重复引用 */
                goto L_2dbf;  /* 重复引用 */
                goto L_2dcb;  /* 重复引用 */
                L_2dd8:; /* 0x2dd8 */
                r2 = r0 + r5;
                goto L_2da6;
                L_2ddf:; /* 0x2ddf */
                for (int i = 0; i <= 5; i++) r[i] = pop32();
                return;
            }
            goto L_2ddf;  /* 重复引用 */
        }
        goto L_2db4;  /* 重复引用 */
        goto L_2db4;  /* 重复引用 */
        goto L_2dbc;  /* 重复引用 */
        goto L_2dbf;  /* 重复引用 */
        goto L_2dcb;  /* 重复引用 */
    }
    goto L_2da2;  /* 重复引用 */
}

/* ==== sub_2de1  (被调用 24 次) ==== */
static void sub_2de1(void) {
    L_2de1:; /* 0x2de1 */
    for (int i = 4; i >= 0; i--) push32(r[i]);
    r15 = 0x200u;
    r2 = r13;
    r3 = r11;
    r4 = r12;
    r13 = d32(sp+0x18);
    r9 = 0x21300u;
    iowr(r9, r15);
    r15 = 0x1u;
    if (!(r13 == 0x2u)) {
        L_2dfc:; /* 0x2dfc */
        if (!(r13 == 0x1u)) {
            L_2e00:; /* 0x2e00 */
            r15 = 0;
            goto L_2e32;
            L_2e06:; /* 0x2e06 */
            if (!(r14 != 0x0u)) {
                L_2e0a:; /* 0x2e0a */
                r15 = 0x80000002u;
                goto L_2e32;
                L_2e13:; /* 0x2e13 */
                if (!(r14 != 0x3u)) {
                    L_2e17:; /* 0x2e17 */
                    r15 = 0x80000003u;
                    goto L_2e32;
                    L_2e20:; /* 0x2e20 */
                    if (!(r14 != 0x2u)) {
                        L_2e24:; /* 0x2e24 */
                        r15 = 0x80000004u;
                        goto L_2e32;
                        L_2e2d:; /* 0x2e2d */
                        r15 = 0x80000000u;
                        L_2e32:; /* 0x2e32 */
                        r9 = 0x28800u;
                        iowr(r9, r15);
                        sr_xdbase = r10;
                        r9 = 0;
                        sr_xtargets = r9;
                        r10 = 0x4300u;
                        r11 = 0;
                        CALL(sub_10);
                        r15 = 0x4800u;
                        r9 = 0;
                        r9 = iord(r15+r9*0x4);
                        r0 = 0;
                        r1 = r15;
                        goto L_2e61;
                        L_2e5a:; /* 0x2e5a */
                        CALL(sub_215e);
                        r9 = iord(r1+r0*0x4);
                        L_2e61:; /* 0x2e61 */
                        r15 = r9 >> 0x18u;
                        r9 = (r9 >> 16) & 0xffu;
                        r9 = r9 + r15;
                        if (!(r9 == 0x4u)) {
                            L_2e6e:; /* 0x2e6e */
                            r9 = d32(sp+0x1c);
                            r12 = r4 << 0x10u;
                            if (!(r9 != 0x1u)) {
                                L_2e78:; /* 0x2e78 */
                                r9 = r2 | r12;
                                r3 = xdld(r9);
                                goto L_2e88;
                                L_2e82:; /* 0x2e82 */
                                r9 = r2 | r12;
                                xdst(r3, r9);
                                L_2e88:; /* 0x2e88 */
                                r9 = d32(sp+0x20);
                                if (!(r9 != 0x2u)) {
                                    L_2e8f:; /* 0x2e8f */
                                    goto L_2e9b;
                                    L_2e93:; /* 0x2e93 */
                                    CALL(sub_215e);
                                    goto L_2ea0;
                                    L_2e9b:; /* 0x2e9b */
                                    r1 = 0x4800u;
                                    r0 = 0;
                                    L_2ea0:; /* 0x2ea0 */
                                    r9 = iord(r1+r0*0x4);
                                    r9 &= 0x2u;
                                    if (!!FZ(falcon_flags)) {
                                        L_2ea9:; /* 0x2ea9 */
                                        UNKNOWN("xdwait"); /* FIXME */
                                        L_2eab:; /* 0x2eab */
                                        r15 = 0;
                                        r9 = 0x28800u;
                                        iowr(r9, r15);
                                        r15 = 0x200u;
                                        r9 = r9 - 0x6f00u;
                                        iowr(r9, r15);
                                        for (int i = 0; i <= 4; i++) r[i] = pop32();
                                        return;
                                    }
                                    goto L_2e93;  /* 重复引用 */
                                    goto L_2e93;  /* 重复引用 */
                                    goto L_2e9b;  /* 重复引用 */
                                    goto L_2ea0;  /* 重复引用 */
                                    goto L_2ea9;  /* 重复引用 */
                                }
                                goto L_2eab;  /* 重复引用 */
                            }
                            goto L_2e82;  /* 重复引用 */
                            goto L_2e78;  /* 重复引用 */
                            goto L_2e82;  /* 重复引用 */
                            goto L_2e88;  /* 重复引用 */
                            goto L_2e8f;  /* 重复引用 */
                            goto L_2e93;  /* 重复引用 */
                            goto L_2e9b;  /* 重复引用 */
                            goto L_2ea0;  /* 重复引用 */
                            goto L_2ea9;  /* 重复引用 */
                            goto L_2eab;  /* 重复引用 */
                        }
                        goto L_2e5a;  /* 重复引用 */
                    }
                    goto L_2e2d;  /* 重复引用 */
                }
                goto L_2e20;  /* 重复引用 */
            }
            goto L_2e13;  /* 重复引用 */
        }
        goto L_2e06;  /* 重复引用 */
        goto L_2e00;  /* 重复引用 */
        goto L_2e06;  /* 重复引用 */
        goto L_2e0a;  /* 重复引用 */
        goto L_2e13;  /* 重复引用 */
        goto L_2e17;  /* 重复引用 */
        goto L_2e20;  /* 重复引用 */
        goto L_2e24;  /* 重复引用 */
        goto L_2e2d;  /* 重复引用 */
    }
    goto L_2e32;  /* 重复引用 */
}

/* ==== sub_2ec1  (被调用 3 次) ==== */
static void sub_2ec1(void) {
    L_2ec1:; /* 0x2ec1 */
    for (int i = 0; i >= 0; i--) push32(r[i]);
    r15 = 0x4u;
    sp += -0xcu;
    r0 = r10;
    r9 = 0x21300u;
    iowr(r9, r15);
    r9 = 0x2u;
    s32(sp, r9);
    r9 = 0x1u;
    s32(sp+0x8, r10);
    r11 = 0;
    s32(sp+0x4, r9);
    r10 = 0;
    r12 = 0x6u;
    r13 = 0xa00u;
    r14 = 0;
    CALL(sub_2de1);
    r11 = 0;
    L_2ef0:; /* 0x2ef0 */
    r9 = 0xe00u;
    r13 = 0xa00u;
    r15 = r11 + r9;
    r9 = r11 + r13;
    r9 = d32(r9);
    r11 = r11 + 0x4u;
    s32(r15, r9);
    if (!(r11 != 0x100u)) {
        L_2f0a:; /* 0x2f0a */
        r9 = 0x2u;
        s32(sp, r9);
        r9 = 0x1u;
        r14 = 0;
        s32(sp+0x4, r9);
        s32(sp+0x8, r0);
        r10 = 0;
        r12 = 0x6u;
        CALL(sub_2de1);
        r9 = 0xa00u;
        r15 = 0xf00u;
        r14 = 0xb00u;
        L_2f2d:; /* 0x2f2d */
        r13 = d32(r9);
        r9 = r9 + 0x4u;
        s32(r15, r13);
        r15 = r15 + 0x4u;
        fc_cmp(r9, r14);
        if (!!FZ(falcon_flags)) {
            L_2f3c:; /* 0x2f3c */
            r15 = 0x4u;
            r9 = 0x21900u;
            iowr(r9, r15);
            sp += 0xcu;
            for (int i = 0; i <= 0; i++) r[i] = pop32();
            return;
        }
        goto L_2f2d;  /* 重复引用 */
        goto L_2f2d;  /* 重复引用 */
        goto L_2f3c;  /* 重复引用 */
    }
    goto L_2ef0;  /* 重复引用 */
}

/* ==== sub_2f4a  (被调用 3 次) ==== */
static void sub_2f4a(void) {
    L_2f4a:; /* 0x2f4a */
    for (int i = 0; i >= 0; i--) push32(r[i]);
    r15 = 0x8u;
    sp += -0xcu;
    r0 = r10;
    r9 = 0x21300u;
    iowr(r9, r15);
    r14 = 0;
    L_2f5c:; /* 0x2f5c */
    r9 = 0xa00u;
    r13 = 0xe00u;
    r15 = r14 + r9;
    r9 = r14 + r13;
    r9 = d32(r9);
    r14 = r14 + 0x4u;
    s32(r15, r9);
    if (!(r14 != 0x100u)) {
        L_2f76:; /* 0x2f76 */
        r9 = 0x2u;
        r14 = 0;
        s32(sp+0x4, r9);
        s32(sp, r9);
        s32(sp+0x8, r0);
        r10 = 0;
        r11 = 0;
        r12 = 0x6u;
        r13 = 0xa00u;
        CALL(sub_2de1);
        r9 = 0xf00u;
        r15 = 0xa00u;
        r14 = 0x1000u;
        L_2f9d:; /* 0x2f9d */
        r13 = d32(r9);
        r9 = r9 + 0x4u;
        s32(r15, r13);
        r15 = r15 + 0x4u;
        fc_cmp(r9, r14);
        if (!!FZ(falcon_flags)) {
            L_2fac:; /* 0x2fac */
            r9 = 0x2u;
            s32(sp+0x8, r0);
            s32(sp+0x4, r9);
            s32(sp, r9);
            r10 = 0;
            r11 = 0x100u;
            r12 = 0x6u;
            r13 = 0xa00u;
            r14 = 0;
            CALL(sub_2de1);
            r15 = 0x8u;
            r9 = 0x21900u;
            iowr(r9, r15);
            sp += 0xcu;
            for (int i = 0; i <= 0; i++) r[i] = pop32();
            return;
        }
        goto L_2f9d;  /* 重复引用 */
        goto L_2f9d;  /* 重复引用 */
        goto L_2fac;  /* 重复引用 */
    }
    goto L_2f5c;  /* 重复引用 */
}

/* ==== sub_2fd6  (被调用 1 次) ==== */
static void sub_2fd6(void) {
    L_2fd6:; /* 0x2fd6 */
    for (int i = 0; i >= 0; i--) push32(r[i]);
    r15 = 0x1u;
    sp += -0xcu;
    r0 = r10;
    r9 = 0x21300u;
    iowr(r9, r15);
    r9 = 0x2u;
    s32(sp, r9);
    r9 = 0x1u;
    s32(sp+0x8, r10);
    r14 = 0;
    s32(sp+0x4, r9);
    r10 = 0;
    r11 = 0x200u;
    r12 = 0x6u;
    r13 = 0xa00u;
    CALL(sub_2de1);
    r14 = 0;
    L_3006:; /* 0x3006 */
    r9 = 0x1000u;
    r13 = 0xa00u;
    r15 = r14 + r9;
    r9 = r14 + r13;
    r9 = d32(r9);
    r14 = r14 + 0x4u;
    s32(r15, r9);
    if (!(r14 != 0x100u)) {
        L_3020:; /* 0x3020 */
        r9 = 0x2u;
        s32(sp, r9);
        r9 = 0x1u;
        r14 = 0;
        s32(sp+0x4, r9);
        s32(sp+0x8, r0);
        r10 = 0;
        r11 = 0x300u;
        r12 = 0x6u;
        CALL(sub_2de1);
        r9 = 0xa00u;
        r15 = 0x1100u;
        r14 = 0xb00u;
        L_3046:; /* 0x3046 */
        r13 = d32(r9);
        r9 = r9 + 0x4u;
        s32(r15, r13);
        r15 = r15 + 0x4u;
        fc_cmp(r9, r14);
        if (!!FZ(falcon_flags)) {
            L_3055:; /* 0x3055 */
            r15 = 0x1u;
            r9 = 0x21900u;
            iowr(r9, r15);
            sp += 0xcu;
            for (int i = 0; i <= 0; i++) r[i] = pop32();
            return;
        }
        goto L_3046;  /* 重复引用 */
        goto L_3046;  /* 重复引用 */
        goto L_3055;  /* 重复引用 */
    }
    goto L_3006;  /* 重复引用 */
}

/* ==== sub_3063  (被调用 1 次) ==== */
static void sub_3063(void) {
    L_3063:; /* 0x3063 */
    for (int i = 0; i >= 0; i--) push32(r[i]);
    r15 = 0x2u;
    sp += -0xcu;
    r0 = r10;
    r9 = 0x21300u;
    iowr(r9, r15);
    r14 = 0;
    L_3075:; /* 0x3075 */
    r9 = 0xa00u;
    r13 = 0x1000u;
    r15 = r14 + r9;
    r9 = r14 + r13;
    r9 = d32(r9);
    r14 = r14 + 0x4u;
    s32(r15, r9);
    if (!(r14 != 0x100u)) {
        L_308f:; /* 0x308f */
        r9 = 0x2u;
        r14 = 0;
        s32(sp+0x4, r9);
        s32(sp, r9);
        s32(sp+0x8, r0);
        r10 = 0;
        r11 = 0x200u;
        r12 = 0x6u;
        r13 = 0xa00u;
        CALL(sub_2de1);
        r9 = 0x1100u;
        r15 = 0xa00u;
        r14 = 0x1200u;
        L_30b7:; /* 0x30b7 */
        r13 = d32(r9);
        r9 = r9 + 0x4u;
        s32(r15, r13);
        r15 = r15 + 0x4u;
        fc_cmp(r9, r14);
        if (!!FZ(falcon_flags)) {
            L_30c6:; /* 0x30c6 */
            s32(sp+0x8, r0);
            r10 = 0;
            r0 = 0x2u;
            r11 = 0x300u;
            s32(sp, r0);
            s32(sp+0x4, r0);
            r12 = 0x6u;
            r13 = 0xa00u;
            r14 = 0;
            CALL(sub_2de1);
            r9 = 0x21900u;
            iowr(r9, r0);
            sp += 0xcu;
            for (int i = 0; i <= 0; i++) r[i] = pop32();
            return;
        }
        goto L_30b7;  /* 重复引用 */
        goto L_30b7;  /* 重复引用 */
        goto L_30c6;  /* 重复引用 */
    }
    goto L_3075;  /* 重复引用 */
}

/* ==== sub_315c  (被调用 1 次) ==== */
static void sub_315c(void) {
    L_315c:; /* 0x315c */
    r9 = 0x12a4u;
    r11 = d32(r9);
    r9 = 0x12a0u;
    r15 = d32(r9);
    r9 = 0x2u;
    sp += -0xcu;
    r14 = 0;
    s32(sp+0x8, r9);
    s32(sp, r9);
    s32(sp+0x4, r9);
    r11 = r11 - 0x1u;
    r10 = 0;
    r11 >>= 0x6u;
    r12 = 0x6u;
    r11 = r11 + r15;
    r13 = 0xa00u;
    r11 <<= 0x8u;
    CALL(sub_2de1);
    r9 = 0xa00u;
    r14 = 0;
    r15 = 0xb00u;
    L_319a:; /* 0x319a */
    s32(r9, r14);
    r9 = r9 + 0x4u;
    fc_cmp(r9, r15);
    if (!!FZ(falcon_flags)) {
        L_31a4:; /* 0x31a4 */
        sp += 0xcu;
        return;
    }
    goto L_319a;  /* 重复引用 */
}

/* ==== sub_31cf  (被调用 26 次) ==== */
static void sub_31cf(void) {
    L_31cf:; /* 0x31cf */
    for (int i = 1; i >= 0; i--) push32(r[i]);
    r15 = 0x100u;
    r9 = 0x21300u;
    iowr(r9, r15);
    r1 = 0x10000u;
    r0 = 0;
    goto L_31e9;
    L_31e5:; /* 0x31e5 */
    CALL(sub_215e);
    L_31e9:; /* 0x31e9 */
    r9 = iord(r1+r0*0x4);
    r9 &= 0x1000u;
    if (!!FZ(falcon_flags)) {
        L_31f3:; /* 0x31f3 */
        r15 = 0x100u;
        r9 = 0x21900u;
        iowr(r9, r15);
        for (int i = 0; i <= 1; i++) r[i] = pop32();
        return;
    }
    goto L_31e5;  /* 重复引用 */
}

/* ==== sub_31ff  (被调用 1 次) ==== */
static void sub_31ff(void) {
    L_31ff:; /* 0x31ff */
    for (int i = 5; i >= 0; i--) push32(r[i]);
    r0 = r10;
    sp += -0xcu;
    r1 = r11;
    r2 = r12;
    CALL(sub_1f53);
    r9 = 0x1u;
    if (!(r10 == 0x0u)) {
        L_3215:; /* 0x3215 */
        r11 = r1;
        r12 = r2;
        r10 = 0x1u;
        CALL(sub_1eda);
        r11 = r1;
        r5 = r10;
        r12 = r2;
        r10 = 0x2u;
        CALL(sub_1eda);
        r1 = (r0 >> 2) & 0x3fffu;
        r4 = r10;
        r15 = (r0 >> 16) & 0xfu;
        if (!FZ(falcon_flags)) {
            L_3237:; /* 0x3237 */
            if (!(r15 != 0x1u)) {
                L_323b:; /* 0x323b */
                goto L_3249;
                L_323f:; /* 0x323f */
                r9 = 0x1454u;
                s32(r9, r15);
                goto L_325c;
                L_3249:; /* 0x3249 */
                r9 = r0 >> 0x14u;
                r9 = r9 + 0x1u;
                r3 = r9 << 0x8u;
                goto L_325e;
                L_3256:; /* 0x3256 */
                r10 = 0x11u;
                CALL(sub_5c0);
                L_325c:; /* 0x325c */
                r3 = 0;
                L_325e:; /* 0x325e */
                r9 = 0x1u;
                r0 = 0x2u;
                r10 = 0;
                r11 = r3;
                r12 = 0x6u;
                r13 = 0xa00u;
                r14 = 0;
                s32(sp+0x4, r9);
                s32(sp, r0);
                s32(sp+0x8, r0);
                CALL(sub_2de1);
                r9 = 0xa00u;
                r15 = r1 << 0x2u;
                r15 = r15 + r9;
                r1 = d32(r15);
                r13 = r9;
                r11 = r3;
                r10 = 0;
                r12 = 0x6u;
                r14 = 0;
                r2 = r4 & r5;
                r9 = ~r4;
                r9 &= r1;
                r9 |= r2;
                s32(r15, r9);
                s32(sp+0x8, r0);
                s32(sp, r0);
                s32(sp+0x4, r0);
                CALL(sub_2de1);
                CALL(sub_31cf);
                r9 = 0;
                L_32b2:; /* 0x32b2 */
                r10 = r9;
                sp += 0xcu;
                for (int i = 0; i <= 5; i++) r[i] = pop32();
                return;
                goto L_3249;  /* 重复引用 */
            }
            goto L_3256;  /* 重复引用 */
            goto L_323b;  /* 重复引用 */
            goto L_3249;  /* 重复引用 */
            goto L_3256;  /* 重复引用 */
        }
        goto L_323f;  /* 重复引用 */
        goto L_3237;  /* 重复引用 */
        goto L_323b;  /* 重复引用 */
        goto L_323f;  /* 重复引用 */
        goto L_3249;  /* 重复引用 */
        goto L_3256;  /* 重复引用 */
        goto L_325c;  /* 重复引用 */
        goto L_325e;  /* 重复引用 */
    }
    goto L_32b2;  /* 重复引用 */
}

/* ==== sub_32b9  (被调用 39 次) ==== */
static void sub_32b9(void) {
    L_32b9:; /* 0x32b9 */
    for (int i = 2; i >= 0; i--) push32(r[i]);
    r0 = r12;
    r1 = r10;
    r2 = r11;
    CALL(sub_31cf);
    r11 = r1;
    r10 = 0x28100u;
    CALL(sub_10);
    r11 = r2;
    r10 = 0x28e00u;
    CALL(sub_10);
    r11 = r0;
    r10 = 0x28f00u;
    CALL(sub_10);
    for (int i = 0; i <= 2; i++) r[i] = pop32();
    return;
}

/* ==== sub_32e5  (被调用 1 次) ==== */
static void sub_32e5(void) {
    L_32e5:; /* 0x32e5 */
    r15 = 0;
    r9 = 0x28100u;
    r9 = iord(r9+r15*0x4);
    r9 = 0x28e00u;
    r9 = iord(r9+r15*0x4);
    r9 = 0x12fcu;
    r10 = d32(r9);
    r9 = 0x1300u;
    r11 = d32(r9);
    r9 = 0x1304u;
    r12 = d32(r9);
    CALL(sub_32b9);
    r10 = 0x1u;
    CALL(sub_e3);
    r10 = 0xbu;
    r11 = 0x3fu;
    CALL(sub_c4);
    r9 = 0x1000u;
    r11 = d32(r9+0xe8);
    r10 = 0x10u;
    r11 = (r11 >> 16) & 0xffu;
    CALL(sub_c4);
    r9 = 0x688u;
    r13 = d32(r9);
    r10 = 0x1au;
    r11 = 0x2u;
    r12 = 0x664u;
    CALL(sub_7e1);
    CALL(sub_2175);
    r9 = 0x12e0u;
    r10 = d32(r9);
    r9 = 0x12e4u;
    r11 = d32(r9);
    r9 = 0x12e8u;
    r12 = d32(r9);
    CALL(sub_32b9);
    return;
}

/* ==== sub_3357  (被调用 1 次) ==== */
static void sub_3357(void) {
    L_3357:; /* 0x3357 */
    for (int i = 1; i >= 0; i--) push32(r[i]);
    r10 = 0x65u;
    r11 = 0;
    CALL(sub_cc5);
    r9 = 0x12fcu;
    r10 = d32(r9);
    r9 = 0x1300u;
    r11 = d32(r9);
    r9 = 0x1304u;
    r12 = d32(r9);
    r1 = 0x1000u;
    CALL(sub_32b9);
    r10 = 0x1u;
    CALL(sub_e3);
    r11 = 0xcu;
    r10 = 0xbu;
    CALL(sub_c4);
    r0 = d32(r1+0xe8);
    r10 = 0x2u;
    CALL(sub_97a);
    r11 = r10 >> 0x8u;
    r0 &= 0xffffu;
    r10 = 0x10u;
    r11 = r11 + r0;
    CALL(sub_c4);
    r9 = 0x660u;
    r13 = d32(r9);
    r12 = 0x630u;
    r10 = 0xcu;
    r11 = 0x2u;
    CALL(sub_7e1);
    r9 = 0x14a4u;
    r9 = d32(r9);
    r10 = 0xbu;
    r11 = r9 + r9;
    r11 = r11 + r9;
    r11 <<= 0x2u;
    CALL(sub_c4);
    r0 = d32(r1+0xec);
    r10 = 0xdu;
    CALL(sub_97a);
    r11 = r10 >> 0x8u;
    r0 &= 0xffffu;
    r10 = 0x10u;
    r11 = r11 + r0;
    CALL(sub_c4);
    r9 = 0x88cu;
    r13 = d32(r9);
    r12 = 0x85cu;
    r10 = 0xfu;
    r11 = 0x2u;
    CALL(sub_7e1);
    r11 = 0x2u;
    r10 = 0xbu;
    CALL(sub_c4);
    r0 = d32(r1+0xe8);
    r10 = 0x1au;
    CALL(sub_97a);
    r11 = r10 >> 0x8u;
    r0 = (r0 >> 16) & 0xffu;
    r10 = 0x10u;
    r11 = r11 + r0;
    CALL(sub_c4);
    r9 = 0x694u;
    r13 = d32(r9);
    r10 = 0x1bu;
    r11 = 0x2u;
    r12 = 0x68cu;
    CALL(sub_7e1);
    CALL(sub_2175);
    r9 = 0x12e0u;
    r10 = d32(r9);
    r9 = 0x12e4u;
    r11 = d32(r9);
    r9 = 0x12e8u;
    r12 = d32(r9);
    CALL(sub_32b9);
    CALL(sub_23fc);
    for (int i = 0; i <= 1; i++) r[i] = pop32();
    return;
}

/* ==== sub_3446  (被调用 1 次) ==== */
static void sub_3446(void) {
    L_3446:; /* 0x3446 */
    for (int i = 0; i >= 0; i--) push32(r[i]);
    r15 = 0x800000u;
    r9 = 0x21400u;
    iowr(r9, r15);
    r9 = 0x130cu;
    r9 = d32(r9);
    if (!(r9 != 0x2u)) {
        L_345e:; /* 0x345e */
        CALL(sub_227c);
        L_3462:; /* 0x3462 */
        r9 = 0x130cu;
        r9 = d32(r9);
        r9 = r9 - 0x1u;
        fc_cmp(r9, 0x1u);
        if (!(!FC(falcon_flags) && !FZ(falcon_flags))) {
            L_3472:; /* 0x3472 */
            r9 = 0x12fcu;
            r10 = d32(r9);
            r9 = 0x1300u;
            r11 = d32(r9);
            r9 = 0x1304u;
            r12 = d32(r9);
            CALL(sub_32b9);
            r10 = 0;
            CALL(sub_e3);
            r9 = 0x1000u;
            r0 = d32(r9+0xe8);
            r10 = 0xfu;
            r0 = (r0 >> 16) & 0xffu;
            r11 = r0;
            CALL(sub_c4);
            r9 = 0x688u;
            r13 = d32(r9);
            r12 = 0x664u;
            r11 = 0x2u;
            r10 = 0x1au;
            CALL(sub_7e1);
            r10 = 0x1au;
            CALL(sub_97a);
            r11 = r10 >> 0x8u;
            r10 = 0xfu;
            r11 = r11 + r0;
            CALL(sub_c4);
            r9 = 0x694u;
            r13 = d32(r9);
            r10 = 0x1bu;
            r11 = 0x2u;
            r12 = 0x68cu;
            CALL(sub_7e1);
            CALL(sub_2175);
            r9 = 0x12e0u;
            r10 = d32(r9);
            r9 = 0x12e4u;
            r11 = d32(r9);
            r9 = 0x12e8u;
            r12 = d32(r9);
            CALL(sub_32b9);
            L_34f0:; /* 0x34f0 */
            r15 = 0x800000u;
            r9 = 0x21a00u;
            iowr(r9, r15);
            for (int i = 0; i <= 0; i++) r[i] = pop32();
            return;
        }
        goto L_34f0;  /* 重复引用 */
    }
    goto L_3462;  /* 重复引用 */
}

/* ==== sub_34fe  (被调用 1 次) ==== */
static void sub_34fe(void) {
    L_34fe:; /* 0x34fe */
    for (int i = 0; i >= 0; i--) push32(r[i]);
    r15 = 0x4000000u;
    r9 = 0x21400u;
    iowr(r9, r15);
    r9 = 0x130cu;
    r9 = d32(r9);
    r9 = r9 - 0x1u;
    fc_cmp(r9, 0x1u);
    if (!(!FC(falcon_flags) && !FZ(falcon_flags))) {
        L_351c:; /* 0x351c */
        r9 = 0x12fcu;
        r10 = d32(r9);
        r9 = 0x1300u;
        r11 = d32(r9);
        r9 = 0x1304u;
        r12 = d32(r9);
        r0 = 0x1000u;
        CALL(sub_32b9);
        r10 = 0x1u;
        CALL(sub_e3);
        r10 = 0xbu;
        r11 = 0x34du;
        CALL(sub_c4);
        r11 = d32(r0+0xe8);
        r10 = 0x10u;
        r11 = (r11 & 0xffffu) | ((u32)0x0u << 16); /* 待复核 */
        CALL(sub_c4);
        r9 = 0x62cu;
        r13 = d32(r9);
        r12 = 0x42cu;
        r10 = 0x2u;
        r11 = r10;
        CALL(sub_7e1);
        r10 = 0xbu;
        r11 = 0x3fu;
        CALL(sub_c4);
        r11 = d32(r0+0xe8);
        r10 = 0x10u;
        r11 = (r11 >> 16) & 0xffu;
        CALL(sub_c4);
        r9 = 0x688u;
        r13 = d32(r9);
        r12 = 0x664u;
        r10 = 0x1au;
        r11 = 0x2u;
        CALL(sub_7e1);
        r9 = 0x14a4u;
        r10 = d32(r9);
        r11 = 0x322u;
        CALL(sub_77ce);
        r9 = 0x14acu;
        r15 = d32(r9);
        r9 = 0x14b0u;
        r14 = d32(r9);
        r9 = r15 + r15;
        r9 = r9 + r15;
        r10 = r10 + r9;
        r10 = r10 + 0x3u;
        r11 = r14 << 0x2u;
        r11 = r11 + r14;
        r11 = r10 + r11;
        r10 = 0xbu;
        CALL(sub_c4);
        r11 = d32(r0+0xec);
        r10 = 0x10u;
        r11 = (r11 & 0xffffu) | ((u32)0x0u << 16); /* 待复核 */
        CALL(sub_c4);
        r9 = 0x848u;
        r13 = d32(r9);
        r10 = 0xdu;
        r11 = 0x1u;
        r12 = 0x698u;
        CALL(sub_7e1);
        r9 = 0x858u;
        r13 = d32(r9);
        r10 = 0xeu;
        r11 = 0x3u;
        r12 = 0x84cu;
        CALL(sub_7e1);
        r9 = 0x8b0u;
        r13 = d32(r9);
        r10 = 0x16u;
        r11 = 0x3u;
        r12 = 0x8a8u;
        CALL(sub_7e1);
        r9 = 0x8c0u;
        r13 = d32(r9);
        r10 = 0x18u;
        r11 = 0x3u;
        r12 = 0x8b4u;
        CALL(sub_7e1);
        r9 = 0x8a4u;
        r13 = d32(r9);
        r10 = 0x17u;
        r11 = 0x4u;
        r12 = 0x890u;
        CALL(sub_7e1);
        CALL(sub_2175);
        r9 = 0x12e0u;
        r10 = d32(r9);
        r9 = 0x12e4u;
        r11 = d32(r9);
        r9 = 0x12e8u;
        r12 = d32(r9);
        CALL(sub_32b9);
        L_363d:; /* 0x363d */
        r15 = 0x4000000u;
        r9 = 0x21a00u;
        iowr(r9, r15);
        for (int i = 0; i <= 0; i++) r[i] = pop32();
        return;
    }
    goto L_363d;  /* 重复引用 */
}

/* ==== sub_364b  (被调用 1 次) ==== */
static void sub_364b(void) {
    L_364b:; /* 0x364b */
    for (int i = 1; i >= 0; i--) push32(r[i]);
    r15 = 0x2000000u;
    r9 = 0x21400u;
    iowr(r9, r15);
    r9 = 0x130cu;
    r9 = d32(r9);
    if (!(r9 != 0x2u)) {
        L_3663:; /* 0x3663 */
        r0 = 0x14a4u;
        r11 = d32(r0);
        r10 = 0x246000u;
        r12 = 0x1u;
        CALL(sub_363);
        r12 = d32(r0);
        r10 = 0x246014u;
        r11 = 0x246010u;
        CALL(sub_2d92);
        r11 = d32(r0);
        r10 = 0x246000u;
        r12 = 0;
        CALL(sub_363);
        r11 = 0x1u;
        r10 = 0x248000u;
        r12 = r11;
        CALL(sub_363);
        r10 = 0x248014u;
        r11 = 0x248010u;
        r12 = 0x1u;
        CALL(sub_2d92);
        r10 = 0x248000u;
        r11 = 0x1u;
        r12 = 0;
        CALL(sub_363);
        L_36b3:; /* 0x36b3 */
        r9 = 0x130cu;
        r9 = d32(r9);
        r9 = r9 - 0x1u;
        fc_cmp(r9, 0x1u);
        if (!(!FC(falcon_flags) && !FZ(falcon_flags))) {
            L_36c3:; /* 0x36c3 */
            CALL(sub_2c19);
            r9 = 0x12fcu;
            r10 = d32(r9);
            r9 = 0x1300u;
            r11 = d32(r9);
            r9 = 0x1304u;
            r12 = d32(r9);
            r1 = 0x1000u;
            CALL(sub_32b9);
            r10 = 0;
            CALL(sub_e3);
            r0 = d32(r1+0xe8);
            r10 = 0xfu;
            r0 &= 0xffffu;
            r11 = r0;
            CALL(sub_c4);
            r9 = 0x62cu;
            r13 = d32(r9);
            r12 = 0x42cu;
            r10 = 0x2u;
            r11 = r10;
            CALL(sub_7e1);
            r10 = 0x2u;
            CALL(sub_97a);
            r11 = r10 >> 0x8u;
            r10 = 0xfu;
            r11 = r11 + r0;
            CALL(sub_c4);
            r9 = 0x660u;
            r13 = d32(r9);
            r12 = 0x630u;
            r10 = 0xcu;
            r11 = 0x2u;
            CALL(sub_7e1);
            r0 = d32(r1+0xec);
            r10 = 0xfu;
            r0 &= 0xffffu;
            r11 = r0;
            CALL(sub_c4);
            r9 = 0x848u;
            r13 = d32(r9);
            r10 = 0xdu;
            r11 = 0x1u;
            r12 = 0x698u;
            CALL(sub_7e1);
            r9 = 0x858u;
            r13 = d32(r9);
            r10 = 0xeu;
            r11 = 0x3u;
            r12 = 0x84cu;
            CALL(sub_7e1);
            r9 = 0x8b0u;
            r13 = d32(r9);
            r10 = 0x16u;
            r11 = 0x3u;
            r12 = 0x8a8u;
            CALL(sub_7e1);
            r9 = 0x8c0u;
            r13 = d32(r9);
            r10 = 0x18u;
            r11 = 0x3u;
            r12 = 0x8b4u;
            CALL(sub_7e1);
            r9 = 0x8a4u;
            r13 = d32(r9);
            r12 = 0x890u;
            r11 = 0x4u;
            r10 = 0x17u;
            CALL(sub_7e1);
            r10 = 0xdu;
            CALL(sub_97a);
            r11 = r10 >> 0x8u;
            r10 = 0xfu;
            r11 = r11 + r0;
            CALL(sub_c4);
            r9 = 0x88cu;
            r13 = d32(r9);
            r10 = 0xfu;
            r11 = 0x2u;
            r12 = 0x85cu;
            CALL(sub_7e1);
            CALL(sub_2175);
            r9 = 0x12e0u;
            r10 = d32(r9);
            r9 = 0x12e4u;
            r11 = d32(r9);
            r9 = 0x12e8u;
            r12 = d32(r9);
            CALL(sub_32b9);
            L_37d3:; /* 0x37d3 */
            r15 = 0x2000000u;
            r9 = 0x21a00u;
            iowr(r9, r15);
            for (int i = 0; i <= 1; i++) r[i] = pop32();
            return;
        }
        goto L_37d3;  /* 重复引用 */
    }
    goto L_36b3;  /* 重复引用 */
}

/* ==== sub_37e1  (被调用 2 次) ==== */
static void sub_37e1(void) {
    L_37e1:; /* 0x37e1 */
    for (int i = 3; i >= 0; i--) push32(r[i]);
    r15 = 0x80000u;
    sp += -0xcu;
    r9 = 0x21400u;
    iowr(r9, r15);
    r15 = 0;
    r9 = r9 + 0x6d00u;
    r3 = iord(r9+r15*0x4);
    r9 = r9 + 0xd00u;
    r2 = iord(r9+r15*0x4);
    r9 = r9 + 0x100u;
    r1 = iord(r9+r15*0x4);
    r13 = 0x2de00u;
    r13 = iord(r13+r15*0x4);
    r9 = 0xe00u;
    r14 = d32(r9+0xcc);
    r12 = d32(r9+0xc8);
    r9 = 0x12ecu;
    r15 = d32(r9);
    r9 = 0x1ffffu;
    r14 &= r9;
    r9 = 0x1464u;
    r12 >>= 0x8u;
    r0 = r14 >> 0x8u;
    r14 <<= 0x18u;
    r10 = r14 | r12;
    s32(r9, r10);
    r9 = 0x1468u;
    r11 = r15 & 0x3fu;
    r13 &= 0x3fu;
    r11 <<= 0x10u;
    r13 <<= 0x18u;
    s32(r9, r0);
    r15 = r15 + 0x40u;
    r9 = 0x146cu;
    r15 &= 0xffu;
    r15 |= r11;
    r12 = r15 | r13;
    s32(r9, r12);
    if (!(r10 == 0x0u)) {
        L_3863:; /* 0x3863 */
        r11 = r0;
        CALL(sub_32b9);
        r9 = 0x2u;
        s32(sp+0x4, r9);
        s32(sp, r9);
        r9 = 0x1u;
        r10 = 0;
        r11 = 0;
        r12 = 0x5u;
        r13 = 0xc00u;
        r14 = 0;
        s32(sp+0x8, r9);
        CALL(sub_2de1);
        r10 = r3;
        r11 = r2;
        r12 = r1;
        CALL(sub_32b9);
        L_3890:; /* 0x3890 */
        r15 = 0x80000u;
        r9 = 0x21a00u;
        iowr(r9, r15);
        sp += 0xcu;
        for (int i = 0; i <= 3; i++) r[i] = pop32();
        return;
    }
    goto L_3890;  /* 重复引用 */
}

/* ==== sub_38a0  (被调用 2 次) ==== */
static void sub_38a0(void) {
    L_38a0:; /* 0x38a0 */
    for (int i = 6; i >= 0; i--) push32(r[i]);
    r15 = 0x40000u;
    sp += -0xcu;
    r9 = 0x21400u;
    iowr(r9, r15);
    r12 = 0;
    r9 = r9 + 0x6d00u;
    r4 = iord(r9+r12*0x4);
    r9 = r9 + 0xd00u;
    r3 = iord(r9+r12*0x4);
    r9 = r9 + 0x100u;
    r2 = iord(r9+r12*0x4);
    r14 = 0x2de00u;
    r14 = iord(r14+r12*0x4);
    r9 = 0x12ecu;
    r1 = 0xe00u;
    r15 = d32(r9);
    r9 = d32(r1+0xcc);
    r13 = d32(r1+0xc8);
    r5 = 0x1ffffu;
    r11 = r15 & 0x3fu;
    r9 &= r5;
    r0 = r9 >> 0x8u;
    r9 <<= 0x18u;
    r13 >>= 0x8u;
    r10 = r9 | r13;
    r9 = 0x1464u;
    s32(r9, r10);
    r9 = 0x1468u;
    r14 &= 0x3fu;
    r11 <<= 0x10u;
    r14 <<= 0x18u;
    r6 = 0x145cu;
    s32(r9, r0);
    s32(r6, r12);
    r15 = r15 + 0x40u;
    r9 = 0x146cu;
    r15 &= 0xffu;
    r15 |= r11;
    r12 = r15 | r14;
    s32(r9, r12);
    if (!(r10 == 0x0u)) {
        L_3928:; /* 0x3928 */
        r11 = r0;
        CALL(sub_32b9);
        r9 = 0x2u;
        s32(sp+0x8, r9);
        s32(sp, r9);
        r9 = 0x1u;
        r13 = 0xc00u;
        r14 = 0;
        s32(sp+0x4, r9);
        r10 = 0;
        r11 = 0;
        r12 = 0x5u;
        CALL(sub_2de1);
        r10 = r4;
        r11 = r3;
        r12 = r2;
        CALL(sub_32b9);
        r15 = 0xc00u;
        r15 = d32(r15+0x30);
        r9 = 0x1480u;
        r13 = d32(r1);
        s32(r9, r15);
        r9 = d32(r1+0xe8);
        r13 >>= 0x8u;
        r15 = 0x1460u;
        r9 &= r5;
        r14 = r9 >> 0x8u;
        r9 <<= 0x18u;
        s32(r15, r14);
        r9 |= r13;
        s32(r6, r9);
        L_397e:; /* 0x397e */
        r15 = 0x40000u;
        r9 = 0x21a00u;
        iowr(r9, r15);
        sp += 0xcu;
        for (int i = 0; i <= 6; i++) r[i] = pop32();
        return;
    }
    goto L_397e;  /* 重复引用 */
}

/* ==== sub_398e  (被调用 3 次) ==== */
static void sub_398e(void) {
    L_398e:; /* 0x398e */
    for (int i = 7; i >= 0; i--) push32(r[i]);
    r9 = 0x80000000u;
    sp += -0xcu;
    r2 = r10;
    r15 = 0x21200u;
    iowr(r15, r9);
    r9 = 0x13f0u;
    r12 = d32(r9);
    if (!(r12 == 0x0u)) {
        L_39ab:; /* 0x39ab */
        r15 = 0x80000000u;
        r9 = 0x21800u;
        iowr(r9, r15);
        r10 = 0;
        goto L_3b57;
        L_39bd:; /* 0x39bd */
        r13 = 0xe00u;
        r9 = 0xffffffu;
        r15 = d32(r13+0xa0);
        fc_cmp(r10, r9);
        if (!(FC(falcon_flags) || FZ(falcon_flags))) {
            L_39ce:; /* 0x39ce */
            r15 = 0x80000000u;
            r9 = 0x21800u;
            iowr(r9, r15);
            r15 = 0x1u;
            r9 = r9 - 0xa00u;
            iowr(r9, r15);
            r9 = r9 + 0x100u;
            iowr(r9, r10);
            r10 = 0x1u;
            goto L_3b57;
            L_39f2:; /* 0x39f2 */
            r9 = r15 & 0x3u;
            if (!(r9 == 0x1u)) {
                L_39fa:; /* 0x39fa */
                fc_cmp(r9, 0x1u);
                if (!FC(falcon_flags)) {
                    L_3a01:; /* 0x3a01 */
                    if (!(r9 != 0x2u)) {
                        L_3a06:; /* 0x3a06 */
                        r9 = 0x28100u;
                        r7 = iord(r9+r12*0x4);
                        r9 = r9 + 0xd00u;
                        r6 = iord(r9+r12*0x4);
                        r9 = r9 + 0x100u;
                        r5 = iord(r9+r12*0x4);
                        r15 = d32(r13+0xa4);
                        r14 = d32(r13+0xa8);
                        r0 = (r10 >> 5) & 0xffu;
                        r1 = r10 >> 0xdu;
                        r9 = r15 & 0xffu;
                        r14 <<= 0x18u;
                        r15 >>= 0x8u;
                        r14 |= r15;
                        r0 = r0 + r9;
                        r1 = r1 + r14;
                        CALL(sub_31cf);
                        r9 = 0x12ecu;
                        r9 = d32(r9);
                        r10 = r0 >> 0x8u;
                        r11 = 0;
                        r10 = r1 + r10;
                        r12 = r9 + 0x40u;
                        r9 &= 0x3fu;
                        r9 <<= 0x10u;
                        r12 &= 0xffu;
                        r12 = r9 | r12;
                        CALL(sub_32b9);
                        r3 = r0 & 0xffu;
                        r9 = r3 >> 0x1u;
                        r9 |= r3;
                        r4 = r2 >> 0x2u;
                        r15 = r9 >> 0x2u;
                        r15 |= r9;
                        r9 = r15 >> 0x4u;
                        r9 |= r15;
                        r12 = r9 + 0x1u;
                        if (!(r12 == 0x10u)) {
                            L_3a7f:; /* 0x3a7f */
                            fc_cmp(r12, 0x10u);
                            if (!(!FC(falcon_flags) && !FZ(falcon_flags))) {
                                L_3a85:; /* 0x3a85 */
                                if (!(r12 == 0x4u)) {
                                    L_3a89:; /* 0x3a89 */
                                    fc_cmp(r12, 0x4u);
                                    if (!(!FC(falcon_flags) && !FZ(falcon_flags))) {
                                        L_3a8f:; /* 0x3a8f */
                                        fc_cmp(r9, 0x1u);
                                        if (!(!FC(falcon_flags) && !FZ(falcon_flags))) {
                                            L_3a95:; /* 0x3a95 */
                                            goto L_3ac2;
                                            L_3a99:; /* 0x3a99 */
                                            if (!(r12 != 0x8u)) {
                                                L_3a9d:; /* 0x3a9d */
                                                goto L_3ac2;
                                                L_3aa1:; /* 0x3aa1 */
                                                if (!(r12 == 0x40u)) {
                                                    L_3aa5:; /* 0x3aa5 */
                                                    fc_cmp(r12, 0x40u);
                                                    if (!(!FC(falcon_flags) && !FZ(falcon_flags))) {
                                                        L_3aac:; /* 0x3aac */
                                                        if (!(r12 != 0x20u)) {
                                                            L_3ab0:; /* 0x3ab0 */
                                                            goto L_3ac2;
                                                            L_3ab4:; /* 0x3ab4 */
                                                            if (!(r12 == 0x80u)) {
                                                                L_3ab9:; /* 0x3ab9 */
                                                                if (!(r12 != 0x100u)) {
                                                                    L_3abe:; /* 0x3abe */
                                                                    goto L_3ad4;
                                                                    L_3ac2:; /* 0x3ac2 */
                                                                    r12 = 0x3u;
                                                                    goto L_3ad6;
                                                                    L_3ac8:; /* 0x3ac8 */
                                                                    r12 = 0x4u;
                                                                    goto L_3ad6;
                                                                    L_3ace:; /* 0x3ace */
                                                                    r12 = 0x5u;
                                                                    goto L_3ad6;
                                                                    L_3ad4:; /* 0x3ad4 */
                                                                    r12 = 0x6u;
                                                                    L_3ad6:; /* 0x3ad6 */
                                                                    r13 = 0xa00u;
                                                                    r14 = 0;
                                                                    r1 = 0x2u;
                                                                    r0 = 0x1u;
                                                                    r10 = 0;
                                                                    s32(sp+0x4, r0);
                                                                    r11 = r3;
                                                                    s32(sp, r1);
                                                                    s32(sp+0x8, r1);
                                                                    CALL(sub_2de1);
                                                                    r10 = r7;
                                                                    r11 = r6;
                                                                    r12 = r5;
                                                                    CALL(sub_32b9);
                                                                    r15 = 0xa00u;
                                                                    r9 = r3 & 0xfcu;
                                                                    r9 = r9 + r15;
                                                                    r15 = d32(r9);
                                                                    r9 = r4 & 0x1fu;
                                                                    r0 <<= r9;
                                                                    r0 &= r15;
                                                                    if (!!FZ(falcon_flags)) {
                                                                        L_3b13:; /* 0x3b13 */
                                                                        r9 = 0x20e00u;
                                                                        iowr(r9, r1);
                                                                        goto L_3b31;
                                                                        L_3b1e:; /* 0x3b1e */
                                                                        r15 = 0x2u;
                                                                        r9 = 0x20600u;
                                                                        iowr(r9, r15);
                                                                        r15 = 0x3u;
                                                                        r9 = r9 + 0x800u;
                                                                        iowr(r9, r15);
                                                                        L_3b31:; /* 0x3b31 */
                                                                        r9 = r9 + 0x100u;
                                                                        iowr(r9, r2);
                                                                        goto L_3b43;
                                                                        L_3b3d:; /* 0x3b3d */
                                                                        r10 = 0x46u;
                                                                        CALL(sub_5c0);
                                                                        L_3b43:; /* 0x3b43 */
                                                                        r10 = 0x1u;
                                                                        goto L_3b4b;
                                                                        L_3b49:; /* 0x3b49 */
                                                                        r10 = 0;
                                                                        L_3b4b:; /* 0x3b4b */
                                                                        r15 = 0x80000000u;
                                                                        r9 = 0x21800u;
                                                                        iowr(r9, r15);
                                                                        L_3b57:; /* 0x3b57 */
                                                                        sp += 0xcu;
                                                                        for (int i = 0; i <= 7; i++) r[i] = pop32();
                                                                        return;
                                                                    }
                                                                    goto L_3b49;  /* 重复引用 */
                                                                    goto L_3ad4;  /* 重复引用 */
                                                                }
                                                                goto L_3ad6;  /* 重复引用 */
                                                                goto L_3abe;  /* 重复引用 */
                                                                goto L_3ad4;  /* 重复引用 */
                                                            }
                                                            goto L_3ace;  /* 重复引用 */
                                                        }
                                                        goto L_3ad6;  /* 重复引用 */
                                                        goto L_3ab0;  /* 重复引用 */
                                                    }
                                                    goto L_3ab4;  /* 重复引用 */
                                                    goto L_3aac;  /* 重复引用 */
                                                    goto L_3ab0;  /* 重复引用 */
                                                    goto L_3ab4;  /* 重复引用 */
                                                    goto L_3ab9;  /* 重复引用 */
                                                    goto L_3abe;  /* 重复引用 */
                                                    goto L_3ace;  /* 重复引用 */
                                                    goto L_3ad4;  /* 重复引用 */
                                                }
                                                goto L_3ac8;  /* 重复引用 */
                                            }
                                            goto L_3ad6;  /* 重复引用 */
                                        }
                                        goto L_3ad6;  /* 重复引用 */
                                        goto L_3a95;  /* 重复引用 */
                                    }
                                    goto L_3a99;  /* 重复引用 */
                                    goto L_3a8f;  /* 重复引用 */
                                    goto L_3a95;  /* 重复引用 */
                                    goto L_3a99;  /* 重复引用 */
                                    goto L_3a9d;  /* 重复引用 */
                                }
                                goto L_3ac2;  /* 重复引用 */
                                goto L_3a89;  /* 重复引用 */
                                goto L_3a8f;  /* 重复引用 */
                                goto L_3a95;  /* 重复引用 */
                                goto L_3a99;  /* 重复引用 */
                                goto L_3a9d;  /* 重复引用 */
                            }
                            goto L_3aa1;  /* 重复引用 */
                            goto L_3a85;  /* 重复引用 */
                            goto L_3a89;  /* 重复引用 */
                            goto L_3a8f;  /* 重复引用 */
                            goto L_3a95;  /* 重复引用 */
                            goto L_3a99;  /* 重复引用 */
                            goto L_3a9d;  /* 重复引用 */
                            goto L_3aa1;  /* 重复引用 */
                            goto L_3aa5;  /* 重复引用 */
                            goto L_3aac;  /* 重复引用 */
                            goto L_3ab0;  /* 重复引用 */
                            goto L_3ab4;  /* 重复引用 */
                            goto L_3ab9;  /* 重复引用 */
                            goto L_3abe;  /* 重复引用 */
                            goto L_3ac8;  /* 重复引用 */
                            goto L_3ace;  /* 重复引用 */
                            goto L_3ad4;  /* 重复引用 */
                        }
                        goto L_3ac2;  /* 重复引用 */
                        goto L_3a7f;  /* 重复引用 */
                        goto L_3a85;  /* 重复引用 */
                        goto L_3a89;  /* 重复引用 */
                        goto L_3a8f;  /* 重复引用 */
                        goto L_3a95;  /* 重复引用 */
                        goto L_3a99;  /* 重复引用 */
                        goto L_3a9d;  /* 重复引用 */
                        goto L_3aa1;  /* 重复引用 */
                        goto L_3aa5;  /* 重复引用 */
                        goto L_3aac;  /* 重复引用 */
                        goto L_3ab0;  /* 重复引用 */
                        goto L_3ab4;  /* 重复引用 */
                        goto L_3ab9;  /* 重复引用 */
                        goto L_3abe;  /* 重复引用 */
                        goto L_3ac2;  /* 重复引用 */
                        goto L_3ac8;  /* 重复引用 */
                        goto L_3ace;  /* 重复引用 */
                        goto L_3ad4;  /* 重复引用 */
                        goto L_3ad6;  /* 重复引用 */
                        goto L_3b13;  /* 重复引用 */
                    }
                    goto L_3b3d;  /* 重复引用 */
                    goto L_3a06;  /* 重复引用 */
                    goto L_3a7f;  /* 重复引用 */
                    goto L_3a85;  /* 重复引用 */
                    goto L_3a89;  /* 重复引用 */
                    goto L_3a8f;  /* 重复引用 */
                    goto L_3a95;  /* 重复引用 */
                    goto L_3a99;  /* 重复引用 */
                    goto L_3a9d;  /* 重复引用 */
                    goto L_3aa1;  /* 重复引用 */
                    goto L_3aa5;  /* 重复引用 */
                    goto L_3aac;  /* 重复引用 */
                    goto L_3ab0;  /* 重复引用 */
                    goto L_3ab4;  /* 重复引用 */
                    goto L_3ab9;  /* 重复引用 */
                    goto L_3abe;  /* 重复引用 */
                    goto L_3ac2;  /* 重复引用 */
                    goto L_3ac8;  /* 重复引用 */
                    goto L_3ace;  /* 重复引用 */
                    goto L_3ad4;  /* 重复引用 */
                    goto L_3ad6;  /* 重复引用 */
                    goto L_3b13;  /* 重复引用 */
                    goto L_3b3d;  /* 重复引用 */
                }
                goto L_3b49;  /* 重复引用 */
                goto L_3a01;  /* 重复引用 */
                goto L_3a06;  /* 重复引用 */
                goto L_3a7f;  /* 重复引用 */
                goto L_3a85;  /* 重复引用 */
                goto L_3a89;  /* 重复引用 */
                goto L_3a8f;  /* 重复引用 */
                goto L_3a95;  /* 重复引用 */
                goto L_3a99;  /* 重复引用 */
                goto L_3a9d;  /* 重复引用 */
                goto L_3aa1;  /* 重复引用 */
                goto L_3aa5;  /* 重复引用 */
                goto L_3aac;  /* 重复引用 */
                goto L_3ab0;  /* 重复引用 */
                goto L_3ab4;  /* 重复引用 */
                goto L_3ab9;  /* 重复引用 */
                goto L_3abe;  /* 重复引用 */
                goto L_3ac2;  /* 重复引用 */
                goto L_3ac8;  /* 重复引用 */
                goto L_3ace;  /* 重复引用 */
                goto L_3ad4;  /* 重复引用 */
                goto L_3ad6;  /* 重复引用 */
                goto L_3b13;  /* 重复引用 */
                goto L_3b3d;  /* 重复引用 */
                goto L_3b49;  /* 重复引用 */
            }
            goto L_3b1e;  /* 重复引用 */
        }
        goto L_39f2;  /* 重复引用 */
    }
    goto L_39bd;  /* 重复引用 */
}

/* ==== sub_3b5c  (被调用 2 次) ==== */
static void sub_3b5c(void) {
    L_3b5c:; /* 0x3b5c */
    for (int i = 3; i >= 0; i--) push32(r[i]);
    r9 = 0x24u;
    r3 = r10;
    r10 = d32(r9);
    r0 = r12;
    r1 = r11;
    CALL(sub_114);
    if (!(r0 != 0x0u)) {
        L_3b72:; /* 0x3b72 */
        r10 = 0x6u;
        CALL(sub_791);
        goto L_3bde;
        L_3b7c:; /* 0x3b7c */
        r10 = 0x7u;
        CALL(sub_791);
        if (!(r0 != 0x1u)) {
            L_3b86:; /* 0x3b86 */
            r9 = 0x13f8u;
            r11 = d32(r9);
            r10 = 0x4188acu;
            CALL(sub_237);
            r9 = 0x13fcu;
            r11 = d32(r9);
            r10 = 0x418880u;
            CALL(sub_237);
            r9 = 0x1400u;
            r11 = d32(r9);
            r10 = 0x418898u;
            CALL(sub_237);
            r9 = 0x1404u;
            r11 = d32(r9);
            r10 = 0x41889cu;
            CALL(sub_237);
            r9 = 0x1408u;
            r11 = d32(r9);
            r10 = 0x4188a0u;
            CALL(sub_237);
            r9 = 0x140cu;
            r11 = d32(r9);
            r10 = 0x4188bcu;
            CALL(sub_237);
            goto L_3c32;
            L_3bde:; /* 0x3bde */
            r10 = 0x4188acu;
            CALL(sub_297);
            r9 = 0x13f8u;
            s32(r9, r10);
            r10 = 0x418880u;
            CALL(sub_297);
            r9 = 0x13fcu;
            s32(r9, r10);
            r10 = 0x418898u;
            CALL(sub_297);
            r9 = 0x1400u;
            s32(r9, r10);
            r10 = 0x41889cu;
            CALL(sub_297);
            r9 = 0x1404u;
            s32(r9, r10);
            r10 = 0x4188a0u;
            CALL(sub_297);
            r9 = 0x1408u;
            s32(r9, r10);
            r10 = 0x4188bcu;
            CALL(sub_297);
            r9 = 0x140cu;
            s32(r9, r10);
            L_3c32:; /* 0x3c32 */
            r10 = 0x404154u;
            CALL(sub_297);
            r11 = 0;
            r2 = r10;
            r10 = 0x404154u;
            CALL(sub_237);
            CALL(sub_31cf);
            r10 = 0x28e00u;
            r11 = 0;
            CALL(sub_10);
            r10 = 0x28f00u;
            r11 = 0x40u;
            CALL(sub_10);
            r10 = 0x28900u;
            r11 = 0;
            CALL(sub_10);
            r9 = 0x1610u;
            r11 = d32(r9);
            r10 = 0x28300u;
            CALL(sub_10);
            r10 = 0x28400u;
            r11 = 0x7u;
            CALL(sub_10);
            CALL(sub_31cf);
            r10 = r3;
            r11 = r1;
            CALL(sub_cc5);
            r9 = 0x1614u;
            r10 = d32(r9);
            r12 = 0x40u;
            r11 = 0;
            CALL(sub_32b9);
            r10 = r0;
            CALL(sub_e3);
            r10 = 0xfu;
            r11 = 0;
            CALL(sub_c4);
            r10 = 0x10u;
            r11 = 0;
            CALL(sub_c4);
            r9 = r1 - 0x1u;
            fc_cmp(r9, 0x1u);
            if (!(!FC(falcon_flags) && !FZ(falcon_flags))) {
                L_3cb9:; /* 0x3cb9 */
                if (!(r0 != 0x1u)) {
                    L_3cbd:; /* 0x3cbd */
                    r10 = 0xbu;
                    r11 = 0x88u;
                    CALL(sub_c4);
                    L_3cc6:; /* 0x3cc6 */
                    r9 = 0x9e0u;
                    r13 = d32(r9);
                    r10 = 0x1u;
                    r12 = 0x8c4u;
                    r11 = r10;
                    CALL(sub_7e1);
                    r9 = 0x9e4u;
                    r13 = d32(r9);
                    r10 = 0x1u;
                    r11 = 0x4u;
                    r12 = 0x944u;
                    CALL(sub_7e1);
                    L_3cea:; /* 0x3cea */
                    CALL(sub_2175);
                    CALL(sub_23fc);
                    r10 = 0x1u;
                    CALL(sub_791);
                    CALL(sub_31cf);
                    r10 = 0x28400u;
                    r11 = 0x5u;
                    CALL(sub_10);
                    CALL(sub_31cf);
                    r11 = r2;
                    r10 = 0x404154u;
                    CALL(sub_237);
                    CALL(sub_31cf);
                    r15 = 0x1u;
                    r9 = 0x20000u;
                    iowr(r9, r15);
                    r15 = 0;
                    r9 = 0x10c00u;
                    iowr(r9, r15);
                    for (int i = 0; i <= 3; i++) r[i] = pop32();
                    return;
                }
                goto L_3cc6;  /* 重复引用 */
                goto L_3cbd;  /* 重复引用 */
                goto L_3cc6;  /* 重复引用 */
            }
            goto L_3cea;  /* 重复引用 */
        }
        goto L_3bde;  /* 重复引用 */
    }
    goto L_3b7c;  /* 重复引用 */
}

/* ==== sub_3d2c  (被调用 1 次) ==== */
static void sub_3d2c(void) {
    L_3d2c:; /* 0x3d2c */
    r15 = 0x4000000u;
    r9 = 0x21200u;
    iowr(r9, r15);
    r12 = 0;
    CALL(sub_3b5c);
    r15 = 0x4000000u;
    r9 = 0x21800u;
    iowr(r9, r15);
    return;
}

/* ==== sub_3d4c  (被调用 1 次) ==== */
static void sub_3d4c(void) {
    L_3d4c:; /* 0x3d4c */
    for (int i = 1; i >= 0; i--) push32(r[i]);
    r15 = 0x8000000u;
    r1 = r10;
    r0 = r11;
    r9 = 0x21200u;
    iowr(r9, r15);
    if (!(r11 != 0x2u)) {
        L_3d62:; /* 0x3d62 */
        CALL(sub_2b53);
        L_3d66:; /* 0x3d66 */
        r10 = r1;
        r11 = r0;
        r12 = 0x1u;
        CALL(sub_3b5c);
        r15 = 0x8000000u;
        r9 = 0x21800u;
        iowr(r9, r15);
        for (int i = 0; i <= 1; i++) r[i] = pop32();
        return;
    }
    goto L_3d66;  /* 重复引用 */
}

/* ==== sub_3d7e  (被调用 2 次) ==== */
static void sub_3d7e(void) {
    L_3d7e:; /* 0x3d7e */
    for (int i = 2; i >= 0; i--) push32(r[i]);
    r15 = 0x4000u;
    r9 = 0x21400u;
    iowr(r9, r15);
    CALL(sub_31cf);
    r9 = 0;
    r2 = 0x28100u;
    r2 = iord(r2+r9*0x4);
    r1 = 0x28e00u;
    r1 = iord(r1+r9*0x4);
    r0 = 0x28f00u;
    r0 = iord(r0+r9*0x4);
    r9 = 0x12e0u;
    r10 = d32(r9);
    r9 = 0x12e4u;
    r11 = d32(r9);
    r9 = 0x12e8u;
    r12 = d32(r9);
    CALL(sub_32b9);
    CALL(sub_31cf);
    r10 = 0x28400u;
    r11 = 0x205u;
    CALL(sub_10);
    CALL(sub_31cf);
    r10 = r2;
    r11 = r1;
    r12 = r0;
    CALL(sub_32b9);
    r15 = 0x4000u;
    r9 = 0x21a00u;
    iowr(r9, r15);
    for (int i = 0; i <= 2; i++) r[i] = pop32();
    return;
}

/* ==== sub_3de4  (被调用 1 次) ==== */
static void sub_3de4(void) {
    L_3de4:; /* 0x3de4 */
    for (int i = 8; i >= 0; i--) push32(r[i]);
    r15 = 0x100000u;
    r9 = 0x21300u;
    iowr(r9, r15);
    r15 = 0x200000u;
    iowr(r9, r15);
    r14 = sp;
    r9 = r9 + 0x600u;
    iowr(r9, r15);
    r9 = 0x13d0u;
    r10 = d32(r9);
    r9 = 0x13d4u;
    r11 = d32(r9);
    r14 = r14 - 0x200u;
    r9 = -0x200u;
    r12 = 0xc0u;
    r4 = r14 & r9;
    CALL(sub_32b9);
    r5 = r4 + 0x100u;
    r15 = 0x1111u;
    r9 = 0x20700u;
    iowr(r9, r15);
    r9 = 0x13ccu;
    r15 = d32(r9);
    r9 = 0x20700u;
    iowr(r9, r15);
    r9 = 0x13d0u;
    r15 = d32(r9);
    r9 = 0x20700u;
    iowr(r9, r15);
    r9 = 0x13d4u;
    r15 = d32(r9);
    r9 = 0x20700u;
    iowr(r9, r15);
    r9 = 0x13d8u;
    r15 = d32(r9);
    r9 = 0x20700u;
    iowr(r9, r15);
    r9 = 0x13dcu;
    r15 = d32(r9);
    r9 = 0x20700u;
    iowr(r9, r15);
    r15 = 0;
    r9 = r9 - 0x7a00u;
    iowr(r9, r15);
    r15 = 0x1112u;
    r9 = r9 + 0x7a00u;
    iowr(r9, r15);
    r9 = 0x100u;
    sr_xtargets = r9;
    r9 = 0;
    sr_xdbase = r9;
    r14 = 0x60000u;
    r15 = r4 | r14;
    r9 = xdld(r15);
    UNKNOWN("xdwait"); /* FIXME */
    r3 = 0;
    r10 = r5;
    r15 = 0;
    r8 = 0x13ccu;
    r7 = 0;
    r6 = 0;
    goto L_3fac;
    L_3eaf:; /* 0x3eaf */
    r2 = r15 + 0x100u;
    fc_cmp(r2, r9);
    if (!!FC(falcon_flags)) {
        L_3eb9:; /* 0x3eb9 */
        r11 = 0x60000u;
        r9 = r10 | r11;
        r2 = xdld(r9);
        L_3ec3:; /* 0x3ec3 */
        if (!(r3 != 0x0u)) {
            L_3ec7:; /* 0x3ec7 */
            r10 = r4;
            goto L_3ecf;
            L_3ecd:; /* 0x3ecd */
            r10 = r5;
            L_3ecf:; /* 0x3ecf */
            r9 = d32(r8);
            r0 = r9 - r15;
            fc_cmp(r0, 0xffu);
            if (!(!FC(falcon_flags) && !FZ(falcon_flags))) {
                L_3edc:; /* 0x3edc */
                r9 = ~r0;
                r11 = r10 + r0;
                r12 = r9 + 0x101u;
                r9 = (u32)(-(int32_t)r11);
                r9 &= 0x3u;
                fc_cmp(r9, r12);
                if (!(FC(falcon_flags) || FZ(falcon_flags))) {
                    L_3ef2:; /* 0x3ef2 */
                    r9 = r12;
                    L_3ef4:; /* 0x3ef4 */
                    if (!(r9 != 0x0u)) {
                        L_3ef8:; /* 0x3ef8 */
                        r13 = r0;
                        goto L_3f15;
                        L_3efe:; /* 0x3efe */
                        r13 = r0;
                        r15 = 0;
                        L_3f02:; /* 0x3f02 */
                        s32(r11+r15, r6);
                        r13 = r13 + 0x1u;
                        r15 = r15 + 0x1u;
                        fc_cmp(r15, r9);
                        if (!FC(falcon_flags)) {
                            L_3f10:; /* 0x3f10 */
                            fc_cmp(r9, r12);
                            if (FZ(falcon_flags)) goto L_3f4b;
                            L_3f15:; /* 0x3f15 */
                            r1 = r12 - r9;
                            r14 = r1 >> 0x2u;
                            r12 = r14 << 0x2u;
                            if (!FZ(falcon_flags)) {
                                L_3f21:; /* 0x3f21 */
                                r9 = r11 + r9;
                                r15 = 0;
                                L_3f26:; /* 0x3f26 */
                                s32(r9, r7);
                                r15 = r15 + 0x1u;
                                r9 = r9 + 0x4u;
                                fc_cmp(r15, r14);
                                if (!FC(falcon_flags)) {
                                    L_3f33:; /* 0x3f33 */
                                    r13 = r13 + r12;
                                    fc_cmp(r12, r1);
                                    if (FZ(falcon_flags)) goto L_3f4b;
                                    L_3f3b:; /* 0x3f3b */
                                    r9 = r10 + r13;
                                    L_3f3e:; /* 0x3f3e */
                                    s32(r9, r6);
                                    r13 = r13 + 0x1u;
                                    r9 = r9 + 0x1u;
                                    if ((r13 != 0x100u)) goto L_3f3e;
                                    L_3f4b:; /* 0x3f4b */
                                    r9 = r0 + 0x3u;
                                    r15 = r10;
                                    r9 >>= 0x2u;
                                    r9 <<= 0x2u;
                                    r13 = r10 + r9;
                                    goto L_3f69;
                                    L_3f5d:; /* 0x3f5d */
                                    r9 = d32(r15);
                                    r14 = 0x18c00u;
                                    iowr(r14, r9);
                                    r15 = r15 + 0x4u;
                                    L_3f69:; /* 0x3f69 */
                                    fc_cmp(r15, r13);
                                    if (!!FZ(falcon_flags)) {
                                        L_3f6e:; /* 0x3f6e */
                                        goto L_3fa5;
                                        L_3f72:; /* 0x3f72 */
                                        r9 = -0x7400u;
                                        r9 = (r9 & 0xffffu) | ((u32)0x10000u << 16); /* 待复核 */
                                        r13 = 0x40u;
                                        r15 = r7;
                                        r12 = r10;
                                        r11 = r7;
                                        r14 = r7;
                                        L_3f82:; /* 0x3f82 */
                                        r11 = d32(r12);
                                        r14 = d32(r12+0x4);
                                        r15 = r15 + 0x4u;
                                        iowr(r9, r11);
                                        r11 = d32(r12+0x8);
                                        iowr(r9, r14);
                                        r14 = d32(r12+0xc);
                                        r12 = r12 + 0x10u;
                                        iowr(r9, r11);
                                        fc_cmp(r15, r13);
                                        iowr(r9, r14);
                                        if (FC(falcon_flags)) goto L_3f82;
                                        L_3fa5:; /* 0x3fa5 */
                                        r3 ^= 0x1u;
                                        UNKNOWN("xdwait"); /* FIXME */
                                        r15 = r2;
                                        L_3fac:; /* 0x3fac */
                                        r9 = d32(r8);
                                        fc_cmp(r15, r9);
                                        if (!FC(falcon_flags)) {
                                            L_3fb4:; /* 0x3fb4 */
                                            r9 = 0;
                                            r0 = 0x18d00u;
                                            r0 = iord(r0+r9*0x4);
                                            r9 = 0x20700u;
                                            iowr(r9, r0);
                                            r9 = 0x13d8u;
                                            r10 = d32(r9);
                                            r9 = 0x13dcu;
                                            r11 = d32(r9);
                                            r12 = 0xc0u;
                                            CALL(sub_32b9);
                                            r9 = 0x2000u;
                                            sr_xtargets = r9;
                                            r9 = 0;
                                            sr_xdbase = r9;
                                            r15 = 0x2222u;
                                            r9 = 0x20700u;
                                            iowr(r9, r15);
                                            r9 = 0;
                                            s32(r4, r0);
                                            xdst(r9, r4);
                                            UNKNOWN("xdwait"); /* FIXME */
                                            CALL(sub_31cf);
                                            r15 = 0x1u;
                                            r9 = 0x20000u;
                                            iowr(r9, r15);
                                            r15 = 0x100000u;
                                            r9 = r9 + 0x1900u;
                                            iowr(r9, r15);
                                            for (int i = 0; i <= 8; i++) r[i] = pop32();
                                            return;
                                        }
                                        goto L_3eaf;  /* 重复引用 */
                                    }
                                    goto L_3f5d;  /* 重复引用 */
                                }
                                goto L_3f26;  /* 重复引用 */
                                goto L_3f26;  /* 重复引用 */
                                goto L_3f33;  /* 重复引用 */
                            }
                            goto L_3f3b;  /* 重复引用 */
                        }
                        goto L_3f02;  /* 重复引用 */
                    }
                    goto L_3efe;  /* 重复引用 */
                }
                goto L_3ef4;  /* 重复引用 */
                goto L_3ef2;  /* 重复引用 */
                goto L_3ef4;  /* 重复引用 */
                goto L_3ef8;  /* 重复引用 */
                goto L_3efe;  /* 重复引用 */
                goto L_3f02;  /* 重复引用 */
                goto L_3f10;  /* 重复引用 */
                goto L_3f15;  /* 重复引用 */
                goto L_3f21;  /* 重复引用 */
                goto L_3f26;  /* 重复引用 */
                goto L_3f33;  /* 重复引用 */
                goto L_3f3b;  /* 重复引用 */
                goto L_3f3e;  /* 重复引用 */
                goto L_3f4b;  /* 重复引用 */
                goto L_3f5d;  /* 重复引用 */
                goto L_3f69;  /* 重复引用 */
                goto L_3f6e;  /* 重复引用 */
            }
            goto L_3f72;  /* 重复引用 */
        }
        goto L_3ecd;  /* 重复引用 */
    }
    goto L_3ec3;  /* 重复引用 */
}

/* ==== sub_4010  (被调用 2 次) ==== */
static void sub_4010(void) {
    L_4010:; /* 0x4010 */
    for (int i = 1; i >= 0; i--) push32(r[i]);
    r15 = 0x4u;
    r9 = 0x21500u;
    iowr(r9, r15);
    r1 = 0x10000u;
    r0 = 0;
    goto L_4029;
    L_4025:; /* 0x4025 */
    CALL(sub_215e);
    L_4029:; /* 0x4029 */
    r9 = iord(r1+r0*0x4);
    r9 &= 0x10u;
    if (!FZ(falcon_flags)) {
        L_4032:; /* 0x4032 */
        r15 = 0x4u;
        r9 = 0x21b00u;
        iowr(r9, r15);
        for (int i = 0; i <= 1; i++) r[i] = pop32();
        return;
    }
    goto L_4025;  /* 重复引用 */
}

/* ==== sub_403d  (被调用 1 次) ==== */
static void sub_403d(void) {
    L_403d:; /* 0x403d */
    for (int i = 1; i >= 0; i--) push32(r[i]);
    r15 = 0x4000u;
    r0 = r11;
    r9 = 0x21200u;
    iowr(r9, r15);
    r9 = 0x12c4u;
    r9 = d32(r9);
    if (!(r9 != 0x1u)) {
        L_4055:; /* 0x4055 */
        r9 = 0x21800u;
        iowr(r9, r15);
        r1 = 0x64u;
        goto L_419c;
        L_4062:; /* 0x4062 */
        r10 = 0x400144u;
        r11 = 0x100u;
        CALL(sub_237);
        r11 = 0;
        r10 = 0x4u;
        CALL(sub_cc5);
        r10 = 0x1u;
        CALL(sub_29c6);
        r10 = 0x409614u;
        r11 = 0x115u;
        CALL(sub_237);
        r10 = 0x41a614u;
        r11 = 0xa26u;
        CALL(sub_237);
        CALL(sub_c9d);
        r15 = 0;
        r9 = 0x22300u;
        r9 = iord(r9+r15*0x4);
        r9 &= 0x10u;
        if (!FZ(falcon_flags)) {
            L_40a4:; /* 0x40a4 */
            r1 = 0;
            goto L_40d9;
            L_40aa:; /* 0x40aa */
            r15 = 0x8u;
            r9 = 0x30200u;
            iowr(r9, r15);
            r1 = 0;
            r14 = 0x30000u;
            r15 = 0;
            goto L_40c2;
            L_40bf:; /* 0x40bf */
            r1 = r1 + 0x1u;
            L_40c2:; /* 0x40c2 */
            r9 = iord(r14+r15*0x4);
            r9 &= 0x8000u;
            if (!(r9 == 0x0u)) {
                goto L_40bf;  /* 重复引用 */
                L_40cd:; /* 0x40cd */
                fc_cmp(r1, r0);
                if (!FC(falcon_flags)) {
                    L_40d2:; /* 0x40d2 */
                    goto L_40f3;
                    L_40d6:; /* 0x40d6 */
                    r1 = r1 + 0x1u;
                    L_40d9:; /* 0x40d9 */
                    r10 = 0x400384u;
                    CALL(sub_297);
                    r10 = (r10 >> 12) & 0x7u;
                    if (!(r10 != 0x7u)) {
                        L_40e8:; /* 0x40e8 */
                        goto L_40f3;
                        L_40ec:; /* 0x40ec */
                        r1 = r1 + 0x1u;
                        goto L_40f9;
                        L_40f3:; /* 0x40f3 */
                        r14 = 0x10000u;
                        r15 = 0;
                        L_40f9:; /* 0x40f9 */
                        r9 = iord(r14+r15*0x4);
                        r9 &= 0x200u;
                        if (FZ(falcon_flags)) goto L_4123;
                        L_4103:; /* 0x4103 */
                        r9 = 0x12d4u;
                        r10 = d32(r9);
                        r0 = r9;
                        r9 = 0x402e8u;
                        r11 = 0x1u;
                        r10 = r10 + r9;
                        r12 = 0;
                        r10 <<= 0x2u;
                        r13 = r11;
                        CALL(sub_22f);
                        goto L_412c;
                        L_4123:; /* 0x4123 */
                        fc_cmp(r1, r0);
                        if (!FC(falcon_flags)) {
                            L_4128:; /* 0x4128 */
                            goto L_4103;
                            L_412c:; /* 0x412c */
                            r10 = d32(r0);
                            r9 = 0x402f0u;
                            r10 = r10 + r9;
                            r10 <<= 0x2u;
                            CALL(sub_297);
                            r10 &= 0x1u;
                            if (!FZ(falcon_flags)) {
                                L_4142:; /* 0x4142 */
                                r15 = 0;
                                r9 = 0x10c00u;
                                iowr(r9, r15);
                                r9 = 0x12c4u;
                                r0 = 0x1u;
                                r10 = 0x5u;
                                r11 = r0;
                                s32(r9, r0);
                                r9 = 0x12bcu;
                                s32(r9, r15);
                                CALL(sub_d17);
                                CALL(sub_29a6);
                                r10 = 0x409614u;
                                r11 = 0x5u;
                                CALL(sub_237);
                                r10 = 0x41a614u;
                                r11 = 0x806u;
                                CALL(sub_237);
                                r11 = r0;
                                r10 = 0x6u;
                                CALL(sub_d17);
                                CALL(sub_4010);
                                r15 = 0x8000u;
                                r9 = 0x21a00u;
                                iowr(r9, r15);
                                r15 = 0x4000u;
                                r9 = r9 - 0x200u;
                                iowr(r9, r15);
                                L_419c:; /* 0x419c */
                                r10 = r1;
                                for (int i = 0; i <= 1; i++) r[i] = pop32();
                                return;
                            }
                            goto L_412c;  /* 重复引用 */
                        }
                        goto L_40ec;  /* 重复引用 */
                    }
                    goto L_40d6;  /* 重复引用 */
                }
                goto L_40bf;  /* 重复引用 */
                goto L_40d2;  /* 重复引用 */
            }
            goto L_40f3;  /* 重复引用 */
            goto L_40d6;  /* 重复引用 */
            goto L_40d9;  /* 重复引用 */
            goto L_40e8;  /* 重复引用 */
        }
        goto L_40aa;  /* 重复引用 */
    }
    goto L_4062;  /* 重复引用 */
}

/* ==== sub_41a0  (被调用 6 次) ==== */
static void sub_41a0(void) {
    L_41a0:; /* 0x41a0 */
    for (int i = 1; i >= 0; i--) push32(r[i]);
    r1 = 0x28400u;
    r0 = 0;
    L_41a8:; /* 0x41a8 */
    CALL(sub_215e);
    r9 = iord(r1+r0*0x4);
    r9 &= 0x1fu;
    if (!!FZ(falcon_flags)) {
        L_41b5:; /* 0x41b5 */
        for (int i = 0; i <= 1; i++) r[i] = pop32();
        return;
    }
    goto L_41a8;  /* 重复引用 */
}

/* ==== sub_41b7  (被调用 1 次) ==== */
static void sub_41b7(void) {
    L_41b7:; /* 0x41b7 */
    for (int i = 3; i >= 0; i--) push32(r[i]);
    r2 = r10;
    r0 = r11;
    r3 = r12;
    CALL(sub_1f53);
    r9 = 0x1u;
    if (!(r10 == 0x0u)) {
        L_41c9:; /* 0x41c9 */
        r11 = r0;
        r12 = r3;
        r10 = 0x1u;
        CALL(sub_1eda);
        r11 = r0;
        r12 = r3;
        r1 = r10;
        r10 = 0x2u;
        CALL(sub_1eda);
        r0 = r10;
        CALL(sub_31cf);
        r11 = r1;
        r10 = 0x28900u;
        CALL(sub_10);
        r11 = r0;
        r10 = 0x28300u;
        CALL(sub_10);
        if (!(r2 == 0xcu)) {
            L_41fd:; /* 0x41fd */
            if ((r2 != 0xau)) goto L_420b;
            L_4201:; /* 0x4201 */
            r10 = 0x31u;
            CALL(sub_5c0);
            goto L_4215;
            L_420b:; /* 0x420b */
            r11 = r2;
            r10 = 0x28400u;
            CALL(sub_10);
            L_4215:; /* 0x4215 */
            CALL(sub_41a0);
            CALL(sub_31cf);
            r9 = 0;
            L_421f:; /* 0x421f */
            r10 = r9;
            for (int i = 0; i <= 3; i++) r[i] = pop32();
            return;
            goto L_420b;  /* 重复引用 */
        }
        goto L_4201;  /* 重复引用 */
        goto L_41fd;  /* 重复引用 */
        goto L_4201;  /* 重复引用 */
        goto L_420b;  /* 重复引用 */
        goto L_4215;  /* 重复引用 */
    }
    goto L_421f;  /* 重复引用 */
}

/* ==== sub_4223  (被调用 4 次) ==== */
static void sub_4223(void) {
    L_4223:; /* 0x4223 */
    for (int i = 7; i >= 0; i--) push32(r[i]);
    r9 = 0x80000000u;
    sp += -0xcu;
    r2 = r10;
    r15 = 0x21400u;
    iowr(r15, r9);
    r9 = 0x13f0u;
    r15 = d32(r9);
    if (!(r15 != 0x0u)) {
        L_4241:; /* 0x4241 */
        r9 = 0x2de00u;
        r9 = iord(r9+r15*0x4);
        r9 &= 0x3fu;
        if (!FZ(falcon_flags)) {
            L_424f:; /* 0x424f */
            r9 = 0x141cu;
            r9 = d32(r9);
            if (!(r9 != 0x0u)) {
                L_4259:; /* 0x4259 */
                r9 = 0x1420u;
                r9 = d32(r9);
                if ((r9 == 0x0u)) goto L_436e;
                L_4264:; /* 0x4264 */
                r9 = 0x1428u;
                r12 = d32(r9);
                if (!(r12 == 0x0u)) {
                    L_426e:; /* 0x426e */
                    r15 = 0x80000000u;
                    r9 = 0x21a00u;
                    iowr(r9, r15);
                    r15 = 0x4u;
                    goto L_438e;
                    L_4280:; /* 0x4280 */
                    r9 = 0xffffffu;
                    fc_cmp(r2, r9);
                    if (!(FC(falcon_flags) || FZ(falcon_flags))) {
                        L_428a:; /* 0x428a */
                        r15 = 0x80000000u;
                        r9 = 0x21a00u;
                        iowr(r9, r15);
                        r15 = 0x5u;
                        goto L_438e;
                        L_429c:; /* 0x429c */
                        r9 = 0x28100u;
                        r7 = iord(r9+r12*0x4);
                        r9 = r9 + 0xd00u;
                        r6 = iord(r9+r12*0x4);
                        r9 = r9 + 0x100u;
                        r5 = iord(r9+r12*0x4);
                        r9 = 0x1414u;
                        r13 = d32(r9);
                        r9 = 0x1418u;
                        r9 = d32(r9);
                        r15 = 0x1424u;
                        r0 = d32(r15);
                        r15 = r13 >> 0x8u;
                        r11 = r9 >> 0x8u;
                        r9 <<= 0x18u;
                        r9 |= r15;
                        r15 = r2 >> 0xdu;
                        r4 = r2 >> 0x2u;
                        r14 = r15 + r9;
                        r15 = r2 >> 0x5u;
                        fc_cmp(r14, r9);
                        if (!!FC(falcon_flags)) {
                            L_42e2:; /* 0x42e2 */
                            r11 = r11 + 0x1u;
                            L_42e5:; /* 0x42e5 */
                            r9 = r15 & 0xffu;
                            r15 = r13 & 0xffu;
                            r15 = r9 + r15;
                            r9 = r15 >> 0x8u;
                            r1 = r9 + r14;
                            fc_cmp(r1, r14);
                            if (!!FC(falcon_flags)) {
                                L_42f9:; /* 0x42f9 */
                                r11 = r11 + 0x1u;
                                L_42fc:; /* 0x42fc */
                                r9 = 0x1434u;
                                r9 = d32(r9);
                                r3 = r15 & 0xffu;
                                if (!(r9 == 0x0u)) {
                                    L_4309:; /* 0x4309 */
                                    r9 = 0x1430u;
                                    r9 = d32(r9);
                                    fc_cmp(r9, r1);
                                    if (FZ(falcon_flags)) goto L_4354;
                                    L_4314:; /* 0x4314 */
                                    r10 = r1;
                                    r12 = 0xc0u;
                                    CALL(sub_32b9);
                                    CALL(sub_31cf);
                                    r9 = 0x2u;
                                    r14 = r0;
                                    r10 = 0;
                                    r0 = 0x1u;
                                    r11 = r3;
                                    r12 = 0x6u;
                                    s32(sp+0x8, r9);
                                    s32(sp, r0);
                                    s32(sp+0x4, r0);
                                    r13 = 0xb00u;
                                    CALL(sub_2de1);
                                    r9 = 0x1434u;
                                    s32(r9, r0);
                                    r9 = 0x1430u;
                                    r10 = r7;
                                    r11 = r6;
                                    r12 = r5;
                                    s32(r9, r1);
                                    CALL(sub_32b9);
                                    L_4354:; /* 0x4354 */
                                    r15 = 0xb00u;
                                    r9 = r3 & 0xfcu;
                                    r9 = r9 + r15;
                                    r14 = d32(r9);
                                    r15 = r4 & 0x1fu;
                                    r9 = 0x1u;
                                    r9 <<= r15;
                                    r9 &= r14;
                                    if (FZ(falcon_flags)) goto L_4380;
                                    L_436e:; /* 0x436e */
                                    r15 = 0x80000000u;
                                    r9 = 0x21a00u;
                                    iowr(r9, r15);
                                    r10 = 0;
                                    goto L_43a0;
                                    L_4380:; /* 0x4380 */
                                    r15 = 0x80000000u;
                                    r9 = 0x21a00u;
                                    iowr(r9, r15);
                                    r15 = 0x6u;
                                    L_438e:; /* 0x438e */
                                    r9 = r9 - 0xc00u;
                                    iowr(r9, r15);
                                    r9 = r9 + 0x100u;
                                    iowr(r9, r2);
                                    r10 = 0x1u;
                                    L_43a0:; /* 0x43a0 */
                                    sp += 0xcu;
                                    for (int i = 0; i <= 7; i++) r[i] = pop32();
                                    return;
                                }
                                goto L_4314;  /* 重复引用 */
                            }
                            goto L_42fc;  /* 重复引用 */
                        }
                        goto L_42e5;  /* 重复引用 */
                    }
                    goto L_429c;  /* 重复引用 */
                }
                goto L_4280;  /* 重复引用 */
            }
            goto L_4264;  /* 重复引用 */
            goto L_4259;  /* 重复引用 */
            goto L_4264;  /* 重复引用 */
            goto L_426e;  /* 重复引用 */
            goto L_4280;  /* 重复引用 */
            goto L_428a;  /* 重复引用 */
            goto L_429c;  /* 重复引用 */
            goto L_42e2;  /* 重复引用 */
            goto L_42e5;  /* 重复引用 */
            goto L_42f9;  /* 重复引用 */
            goto L_42fc;  /* 重复引用 */
            goto L_4309;  /* 重复引用 */
            goto L_4314;  /* 重复引用 */
            goto L_4354;  /* 重复引用 */
            goto L_4380;  /* 重复引用 */
            goto L_438e;  /* 重复引用 */
        }
        goto L_436e;  /* 重复引用 */
        goto L_424f;  /* 重复引用 */
        goto L_4259;  /* 重复引用 */
        goto L_4264;  /* 重复引用 */
        goto L_426e;  /* 重复引用 */
        goto L_4280;  /* 重复引用 */
        goto L_428a;  /* 重复引用 */
        goto L_429c;  /* 重复引用 */
        goto L_42e2;  /* 重复引用 */
        goto L_42e5;  /* 重复引用 */
        goto L_42f9;  /* 重复引用 */
        goto L_42fc;  /* 重复引用 */
        goto L_4309;  /* 重复引用 */
        goto L_4314;  /* 重复引用 */
        goto L_4354;  /* 重复引用 */
        goto L_4380;  /* 重复引用 */
        goto L_438e;  /* 重复引用 */
    }
    goto L_436e;  /* 重复引用 */
}

/* ==== sub_43a5  (被调用 1 次) ==== */
static void sub_43a5(void) {
    L_43a5:; /* 0x43a5 */
    for (int i = 3; i >= 0; i--) push32(r[i]);
    r0 = r11;
    r3 = r12;
    r2 = r10;
    CALL(sub_398e);
    if (!(r10 == 0x1u)) {
        L_43b5:; /* 0x43b5 */
        r10 = r2;
        CALL(sub_4223);
        if (!(r10 == 0x1u)) {
            L_43bf:; /* 0x43bf */
            r11 = r0;
            r12 = r3;
            r10 = 0x1u;
            CALL(sub_1eda);
            r11 = r0;
            r12 = r3;
            r1 = r10;
            r10 = 0x2u;
            CALL(sub_1eda);
            r0 = r10;
            r10 = r2;
            CALL(sub_297);
            r1 = r0 & r1;
            r0 = ~r0;
            r0 &= r10;
            r10 = r2;
            r11 = r0 | r1;
            CALL(sub_237);
            r10 = 0;
            goto L_43f7;
            L_43f5:; /* 0x43f5 */
            r10 = 0x1u;
            L_43f7:; /* 0x43f7 */
            for (int i = 0; i <= 3; i++) r[i] = pop32();
            return;
        }
        goto L_43f5;  /* 重复引用 */
        goto L_43bf;  /* 重复引用 */
    }
    goto L_43f5;  /* 重复引用 */
}

/* ==== sub_43f9  (被调用 1 次) ==== */
static void sub_43f9(void) {
    L_43f9:; /* 0x43f9 */
    for (int i = 2; i >= 0; i--) push32(r[i]);
    r2 = r11;
    r1 = r12;
    r0 = r10;
    CALL(sub_398e);
    if (!(r10 == 0x1u)) {
        L_4409:; /* 0x4409 */
        r10 = r0;
        CALL(sub_4223);
        if (!(r10 == 0x1u)) {
            L_4413:; /* 0x4413 */
            r12 = r1;
            r11 = r2;
            r10 = 0x1u;
            CALL(sub_1eda);
            r11 = r10;
            r10 = r0;
            CALL(sub_237);
            r10 = 0;
            goto L_442d;
            L_442b:; /* 0x442b */
            r10 = 0x1u;
            L_442d:; /* 0x442d */
            for (int i = 0; i <= 2; i++) r[i] = pop32();
            return;
        }
        goto L_442b;  /* 重复引用 */
        goto L_4413;  /* 重复引用 */
    }
    goto L_442b;  /* 重复引用 */
}

/* ==== sub_442f  (被调用 1 次) ==== */
static void sub_442f(void) {
    L_442f:; /* 0x442f */
    for (int i = 2; i >= 0; i--) push32(r[i]);
    r1 = r11;
    r2 = r12;
    r0 = r10;
    CALL(sub_398e);
    if (!(r10 == 0x1u)) {
        L_443f:; /* 0x443f */
        r10 = r0;
        CALL(sub_4223);
        if (!(r10 == 0x1u)) {
            L_4449:; /* 0x4449 */
            r10 = r0;
            CALL(sub_297);
            r12 = r1;
            r11 = r10;
            r13 = r2;
            r10 = 0x1u;
            CALL(sub_1e5f);
            r10 = 0;
            goto L_4463;
            L_4461:; /* 0x4461 */
            r10 = 0x1u;
            L_4463:; /* 0x4463 */
            for (int i = 0; i <= 2; i++) r[i] = pop32();
            return;
        }
        goto L_4461;  /* 重复引用 */
        goto L_4449;  /* 重复引用 */
    }
    goto L_4461;  /* 重复引用 */
}

/* ==== sub_4465  (被调用 1 次) ==== */
static void sub_4465(void) {
    L_4465:; /* 0x4465 */
    for (int i = 0; i >= 0; i--) push32(r[i]);
    r0 = r10;
    r10 = 0x406020u;
    CALL(sub_297);
    if (!(r0 == 0x0u)) {
        L_4475:; /* 0x4475 */
        r9 = 0x200000u;
        r11 = r10 | r9;
        goto L_4487;
        L_4480:; /* 0x4480 */
        r9 = -0x200001u;
        r11 = r10 & r9;
        L_4487:; /* 0x4487 */
        r10 = 0x406020u;
        CALL(sub_237);
        for (int i = 0; i <= 0; i++) r[i] = pop32();
        return;
    }
    goto L_4480;  /* 重复引用 */
}

/* ==== sub_4491  (被调用 1 次) ==== */
static void sub_4491(void) {
    L_4491:; /* 0x4491 */
    for (int i = 2; i >= 0; i--) push32(r[i]);
    r15 = 0x2000u;
    r9 = 0x21200u;
    iowr(r9, r15);
    r10 = 0x400704u;
    CALL(sub_297);
    r15 = 0x101080u;
    r9 = r10;
    r10 = (r10 >> 16) & 0x7u;
    r0 = r9 & 0x3ffcu;
    r10 = r10 + r15;
    r2 = (r9 >> 22) & 0x1u;
    r10 <<= 0x2u;
    CALL(sub_297);
    r1 = r10 & 0xffffu;
    r10 = 0x400708u;
    CALL(sub_297);
    r9 = 0xa140u;
    fc_cmp(r1, r9);
    if (!FZ(falcon_flags)) {
        L_44d5:; /* 0x44d5 */
        fc_cmp(r1, r9);
        if (!(!FC(falcon_flags) && !FZ(falcon_flags))) {
            L_44da:; /* 0x44da */
            r9 = r9 - 0x1113u;
            fc_cmp(r1, r9);
            if (!!FZ(falcon_flags)) {
                L_44e5:; /* 0x44e5 */
                goto L_45a7;
                L_44e9:; /* 0x44e9 */
                r9 = 0xc997u;
                fc_cmp(r1, r9);
                if (!FZ(falcon_flags)) {
                    L_44f2:; /* 0x44f2 */
                    r9 = r9 + 0x29u;
                    fc_cmp(r1, r9);
                    if (!!FZ(falcon_flags)) {
                        L_44fb:; /* 0x44fb */
                        goto L_4537;
                        L_44ff:; /* 0x44ff */
                        if (!(r0 == 0x230cu)) {
                            L_4505:; /* 0x4505 */
                            fc_cmp(r0, 0x230cu);
                            if (!(!FC(falcon_flags) && !FZ(falcon_flags))) {
                                L_450c:; /* 0x450c */
                                if (!(r0 == 0x2304u)) {
                                    L_4512:; /* 0x4512 */
                                    if (!(r0 == 0x2308u)) {
                                        L_4518:; /* 0x4518 */
                                        if (!(r0 != 0x2300u)) {
                                            L_451e:; /* 0x451e */
                                            goto L_45d4;
                                            L_4522:; /* 0x4522 */
                                            if (!(r0 == 0x2314u)) {
                                                L_4528:; /* 0x4528 */
                                                if (!(r0 == 0x2320u)) {
                                                    L_452d:; /* 0x452d */
                                                    if (!(r0 != 0x2310u)) {
                                                        L_4533:; /* 0x4533 */
                                                        goto L_460c;
                                                        L_4537:; /* 0x4537 */
                                                        if (!(r0 == 0x50cu)) {
                                                            L_453d:; /* 0x453d */
                                                            fc_cmp(r0, 0x50cu);
                                                            if (!(!FC(falcon_flags) && !FZ(falcon_flags))) {
                                                                L_4544:; /* 0x4544 */
                                                                if (!(r0 == 0x504u)) {
                                                                    L_454a:; /* 0x454a */
                                                                    if (!(r0 == 0x508u)) {
                                                                        L_4550:; /* 0x4550 */
                                                                        if (!(r0 != 0x500u)) {
                                                                            L_4556:; /* 0x4556 */
                                                                            goto L_45d4;
                                                                            L_455a:; /* 0x455a */
                                                                            if (!(r0 == 0x514u)) {
                                                                                L_4560:; /* 0x4560 */
                                                                                if (!(r0 == 0x520u)) {
                                                                                    L_4565:; /* 0x4565 */
                                                                                    if (!(r0 != 0x510u)) {
                                                                                        L_456b:; /* 0x456b */
                                                                                        goto L_460c;
                                                                                        L_456f:; /* 0x456f */
                                                                                        CALL(sub_4465);
                                                                                        goto L_4633;
                                                                                        L_4577:; /* 0x4577 */
                                                                                        if (!(r0 == 0x208u)) {
                                                                                            L_457c:; /* 0x457c */
                                                                                            fc_cmp(r0, 0x208u);
                                                                                            if (!(!FC(falcon_flags) && !FZ(falcon_flags))) {
                                                                                                L_4583:; /* 0x4583 */
                                                                                                if (!(r0 == 0x200u)) {
                                                                                                    L_4588:; /* 0x4588 */
                                                                                                    if (!(r0 != 0x204u)) {
                                                                                                        L_458e:; /* 0x458e */
                                                                                                        goto L_45e0;
                                                                                                        L_4592:; /* 0x4592 */
                                                                                                        if (!(r0 == 0x210u)) {
                                                                                                            L_4597:; /* 0x4597 */
                                                                                                            if (!(r0 == 0x214u)) {
                                                                                                                L_459d:; /* 0x459d */
                                                                                                                if (!(r0 != 0x20cu)) {
                                                                                                                    L_45a3:; /* 0x45a3 */
                                                                                                                    goto L_45f8;
                                                                                                                    L_45a7:; /* 0x45a7 */
                                                                                                                    if (!(r0 == 0x8e8u)) {
                                                                                                                        L_45ac:; /* 0x45ac */
                                                                                                                        fc_cmp(r0, 0x8e8u);
                                                                                                                        if (!(!FC(falcon_flags) && !FZ(falcon_flags))) {
                                                                                                                            L_45b3:; /* 0x45b3 */
                                                                                                                            if (!(r0 == 0x8e0u)) {
                                                                                                                                L_45b8:; /* 0x45b8 */
                                                                                                                                if (!(r0 != 0x8e4u)) {
                                                                                                                                    L_45bd:; /* 0x45bd */
                                                                                                                                    goto L_45e0;
                                                                                                                                    L_45c1:; /* 0x45c1 */
                                                                                                                                    if (!(r0 == 0x8f0u)) {
                                                                                                                                        L_45c6:; /* 0x45c6 */
                                                                                                                                        if (!(r0 == 0x8f4u)) {
                                                                                                                                            L_45cb:; /* 0x45cb */
                                                                                                                                            if (!(r0 != 0x8ecu)) {
                                                                                                                                                L_45d0:; /* 0x45d0 */
                                                                                                                                                goto L_45f8;
                                                                                                                                                L_45d4:; /* 0x45d4 */
                                                                                                                                                r11 = r1;
                                                                                                                                                r12 = r2;
                                                                                                                                                CALL(sub_442f);
                                                                                                                                                goto L_4620;
                                                                                                                                                L_45e0:; /* 0x45e0 */
                                                                                                                                                r11 = r1;
                                                                                                                                                r12 = r2;
                                                                                                                                                CALL(sub_43f9);
                                                                                                                                                goto L_4620;
                                                                                                                                                L_45ec:; /* 0x45ec */
                                                                                                                                                r11 = r1;
                                                                                                                                                r12 = r2;
                                                                                                                                                CALL(sub_41b7);
                                                                                                                                                goto L_4620;
                                                                                                                                                L_45f8:; /* 0x45f8 */
                                                                                                                                                r9 = 0x28u;
                                                                                                                                                r11 = d32(r9);
                                                                                                                                                r10 = 0x1u;
                                                                                                                                                r12 = r1;
                                                                                                                                                r13 = r2;
                                                                                                                                                CALL(sub_1e5f);
                                                                                                                                                goto L_4633;
                                                                                                                                                L_460c:; /* 0x460c */
                                                                                                                                                r11 = r1;
                                                                                                                                                r12 = r2;
                                                                                                                                                CALL(sub_43a5);
                                                                                                                                                goto L_4620;
                                                                                                                                                L_4618:; /* 0x4618 */
                                                                                                                                                r11 = r1;
                                                                                                                                                r12 = r2;
                                                                                                                                                CALL(sub_31ff);
                                                                                                                                                L_4620:; /* 0x4620 */
                                                                                                                                                if ((r10 == 0x0u)) goto L_4633;
                                                                                                                                                L_4624:; /* 0x4624 */
                                                                                                                                                r15 = 0x20000u;
                                                                                                                                                r9 = 0x30700u;
                                                                                                                                                iowr(r9, r15);
                                                                                                                                                goto L_464a;
                                                                                                                                                L_4633:; /* 0x4633 */
                                                                                                                                                r10 = 0;
                                                                                                                                                r11 = 0x1u;
                                                                                                                                                r12 = r1;
                                                                                                                                                r13 = r2;
                                                                                                                                                CALL(sub_1e5f);
                                                                                                                                                r10 = 0x400144u;
                                                                                                                                                r11 = 0x100u;
                                                                                                                                                CALL(sub_237);
                                                                                                                                                L_464a:; /* 0x464a */
                                                                                                                                                r15 = 0x2000u;
                                                                                                                                                r9 = 0x21800u;
                                                                                                                                                iowr(r9, r15);
                                                                                                                                                for (int i = 0; i <= 2; i++) r[i] = pop32();
                                                                                                                                                return;
                                                                                                                                            }
                                                                                                                                            goto L_4624;  /* 重复引用 */
                                                                                                                                            goto L_45d0;  /* 重复引用 */
                                                                                                                                        }
                                                                                                                                        goto L_4618;  /* 重复引用 */
                                                                                                                                        goto L_45cb;  /* 重复引用 */
                                                                                                                                        goto L_45d0;  /* 重复引用 */
                                                                                                                                    }
                                                                                                                                    goto L_460c;  /* 重复引用 */
                                                                                                                                }
                                                                                                                                goto L_4624;  /* 重复引用 */
                                                                                                                                goto L_45bd;  /* 重复引用 */
                                                                                                                            }
                                                                                                                            goto L_45d4;  /* 重复引用 */
                                                                                                                            goto L_45b8;  /* 重复引用 */
                                                                                                                            goto L_45bd;  /* 重复引用 */
                                                                                                                        }
                                                                                                                        goto L_45c1;  /* 重复引用 */
                                                                                                                        goto L_45b3;  /* 重复引用 */
                                                                                                                        goto L_45b8;  /* 重复引用 */
                                                                                                                        goto L_45bd;  /* 重复引用 */
                                                                                                                        goto L_45c1;  /* 重复引用 */
                                                                                                                        goto L_45c6;  /* 重复引用 */
                                                                                                                        goto L_45cb;  /* 重复引用 */
                                                                                                                        goto L_45d0;  /* 重复引用 */
                                                                                                                    }
                                                                                                                    goto L_45ec;  /* 重复引用 */
                                                                                                                }
                                                                                                                goto L_4624;  /* 重复引用 */
                                                                                                                goto L_45a3;  /* 重复引用 */
                                                                                                            }
                                                                                                            goto L_4618;  /* 重复引用 */
                                                                                                            goto L_459d;  /* 重复引用 */
                                                                                                            goto L_45a3;  /* 重复引用 */
                                                                                                        }
                                                                                                        goto L_460c;  /* 重复引用 */
                                                                                                    }
                                                                                                    goto L_4624;  /* 重复引用 */
                                                                                                    goto L_458e;  /* 重复引用 */
                                                                                                }
                                                                                                goto L_45d4;  /* 重复引用 */
                                                                                                goto L_4588;  /* 重复引用 */
                                                                                                goto L_458e;  /* 重复引用 */
                                                                                            }
                                                                                            goto L_4592;  /* 重复引用 */
                                                                                            goto L_4583;  /* 重复引用 */
                                                                                            goto L_4588;  /* 重复引用 */
                                                                                            goto L_458e;  /* 重复引用 */
                                                                                            goto L_4592;  /* 重复引用 */
                                                                                            goto L_4597;  /* 重复引用 */
                                                                                            goto L_459d;  /* 重复引用 */
                                                                                            goto L_45a3;  /* 重复引用 */
                                                                                        }
                                                                                        goto L_45ec;  /* 重复引用 */
                                                                                    }
                                                                                    goto L_4624;  /* 重复引用 */
                                                                                    goto L_456b;  /* 重复引用 */
                                                                                }
                                                                                goto L_456f;  /* 重复引用 */
                                                                                goto L_4565;  /* 重复引用 */
                                                                                goto L_456b;  /* 重复引用 */
                                                                            }
                                                                            goto L_4618;  /* 重复引用 */
                                                                        }
                                                                        goto L_4624;  /* 重复引用 */
                                                                        goto L_4556;  /* 重复引用 */
                                                                    }
                                                                    goto L_45ec;  /* 重复引用 */
                                                                    goto L_4550;  /* 重复引用 */
                                                                    goto L_4556;  /* 重复引用 */
                                                                }
                                                                goto L_45e0;  /* 重复引用 */
                                                                goto L_454a;  /* 重复引用 */
                                                                goto L_4550;  /* 重复引用 */
                                                                goto L_4556;  /* 重复引用 */
                                                            }
                                                            goto L_455a;  /* 重复引用 */
                                                            goto L_4544;  /* 重复引用 */
                                                            goto L_454a;  /* 重复引用 */
                                                            goto L_4550;  /* 重复引用 */
                                                            goto L_4556;  /* 重复引用 */
                                                            goto L_455a;  /* 重复引用 */
                                                            goto L_4560;  /* 重复引用 */
                                                            goto L_4565;  /* 重复引用 */
                                                            goto L_456b;  /* 重复引用 */
                                                        }
                                                        goto L_45f8;  /* 重复引用 */
                                                    }
                                                    goto L_4624;  /* 重复引用 */
                                                    goto L_4533;  /* 重复引用 */
                                                }
                                                goto L_456f;  /* 重复引用 */
                                                goto L_452d;  /* 重复引用 */
                                                goto L_4533;  /* 重复引用 */
                                            }
                                            goto L_4618;  /* 重复引用 */
                                        }
                                        goto L_4624;  /* 重复引用 */
                                        goto L_451e;  /* 重复引用 */
                                    }
                                    goto L_45ec;  /* 重复引用 */
                                    goto L_4518;  /* 重复引用 */
                                    goto L_451e;  /* 重复引用 */
                                }
                                goto L_45e0;  /* 重复引用 */
                                goto L_4512;  /* 重复引用 */
                                goto L_4518;  /* 重复引用 */
                                goto L_451e;  /* 重复引用 */
                            }
                            goto L_4522;  /* 重复引用 */
                            goto L_450c;  /* 重复引用 */
                            goto L_4512;  /* 重复引用 */
                            goto L_4518;  /* 重复引用 */
                            goto L_451e;  /* 重复引用 */
                            goto L_4522;  /* 重复引用 */
                            goto L_4528;  /* 重复引用 */
                            goto L_452d;  /* 重复引用 */
                            goto L_4533;  /* 重复引用 */
                        }
                        goto L_45f8;  /* 重复引用 */
                        goto L_4537;  /* 重复引用 */
                        goto L_453d;  /* 重复引用 */
                        goto L_4544;  /* 重复引用 */
                        goto L_454a;  /* 重复引用 */
                        goto L_4550;  /* 重复引用 */
                        goto L_4556;  /* 重复引用 */
                        goto L_455a;  /* 重复引用 */
                        goto L_4560;  /* 重复引用 */
                        goto L_4565;  /* 重复引用 */
                        goto L_456b;  /* 重复引用 */
                    }
                    goto L_4624;  /* 重复引用 */
                    goto L_44fb;  /* 重复引用 */
                    goto L_4537;  /* 重复引用 */
                    goto L_453d;  /* 重复引用 */
                    goto L_4544;  /* 重复引用 */
                    goto L_454a;  /* 重复引用 */
                    goto L_4550;  /* 重复引用 */
                    goto L_4556;  /* 重复引用 */
                    goto L_455a;  /* 重复引用 */
                    goto L_4560;  /* 重复引用 */
                    goto L_4565;  /* 重复引用 */
                    goto L_456b;  /* 重复引用 */
                }
                goto L_44ff;  /* 重复引用 */
                goto L_45a7;  /* 重复引用 */
                goto L_45ac;  /* 重复引用 */
                goto L_45b3;  /* 重复引用 */
                goto L_45b8;  /* 重复引用 */
                goto L_45bd;  /* 重复引用 */
                goto L_45c1;  /* 重复引用 */
                goto L_45c6;  /* 重复引用 */
                goto L_45cb;  /* 重复引用 */
                goto L_45d0;  /* 重复引用 */
            }
            goto L_4624;  /* 重复引用 */
            goto L_44e5;  /* 重复引用 */
            goto L_45a7;  /* 重复引用 */
            goto L_45ac;  /* 重复引用 */
            goto L_45b3;  /* 重复引用 */
            goto L_45b8;  /* 重复引用 */
            goto L_45bd;  /* 重复引用 */
            goto L_45c1;  /* 重复引用 */
            goto L_45c6;  /* 重复引用 */
            goto L_45cb;  /* 重复引用 */
            goto L_45d0;  /* 重复引用 */
        }
        goto L_44e9;  /* 重复引用 */
        goto L_44da;  /* 重复引用 */
        goto L_44e5;  /* 重复引用 */
        goto L_44e9;  /* 重复引用 */
        goto L_44f2;  /* 重复引用 */
        goto L_44fb;  /* 重复引用 */
        goto L_44ff;  /* 重复引用 */
        goto L_4505;  /* 重复引用 */
        goto L_450c;  /* 重复引用 */
        goto L_4512;  /* 重复引用 */
        goto L_4518;  /* 重复引用 */
        goto L_451e;  /* 重复引用 */
        goto L_4522;  /* 重复引用 */
        goto L_4528;  /* 重复引用 */
        goto L_452d;  /* 重复引用 */
        goto L_4533;  /* 重复引用 */
        goto L_4537;  /* 重复引用 */
        goto L_453d;  /* 重复引用 */
        goto L_4544;  /* 重复引用 */
        goto L_454a;  /* 重复引用 */
        goto L_4550;  /* 重复引用 */
        goto L_4556;  /* 重复引用 */
        goto L_455a;  /* 重复引用 */
        goto L_4560;  /* 重复引用 */
        goto L_4565;  /* 重复引用 */
        goto L_456b;  /* 重复引用 */
        goto L_456f;  /* 重复引用 */
        goto L_45a7;  /* 重复引用 */
        goto L_45ac;  /* 重复引用 */
        goto L_45b3;  /* 重复引用 */
        goto L_45b8;  /* 重复引用 */
        goto L_45bd;  /* 重复引用 */
        goto L_45c1;  /* 重复引用 */
        goto L_45c6;  /* 重复引用 */
        goto L_45cb;  /* 重复引用 */
        goto L_45d0;  /* 重复引用 */
    }
    goto L_4577;  /* 重复引用 */
}

/* ==== sub_4656  (被调用 2 次) ==== */
static void sub_4656(void) {
    L_4656:; /* 0x4656 */
    for (int i = 5; i >= 0; i--) push32(r[i]);
    r15 = 0x40000000u;
    r9 = 0x21200u;
    iowr(r9, r15);
    r5 = 0x12c4u;
    r4 = 0x15fcu;
    r0 = 0x15f8u;
    r3 = 0x15b8u;
    r2 = -0xf001u;
    r1 = 0x10002u;
    goto L_46bc;
    L_4680:; /* 0x4680 */
    r9 = d32(r0);
    r15 = d32(r0);
    r14 = d32(r0);
    r13 = 0x15b8u;
    r9 &= 0x7u;
    r9 <<= 0x3u;
    r9 = r9 + r13;
    r14 = r14 + 0x1u;
    r13 = d32(r9);
    s32(r0, r14);
    r9 = d32(r0);
    r15 &= 0x7u;
    r15 = r15 + r15;
    r15 = r15 + 0x1u;
    r11 = d32(r3+r15*0x4);
    if (!(r9 != 0x10u)) {
        L_46ac:; /* 0x46ac */
        s32(r0, r12);
        L_46ae:; /* 0x46ae */
        r9 = r13 & r2;
        fc_cmp(r9, r1);
        if (!!FZ(falcon_flags)) {
            L_46b6:; /* 0x46b6 */
            r10 = r1;
            CALL(sub_4491);
            L_46bc:; /* 0x46bc */
            r9 = d32(r5);
            if (!(r9 == 0x0u)) {
                L_46c2:; /* 0x46c2 */
                r9 = 0x15fcu;
                r9 = d32(r9);
                r9 = 0x15f8u;
                r9 = d32(r9);
                goto L_46dd;
                L_46d2:; /* 0x46d2 */
                r12 = 0;
                L_46d4:; /* 0x46d4 */
                r15 = d32(r4);
                r9 = d32(r0);
                fc_cmp(r15, r9);
                if (!FZ(falcon_flags)) goto L_4680;
                L_46dd:; /* 0x46dd */
                r15 = 0x40000000u;
                r9 = 0x21800u;
                iowr(r9, r15);
                for (int i = 0; i <= 5; i++) r[i] = pop32();
                return;
            }
            goto L_46d2;  /* 重复引用 */
        }
        goto L_46d4;  /* 重复引用 */
    }
    goto L_46ae;  /* 重复引用 */
}

/* ==== sub_46eb  (被调用 2 次) ==== */
static void sub_46eb(void) {
    L_46eb:; /* 0x46eb */
    r9 = 0x15fcu;
    r15 = d32(r9);
    r9 = 0x15f8u;
    r9 = d32(r9);
    fc_cmp(r15, r9);
    if (!FZ(falcon_flags)) {
        L_46fc:; /* 0x46fc */
        CALL(sub_4656);
        L_4700:; /* 0x4700 */
        return;
    }
    goto L_4700;  /* 重复引用 */
}

/* ==== sub_4702  (被调用 2 次) ==== */
static void sub_4702(void) {
    L_4702:; /* 0x4702 */
    for (int i = 2; i >= 0; i--) push32(r[i]);
    r0 = r10;
    r2 = 0x30000u;
    r1 = 0;
    goto L_4718;
    L_4710:; /* 0x4710 */
    CALL(sub_215e);
    CALL(sub_46eb);
    L_4718:; /* 0x4718 */
    r9 = iord(r2+r1*0x4);
    r15 = r9 & 0x2000u;
    if (!!FZ(falcon_flags)) {
        L_4722:; /* 0x4722 */
        r9 = 0x12c0u;
        s32(r9, r15);
        if (!(r0 == 0x0u)) {
            L_472c:; /* 0x472c */
            r15 = 0x1u;
            r9 = 0x12b8u;
            s32(r9, r15);
            L_4734:; /* 0x4734 */
            r15 = 0x20u;
            r9 = 0x21900u;
            iowr(r9, r15);
            for (int i = 0; i <= 2; i++) r[i] = pop32();
            return;
        }
        goto L_4734;  /* 重复引用 */
        goto L_472c;  /* 重复引用 */
        goto L_4734;  /* 重复引用 */
    }
    goto L_4710;  /* 重复引用 */
}

/* ==== sub_473f  (被调用 1 次) ==== */
static void sub_473f(void) {
    L_473f:; /* 0x473f */
    for (int i = 0; i >= 0; i--) push32(r[i]);
    r0 = r10;
    r10 = r11;
    CALL(sub_e82);
    r10 = r0;
    CALL(sub_4702);
    for (int i = 0; i <= 0; i++) r[i] = pop32();
    return;
}

/* ==== sub_4751  (被调用 4 次) ==== */
static void sub_4751(void) {
    L_4751:; /* 0x4751 */
    for (int i = 2; i >= 0; i--) push32(r[i]);
    r15 = 0x40000000u;
    r9 = 0x21300u;
    iowr(r9, r15);
    r2 = 0x12c8u;
    r1 = 0x22a00u;
    r0 = 0x28170000u;
    goto L_477b;
    L_4770:; /* 0x4770 */
    iowr(r1, r0);
    CALL(sub_215e);
    CALL(sub_46eb);
    L_477b:; /* 0x477b */
    r9 = d32(r2);
    if (!(r9 != 0x0u)) {
        L_4781:; /* 0x4781 */
        r15 = 0x40000000u;
        r9 = 0x21900u;
        iowr(r9, r15);
        for (int i = 0; i <= 2; i++) r[i] = pop32();
        return;
    }
    goto L_4770;  /* 重复引用 */
}

/* ==== sub_478f  (被调用 2 次) ==== */
static void sub_478f(void) {
    L_478f:; /* 0x478f */
    for (int i = 0; i >= 0; i--) push32(r[i]);
    r9 = 0;
    r15 = 0x23c00u;
    r15 = iord(r15+r9*0x4);
    r14 = 0x13bcu;
    r15 = r15 + 0x1u;
    s32(r14, r15);
    r9 = -0x1u;
    fc_cmp(r15, r9);
    if (!!FZ(falcon_flags)) {
        L_47aa:; /* 0x47aa */
        r9 = 0x1u;
        s32(r14, r9);
        L_47ae:; /* 0x47ae */
        r0 = 0x13bcu;
        r11 = d32(r0);
        r10 = 0x23c00u;
        CALL(sub_10);
        r10 = d32(r0);
        for (int i = 0; i <= 0; i++) r[i] = pop32();
        return;
    }
    goto L_47ae;  /* 重复引用 */
}

/* ==== sub_47c0  (被调用 2 次) ==== */
static void sub_47c0(void) {
    L_47c0:; /* 0x47c0 */
    for (int i = 0; i >= 0; i--) push32(r[i]);
    r0 = r10;
    r10 = 0x3u;
    if (!(r0 == 0x0u)) {
        L_47ca:; /* 0x47ca */
        r10 = 0x5u;
        L_47cc:; /* 0x47cc */
        CALL(sub_791);
        r9 = 0x1314u;
        r10 = d32(r9);
        r9 = 0x1318u;
        r11 = d32(r9);
        r9 = 0x131cu;
        r12 = d32(r9);
        CALL(sub_32b9);
        r15 = 0x29160000u;
        r9 = 0x22a00u;
        iowr(r9, r15);
        r10 = 0x4u;
        CALL(sub_45b);
        r15 = 0x2c130000u;
        r9 = 0x22a00u;
        iowr(r9, r15);
        r10 = 0x24420u;
        r11 = 0;
        CALL(sub_10);
        CALL(sub_2c19);
        r10 = 0xfu;
        r11 = 0;
        CALL(sub_3ed);
        CALL(sub_2c19);
        r10 = 0x4u;
        r11 = 0x1u;
        CALL(sub_3ed);
        CALL(sub_2c19);
        CALL(sub_ed1);
        r10 = 0x1u;
        CALL(sub_415);
        CALL(sub_2c19);
        if (!(r0 != 0x0u)) {
            L_483c:; /* 0x483c */
            r10 = 0;
            CALL(sub_445);
            goto L_484c;
            L_4846:; /* 0x4846 */
            r10 = 0;
            CALL(sub_42f);
            L_484c:; /* 0x484c */
            CALL(sub_2c19);
            r10 = 0xfu;
            r11 = 0;
            CALL(sub_3ed);
            CALL(sub_2c19);
            r10 = 0x3u;
            r11 = 0x1u;
            CALL(sub_3ed);
            CALL(sub_2c19);
            r15 = 0x29160000u;
            r9 = 0x22a00u;
            iowr(r9, r15);
            r10 = 0x2u;
            CALL(sub_45b);
            for (int i = 0; i <= 0; i++) r[i] = pop32();
            return;
        }
        goto L_4846;  /* 重复引用 */
    }
    goto L_47cc;  /* 重复引用 */
}

/* ==== sub_487c  (被调用 2 次) ==== */
static void sub_487c(void) {
    L_487c:; /* 0x487c */
    for (int i = 2; i >= 0; i--) push32(r[i]);
    r15 = 0x1000u;
    r1 = r10;
    r0 = r11;
    r9 = 0x21300u;
    iowr(r9, r15);
    CALL(sub_ed1);
    r10 = 0x1u;
    CALL(sub_415);
    CALL(sub_2c19);
    r11 = 0;
    r10 = 0xfu;
    CALL(sub_3ed);
    CALL(sub_2c19);
    r11 = 0x1u;
    r10 = r0;
    CALL(sub_3ed);
    CALL(sub_2c19);
    r10 = 0;
    CALL(sub_2c8c);
    CALL(sub_2c19);
    r10 = 0xfu;
    r11 = 0;
    CALL(sub_3ed);
    CALL(sub_2c19);
    r10 = 0x3u;
    r11 = 0x1u;
    CALL(sub_3ed);
    CALL(sub_2c19);
    r10 = 0;
    CALL(sub_415);
    CALL(sub_2c19);
    if (!(r0 == 0x4u)) {
        L_48e2:; /* 0x48e2 */
        r10 = r1;
        r0 = 0;
        r11 = 0x24400u;
        r12 = 0x104u;
        r2 = 0;
        r1 = 0x24420u;
        L_48f3:; /* 0x48f3 */
        r13 = iord(r11+r2*0x4);
        r15 = 0x1000u;
        r9 = r12 >> 0x2u;
        r9 <<= 0x2u;
        r9 = r9 + r15;
        if (!(r13 == 0x0u)) {
            L_4907:; /* 0x4907 */
            s32(r9, r10);
            r13 <<= 0x2u;
            r15 = r13 >> 0x8u;
            r9 = r15 + 0x1u;
            r9 <<= 0x8u;
            r14 = r10 + 0x1u;
            r0 = r0 + r9;
            r10 = r14 + r15;
            r9 = r12 + 0x4u;
            r15 = 0x1000u;
            r9 >>= 0x2u;
            r9 <<= 0x2u;
            r9 = r9 + r15;
            s32(r9, r13);
            L_4930:; /* 0x4930 */
            r11 = r11 + 0x4u;
            r12 = r12 + 0x8u;
            fc_cmp(r11, r1);
            if (!!FZ(falcon_flags)) {
                L_493b:; /* 0x493b */
                goto L_4998;
                L_493f:; /* 0x493f */
                r10 = r1;
                r0 = 0;
                r11 = 0x24400u;
                r12 = 0xa4u;
                r2 = 0;
                r1 = 0x24420u;
                L_4950:; /* 0x4950 */
                r13 = iord(r11+r2*0x4);
                r15 = 0x1000u;
                r9 = r12 >> 0x2u;
                r9 <<= 0x2u;
                r9 = r9 + r15;
                if (!(r13 == 0x0u)) {
                    L_4964:; /* 0x4964 */
                    s32(r9, r10);
                    r13 <<= 0x2u;
                    r15 = r13 >> 0x8u;
                    r9 = r15 + 0x1u;
                    r9 <<= 0x8u;
                    r14 = r10 + 0x1u;
                    r0 = r0 + r9;
                    r10 = r14 + r15;
                    r9 = r12 + 0x4u;
                    r15 = 0x1000u;
                    r9 >>= 0x2u;
                    r9 <<= 0x2u;
                    r9 = r9 + r15;
                    s32(r9, r13);
                    L_498d:; /* 0x498d */
                    r11 = r11 + 0x4u;
                    r12 = r12 + 0x8u;
                    fc_cmp(r11, r1);
                    if (!FZ(falcon_flags)) goto L_4950;
                    L_4998:; /* 0x4998 */
                    r15 = 0x1000u;
                    r9 = 0x21900u;
                    iowr(r9, r15);
                    r10 = r0;
                    for (int i = 0; i <= 2; i++) r[i] = pop32();
                    return;
                }
                goto L_498d;  /* 重复引用 */
            }
            goto L_48f3;  /* 重复引用 */
        }
        goto L_4930;  /* 重复引用 */
        goto L_48f3;  /* 重复引用 */
        goto L_4907;  /* 重复引用 */
        goto L_4930;  /* 重复引用 */
        goto L_493b;  /* 重复引用 */
    }
    goto L_493f;  /* 重复引用 */
}

/* ==== sub_49a6  (被调用 2 次) ==== */
static void sub_49a6(void) {
    L_49a6:; /* 0x49a6 */
    r15 = 0x1604u;
    r15 = d32(r15);
    sp += -0x34u;
    for (int i = 8; i >= 0; i--) push32(r[i]);
    r9 = sp;
    r9 = r9 + 0x54u;
    r8 = r11;
    s32(r9, r15);
    r15 = 0x200u;
    r9 = 0x21200u;
    iowr(r9, r15);
    r9 = 0x24u;
    r10 = d32(r9);
    r1 = 0x1280u;
    CALL(sub_114);
    r10 = 0x1u;
    CALL(sub_29c6);
    r10 = 0x1u;
    r11 = r10;
    r12 = r10;
    CALL(sub_cf5);
    CALL(sub_290c);
    r10 = 0;
    CALL(sub_2988);
    r10 = 0x1u;
    CALL(sub_97a);
    r9 = 0x1284u;
    s32(r1, r10);
    s32(r9, r10);
    r15 = 0x22000u;
    r9 = 0;
    r15 = iord(r15+r9*0x4);
    r0 = 0x1000u;
    r9 = d32(r0+0x4);
    r10 = 0;
    r11 = 0x3u;
    r12 = 0x1u;
    r9 &= 0x20u;
    r15 |= r9;
    s32(r0+0x4, r15);
    CALL(sub_487c);
    r15 = d32(r1);
    r9 = 0x1288u;
    r14 = 0x28000u;
    s32(r9, r10);
    r10 = r10 + r15;
    r15 = 0x28028u;
    s32(r0, r10);
    L_4a33:; /* 0x4a33 */
    r13 = 0xfffd8034u;
    r9 = r14 + r13;
    r9 = d32(r9);
    r9 &= 0x7u;
    r9 <<= 0x4u;
    r9 |= 0x8u;
    iowr(r14, r9);
    r14 = r14 + 0x4u;
    fc_cmp(r14, r15);
    if (!!FZ(falcon_flags)) {
        L_4a51:; /* 0x4a51 */
        r0 = 0x14a0u;
        r9 = d32(r0);
        r1 = 0x1280u;
        r6 = r0;
        r5 = r1;
        r9 <<= 0x9u;
        r9 = r9 + 0x400u;
        r9 = r9 + r10;
        s32(r1, r9);
        CALL(sub_2175);
        r9 = d32(r0);
        r15 = 0x1284u;
        r15 = d32(r15);
        r14 = 0x1000u;
        r9 = r9 + 0x2u;
        r9 <<= 0x1u;
        s32(r14+0x10, r15);
        r9 &= 0xfffeu;
        r15 = (r15 >> 8) & 0xffu;
        r15 <<= 0x10u;
        r9 |= r15;
        s32(r14+0xc, r9);
        r9 = 0x1288u;
        r9 = d32(r9);
        r10 = 0x41a800u;
        r11 = 0;
        r3 = d32(r1);
        s32(r14+0x14, r9);
        CALL(sub_237);
        r10 = 0x10u;
        r11 = 0;
        r4 = sp;
        CALL(sub_cc5);
        r4 = r4 + 0x24u;
        CALL(sub_23fc);
        r2 = 0;
        r1 = r4;
        r0 = 0x502800u;
        goto L_4ae2;
        L_4ac8:; /* 0x4ac8 */
        r10 = r0;
        CALL(sub_297);
        r9 = d32(r5);
        s32(r1, r10);
        r2 = r2 + 0x1u;
        r0 = r0 + 0x8000u;
        r10 = r10 + r9;
        r1 = r1 + 0x4u;
        s32(r5, r10);
        L_4ae2:; /* 0x4ae2 */
        r9 = d32(r6);
        r13 = 0x1280u;
        fc_cmp(r2, r9);
        if (!FC(falcon_flags)) {
            L_4aed:; /* 0x4aed */
            r14 = d32(r13);
            r15 = r9 + r9;
            r15 = r15 + r9;
            r15 = r15 + 0x1u;
            r9 = r15 << 0x8u;
            r9 = r9 + r14;
            s32(r13, r9);
            r9 = 0x10000u;
            r14 >>= 0x8u;
            r15 &= 0xffu;
            r13 = r14 & 0xffffu;
            r15 <<= 0x10u;
            r15 |= r13;
            r13 |= r9;
            r9 = 0x1000u;
            s32(r9+0xf0, r13);
            r9 = 0xe00u;
            r0 = 0x12a0u;
            r10 = 0x41a800u;
            s32(r0, r14);
            r11 = 0;
            s32(r9+0xec, r15);
            CALL(sub_237);
            r7 = r0;
            r10 = 0x10500u;
            r11 = 0;
            r3 >>= 0x8u;
            CALL(sub_10);
            r1 = 0;
            r2 = 0;
            r0 = 0x502810u;
            r6 = 0x14a0u;
            r5 = 0x30000u;
            goto L_4b99;
            L_4b58:; /* 0x4b58 */
            r11 = d32(r7);
            r10 = r0;
            r1 = r1 + 0x1u;
            r11 = r11 + 0x1u;
            r11 = r11 + r2;
            r11 &= 0xffffu;
            r11 |= r5;
            CALL(sub_237);
            r10 = r0 - 0x310u;
            r11 = r3;
            CALL(sub_237);
            r10 = r0 - 0x30cu;
            r11 = 0x14u;
            CALL(sub_237);
            r9 = d32(r4);
            r2 = r2 + 0x3u;
            r0 = r0 + 0x8000u;
            r4 = r4 + 0x4u;
            r9 >>= 0x8u;
            r3 = r3 + r9;
            L_4b99:; /* 0x4b99 */
            r9 = d32(r6);
            fc_cmp(r1, r9);
            if (!FC(falcon_flags)) {
                L_4ba0:; /* 0x4ba0 */
                CALL(sub_23fc);
                r15 = 0x1280u;
                r9 = d32(r15);
                fc_cmp(r8, r9);
                if (!(FC(falcon_flags) || FZ(falcon_flags))) {
                    L_4baf:; /* 0x4baf */
                    s32(r15, r8);
                    L_4bb1:; /* 0x4bb1 */
                    r9 = 0x1280u;
                    r9 = d32(r9);
                    r15 = 0xe00u;
                    r10 = 0x2u;
                    s32(r15+0x4, r9);
                    r9 = 0x14a0u;
                    r9 = d32(r9);
                    s32(r15+0x8, r9);
                    r9 = 0x14a4u;
                    r9 = d32(r9);
                    s32(r15+0x34, r9);
                    CALL(sub_45b);
                    r10 = 0;
                    CALL(sub_29c6);
                    r10 = 0x1u;
                    r11 = r10;
                    r12 = r10;
                    CALL(sub_c7b);
                    CALL(sub_290c);
                    r10 = 0;
                    CALL(sub_2988);
                    r15 = 0;
                    r9 = 0x10c00u;
                    iowr(r9, r15);
                    r9 = 0x1280u;
                    r15 = d32(r9);
                    r9 = 0x20000u;
                    iowr(r9, r15);
                    r15 = 0x200u;
                    r9 = r9 + 0x1800u;
                    iowr(r9, r15);
                    r9 = sp;
                    r9 = r9 + 0x54u;
                    r15 = d32(r9);
                    r9 = 0x1604u;
                    r9 = d32(r9);
                    fc_cmp(r15, r9);
                    if (!FZ(falcon_flags)) {
                        L_4c24:; /* 0x4c24 */
                        CALL(sub_747);
                        L_4c28:; /* 0x4c28 */
                        for (int i = 0; i <= 8; i++) r[i] = pop32();
                        sp += 0x34;
                        return;
                    }
                    goto L_4c28;  /* 重复引用 */
                }
                goto L_4bb1;  /* 重复引用 */
                goto L_4baf;  /* 重复引用 */
                goto L_4bb1;  /* 重复引用 */
                goto L_4c24;  /* 重复引用 */
                goto L_4c28;  /* 重复引用 */
            }
            goto L_4b58;  /* 重复引用 */
            goto L_4b58;  /* 重复引用 */
            goto L_4b99;  /* 重复引用 */
            goto L_4ba0;  /* 重复引用 */
            goto L_4baf;  /* 重复引用 */
            goto L_4bb1;  /* 重复引用 */
            goto L_4c24;  /* 重复引用 */
            goto L_4c28;  /* 重复引用 */
        }
        goto L_4ac8;  /* 重复引用 */
        goto L_4ac8;  /* 重复引用 */
        goto L_4ae2;  /* 重复引用 */
        goto L_4aed;  /* 重复引用 */
        goto L_4b58;  /* 重复引用 */
        goto L_4b99;  /* 重复引用 */
        goto L_4ba0;  /* 重复引用 */
        goto L_4baf;  /* 重复引用 */
        goto L_4bb1;  /* 重复引用 */
        goto L_4c24;  /* 重复引用 */
        goto L_4c28;  /* 重复引用 */
    }
    goto L_4a33;  /* 重复引用 */
}

/* ==== sub_4c2b  (被调用 2 次) ==== */
static void sub_4c2b(void) {
    L_4c2b:; /* 0x4c2b */
    r15 = 0x1604u;
    r15 = d32(r15);
    sp += -0x34u;
    for (int i = 7; i >= 0; i--) push32(r[i]);
    r9 = sp;
    r9 = r9 + 0x50u;
    r7 = r11;
    s32(r9, r15);
    r15 = 0x8u;
    r9 = 0x21400u;
    iowr(r9, r15);
    r9 = 0x1280u;
    r15 = d32(r9);
    r9 = 0x24u;
    r10 = d32(r9);
    r2 = 0x129cu;
    r15 = r15 + 0x1000u;
    s32(r2, r15);
    CALL(sub_114);
    r1 = 0;
    r10 = 0x1u;
    s32(r2, r1);
    CALL(sub_29c6);
    r10 = 0x1u;
    r11 = r10;
    r12 = r10;
    CALL(sub_cf5);
    r11 = 0x4u;
    r12 = 0x1u;
    s32(r2, r1);
    r10 = 0;
    CALL(sub_487c);
    r9 = 0x12b4u;
    r0 = r10;
    s32(r9, r1);
    r10 = 0x2u;
    CALL(sub_45b);
    r9 = d32(r2);
    r15 = 0x28000u;
    r14 = 0x28028u;
    r0 = r0 + r9;
    r9 = 0x1000u;
    s32(r2, r0);
    s32(r9+0x94, r0);
    L_4ca8:; /* 0x4ca8 */
    r13 = 0xfffd8034u;
    r9 = r15 + r13;
    r9 = d32(r9);
    r9 &= 0x7u;
    r9 <<= 0x4u;
    r9 |= 0x8u;
    iowr(r15, r9);
    r15 = r15 + 0x4u;
    fc_cmp(r15, r14);
    if (!!FZ(falcon_flags)) {
        L_4cc6:; /* 0x4cc6 */
        r10 = 0x41a800u;
        r11 = 0;
        CALL(sub_237);
        r10 = 0x1au;
        r11 = 0;
        CALL(sub_cc5);
        CALL(sub_23fc);
        r9 = 0x129cu;
        r10 = sp;
        r6 = r9;
        r10 = r10 + 0x20u;
        r4 = d32(r9);
        r3 = r10;
        r11 = 0;
        r12 = 0x30u;
        r2 = r3;
        CALL(sub_77e8);
        r1 = 0;
        r0 = 0x502800u;
        r5 = 0x14a0u;
        goto L_4d1e;
        L_4d04:; /* 0x4d04 */
        r10 = r0;
        CALL(sub_297);
        r9 = d32(r6);
        s32(r2, r10);
        r1 = r1 + 0x1u;
        r0 = r0 + 0x8000u;
        r10 = r10 + r9;
        r2 = r2 + 0x4u;
        s32(r6, r10);
        L_4d1e:; /* 0x4d1e */
        r9 = d32(r5);
        fc_cmp(r1, r9);
        if (!FC(falcon_flags)) {
            L_4d25:; /* 0x4d25 */
            r10 = 0x41a800u;
            r11 = 0;
            CALL(sub_237);
            r2 = r4 >> 0x8u;
            r10 = 0x10500u;
            r11 = 0;
            r1 = 0;
            CALL(sub_10);
            r0 = 0x502500u;
            r4 = 0x14a0u;
            goto L_4d6e;
            L_4d4a:; /* 0x4d4a */
            r10 = r0;
            r11 = r2;
            CALL(sub_237);
            r10 = r0 + 0x4u;
            r11 = 0x1du;
            CALL(sub_237);
            r9 = d32(r3);
            r1 = r1 + 0x1u;
            r0 = r0 + 0x8000u;
            r3 = r3 + 0x4u;
            r9 >>= 0x8u;
            r2 = r2 + r9;
            L_4d6e:; /* 0x4d6e */
            r9 = d32(r4);
            fc_cmp(r1, r9);
            if (!FC(falcon_flags)) {
                L_4d75:; /* 0x4d75 */
                r15 = 0x129cu;
                r9 = d32(r15);
                fc_cmp(r7, r9);
                if (!(FC(falcon_flags) || FZ(falcon_flags))) {
                    L_4d80:; /* 0x4d80 */
                    s32(r15, r7);
                    L_4d82:; /* 0x4d82 */
                    r15 = 0x129cu;
                    r15 = d32(r15);
                    r9 = 0xe00u;
                    r10 = 0x1u;
                    r11 = r10;
                    r12 = r10;
                    s32(r9+0x6c, r15);
                    CALL(sub_c7b);
                    r10 = 0;
                    CALL(sub_2988);
                    r15 = 0;
                    r9 = 0x10c00u;
                    iowr(r9, r15);
                    r9 = 0x129cu;
                    r15 = d32(r9);
                    r9 = 0x20000u;
                    iowr(r9, r15);
                    r15 = 0x8u;
                    r9 = r9 + 0x1a00u;
                    iowr(r9, r15);
                    r9 = sp;
                    r9 = r9 + 0x50u;
                    r15 = d32(r9);
                    r9 = 0x1604u;
                    r9 = d32(r9);
                    fc_cmp(r15, r9);
                    if (!FZ(falcon_flags)) {
                        L_4dd2:; /* 0x4dd2 */
                        CALL(sub_747);
                        L_4dd6:; /* 0x4dd6 */
                        for (int i = 0; i <= 7; i++) r[i] = pop32();
                        sp += 0x34;
                        return;
                    }
                    goto L_4dd6;  /* 重复引用 */
                }
                goto L_4d82;  /* 重复引用 */
                goto L_4d80;  /* 重复引用 */
                goto L_4d82;  /* 重复引用 */
                goto L_4dd2;  /* 重复引用 */
                goto L_4dd6;  /* 重复引用 */
            }
            goto L_4d4a;  /* 重复引用 */
            goto L_4d4a;  /* 重复引用 */
            goto L_4d6e;  /* 重复引用 */
            goto L_4d75;  /* 重复引用 */
            goto L_4d80;  /* 重复引用 */
            goto L_4d82;  /* 重复引用 */
            goto L_4dd2;  /* 重复引用 */
            goto L_4dd6;  /* 重复引用 */
        }
        goto L_4d04;  /* 重复引用 */
        goto L_4d04;  /* 重复引用 */
        goto L_4d1e;  /* 重复引用 */
        goto L_4d25;  /* 重复引用 */
        goto L_4d4a;  /* 重复引用 */
        goto L_4d6e;  /* 重复引用 */
        goto L_4d75;  /* 重复引用 */
        goto L_4d80;  /* 重复引用 */
        goto L_4d82;  /* 重复引用 */
        goto L_4dd2;  /* 重复引用 */
        goto L_4dd6;  /* 重复引用 */
    }
    goto L_4ca8;  /* 重复引用 */
}

/* ==== sub_4dd9  (被调用 2 次) ==== */
static void sub_4dd9(void) {
    L_4dd9:; /* 0x4dd9 */
    sp += -0x8u;
    r15 = 0;
    for (int i = 8; i >= 0; i--) push32(r[i]);
    r9 = 0x2de00u;
    sp += -0xcu;
    r5 = r11;
    r7 = r12;
    r14 = iord(r9+r15*0x4);
    r15 = 0x20u;
    r9 = 0x21200u;
    iowr(r9, r15);
    r9 = r11 >> 0x1fu;
    if (!(r9 != 0x1u)) {
        L_4dff:; /* 0x4dff */
        r9 = 0xfffffffu;
        r1 = r11 & r9;
        r9 = (r11 >> 28) & 0x3u;
        s32(sp+0x34, r9);
        if (!(r12 != 0x2u)) {
            L_4e11:; /* 0x4e11 */
            r9 = 0x3fffffffu;
            r15 = 0x22e00u;
            r9 = r11 & r9;
            iowr(r15, r9);
            r15 = 0x3u;
            r9 = 0x22f00u;
            iowr(r9, r15);
            L_4e29:; /* 0x4e29 */
            r9 = r14 & 0x3fu;
            r10 = 0x28e00u;
            r6 = r9 << 0x18u;
            r11 = 0;
            CALL(sub_10);
            r10 = 0x28f00u;
            r8 = r6 | 0x40u;
            r11 = r8;
            CALL(sub_10);
            r10 = 0x28900u;
            r11 = 0;
            CALL(sub_10);
            r0 = 0x90000000u;
            r9 = 0x2c100u;
            r0 = r1 | r0;
            iowr(r9, r0);
            r10 = 0x28300u;
            r11 = r0;
            CALL(sub_10);
            r10 = 0x28400u;
            r11 = 0x7u;
            CALL(sub_10);
            CALL(sub_41a0);
            r12 = r8;
            r10 = 0;
            r11 = 0;
            CALL(sub_32b9);
            r14 = d32(sp+0x34);
            r9 = 0x1u;
            s32(sp+0x4, r9);
            s32(sp, r9);
            r9 = 0x2u;
            r1 <<= 0x4u;
            s32(sp+0x8, r9);
            r10 = r1;
            s32(sp+0x30, r1);
            r12 = 0x6u;
            r13 = 0xa00u;
            r11 = 0x200u;
            CALL(sub_2de1);
            r9 = 0xa00u;
            r14 = d32(r9+0x10);
            r13 = d32(r9);
            r12 = d32(r9+0x14);
            r10 = d32(r9+0x18);
            r15 = d32(r9+0x4);
            r9 = -0x1000u;
            r13 &= r9;
            r14 &= r9;
            r9 = 0x12e0u;
            r12 <<= 0x18u;
            r14 >>= 0x8u;
            r14 |= r12;
            s32(r9, r14);
            r9 = 0x12e4u;
            r14 = 0;
            s32(r9, r14);
            r9 = 0x1448u;
            r15 <<= 0x18u;
            r13 >>= 0x8u;
            r13 |= r15;
            s32(r9, r13);
            r9 = 0x12ecu;
            r11 = r10 + 0x40u;
            s32(r9, r10);
            r11 &= 0xffu;
            r9 = 0x12e8u;
            r15 = r10 & 0x3fu;
            r15 <<= 0x10u;
            r15 |= r11;
            r15 |= r6;
            r10 = 0x28e00u;
            s32(r9, r15);
            r11 = 0;
            CALL(sub_10);
            r10 = 0x28900u;
            r11 = 0;
            CALL(sub_10);
            r9 = 0x2c100u;
            iowr(r9, r5);
            r10 = 0x28300u;
            r11 = r5;
            r0 = 0xa98u;
            CALL(sub_10);
            r3 = 0;
            r4 = 0x20u;
            goto L_4f8b;
            L_4f36:; /* 0x4f36 */
            r2 = 0;
            L_4f38:; /* 0x4f38 */
            r15 = d32(r0);
            r9 = 0x1u;
            r9 <<= r2;
            r9 &= r15;
            if (!FZ(falcon_flags)) {
                L_4f45:; /* 0x4f45 */
                r9 = r1 & 0x3fu;
                r9 <<= 0x10u;
                r9 |= r6;
                r11 = r1 + 0x40u;
                r10 = 0x28f00u;
                r11 &= 0xffu;
                r11 = r9 | r11;
                CALL(sub_10);
                r10 = 0x28400u;
                r11 = 0x7u;
                CALL(sub_10);
                CALL(sub_41a0);
                r9 = 0x2c000u;
                iowr(r9, r5);
                r3 = r3 + 0x1u;
                L_4f77:; /* 0x4f77 */
                r1 = r1 + 0x1u;
                r2 = r2 + 0x1u;
                if ((r2 != 0x20u)) goto L_4f38;
                L_4f81:; /* 0x4f81 */
                r4 = r4 + 0x20u;
                r0 = r0 + 0x4u;
                if ((r4 == 0x60u)) goto L_4fda;
                L_4f8b:; /* 0x4f8b */
                r1 = r4 - 0x20u;
                if (!(r7 != 0x4u)) {
                    L_4f92:; /* 0x4f92 */
                    r2 = 0;
                    L_4f94:; /* 0x4f94 */
                    r15 = d32(r0);
                    r9 = 0x1u;
                    r9 <<= r2;
                    r2 = r2 + 0x1u;
                    r9 &= r15;
                    if (!FZ(falcon_flags)) {
                        L_4fa4:; /* 0x4fa4 */
                        r9 = r1 & 0x3fu;
                        r9 <<= 0x10u;
                        r9 |= r6;
                        r10 = 0x28f00u;
                        r11 = r1 + 0x40u;
                        r11 &= 0xffu;
                        r11 = r9 | r11;
                        CALL(sub_10);
                        r10 = 0x28400u;
                        r11 = 0x7u;
                        r3 = r3 + 0x1u;
                        CALL(sub_10);
                        CALL(sub_41a0);
                        L_4fcf:; /* 0x4fcf */
                        r1 = r1 + 0x1u;
                        if (!(r2 != 0x20u)) {
                            L_4fd6:; /* 0x4fd6 */
                            goto L_4f81;
                            L_4fda:; /* 0x4fda */
                            if (!(r3 != 0x0u)) {
                                L_4fde:; /* 0x4fde */
                                if (!(r7 != 0x4u)) {
                                    L_4fe2:; /* 0x4fe2 */
                                    r1 = 0;
                                    L_4fe4:; /* 0x4fe4 */
                                    r9 = r1 & 0x3fu;
                                    r9 <<= 0x10u;
                                    r9 |= r6;
                                    r11 = r1 + 0x40u;
                                    r10 = 0x28f00u;
                                    r11 &= 0xffu;
                                    r11 = r9 | r11;
                                    CALL(sub_10);
                                    r10 = 0x28400u;
                                    r11 = 0x7u;
                                    r1 = r1 + 0x1u;
                                    CALL(sub_10);
                                    CALL(sub_41a0);
                                    if (!(r1 != 0x40u)) {
                                        L_5013:; /* 0x5013 */
                                        goto L_504f;
                                        L_5017:; /* 0x5017 */
                                        r1 = 0;
                                        r2 = 0x2c000u;
                                        L_501d:; /* 0x501d */
                                        r9 = r1 & 0x3fu;
                                        r9 <<= 0x10u;
                                        r9 |= r6;
                                        r11 = r1 + 0x40u;
                                        r10 = 0x28f00u;
                                        r11 &= 0xffu;
                                        r11 = r9 | r11;
                                        CALL(sub_10);
                                        r10 = 0x28400u;
                                        r11 = 0x7u;
                                        CALL(sub_10);
                                        CALL(sub_41a0);
                                        iowr(r2, r5);
                                        r1 = r1 + 0x1u;
                                        if ((r1 != 0x40u)) goto L_501d;
                                        L_504f:; /* 0x504f */
                                        CALL(sub_31cf);
                                        r10 = 0x28e00u;
                                        r11 = 0;
                                        CALL(sub_10);
                                        if (!(r7 != 0x1u)) {
                                            L_5062:; /* 0x5062 */
                                            CALL(sub_478f);
                                            r9 = 0x13f0u;
                                            r15 = d32(r9);
                                            r9 = 0x13c0u;
                                            s32(r9, r10);
                                            if (!(r15 == 0x0u)) {
                                                L_5076:; /* 0x5076 */
                                                r15 = 0;
                                                r9 = 0x13f4u;
                                                s32(r9, r15);
                                                L_507e:; /* 0x507e */
                                                r15 = 0x13c0u;
                                                r15 = d32(r15);
                                                r9 = 0xe00u;
                                                r10 = 0x1u;
                                                r1 = 0xa00u;
                                                s32(r9+0xf0, r15);
                                                CALL(sub_1070);
                                                r12 = r8;
                                                r10 = 0;
                                                r11 = 0;
                                                CALL(sub_32b9);
                                                r14 = d32(sp+0x34);
                                                r10 = d32(sp+0x30);
                                                r3 = 0x1u;
                                                r2 = 0x2u;
                                                r13 = r1;
                                                s32(sp, r3);
                                                s32(sp+0x4, r3);
                                                s32(sp+0x8, r2);
                                                r11 = 0x200u;
                                                r12 = 0x6u;
                                                CALL(sub_2de1);
                                                r14 = d32(r1+0x10);
                                                r13 = d32(r1);
                                                r11 = d32(r1+0x14);
                                                r15 = d32(r1+0x18);
                                                r12 = d32(r1+0x4);
                                                r9 = -0x1000u;
                                                r13 &= r9;
                                                r14 &= r9;
                                                r9 = 0x12e0u;
                                                r11 <<= 0x18u;
                                                r14 >>= 0x8u;
                                                r14 |= r11;
                                                s32(r9, r14);
                                                r9 = 0x12e4u;
                                                r10 = r14;
                                                r14 = 0;
                                                s32(r9, r14);
                                                r9 = 0x1448u;
                                                r4 = 0x12ecu;
                                                r0 = r15 + 0x40u;
                                                s32(r4, r15);
                                                r0 &= 0xffu;
                                                r12 <<= 0x18u;
                                                r13 >>= 0x8u;
                                                r15 &= 0x3fu;
                                                r13 |= r12;
                                                r15 <<= 0x10u;
                                                s32(r9, r13);
                                                r15 |= r0;
                                                r9 = 0x12e8u;
                                                r15 |= r6;
                                                r11 = 0;
                                                r12 = r15;
                                                s32(r9, r15);
                                                CALL(sub_32b9);
                                                r13 = r1;
                                                r10 = 0;
                                                r11 = 0;
                                                r12 = 0x6u;
                                                r14 = 0;
                                                s32(sp+0x4, r3);
                                                s32(sp+0x8, r2);
                                                s32(sp, r2);
                                                CALL(sub_2de1);
                                                CALL(sub_31cf);
                                                r9 = d32(r1+0x7c);
                                                r15 = d32(r1+0x78);
                                                r14 = d32(r4);
                                                r9 >>= 0x8u;
                                                r12 = (r15 >> 8) & 0x1ffu;
                                                r15 <<= 0x18u;
                                                r15 |= r9;
                                                r9 = 0x1438u;
                                                s32(r9, r15);
                                                r9 = 0x143cu;
                                                s32(r9, r12);
                                                r9 = 0x1440u;
                                                r13 = r14 + 0x40u;
                                                r15 = 0xc0ffeeb2u;
                                                r13 &= 0xffu;
                                                r14 &= 0x3fu;
                                                r14 <<= 0x10u;
                                                r14 |= r13;
                                                r14 |= r6;
                                                s32(r9, r14);
                                                r9 = 0x20a00u;
                                                iowr(r9, r15);
                                                r9 = 0x1438u;
                                                r15 = d32(r9);
                                                r9 = 0x20a00u;
                                                iowr(r9, r15);
                                                r9 = 0x143cu;
                                                r15 = d32(r9);
                                                r9 = 0x20a00u;
                                                iowr(r9, r15);
                                                iowr(r9, r14);
                                                r9 = 0xa00u;
                                                r9 = d32(r9+0xc);
                                                r15 = 0x1444u;
                                                r9 &= 0x3fu;
                                                s32(r15, r9);
                                                r15 = 0x20a00u;
                                                iowr(r15, r9);
                                                if (!(r9 != 0x21u)) {
                                                    L_51ba:; /* 0x51ba */
                                                    r15 = 0x1438u;
                                                    r15 = d32(r15);
                                                    r9 = 0x12e0u;
                                                    s32(r9, r15);
                                                    r15 = 0x143cu;
                                                    r15 = d32(r15);
                                                    r9 = 0x12e4u;
                                                    s32(r9, r15);
                                                    r15 = 0x1440u;
                                                    r15 = d32(r15);
                                                    r9 = 0x12e8u;
                                                    s32(r9, r15);
                                                    L_51de:; /* 0x51de */
                                                    r9 = 0x12e8u;
                                                    r0 = 0x12e0u;
                                                    r12 = d32(r9);
                                                    r1 = 0x12e4u;
                                                    r10 = d32(r0);
                                                    r11 = d32(r1);
                                                    CALL(sub_32b9);
                                                    r14 = 0xe00u;
                                                    r15 = d32(r14+0xc);
                                                    r9 = 0x600dc0deu;
                                                    s32(r14+0xfc, r9);
                                                    r9 = 0xcafe0000u;
                                                    r15 &= 0xffffu;
                                                    r15 |= r9;
                                                    r9 = 0xdeadce11u;
                                                    r10 = 0x2u;
                                                    s32(r14+0x100, r9);
                                                    r9 = 0xfaceb00cu;
                                                    s32(r14+0xc, r15);
                                                    s32(r14+0x1fc, r9);
                                                    CALL(sub_2f4a);
                                                    CALL(sub_31cf);
                                                    r10 = 0x28400u;
                                                    r11 = 0x5u;
                                                    CALL(sub_10);
                                                    r9 = 0x12ecu;
                                                    r11 = d32(r9);
                                                    r10 = 0x41a814u;
                                                    CALL(sub_237);
                                                    r11 = d32(r0);
                                                    r10 = 0x13u;
                                                    CALL(sub_cc5);
                                                    CALL(sub_23fc);
                                                    r11 = d32(r1);
                                                    r10 = 0x1eu;
                                                    CALL(sub_cc5);
                                                    CALL(sub_23fc);
                                                    CALL(sub_31cf);
                                                    L_5260:; /* 0x5260 */
                                                    r15 = 0x20u;
                                                    r9 = 0x21800u;
                                                    iowr(r9, r15);
                                                    sp += 0xcu;
                                                    for (int i = 0; i <= 8; i++) r[i] = pop32();
                                                    sp += 0x8;
                                                    return;
                                                }
                                                goto L_51de;  /* 重复引用 */
                                            }
                                            goto L_507e;  /* 重复引用 */
                                            goto L_5076;  /* 重复引用 */
                                            goto L_507e;  /* 重复引用 */
                                            goto L_51ba;  /* 重复引用 */
                                            goto L_51de;  /* 重复引用 */
                                        }
                                        goto L_5260;  /* 重复引用 */
                                    }
                                    goto L_4fe4;  /* 重复引用 */
                                    goto L_4fe4;  /* 重复引用 */
                                    goto L_5013;  /* 重复引用 */
                                }
                                goto L_5017;  /* 重复引用 */
                                goto L_4fe2;  /* 重复引用 */
                                goto L_4fe4;  /* 重复引用 */
                                goto L_5013;  /* 重复引用 */
                                goto L_5017;  /* 重复引用 */
                                goto L_501d;  /* 重复引用 */
                            }
                            goto L_504f;  /* 重复引用 */
                        }
                        goto L_4f94;  /* 重复引用 */
                    }
                    goto L_4fcf;  /* 重复引用 */
                    goto L_4f94;  /* 重复引用 */
                    goto L_4fa4;  /* 重复引用 */
                    goto L_4fcf;  /* 重复引用 */
                    goto L_4fd6;  /* 重复引用 */
                }
                goto L_4f36;  /* 重复引用 */
            }
            goto L_4f77;  /* 重复引用 */
        }
        goto L_4e29;  /* 重复引用 */
        goto L_4e11;  /* 重复引用 */
        goto L_4e29;  /* 重复引用 */
        goto L_4f36;  /* 重复引用 */
        goto L_4f38;  /* 重复引用 */
        goto L_4f45;  /* 重复引用 */
        goto L_4f77;  /* 重复引用 */
        goto L_4f81;  /* 重复引用 */
        goto L_4f8b;  /* 重复引用 */
        goto L_4f92;  /* 重复引用 */
        goto L_4f94;  /* 重复引用 */
        goto L_4fa4;  /* 重复引用 */
        goto L_4fcf;  /* 重复引用 */
        goto L_4fd6;  /* 重复引用 */
        goto L_4fda;  /* 重复引用 */
        goto L_4fde;  /* 重复引用 */
        goto L_4fe2;  /* 重复引用 */
        goto L_4fe4;  /* 重复引用 */
        goto L_5013;  /* 重复引用 */
        goto L_5017;  /* 重复引用 */
        goto L_501d;  /* 重复引用 */
        goto L_504f;  /* 重复引用 */
        goto L_5062;  /* 重复引用 */
        goto L_5076;  /* 重复引用 */
        goto L_507e;  /* 重复引用 */
        goto L_51ba;  /* 重复引用 */
        goto L_51de;  /* 重复引用 */
    }
    goto L_5260;  /* 重复引用 */
}

/* ==== sub_526f  (被调用 2 次) ==== */
static void sub_526f(void) {
    L_526f:; /* 0x526f */
    r9 = 0xe00u;
    r14 = d32(r9+0x78);
    r13 = d32(r9+0x7c);
    r9 = 0x12ecu;
    r15 = d32(r9);
    for (int i = 0; i >= 0; i--) push32(r[i]);
    r13 >>= 0x8u;
    r0 = (r14 >> 8) & 0x1ffu;
    r9 = r15 + 0x40u;
    r9 &= 0xffu;
    r15 &= 0x3fu;
    r15 <<= 0x10u;
    r15 |= r9;
    r9 = 0x1438u;
    r14 <<= 0x18u;
    r14 |= r13;
    s32(r9, r14);
    r9 = 0x143cu;
    s32(r9, r0);
    r9 = 0x1440u;
    sp += -0xcu;
    r11 &= 0x3fu;
    r11 <<= 0x18u;
    r15 |= r11;
    s32(r9, r15);
    r9 = 0x20a00u;
    iowr(r9, r14);
    iowr(r9, r0);
    iowr(r9, r15);
    r9 = 0x12e0u;
    s32(r9, r14);
    r9 = 0x12e4u;
    s32(r9, r0);
    r9 = 0x12e8u;
    r12 = r15;
    s32(r9, r15);
    r10 = r14;
    r11 = r0;
    CALL(sub_32b9);
    r9 = 0x2u;
    r11 = 0;
    r13 = 0xa00u;
    r14 = 0;
    r10 = 0;
    r12 = 0x6u;
    s32(sp+0x8, r9);
    s32(sp, r9);
    r9 = 0x1u;
    s32(sp+0x4, r9);
    CALL(sub_2de1);
    CALL(sub_31cf);
    r9 = 0xe00u;
    r13 = d32(r9+0x18);
    r15 = 0xa00u;
    r14 = d32(r9+0x20);
    r11 = 0;
    s32(r15+0x18, r13);
    r13 = d32(r9+0x60);
    s32(r15+0x20, r14);
    r14 = d32(r9+0x2c);
    s32(r15+0x60, r13);
    r13 = d32(r9+0x94);
    s32(r15+0x2c, r14);
    r14 = d32(r9+0xb4);
    s32(r15+0x94, r13);
    r13 = d32(r9+0xb0);
    s32(r15+0xb4, r14);
    r14 = d32(r9+0x68);
    s32(r15+0xb0, r13);
    r13 = d32(r9+0x64);
    s32(r15+0x68, r14);
    r14 = d32(r9+0x7c);
    s32(r15+0x64, r13);
    r13 = d32(r9+0x78);
    s32(r15+0x7c, r14);
    r14 = d32(r9+0xa4);
    s32(r15+0x78, r13);
    r13 = d32(r9+0xa8);
    r9 = d32(r9+0x14);
    s32(r15+0xa4, r14);
    s32(r15+0xa8, r13);
    s32(r15+0x14, r9);
    L_5363:; /* 0x5363 */
    r13 = 0xa00u;
    r9 = r11 + r13;
    r9 = d32(r9);
    r14 = 0xe00u;
    r15 = r11 + r14;
    r11 = r11 + 0x4u;
    s32(r15, r9);
    if (!(r11 != 0x100u)) {
        L_537d:; /* 0x537d */
        r9 = 0x2u;
        s32(sp+0x8, r9);
        s32(sp, r9);
        r9 = 0x1u;
        r14 = 0;
        s32(sp+0x4, r9);
        r10 = 0;
        r12 = 0x6u;
        CALL(sub_2de1);
        r9 = 0xa00u;
        r15 = 0xf00u;
        r14 = 0xb00u;
        L_53a0:; /* 0x53a0 */
        r13 = d32(r9);
        r9 = r9 + 0x4u;
        s32(r15, r13);
        r15 = r15 + 0x4u;
        fc_cmp(r9, r14);
        if (!!FZ(falcon_flags)) {
            L_53af:; /* 0x53af */
            sp += 0xcu;
            for (int i = 0; i <= 0; i++) r[i] = pop32();
            return;
        }
        goto L_53a0;  /* 重复引用 */
        goto L_53a0;  /* 重复引用 */
        goto L_53af;  /* 重复引用 */
    }
    goto L_5363;  /* 重复引用 */
}

/* ==== sub_53b4  (被调用 1 次) ==== */
static void sub_53b4(void) {
    L_53b4:; /* 0x53b4 */
    if (!(r10 == 0x0u)) {
        L_53b8:; /* 0x53b8 */
        r9 = 0x13c0u;
        r15 = d32(r9);
        r9 = 0x22e00u;
        iowr(r9, r15);
        r15 = 0x8u;
        goto L_5473;
        L_53cb:; /* 0x53cb */
        if (!(r11 != 0x2u)) {
            L_53cf:; /* 0x53cf */
            if (!(r12 != 0x1u)) {
                L_53d3:; /* 0x53d3 */
                r9 = 0x13c0u;
                r15 = d32(r9);
                r9 = 0x22e00u;
                iowr(r9, r15);
                r15 = 0x10u;
                goto L_5473;
                L_53e6:; /* 0x53e6 */
                if (!(r13 != 0x1u)) {
                    L_53ea:; /* 0x53ea */
                    r9 = 0x13c0u;
                    r15 = d32(r9);
                    r9 = 0x22e00u;
                    iowr(r9, r15);
                    r15 = 0xeu;
                    goto L_5473;
                    L_53fd:; /* 0x53fd */
                    r15 = 0x13c0u;
                    if (!(r13 != 0x2u)) {
                        L_5405:; /* 0x5405 */
                        r15 = d32(r15);
                        r9 = 0x22e00u;
                        iowr(r9, r15);
                        r15 = 0x11u;
                        goto L_5473;
                        L_5414:; /* 0x5414 */
                        r15 = d32(r15);
                        r9 = 0x22e00u;
                        iowr(r9, r15);
                        r15 = 0x9u;
                        goto L_5473;
                        L_5423:; /* 0x5423 */
                        if (!(r12 != 0x1u)) {
                            L_5427:; /* 0x5427 */
                            r9 = 0x13c0u;
                            r15 = d32(r9);
                            r9 = 0x22e00u;
                            iowr(r9, r15);
                            r15 = 0x12u;
                            goto L_5473;
                            L_543a:; /* 0x543a */
                            if (!(r13 != 0x1u)) {
                                L_543e:; /* 0x543e */
                                r9 = 0x13c0u;
                                r15 = d32(r9);
                                r9 = 0x22e00u;
                                iowr(r9, r15);
                                r15 = 0x5u;
                                goto L_5473;
                                L_5451:; /* 0x5451 */
                                r15 = 0x13c0u;
                                if (!(r13 != 0x2u)) {
                                    L_5459:; /* 0x5459 */
                                    r15 = d32(r15);
                                    r9 = 0x22e00u;
                                    iowr(r9, r15);
                                    r15 = 0x13u;
                                    goto L_5473;
                                    L_5468:; /* 0x5468 */
                                    r15 = d32(r15);
                                    r9 = 0x22e00u;
                                    iowr(r9, r15);
                                    r15 = 0xau;
                                    L_5473:; /* 0x5473 */
                                    r9 = r9 + 0x100u;
                                    iowr(r9, r15);
                                    return;
                                }
                                goto L_5468;  /* 重复引用 */
                            }
                            goto L_5451;  /* 重复引用 */
                        }
                        goto L_543a;  /* 重复引用 */
                    }
                    goto L_5414;  /* 重复引用 */
                }
                goto L_53fd;  /* 重复引用 */
            }
            goto L_53e6;  /* 重复引用 */
            goto L_53d3;  /* 重复引用 */
            goto L_53e6;  /* 重复引用 */
            goto L_53ea;  /* 重复引用 */
            goto L_53fd;  /* 重复引用 */
            goto L_5405;  /* 重复引用 */
            goto L_5414;  /* 重复引用 */
        }
        goto L_5423;  /* 重复引用 */
    }
    goto L_53cb;  /* 重复引用 */
}

/* ==== sub_547d  (被调用 1 次) ==== */
static void sub_547d(void) {
    L_547d:; /* 0x547d */
    r14 = 0xe00u;
    r15 = d32(r14+0x8c);
    r9 = r15 & 0x10u;
    if (!FZ(falcon_flags)) {
        L_548a:; /* 0x548a */
        r9 = -0x11u;
        r9 = r15 & r9;
        s32(r14+0x8c, r9);
        r9 = 0x20900u;
        iowr(r9, r10);
        r9 = r9 + 0x600u;
        iowr(r9, r11);
        r15 = 0x2u;
        r9 = 0x30700u;
        iowr(r9, r15);
        L_54aa:; /* 0x54aa */
        return;
    }
    goto L_54aa;  /* 重复引用 */
}

/* ==== sub_54ac  (被调用 1 次) ==== */
static void sub_54ac(void) {
    L_54ac:; /* 0x54ac */
    for (int i = 0; i >= 0; i--) push32(r[i]);
    r15 = 0x350a0000u;
    r0 = r10;
    r9 = 0x22a00u;
    iowr(r9, r15);
    r15 = 0xeu;
    r9 = r9 - 0x7e00u;
    iowr(r9, r15);
    CALL(sub_768);
    if (!(r0 != 0x1u)) {
        L_54ce:; /* 0x54ce */
        if (!(r10 != 0x0u)) {
            L_54d2:; /* 0x54d2 */
            r9 = 0x20u;
            r9 = d32(r9);
            if ((r9 == 0x0u)) goto L_54e6;
            L_54dc:; /* 0x54dc */
            r9 = 0x9ecu;
            r9 = d32(r9);
            if ((r9 != 0x1u)) goto L_5510;
            L_54e6:; /* 0x54e6 */
            r9 = 0x1410u;
            r14 = d32(r9);
            r15 = 0x1u;
            r9 = 0x9ecu;
            s32(r9, r15);
            if (!(r14 != 0x0u)) {
                L_54f8:; /* 0x54f8 */
                CALL(sub_b8b);
                L_54fc:; /* 0x54fc */
                r9 = 0x12dcu;
                r9 = d32(r9);
                if (!(r9 != 0x0u)) {
                    L_5506:; /* 0x5506 */
                    r10 = 0x4181e8u;
                    r11 = 0xcu;
                    CALL(sub_237);
                    L_5510:; /* 0x5510 */
                    r10 = r0;
                    CALL(sub_d91);
                    for (int i = 0; i <= 0; i++) r[i] = pop32();
                    return;
                }
                goto L_5510;  /* 重复引用 */
            }
            goto L_54fc;  /* 重复引用 */
        }
        goto L_54e6;  /* 重复引用 */
        goto L_54d2;  /* 重复引用 */
    }
    goto L_54dc;  /* 重复引用 */
}

/* ==== sub_5518  (被调用 1 次) ==== */
static void sub_5518(void) {
    L_5518:; /* 0x5518 */
    for (int i = 2; i >= 0; i--) push32(r[i]);
    r15 = 0x350a0000u;
    r9 = 0x22a00u;
    iowr(r9, r15);
    CALL(sub_2296);
    r9 = 0x9ecu;
    r9 = d32(r9);
    if (!(r9 != 0x1u)) {
        L_5534:; /* 0x5534 */
        r9 = 0x1410u;
        r9 = d32(r9);
        if (!(r9 != 0x0u)) {
            L_553e:; /* 0x553e */
            CALL(sub_2749);
            L_5542:; /* 0x5542 */
            r9 = 0x12dcu;
            r9 = d32(r9);
            if (!(r9 != 0x0u)) {
                L_554c:; /* 0x554c */
                r1 = 0;
                r0 = 0x5001e8u;
                r2 = 0x14a0u;
                goto L_5572;
                L_555a:; /* 0x555a */
                CALL(sub_215e);
                L_555e:; /* 0x555e */
                r10 = r0;
                CALL(sub_297);
                r10 = (r10 >> 2) & 0x3u;
                if (!!FZ(falcon_flags)) {
                    L_556a:; /* 0x556a */
                    r1 = r1 + 0x1u;
                    r0 = r0 + 0x8000u;
                    L_5572:; /* 0x5572 */
                    r9 = d32(r2);
                    fc_cmp(r1, r9);
                    if (FC(falcon_flags)) goto L_555e;
                    L_5579:; /* 0x5579 */
                    for (int i = 0; i <= 2; i++) r[i] = pop32();
                    return;
                }
                goto L_555a;  /* 重复引用 */
                goto L_555a;  /* 重复引用 */
                goto L_555e;  /* 重复引用 */
                goto L_556a;  /* 重复引用 */
                goto L_5572;  /* 重复引用 */
            }
            goto L_5579;  /* 重复引用 */
        }
        goto L_5542;  /* 重复引用 */
        goto L_553e;  /* 重复引用 */
        goto L_5542;  /* 重复引用 */
        goto L_554c;  /* 重复引用 */
        goto L_555a;  /* 重复引用 */
        goto L_555e;  /* 重复引用 */
        goto L_556a;  /* 重复引用 */
        goto L_5572;  /* 重复引用 */
    }
    goto L_5579;  /* 重复引用 */
}

/* ==== sub_557b  (被调用 4 次) ==== */
static void sub_557b(void) {
    L_557b:; /* 0x557b */
    for (int i = 4; i >= 0; i--) push32(r[i]);
    r2 = r10;
    r4 = r11;
    L_5581:; /* 0x5581 */
    r10 = 0x10a030u;
    CALL(sub_297);
    r0 = r10;
    r10 = 0x10a02cu;
    CALL(sub_297);
    r3 = r10;
    r10 = 0x10a030u;
    CALL(sub_297);
    r1 = r10;
    fc_cmp(r10, r0);
    if (!!FZ(falcon_flags)) {
        L_55a4:; /* 0x55a4 */
        r0 = r2 + 0x1u;
        fc_cmp(r0, 0x1fu);
        if (!(FC(falcon_flags) || FZ(falcon_flags))) {
            L_55ad:; /* 0x55ad */
            r10 = 0x27u;
            CALL(sub_5c0);
            goto L_55f2;
            L_55b7:; /* 0x55b7 */
            fc_cmp(r2, 0x1fu);
            if (!(!FC(falcon_flags) && !FZ(falcon_flags))) {
                L_55bd:; /* 0x55bd */
                r9 = 0x1200u;
                r14 = r3 >> 0x5u;
                r15 = r2 << 0x2u;
                r15 = r15 + r9;
                r9 = r10 << 0x1bu;
                r9 |= r14;
                s32(r15, r9);
                goto L_55dc;
                L_55d6:; /* 0x55d6 */
                r10 = 0x27u;
                CALL(sub_5c0);
                L_55dc:; /* 0x55dc */
                r14 = 0x1200u;
                r9 = r0 << 0x2u;
                r15 = (r1 >> 5) & 0xffffffu;
                r9 = r9 + r14;
                r14 = r4 << 0x18u;
                r15 |= r14;
                s32(r9, r15);
                L_55f2:; /* 0x55f2 */
                for (int i = 0; i <= 4; i++) r[i] = pop32();
                return;
            }
            goto L_55d6;  /* 重复引用 */
        }
        goto L_55b7;  /* 重复引用 */
        goto L_55ad;  /* 重复引用 */
        goto L_55b7;  /* 重复引用 */
        goto L_55bd;  /* 重复引用 */
        goto L_55d6;  /* 重复引用 */
        goto L_55dc;  /* 重复引用 */
        goto L_55f2;  /* 重复引用 */
    }
    goto L_5581;  /* 重复引用 */
}

/* ==== sub_55f4  (被调用 1 次) ==== */
static void sub_55f4(void) {
    L_55f4:; /* 0x55f4 */
    r15 = 0x1200u;
    r9 = 0;
    s32(r15+0x3c, r9);
    s32(r15+0x18, r9);
    s32(r15+0x1c, r9);
    s32(r15+0x20, r9);
    s32(r15+0x24, r9);
    s32(r15+0x28, r9);
    s32(r15+0x2c, r9);
    s32(r15+0x30, r9);
    s32(r15+0x34, r9);
    s32(r15+0x38, r9);
    return;
}

/* ==== sub_561a  (被调用 1 次) ==== */
static void sub_561a(void) {
    L_561a:; /* 0x561a */
    for (int i = 4; i >= 0; i--) push32(r[i]);
    r0 = r10;
    sp += -0xcu;
    CALL(sub_31cf);
    r15 = 0;
    r9 = 0x28100u;
    r4 = iord(r9+r15*0x4);
    r9 = r9 + 0xd00u;
    r3 = iord(r9+r15*0x4);
    r9 = r9 + 0x100u;
    r2 = iord(r9+r15*0x4);
    r9 = r9 + 0x4900u;
    r0 = r0 + r9;
    r10 = r0 << 0x6u;
    CALL(sub_297);
    r9 = 0x14b8u;
    r0 = 0x7fffffffu;
    r1 = r10 & r0;
    r10 = d32(r9);
    r9 = 0x14bcu;
    r11 = d32(r9);
    r9 = 0x14c0u;
    r12 = d32(r9);
    CALL(sub_32b9);
    r10 = 0x28u;
    fc_cmp(r1, r0);
    if (!FZ(falcon_flags)) {
        L_5672:; /* 0x5672 */
        r11 = r1 << 0x7u;
        r9 = r1 >> 0x19u;
        r10 = 0x29u;
        if (!!FZ(falcon_flags)) {
            L_567d:; /* 0x567d */
            r9 = 0x2u;
            r10 = 0;
            s32(sp+0x8, r9);
            s32(sp, r9);
            s32(sp+0x4, r9);
            r12 = 0x5u;
            r13 = 0x1200u;
            r14 = 0;
            CALL(sub_2de1);
            goto L_569e;
            L_569a:; /* 0x569a */
            CALL(sub_5c0);
            L_569e:; /* 0x569e */
            r10 = r4;
            r11 = r3;
            r12 = r2;
            CALL(sub_32b9);
            sp += 0xcu;
            for (int i = 0; i <= 4; i++) r[i] = pop32();
            return;
        }
        goto L_569a;  /* 重复引用 */
        goto L_567d;  /* 重复引用 */
    }
    goto L_569a;  /* 重复引用 */
}

/* ==== sub_56ad  (被调用 2 次) ==== */
static void sub_56ad(void) {
    L_56ad:; /* 0x56ad */
    r9 = 0x2d800u;
    for (int i = 4; i >= 0; i--) push32(r[i]);
    r1 = r10;
    r1 = r1 + r9;
    r4 = r1 << 0x6u;
    r10 = r4;
    CALL(sub_297);
    r9 = -0x2d800u;
    r1 = r1 + r9;
    r9 = 0xb60004u;
    r0 = r10;
    r2 = r10 + 0x1u;
    r10 = r1 << 0x6u;
    r10 = r10 + r9;
    CALL(sub_297);
    r3 = r10;
    fc_cmp(r2, r0);
    if (!!FC(falcon_flags)) {
        L_56e3:; /* 0x56e3 */
        r10 = 0x28u;
        CALL(sub_5c0);
        goto L_56fa;
        L_56ed:; /* 0x56ed */
        r9 = 0x14c4u;
        r9 = d32(r9);
        fc_cmp(r2, r9);
        if (!FC(falcon_flags)) {
            L_56f8:; /* 0x56f8 */
            r2 = 0;
            L_56fa:; /* 0x56fa */
            fc_cmp(r2, r3);
            if (!!FZ(falcon_flags)) {
                L_56ff:; /* 0x56ff */
                r10 = 0x30u;
                CALL(sub_5c0);
                goto L_571b;
                L_5709:; /* 0x5709 */
                r10 = r1;
                CALL(sub_561a);
                CALL(sub_55f4);
                r10 = r4;
                r11 = r2;
                CALL(sub_237);
                L_571b:; /* 0x571b */
                r15 = 0;
                r9 = 0x1200u;
                s32(r9+0x8, r15);
                for (int i = 0; i <= 4; i++) r[i] = pop32();
                return;
            }
            goto L_5709;  /* 重复引用 */
        }
        goto L_56fa;  /* 重复引用 */
    }
    goto L_56ed;  /* 重复引用 */
}

/* ==== sub_5726  (被调用 2 次) ==== */
static void sub_5726(void) {
    L_5726:; /* 0x5726 */
    for (int i = 6; i >= 0; i--) push32(r[i]);
    r15 = 0x100000u;
    r2 = r10;
    r5 = r11;
    r4 = r12;
    r9 = 0x21400u;
    iowr(r9, r15);
    r3 = 0xe00u;
    r9 = d32(r3+0xb4);
    r12 = d32(r3+0xb0);
    r11 = d32(r3+0xac);
    r15 = r13 + 0x40u;
    r9 >>= 0x8u;
    r1 = (r12 >> 8) & 0x1ffu;
    r12 <<= 0x18u;
    r12 |= r9;
    r9 = 0x14b8u;
    s32(r9, r12);
    r9 = 0x14bcu;
    r15 &= 0xffu;
    r11 &= 0xffffu;
    r10 = r14 << 0x6u;
    s32(r9, r1);
    r13 &= 0x3fu;
    r9 = 0x14c0u;
    r13 <<= 0x10u;
    r14 &= 0x3fu;
    r13 |= r15;
    r14 <<= 0x18u;
    r13 |= r14;
    r0 = 0x14c4u;
    s32(r9, r13);
    r6 = 0xb60004u;
    s32(r0, r11);
    r10 = r10 + r6;
    CALL(sub_297);
    r15 = d32(r0);
    r10 >>= 0x1fu;
    r9 = 0x14b4u;
    s32(r9, r10);
    if (!(r15 == 0x0u)) {
        L_57a5:; /* 0x57a5 */
        if (!(r10 == 0x0u)) {
            L_57a9:; /* 0x57a9 */
            if (!(r2 != 0x0u)) {
                L_57ad:; /* 0x57ad */
                r9 = 0x1200u;
                r15 = d32(r9+0x10);
                r6 = d32(r9+0x14);
                s32(r9+0x3c, r2);
                s32(r9+0x10, r2);
                s32(r9+0x8, r15);
                s32(r9+0xc, r6);
                s32(r9+0x14, r2);
                s32(r9+0x30, r2);
                s32(r9+0x34, r2);
                s32(r9+0x38, r2);
                r10 = 0x6u;
                r11 = 0x1u;
                goto L_5801;
                L_57d7:; /* 0x57d7 */
                if (!(r2 != 0x1u)) {
                    L_57db:; /* 0x57db */
                    r9 = d32(r3+0x108);
                    r3 = d32(r3+0x104);
                    r15 = 0x1200u;
                    r10 = 0xcu;
                    s32(r15+0x7c, r9);
                    r9 = 0;
                    s32(r15+0x10, r4);
                    s32(r15, r9);
                    s32(r15+0x14, r5);
                    r9 = 0x600dbeefu;
                    s32(r15+0x78, r3);
                    s32(r15+0x4, r9);
                    r11 = 0x4u;
                    L_5801:; /* 0x5801 */
                    CALL(sub_557b);
                    L_5805:; /* 0x5805 */
                    r15 = 0x100000u;
                    r9 = 0x21a00u;
                    iowr(r9, r15);
                    for (int i = 0; i <= 6; i++) r[i] = pop32();
                    return;
                }
                goto L_5805;  /* 重复引用 */
            }
            goto L_57d7;  /* 重复引用 */
            goto L_57ad;  /* 重复引用 */
            goto L_57d7;  /* 重复引用 */
            goto L_57db;  /* 重复引用 */
            goto L_5801;  /* 重复引用 */
        }
        goto L_5805;  /* 重复引用 */
        goto L_57a9;  /* 重复引用 */
        goto L_57ad;  /* 重复引用 */
        goto L_57d7;  /* 重复引用 */
        goto L_57db;  /* 重复引用 */
        goto L_5801;  /* 重复引用 */
    }
    goto L_5805;  /* 重复引用 */
}

/* ==== sub_5812  (被调用 2 次) ==== */
static void sub_5812(void) {
    L_5812:; /* 0x5812 */
    if (!(r10 != 0x1u)) {
        L_5816:; /* 0x5816 */
        r15 = 0x310e0000u;
        r9 = 0x22a00u;
        iowr(r9, r15);
        r9 = 0x1314u;
        r11 = d32(r9);
        r10 = 0x1cu;
        CALL(sub_cc5);
        CALL(sub_23fc);
        r9 = 0x131cu;
        r11 = d32(r9);
        r10 = 0x1fu;
        CALL(sub_cc5);
        CALL(sub_23fc);
        r15 = 0x37080000u;
        r9 = 0x22a00u;
        iowr(r9, r15);
        L_584e:; /* 0x584e */
        return;
    }
    goto L_584e;  /* 重复引用 */
}

/* ==== sub_5850  (被调用 3 次) ==== */
static void sub_5850(void) {
    L_5850:; /* 0x5850 */
    r15 = 0x1604u;
    r15 = d32(r15);
    sp += -0x48u;
    for (int i = 8; i >= 0; i--) push32(r[i]);
    sp += -0xcu;
    r9 = sp;
    r9 = r9 + 0x74u;
    r0 = r10;
    s32(r9, r15);
    s32(sp+0x30, r11);
    r15 = 0x80000u;
    r9 = 0x21200u;
    iowr(r9, r15);
    r15 = 0x800000u;
    r9 = r9 + 0x1800u;
    iowr(r9, r15);
    r15 = 0x37080000u;
    iowr(r9, r15);
    CALL(sub_768);
    CALL(sub_4751);
    r15 = 0x8u;
    r9 = 0x1ac00u;
    iowr(r9, r15);
    r15 = 0;
    r9 = 0x2de00u;
    r9 = iord(r9+r15*0x4);
    r9 &= 0x3fu;
    r15 = 0x36090000u;
    s32(sp+0x38, r9);
    r9 = 0x22a00u;
    iowr(r9, r15);
    r11 = d32(sp+0x30);
    r10 = r0;
    r12 = 0x2u;
    CALL(sub_4dd9);
    r15 = 0x37080000u;
    r9 = 0x22a00u;
    iowr(r9, r15);
    r9 = 0x12e0u;
    r10 = d32(r9);
    r9 = 0x12e4u;
    r11 = d32(r9);
    r9 = 0x12e8u;
    r12 = d32(r9);
    CALL(sub_32b9);
    r15 = 0x320d0000u;
    r9 = 0x22a00u;
    iowr(r9, r15);
    r10 = 0x2u;
    CALL(sub_2ec1);
    CALL(sub_31cf);
    r15 = 0x37080000u;
    r9 = 0x22a00u;
    iowr(r9, r15);
    r15 = 0xc0ffeeb1u;
    r9 = r9 - 0x2000u;
    iowr(r9, r15);
    r9 = 0xe00u;
    r9 = d32(r9+0xc);
    r15 = 0x1444u;
    r9 &= 0x3fu;
    s32(r15, r9);
    r15 = 0x20a00u;
    iowr(r15, r9);
    if (!(r9 == 0x21u)) {
        L_592e:; /* 0x592e */
        r3 = 0;
        goto L_594f;
        L_5934:; /* 0x5934 */
        r9 = 0x2b140000u;
        r15 = 0x22a00u;
        iowr(r15, r9);
        r9 = 0x12ecu;
        r11 = d32(sp+0x38);
        r10 = d32(r9);
        r3 = 0x1u;
        CALL(sub_526f);
        L_594f:; /* 0x594f */
        r15 = 0x310e0000u;
        r9 = 0x22a00u;
        iowr(r9, r15);
        r9 = 0x12ecu;
        r11 = d32(r9);
        r10 = 0x41a814u;
        CALL(sub_237);
        r9 = 0x12e0u;
        r11 = d32(r9);
        r10 = 0x13u;
        CALL(sub_cc5);
        CALL(sub_23fc);
        r9 = 0x12e4u;
        r11 = d32(r9);
        r10 = 0x1eu;
        CALL(sub_cc5);
        CALL(sub_23fc);
        r9 = 0x1324u;
        r9 = d32(r9);
        if (!(r9 != 0x0u)) {
            L_5993:; /* 0x5993 */
            r10 = 0x41a800u;
            r11 = 0;
            CALL(sub_237);
            r11 = d32(sp+0x30);
            r10 = 0x6cu;
            CALL(sub_cc5);
            L_59a6:; /* 0x59a6 */
            r10 = 0x2u;
            CALL(sub_2fd6);
            r15 = 0x2e110000u;
            r9 = 0x22a00u;
            iowr(r9, r15);
            r9 = 0x12ecu;
            r11 = d32(sp+0x38);
            r10 = d32(r9);
            CALL(sub_1a42);
            r9 = 0x130cu;
            r9 = d32(r9);
            r9 = r9 - 0x1u;
            fc_cmp(r9, 0x1u);
            if (!(!FC(falcon_flags) && !FZ(falcon_flags))) {
                L_59d4:; /* 0x59d4 */
                CALL(sub_32e5);
                L_59d8:; /* 0x59d8 */
                r10 = 0;
                CALL(sub_29c6);
                r14 = d32(sp+0x30);
                r9 = 0xfffffffu;
                r10 = 0x1u;
                r11 = r10;
                r14 &= r9;
                r12 = r10;
                s32(sp+0x3c, r14);
                CALL(sub_cf5);
                CALL(sub_e16);
                r1 = r10;
                CALL(sub_54ac);
                r9 = 0x24u;
                r10 = d32(r9);
                CALL(sub_114);
                r9 = 0xe00u;
                r13 = d32(r9+0x88);
                r15 = d32(r9+0xe0);
                r9 = 0x1324u;
                r14 = 0;
                s32(r9, r14);
                r9 = (r13 >> 4) & 0xfu;
                s32(sp+0x34, r9);
                r15 &= 0x1u;
                r4 = r13 & 0xfu;
                if (!(r15 == 0x0u)) {
                    L_5a2c:; /* 0x5a2c */
                    r10 = 0x35u;
                    CALL(sub_5c0);
                    L_5a32:; /* 0x5a32 */
                    r9 = 0x14a0u;
                    r15 = d32(r9);
                    r9 = 0xe00u;
                    r9 = d32(r9+0x8);
                    fc_cmp(r15, r9);
                    if (!FZ(falcon_flags)) {
                        L_5a44:; /* 0x5a44 */
                        r10 = 0x32u;
                        CALL(sub_5c0);
                        L_5a4a:; /* 0x5a4a */
                        r9 = 0x1284u;
                        r15 = d32(r9);
                        r9 = 0x1000u;
                        r9 = d32(r9+0x10);
                        fc_cmp(r15, r9);
                        if (!FZ(falcon_flags)) {
                            L_5a5c:; /* 0x5a5c */
                            r10 = 0x40u;
                            CALL(sub_5c0);
                            L_5a62:; /* 0x5a62 */
                            r9 = 0x1288u;
                            r15 = d32(r9);
                            r9 = 0x1000u;
                            r9 = d32(r9+0x14);
                            fc_cmp(r15, r9);
                            if (!FZ(falcon_flags)) {
                                L_5a74:; /* 0x5a74 */
                                r10 = 0x38u;
                                CALL(sub_5c0);
                                L_5a7a:; /* 0x5a7a */
                                r9 = 0x37080000u;
                                r15 = 0x22a00u;
                                iowr(r15, r9);
                                r0 = 0xe00u;
                                r9 = d32(r0+0xf4);
                                if (!(r9 != 0x0u)) {
                                    L_5a91:; /* 0x5a91 */
                                    r9 = d32(r0+0xf8);
                                    if (!(r9 != 0x0u)) {
                                        L_5a98:; /* 0x5a98 */
                                        CALL(sub_478f);
                                        r9 = 0x13c0u;
                                        s32(r0+0xf0, r10);
                                        s32(r9, r10);
                                        r15 = 0x300f0000u;
                                        r9 = 0x22a00u;
                                        iowr(r9, r15);
                                        r10 = 0x1u;
                                        CALL(sub_1070);
                                        r15 = 0x37080000u;
                                        r9 = 0x22a00u;
                                        iowr(r9, r15);
                                        r9 = 0x13c0u;
                                        r15 = d32(r9);
                                        r9 = 0x22e00u;
                                        iowr(r9, r15);
                                        r15 = 0xcu;
                                        r9 = r9 + 0x100u;
                                        iowr(r9, r15);
                                        r3 = 0x1u;
                                        goto L_5aed;
                                        L_5ae0:; /* 0x5ae0 */
                                        r15 = 0xe00u;
                                        r15 = d32(r15+0xf0);
                                        r9 = 0x13c0u;
                                        s32(r9, r15);
                                        L_5aed:; /* 0x5aed */
                                        r15 = 0x2f100000u;
                                        r9 = 0x22a00u;
                                        iowr(r9, r15);
                                        r9 = 0x13c0u;
                                        r11 = d32(sp+0x3c);
                                        r12 = d32(r9);
                                        r14 = d32(sp+0x38);
                                        r9 = 0x12ecu;
                                        r13 = d32(r9);
                                        r10 = 0x1u;
                                        CALL(sub_5726);
                                        r15 = 0x37080000u;
                                        r9 = 0x22a00u;
                                        iowr(r9, r15);
                                        r15 = 0x300f0000u;
                                        iowr(r9, r15);
                                        r15 = 0xe00u;
                                        r9 = d32(r15+0x80);
                                        r14 = d32(r15+0x38);
                                        r15 = 0x1320u;
                                        r9 &= 0x3u;
                                        r14 &= 0xffu;
                                        s32(r15, r9);
                                        r9 = 0x30u;
                                        s32(r9, r14);
                                        CALL(sub_38a0);
                                        r15 = 0x37080000u;
                                        r9 = 0x22a00u;
                                        iowr(r9, r15);
                                        r10 = 0x4041b8u;
                                        CALL(sub_297);
                                        r9 = 0xe00u;
                                        r9 = d32(r9+0x8c);
                                        r9 &= 0x3u;
                                        if (!(r9 != 0x1u)) {
                                            L_5b67:; /* 0x5b67 */
                                            if (!(r4 != 0x1u)) {
                                                L_5b6b:; /* 0x5b6b */
                                                r9 = 0x1324u;
                                                s32(r9, r4);
                                                L_5b71:; /* 0x5b71 */
                                                r15 = 0xc0ffee01u;
                                                r9 = 0x20a00u;
                                                iowr(r9, r15);
                                                r9 = 0x1324u;
                                                r15 = d32(r9);
                                                r9 = 0x20a00u;
                                                iowr(r9, r15);
                                                r10 = 0x400160u;
                                                CALL(sub_297);
                                                r11 = d32(sp+0x38);
                                                r9 = 0xfc0fffffu;
                                                r10 &= r9;
                                                r11 <<= 0x14u;
                                                r11 = r10 | r11;
                                                r10 = 0x400160u;
                                                CALL(sub_237);
                                                CALL(sub_290c);
                                                r10 = r1;
                                                CALL(sub_5518);
                                                r15 = 0x37080000u;
                                                r9 = 0x22a00u;
                                                iowr(r9, r15);
                                                r15 = 0x8u;
                                                r9 = r9 - 0x7e00u;
                                                iowr(r9, r15);
                                                L_5bcb:; /* 0x5bcb */
                                                r10 = 0x400384u;
                                                CALL(sub_297);
                                                r0 = r10;
                                                CALL(sub_215e);
                                                r0 = (r0 >> 12) & 0x7u;
                                                if (!!FZ(falcon_flags)) {
                                                    L_5bdf:; /* 0x5bdf */
                                                    r9 = 0x1324u;
                                                    r9 = d32(r9);
                                                    if (!(r9 != 0x0u)) {
                                                        L_5be9:; /* 0x5be9 */
                                                        r10 = 0x8u;
                                                        CALL(sub_23af);
                                                        L_5bef:; /* 0x5bef */
                                                        r9 = 0x13c0u;
                                                        r15 = d32(r9);
                                                        r9 = 0x2dd00u;
                                                        iowr(r9, r15);
                                                        r10 = 0;
                                                        CALL(sub_2988);
                                                        if (!(r4 != 0x1u)) {
                                                            L_5c06:; /* 0x5c06 */
                                                            r9 = 0x13c0u;
                                                            r15 = d32(r9);
                                                            r9 = 0x22e00u;
                                                            iowr(r9, r15);
                                                            r15 = 0x14u;
                                                            r9 = r9 + 0x100u;
                                                            iowr(r9, r15);
                                                            r15 = 0xau;
                                                            goto L_5c7d;
                                                            L_5c23:; /* 0x5c23 */
                                                            r14 = d32(sp+0x34);
                                                            if (!(r14 != 0x1u)) {
                                                                L_5c2a:; /* 0x5c2a */
                                                                r9 = 0x13c0u;
                                                                r15 = d32(r9);
                                                                r9 = 0x22e00u;
                                                                iowr(r9, r15);
                                                                r15 = 0xfu;
                                                                r9 = r9 + 0x100u;
                                                                iowr(r9, r15);
                                                                r15 = 0xcu;
                                                                goto L_5c7d;
                                                                L_5c47:; /* 0x5c47 */
                                                                r15 = 0x13c0u;
                                                                if (!(r14 != 0x2u)) {
                                                                    L_5c4f:; /* 0x5c4f */
                                                                    r15 = d32(r15);
                                                                    r9 = 0x22e00u;
                                                                    iowr(r9, r15);
                                                                    r15 = 0x15u;
                                                                    r9 = r9 + 0x100u;
                                                                    iowr(r9, r15);
                                                                    r15 = 0xbu;
                                                                    goto L_5c7d;
                                                                    L_5c68:; /* 0x5c68 */
                                                                    r15 = d32(r15);
                                                                    r9 = 0x22e00u;
                                                                    iowr(r9, r15);
                                                                    r15 = 0xbu;
                                                                    r9 = r9 + 0x100u;
                                                                    iowr(r9, r15);
                                                                    r15 = 0x9u;
                                                                    L_5c7d:; /* 0x5c7d */
                                                                    r9 = 0x1ac00u;
                                                                    iowr(r9, r15);
                                                                    r15 = 0x2d120000u;
                                                                    r9 = 0x22a00u;
                                                                    iowr(r9, r15);
                                                                    r9 = 0x12ecu;
                                                                    r11 = d32(sp+0x38);
                                                                    r10 = d32(r9);
                                                                    CALL(sub_16df);
                                                                    r15 = 0x37080000u;
                                                                    r9 = 0x22a00u;
                                                                    iowr(r9, r15);
                                                                    if (!(r4 != 0x1u)) {
                                                                        L_5cae:; /* 0x5cae */
                                                                        r9 = 0x145cu;
                                                                        r9 = d32(r9);
                                                                        if (!(r9 == 0x0u)) {
                                                                            L_5cb9:; /* 0x5cb9 */
                                                                            r9 = 0x30u;
                                                                            r9 = d32(r9);
                                                                            if (!(r9 != 0x3u)) {
                                                                                L_5cc4:; /* 0x5cc4 */
                                                                                r15 = 0x300f0000u;
                                                                                r9 = 0x22a00u;
                                                                                iowr(r9, r15);
                                                                                r2 = 0xc00u;
                                                                                r14 = d32(r2+0x10);
                                                                                r9 = 0xe00u;
                                                                                r15 = 0x1474u;
                                                                                r13 = d32(r9+0x38);
                                                                                r9 = 0x145cu;
                                                                                s32(r15, r14);
                                                                                r15 = d32(r9);
                                                                                r9 = 0x1460u;
                                                                                r9 = d32(r9);
                                                                                r2 = d32(r2);
                                                                                r11 = r14;
                                                                                r13 = (r13 >> 8) & 0xffu;
                                                                                r14 = r9 >> 0x10u;
                                                                                r9 &= 0xffffu;
                                                                                r12 = r15 >> 0x10u;
                                                                                r0 = sp;
                                                                                r15 &= 0xffffu;
                                                                                r0 = r0 + 0x64u;
                                                                                s32(r0+0x8, r9);
                                                                                r9 = 0x1484u;
                                                                                r10 = r13;
                                                                                s32(r9, r13);
                                                                                s32(r0+0x4, r12);
                                                                                s32(r0+0xc, r14);
                                                                                s32(r0, r15);
                                                                                r1 = 0x1478u;
                                                                                s32(r1, r2);
                                                                                CALL(sub_77ce);
                                                                                r14 = r10 + r2;
                                                                                r9 = r14 >> 0x18u;
                                                                                r15 = sp;
                                                                                r14 >>= 0x8u;
                                                                                r15 = r15 + 0x54u;
                                                                                s32(r15+0x4, r9);
                                                                                r9 = r14 & 0xffffu;
                                                                                s32(r15, r9);
                                                                                r9 = 0;
                                                                                s32(r15+0x8, r9);
                                                                                s32(r15+0xc, r9);
                                                                                r9 = 0x1470u;
                                                                                r11 = r0;
                                                                                r12 = r15;
                                                                                s32(r9, r14);
                                                                                r0 = sp;
                                                                                r0 = r0 + 0x44u;
                                                                                r10 = r0;
                                                                                CALL(sub_1021);
                                                                                r15 = d32(r0+0x4);
                                                                                r13 = d32(r0);
                                                                                r9 = 0x12ecu;
                                                                                r9 = d32(r9);
                                                                                r15 <<= 0x10u;
                                                                                r2 = r15 | r13;
                                                                                r14 = d32(r0+0xc);
                                                                                r15 = r9 + 0x40u;
                                                                                r15 &= 0xffu;
                                                                                r9 &= 0x3fu;
                                                                                r9 <<= 0x10u;
                                                                                r9 |= r15;
                                                                                r15 = d32(sp+0x38);
                                                                                r12 = d32(r0+0x8);
                                                                                r14 <<= 0x10u;
                                                                                r10 = 0x2u;
                                                                                r15 <<= 0x18u;
                                                                                r1 = r14 | r12;
                                                                                r0 = r9 | r15;
                                                                                CALL(sub_1070);
                                                                                r14 = 0x1494u;
                                                                                r9 = d32(r14);
                                                                                r15 = -0x100u;
                                                                                r3 = 0x1u;
                                                                                r15 = r9 & r15;
                                                                                r9 = r9 + 0x1u;
                                                                                r9 &= 0xffu;
                                                                                r9 |= r15;
                                                                                s32(r14, r9);
                                                                                goto L_5de5;
                                                                                L_5db6:; /* 0x5db6 */
                                                                                r15 = 0xe00u;
                                                                                r9 = 0x12ecu;
                                                                                r14 = d32(r15+0x64);
                                                                                r9 = d32(r9);
                                                                                r2 = d32(r15+0x68);
                                                                                r15 = 0x1ffffu;
                                                                                r1 = r14 & r15;
                                                                                r15 = r9 + 0x40u;
                                                                                r15 &= 0xffu;
                                                                                r9 &= 0x3fu;
                                                                                r9 <<= 0x10u;
                                                                                r9 |= r15;
                                                                                r15 = d32(sp+0x38);
                                                                                r15 <<= 0x18u;
                                                                                r0 = r9 | r15;
                                                                                L_5de5:; /* 0x5de5 */
                                                                                r9 = 0x1314u;
                                                                                s32(r9, r2);
                                                                                r9 = 0x1318u;
                                                                                s32(r9, r1);
                                                                                r9 = 0x131cu;
                                                                                s32(r9, r0);
                                                                                L_5df7:; /* 0x5df7 */
                                                                                r14 = 0xe00u;
                                                                                r9 = d32(r14+0xc);
                                                                                r15 = -0x10000u;
                                                                                r9 &= r15;
                                                                                r15 = 0xcafe0000u;
                                                                                fc_cmp(r9, r15);
                                                                                if (!!FZ(falcon_flags)) {
                                                                                    L_5e0f:; /* 0x5e0f */
                                                                                    r15 = d32(r14+0xfc);
                                                                                    r9 = 0x600dc0deu;
                                                                                    fc_cmp(r15, r9);
                                                                                    if (!!FZ(falcon_flags)) {
                                                                                        L_5e1c:; /* 0x5e1c */
                                                                                        r15 = d32(r14+0x100);
                                                                                        r9 = 0xdeadce11u;
                                                                                        fc_cmp(r15, r9);
                                                                                        if (!!FZ(falcon_flags)) {
                                                                                            L_5e29:; /* 0x5e29 */
                                                                                            r15 = d32(r14+0x1fc);
                                                                                            r9 = 0xfaceb00cu;
                                                                                            fc_cmp(r15, r9);
                                                                                            if (FZ(falcon_flags)) goto L_5e54;
                                                                                            L_5e36:; /* 0x5e36 */
                                                                                            r10 = 0x1u;
                                                                                            CALL(sub_791);
                                                                                            r10 = 0x15u;
                                                                                            CALL(sub_5c0);
                                                                                            r15 = 0x2u;
                                                                                            r9 = 0x20000u;
                                                                                            iowr(r9, r15);
                                                                                            r15 = 0xbadc0de0u;
                                                                                            goto L_5f0c;
                                                                                            L_5e54:; /* 0x5e54 */
                                                                                            r15 = 0x3b040000u;
                                                                                            r9 = 0x22a00u;
                                                                                            iowr(r9, r15);
                                                                                            r9 = 0x1324u;
                                                                                            r9 = d32(r9);
                                                                                            if (!(r9 != 0x0u)) {
                                                                                                L_5e6a:; /* 0x5e6a */
                                                                                                CALL(sub_23fc);
                                                                                                L_5e6e:; /* 0x5e6e */
                                                                                                r0 = 0x12ecu;
                                                                                                r10 = d32(r0);
                                                                                                CALL(sub_24c4);
                                                                                                r10 = d32(r0);
                                                                                                CALL(sub_2689);
                                                                                                r9 = 0x1324u;
                                                                                                r9 = d32(r9);
                                                                                                if (!(r9 != 0x0u)) {
                                                                                                    L_5e88:; /* 0x5e88 */
                                                                                                    r10 = r4;
                                                                                                    CALL(sub_5812);
                                                                                                    L_5e8e:; /* 0x5e8e */
                                                                                                    r10 = 0x7u;
                                                                                                    r11 = 0;
                                                                                                    CALL(sub_d17);
                                                                                                    r9 = 0x1324u;
                                                                                                    r9 = d32(r9);
                                                                                                    if (!(r9 != 0x0u)) {
                                                                                                        L_5ea0:; /* 0x5ea0 */
                                                                                                        r10 = 0x41a800u;
                                                                                                        r11 = 0;
                                                                                                        CALL(sub_237);
                                                                                                        r11 = d32(sp+0x30);
                                                                                                        r10 = 0x2u;
                                                                                                        CALL(sub_cc5);
                                                                                                        L_5eb3:; /* 0x5eb3 */
                                                                                                        r14 = 0x1000u;
                                                                                                        r9 = d32(r14+0x4);
                                                                                                        r15 = -0x10000u;
                                                                                                        r9 &= r15;
                                                                                                        r15 = 0xca110000u;
                                                                                                        fc_cmp(r9, r15);
                                                                                                        if (!!FZ(falcon_flags)) {
                                                                                                            L_5ecb:; /* 0x5ecb */
                                                                                                            r15 = d32(r14+0xfc);
                                                                                                            r9 = 0xad0becabu;
                                                                                                            fc_cmp(r15, r9);
                                                                                                            if (!!FZ(falcon_flags)) {
                                                                                                                L_5ed8:; /* 0x5ed8 */
                                                                                                                r15 = d32(r14+0x100);
                                                                                                                r9 = 0x1ceb00dau;
                                                                                                                fc_cmp(r15, r9);
                                                                                                                if (!!FZ(falcon_flags)) {
                                                                                                                    L_5ee5:; /* 0x5ee5 */
                                                                                                                    r15 = d32(r14+0x1fc);
                                                                                                                    r9 = 0xf00dbeefu;
                                                                                                                    fc_cmp(r15, r9);
                                                                                                                    if (FZ(falcon_flags)) goto L_5f22;
                                                                                                                    L_5ef2:; /* 0x5ef2 */
                                                                                                                    r10 = 0x1u;
                                                                                                                    CALL(sub_791);
                                                                                                                    r10 = 0x15u;
                                                                                                                    CALL(sub_5c0);
                                                                                                                    r15 = 0x2u;
                                                                                                                    r9 = 0x20000u;
                                                                                                                    iowr(r9, r15);
                                                                                                                    r15 = 0xbadc0de1u;
                                                                                                                    L_5f0c:; /* 0x5f0c */
                                                                                                                    r9 = r9 + 0xe00u;
                                                                                                                    iowr(r9, r15);
                                                                                                                    r15 = 0x3f000000u;
                                                                                                                    r9 = r9 + 0x1c00u;
                                                                                                                    goto L_6479;
                                                                                                                    L_5f22:; /* 0x5f22 */
                                                                                                                    r9 = 0x24u;
                                                                                                                    r10 = d32(r9);
                                                                                                                    CALL(sub_114);
                                                                                                                    r10 = 0x4u;
                                                                                                                    CALL(sub_791);
                                                                                                                    r9 = 0x1324u;
                                                                                                                    r9 = d32(r9);
                                                                                                                    if (!(r9 != 0x0u)) {
                                                                                                                        L_5f3c:; /* 0x5f3c */
                                                                                                                        r15 = 0x29160000u;
                                                                                                                        r9 = 0x22a00u;
                                                                                                                        iowr(r9, r15);
                                                                                                                        r10 = 0x2u;
                                                                                                                        CALL(sub_45b);
                                                                                                                        L_5f4e:; /* 0x5f4e */
                                                                                                                        r15 = 0x3e010000u;
                                                                                                                        r9 = 0x22a00u;
                                                                                                                        iowr(r9, r15);
                                                                                                                        r9 = 0x1324u;
                                                                                                                        r9 = d32(r9);
                                                                                                                        if (!(r9 != 0x0u)) {
                                                                                                                            L_5f64:; /* 0x5f64 */
                                                                                                                            CALL(sub_ed1);
                                                                                                                            r10 = 0x1u;
                                                                                                                            CALL(sub_415);
                                                                                                                            CALL(sub_2c19);
                                                                                                                            r10 = 0;
                                                                                                                            CALL(sub_42f);
                                                                                                                            L_5f78:; /* 0x5f78 */
                                                                                                                            r10 = 0x1u;
                                                                                                                            CALL(sub_e3);
                                                                                                                            CALL(sub_2175);
                                                                                                                            r10 = 0xbu;
                                                                                                                            r11 = 0xf2u;
                                                                                                                            CALL(sub_c4);
                                                                                                                            r9 = 0x1000u;
                                                                                                                            r11 = d32(r9+0xc);
                                                                                                                            r10 = 0x10u;
                                                                                                                            r11 = (r11 & 0xffffu) | ((u32)0x0u << 16); /* 待复核 */
                                                                                                                            CALL(sub_c4);
                                                                                                                            r9 = 0x1324u;
                                                                                                                            r9 = d32(r9);
                                                                                                                            r10 = 0x4041b8u;
                                                                                                                            fc_cmp(r9, 0x0u);
                                                                                                                            fc_xbit(r0);
                                                                                                                            CALL(sub_297);
                                                                                                                            r9 = 0xe00u;
                                                                                                                            r9 = d32(r9+0x88);
                                                                                                                            r9 &= 0xfu;
                                                                                                                            s32(sp+0x40, r9);
                                                                                                                            if (!(r0 == 0x0u)) {
                                                                                                                                L_5fc0:; /* 0x5fc0 */
                                                                                                                                r9 = 0x3bcu;
                                                                                                                                r13 = d32(r9);
                                                                                                                                r10 = 0x1u;
                                                                                                                                r12 = 0x328u;
                                                                                                                                r11 = r10;
                                                                                                                                CALL(sub_7e1);
                                                                                                                                r9 = 0x408u;
                                                                                                                                r13 = d32(r9);
                                                                                                                                r10 = 0x1u;
                                                                                                                                r11 = 0x3u;
                                                                                                                                r12 = 0x3c0u;
                                                                                                                                CALL(sub_7e1);
                                                                                                                                r9 = 0x428u;
                                                                                                                                r13 = d32(r9);
                                                                                                                                r10 = 0x15u;
                                                                                                                                r11 = 0x4u;
                                                                                                                                r12 = 0x41cu;
                                                                                                                                CALL(sub_7e1);
                                                                                                                                L_5ff6:; /* 0x5ff6 */
                                                                                                                                CALL(sub_2175);
                                                                                                                                if (!(r0 == 0x0u)) {
                                                                                                                                    L_5ffe:; /* 0x5ffe */
                                                                                                                                    r9 = 0x130cu;
                                                                                                                                    r9 = d32(r9);
                                                                                                                                    r9 = r9 - 0x1u;
                                                                                                                                    fc_cmp(r9, 0x1u);
                                                                                                                                    if (!(!FC(falcon_flags) && !FZ(falcon_flags))) {
                                                                                                                                        L_600d:; /* 0x600d */
                                                                                                                                        CALL(sub_34fe);
                                                                                                                                        L_6011:; /* 0x6011 */
                                                                                                                                        r15 = 0x3d020000u;
                                                                                                                                        r9 = 0x22a00u;
                                                                                                                                        iowr(r9, r15);
                                                                                                                                        CALL(sub_2c19);
                                                                                                                                        r9 = 0x1324u;
                                                                                                                                        r9 = d32(r9);
                                                                                                                                        if (!(r9 != 0x0u)) {
                                                                                                                                            L_602b:; /* 0x602b */
                                                                                                                                            r15 = d32(sp+0x40);
                                                                                                                                            if (!(r15 != 0x1u)) {
                                                                                                                                                L_6032:; /* 0x6032 */
                                                                                                                                                r10 = r15;
                                                                                                                                                CALL(sub_47c0);
                                                                                                                                                L_6038:; /* 0x6038 */
                                                                                                                                                r9 = 0x12e0u;
                                                                                                                                                r10 = d32(r9);
                                                                                                                                                r9 = 0x12e4u;
                                                                                                                                                r11 = d32(r9);
                                                                                                                                                r9 = 0x12e8u;
                                                                                                                                                r12 = d32(r9);
                                                                                                                                                CALL(sub_32b9);
                                                                                                                                                r15 = 0x37080000u;
                                                                                                                                                r9 = 0x22a00u;
                                                                                                                                                iowr(r9, r15);
                                                                                                                                                r14 = 0xe00u;
                                                                                                                                                r9 = d32(r14+0xf8);
                                                                                                                                                r15 = 0x1324u;
                                                                                                                                                r15 = d32(r15);
                                                                                                                                                r9 = r9 + 0x1u;
                                                                                                                                                s32(r14+0xf8, r9);
                                                                                                                                                if (!(r15 != 0x0u)) {
                                                                                                                                                    L_6071:; /* 0x6071 */
                                                                                                                                                    r10 = 0;
                                                                                                                                                    CALL(sub_415);
                                                                                                                                                    CALL(sub_2c19);
                                                                                                                                                    L_607b:; /* 0x607b */
                                                                                                                                                    CALL(sub_751);
                                                                                                                                                    r15 = 0x3b040000u;
                                                                                                                                                    r9 = 0x22a00u;
                                                                                                                                                    iowr(r9, r15);
                                                                                                                                                    r9 = 0x1324u;
                                                                                                                                                    r9 = d32(r9);
                                                                                                                                                    if (!(r9 != 0x0u)) {
                                                                                                                                                        L_6095:; /* 0x6095 */
                                                                                                                                                        CALL(sub_23fc);
                                                                                                                                                        L_6099:; /* 0x6099 */
                                                                                                                                                        r15 = 0x37080000u;
                                                                                                                                                        r9 = 0x22a00u;
                                                                                                                                                        iowr(r9, r15);
                                                                                                                                                        r10 = 0;
                                                                                                                                                        CALL(sub_29c6);
                                                                                                                                                        r10 = 0x1u;
                                                                                                                                                        r11 = r10;
                                                                                                                                                        r12 = r10;
                                                                                                                                                        CALL(sub_c7b);
                                                                                                                                                        CALL(sub_290c);
                                                                                                                                                        r10 = 0;
                                                                                                                                                        CALL(sub_2988);
                                                                                                                                                        r9 = 0x13c0u;
                                                                                                                                                        r15 = d32(r9);
                                                                                                                                                        r9 = 0x22e00u;
                                                                                                                                                        iowr(r9, r15);
                                                                                                                                                        r15 = 0x4u;
                                                                                                                                                        r9 = r9 + 0x100u;
                                                                                                                                                        iowr(r9, r15);
                                                                                                                                                        r15 = 0x8u;
                                                                                                                                                        r9 = 0x1ac00u;
                                                                                                                                                        iowr(r9, r15);
                                                                                                                                                        r15 = 0x340b0000u;
                                                                                                                                                        r9 = r9 + 0x7e00u;
                                                                                                                                                        iowr(r9, r15);
                                                                                                                                                        r9 = 0x130cu;
                                                                                                                                                        r9 = d32(r9);
                                                                                                                                                        r9 = r9 - 0x1u;
                                                                                                                                                        fc_cmp(r9, 0x1u);
                                                                                                                                                        if (!(!FC(falcon_flags) && !FZ(falcon_flags))) {
                                                                                                                                                            L_60fb:; /* 0x60fb */
                                                                                                                                                            CALL(sub_290c);
                                                                                                                                                            r10 = 0;
                                                                                                                                                            CALL(sub_29c6);
                                                                                                                                                            r10 = 0x1u;
                                                                                                                                                            r11 = r10;
                                                                                                                                                            r12 = r10;
                                                                                                                                                            CALL(sub_cf5);
                                                                                                                                                            CALL(sub_290c);
                                                                                                                                                            r15 = 0x2e110000u;
                                                                                                                                                            r9 = 0x22a00u;
                                                                                                                                                            iowr(r9, r15);
                                                                                                                                                            CALL(sub_3357);
                                                                                                                                                            r10 = 0x1u;
                                                                                                                                                            r11 = r10;
                                                                                                                                                            r12 = r10;
                                                                                                                                                            CALL(sub_c7b);
                                                                                                                                                            CALL(sub_290c);
                                                                                                                                                            r10 = 0;
                                                                                                                                                            CALL(sub_2988);
                                                                                                                                                            L_6137:; /* 0x6137 */
                                                                                                                                                            r9 = 0xe00u;
                                                                                                                                                            r5 = d32(r9+0x10);
                                                                                                                                                            if (!(r5 == 0x0u)) {
                                                                                                                                                                L_6143:; /* 0x6143 */
                                                                                                                                                                r15 = 0xdu;
                                                                                                                                                                r9 = 0x1ac00u;
                                                                                                                                                                iowr(r9, r15);
                                                                                                                                                                r9 = 0xe00u;
                                                                                                                                                                r15 = d32(r9+0x14);
                                                                                                                                                                r0 = d32(r9+0x18);
                                                                                                                                                                r9 = 0x12ecu;
                                                                                                                                                                r12 = d32(r9);
                                                                                                                                                                r15 >>= 0x8u;
                                                                                                                                                                r11 = 0;
                                                                                                                                                                r0 <<= 0x18u;
                                                                                                                                                                r9 = r12 + 0x40u;
                                                                                                                                                                r9 &= 0xffu;
                                                                                                                                                                r12 &= 0x3fu;
                                                                                                                                                                r12 <<= 0x10u;
                                                                                                                                                                r12 |= r9;
                                                                                                                                                                r9 = r5 << 0x3u;
                                                                                                                                                                r9 = r9 + 0xffu;
                                                                                                                                                                r7 = r9 >> 0x8u;
                                                                                                                                                                r9 = d32(sp+0x38);
                                                                                                                                                                r0 |= r15;
                                                                                                                                                                r10 = r0;
                                                                                                                                                                r9 <<= 0x18u;
                                                                                                                                                                r12 |= r9;
                                                                                                                                                                CALL(sub_32b9);
                                                                                                                                                                r15 = 0xc0ffeeb4u;
                                                                                                                                                                r9 = 0x20a00u;
                                                                                                                                                                iowr(r9, r15);
                                                                                                                                                                iowr(r9, r0);
                                                                                                                                                                r4 = 0;
                                                                                                                                                                r3 = 0;
                                                                                                                                                                r8 = 0x2u;
                                                                                                                                                                r6 = 0x20a00u;
                                                                                                                                                                goto L_6209;
                                                                                                                                                                L_61ab:; /* 0x61ab */
                                                                                                                                                                r9 = 0x1u;
                                                                                                                                                                s32(sp, r8);
                                                                                                                                                                s32(sp+0x4, r9);
                                                                                                                                                                s32(sp+0x8, r8);
                                                                                                                                                                r10 = 0;
                                                                                                                                                                r11 = r3 << 0x8u;
                                                                                                                                                                r12 = 0x6u;
                                                                                                                                                                r13 = 0xa00u;
                                                                                                                                                                r14 = 0;
                                                                                                                                                                r1 = 0xa00u;
                                                                                                                                                                CALL(sub_2de1);
                                                                                                                                                                L_61cb:; /* 0x61cb */
                                                                                                                                                                r0 = d32(r1);
                                                                                                                                                                r2 = d32(r1+0x4);
                                                                                                                                                                r10 = r0;
                                                                                                                                                                CALL(sub_4223);
                                                                                                                                                                if (!(r10 == 0x0u)) {
                                                                                                                                                                    L_61da:; /* 0x61da */
                                                                                                                                                                    r10 = 0x23u;
                                                                                                                                                                    CALL(sub_5c0);
                                                                                                                                                                    goto L_61f5;
                                                                                                                                                                    L_61e4:; /* 0x61e4 */
                                                                                                                                                                    iowr(r6, r0);
                                                                                                                                                                    iowr(r6, r2);
                                                                                                                                                                    r10 = r0;
                                                                                                                                                                    r11 = r2;
                                                                                                                                                                    r4 = r4 + 0x1u;
                                                                                                                                                                    CALL(sub_237);
                                                                                                                                                                    L_61f5:; /* 0x61f5 */
                                                                                                                                                                    fc_cmp(r4, r5);
                                                                                                                                                                    if (!FZ(falcon_flags)) {
                                                                                                                                                                        L_61fa:; /* 0x61fa */
                                                                                                                                                                        r1 = r1 + 0x8u;
                                                                                                                                                                        r14 = 0xb00u;
                                                                                                                                                                        fc_cmp(r1, r14);
                                                                                                                                                                        if (!!FZ(falcon_flags)) {
                                                                                                                                                                            L_6206:; /* 0x6206 */
                                                                                                                                                                            r3 = r3 + 0x1u;
                                                                                                                                                                            L_6209:; /* 0x6209 */
                                                                                                                                                                            fc_cmp(r3, r7);
                                                                                                                                                                            if (FC(falcon_flags)) goto L_61ab;
                                                                                                                                                                            L_620e:; /* 0x620e */
                                                                                                                                                                            r9 = 0x12e0u;
                                                                                                                                                                            r10 = d32(r9);
                                                                                                                                                                            r9 = 0x12e4u;
                                                                                                                                                                            r11 = d32(r9);
                                                                                                                                                                            r9 = 0x12e8u;
                                                                                                                                                                            r12 = d32(r9);
                                                                                                                                                                            CALL(sub_32b9);
                                                                                                                                                                            r15 = 0;
                                                                                                                                                                            r9 = 0xe00u;
                                                                                                                                                                            r10 = 0x1209fcu;
                                                                                                                                                                            s32(r9+0x10, r15);
                                                                                                                                                                            r11 = 0x10fe7ceu;
                                                                                                                                                                            CALL(sub_237);
                                                                                                                                                                            r10 = 0x1211fcu;
                                                                                                                                                                            r11 = 0x20fe7ceu;
                                                                                                                                                                            CALL(sub_237);
                                                                                                                                                                            r9 = 0x13c0u;
                                                                                                                                                                            r15 = d32(r9);
                                                                                                                                                                            r9 = 0x22e00u;
                                                                                                                                                                            iowr(r9, r15);
                                                                                                                                                                            r15 = 0xdu;
                                                                                                                                                                            r9 = r9 + 0x100u;
                                                                                                                                                                            iowr(r9, r15);
                                                                                                                                                                            r15 = 0x8u;
                                                                                                                                                                            r9 = 0x1ac00u;
                                                                                                                                                                            iowr(r9, r15);
                                                                                                                                                                            r3 = 0x1u;
                                                                                                                                                                            L_6269:; /* 0x6269 */
                                                                                                                                                                            r15 = 0x37080000u;
                                                                                                                                                                            r9 = 0x22a00u;
                                                                                                                                                                            iowr(r9, r15);
                                                                                                                                                                            r9 = 0x145cu;
                                                                                                                                                                            r9 = d32(r9);
                                                                                                                                                                            if (!(r9 == 0x0u)) {
                                                                                                                                                                                L_6280:; /* 0x6280 */
                                                                                                                                                                                r9 = 0x1320u;
                                                                                                                                                                                r9 = d32(r9);
                                                                                                                                                                                if (!(r9 != 0x1u)) {
                                                                                                                                                                                    L_628a:; /* 0x628a */
                                                                                                                                                                                    r9 = 0x30u;
                                                                                                                                                                                    r9 = d32(r9);
                                                                                                                                                                                    if (!(r9 != 0x1u)) {
                                                                                                                                                                                        L_6294:; /* 0x6294 */
                                                                                                                                                                                        r15 = 0x300f0000u;
                                                                                                                                                                                        r9 = 0x22a00u;
                                                                                                                                                                                        iowr(r9, r15);
                                                                                                                                                                                        CALL(sub_10f8);
                                                                                                                                                                                        r9 = 0x1484u;
                                                                                                                                                                                        s32(r9, r10);
                                                                                                                                                                                        r9 = -0x1u;
                                                                                                                                                                                        fc_cmp(r10, r9);
                                                                                                                                                                                        if (!FZ(falcon_flags)) {
                                                                                                                                                                                            L_62b1:; /* 0x62b1 */
                                                                                                                                                                                            r13 = 0xe00u;
                                                                                                                                                                                            r14 = d32(r13+0x38);
                                                                                                                                                                                            r15 = -0xff01u;
                                                                                                                                                                                            r9 = r10 << 0x8u;
                                                                                                                                                                                            r9 &= 0xffffu;
                                                                                                                                                                                            r14 &= r15;
                                                                                                                                                                                            r9 |= r14;
                                                                                                                                                                                            r10 = 0x2u;
                                                                                                                                                                                            s32(r13+0x38, r9);
                                                                                                                                                                                            CALL(sub_1070);
                                                                                                                                                                                            r13 = 0x1494u;
                                                                                                                                                                                            r15 = d32(r13);
                                                                                                                                                                                            r14 = -0x100u;
                                                                                                                                                                                            r9 = r15 + 0x1u;
                                                                                                                                                                                            r15 &= r14;
                                                                                                                                                                                            r9 &= 0xffu;
                                                                                                                                                                                            r9 |= r15;
                                                                                                                                                                                            s32(r13, r9);
                                                                                                                                                                                            L_62e9:; /* 0x62e9 */
                                                                                                                                                                                            r10 = d32(sp+0x3c);
                                                                                                                                                                                            CALL(sub_1196);
                                                                                                                                                                                            r15 = 0x37080000u;
                                                                                                                                                                                            r9 = 0x22a00u;
                                                                                                                                                                                            iowr(r9, r15);
                                                                                                                                                                                            r3 = 0x1u;
                                                                                                                                                                                            r0 = r3;
                                                                                                                                                                                            goto L_6306;
                                                                                                                                                                                            L_6304:; /* 0x6304 */
                                                                                                                                                                                            r0 = 0;
                                                                                                                                                                                            L_6306:; /* 0x6306 */
                                                                                                                                                                                            r15 = d32(sp+0x40);
                                                                                                                                                                                            if (!(r15 == 0x0u)) {
                                                                                                                                                                                                L_630d:; /* 0x630d */
                                                                                                                                                                                                if (!(r15 == 0x1u)) {
                                                                                                                                                                                                    L_6311:; /* 0x6311 */
                                                                                                                                                                                                    r13 = 0;
                                                                                                                                                                                                    goto L_6358;
                                                                                                                                                                                                    L_6317:; /* 0x6317 */
                                                                                                                                                                                                    r9 = 0x1494u;
                                                                                                                                                                                                    r15 = d32(r9+0x8);
                                                                                                                                                                                                    r14 = 0xffffffu;
                                                                                                                                                                                                    r13 = 0;
                                                                                                                                                                                                    r14 = r15 & r14;
                                                                                                                                                                                                    r15 >>= 0x18u;
                                                                                                                                                                                                    r15 = r15 + 0x1u;
                                                                                                                                                                                                    r15 <<= 0x18u;
                                                                                                                                                                                                    goto L_6352;
                                                                                                                                                                                                    L_6335:; /* 0x6335 */
                                                                                                                                                                                                    r9 = 0x1494u;
                                                                                                                                                                                                    r15 = d32(r9+0x8);
                                                                                                                                                                                                    r14 = -0xff01u;
                                                                                                                                                                                                    r13 = 0x2u;
                                                                                                                                                                                                    r14 = r15 & r14;
                                                                                                                                                                                                    r15 &= 0xff00u;
                                                                                                                                                                                                    r15 = r15 + 0x100u;
                                                                                                                                                                                                    r15 &= 0xffffu;
                                                                                                                                                                                                    L_6352:; /* 0x6352 */
                                                                                                                                                                                                    r15 |= r14;
                                                                                                                                                                                                    s32(r9+0x8, r15);
                                                                                                                                                                                                    L_6358:; /* 0x6358 */
                                                                                                                                                                                                    r9 = d32(sp+0x34);
                                                                                                                                                                                                    if (!(r9 == 0x1u)) {
                                                                                                                                                                                                        L_635f:; /* 0x635f */
                                                                                                                                                                                                        if (!(r9 == 0x2u)) {
                                                                                                                                                                                                            L_6363:; /* 0x6363 */
                                                                                                                                                                                                            r11 = 0;
                                                                                                                                                                                                            goto L_636c;
                                                                                                                                                                                                            L_6369:; /* 0x6369 */
                                                                                                                                                                                                            r11 = d32(sp+0x34);
                                                                                                                                                                                                            L_636c:; /* 0x636c */
                                                                                                                                                                                                            r9 = r13 << 0x4u;
                                                                                                                                                                                                            r9 |= 0x1u;
                                                                                                                                                                                                            r11 &= 0x3u;
                                                                                                                                                                                                            r10 = 0x4041b4u;
                                                                                                                                                                                                            r11 <<= 0x8u;
                                                                                                                                                                                                            r11 = r9 | r11;
                                                                                                                                                                                                            CALL(sub_237);
                                                                                                                                                                                                            if (!(r3 == 0x0u)) {
                                                                                                                                                                                                                L_6387:; /* 0x6387 */
                                                                                                                                                                                                                r15 = 0x320d0000u;
                                                                                                                                                                                                                r9 = 0x22a00u;
                                                                                                                                                                                                                iowr(r9, r15);
                                                                                                                                                                                                                r10 = 0x2u;
                                                                                                                                                                                                                CALL(sub_2f4a);
                                                                                                                                                                                                                L_6399:; /* 0x6399 */
                                                                                                                                                                                                                if (!(r0 == 0x0u)) {
                                                                                                                                                                                                                    L_639d:; /* 0x639d */
                                                                                                                                                                                                                    r15 = 0x300f0000u;
                                                                                                                                                                                                                    r9 = 0x22a00u;
                                                                                                                                                                                                                    iowr(r9, r15);
                                                                                                                                                                                                                    CALL(sub_37e1);
                                                                                                                                                                                                                    L_63ad:; /* 0x63ad */
                                                                                                                                                                                                                    r15 = 0x37080000u;
                                                                                                                                                                                                                    r9 = 0x22a00u;
                                                                                                                                                                                                                    iowr(r9, r15);
                                                                                                                                                                                                                    r14 = d32(sp+0x30);
                                                                                                                                                                                                                    r9 = 0x144cu;
                                                                                                                                                                                                                    r15 = 0x1u;
                                                                                                                                                                                                                    s32(r9, r14);
                                                                                                                                                                                                                    r9 = 0x1450u;
                                                                                                                                                                                                                    s32(r9, r15);
                                                                                                                                                                                                                    r9 = 0x1454u;
                                                                                                                                                                                                                    s32(r9, r15);
                                                                                                                                                                                                                    r15 = 0;
                                                                                                                                                                                                                    r9 = 0x1ac00u;
                                                                                                                                                                                                                    iowr(r9, r15);
                                                                                                                                                                                                                    r9 = 0x14c4u;
                                                                                                                                                                                                                    r9 = d32(r9);
                                                                                                                                                                                                                    if (!(r9 == 0x0u)) {
                                                                                                                                                                                                                        L_63e3:; /* 0x63e3 */
                                                                                                                                                                                                                        r9 = 0x14b4u;
                                                                                                                                                                                                                        r9 = d32(r9);
                                                                                                                                                                                                                        if (!(r9 == 0x0u)) {
                                                                                                                                                                                                                            L_63ed:; /* 0x63ed */
                                                                                                                                                                                                                            r15 = 0x2f100000u;
                                                                                                                                                                                                                            r9 = 0x22a00u;
                                                                                                                                                                                                                            iowr(r9, r15);
                                                                                                                                                                                                                            r11 = 0x5u;
                                                                                                                                                                                                                            r10 = 0xeu;
                                                                                                                                                                                                                            CALL(sub_557b);
                                                                                                                                                                                                                            r10 = d32(sp+0x38);
                                                                                                                                                                                                                            CALL(sub_56ad);
                                                                                                                                                                                                                            r15 = 0x37080000u;
                                                                                                                                                                                                                            r9 = 0x22a00u;
                                                                                                                                                                                                                            iowr(r9, r15);
                                                                                                                                                                                                                            L_6414:; /* 0x6414 */
                                                                                                                                                                                                                            r15 = 0;
                                                                                                                                                                                                                            r9 = 0x10c00u;
                                                                                                                                                                                                                            iowr(r9, r15);
                                                                                                                                                                                                                            r10 = 0x1u;
                                                                                                                                                                                                                            CALL(sub_791);
                                                                                                                                                                                                                            r9 = 0x9f0u;
                                                                                                                                                                                                                            r15 = 0;
                                                                                                                                                                                                                            s32(r9, r15);
                                                                                                                                                                                                                            r9 = 0x1494u;
                                                                                                                                                                                                                            r15 = d32(r9);
                                                                                                                                                                                                                            r9 = 0x20a00u;
                                                                                                                                                                                                                            iowr(r9, r15);
                                                                                                                                                                                                                            r9 = 0x1494u;
                                                                                                                                                                                                                            r15 = d32(r9+0x4);
                                                                                                                                                                                                                            r9 = 0x20b00u;
                                                                                                                                                                                                                            iowr(r9, r15);
                                                                                                                                                                                                                            r9 = 0x1494u;
                                                                                                                                                                                                                            r15 = d32(r9+0x8);
                                                                                                                                                                                                                            r9 = 0x20c00u;
                                                                                                                                                                                                                            iowr(r9, r15);
                                                                                                                                                                                                                            r9 = 0xc00u;
                                                                                                                                                                                                                            r15 = d32(r9+0x34);
                                                                                                                                                                                                                            r9 = 0x20d00u;
                                                                                                                                                                                                                            iowr(r9, r15);
                                                                                                                                                                                                                            CALL(sub_2175);
                                                                                                                                                                                                                            r15 = 0x4u;
                                                                                                                                                                                                                            r9 = 0x20000u;
                                                                                                                                                                                                                            iowr(r9, r15);
                                                                                                                                                                                                                            r15 = 0x3f000000u;
                                                                                                                                                                                                                            r9 = r9 + 0x2a00u;
                                                                                                                                                                                                                            L_6479:; /* 0x6479 */
                                                                                                                                                                                                                            iowr(r9, r15);
                                                                                                                                                                                                                            r15 = 0x80000000u;
                                                                                                                                                                                                                            iowr(r9, r15);
                                                                                                                                                                                                                            r15 = 0x80000u;
                                                                                                                                                                                                                            r9 = r9 - 0x1200u;
                                                                                                                                                                                                                            iowr(r9, r15);
                                                                                                                                                                                                                            r9 = sp;
                                                                                                                                                                                                                            r9 = r9 + 0x74u;
                                                                                                                                                                                                                            r15 = d32(r9);
                                                                                                                                                                                                                            r9 = 0x1604u;
                                                                                                                                                                                                                            r9 = d32(r9);
                                                                                                                                                                                                                            fc_cmp(r15, r9);
                                                                                                                                                                                                                            if (!FZ(falcon_flags)) {
                                                                                                                                                                                                                                L_64a3:; /* 0x64a3 */
                                                                                                                                                                                                                                CALL(sub_747);
                                                                                                                                                                                                                                L_64a7:; /* 0x64a7 */
                                                                                                                                                                                                                                sp += 0xcu;
                                                                                                                                                                                                                                for (int i = 0; i <= 8; i++) r[i] = pop32();
                                                                                                                                                                                                                                sp += 0x48;
                                                                                                                                                                                                                                return;
                                                                                                                                                                                                                            }
                                                                                                                                                                                                                            goto L_64a7;  /* 重复引用 */
                                                                                                                                                                                                                        }
                                                                                                                                                                                                                        goto L_6414;  /* 重复引用 */
                                                                                                                                                                                                                        goto L_63ed;  /* 重复引用 */
                                                                                                                                                                                                                    }
                                                                                                                                                                                                                    goto L_6414;  /* 重复引用 */
                                                                                                                                                                                                                }
                                                                                                                                                                                                                goto L_63ad;  /* 重复引用 */
                                                                                                                                                                                                            }
                                                                                                                                                                                                            goto L_6399;  /* 重复引用 */
                                                                                                                                                                                                        }
                                                                                                                                                                                                        goto L_6369;  /* 重复引用 */
                                                                                                                                                                                                        goto L_6363;  /* 重复引用 */
                                                                                                                                                                                                    }
                                                                                                                                                                                                    goto L_6369;  /* 重复引用 */
                                                                                                                                                                                                }
                                                                                                                                                                                                goto L_6335;  /* 重复引用 */
                                                                                                                                                                                                goto L_6311;  /* 重复引用 */
                                                                                                                                                                                                goto L_6335;  /* 重复引用 */
                                                                                                                                                                                            }
                                                                                                                                                                                            goto L_6317;  /* 重复引用 */
                                                                                                                                                                                        }
                                                                                                                                                                                        goto L_62e9;  /* 重复引用 */
                                                                                                                                                                                        goto L_62b1;  /* 重复引用 */
                                                                                                                                                                                        goto L_62e9;  /* 重复引用 */
                                                                                                                                                                                    }
                                                                                                                                                                                    goto L_6304;  /* 重复引用 */
                                                                                                                                                                                    goto L_6294;  /* 重复引用 */
                                                                                                                                                                                    goto L_62b1;  /* 重复引用 */
                                                                                                                                                                                    goto L_62e9;  /* 重复引用 */
                                                                                                                                                                                }
                                                                                                                                                                                goto L_6304;  /* 重复引用 */
                                                                                                                                                                                goto L_628a;  /* 重复引用 */
                                                                                                                                                                                goto L_6294;  /* 重复引用 */
                                                                                                                                                                                goto L_62b1;  /* 重复引用 */
                                                                                                                                                                                goto L_62e9;  /* 重复引用 */
                                                                                                                                                                            }
                                                                                                                                                                            goto L_6304;  /* 重复引用 */
                                                                                                                                                                        }
                                                                                                                                                                        goto L_61cb;  /* 重复引用 */
                                                                                                                                                                        goto L_6206;  /* 重复引用 */
                                                                                                                                                                    }
                                                                                                                                                                    goto L_620e;  /* 重复引用 */
                                                                                                                                                                }
                                                                                                                                                                goto L_61e4;  /* 重复引用 */
                                                                                                                                                                goto L_61ab;  /* 重复引用 */
                                                                                                                                                                goto L_61cb;  /* 重复引用 */
                                                                                                                                                                goto L_61da;  /* 重复引用 */
                                                                                                                                                                goto L_61e4;  /* 重复引用 */
                                                                                                                                                                goto L_61f5;  /* 重复引用 */
                                                                                                                                                                goto L_61fa;  /* 重复引用 */
                                                                                                                                                                goto L_6206;  /* 重复引用 */
                                                                                                                                                                goto L_6209;  /* 重复引用 */
                                                                                                                                                                goto L_620e;  /* 重复引用 */
                                                                                                                                                            }
                                                                                                                                                            goto L_6269;  /* 重复引用 */
                                                                                                                                                        }
                                                                                                                                                        goto L_6137;  /* 重复引用 */
                                                                                                                                                    }
                                                                                                                                                    goto L_6099;  /* 重复引用 */
                                                                                                                                                }
                                                                                                                                                goto L_607b;  /* 重复引用 */
                                                                                                                                            }
                                                                                                                                            goto L_6038;  /* 重复引用 */
                                                                                                                                            goto L_6032;  /* 重复引用 */
                                                                                                                                        }
                                                                                                                                        goto L_6038;  /* 重复引用 */
                                                                                                                                    }
                                                                                                                                    goto L_6011;  /* 重复引用 */
                                                                                                                                    goto L_600d;  /* 重复引用 */
                                                                                                                                }
                                                                                                                                goto L_6011;  /* 重复引用 */
                                                                                                                            }
                                                                                                                            goto L_5ff6;  /* 重复引用 */
                                                                                                                        }
                                                                                                                        goto L_5f78;  /* 重复引用 */
                                                                                                                    }
                                                                                                                    goto L_5f4e;  /* 重复引用 */
                                                                                                                    goto L_5f22;  /* 重复引用 */
                                                                                                                    goto L_5f3c;  /* 重复引用 */
                                                                                                                    goto L_5f4e;  /* 重复引用 */
                                                                                                                    goto L_5f64;  /* 重复引用 */
                                                                                                                    goto L_5f78;  /* 重复引用 */
                                                                                                                    goto L_5fc0;  /* 重复引用 */
                                                                                                                    goto L_5ff6;  /* 重复引用 */
                                                                                                                    goto L_5ffe;  /* 重复引用 */
                                                                                                                    goto L_600d;  /* 重复引用 */
                                                                                                                    goto L_6011;  /* 重复引用 */
                                                                                                                    goto L_602b;  /* 重复引用 */
                                                                                                                    goto L_6032;  /* 重复引用 */
                                                                                                                    goto L_6038;  /* 重复引用 */
                                                                                                                    goto L_6071;  /* 重复引用 */
                                                                                                                    goto L_607b;  /* 重复引用 */
                                                                                                                    goto L_6095;  /* 重复引用 */
                                                                                                                    goto L_6099;  /* 重复引用 */
                                                                                                                    goto L_60fb;  /* 重复引用 */
                                                                                                                    goto L_6137;  /* 重复引用 */
                                                                                                                    goto L_6143;  /* 重复引用 */
                                                                                                                    goto L_61ab;  /* 重复引用 */
                                                                                                                    goto L_61cb;  /* 重复引用 */
                                                                                                                    goto L_61da;  /* 重复引用 */
                                                                                                                    goto L_61e4;  /* 重复引用 */
                                                                                                                    goto L_61f5;  /* 重复引用 */
                                                                                                                    goto L_61fa;  /* 重复引用 */
                                                                                                                    goto L_6206;  /* 重复引用 */
                                                                                                                    goto L_6209;  /* 重复引用 */
                                                                                                                    goto L_620e;  /* 重复引用 */
                                                                                                                    goto L_6269;  /* 重复引用 */
                                                                                                                    goto L_6280;  /* 重复引用 */
                                                                                                                    goto L_628a;  /* 重复引用 */
                                                                                                                    goto L_6294;  /* 重复引用 */
                                                                                                                    goto L_62b1;  /* 重复引用 */
                                                                                                                    goto L_62e9;  /* 重复引用 */
                                                                                                                    goto L_6304;  /* 重复引用 */
                                                                                                                    goto L_6306;  /* 重复引用 */
                                                                                                                    goto L_630d;  /* 重复引用 */
                                                                                                                    goto L_6311;  /* 重复引用 */
                                                                                                                    goto L_6317;  /* 重复引用 */
                                                                                                                    goto L_6335;  /* 重复引用 */
                                                                                                                    goto L_6352;  /* 重复引用 */
                                                                                                                    goto L_6358;  /* 重复引用 */
                                                                                                                    goto L_635f;  /* 重复引用 */
                                                                                                                    goto L_6363;  /* 重复引用 */
                                                                                                                    goto L_6369;  /* 重复引用 */
                                                                                                                    goto L_636c;  /* 重复引用 */
                                                                                                                    goto L_6387;  /* 重复引用 */
                                                                                                                    goto L_6399;  /* 重复引用 */
                                                                                                                    goto L_639d;  /* 重复引用 */
                                                                                                                    goto L_63ad;  /* 重复引用 */
                                                                                                                    goto L_63e3;  /* 重复引用 */
                                                                                                                    goto L_63ed;  /* 重复引用 */
                                                                                                                    goto L_6414;  /* 重复引用 */
                                                                                                                }
                                                                                                                goto L_5ef2;  /* 重复引用 */
                                                                                                                goto L_5ee5;  /* 重复引用 */
                                                                                                                goto L_5f22;  /* 重复引用 */
                                                                                                                goto L_5f3c;  /* 重复引用 */
                                                                                                                goto L_5f4e;  /* 重复引用 */
                                                                                                                goto L_5f64;  /* 重复引用 */
                                                                                                                goto L_5f78;  /* 重复引用 */
                                                                                                                goto L_5fc0;  /* 重复引用 */
                                                                                                                goto L_5ff6;  /* 重复引用 */
                                                                                                                goto L_5ffe;  /* 重复引用 */
                                                                                                                goto L_600d;  /* 重复引用 */
                                                                                                                goto L_6011;  /* 重复引用 */
                                                                                                                goto L_602b;  /* 重复引用 */
                                                                                                                goto L_6032;  /* 重复引用 */
                                                                                                                goto L_6038;  /* 重复引用 */
                                                                                                                goto L_6071;  /* 重复引用 */
                                                                                                                goto L_607b;  /* 重复引用 */
                                                                                                                goto L_6095;  /* 重复引用 */
                                                                                                                goto L_6099;  /* 重复引用 */
                                                                                                                goto L_60fb;  /* 重复引用 */
                                                                                                                goto L_6137;  /* 重复引用 */
                                                                                                                goto L_6143;  /* 重复引用 */
                                                                                                                goto L_61ab;  /* 重复引用 */
                                                                                                                goto L_61cb;  /* 重复引用 */
                                                                                                                goto L_61da;  /* 重复引用 */
                                                                                                                goto L_61e4;  /* 重复引用 */
                                                                                                                goto L_61f5;  /* 重复引用 */
                                                                                                                goto L_61fa;  /* 重复引用 */
                                                                                                                goto L_6206;  /* 重复引用 */
                                                                                                                goto L_6209;  /* 重复引用 */
                                                                                                                goto L_620e;  /* 重复引用 */
                                                                                                                goto L_6269;  /* 重复引用 */
                                                                                                                goto L_6280;  /* 重复引用 */
                                                                                                                goto L_628a;  /* 重复引用 */
                                                                                                                goto L_6294;  /* 重复引用 */
                                                                                                                goto L_62b1;  /* 重复引用 */
                                                                                                                goto L_62e9;  /* 重复引用 */
                                                                                                                goto L_6304;  /* 重复引用 */
                                                                                                                goto L_6306;  /* 重复引用 */
                                                                                                                goto L_630d;  /* 重复引用 */
                                                                                                                goto L_6311;  /* 重复引用 */
                                                                                                                goto L_6317;  /* 重复引用 */
                                                                                                                goto L_6335;  /* 重复引用 */
                                                                                                                goto L_6352;  /* 重复引用 */
                                                                                                                goto L_6358;  /* 重复引用 */
                                                                                                                goto L_635f;  /* 重复引用 */
                                                                                                                goto L_6363;  /* 重复引用 */
                                                                                                                goto L_6369;  /* 重复引用 */
                                                                                                                goto L_636c;  /* 重复引用 */
                                                                                                                goto L_6387;  /* 重复引用 */
                                                                                                                goto L_6399;  /* 重复引用 */
                                                                                                                goto L_639d;  /* 重复引用 */
                                                                                                                goto L_63ad;  /* 重复引用 */
                                                                                                                goto L_63e3;  /* 重复引用 */
                                                                                                                goto L_63ed;  /* 重复引用 */
                                                                                                                goto L_6414;  /* 重复引用 */
                                                                                                            }
                                                                                                            goto L_5ef2;  /* 重复引用 */
                                                                                                            goto L_5ed8;  /* 重复引用 */
                                                                                                            goto L_5ee5;  /* 重复引用 */
                                                                                                            goto L_5f22;  /* 重复引用 */
                                                                                                            goto L_5f3c;  /* 重复引用 */
                                                                                                            goto L_5f4e;  /* 重复引用 */
                                                                                                            goto L_5f64;  /* 重复引用 */
                                                                                                            goto L_5f78;  /* 重复引用 */
                                                                                                            goto L_5fc0;  /* 重复引用 */
                                                                                                            goto L_5ff6;  /* 重复引用 */
                                                                                                            goto L_5ffe;  /* 重复引用 */
                                                                                                            goto L_600d;  /* 重复引用 */
                                                                                                            goto L_6011;  /* 重复引用 */
                                                                                                            goto L_602b;  /* 重复引用 */
                                                                                                            goto L_6032;  /* 重复引用 */
                                                                                                            goto L_6038;  /* 重复引用 */
                                                                                                            goto L_6071;  /* 重复引用 */
                                                                                                            goto L_607b;  /* 重复引用 */
                                                                                                            goto L_6095;  /* 重复引用 */
                                                                                                            goto L_6099;  /* 重复引用 */
                                                                                                            goto L_60fb;  /* 重复引用 */
                                                                                                            goto L_6137;  /* 重复引用 */
                                                                                                            goto L_6143;  /* 重复引用 */
                                                                                                            goto L_61ab;  /* 重复引用 */
                                                                                                            goto L_61cb;  /* 重复引用 */
                                                                                                            goto L_61da;  /* 重复引用 */
                                                                                                            goto L_61e4;  /* 重复引用 */
                                                                                                            goto L_61f5;  /* 重复引用 */
                                                                                                            goto L_61fa;  /* 重复引用 */
                                                                                                            goto L_6206;  /* 重复引用 */
                                                                                                            goto L_6209;  /* 重复引用 */
                                                                                                            goto L_620e;  /* 重复引用 */
                                                                                                            goto L_6269;  /* 重复引用 */
                                                                                                            goto L_6280;  /* 重复引用 */
                                                                                                            goto L_628a;  /* 重复引用 */
                                                                                                            goto L_6294;  /* 重复引用 */
                                                                                                            goto L_62b1;  /* 重复引用 */
                                                                                                            goto L_62e9;  /* 重复引用 */
                                                                                                            goto L_6304;  /* 重复引用 */
                                                                                                            goto L_6306;  /* 重复引用 */
                                                                                                            goto L_630d;  /* 重复引用 */
                                                                                                            goto L_6311;  /* 重复引用 */
                                                                                                            goto L_6317;  /* 重复引用 */
                                                                                                            goto L_6335;  /* 重复引用 */
                                                                                                            goto L_6352;  /* 重复引用 */
                                                                                                            goto L_6358;  /* 重复引用 */
                                                                                                            goto L_635f;  /* 重复引用 */
                                                                                                            goto L_6363;  /* 重复引用 */
                                                                                                            goto L_6369;  /* 重复引用 */
                                                                                                            goto L_636c;  /* 重复引用 */
                                                                                                            goto L_6387;  /* 重复引用 */
                                                                                                            goto L_6399;  /* 重复引用 */
                                                                                                            goto L_639d;  /* 重复引用 */
                                                                                                            goto L_63ad;  /* 重复引用 */
                                                                                                            goto L_63e3;  /* 重复引用 */
                                                                                                            goto L_63ed;  /* 重复引用 */
                                                                                                            goto L_6414;  /* 重复引用 */
                                                                                                        }
                                                                                                        goto L_5ef2;  /* 重复引用 */
                                                                                                    }
                                                                                                    goto L_5eb3;  /* 重复引用 */
                                                                                                }
                                                                                                goto L_5e8e;  /* 重复引用 */
                                                                                            }
                                                                                            goto L_5e6e;  /* 重复引用 */
                                                                                            goto L_5e54;  /* 重复引用 */
                                                                                            goto L_5e6a;  /* 重复引用 */
                                                                                            goto L_5e6e;  /* 重复引用 */
                                                                                            goto L_5e88;  /* 重复引用 */
                                                                                            goto L_5e8e;  /* 重复引用 */
                                                                                            goto L_5ea0;  /* 重复引用 */
                                                                                            goto L_5eb3;  /* 重复引用 */
                                                                                            goto L_5ecb;  /* 重复引用 */
                                                                                            goto L_5ed8;  /* 重复引用 */
                                                                                            goto L_5ee5;  /* 重复引用 */
                                                                                            goto L_5ef2;  /* 重复引用 */
                                                                                            goto L_5f22;  /* 重复引用 */
                                                                                            goto L_5f3c;  /* 重复引用 */
                                                                                            goto L_5f4e;  /* 重复引用 */
                                                                                            goto L_5f64;  /* 重复引用 */
                                                                                            goto L_5f78;  /* 重复引用 */
                                                                                            goto L_5fc0;  /* 重复引用 */
                                                                                            goto L_5ff6;  /* 重复引用 */
                                                                                            goto L_5ffe;  /* 重复引用 */
                                                                                            goto L_600d;  /* 重复引用 */
                                                                                            goto L_6011;  /* 重复引用 */
                                                                                            goto L_602b;  /* 重复引用 */
                                                                                            goto L_6032;  /* 重复引用 */
                                                                                            goto L_6038;  /* 重复引用 */
                                                                                            goto L_6071;  /* 重复引用 */
                                                                                            goto L_607b;  /* 重复引用 */
                                                                                            goto L_6095;  /* 重复引用 */
                                                                                            goto L_6099;  /* 重复引用 */
                                                                                            goto L_60fb;  /* 重复引用 */
                                                                                            goto L_6137;  /* 重复引用 */
                                                                                            goto L_6143;  /* 重复引用 */
                                                                                            goto L_61ab;  /* 重复引用 */
                                                                                            goto L_61cb;  /* 重复引用 */
                                                                                            goto L_61da;  /* 重复引用 */
                                                                                            goto L_61e4;  /* 重复引用 */
                                                                                            goto L_61f5;  /* 重复引用 */
                                                                                            goto L_61fa;  /* 重复引用 */
                                                                                            goto L_6206;  /* 重复引用 */
                                                                                            goto L_6209;  /* 重复引用 */
                                                                                            goto L_620e;  /* 重复引用 */
                                                                                            goto L_6269;  /* 重复引用 */
                                                                                            goto L_6280;  /* 重复引用 */
                                                                                            goto L_628a;  /* 重复引用 */
                                                                                            goto L_6294;  /* 重复引用 */
                                                                                            goto L_62b1;  /* 重复引用 */
                                                                                            goto L_62e9;  /* 重复引用 */
                                                                                            goto L_6304;  /* 重复引用 */
                                                                                            goto L_6306;  /* 重复引用 */
                                                                                            goto L_630d;  /* 重复引用 */
                                                                                            goto L_6311;  /* 重复引用 */
                                                                                            goto L_6317;  /* 重复引用 */
                                                                                            goto L_6335;  /* 重复引用 */
                                                                                            goto L_6352;  /* 重复引用 */
                                                                                            goto L_6358;  /* 重复引用 */
                                                                                            goto L_635f;  /* 重复引用 */
                                                                                            goto L_6363;  /* 重复引用 */
                                                                                            goto L_6369;  /* 重复引用 */
                                                                                            goto L_636c;  /* 重复引用 */
                                                                                            goto L_6387;  /* 重复引用 */
                                                                                            goto L_6399;  /* 重复引用 */
                                                                                            goto L_639d;  /* 重复引用 */
                                                                                            goto L_63ad;  /* 重复引用 */
                                                                                            goto L_63e3;  /* 重复引用 */
                                                                                            goto L_63ed;  /* 重复引用 */
                                                                                            goto L_6414;  /* 重复引用 */
                                                                                        }
                                                                                        goto L_5e36;  /* 重复引用 */
                                                                                        goto L_5e29;  /* 重复引用 */
                                                                                        goto L_5e54;  /* 重复引用 */
                                                                                        goto L_5e6a;  /* 重复引用 */
                                                                                        goto L_5e6e;  /* 重复引用 */
                                                                                        goto L_5e88;  /* 重复引用 */
                                                                                        goto L_5e8e;  /* 重复引用 */
                                                                                        goto L_5ea0;  /* 重复引用 */
                                                                                        goto L_5eb3;  /* 重复引用 */
                                                                                        goto L_5ecb;  /* 重复引用 */
                                                                                        goto L_5ed8;  /* 重复引用 */
                                                                                        goto L_5ee5;  /* 重复引用 */
                                                                                        goto L_5ef2;  /* 重复引用 */
                                                                                        goto L_5f22;  /* 重复引用 */
                                                                                        goto L_5f3c;  /* 重复引用 */
                                                                                        goto L_5f4e;  /* 重复引用 */
                                                                                        goto L_5f64;  /* 重复引用 */
                                                                                        goto L_5f78;  /* 重复引用 */
                                                                                        goto L_5fc0;  /* 重复引用 */
                                                                                        goto L_5ff6;  /* 重复引用 */
                                                                                        goto L_5ffe;  /* 重复引用 */
                                                                                        goto L_600d;  /* 重复引用 */
                                                                                        goto L_6011;  /* 重复引用 */
                                                                                        goto L_602b;  /* 重复引用 */
                                                                                        goto L_6032;  /* 重复引用 */
                                                                                        goto L_6038;  /* 重复引用 */
                                                                                        goto L_6071;  /* 重复引用 */
                                                                                        goto L_607b;  /* 重复引用 */
                                                                                        goto L_6095;  /* 重复引用 */
                                                                                        goto L_6099;  /* 重复引用 */
                                                                                        goto L_60fb;  /* 重复引用 */
                                                                                        goto L_6137;  /* 重复引用 */
                                                                                        goto L_6143;  /* 重复引用 */
                                                                                        goto L_61ab;  /* 重复引用 */
                                                                                        goto L_61cb;  /* 重复引用 */
                                                                                        goto L_61da;  /* 重复引用 */
                                                                                        goto L_61e4;  /* 重复引用 */
                                                                                        goto L_61f5;  /* 重复引用 */
                                                                                        goto L_61fa;  /* 重复引用 */
                                                                                        goto L_6206;  /* 重复引用 */
                                                                                        goto L_6209;  /* 重复引用 */
                                                                                        goto L_620e;  /* 重复引用 */
                                                                                        goto L_6269;  /* 重复引用 */
                                                                                        goto L_6280;  /* 重复引用 */
                                                                                        goto L_628a;  /* 重复引用 */
                                                                                        goto L_6294;  /* 重复引用 */
                                                                                        goto L_62b1;  /* 重复引用 */
                                                                                        goto L_62e9;  /* 重复引用 */
                                                                                        goto L_6304;  /* 重复引用 */
                                                                                        goto L_6306;  /* 重复引用 */
                                                                                        goto L_630d;  /* 重复引用 */
                                                                                        goto L_6311;  /* 重复引用 */
                                                                                        goto L_6317;  /* 重复引用 */
                                                                                        goto L_6335;  /* 重复引用 */
                                                                                        goto L_6352;  /* 重复引用 */
                                                                                        goto L_6358;  /* 重复引用 */
                                                                                        goto L_635f;  /* 重复引用 */
                                                                                        goto L_6363;  /* 重复引用 */
                                                                                        goto L_6369;  /* 重复引用 */
                                                                                        goto L_636c;  /* 重复引用 */
                                                                                        goto L_6387;  /* 重复引用 */
                                                                                        goto L_6399;  /* 重复引用 */
                                                                                        goto L_639d;  /* 重复引用 */
                                                                                        goto L_63ad;  /* 重复引用 */
                                                                                        goto L_63e3;  /* 重复引用 */
                                                                                        goto L_63ed;  /* 重复引用 */
                                                                                        goto L_6414;  /* 重复引用 */
                                                                                    }
                                                                                    goto L_5e36;  /* 重复引用 */
                                                                                    goto L_5e1c;  /* 重复引用 */
                                                                                    goto L_5e29;  /* 重复引用 */
                                                                                    goto L_5e54;  /* 重复引用 */
                                                                                    goto L_5e6a;  /* 重复引用 */
                                                                                    goto L_5e6e;  /* 重复引用 */
                                                                                    goto L_5e88;  /* 重复引用 */
                                                                                    goto L_5e8e;  /* 重复引用 */
                                                                                    goto L_5ea0;  /* 重复引用 */
                                                                                    goto L_5eb3;  /* 重复引用 */
                                                                                    goto L_5ecb;  /* 重复引用 */
                                                                                    goto L_5ed8;  /* 重复引用 */
                                                                                    goto L_5ee5;  /* 重复引用 */
                                                                                    goto L_5ef2;  /* 重复引用 */
                                                                                    goto L_5f22;  /* 重复引用 */
                                                                                    goto L_5f3c;  /* 重复引用 */
                                                                                    goto L_5f4e;  /* 重复引用 */
                                                                                    goto L_5f64;  /* 重复引用 */
                                                                                    goto L_5f78;  /* 重复引用 */
                                                                                    goto L_5fc0;  /* 重复引用 */
                                                                                    goto L_5ff6;  /* 重复引用 */
                                                                                    goto L_5ffe;  /* 重复引用 */
                                                                                    goto L_600d;  /* 重复引用 */
                                                                                    goto L_6011;  /* 重复引用 */
                                                                                    goto L_602b;  /* 重复引用 */
                                                                                    goto L_6032;  /* 重复引用 */
                                                                                    goto L_6038;  /* 重复引用 */
                                                                                    goto L_6071;  /* 重复引用 */
                                                                                    goto L_607b;  /* 重复引用 */
                                                                                    goto L_6095;  /* 重复引用 */
                                                                                    goto L_6099;  /* 重复引用 */
                                                                                    goto L_60fb;  /* 重复引用 */
                                                                                    goto L_6137;  /* 重复引用 */
                                                                                    goto L_6143;  /* 重复引用 */
                                                                                    goto L_61ab;  /* 重复引用 */
                                                                                    goto L_61cb;  /* 重复引用 */
                                                                                    goto L_61da;  /* 重复引用 */
                                                                                    goto L_61e4;  /* 重复引用 */
                                                                                    goto L_61f5;  /* 重复引用 */
                                                                                    goto L_61fa;  /* 重复引用 */
                                                                                    goto L_6206;  /* 重复引用 */
                                                                                    goto L_6209;  /* 重复引用 */
                                                                                    goto L_620e;  /* 重复引用 */
                                                                                    goto L_6269;  /* 重复引用 */
                                                                                    goto L_6280;  /* 重复引用 */
                                                                                    goto L_628a;  /* 重复引用 */
                                                                                    goto L_6294;  /* 重复引用 */
                                                                                    goto L_62b1;  /* 重复引用 */
                                                                                    goto L_62e9;  /* 重复引用 */
                                                                                    goto L_6304;  /* 重复引用 */
                                                                                    goto L_6306;  /* 重复引用 */
                                                                                    goto L_630d;  /* 重复引用 */
                                                                                    goto L_6311;  /* 重复引用 */
                                                                                    goto L_6317;  /* 重复引用 */
                                                                                    goto L_6335;  /* 重复引用 */
                                                                                    goto L_6352;  /* 重复引用 */
                                                                                    goto L_6358;  /* 重复引用 */
                                                                                    goto L_635f;  /* 重复引用 */
                                                                                    goto L_6363;  /* 重复引用 */
                                                                                    goto L_6369;  /* 重复引用 */
                                                                                    goto L_636c;  /* 重复引用 */
                                                                                    goto L_6387;  /* 重复引用 */
                                                                                    goto L_6399;  /* 重复引用 */
                                                                                    goto L_639d;  /* 重复引用 */
                                                                                    goto L_63ad;  /* 重复引用 */
                                                                                    goto L_63e3;  /* 重复引用 */
                                                                                    goto L_63ed;  /* 重复引用 */
                                                                                    goto L_6414;  /* 重复引用 */
                                                                                }
                                                                                goto L_5e36;  /* 重复引用 */
                                                                            }
                                                                            goto L_5db6;  /* 重复引用 */
                                                                            goto L_5cc4;  /* 重复引用 */
                                                                        }
                                                                        goto L_5db6;  /* 重复引用 */
                                                                        goto L_5cb9;  /* 重复引用 */
                                                                        goto L_5cc4;  /* 重复引用 */
                                                                        goto L_5db6;  /* 重复引用 */
                                                                        goto L_5de5;  /* 重复引用 */
                                                                    }
                                                                    goto L_5df7;  /* 重复引用 */
                                                                }
                                                                goto L_5c68;  /* 重复引用 */
                                                            }
                                                            goto L_5c47;  /* 重复引用 */
                                                        }
                                                        goto L_5c23;  /* 重复引用 */
                                                    }
                                                    goto L_5bef;  /* 重复引用 */
                                                    goto L_5be9;  /* 重复引用 */
                                                    goto L_5bef;  /* 重复引用 */
                                                    goto L_5c06;  /* 重复引用 */
                                                    goto L_5c23;  /* 重复引用 */
                                                    goto L_5c2a;  /* 重复引用 */
                                                    goto L_5c47;  /* 重复引用 */
                                                    goto L_5c4f;  /* 重复引用 */
                                                    goto L_5c68;  /* 重复引用 */
                                                    goto L_5c7d;  /* 重复引用 */
                                                    goto L_5cae;  /* 重复引用 */
                                                    goto L_5cb9;  /* 重复引用 */
                                                    goto L_5cc4;  /* 重复引用 */
                                                    goto L_5db6;  /* 重复引用 */
                                                    goto L_5de5;  /* 重复引用 */
                                                    goto L_5df7;  /* 重复引用 */
                                                    goto L_5e0f;  /* 重复引用 */
                                                    goto L_5e1c;  /* 重复引用 */
                                                    goto L_5e29;  /* 重复引用 */
                                                    goto L_5e36;  /* 重复引用 */
                                                    goto L_5e54;  /* 重复引用 */
                                                    goto L_5e6a;  /* 重复引用 */
                                                    goto L_5e6e;  /* 重复引用 */
                                                    goto L_5e88;  /* 重复引用 */
                                                    goto L_5e8e;  /* 重复引用 */
                                                    goto L_5ea0;  /* 重复引用 */
                                                    goto L_5eb3;  /* 重复引用 */
                                                    goto L_5ecb;  /* 重复引用 */
                                                    goto L_5ed8;  /* 重复引用 */
                                                    goto L_5ee5;  /* 重复引用 */
                                                    goto L_5ef2;  /* 重复引用 */
                                                    goto L_5f0c;  /* 重复引用 */
                                                    goto L_5f22;  /* 重复引用 */
                                                    goto L_5f3c;  /* 重复引用 */
                                                    goto L_5f4e;  /* 重复引用 */
                                                    goto L_5f64;  /* 重复引用 */
                                                    goto L_5f78;  /* 重复引用 */
                                                    goto L_5fc0;  /* 重复引用 */
                                                    goto L_5ff6;  /* 重复引用 */
                                                    goto L_5ffe;  /* 重复引用 */
                                                    goto L_600d;  /* 重复引用 */
                                                    goto L_6011;  /* 重复引用 */
                                                    goto L_602b;  /* 重复引用 */
                                                    goto L_6032;  /* 重复引用 */
                                                    goto L_6038;  /* 重复引用 */
                                                    goto L_6071;  /* 重复引用 */
                                                    goto L_607b;  /* 重复引用 */
                                                    goto L_6095;  /* 重复引用 */
                                                    goto L_6099;  /* 重复引用 */
                                                    goto L_60fb;  /* 重复引用 */
                                                    goto L_6137;  /* 重复引用 */
                                                    goto L_6143;  /* 重复引用 */
                                                    goto L_61ab;  /* 重复引用 */
                                                    goto L_61cb;  /* 重复引用 */
                                                    goto L_61da;  /* 重复引用 */
                                                    goto L_61e4;  /* 重复引用 */
                                                    goto L_61f5;  /* 重复引用 */
                                                    goto L_61fa;  /* 重复引用 */
                                                    goto L_6206;  /* 重复引用 */
                                                    goto L_6209;  /* 重复引用 */
                                                    goto L_620e;  /* 重复引用 */
                                                    goto L_6269;  /* 重复引用 */
                                                    goto L_6280;  /* 重复引用 */
                                                    goto L_628a;  /* 重复引用 */
                                                    goto L_6294;  /* 重复引用 */
                                                    goto L_62b1;  /* 重复引用 */
                                                    goto L_62e9;  /* 重复引用 */
                                                    goto L_6304;  /* 重复引用 */
                                                    goto L_6306;  /* 重复引用 */
                                                    goto L_630d;  /* 重复引用 */
                                                    goto L_6311;  /* 重复引用 */
                                                    goto L_6317;  /* 重复引用 */
                                                    goto L_6335;  /* 重复引用 */
                                                    goto L_6352;  /* 重复引用 */
                                                    goto L_6358;  /* 重复引用 */
                                                    goto L_635f;  /* 重复引用 */
                                                    goto L_6363;  /* 重复引用 */
                                                    goto L_6369;  /* 重复引用 */
                                                    goto L_636c;  /* 重复引用 */
                                                    goto L_6387;  /* 重复引用 */
                                                    goto L_6399;  /* 重复引用 */
                                                    goto L_639d;  /* 重复引用 */
                                                    goto L_63ad;  /* 重复引用 */
                                                    goto L_63e3;  /* 重复引用 */
                                                    goto L_63ed;  /* 重复引用 */
                                                    goto L_6414;  /* 重复引用 */
                                                    goto L_6479;  /* 重复引用 */
                                                    goto L_64a3;  /* 重复引用 */
                                                    goto L_64a7;  /* 重复引用 */
                                                }
                                                goto L_5bcb;  /* 重复引用 */
                                            }
                                            goto L_5b71;  /* 重复引用 */
                                            goto L_5b6b;  /* 重复引用 */
                                        }
                                        goto L_5b71;  /* 重复引用 */
                                    }
                                    goto L_5ae0;  /* 重复引用 */
                                    goto L_5a98;  /* 重复引用 */
                                }
                                goto L_5ae0;  /* 重复引用 */
                            }
                            goto L_5a7a;  /* 重复引用 */
                        }
                        goto L_5a62;  /* 重复引用 */
                    }
                    goto L_5a4a;  /* 重复引用 */
                }
                goto L_5a32;  /* 重复引用 */
            }
            goto L_59d8;  /* 重复引用 */
        }
        goto L_59a6;  /* 重复引用 */
    }
    goto L_5934;  /* 重复引用 */
}

/* ==== sub_64ad  (被调用 4 次) ==== */
static void sub_64ad(void) {
    L_64ad:; /* 0x64ad */
    r15 = 0x1604u;
    r15 = d32(r15);
    sp += -0x38u;
    for (int i = 8; i >= 0; i--) push32(r[i]);
    sp += -0xcu;
    r9 = sp;
    r9 = r9 + 0x64u;
    r0 = r11;
    s32(r9, r15);
    r7 = r12;
    r5 = r13;
    r15 = 0x40000u;
    r9 = 0x21200u;
    iowr(r9, r15);
    r15 = 0x400000u;
    r9 = r9 + 0x1800u;
    iowr(r9, r15);
    r15 = 0x37080000u;
    iowr(r9, r15);
    CALL(sub_4751);
    r15 = 0x1u;
    r9 = 0x1ac00u;
    iowr(r9, r15);
    r9 = 0x3fffffffu;
    r9 = r0 & r9;
    s32(sp+0x30, r9);
    r9 = 0xfffffffu;
    r15 = 0;
    r3 = r0 & r9;
    r9 = 0x2de00u;
    r9 = iord(r9+r15*0x4);
    r6 = r9 & 0x3fu;
    if (!(r5 == 0x0u)) {
        L_6519:; /* 0x6519 */
        r9 = 0x20500u;
        r9 = iord(r9+r15*0x4);
        r14 = 0x13c4u;
        if (!(r9 != 0xfu)) {
            L_6528:; /* 0x6528 */
            r9 = 0x1u;
            s32(r14, r9);
            goto L_6532;
            L_6530:; /* 0x6530 */
            s32(r14, r15);
            L_6532:; /* 0x6532 */
            r15 = 0;
            r9 = 0x20800u;
            r9 = iord(r9+r15*0x4);
            r14 = 0x13c8u;
            if (!(r9 != 0xfu)) {
                L_6543:; /* 0x6543 */
                r9 = 0x1u;
                s32(r14, r9);
                goto L_655d;
                L_654b:; /* 0x654b */
                s32(r14, r15);
                goto L_655d;
                L_6551:; /* 0x6551 */
                r9 = 0x144cu;
                r9 = d32(r9);
                fc_cmp(r9, r0);
                if (FZ(falcon_flags)) goto L_666c;
                L_655d:; /* 0x655d */
                r15 = 0x27180000u;
                r9 = 0x22a00u;
                iowr(r9, r15);
                r10 = 0;
                r2 = r6 << 0x18u;
                r11 = 0;
                r12 = r2 | 0x40u;
                CALL(sub_32b9);
                r9 = 0x1u;
                s32(sp+0x4, r9);
                s32(sp, r9);
                r9 = 0x2u;
                r14 = (r0 >> 28) & 0x3u;
                r10 = r3 << 0x4u;
                s32(sp+0x8, r9);
                r13 = 0xa00u;
                r11 = 0x200u;
                r12 = 0x6u;
                CALL(sub_2de1);
                r9 = 0xa00u;
                r14 = d32(r9+0x10);
                r13 = d32(r9);
                r12 = d32(r9+0x14);
                r1 = d32(r9+0x18);
                r15 = d32(r9+0x4);
                r9 = -0x1000u;
                r13 &= r9;
                r14 &= r9;
                r9 = 0x12e0u;
                r12 <<= 0x18u;
                r14 >>= 0x8u;
                r14 |= r12;
                s32(r9, r14);
                r9 = 0x12e4u;
                r0 = 0;
                s32(r9, r0);
                r9 = 0x1448u;
                r15 <<= 0x18u;
                r13 >>= 0x8u;
                r13 |= r15;
                s32(r9, r13);
                r9 = 0x12ecu;
                r11 = r1 + 0x40u;
                s32(r9, r1);
                r11 &= 0xffu;
                r9 = 0x12e8u;
                r15 = r1 & 0x3fu;
                r15 <<= 0x10u;
                r15 |= r11;
                r15 |= r2;
                r10 = r14;
                r12 = r15;
                s32(r9, r15);
                r11 = 0;
                CALL(sub_32b9);
                r9 = 0x1450u;
                s32(r9, r0);
                r9 = 0x144cu;
                s32(r9, r0);
                r9 = 0x1454u;
                r15 = 0x320d0000u;
                s32(r9, r0);
                r9 = 0x22a00u;
                iowr(r9, r15);
                r10 = 0x2u;
                CALL(sub_2ec1);
                CALL(sub_31cf);
                r15 = 0xc0ffeeb0u;
                r9 = 0x20a00u;
                iowr(r9, r15);
                r9 = 0xe00u;
                r15 = d32(r9+0xc);
                r9 = 0x1444u;
                r15 &= 0x3fu;
                s32(r9, r15);
                r9 = 0x20a00u;
                iowr(r9, r15);
                r1 = 0x1u;
                if (!(r15 != 0x21u)) {
                    L_6652:; /* 0x6652 */
                    r9 = 0x2b140000u;
                    r15 = 0x22a00u;
                    iowr(r15, r9);
                    r9 = 0x12ecu;
                    r11 = r6;
                    r10 = d32(r9);
                    r1 = 0x1u;
                    goto L_66e0;
                    L_666c:; /* 0x666c */
                    r9 = 0x12e0u;
                    r10 = d32(r9);
                    r9 = 0x12e4u;
                    r11 = d32(r9);
                    r9 = 0x12e8u;
                    r12 = d32(r9);
                    CALL(sub_32b9);
                    r9 = 0x1454u;
                    r9 = d32(r9);
                    if (!(r9 != 0x0u)) {
                        L_668c:; /* 0x668c */
                        r15 = 0x320d0000u;
                        r9 = 0x22a00u;
                        iowr(r9, r15);
                        r10 = 0x2u;
                        CALL(sub_2ec1);
                        CALL(sub_31cf);
                        r15 = 0xc0ffeeb0u;
                        r9 = 0x20a00u;
                        iowr(r9, r15);
                        r9 = 0xe00u;
                        r9 = d32(r9+0xc);
                        r15 = 0x1444u;
                        r9 &= 0x3fu;
                        s32(r15, r9);
                        r15 = 0x20a00u;
                        iowr(r15, r9);
                        if (!(r9 != 0x21u)) {
                            L_66c9:; /* 0x66c9 */
                            r9 = 0x2b140000u;
                            r15 = r15 + 0x2000u;
                            iowr(r15, r9);
                            r9 = 0x12ecu;
                            r10 = d32(r9);
                            r11 = r6;
                            r1 = 0;
                            L_66e0:; /* 0x66e0 */
                            CALL(sub_526f);
                            goto L_66ea;
                            L_66e8:; /* 0x66e8 */
                            r1 = 0;
                            L_66ea:; /* 0x66ea */
                            r15 = 0x37080000u;
                            r9 = 0x22a00u;
                            iowr(r9, r15);
                            r15 = 0;
                            r9 = 0xe00u;
                            s32(r9+0xe0, r15);
                            r15 = 0x300f0000u;
                            r9 = 0x22a00u;
                            iowr(r9, r15);
                            CALL(sub_38a0);
                            r15 = 0xe00u;
                            r9 = d32(r15+0x80);
                            r14 = d32(r15+0x38);
                            r15 = 0x1320u;
                            r9 &= 0x3u;
                            s32(r15, r9);
                            r9 = 0x30u;
                            r14 &= 0xffu;
                            r15 = 0x37080000u;
                            s32(r9, r14);
                            r9 = 0x22a00u;
                            iowr(r9, r15);
                            r9 = 0x1494u;
                            r15 = d32(r9);
                            r9 = 0x20a00u;
                            iowr(r9, r15);
                            r9 = 0x1494u;
                            r15 = d32(r9+0x4);
                            r9 = 0x20b00u;
                            iowr(r9, r15);
                            r9 = 0x1494u;
                            r15 = d32(r9+0x8);
                            r9 = 0x20c00u;
                            iowr(r9, r15);
                            r9 = 0xe00u;
                            r9 = d32(r9+0x8c);
                            r15 = 0x1324u;
                            r9 &= 0x3u;
                            if (!(r9 == 0x1u)) {
                                L_6772:; /* 0x6772 */
                                r9 = 0;
                                L_6774:; /* 0x6774 */
                                s32(r15, r9);
                                r10 = 0x4041b8u;
                                CALL(sub_297);
                                r9 = 0xe00u;
                                r14 = d32(r9+0x80);
                                r13 = d32(r9+0x84);
                                r9 = d32(r9+0xf0);
                                r15 = 0x13c0u;
                                r14 &= 0x3u;
                                r13 &= 0x3u;
                                s32(r15, r9);
                                r9 = 0x145cu;
                                r9 = d32(r9);
                                r15 = 0x1320u;
                                s32(r15, r14);
                                fc_cmp(r14, 0x1u);
                                fc_xbit(r0);
                                if (!(r9 == 0x0u)) {
                                    L_67ad:; /* 0x67ad */
                                    r9 = 0x30u;
                                    r9 = d32(r9);
                                    if (!(r9 == 0x2u)) {
                                        L_67b7:; /* 0x67b7 */
                                        r9 = 0;
                                        r0 = 0;
                                        s32(r15, r9);
                                        L_67bd:; /* 0x67bd */
                                        if (!(r13 != 0x1u)) {
                                            L_67c1:; /* 0x67c1 */
                                            r0 |= 0x2u;
                                            goto L_67cf;
                                            L_67c8:; /* 0x67c8 */
                                            if (!(r13 != 0x2u)) {
                                                L_67cc:; /* 0x67cc */
                                                r0 |= 0x4u;
                                                L_67cf:; /* 0x67cf */
                                                r15 = 0x2f100000u;
                                                r9 = 0x22a00u;
                                                iowr(r9, r15);
                                                r9 = 0x13c0u;
                                                r12 = d32(r9);
                                                r9 = 0x12ecu;
                                                r13 = d32(r9);
                                                r11 = r3;
                                                r10 = 0;
                                                r14 = r6;
                                                CALL(sub_5726);
                                                if (!(r5 != 0x0u)) {
                                                    L_67f5:; /* 0x67f5 */
                                                    r10 = 0x5u;
                                                    r11 = 0;
                                                    CALL(sub_d17);
                                                    L_67fd:; /* 0x67fd */
                                                    r15 = 0x2u;
                                                    r9 = 0x1ac00u;
                                                    iowr(r9, r15);
                                                    r15 = 0x3c030000u;
                                                    r9 = r9 + 0x7e00u;
                                                    iowr(r9, r15);
                                                    r10 = r0;
                                                    CALL(sub_e82);
                                                    if (!(r1 != 0x1u)) {
                                                        L_681d:; /* 0x681d */
                                                        r15 = 0x310e0000u;
                                                        r9 = 0x22a00u;
                                                        iowr(r9, r15);
                                                        r9 = 0x12ecu;
                                                        r11 = d32(r9);
                                                        r10 = 0x41a814u;
                                                        CALL(sub_237);
                                                        r9 = 0x12e0u;
                                                        r11 = d32(r9);
                                                        r10 = 0x13u;
                                                        CALL(sub_cc5);
                                                        CALL(sub_23fc);
                                                        r9 = 0x12e4u;
                                                        r11 = d32(r9);
                                                        r10 = 0x1eu;
                                                        CALL(sub_cc5);
                                                        CALL(sub_23fc);
                                                        L_6857:; /* 0x6857 */
                                                        if (!(r5 != 0x0u)) {
                                                            L_685b:; /* 0x685b */
                                                            r10 = 0x6bu;
                                                            r11 = 0;
                                                            CALL(sub_cc5);
                                                            L_6863:; /* 0x6863 */
                                                            r15 = 0x37080000u;
                                                            r9 = 0x22a00u;
                                                            iowr(r9, r15);
                                                            r15 = 0x3c030000u;
                                                            iowr(r9, r15);
                                                            fc_cmp(r5, 0x0u);
                                                            fc_xbit(r10);
                                                            CALL(sub_4702);
                                                            CALL(sub_4751);
                                                            r15 = 0;
                                                            r9 = 0x30000u;
                                                            r9 = iord(r9+r15*0x4);
                                                            r15 = 0x14c4u;
                                                            r14 = d32(r15);
                                                            r0 = (r9 >> 6) & 0x1u;
                                                            r15 = r0 << 0x8u;
                                                            r3 = (r9 >> 28) & 0x3u;
                                                            r4 = r9 >> 0x1eu;
                                                            r9 = r4 << 0x4u;
                                                            r9 |= r3;
                                                            r9 |= r15;
                                                            r15 = 0xe00u;
                                                            s32(r15+0x88, r9);
                                                            if (!(r14 == 0x0u)) {
                                                                L_68b4:; /* 0x68b4 */
                                                                r9 = 0x14b4u;
                                                                r9 = d32(r9);
                                                                if (!(r9 == 0x0u)) {
                                                                    L_68be:; /* 0x68be */
                                                                    r15 = 0x2f100000u;
                                                                    r9 = 0x22a00u;
                                                                    iowr(r9, r15);
                                                                    if (!(r3 != 0x1u)) {
                                                                        L_68ce:; /* 0x68ce */
                                                                        r10 = 0x8u;
                                                                        r11 = 0xbu;
                                                                        goto L_68f2;
                                                                        L_68d6:; /* 0x68d6 */
                                                                        if (!(r4 != 0x1u)) {
                                                                            L_68da:; /* 0x68da */
                                                                            r10 = 0x8u;
                                                                            r11 = 0xcu;
                                                                            goto L_68f2;
                                                                            L_68e2:; /* 0x68e2 */
                                                                            if (!(r4 != 0x2u)) {
                                                                                L_68e6:; /* 0x68e6 */
                                                                                r10 = 0x8u;
                                                                                r11 = 0xdu;
                                                                                goto L_68f2;
                                                                                L_68ee:; /* 0x68ee */
                                                                                r10 = 0x8u;
                                                                                r11 = 0xau;
                                                                                L_68f2:; /* 0x68f2 */
                                                                                CALL(sub_557b);
                                                                                r15 = 0x37080000u;
                                                                                r9 = 0x22a00u;
                                                                                iowr(r9, r15);
                                                                                L_6902:; /* 0x6902 */
                                                                                r15 = 0x5u;
                                                                                if (!(r3 == 0x1u)) {
                                                                                    L_6908:; /* 0x6908 */
                                                                                    if (!(r4 != 0x1u)) {
                                                                                        L_690c:; /* 0x690c */
                                                                                        r15 = 0;
                                                                                        r9 = 0x1324u;
                                                                                        s32(r9, r15);
                                                                                        r15 = 0x7u;
                                                                                        goto L_6932;
                                                                                        L_691a:; /* 0x691a */
                                                                                        r15 = 0x1324u;
                                                                                        if (!(r4 != 0x2u)) {
                                                                                            L_6922:; /* 0x6922 */
                                                                                            r9 = 0;
                                                                                            s32(r15, r9);
                                                                                            r15 = 0x6u;
                                                                                            goto L_6932;
                                                                                            L_692c:; /* 0x692c */
                                                                                            r9 = 0;
                                                                                            s32(r15, r9);
                                                                                            r15 = 0x4u;
                                                                                            L_6932:; /* 0x6932 */
                                                                                            r9 = 0x1ac00u;
                                                                                            iowr(r9, r15);
                                                                                            r15 = 0xc0ffee00u;
                                                                                            r9 = 0x20a00u;
                                                                                            iowr(r9, r15);
                                                                                            r9 = 0x1324u;
                                                                                            r15 = d32(r9);
                                                                                            r9 = 0x20a00u;
                                                                                            iowr(r9, r15);
                                                                                            r15 = 0x1u;
                                                                                            if (!(r0 != 0x0u)) {
                                                                                                L_6958:; /* 0x6958 */
                                                                                                r15 = 0;
                                                                                                L_695a:; /* 0x695a */
                                                                                                r9 = 0x2dc00u;
                                                                                                iowr(r9, r15);
                                                                                                r9 = 0x145cu;
                                                                                                r9 = d32(r9);
                                                                                                if (!(r9 == 0x0u)) {
                                                                                                    L_696b:; /* 0x696b */
                                                                                                    if (!(r3 != 0x0u)) {
                                                                                                        L_696f:; /* 0x696f */
                                                                                                        r9 = 0x30u;
                                                                                                        r9 = d32(r9);
                                                                                                        if (!(r9 != 0x2u)) {
                                                                                                            L_6979:; /* 0x6979 */
                                                                                                            r15 = 0x300f0000u;
                                                                                                            r9 = 0x22a00u;
                                                                                                            iowr(r9, r15);
                                                                                                            r10 = 0x1u;
                                                                                                            CALL(sub_1070);
                                                                                                            r9 = 0xe00u;
                                                                                                            r13 = 0x1494u;
                                                                                                            r10 = d32(r9+0x38);
                                                                                                            r9 = d32(r13);
                                                                                                            r15 = 0x1484u;
                                                                                                            r14 = -0xff01u;
                                                                                                            r10 = (r10 >> 8) & 0xffu;
                                                                                                            r14 = r9 & r14;
                                                                                                            r9 &= 0xff00u;
                                                                                                            r9 = r9 + 0x100u;
                                                                                                            r9 &= 0xffffu;
                                                                                                            r9 |= r14;
                                                                                                            s32(r15, r10);
                                                                                                            s32(r13, r9);
                                                                                                            CALL(sub_108e);
                                                                                                            r15 = 0x37080000u;
                                                                                                            r9 = 0x22a00u;
                                                                                                            iowr(r9, r15);
                                                                                                            r8 = 0x1u;
                                                                                                            goto L_69d2;
                                                                                                            L_69d0:; /* 0x69d0 */
                                                                                                            r8 = 0;
                                                                                                            L_69d2:; /* 0x69d2 */
                                                                                                            r15 = 0x2e110000u;
                                                                                                            r9 = 0x22a00u;
                                                                                                            iowr(r9, r15);
                                                                                                            r9 = 0xe00u;
                                                                                                            r15 = d32(r9+0x28);
                                                                                                            r9 = 0x1310u;
                                                                                                            r14 = (r15 >> 3) & 0x7u;
                                                                                                            r15 &= 0x7u;
                                                                                                            s32(r9, r14);
                                                                                                            r9 = 0x130cu;
                                                                                                            s32(r9, r15);
                                                                                                            r15 = 0x37080000u;
                                                                                                            r9 = 0x22a00u;
                                                                                                            iowr(r9, r15);
                                                                                                            r10 = 0;
                                                                                                            CALL(sub_29c6);
                                                                                                            r10 = 0x1u;
                                                                                                            r11 = r10;
                                                                                                            r12 = r10;
                                                                                                            CALL(sub_cf5);
                                                                                                            CALL(sub_290c);
                                                                                                            r10 = 0;
                                                                                                            CALL(sub_2988);
                                                                                                            if (!(r4 != 0x2u)) {
                                                                                                                L_6a21:; /* 0x6a21 */
                                                                                                                r10 = 0x419ac4u;
                                                                                                                r11 = 0;
                                                                                                                r1 = 0;
                                                                                                                CALL(sub_237);
                                                                                                                r0 = 0x504334u;
                                                                                                                r2 = 0x14a0u;
                                                                                                                goto L_6a53;
                                                                                                                L_6a39:; /* 0x6a39 */
                                                                                                                r10 = r0;
                                                                                                                CALL(sub_297);
                                                                                                                r1 = r1 + 0x1u;
                                                                                                                r11 = r10 ^ 0x1u;
                                                                                                                r10 = r0 - 0x2800u;
                                                                                                                r0 = r0 + 0x8000u;
                                                                                                                CALL(sub_237);
                                                                                                                L_6a53:; /* 0x6a53 */
                                                                                                                r9 = d32(r2);
                                                                                                                fc_cmp(r1, r9);
                                                                                                                if (FC(falcon_flags)) goto L_6a39;
                                                                                                                L_6a5a:; /* 0x6a5a */
                                                                                                                r9 = 0x24u;
                                                                                                                r10 = d32(r9);
                                                                                                                CALL(sub_114);
                                                                                                                r10 = r5;
                                                                                                                r11 = r7;
                                                                                                                r12 = r3;
                                                                                                                r13 = r4;
                                                                                                                CALL(sub_53b4);
                                                                                                                r9 = 0x1324u;
                                                                                                                r9 = d32(r9);
                                                                                                                if (!(r9 != 0x0u)) {
                                                                                                                    L_6a7b:; /* 0x6a7b */
                                                                                                                    if (!(r3 != 0x1u)) {
                                                                                                                        L_6a80:; /* 0x6a80 */
                                                                                                                        r9 = 0x145cu;
                                                                                                                        r9 = d32(r9);
                                                                                                                        if (!(r9 == 0x0u)) {
                                                                                                                            L_6a8b:; /* 0x6a8b */
                                                                                                                            r9 = 0x30u;
                                                                                                                            r9 = d32(r9);
                                                                                                                            if (!(r9 != 0x2u)) {
                                                                                                                                L_6a96:; /* 0x6a96 */
                                                                                                                                r15 = 0x300f0000u;
                                                                                                                                r9 = 0x22a00u;
                                                                                                                                iowr(r9, r15);
                                                                                                                                r2 = 0xc00u;
                                                                                                                                r9 = d32(r2+0x10);
                                                                                                                                r15 = 0x1474u;
                                                                                                                                r2 = d32(r2);
                                                                                                                                r0 = sp;
                                                                                                                                s32(r15, r9);
                                                                                                                                r9 = 0xe00u;
                                                                                                                                r13 = d32(r9+0x38);
                                                                                                                                r9 = 0x145cu;
                                                                                                                                r11 = d32(r15);
                                                                                                                                r15 = d32(r9);
                                                                                                                                r9 = 0x1460u;
                                                                                                                                r9 = d32(r9);
                                                                                                                                r0 = r0 + 0x54u;
                                                                                                                                r13 = (r13 >> 8) & 0xffu;
                                                                                                                                r12 = r15 >> 0x10u;
                                                                                                                                r14 = r9 >> 0x10u;
                                                                                                                                r9 &= 0xffffu;
                                                                                                                                r15 &= 0xffffu;
                                                                                                                                s32(r0+0x8, r9);
                                                                                                                                r9 = 0x1484u;
                                                                                                                                s32(r0+0xc, r14);
                                                                                                                                s32(r9, r13);
                                                                                                                                r10 = r13;
                                                                                                                                s32(r0+0x4, r12);
                                                                                                                                s32(r0, r15);
                                                                                                                                r1 = 0x1478u;
                                                                                                                                s32(r1, r2);
                                                                                                                                CALL(sub_77ce);
                                                                                                                                r10 = r10 + r2;
                                                                                                                                r9 = r10 >> 0x18u;
                                                                                                                                r15 = sp;
                                                                                                                                r10 >>= 0x8u;
                                                                                                                                r15 = r15 + 0x44u;
                                                                                                                                s32(r15+0x4, r9);
                                                                                                                                r9 = r10 & 0xffffu;
                                                                                                                                s32(r15, r9);
                                                                                                                                r9 = 0;
                                                                                                                                s32(r15+0x8, r9);
                                                                                                                                s32(r15+0xc, r9);
                                                                                                                                r9 = 0x1470u;
                                                                                                                                r12 = r15;
                                                                                                                                s32(r9, r10);
                                                                                                                                r11 = r0;
                                                                                                                                r0 = sp;
                                                                                                                                r0 = r0 + 0x34u;
                                                                                                                                r10 = r0;
                                                                                                                                CALL(sub_1021);
                                                                                                                                r12 = d32(r0+0x8);
                                                                                                                                r15 = d32(r0+0x4);
                                                                                                                                r13 = d32(r0);
                                                                                                                                r14 = d32(r0+0xc);
                                                                                                                                r9 = 0x12ecu;
                                                                                                                                r15 <<= 0x10u;
                                                                                                                                r9 = d32(r9);
                                                                                                                                r14 <<= 0x10u;
                                                                                                                                r13 = r15 | r13;
                                                                                                                                r14 |= r12;
                                                                                                                                goto L_6b68;
                                                                                                                                L_6b51:; /* 0x6b51 */
                                                                                                                                r15 = 0xe00u;
                                                                                                                                r9 = 0x12ecu;
                                                                                                                                r14 = d32(r15+0x64);
                                                                                                                                r9 = d32(r9);
                                                                                                                                r13 = d32(r15+0x68);
                                                                                                                                r15 = 0x1ffffu;
                                                                                                                                r14 &= r15;
                                                                                                                                L_6b68:; /* 0x6b68 */
                                                                                                                                r15 = r9 + 0x40u;
                                                                                                                                r9 &= 0x3fu;
                                                                                                                                r15 &= 0xffu;
                                                                                                                                r9 <<= 0x10u;
                                                                                                                                r9 |= r15;
                                                                                                                                r15 = r6 << 0x18u;
                                                                                                                                r15 = r9 | r15;
                                                                                                                                r9 = 0x1314u;
                                                                                                                                s32(r9, r13);
                                                                                                                                r9 = 0x1318u;
                                                                                                                                s32(r9, r14);
                                                                                                                                r9 = 0x131cu;
                                                                                                                                s32(r9, r15);
                                                                                                                                L_6b8f:; /* 0x6b8f */
                                                                                                                                r15 = 0x2e110000u;
                                                                                                                                r9 = 0x22a00u;
                                                                                                                                iowr(r9, r15);
                                                                                                                                r9 = 0x12ecu;
                                                                                                                                r10 = d32(r9);
                                                                                                                                r11 = r6;
                                                                                                                                CALL(sub_19f6);
                                                                                                                                r15 = 0x2d120000u;
                                                                                                                                r9 = 0x22a00u;
                                                                                                                                iowr(r9, r15);
                                                                                                                                r9 = 0x12ecu;
                                                                                                                                r10 = d32(r9);
                                                                                                                                r11 = r6;
                                                                                                                                CALL(sub_16df);
                                                                                                                                r9 = 0x1308u;
                                                                                                                                r9 = d32(r9);
                                                                                                                                if (!(r9 == 0x0u)) {
                                                                                                                                    L_6bc9:; /* 0x6bc9 */
                                                                                                                                    if (!(r5 == 0x0u)) {
                                                                                                                                        L_6bcd:; /* 0x6bcd */
                                                                                                                                        r15 = 0xe00u;
                                                                                                                                        r9 = 0;
                                                                                                                                        s32(r15+0x20, r9);
                                                                                                                                        s32(r15+0x1c, r9);
                                                                                                                                        L_6bd9:; /* 0x6bd9 */
                                                                                                                                        r15 = 0x310e0000u;
                                                                                                                                        r9 = 0x22a00u;
                                                                                                                                        iowr(r9, r15);
                                                                                                                                        if (!(r5 != 0x0u)) {
                                                                                                                                            L_6be9:; /* 0x6be9 */
                                                                                                                                            CALL(sub_23fc);
                                                                                                                                            L_6bed:; /* 0x6bed */
                                                                                                                                            r0 = 0x12ecu;
                                                                                                                                            r10 = d32(r0);
                                                                                                                                            CALL(sub_24c4);
                                                                                                                                            r10 = d32(r0);
                                                                                                                                            CALL(sub_2689);
                                                                                                                                            r15 = 0x37080000u;
                                                                                                                                            r9 = 0x22a00u;
                                                                                                                                            iowr(r9, r15);
                                                                                                                                            r9 = 0x1324u;
                                                                                                                                            r9 = d32(r9);
                                                                                                                                            if (!(r9 != 0x0u)) {
                                                                                                                                                L_6c13:; /* 0x6c13 */
                                                                                                                                                r10 = r3;
                                                                                                                                                CALL(sub_5812);
                                                                                                                                                L_6c19:; /* 0x6c19 */
                                                                                                                                                if (!(r5 != 0x0u)) {
                                                                                                                                                    L_6c1d:; /* 0x6c1d */
                                                                                                                                                    r10 = 0x6u;
                                                                                                                                                    r11 = 0;
                                                                                                                                                    CALL(sub_d17);
                                                                                                                                                    L_6c25:; /* 0x6c25 */
                                                                                                                                                    r9 = 0x1324u;
                                                                                                                                                    r9 = d32(r9);
                                                                                                                                                    if (!(r9 != 0x0u)) {
                                                                                                                                                        L_6c2f:; /* 0x6c2f */
                                                                                                                                                        r10 = 0x41a800u;
                                                                                                                                                        r11 = 0;
                                                                                                                                                        CALL(sub_237);
                                                                                                                                                        r10 = 0x1u;
                                                                                                                                                        if (!(r7 == 0x2u)) {
                                                                                                                                                            L_6c3f:; /* 0x6c3f */
                                                                                                                                                            r10 = 0x9u;
                                                                                                                                                            if (!(r5 != 0x0u)) {
                                                                                                                                                                L_6c45:; /* 0x6c45 */
                                                                                                                                                                r10 = 0x8u;
                                                                                                                                                                L_6c47:; /* 0x6c47 */
                                                                                                                                                                r11 = r3;
                                                                                                                                                                CALL(sub_cc5);
                                                                                                                                                                L_6c4d:; /* 0x6c4d */
                                                                                                                                                                r15 = 0x3e010000u;
                                                                                                                                                                r9 = 0x22a00u;
                                                                                                                                                                iowr(r9, r15);
                                                                                                                                                                r9 = 0x24u;
                                                                                                                                                                r10 = d32(r9);
                                                                                                                                                                CALL(sub_114);
                                                                                                                                                                r10 = 0x2u;
                                                                                                                                                                CALL(sub_791);
                                                                                                                                                                r9 = 0x1324u;
                                                                                                                                                                r9 = d32(r9);
                                                                                                                                                                if (!(r9 != 0x0u)) {
                                                                                                                                                                    L_6c73:; /* 0x6c73 */
                                                                                                                                                                    CALL(sub_ed1);
                                                                                                                                                                    r10 = 0x1u;
                                                                                                                                                                    CALL(sub_415);
                                                                                                                                                                    CALL(sub_2c19);
                                                                                                                                                                    r10 = 0;
                                                                                                                                                                    CALL(sub_445);
                                                                                                                                                                    L_6c87:; /* 0x6c87 */
                                                                                                                                                                    r10 = 0;
                                                                                                                                                                    CALL(sub_e3);
                                                                                                                                                                    CALL(sub_2175);
                                                                                                                                                                    r9 = 0x1000u;
                                                                                                                                                                    r11 = d32(r9+0xc);
                                                                                                                                                                    r10 = 0xfu;
                                                                                                                                                                    r11 = (r11 & 0xffffu) | ((u32)0x0u << 16); /* 待复核 */
                                                                                                                                                                    CALL(sub_c4);
                                                                                                                                                                    r9 = 0x1324u;
                                                                                                                                                                    r9 = d32(r9);
                                                                                                                                                                    if (!(r9 == 0x0u)) {
                                                                                                                                                                        L_6cac:; /* 0x6cac */
                                                                                                                                                                        r0 = 0;
                                                                                                                                                                        L_6cae:; /* 0x6cae */
                                                                                                                                                                        CALL(sub_2175);
                                                                                                                                                                        if (!(r0 == 0x0u)) {
                                                                                                                                                                            L_6cb6:; /* 0x6cb6 */
                                                                                                                                                                            r9 = 0x130cu;
                                                                                                                                                                            r9 = d32(r9);
                                                                                                                                                                            r9 = r9 - 0x1u;
                                                                                                                                                                            fc_cmp(r9, 0x1u);
                                                                                                                                                                            if (!(!FC(falcon_flags) && !FZ(falcon_flags))) {
                                                                                                                                                                                L_6cc5:; /* 0x6cc5 */
                                                                                                                                                                                CALL(sub_364b);
                                                                                                                                                                                CALL(sub_1973);
                                                                                                                                                                                L_6ccd:; /* 0x6ccd */
                                                                                                                                                                                r15 = 0x3d020000u;
                                                                                                                                                                                r9 = 0x22a00u;
                                                                                                                                                                                iowr(r9, r15);
                                                                                                                                                                                CALL(sub_2c19);
                                                                                                                                                                                r9 = 0x1324u;
                                                                                                                                                                                r9 = d32(r9);
                                                                                                                                                                                if (!(r9 != 0x0u)) {
                                                                                                                                                                                    L_6ce7:; /* 0x6ce7 */
                                                                                                                                                                                    if (!(r3 != 0x1u)) {
                                                                                                                                                                                        L_6ceb:; /* 0x6ceb */
                                                                                                                                                                                        r10 = 0;
                                                                                                                                                                                        CALL(sub_47c0);
                                                                                                                                                                                        L_6cf1:; /* 0x6cf1 */
                                                                                                                                                                                        r9 = 0x12e0u;
                                                                                                                                                                                        r10 = d32(r9);
                                                                                                                                                                                        r9 = 0x12e4u;
                                                                                                                                                                                        r11 = d32(r9);
                                                                                                                                                                                        r9 = 0x12e8u;
                                                                                                                                                                                        r12 = d32(r9);
                                                                                                                                                                                        CALL(sub_32b9);
                                                                                                                                                                                        r15 = 0x37080000u;
                                                                                                                                                                                        r9 = 0x22a00u;
                                                                                                                                                                                        iowr(r9, r15);
                                                                                                                                                                                        r12 = 0xe00u;
                                                                                                                                                                                        r15 = d32(r12+0xf4);
                                                                                                                                                                                        r13 = 0x1000u;
                                                                                                                                                                                        r9 = d32(r13+0x4);
                                                                                                                                                                                        fc_cmp(r3, 0x1u);
                                                                                                                                                                                        fc_xbit(r14);
                                                                                                                                                                                        r15 = r15 + 0x1u;
                                                                                                                                                                                        r9 &= 0xffdfu;
                                                                                                                                                                                        r14 <<= 0x5u;
                                                                                                                                                                                        s32(r12+0xf4, r15);
                                                                                                                                                                                        r15 = 0xca110000u;
                                                                                                                                                                                        r9 |= r15;
                                                                                                                                                                                        r9 |= r14;
                                                                                                                                                                                        s32(r13+0x4, r9);
                                                                                                                                                                                        r9 = 0xad0becabu;
                                                                                                                                                                                        s32(r13+0xfc, r9);
                                                                                                                                                                                        r9 = 0x1ceb00dau;
                                                                                                                                                                                        s32(r13+0x100, r9);
                                                                                                                                                                                        r9 = 0xf00dbeefu;
                                                                                                                                                                                        s32(r13+0x1fc, r9);
                                                                                                                                                                                        if (!(r4 != 0x2u)) {
                                                                                                                                                                                            L_6d5e:; /* 0x6d5e */
                                                                                                                                                                                            r9 = d32(r12+0xdc);
                                                                                                                                                                                            r15 = 0;
                                                                                                                                                                                            r9 = r9 + 0x1u;
                                                                                                                                                                                            s32(r12+0xdc, r9);
                                                                                                                                                                                            goto L_6d7f;
                                                                                                                                                                                            L_6d6d:; /* 0x6d6d */
                                                                                                                                                                                            r15 = 0x1u;
                                                                                                                                                                                            fc_cmp(r4, r15);
                                                                                                                                                                                            if (!!FZ(falcon_flags)) {
                                                                                                                                                                                                L_6d74:; /* 0x6d74 */
                                                                                                                                                                                                r9 = d32(r12+0xd4);
                                                                                                                                                                                                r15 = 0;
                                                                                                                                                                                                r9 = r9 + 0x1u;
                                                                                                                                                                                                s32(r12+0xd4, r9);
                                                                                                                                                                                                L_6d7f:; /* 0x6d7f */
                                                                                                                                                                                                if (!(r3 != 0x1u)) {
                                                                                                                                                                                                    L_6d83:; /* 0x6d83 */
                                                                                                                                                                                                    r14 = 0xe00u;
                                                                                                                                                                                                    r15 = d32(r14+0xd8);
                                                                                                                                                                                                    r13 = 0x1494u;
                                                                                                                                                                                                    r9 = d32(r13+0x8);
                                                                                                                                                                                                    r15 = r15 + 0x1u;
                                                                                                                                                                                                    s32(r14+0xd8, r15);
                                                                                                                                                                                                    r15 = -0x100u;
                                                                                                                                                                                                    r15 = r9 & r15;
                                                                                                                                                                                                    r9 = r9 + 0x1u;
                                                                                                                                                                                                    r9 &= 0xffu;
                                                                                                                                                                                                    goto L_6dd3;
                                                                                                                                                                                                    L_6da7:; /* 0x6da7 */
                                                                                                                                                                                                    if (!(r15 == 0x0u)) {
                                                                                                                                                                                                        L_6dab:; /* 0x6dab */
                                                                                                                                                                                                        r14 = 0xe00u;
                                                                                                                                                                                                        r15 = d32(r14+0xd0);
                                                                                                                                                                                                        r13 = 0x1494u;
                                                                                                                                                                                                        r9 = d32(r13+0x8);
                                                                                                                                                                                                        r15 = r15 + 0x1u;
                                                                                                                                                                                                        s32(r14+0xd0, r15);
                                                                                                                                                                                                        r15 = 0xff00ffffu;
                                                                                                                                                                                                        r15 = r9 & r15;
                                                                                                                                                                                                        r9 = (r9 >> 16) & 0xffu;
                                                                                                                                                                                                        r9 = r9 + 0x1u;
                                                                                                                                                                                                        r9 &= 0xffu;
                                                                                                                                                                                                        r9 <<= 0x10u;
                                                                                                                                                                                                        L_6dd3:; /* 0x6dd3 */
                                                                                                                                                                                                        r9 |= r15;
                                                                                                                                                                                                        s32(r13+0x8, r9);
                                                                                                                                                                                                        L_6dd9:; /* 0x6dd9 */
                                                                                                                                                                                                        r9 = 0x145cu;
                                                                                                                                                                                                        r9 = d32(r9);
                                                                                                                                                                                                        if (!(r9 == 0x0u)) {
                                                                                                                                                                                                            L_6de3:; /* 0x6de3 */
                                                                                                                                                                                                            r9 = 0x30u;
                                                                                                                                                                                                            r9 = d32(r9);
                                                                                                                                                                                                            if (!(r9 != 0x2u)) {
                                                                                                                                                                                                                L_6ded:; /* 0x6ded */
                                                                                                                                                                                                                if (!(r3 != 0x1u)) {
                                                                                                                                                                                                                    L_6df1:; /* 0x6df1 */
                                                                                                                                                                                                                    r15 = 0x300f0000u;
                                                                                                                                                                                                                    r9 = 0x22a00u;
                                                                                                                                                                                                                    iowr(r9, r15);
                                                                                                                                                                                                                    r10 = 0x3u;
                                                                                                                                                                                                                    CALL(sub_1070);
                                                                                                                                                                                                                    r13 = 0x1494u;
                                                                                                                                                                                                                    r14 = d32(r13);
                                                                                                                                                                                                                    r15 = 0xff00ffffu;
                                                                                                                                                                                                                    r9 = (r14 >> 16) & 0xffu;
                                                                                                                                                                                                                    r14 &= r15;
                                                                                                                                                                                                                    r9 = r9 + 0x1u;
                                                                                                                                                                                                                    r9 &= 0xffu;
                                                                                                                                                                                                                    r9 <<= 0x10u;
                                                                                                                                                                                                                    r9 |= r14;
                                                                                                                                                                                                                    s32(r13, r9);
                                                                                                                                                                                                                    L_6e22:; /* 0x6e22 */
                                                                                                                                                                                                                    if (!(r8 == 0x0u)) {
                                                                                                                                                                                                                        L_6e26:; /* 0x6e26 */
                                                                                                                                                                                                                        r15 = 0x300f0000u;
                                                                                                                                                                                                                        r9 = 0x22a00u;
                                                                                                                                                                                                                        iowr(r9, r15);
                                                                                                                                                                                                                        CALL(sub_37e1);
                                                                                                                                                                                                                        L_6e36:; /* 0x6e36 */
                                                                                                                                                                                                                        r15 = 0x330c0000u;
                                                                                                                                                                                                                        r9 = 0x22a00u;
                                                                                                                                                                                                                        iowr(r9, r15);
                                                                                                                                                                                                                        r10 = 0x1u;
                                                                                                                                                                                                                        CALL(sub_3063);
                                                                                                                                                                                                                        r15 = 0x320d0000u;
                                                                                                                                                                                                                        r9 = 0x22a00u;
                                                                                                                                                                                                                        iowr(r9, r15);
                                                                                                                                                                                                                        r10 = 0x2u;
                                                                                                                                                                                                                        CALL(sub_2f4a);
                                                                                                                                                                                                                        if (!(r0 == 0x0u)) {
                                                                                                                                                                                                                            L_6e5e:; /* 0x6e5e */
                                                                                                                                                                                                                            r9 = 0x130cu;
                                                                                                                                                                                                                            r9 = d32(r9);
                                                                                                                                                                                                                            r9 = r9 - 0x1u;
                                                                                                                                                                                                                            fc_cmp(r9, 0x1u);
                                                                                                                                                                                                                            if (!(!FC(falcon_flags) && !FZ(falcon_flags))) {
                                                                                                                                                                                                                                L_6e6d:; /* 0x6e6d */
                                                                                                                                                                                                                                CALL(sub_3446);
                                                                                                                                                                                                                                L_6e71:; /* 0x6e71 */
                                                                                                                                                                                                                                r9 = 0x24u;
                                                                                                                                                                                                                                r10 = d32(r9);
                                                                                                                                                                                                                                CALL(sub_114);
                                                                                                                                                                                                                                r10 = 0x1u;
                                                                                                                                                                                                                                CALL(sub_791);
                                                                                                                                                                                                                                if (!(r5 != 0x0u)) {
                                                                                                                                                                                                                                    L_6e85:; /* 0x6e85 */
                                                                                                                                                                                                                                    CALL(sub_3d7e);
                                                                                                                                                                                                                                    goto L_6ea7;
                                                                                                                                                                                                                                    L_6e8d:; /* 0x6e8d */
                                                                                                                                                                                                                                    r15 = 0x26190000u;
                                                                                                                                                                                                                                    r9 = 0x22a00u;
                                                                                                                                                                                                                                    iowr(r9, r15);
                                                                                                                                                                                                                                    r10 = 0x28400u;
                                                                                                                                                                                                                                    r11 = 0x5u;
                                                                                                                                                                                                                                    CALL(sub_10);
                                                                                                                                                                                                                                    CALL(sub_31cf);
                                                                                                                                                                                                                                    L_6ea7:; /* 0x6ea7 */
                                                                                                                                                                                                                                    r15 = 0x26190000u;
                                                                                                                                                                                                                                    r9 = 0x22a00u;
                                                                                                                                                                                                                                    iowr(r9, r15);
                                                                                                                                                                                                                                    r10 = 0x28400u;
                                                                                                                                                                                                                                    r11 = 0x10bu;
                                                                                                                                                                                                                                    CALL(sub_10);
                                                                                                                                                                                                                                    CALL(sub_31cf);
                                                                                                                                                                                                                                    r15 = 0x3b040000u;
                                                                                                                                                                                                                                    r9 = 0x22a00u;
                                                                                                                                                                                                                                    iowr(r9, r15);
                                                                                                                                                                                                                                    r9 = 0x1324u;
                                                                                                                                                                                                                                    r9 = d32(r9);
                                                                                                                                                                                                                                    if (!(r9 != 0x0u)) {
                                                                                                                                                                                                                                        L_6ed8:; /* 0x6ed8 */
                                                                                                                                                                                                                                        CALL(sub_23fc);
                                                                                                                                                                                                                                        L_6edc:; /* 0x6edc */
                                                                                                                                                                                                                                        r15 = 0x37080000u;
                                                                                                                                                                                                                                        r9 = 0x22a00u;
                                                                                                                                                                                                                                        iowr(r9, r15);
                                                                                                                                                                                                                                        if (!(r7 != 0x0u)) {
                                                                                                                                                                                                                                            L_6eec:; /* 0x6eec */
                                                                                                                                                                                                                                            r9 = 0x1324u;
                                                                                                                                                                                                                                            r9 = d32(r9);
                                                                                                                                                                                                                                            if (!(r9 != 0x0u)) {
                                                                                                                                                                                                                                                L_6ef6:; /* 0x6ef6 */
                                                                                                                                                                                                                                                r10 = 0;
                                                                                                                                                                                                                                                CALL(sub_415);
                                                                                                                                                                                                                                                CALL(sub_2c19);
                                                                                                                                                                                                                                                L_6f00:; /* 0x6f00 */
                                                                                                                                                                                                                                                r10 = 0;
                                                                                                                                                                                                                                                CALL(sub_29c6);
                                                                                                                                                                                                                                                r10 = 0x1u;
                                                                                                                                                                                                                                                r11 = r10;
                                                                                                                                                                                                                                                r12 = r10;
                                                                                                                                                                                                                                                CALL(sub_c7b);
                                                                                                                                                                                                                                                CALL(sub_290c);
                                                                                                                                                                                                                                                r10 = 0;
                                                                                                                                                                                                                                                CALL(sub_2988);
                                                                                                                                                                                                                                                r9 = 0x13c0u;
                                                                                                                                                                                                                                                r15 = d32(r9);
                                                                                                                                                                                                                                                r9 = 0x22e00u;
                                                                                                                                                                                                                                                iowr(r9, r15);
                                                                                                                                                                                                                                                r15 = 0x4u;
                                                                                                                                                                                                                                                r9 = r9 + 0x100u;
                                                                                                                                                                                                                                                iowr(r9, r15);
                                                                                                                                                                                                                                                L_6f31:; /* 0x6f31 */
                                                                                                                                                                                                                                                r15 = 0;
                                                                                                                                                                                                                                                r9 = 0x10c00u;
                                                                                                                                                                                                                                                iowr(r9, r15);
                                                                                                                                                                                                                                                r9 = 0x14c4u;
                                                                                                                                                                                                                                                r9 = d32(r9);
                                                                                                                                                                                                                                                if (!(r9 == 0x0u)) {
                                                                                                                                                                                                                                                    L_6f44:; /* 0x6f44 */
                                                                                                                                                                                                                                                    r9 = 0x14b4u;
                                                                                                                                                                                                                                                    r9 = d32(r9);
                                                                                                                                                                                                                                                    if (!(r9 == 0x0u)) {
                                                                                                                                                                                                                                                        L_6f4e:; /* 0x6f4e */
                                                                                                                                                                                                                                                        r15 = 0x2f100000u;
                                                                                                                                                                                                                                                        r9 = 0x22a00u;
                                                                                                                                                                                                                                                        iowr(r9, r15);
                                                                                                                                                                                                                                                        r11 = 0x3u;
                                                                                                                                                                                                                                                        r10 = 0xau;
                                                                                                                                                                                                                                                        CALL(sub_557b);
                                                                                                                                                                                                                                                        r10 = r6;
                                                                                                                                                                                                                                                        CALL(sub_56ad);
                                                                                                                                                                                                                                                        r15 = 0x37080000u;
                                                                                                                                                                                                                                                        r9 = 0x22a00u;
                                                                                                                                                                                                                                                        iowr(r9, r15);
                                                                                                                                                                                                                                                        L_6f74:; /* 0x6f74 */
                                                                                                                                                                                                                                                        r10 = d32(sp+0x30);
                                                                                                                                                                                                                                                        r11 = r6;
                                                                                                                                                                                                                                                        CALL(sub_547d);
                                                                                                                                                                                                                                                        r15 = 0;
                                                                                                                                                                                                                                                        r9 = 0x1ac00u;
                                                                                                                                                                                                                                                        iowr(r9, r15);
                                                                                                                                                                                                                                                        r9 = 0x1494u;
                                                                                                                                                                                                                                                        r15 = d32(r9);
                                                                                                                                                                                                                                                        r9 = 0x20a00u;
                                                                                                                                                                                                                                                        iowr(r9, r15);
                                                                                                                                                                                                                                                        r9 = 0x1494u;
                                                                                                                                                                                                                                                        r15 = d32(r9+0x4);
                                                                                                                                                                                                                                                        r9 = 0x20b00u;
                                                                                                                                                                                                                                                        iowr(r9, r15);
                                                                                                                                                                                                                                                        r9 = 0x1494u;
                                                                                                                                                                                                                                                        r15 = d32(r9+0x8);
                                                                                                                                                                                                                                                        r9 = 0x20c00u;
                                                                                                                                                                                                                                                        iowr(r9, r15);
                                                                                                                                                                                                                                                        r9 = 0x2c000u;
                                                                                                                                                                                                                                                        r15 = d32(sp+0x30);
                                                                                                                                                                                                                                                        iowr(r9, r15);
                                                                                                                                                                                                                                                        r15 = 0;
                                                                                                                                                                                                                                                        r9 = 0x12bcu;
                                                                                                                                                                                                                                                        s32(r9, r15);
                                                                                                                                                                                                                                                        r15 = 0x8000u;
                                                                                                                                                                                                                                                        r9 = 0x21a00u;
                                                                                                                                                                                                                                                        iowr(r9, r15);
                                                                                                                                                                                                                                                        CALL(sub_2175);
                                                                                                                                                                                                                                                        r15 = 0x1u;
                                                                                                                                                                                                                                                        r9 = 0x20000u;
                                                                                                                                                                                                                                                        iowr(r9, r15);
                                                                                                                                                                                                                                                        r15 = 0x3f000000u;
                                                                                                                                                                                                                                                        r9 = r9 + 0x2a00u;
                                                                                                                                                                                                                                                        iowr(r9, r15);
                                                                                                                                                                                                                                                        r15 = 0x40000000u;
                                                                                                                                                                                                                                                        iowr(r9, r15);
                                                                                                                                                                                                                                                        r15 = 0x40000u;
                                                                                                                                                                                                                                                        r9 = r9 - 0x1200u;
                                                                                                                                                                                                                                                        iowr(r9, r15);
                                                                                                                                                                                                                                                        r9 = sp;
                                                                                                                                                                                                                                                        r9 = r9 + 0x64u;
                                                                                                                                                                                                                                                        r15 = d32(r9);
                                                                                                                                                                                                                                                        r9 = 0x1604u;
                                                                                                                                                                                                                                                        r9 = d32(r9);
                                                                                                                                                                                                                                                        fc_cmp(r15, r9);
                                                                                                                                                                                                                                                        if (!FZ(falcon_flags)) {
                                                                                                                                                                                                                                                            L_700d:; /* 0x700d */
                                                                                                                                                                                                                                                            goto L_705c;
                                                                                                                                                                                                                                                            L_7011:; /* 0x7011 */
                                                                                                                                                                                                                                                            r9 = 0x1450u;
                                                                                                                                                                                                                                                            r9 = d32(r9);
                                                                                                                                                                                                                                                            if (!(r9 == 0x0u)) {
                                                                                                                                                                                                                                                                goto L_6551;  /* 重复引用 */
                                                                                                                                                                                                                                                                goto L_666c;  /* 重复引用 */
                                                                                                                                                                                                                                                                goto L_668c;  /* 重复引用 */
                                                                                                                                                                                                                                                                goto L_66c9;  /* 重复引用 */
                                                                                                                                                                                                                                                                goto L_66e8;  /* 重复引用 */
                                                                                                                                                                                                                                                                L_701c:; /* 0x701c */
                                                                                                                                                                                                                                                                goto L_6551;
                                                                                                                                                                                                                                                                L_7020:; /* 0x7020 */
                                                                                                                                                                                                                                                                r9 = 0x3bcu;
                                                                                                                                                                                                                                                                r13 = d32(r9);
                                                                                                                                                                                                                                                                r10 = 0x1u;
                                                                                                                                                                                                                                                                r12 = 0x328u;
                                                                                                                                                                                                                                                                r11 = r10;
                                                                                                                                                                                                                                                                CALL(sub_7e1);
                                                                                                                                                                                                                                                                r9 = 0x408u;
                                                                                                                                                                                                                                                                r13 = d32(r9);
                                                                                                                                                                                                                                                                r10 = 0x1u;
                                                                                                                                                                                                                                                                r11 = 0x3u;
                                                                                                                                                                                                                                                                r12 = 0x3c0u;
                                                                                                                                                                                                                                                                CALL(sub_7e1);
                                                                                                                                                                                                                                                                r9 = 0x428u;
                                                                                                                                                                                                                                                                r13 = d32(r9);
                                                                                                                                                                                                                                                                r10 = 0x15u;
                                                                                                                                                                                                                                                                r11 = 0x4u;
                                                                                                                                                                                                                                                                r12 = 0x41cu;
                                                                                                                                                                                                                                                                r0 = 0x1u;
                                                                                                                                                                                                                                                                CALL(sub_7e1);
                                                                                                                                                                                                                                                                goto L_6cae;
                                                                                                                                                                                                                                                                L_705c:; /* 0x705c */
                                                                                                                                                                                                                                                                CALL(sub_747);
                                                                                                                                                                                                                                                                L_7060:; /* 0x7060 */
                                                                                                                                                                                                                                                                sp += 0xcu;
                                                                                                                                                                                                                                                                for (int i = 0; i <= 8; i++) r[i] = pop32();
                                                                                                                                                                                                                                                                sp += 0x38;
                                                                                                                                                                                                                                                                return;
                                                                                                                                                                                                                                                            }
                                                                                                                                                                                                                                                            goto L_655d;  /* 重复引用 */
                                                                                                                                                                                                                                                            goto L_705c;  /* 重复引用 */
                                                                                                                                                                                                                                                        }
                                                                                                                                                                                                                                                        goto L_7060;  /* 重复引用 */
                                                                                                                                                                                                                                                    }
                                                                                                                                                                                                                                                    goto L_6f74;  /* 重复引用 */
                                                                                                                                                                                                                                                    goto L_6f4e;  /* 重复引用 */
                                                                                                                                                                                                                                                }
                                                                                                                                                                                                                                                goto L_6f74;  /* 重复引用 */
                                                                                                                                                                                                                                            }
                                                                                                                                                                                                                                            goto L_6f00;  /* 重复引用 */
                                                                                                                                                                                                                                            goto L_6ef6;  /* 重复引用 */
                                                                                                                                                                                                                                            goto L_6f00;  /* 重复引用 */
                                                                                                                                                                                                                                        }
                                                                                                                                                                                                                                        goto L_6f31;  /* 重复引用 */
                                                                                                                                                                                                                                    }
                                                                                                                                                                                                                                    goto L_6edc;  /* 重复引用 */
                                                                                                                                                                                                                                }
                                                                                                                                                                                                                                goto L_6e8d;  /* 重复引用 */
                                                                                                                                                                                                                            }
                                                                                                                                                                                                                            goto L_6e71;  /* 重复引用 */
                                                                                                                                                                                                                            goto L_6e6d;  /* 重复引用 */
                                                                                                                                                                                                                        }
                                                                                                                                                                                                                        goto L_6e71;  /* 重复引用 */
                                                                                                                                                                                                                    }
                                                                                                                                                                                                                    goto L_6e36;  /* 重复引用 */
                                                                                                                                                                                                                }
                                                                                                                                                                                                                goto L_6e22;  /* 重复引用 */
                                                                                                                                                                                                                goto L_6df1;  /* 重复引用 */
                                                                                                                                                                                                            }
                                                                                                                                                                                                            goto L_6e22;  /* 重复引用 */
                                                                                                                                                                                                            goto L_6ded;  /* 重复引用 */
                                                                                                                                                                                                            goto L_6df1;  /* 重复引用 */
                                                                                                                                                                                                        }
                                                                                                                                                                                                        goto L_6e22;  /* 重复引用 */
                                                                                                                                                                                                    }
                                                                                                                                                                                                    goto L_6dd9;  /* 重复引用 */
                                                                                                                                                                                                }
                                                                                                                                                                                                goto L_6da7;  /* 重复引用 */
                                                                                                                                                                                            }
                                                                                                                                                                                            goto L_6d7f;  /* 重复引用 */
                                                                                                                                                                                        }
                                                                                                                                                                                        goto L_6d6d;  /* 重复引用 */
                                                                                                                                                                                    }
                                                                                                                                                                                    goto L_6cf1;  /* 重复引用 */
                                                                                                                                                                                    goto L_6ceb;  /* 重复引用 */
                                                                                                                                                                                }
                                                                                                                                                                                goto L_6cf1;  /* 重复引用 */
                                                                                                                                                                            }
                                                                                                                                                                            goto L_6ccd;  /* 重复引用 */
                                                                                                                                                                            goto L_6cc5;  /* 重复引用 */
                                                                                                                                                                        }
                                                                                                                                                                        goto L_6ccd;  /* 重复引用 */
                                                                                                                                                                    }
                                                                                                                                                                    goto L_7020;  /* 重复引用 */
                                                                                                                                                                }
                                                                                                                                                                goto L_6c87;  /* 重复引用 */
                                                                                                                                                            }
                                                                                                                                                            goto L_6c47;  /* 重复引用 */
                                                                                                                                                            goto L_6c45;  /* 重复引用 */
                                                                                                                                                        }
                                                                                                                                                        goto L_6c47;  /* 重复引用 */
                                                                                                                                                        goto L_6c3f;  /* 重复引用 */
                                                                                                                                                        goto L_6c45;  /* 重复引用 */
                                                                                                                                                        goto L_6c47;  /* 重复引用 */
                                                                                                                                                    }
                                                                                                                                                    goto L_6c4d;  /* 重复引用 */
                                                                                                                                                }
                                                                                                                                                goto L_6c25;  /* 重复引用 */
                                                                                                                                            }
                                                                                                                                            goto L_6c19;  /* 重复引用 */
                                                                                                                                        }
                                                                                                                                        goto L_6bed;  /* 重复引用 */
                                                                                                                                    }
                                                                                                                                    goto L_6bd9;  /* 重复引用 */
                                                                                                                                    goto L_6bcd;  /* 重复引用 */
                                                                                                                                }
                                                                                                                                goto L_6bd9;  /* 重复引用 */
                                                                                                                            }
                                                                                                                            goto L_6b51;  /* 重复引用 */
                                                                                                                            goto L_6a96;  /* 重复引用 */
                                                                                                                        }
                                                                                                                        goto L_6b51;  /* 重复引用 */
                                                                                                                        goto L_6a8b;  /* 重复引用 */
                                                                                                                        goto L_6a96;  /* 重复引用 */
                                                                                                                        goto L_6b51;  /* 重复引用 */
                                                                                                                        goto L_6b68;  /* 重复引用 */
                                                                                                                    }
                                                                                                                    goto L_6b8f;  /* 重复引用 */
                                                                                                                    goto L_6a80;  /* 重复引用 */
                                                                                                                    goto L_6a8b;  /* 重复引用 */
                                                                                                                    goto L_6a96;  /* 重复引用 */
                                                                                                                    goto L_6b51;  /* 重复引用 */
                                                                                                                    goto L_6b68;  /* 重复引用 */
                                                                                                                }
                                                                                                                goto L_6b8f;  /* 重复引用 */
                                                                                                                goto L_6a39;  /* 重复引用 */
                                                                                                                goto L_6a53;  /* 重复引用 */
                                                                                                            }
                                                                                                            goto L_6a5a;  /* 重复引用 */
                                                                                                        }
                                                                                                        goto L_69d0;  /* 重复引用 */
                                                                                                        goto L_6979;  /* 重复引用 */
                                                                                                    }
                                                                                                    goto L_69d0;  /* 重复引用 */
                                                                                                    goto L_696f;  /* 重复引用 */
                                                                                                    goto L_6979;  /* 重复引用 */
                                                                                                }
                                                                                                goto L_69d0;  /* 重复引用 */
                                                                                            }
                                                                                            goto L_695a;  /* 重复引用 */
                                                                                        }
                                                                                        goto L_692c;  /* 重复引用 */
                                                                                    }
                                                                                    goto L_691a;  /* 重复引用 */
                                                                                    goto L_690c;  /* 重复引用 */
                                                                                    goto L_691a;  /* 重复引用 */
                                                                                    goto L_6922;  /* 重复引用 */
                                                                                    goto L_692c;  /* 重复引用 */
                                                                                }
                                                                                goto L_6932;  /* 重复引用 */
                                                                            }
                                                                            goto L_68ee;  /* 重复引用 */
                                                                        }
                                                                        goto L_68e2;  /* 重复引用 */
                                                                    }
                                                                    goto L_68d6;  /* 重复引用 */
                                                                    goto L_68ce;  /* 重复引用 */
                                                                    goto L_68d6;  /* 重复引用 */
                                                                    goto L_68da;  /* 重复引用 */
                                                                    goto L_68e2;  /* 重复引用 */
                                                                    goto L_68e6;  /* 重复引用 */
                                                                    goto L_68ee;  /* 重复引用 */
                                                                    goto L_68f2;  /* 重复引用 */
                                                                }
                                                                goto L_6902;  /* 重复引用 */
                                                                goto L_68be;  /* 重复引用 */
                                                                goto L_68ce;  /* 重复引用 */
                                                                goto L_68d6;  /* 重复引用 */
                                                                goto L_68da;  /* 重复引用 */
                                                                goto L_68e2;  /* 重复引用 */
                                                                goto L_68e6;  /* 重复引用 */
                                                                goto L_68ee;  /* 重复引用 */
                                                                goto L_68f2;  /* 重复引用 */
                                                            }
                                                            goto L_6902;  /* 重复引用 */
                                                        }
                                                        goto L_6863;  /* 重复引用 */
                                                    }
                                                    goto L_6857;  /* 重复引用 */
                                                }
                                                goto L_67fd;  /* 重复引用 */
                                            }
                                            goto L_67cf;  /* 重复引用 */
                                        }
                                        goto L_67c8;  /* 重复引用 */
                                    }
                                    goto L_67bd;  /* 重复引用 */
                                    goto L_67b7;  /* 重复引用 */
                                }
                                goto L_67bd;  /* 重复引用 */
                            }
                            goto L_6774;  /* 重复引用 */
                        }
                        goto L_66e8;  /* 重复引用 */
                        goto L_66c9;  /* 重复引用 */
                    }
                    goto L_66e8;  /* 重复引用 */
                }
                goto L_66ea;  /* 重复引用 */
            }
            goto L_654b;  /* 重复引用 */
        }
        goto L_6530;  /* 重复引用 */
        goto L_6528;  /* 重复引用 */
        goto L_6530;  /* 重复引用 */
        goto L_6532;  /* 重复引用 */
        goto L_6543;  /* 重复引用 */
        goto L_654b;  /* 重复引用 */
    }
    goto L_7011;  /* 重复引用 */
}

/* ==== sub_7066  (被调用 1 次) ==== */
static void sub_7066(void) {
    L_7066:; /* 0x7066 */
    for (int i = 2; i >= 0; i--) push32(r[i]);
    r15 = 0x1000u;
    r9 = 0x21200u;
    iowr(r9, r15);
    r12 = 0;
    r13 = 0x1u;
    CALL(sub_64ad);
    r2 = 0x1370u;
    r13 = 0x136cu;
    r1 = 0;
    r0 = -0xf001u;
    r10 = 0x10000u;
    r11 = 0x2c300u;
    r12 = 0x1u;
    goto L_70d0;
    L_7096:; /* 0x7096 */
    r9 = d32(r13);
    r15 = d32(r13);
    r15 = d32(r13);
    r14 = 0x132cu;
    r9 &= 0x7u;
    r9 <<= 0x3u;
    r9 = r9 + r14;
    r15 = r15 + 0x1u;
    r14 = d32(r9);
    s32(r13, r15);
    r9 = d32(r13);
    r14 &= r0;
    if (!(r9 != 0x10u)) {
        L_70b9:; /* 0x70b9 */
        s32(r13, r1);
        L_70bb:; /* 0x70bb */
        fc_cmp(r14, r10);
        if (!FZ(falcon_flags)) {
            L_70c0:; /* 0x70c0 */
            r15 = 0x2u;
            r9 = 0x20000u;
            iowr(r9, r15);
            goto L_70d9;
            L_70cd:; /* 0x70cd */
            iowr(r11, r12);
            L_70d0:; /* 0x70d0 */
            r15 = d32(r2);
            r9 = d32(r13);
            fc_cmp(r15, r9);
            if (!FZ(falcon_flags)) goto L_7096;
            L_70d9:; /* 0x70d9 */
            r15 = 0x1000u;
            r9 = 0x21800u;
            iowr(r9, r15);
            for (int i = 0; i <= 2; i++) r[i] = pop32();
            return;
        }
        goto L_70cd;  /* 重复引用 */
    }
    goto L_70bb;  /* 重复引用 */
}

/* ==== sub_70e5  (被调用 1 次) ==== */
static void sub_70e5(void) {
    L_70e5:; /* 0x70e5 */
    for (int i = 2; i >= 0; i--) push32(r[i]);
    r15 = 0x10000u;
    r9 = 0x21200u;
    iowr(r9, r15);
    r2 = 0x2c000u;
    r15 = 0;
    r11 = iord(r2+r15*0x4);
    r9 = 0x2c100u;
    r1 = iord(r9+r15*0x4);
    r0 = r1 >> 0x1fu;
    r9 = r9 + 0x1d00u;
    r9 = iord(r9+r15*0x4);
    r9 = r11 >> 0x1fu;
    if (!FZ(falcon_flags)) {
        L_7114:; /* 0x7114 */
        r9 = 0x3fffffffu;
        r15 = r1 & r9;
        r9 = r11 & r9;
        if (!(r0 == 0x0u)) {
            L_7123:; /* 0x7123 */
            fc_cmp(r9, r15);
            if (!FZ(falcon_flags)) {
                L_7128:; /* 0x7128 */
                r9 = 0x13f0u;
                r9 = d32(r9);
                if (!(r9 != 0x0u)) {
                    L_7132:; /* 0x7132 */
                    r10 = 0;
                    r12 = 0x2u;
                    r13 = 0;
                    CALL(sub_64ad);
                    L_713c:; /* 0x713c */
                    r9 = 0x2c000u;
                    iowr(r9, r1);
                    r9 = 0x13f0u;
                    r0 = d32(r9);
                    if (!(r0 != 0x0u)) {
                        L_714e:; /* 0x714e */
                        r11 = r1;
                        r10 = 0;
                        r12 = 0x2u;
                        CALL(sub_5850);
                        r9 = 0x12b8u;
                        s32(r9, r0);
                        goto L_7253;
                        L_7162:; /* 0x7162 */
                        r15 = 0;
                        r9 = 0x2dc00u;
                        iowr(r9, r15);
                        r10 = 0x4041b4u;
                        r11 = 0x1u;
                        CALL(sub_237);
                        r9 = 0x12bcu;
                        r15 = 0x1u;
                        s32(r9, r15);
                        r15 = r15 + 0x7fffu;
                        r9 = 0x21400u;
                        goto L_7250;
                        L_718a:; /* 0x718a */
                        fc_cmp(r9, r15);
                        if (!!FZ(falcon_flags)) {
                            L_7190:; /* 0x7190 */
                            r9 = 0x13f0u;
                            r2 = d32(r9);
                            if (!(r2 != 0x0u)) {
                                L_719a:; /* 0x719a */
                                r10 = 0;
                                r12 = 0;
                                r13 = 0;
                                CALL(sub_64ad);
                                r9 = 0x12b8u;
                                s32(r9, r2);
                                goto L_71e1;
                                L_71ae:; /* 0x71ae */
                                r10 = 0;
                                r11 = 0;
                                CALL(sub_473f);
                                r9 = 0x30000u;
                                r9 = iord(r9+r0*0x4);
                                r15 = 0x1u;
                                r9 &= 0x40u;
                                if (!!FZ(falcon_flags)) {
                                    L_71c5:; /* 0x71c5 */
                                    r15 = 0;
                                    L_71c7:; /* 0x71c7 */
                                    r9 = 0x2dc00u;
                                    iowr(r9, r15);
                                    r15 = 0;
                                    r9 = 0x12bcu;
                                    s32(r9, r15);
                                    r15 = 0x8000u;
                                    r9 = 0x21a00u;
                                    iowr(r9, r15);
                                    L_71e1:; /* 0x71e1 */
                                    r9 = 0x2c000u;
                                    iowr(r9, r1);
                                    goto L_7253;
                                    L_71ec:; /* 0x71ec */
                                    if (!(r0 == 0x0u)) {
                                        L_71f0:; /* 0x71f0 */
                                        CALL(sub_4751);
                                        r9 = 0x1u;
                                        r15 = 0x12b8u;
                                        s32(r15, r9);
                                        iowr(r2, r1);
                                        r9 = 0x13f0u;
                                        r0 = d32(r9);
                                        r2 = 0x12b8u;
                                        if (!(r0 != 0x0u)) {
                                            L_720d:; /* 0x720d */
                                            r11 = r1;
                                            r10 = 0;
                                            r12 = 0x1u;
                                            CALL(sub_5850);
                                            s32(r2, r0);
                                            goto L_724a;
                                            L_721d:; /* 0x721d */
                                            r15 = 0x13f4u;
                                            r9 = d32(r15);
                                            r11 = 0x1u;
                                            r10 = 0x4041b4u;
                                            r9 = r9 + r11;
                                            s32(r15, r9);
                                            CALL(sub_237);
                                            r9 = 0;
                                            s32(r2, r9);
                                            r9 = 0x12bcu;
                                            r15 = 0x1u;
                                            s32(r9, r15);
                                            r15 = r15 + 0x7fffu;
                                            r9 = 0x21400u;
                                            iowr(r9, r15);
                                            L_724a:; /* 0x724a */
                                            r15 = 0;
                                            r9 = 0x2dc00u;
                                            L_7250:; /* 0x7250 */
                                            iowr(r9, r15);
                                            L_7253:; /* 0x7253 */
                                            r15 = 0x10000u;
                                            r9 = 0x21800u;
                                            iowr(r9, r15);
                                            for (int i = 0; i <= 2; i++) r[i] = pop32();
                                            return;
                                        }
                                        goto L_721d;  /* 重复引用 */
                                        goto L_720d;  /* 重复引用 */
                                        goto L_721d;  /* 重复引用 */
                                    }
                                    goto L_724a;  /* 重复引用 */
                                }
                                goto L_71c7;  /* 重复引用 */
                            }
                            goto L_71ae;  /* 重复引用 */
                            goto L_719a;  /* 重复引用 */
                            goto L_71ae;  /* 重复引用 */
                            goto L_71c5;  /* 重复引用 */
                            goto L_71c7;  /* 重复引用 */
                            goto L_71e1;  /* 重复引用 */
                        }
                        goto L_7253;  /* 重复引用 */
                    }
                    goto L_7253;  /* 重复引用 */
                }
                goto L_713c;  /* 重复引用 */
                goto L_7132;  /* 重复引用 */
                goto L_713c;  /* 重复引用 */
                goto L_714e;  /* 重复引用 */
            }
            goto L_7162;  /* 重复引用 */
            goto L_7128;  /* 重复引用 */
            goto L_7132;  /* 重复引用 */
            goto L_713c;  /* 重复引用 */
            goto L_714e;  /* 重复引用 */
            goto L_7162;  /* 重复引用 */
        }
        goto L_718a;  /* 重复引用 */
        goto L_7123;  /* 重复引用 */
        goto L_7128;  /* 重复引用 */
        goto L_7132;  /* 重复引用 */
        goto L_713c;  /* 重复引用 */
        goto L_714e;  /* 重复引用 */
        goto L_7162;  /* 重复引用 */
        goto L_718a;  /* 重复引用 */
        goto L_7190;  /* 重复引用 */
        goto L_719a;  /* 重复引用 */
        goto L_71ae;  /* 重复引用 */
        goto L_71c5;  /* 重复引用 */
        goto L_71c7;  /* 重复引用 */
        goto L_71e1;  /* 重复引用 */
    }
    goto L_71ec;  /* 重复引用 */
}

/* ==== sub_7260  (被调用 1 次) ==== */
static void sub_7260(void) {
    L_7260:; /* 0x7260 */
    sp += -0x8u;
    for (int i = 1; i >= 0; i--) push32(r[i]);
    r1 = 0x1604u;
    r9 = d32(r1);
    r12 = r10;
    r0 = sp;
    r10 = sp;
    r0 = r0 + 0xcu;
    r10 = r10 + 0x8u;
    s32(r0, r9);
    r11 = 0xffu;
    CALL(sub_77e8);
    r15 = d32(r0);
    r9 = d32(r1);
    fc_cmp(r15, r9);
    if (!FZ(falcon_flags)) {
        L_728b:; /* 0x728b */
        CALL(sub_747);
        L_728f:; /* 0x728f */
        for (int i = 0; i <= 1; i++) r[i] = pop32();
        sp += 0x8;
        return;
    }
    goto L_728f;  /* 重复引用 */
}

/* ==== sub_7292  (被调用 1 次) ==== */
static void sub_7292(void) {
    L_7292:; /* 0x7292 */
    for (int i = 1; i >= 0; i--) push32(r[i]);
    r15 = 0x8u;
    r9 = 0x21200u;
    iowr(r9, r15);
    r9 = 0x1370u;
    r12 = 0x136cu;
    r14 = d32(r9);
    r15 = d32(r12);
    r11 = 0;
    r9 = 0x12c0u;
    s32(r9, r11);
    fc_cmp(r14, r15);
    if (!FZ(falcon_flags)) {
        L_72b7:; /* 0x72b7 */
        r9 = d32(r12);
        r15 = d32(r12);
        r14 = d32(r12);
        r13 = 0x132cu;
        r9 &= 0x7u;
        r9 <<= 0x3u;
        r14 = r14 + 0x1u;
        r9 = r9 + r13;
        r10 = d32(r9);
        s32(r12, r14);
        r14 = d32(r12);
        r15 &= 0x7u;
        r15 = r15 + r15;
        r15 = r15 + 0x1u;
        r13 = d32(r13+r15*0x4);
        if (!(r14 != 0x10u)) {
            L_72e3:; /* 0x72e3 */
            s32(r12, r11);
            L_72e5:; /* 0x72e5 */
            r9 = -0xf001u;
            r10 &= r9;
            if (!(r10 == 0x25u)) {
                L_72f1:; /* 0x72f1 */
                fc_cmp(r10, 0x25u);
                if (!(!FC(falcon_flags) && !FZ(falcon_flags))) {
                    L_72f8:; /* 0x72f8 */
                    fc_cmp(r10, 0x14u);
                    if (!(!FC(falcon_flags) && !FZ(falcon_flags))) {
                        L_72fe:; /* 0x72fe */
                        fc_cmp(r10, 0x13u);
                        if (!!FC(falcon_flags)) {
                            L_7305:; /* 0x7305 */
                            if (!(r10 == 0x9u)) {
                                L_730a:; /* 0x730a */
                                fc_cmp(r10, 0x9u);
                                if (!(!FC(falcon_flags) && !FZ(falcon_flags))) {
                                    L_7310:; /* 0x7310 */
                                    if (!(r10 == 0x2u)) {
                                        L_7315:; /* 0x7315 */
                                        fc_cmp(r10, 0x2u);
                                        if (!(!FC(falcon_flags) && !FZ(falcon_flags))) {
                                            L_731b:; /* 0x731b */
                                            if (!(r10 == 0x0u)) {
                                                L_7320:; /* 0x7320 */
                                                if (!(r10 != 0x1u)) {
                                                    L_7325:; /* 0x7325 */
                                                    goto L_7489;
                                                    L_7329:; /* 0x7329 */
                                                    if (!(r10 == 0x6u)) {
                                                        L_732e:; /* 0x732e */
                                                        if (!(r10 == 0x8u)) {
                                                            L_7333:; /* 0x7333 */
                                                            if (!(r10 != 0x3u)) {
                                                                L_7338:; /* 0x7338 */
                                                                goto L_74f1;
                                                                L_733c:; /* 0x733c */
                                                                if (!(r10 == 0xeu)) {
                                                                    L_7341:; /* 0x7341 */
                                                                    fc_cmp(r10, 0xeu);
                                                                    if (!(!FC(falcon_flags) && !FZ(falcon_flags))) {
                                                                        L_7347:; /* 0x7347 */
                                                                        if (!(r10 == 0xcu)) {
                                                                            L_734c:; /* 0x734c */
                                                                            if (!(r10 != 0xdu)) {
                                                                                L_7351:; /* 0x7351 */
                                                                                goto L_75d6;
                                                                                L_7355:; /* 0x7355 */
                                                                                if (!(r10 == 0x10u)) {
                                                                                    L_735a:; /* 0x735a */
                                                                                    fc_cmp(r10, 0x10u);
                                                                                    if (!FC(falcon_flags)) {
                                                                                        L_7361:; /* 0x7361 */
                                                                                        if (!(r10 != 0x11u)) {
                                                                                            L_7366:; /* 0x7366 */
                                                                                            goto L_75b9;
                                                                                            L_736a:; /* 0x736a */
                                                                                            if (!(r10 == 0x1bu)) {
                                                                                                L_736f:; /* 0x736f */
                                                                                                fc_cmp(r10, 0x1bu);
                                                                                                if (!(!FC(falcon_flags) && !FZ(falcon_flags))) {
                                                                                                    L_7375:; /* 0x7375 */
                                                                                                    fc_cmp(r10, 0x19u);
                                                                                                    if (!(!FC(falcon_flags) && !FZ(falcon_flags))) {
                                                                                                        L_737c:; /* 0x737c */
                                                                                                        fc_cmp(r10, 0x17u);
                                                                                                        if (!!FC(falcon_flags)) {
                                                                                                            L_7383:; /* 0x7383 */
                                                                                                            if (!(r10 == 0x15u)) {
                                                                                                                L_7388:; /* 0x7388 */
                                                                                                                if (!(r10 != 0x16u)) {
                                                                                                                    L_738d:; /* 0x738d */
                                                                                                                    goto L_75a5;
                                                                                                                    L_7391:; /* 0x7391 */
                                                                                                                    if (!(r10 == 0x21u)) {
                                                                                                                        L_7396:; /* 0x7396 */
                                                                                                                        fc_cmp(r10, 0x21u);
                                                                                                                        if (!(!FC(falcon_flags) && !FZ(falcon_flags))) {
                                                                                                                            L_739c:; /* 0x739c */
                                                                                                                            fc_cmp(r10, 0x1fu);
                                                                                                                            if (!(!FC(falcon_flags) && !FZ(falcon_flags))) {
                                                                                                                                L_73a3:; /* 0x73a3 */
                                                                                                                                goto L_7738;
                                                                                                                                L_73a7:; /* 0x73a7 */
                                                                                                                                fc_cmp(r10, 0x23u);
                                                                                                                                if (!(FC(falcon_flags) || FZ(falcon_flags))) {
                                                                                                                                    L_73ae:; /* 0x73ae */
                                                                                                                                    goto L_75cb;
                                                                                                                                    L_73b2:; /* 0x73b2 */
                                                                                                                                    if (!(r10 == 0x55u)) {
                                                                                                                                        L_73b7:; /* 0x73b7 */
                                                                                                                                        fc_cmp(r10, 0x55u);
                                                                                                                                        if (!(!FC(falcon_flags) && !FZ(falcon_flags))) {
                                                                                                                                            L_73be:; /* 0x73be */
                                                                                                                                            if (!(r10 == 0x31u)) {
                                                                                                                                                L_73c3:; /* 0x73c3 */
                                                                                                                                                fc_cmp(r10, 0x31u);
                                                                                                                                                if (!(!FC(falcon_flags) && !FZ(falcon_flags))) {
                                                                                                                                                    L_73c9:; /* 0x73c9 */
                                                                                                                                                    if (!(r10 == 0x2au)) {
                                                                                                                                                        L_73ce:; /* 0x73ce */
                                                                                                                                                        fc_cmp(r10, 0x2au);
                                                                                                                                                        if (!FC(falcon_flags)) {
                                                                                                                                                            L_73d5:; /* 0x73d5 */
                                                                                                                                                            if (!(r10 == 0x2fu)) {
                                                                                                                                                                L_73da:; /* 0x73da */
                                                                                                                                                                fc_cmp(r10, 0x2fu);
                                                                                                                                                                if (!(!FC(falcon_flags) && !FZ(falcon_flags))) {
                                                                                                                                                                    L_73e1:; /* 0x73e1 */
                                                                                                                                                                    if (!(r10 != 0x2eu)) {
                                                                                                                                                                        L_73e6:; /* 0x73e6 */
                                                                                                                                                                        goto L_7557;
                                                                                                                                                                        L_73ea:; /* 0x73ea */
                                                                                                                                                                        if (!(r10 == 0x34u)) {
                                                                                                                                                                            L_73ef:; /* 0x73ef */
                                                                                                                                                                            fc_cmp(r10, 0x34u);
                                                                                                                                                                            if (!(!FC(falcon_flags) && !FZ(falcon_flags))) {
                                                                                                                                                                                L_73f5:; /* 0x73f5 */
                                                                                                                                                                                if (!(r10 == 0x32u)) {
                                                                                                                                                                                    L_73fa:; /* 0x73fa */
                                                                                                                                                                                    if (!(r10 != 0x33u)) {
                                                                                                                                                                                        L_73ff:; /* 0x73ff */
                                                                                                                                                                                        goto L_7637;
                                                                                                                                                                                        L_7403:; /* 0x7403 */
                                                                                                                                                                                        if (!(r10 == 0x36u)) {
                                                                                                                                                                                            L_7408:; /* 0x7408 */
                                                                                                                                                                                            fc_cmp(r10, 0x36u);
                                                                                                                                                                                            if (!FC(falcon_flags)) {
                                                                                                                                                                                                L_740f:; /* 0x740f */
                                                                                                                                                                                                if (!(r10 != 0x54u)) {
                                                                                                                                                                                                    L_7414:; /* 0x7414 */
                                                                                                                                                                                                    goto L_7523;
                                                                                                                                                                                                    L_7418:; /* 0x7418 */
                                                                                                                                                                                                    fc_cmp(r10, 0x64u);
                                                                                                                                                                                                    if (!(!FC(falcon_flags) && !FZ(falcon_flags))) {
                                                                                                                                                                                                        L_741f:; /* 0x741f */
                                                                                                                                                                                                        fc_cmp(r10, 0x62u);
                                                                                                                                                                                                        if (!!FC(falcon_flags)) {
                                                                                                                                                                                                            L_7427:; /* 0x7427 */
                                                                                                                                                                                                            if (!(r10 == 0x58u)) {
                                                                                                                                                                                                                L_742c:; /* 0x742c */
                                                                                                                                                                                                                fc_cmp(r10, 0x58u);
                                                                                                                                                                                                                if (!(!FC(falcon_flags) && !FZ(falcon_flags))) {
                                                                                                                                                                                                                    L_7433:; /* 0x7433 */
                                                                                                                                                                                                                    if (!(r10 == 0x56u)) {
                                                                                                                                                                                                                        L_7438:; /* 0x7438 */
                                                                                                                                                                                                                        if (!(r10 != 0x57u)) {
                                                                                                                                                                                                                            L_743d:; /* 0x743d */
                                                                                                                                                                                                                            goto L_754f;
                                                                                                                                                                                                                            L_7441:; /* 0x7441 */
                                                                                                                                                                                                                            if (!(r10 == 0x59u)) {
                                                                                                                                                                                                                                L_7446:; /* 0x7446 */
                                                                                                                                                                                                                                if (!(r10 != 0x60u)) {
                                                                                                                                                                                                                                    L_744b:; /* 0x744b */
                                                                                                                                                                                                                                    goto L_74f9;
                                                                                                                                                                                                                                    L_744f:; /* 0x744f */
                                                                                                                                                                                                                                    if (!(r10 == 0x70u)) {
                                                                                                                                                                                                                                        L_7454:; /* 0x7454 */
                                                                                                                                                                                                                                        fc_cmp(r10, 0x70u);
                                                                                                                                                                                                                                        if (!(!FC(falcon_flags) && !FZ(falcon_flags))) {
                                                                                                                                                                                                                                            L_745b:; /* 0x745b */
                                                                                                                                                                                                                                            if (!(r10 == 0x69u)) {
                                                                                                                                                                                                                                                L_7460:; /* 0x7460 */
                                                                                                                                                                                                                                                if (!(r10 != 0x6au)) {
                                                                                                                                                                                                                                                    L_7465:; /* 0x7465 */
                                                                                                                                                                                                                                                    goto L_770c;
                                                                                                                                                                                                                                                    L_7469:; /* 0x7469 */
                                                                                                                                                                                                                                                    r9 = 0x10001u;
                                                                                                                                                                                                                                                    fc_cmp(r10, r9);
                                                                                                                                                                                                                                                    if (!FZ(falcon_flags)) {
                                                                                                                                                                                                                                                        L_7473:; /* 0x7473 */
                                                                                                                                                                                                                                                        r9 = r9 + 0x3u;
                                                                                                                                                                                                                                                        fc_cmp(r10, r9);
                                                                                                                                                                                                                                                        if (!FZ(falcon_flags)) {
                                                                                                                                                                                                                                                            L_747c:; /* 0x747c */
                                                                                                                                                                                                                                                            r9 = r9 - 0x4u;
                                                                                                                                                                                                                                                            fc_cmp(r10, r9);
                                                                                                                                                                                                                                                            if (!!FZ(falcon_flags)) {
                                                                                                                                                                                                                                                                L_7485:; /* 0x7485 */
                                                                                                                                                                                                                                                                goto L_76e1;
                                                                                                                                                                                                                                                                L_7489:; /* 0x7489 */
                                                                                                                                                                                                                                                                r11 = r13;
                                                                                                                                                                                                                                                                r10 = 0x1u;
                                                                                                                                                                                                                                                                r12 = 0x2u;
                                                                                                                                                                                                                                                                goto L_74af;
                                                                                                                                                                                                                                                                L_7493:; /* 0x7493 */
                                                                                                                                                                                                                                                                r0 = 0x12b8u;
                                                                                                                                                                                                                                                                r12 = 0x1u;
                                                                                                                                                                                                                                                                r11 = r13;
                                                                                                                                                                                                                                                                s32(r0, r12);
                                                                                                                                                                                                                                                                CALL(sub_5850);
                                                                                                                                                                                                                                                                r9 = 0;
                                                                                                                                                                                                                                                                s32(r0, r9);
                                                                                                                                                                                                                                                                goto L_7738;
                                                                                                                                                                                                                                                                L_74a9:; /* 0x74a9 */
                                                                                                                                                                                                                                                                r11 = r13;
                                                                                                                                                                                                                                                                r10 = 0x8u;
                                                                                                                                                                                                                                                                r12 = 0;
                                                                                                                                                                                                                                                                L_74af:; /* 0x74af */
                                                                                                                                                                                                                                                                r13 = 0;
                                                                                                                                                                                                                                                                CALL(sub_64ad);
                                                                                                                                                                                                                                                                r15 = 0;
                                                                                                                                                                                                                                                                r9 = 0x12b8u;
                                                                                                                                                                                                                                                                s32(r9, r15);
                                                                                                                                                                                                                                                                goto L_7738;
                                                                                                                                                                                                                                                                L_74c1:; /* 0x74c1 */
                                                                                                                                                                                                                                                                r9 = 0x24u;
                                                                                                                                                                                                                                                                r11 = r13;
                                                                                                                                                                                                                                                                s32(r9, r13);
                                                                                                                                                                                                                                                                CALL(sub_cc5);
                                                                                                                                                                                                                                                                CALL(sub_23fc);
                                                                                                                                                                                                                                                                goto L_7738;
                                                                                                                                                                                                                                                                L_74d5:; /* 0x74d5 */
                                                                                                                                                                                                                                                                r1 = 0x12b8u;
                                                                                                                                                                                                                                                                r0 = 0x1u;
                                                                                                                                                                                                                                                                r11 = r13;
                                                                                                                                                                                                                                                                s32(r1, r0);
                                                                                                                                                                                                                                                                CALL(sub_7066);
                                                                                                                                                                                                                                                                r9 = 0x142cu;
                                                                                                                                                                                                                                                                s32(r9, r0);
                                                                                                                                                                                                                                                                r9 = 0;
                                                                                                                                                                                                                                                                s32(r1, r9);
                                                                                                                                                                                                                                                                goto L_7738;
                                                                                                                                                                                                                                                                L_74f1:; /* 0x74f1 */
                                                                                                                                                                                                                                                                r11 = r13;
                                                                                                                                                                                                                                                                r12 = 0x1u;
                                                                                                                                                                                                                                                                goto L_74ff;
                                                                                                                                                                                                                                                                L_74f9:; /* 0x74f9 */
                                                                                                                                                                                                                                                                r11 = r13;
                                                                                                                                                                                                                                                                r10 = 0x60u;
                                                                                                                                                                                                                                                                r12 = 0x4u;
                                                                                                                                                                                                                                                                L_74ff:; /* 0x74ff */
                                                                                                                                                                                                                                                                CALL(sub_4dd9);
                                                                                                                                                                                                                                                                r15 = 0x10u;
                                                                                                                                                                                                                                                                L_7505:; /* 0x7505 */
                                                                                                                                                                                                                                                                r9 = 0x20000u;
                                                                                                                                                                                                                                                                L_7509:; /* 0x7509 */
                                                                                                                                                                                                                                                                iowr(r9, r15);
                                                                                                                                                                                                                                                                goto L_7738;
                                                                                                                                                                                                                                                                L_7510:; /* 0x7510 */
                                                                                                                                                                                                                                                                r15 = 0x12c8u;
                                                                                                                                                                                                                                                                r9 = 0x1u;
                                                                                                                                                                                                                                                                s32(r15, r9);
                                                                                                                                                                                                                                                                r15 = 0x20100u;
                                                                                                                                                                                                                                                                iowr(r15, r9);
                                                                                                                                                                                                                                                                goto L_7738;
                                                                                                                                                                                                                                                                L_7523:; /* 0x7523 */
                                                                                                                                                                                                                                                                r9 = 0x13ccu;
                                                                                                                                                                                                                                                                goto L_752f;
                                                                                                                                                                                                                                                                L_752b:; /* 0x752b */
                                                                                                                                                                                                                                                                r9 = 0x13d0u;
                                                                                                                                                                                                                                                                L_752f:; /* 0x752f */
                                                                                                                                                                                                                                                                s32(r9, r13);
                                                                                                                                                                                                                                                                L_7531:; /* 0x7531 */
                                                                                                                                                                                                                                                                r15 = 0x1u;
                                                                                                                                                                                                                                                                goto L_7505;
                                                                                                                                                                                                                                                                L_7537:; /* 0x7537 */
                                                                                                                                                                                                                                                                r9 = 0x13d4u;
                                                                                                                                                                                                                                                                goto L_752f;
                                                                                                                                                                                                                                                                L_753f:; /* 0x753f */
                                                                                                                                                                                                                                                                r9 = 0x13d8u;
                                                                                                                                                                                                                                                                goto L_752f;
                                                                                                                                                                                                                                                                L_7547:; /* 0x7547 */
                                                                                                                                                                                                                                                                r9 = 0x13dcu;
                                                                                                                                                                                                                                                                goto L_752f;
                                                                                                                                                                                                                                                                L_754f:; /* 0x754f */
                                                                                                                                                                                                                                                                CALL(sub_3de4);
                                                                                                                                                                                                                                                                goto L_7738;
                                                                                                                                                                                                                                                                L_7557:; /* 0x7557 */
                                                                                                                                                                                                                                                                r9 = 0x13e8u;
                                                                                                                                                                                                                                                                s32(r9, r13);
                                                                                                                                                                                                                                                                r10 = 0x37u;
                                                                                                                                                                                                                                                                fc_cmp(r13, 0x1u);
                                                                                                                                                                                                                                                                if (!(!FC(falcon_flags) && !FZ(falcon_flags))) {
                                                                                                                                                                                                                                                                    L_7566:; /* 0x7566 */
                                                                                                                                                                                                                                                                    goto L_7531;
                                                                                                                                                                                                                                                                    L_756a:; /* 0x756a */
                                                                                                                                                                                                                                                                    r9 = 0x13e8u;
                                                                                                                                                                                                                                                                    r15 = d32(r9);
                                                                                                                                                                                                                                                                    r9 = 0x13e0u;
                                                                                                                                                                                                                                                                    s32(r9+r15*0x4, r13);
                                                                                                                                                                                                                                                                    goto L_7531;
                                                                                                                                                                                                                                                                    L_757b:; /* 0x757b */
                                                                                                                                                                                                                                                                    r11 = r13;
                                                                                                                                                                                                                                                                    CALL(sub_21a2);
                                                                                                                                                                                                                                                                    goto L_7738;
                                                                                                                                                                                                                                                                    L_7585:; /* 0x7585 */
                                                                                                                                                                                                                                                                    r11 = r13;
                                                                                                                                                                                                                                                                    CALL(sub_23ea);
                                                                                                                                                                                                                                                                    goto L_7738;
                                                                                                                                                                                                                                                                    L_758f:; /* 0x758f */
                                                                                                                                                                                                                                                                    r11 = r13;
                                                                                                                                                                                                                                                                    CALL(sub_49a6);
                                                                                                                                                                                                                                                                    goto L_7738;
                                                                                                                                                                                                                                                                    L_7599:; /* 0x7599 */
                                                                                                                                                                                                                                                                    r11 = r13;
                                                                                                                                                                                                                                                                    r10 = 0x1au;
                                                                                                                                                                                                                                                                    CALL(sub_4c2b);
                                                                                                                                                                                                                                                                    goto L_7738;
                                                                                                                                                                                                                                                                    L_75a5:; /* 0x75a5 */
                                                                                                                                                                                                                                                                    r11 = r13;
                                                                                                                                                                                                                                                                    CALL(sub_29e6);
                                                                                                                                                                                                                                                                    goto L_7738;
                                                                                                                                                                                                                                                                    L_75af:; /* 0x75af */
                                                                                                                                                                                                                                                                    r11 = r13;
                                                                                                                                                                                                                                                                    CALL(sub_2514);
                                                                                                                                                                                                                                                                    goto L_7738;
                                                                                                                                                                                                                                                                    L_75b9:; /* 0x75b9 */
                                                                                                                                                                                                                                                                    r11 = r13;
                                                                                                                                                                                                                                                                    CALL(sub_2cce);
                                                                                                                                                                                                                                                                    goto L_7738;
                                                                                                                                                                                                                                                                    L_75c3:; /* 0x75c3 */
                                                                                                                                                                                                                                                                    CALL(sub_c19);
                                                                                                                                                                                                                                                                    goto L_7738;
                                                                                                                                                                                                                                                                    L_75cb:; /* 0x75cb */
                                                                                                                                                                                                                                                                    r9 = 0x2de00u;
                                                                                                                                                                                                                                                                    iowr(r9, r13);
                                                                                                                                                                                                                                                                    goto L_7531;
                                                                                                                                                                                                                                                                    L_75d6:; /* 0x75d6 */
                                                                                                                                                                                                                                                                    CALL(sub_2717);
                                                                                                                                                                                                                                                                    goto L_7738;
                                                                                                                                                                                                                                                                    L_75de:; /* 0x75de */
                                                                                                                                                                                                                                                                    CALL(sub_26d1);
                                                                                                                                                                                                                                                                    goto L_7738;
                                                                                                                                                                                                                                                                    L_75e6:; /* 0x75e6 */
                                                                                                                                                                                                                                                                    r15 = 0x10000000u;
                                                                                                                                                                                                                                                                    r9 = 0x21200u;
                                                                                                                                                                                                                                                                    iowr(r9, r15);
                                                                                                                                                                                                                                                                    r9 = 0x13f0u;
                                                                                                                                                                                                                                                                    r15 = 0x1u;
                                                                                                                                                                                                                                                                    s32(r9, r15);
                                                                                                                                                                                                                                                                    r9 = 0x20000u;
                                                                                                                                                                                                                                                                    iowr(r9, r15);
                                                                                                                                                                                                                                                                    r15 = 0x10000000u;
                                                                                                                                                                                                                                                                    r9 = r9 + 0x1800u;
                                                                                                                                                                                                                                                                    goto L_7509;
                                                                                                                                                                                                                                                                    L_760f:; /* 0x760f */
                                                                                                                                                                                                                                                                    CALL(sub_1e1a);
                                                                                                                                                                                                                                                                    goto L_7738;
                                                                                                                                                                                                                                                                    L_7617:; /* 0x7617 */
                                                                                                                                                                                                                                                                    r11 = r13;
                                                                                                                                                                                                                                                                    r10 = 0x30u;
                                                                                                                                                                                                                                                                    CALL(sub_1bec);
                                                                                                                                                                                                                                                                    goto L_7738;
                                                                                                                                                                                                                                                                    L_7623:; /* 0x7623 */
                                                                                                                                                                                                                                                                    r11 = r13;
                                                                                                                                                                                                                                                                    CALL(sub_1c31);
                                                                                                                                                                                                                                                                    goto L_7738;
                                                                                                                                                                                                                                                                    L_762d:; /* 0x762d */
                                                                                                                                                                                                                                                                    r11 = r13;
                                                                                                                                                                                                                                                                    CALL(sub_242a);
                                                                                                                                                                                                                                                                    goto L_7738;
                                                                                                                                                                                                                                                                    L_7637:; /* 0x7637 */
                                                                                                                                                                                                                                                                    r11 = r13;
                                                                                                                                                                                                                                                                    r10 = 0x33u;
                                                                                                                                                                                                                                                                    CALL(sub_3d2c);
                                                                                                                                                                                                                                                                    goto L_7738;
                                                                                                                                                                                                                                                                    L_7643:; /* 0x7643 */
                                                                                                                                                                                                                                                                    r11 = r13;
                                                                                                                                                                                                                                                                    CALL(sub_3d4c);
                                                                                                                                                                                                                                                                    goto L_7738;
                                                                                                                                                                                                                                                                    L_764d:; /* 0x764d */
                                                                                                                                                                                                                                                                    r11 = r13;
                                                                                                                                                                                                                                                                    r10 = 0x35u;
                                                                                                                                                                                                                                                                    CALL(sub_cc5);
                                                                                                                                                                                                                                                                    CALL(sub_ef7);
                                                                                                                                                                                                                                                                    CALL(sub_23fc);
                                                                                                                                                                                                                                                                    CALL(sub_189b);
                                                                                                                                                                                                                                                                    goto L_7531;
                                                                                                                                                                                                                                                                    L_7665:; /* 0x7665 */
                                                                                                                                                                                                                                                                    r9 = 0x24u;
                                                                                                                                                                                                                                                                    r10 = d32(r9);
                                                                                                                                                                                                                                                                    CALL(sub_114);
                                                                                                                                                                                                                                                                    CALL(sub_a26);
                                                                                                                                                                                                                                                                    r15 = 0;
                                                                                                                                                                                                                                                                    r9 = 0x10c00u;
                                                                                                                                                                                                                                                                    iowr(r9, r15);
                                                                                                                                                                                                                                                                    r9 = 0x9ecu;
                                                                                                                                                                                                                                                                    r0 = 0x1u;
                                                                                                                                                                                                                                                                    s32(r9, r0);
                                                                                                                                                                                                                                                                    r9 = 0x9f0u;
                                                                                                                                                                                                                                                                    s32(r9, r0);
                                                                                                                                                                                                                                                                    CALL(sub_a69);
                                                                                                                                                                                                                                                                    r9 = 0x24u;
                                                                                                                                                                                                                                                                    r11 = d32(r9);
                                                                                                                                                                                                                                                                    r10 = 0x21u;
                                                                                                                                                                                                                                                                    CALL(sub_cc5);
                                                                                                                                                                                                                                                                    CALL(sub_23fc);
                                                                                                                                                                                                                                                                    r10 = 0x36u;
                                                                                                                                                                                                                                                                    r11 = 0;
                                                                                                                                                                                                                                                                    CALL(sub_49a6);
                                                                                                                                                                                                                                                                    r10 = 0x36u;
                                                                                                                                                                                                                                                                    r11 = 0;
                                                                                                                                                                                                                                                                    CALL(sub_4c2b);
                                                                                                                                                                                                                                                                    r10 = 0x36u;
                                                                                                                                                                                                                                                                    r11 = 0;
                                                                                                                                                                                                                                                                    CALL(sub_29e6);
                                                                                                                                                                                                                                                                    r10 = 0x36u;
                                                                                                                                                                                                                                                                    r11 = 0;
                                                                                                                                                                                                                                                                    CALL(sub_2514);
                                                                                                                                                                                                                                                                    r11 = r0;
                                                                                                                                                                                                                                                                    r10 = 0x36u;
                                                                                                                                                                                                                                                                    CALL(sub_1bec);
                                                                                                                                                                                                                                                                    r9 = 0x1614u;
                                                                                                                                                                                                                                                                    r15 = d32(r9);
                                                                                                                                                                                                                                                                    r9 = 0x20400u;
                                                                                                                                                                                                                                                                    iowr(r9, r15);
                                                                                                                                                                                                                                                                    r10 = 0x32u;
                                                                                                                                                                                                                                                                    r11 = 0;
                                                                                                                                                                                                                                                                    CALL(sub_242a);
                                                                                                                                                                                                                                                                    r15 = 0x36u;
                                                                                                                                                                                                                                                                    goto L_7505;
                                                                                                                                                                                                                                                                    L_76e1:; /* 0x76e1 */
                                                                                                                                                                                                                                                                    CALL(sub_70e5);
                                                                                                                                                                                                                                                                    r15 = 0x1u;
                                                                                                                                                                                                                                                                    r9 = 0x2c300u;
                                                                                                                                                                                                                                                                    goto L_7509;
                                                                                                                                                                                                                                                                    L_76ef:; /* 0x76ef */
                                                                                                                                                                                                                                                                    r9 = 0x12ccu;
                                                                                                                                                                                                                                                                    r11 = r13;
                                                                                                                                                                                                                                                                    r0 = 0x1u;
                                                                                                                                                                                                                                                                    s32(r9, r0);
                                                                                                                                                                                                                                                                    CALL(sub_cc5);
                                                                                                                                                                                                                                                                    CALL(sub_23fc);
                                                                                                                                                                                                                                                                    r9 = 0x20100u;
                                                                                                                                                                                                                                                                    iowr(r9, r0);
                                                                                                                                                                                                                                                                    goto L_7738;
                                                                                                                                                                                                                                                                    L_770c:; /* 0x770c */
                                                                                                                                                                                                                                                                    r15 = 0;
                                                                                                                                                                                                                                                                    r9 = 0x12ccu;
                                                                                                                                                                                                                                                                    r11 = r13;
                                                                                                                                                                                                                                                                    s32(r9, r15);
                                                                                                                                                                                                                                                                    CALL(sub_cc5);
                                                                                                                                                                                                                                                                    CALL(sub_23fc);
                                                                                                                                                                                                                                                                    r15 = 0x1u;
                                                                                                                                                                                                                                                                    r9 = 0x20100u;
                                                                                                                                                                                                                                                                    goto L_7509;
                                                                                                                                                                                                                                                                    L_7728:; /* 0x7728 */
                                                                                                                                                                                                                                                                    r10 = r13;
                                                                                                                                                                                                                                                                    CALL(sub_7260);
                                                                                                                                                                                                                                                                    goto L_7738;
                                                                                                                                                                                                                                                                    L_7732:; /* 0x7732 */
                                                                                                                                                                                                                                                                    r10 = 0x9u;
                                                                                                                                                                                                                                                                    L_7734:; /* 0x7734 */
                                                                                                                                                                                                                                                                    CALL(sub_5c0);
                                                                                                                                                                                                                                                                    L_7738:; /* 0x7738 */
                                                                                                                                                                                                                                                                    CALL(sub_4010);
                                                                                                                                                                                                                                                                    L_773c:; /* 0x773c */
                                                                                                                                                                                                                                                                    r15 = 0x8u;
                                                                                                                                                                                                                                                                    r9 = 0x21800u;
                                                                                                                                                                                                                                                                    iowr(r9, r15);
                                                                                                                                                                                                                                                                    for (int i = 0; i <= 1; i++) r[i] = pop32();
                                                                                                                                                                                                                                                                    return;
                                                                                                                                                                                                                                                                }
                                                                                                                                                                                                                                                                goto L_7734;  /* 重复引用 */
                                                                                                                                                                                                                                                                goto L_76e1;  /* 重复引用 */
                                                                                                                                                                                                                                                            }
                                                                                                                                                                                                                                                            goto L_7732;  /* 重复引用 */
                                                                                                                                                                                                                                                            goto L_7485;  /* 重复引用 */
                                                                                                                                                                                                                                                            goto L_76e1;  /* 重复引用 */
                                                                                                                                                                                                                                                        }
                                                                                                                                                                                                                                                        goto L_7510;  /* 重复引用 */
                                                                                                                                                                                                                                                        goto L_747c;  /* 重复引用 */
                                                                                                                                                                                                                                                        goto L_7485;  /* 重复引用 */
                                                                                                                                                                                                                                                        goto L_7510;  /* 重复引用 */
                                                                                                                                                                                                                                                        goto L_76e1;  /* 重复引用 */
                                                                                                                                                                                                                                                    }
                                                                                                                                                                                                                                                    goto L_7738;  /* 重复引用 */
                                                                                                                                                                                                                                                    goto L_770c;  /* 重复引用 */
                                                                                                                                                                                                                                                }
                                                                                                                                                                                                                                                goto L_7732;  /* 重复引用 */
                                                                                                                                                                                                                                                goto L_7465;  /* 重复引用 */
                                                                                                                                                                                                                                                goto L_770c;  /* 重复引用 */
                                                                                                                                                                                                                                            }
                                                                                                                                                                                                                                            goto L_76ef;  /* 重复引用 */
                                                                                                                                                                                                                                            goto L_7460;  /* 重复引用 */
                                                                                                                                                                                                                                            goto L_7465;  /* 重复引用 */
                                                                                                                                                                                                                                            goto L_76ef;  /* 重复引用 */
                                                                                                                                                                                                                                            goto L_770c;  /* 重复引用 */
                                                                                                                                                                                                                                        }
                                                                                                                                                                                                                                        goto L_7469;  /* 重复引用 */
                                                                                                                                                                                                                                        goto L_745b;  /* 重复引用 */
                                                                                                                                                                                                                                        goto L_7460;  /* 重复引用 */
                                                                                                                                                                                                                                        goto L_7465;  /* 重复引用 */
                                                                                                                                                                                                                                        goto L_7469;  /* 重复引用 */
                                                                                                                                                                                                                                        goto L_7473;  /* 重复引用 */
                                                                                                                                                                                                                                        goto L_747c;  /* 重复引用 */
                                                                                                                                                                                                                                        goto L_7485;  /* 重复引用 */
                                                                                                                                                                                                                                        goto L_7510;  /* 重复引用 */
                                                                                                                                                                                                                                        goto L_76e1;  /* 重复引用 */
                                                                                                                                                                                                                                        goto L_76ef;  /* 重复引用 */
                                                                                                                                                                                                                                        goto L_770c;  /* 重复引用 */
                                                                                                                                                                                                                                    }
                                                                                                                                                                                                                                    goto L_7728;  /* 重复引用 */
                                                                                                                                                                                                                                    goto L_74f9;  /* 重复引用 */
                                                                                                                                                                                                                                }
                                                                                                                                                                                                                                goto L_7732;  /* 重复引用 */
                                                                                                                                                                                                                                goto L_744b;  /* 重复引用 */
                                                                                                                                                                                                                                goto L_74f9;  /* 重复引用 */
                                                                                                                                                                                                                            }
                                                                                                                                                                                                                            goto L_7547;  /* 重复引用 */
                                                                                                                                                                                                                            goto L_754f;  /* 重复引用 */
                                                                                                                                                                                                                        }
                                                                                                                                                                                                                        goto L_7732;  /* 重复引用 */
                                                                                                                                                                                                                        goto L_743d;  /* 重复引用 */
                                                                                                                                                                                                                        goto L_754f;  /* 重复引用 */
                                                                                                                                                                                                                    }
                                                                                                                                                                                                                    goto L_753f;  /* 重复引用 */
                                                                                                                                                                                                                    goto L_7438;  /* 重复引用 */
                                                                                                                                                                                                                    goto L_743d;  /* 重复引用 */
                                                                                                                                                                                                                    goto L_753f;  /* 重复引用 */
                                                                                                                                                                                                                    goto L_754f;  /* 重复引用 */
                                                                                                                                                                                                                }
                                                                                                                                                                                                                goto L_7441;  /* 重复引用 */
                                                                                                                                                                                                                goto L_7433;  /* 重复引用 */
                                                                                                                                                                                                                goto L_7438;  /* 重复引用 */
                                                                                                                                                                                                                goto L_743d;  /* 重复引用 */
                                                                                                                                                                                                                goto L_7441;  /* 重复引用 */
                                                                                                                                                                                                                goto L_7446;  /* 重复引用 */
                                                                                                                                                                                                                goto L_744b;  /* 重复引用 */
                                                                                                                                                                                                                goto L_74f9;  /* 重复引用 */
                                                                                                                                                                                                                goto L_753f;  /* 重复引用 */
                                                                                                                                                                                                                goto L_7547;  /* 重复引用 */
                                                                                                                                                                                                                goto L_754f;  /* 重复引用 */
                                                                                                                                                                                                            }
                                                                                                                                                                                                            goto L_7537;  /* 重复引用 */
                                                                                                                                                                                                            goto L_742c;  /* 重复引用 */
                                                                                                                                                                                                            goto L_7433;  /* 重复引用 */
                                                                                                                                                                                                            goto L_7438;  /* 重复引用 */
                                                                                                                                                                                                            goto L_743d;  /* 重复引用 */
                                                                                                                                                                                                            goto L_7441;  /* 重复引用 */
                                                                                                                                                                                                            goto L_7446;  /* 重复引用 */
                                                                                                                                                                                                            goto L_744b;  /* 重复引用 */
                                                                                                                                                                                                            goto L_74f9;  /* 重复引用 */
                                                                                                                                                                                                            goto L_7537;  /* 重复引用 */
                                                                                                                                                                                                            goto L_753f;  /* 重复引用 */
                                                                                                                                                                                                            goto L_7547;  /* 重复引用 */
                                                                                                                                                                                                            goto L_754f;  /* 重复引用 */
                                                                                                                                                                                                        }
                                                                                                                                                                                                        goto L_7738;  /* 重复引用 */
                                                                                                                                                                                                        goto L_7427;  /* 重复引用 */
                                                                                                                                                                                                        goto L_742c;  /* 重复引用 */
                                                                                                                                                                                                        goto L_7433;  /* 重复引用 */
                                                                                                                                                                                                        goto L_7438;  /* 重复引用 */
                                                                                                                                                                                                        goto L_743d;  /* 重复引用 */
                                                                                                                                                                                                        goto L_7441;  /* 重复引用 */
                                                                                                                                                                                                        goto L_7446;  /* 重复引用 */
                                                                                                                                                                                                        goto L_744b;  /* 重复引用 */
                                                                                                                                                                                                        goto L_74f9;  /* 重复引用 */
                                                                                                                                                                                                        goto L_7537;  /* 重复引用 */
                                                                                                                                                                                                        goto L_753f;  /* 重复引用 */
                                                                                                                                                                                                        goto L_7547;  /* 重复引用 */
                                                                                                                                                                                                        goto L_754f;  /* 重复引用 */
                                                                                                                                                                                                    }
                                                                                                                                                                                                    goto L_744f;  /* 重复引用 */
                                                                                                                                                                                                    goto L_7523;  /* 重复引用 */
                                                                                                                                                                                                }
                                                                                                                                                                                                goto L_7732;  /* 重复引用 */
                                                                                                                                                                                                goto L_7414;  /* 重复引用 */
                                                                                                                                                                                                goto L_7523;  /* 重复引用 */
                                                                                                                                                                                            }
                                                                                                                                                                                            goto L_764d;  /* 重复引用 */
                                                                                                                                                                                            goto L_740f;  /* 重复引用 */
                                                                                                                                                                                            goto L_7414;  /* 重复引用 */
                                                                                                                                                                                            goto L_7523;  /* 重复引用 */
                                                                                                                                                                                            goto L_764d;  /* 重复引用 */
                                                                                                                                                                                        }
                                                                                                                                                                                        goto L_7665;  /* 重复引用 */
                                                                                                                                                                                        goto L_7637;  /* 重复引用 */
                                                                                                                                                                                    }
                                                                                                                                                                                    goto L_7732;  /* 重复引用 */
                                                                                                                                                                                    goto L_73ff;  /* 重复引用 */
                                                                                                                                                                                    goto L_7637;  /* 重复引用 */
                                                                                                                                                                                }
                                                                                                                                                                                goto L_762d;  /* 重复引用 */
                                                                                                                                                                                goto L_73fa;  /* 重复引用 */
                                                                                                                                                                                goto L_73ff;  /* 重复引用 */
                                                                                                                                                                                goto L_762d;  /* 重复引用 */
                                                                                                                                                                                goto L_7637;  /* 重复引用 */
                                                                                                                                                                            }
                                                                                                                                                                            goto L_7403;  /* 重复引用 */
                                                                                                                                                                            goto L_73f5;  /* 重复引用 */
                                                                                                                                                                            goto L_73fa;  /* 重复引用 */
                                                                                                                                                                            goto L_73ff;  /* 重复引用 */
                                                                                                                                                                            goto L_7403;  /* 重复引用 */
                                                                                                                                                                            goto L_7408;  /* 重复引用 */
                                                                                                                                                                            goto L_740f;  /* 重复引用 */
                                                                                                                                                                            goto L_7414;  /* 重复引用 */
                                                                                                                                                                            goto L_7523;  /* 重复引用 */
                                                                                                                                                                            goto L_762d;  /* 重复引用 */
                                                                                                                                                                            goto L_7637;  /* 重复引用 */
                                                                                                                                                                            goto L_764d;  /* 重复引用 */
                                                                                                                                                                            goto L_7665;  /* 重复引用 */
                                                                                                                                                                        }
                                                                                                                                                                        goto L_7643;  /* 重复引用 */
                                                                                                                                                                        goto L_7557;  /* 重复引用 */
                                                                                                                                                                        goto L_7566;  /* 重复引用 */
                                                                                                                                                                    }
                                                                                                                                                                    goto L_7732;  /* 重复引用 */
                                                                                                                                                                    goto L_73e6;  /* 重复引用 */
                                                                                                                                                                    goto L_7557;  /* 重复引用 */
                                                                                                                                                                    goto L_7566;  /* 重复引用 */
                                                                                                                                                                }
                                                                                                                                                                goto L_7617;  /* 重复引用 */
                                                                                                                                                                goto L_73e1;  /* 重复引用 */
                                                                                                                                                                goto L_73e6;  /* 重复引用 */
                                                                                                                                                                goto L_7557;  /* 重复引用 */
                                                                                                                                                                goto L_7566;  /* 重复引用 */
                                                                                                                                                                goto L_7617;  /* 重复引用 */
                                                                                                                                                            }
                                                                                                                                                            goto L_756a;  /* 重复引用 */
                                                                                                                                                            goto L_73da;  /* 重复引用 */
                                                                                                                                                            goto L_73e1;  /* 重复引用 */
                                                                                                                                                            goto L_73e6;  /* 重复引用 */
                                                                                                                                                            goto L_7557;  /* 重复引用 */
                                                                                                                                                            goto L_7566;  /* 重复引用 */
                                                                                                                                                            goto L_756a;  /* 重复引用 */
                                                                                                                                                            goto L_7617;  /* 重复引用 */
                                                                                                                                                        }
                                                                                                                                                        goto L_7738;  /* 重复引用 */
                                                                                                                                                        goto L_73d5;  /* 重复引用 */
                                                                                                                                                        goto L_73da;  /* 重复引用 */
                                                                                                                                                        goto L_73e1;  /* 重复引用 */
                                                                                                                                                        goto L_73e6;  /* 重复引用 */
                                                                                                                                                        goto L_7557;  /* 重复引用 */
                                                                                                                                                        goto L_7566;  /* 重复引用 */
                                                                                                                                                        goto L_756a;  /* 重复引用 */
                                                                                                                                                        goto L_7617;  /* 重复引用 */
                                                                                                                                                    }
                                                                                                                                                    goto L_757b;  /* 重复引用 */
                                                                                                                                                    goto L_73ce;  /* 重复引用 */
                                                                                                                                                    goto L_73d5;  /* 重复引用 */
                                                                                                                                                    goto L_73da;  /* 重复引用 */
                                                                                                                                                    goto L_73e1;  /* 重复引用 */
                                                                                                                                                    goto L_73e6;  /* 重复引用 */
                                                                                                                                                    goto L_7557;  /* 重复引用 */
                                                                                                                                                    goto L_7566;  /* 重复引用 */
                                                                                                                                                    goto L_756a;  /* 重复引用 */
                                                                                                                                                    goto L_757b;  /* 重复引用 */
                                                                                                                                                    goto L_7617;  /* 重复引用 */
                                                                                                                                                }
                                                                                                                                                goto L_73ea;  /* 重复引用 */
                                                                                                                                                goto L_73c9;  /* 重复引用 */
                                                                                                                                                goto L_73ce;  /* 重复引用 */
                                                                                                                                                goto L_73d5;  /* 重复引用 */
                                                                                                                                                goto L_73da;  /* 重复引用 */
                                                                                                                                                goto L_73e1;  /* 重复引用 */
                                                                                                                                                goto L_73e6;  /* 重复引用 */
                                                                                                                                                goto L_73ea;  /* 重复引用 */
                                                                                                                                                goto L_73ef;  /* 重复引用 */
                                                                                                                                                goto L_73f5;  /* 重复引用 */
                                                                                                                                                goto L_73fa;  /* 重复引用 */
                                                                                                                                                goto L_73ff;  /* 重复引用 */
                                                                                                                                                goto L_7403;  /* 重复引用 */
                                                                                                                                                goto L_7408;  /* 重复引用 */
                                                                                                                                                goto L_740f;  /* 重复引用 */
                                                                                                                                                goto L_7414;  /* 重复引用 */
                                                                                                                                                goto L_7523;  /* 重复引用 */
                                                                                                                                                goto L_7557;  /* 重复引用 */
                                                                                                                                                goto L_7566;  /* 重复引用 */
                                                                                                                                                goto L_756a;  /* 重复引用 */
                                                                                                                                                goto L_757b;  /* 重复引用 */
                                                                                                                                                goto L_7617;  /* 重复引用 */
                                                                                                                                                goto L_762d;  /* 重复引用 */
                                                                                                                                                goto L_7637;  /* 重复引用 */
                                                                                                                                                goto L_7643;  /* 重复引用 */
                                                                                                                                                goto L_764d;  /* 重复引用 */
                                                                                                                                                goto L_7665;  /* 重复引用 */
                                                                                                                                            }
                                                                                                                                            goto L_7623;  /* 重复引用 */
                                                                                                                                            goto L_73c3;  /* 重复引用 */
                                                                                                                                            goto L_73c9;  /* 重复引用 */
                                                                                                                                            goto L_73ce;  /* 重复引用 */
                                                                                                                                            goto L_73d5;  /* 重复引用 */
                                                                                                                                            goto L_73da;  /* 重复引用 */
                                                                                                                                            goto L_73e1;  /* 重复引用 */
                                                                                                                                            goto L_73e6;  /* 重复引用 */
                                                                                                                                            goto L_73ea;  /* 重复引用 */
                                                                                                                                            goto L_73ef;  /* 重复引用 */
                                                                                                                                            goto L_73f5;  /* 重复引用 */
                                                                                                                                            goto L_73fa;  /* 重复引用 */
                                                                                                                                            goto L_73ff;  /* 重复引用 */
                                                                                                                                            goto L_7403;  /* 重复引用 */
                                                                                                                                            goto L_7408;  /* 重复引用 */
                                                                                                                                            goto L_740f;  /* 重复引用 */
                                                                                                                                            goto L_7414;  /* 重复引用 */
                                                                                                                                            goto L_7523;  /* 重复引用 */
                                                                                                                                            goto L_7557;  /* 重复引用 */
                                                                                                                                            goto L_7566;  /* 重复引用 */
                                                                                                                                            goto L_756a;  /* 重复引用 */
                                                                                                                                            goto L_757b;  /* 重复引用 */
                                                                                                                                            goto L_7617;  /* 重复引用 */
                                                                                                                                            goto L_7623;  /* 重复引用 */
                                                                                                                                            goto L_762d;  /* 重复引用 */
                                                                                                                                            goto L_7637;  /* 重复引用 */
                                                                                                                                            goto L_7643;  /* 重复引用 */
                                                                                                                                            goto L_764d;  /* 重复引用 */
                                                                                                                                            goto L_7665;  /* 重复引用 */
                                                                                                                                        }
                                                                                                                                        goto L_7418;  /* 重复引用 */
                                                                                                                                        goto L_73be;  /* 重复引用 */
                                                                                                                                        goto L_73c3;  /* 重复引用 */
                                                                                                                                        goto L_73c9;  /* 重复引用 */
                                                                                                                                        goto L_73ce;  /* 重复引用 */
                                                                                                                                        goto L_73d5;  /* 重复引用 */
                                                                                                                                        goto L_73da;  /* 重复引用 */
                                                                                                                                        goto L_73e1;  /* 重复引用 */
                                                                                                                                        goto L_73e6;  /* 重复引用 */
                                                                                                                                        goto L_73ea;  /* 重复引用 */
                                                                                                                                        goto L_73ef;  /* 重复引用 */
                                                                                                                                        goto L_73f5;  /* 重复引用 */
                                                                                                                                        goto L_73fa;  /* 重复引用 */
                                                                                                                                        goto L_73ff;  /* 重复引用 */
                                                                                                                                        goto L_7403;  /* 重复引用 */
                                                                                                                                        goto L_7408;  /* 重复引用 */
                                                                                                                                        goto L_740f;  /* 重复引用 */
                                                                                                                                        goto L_7414;  /* 重复引用 */
                                                                                                                                        goto L_7418;  /* 重复引用 */
                                                                                                                                        goto L_741f;  /* 重复引用 */
                                                                                                                                        goto L_7427;  /* 重复引用 */
                                                                                                                                        goto L_742c;  /* 重复引用 */
                                                                                                                                        goto L_7433;  /* 重复引用 */
                                                                                                                                        goto L_7438;  /* 重复引用 */
                                                                                                                                        goto L_743d;  /* 重复引用 */
                                                                                                                                        goto L_7441;  /* 重复引用 */
                                                                                                                                        goto L_7446;  /* 重复引用 */
                                                                                                                                        goto L_744b;  /* 重复引用 */
                                                                                                                                        goto L_744f;  /* 重复引用 */
                                                                                                                                        goto L_7454;  /* 重复引用 */
                                                                                                                                        goto L_745b;  /* 重复引用 */
                                                                                                                                        goto L_7460;  /* 重复引用 */
                                                                                                                                        goto L_7465;  /* 重复引用 */
                                                                                                                                        goto L_7469;  /* 重复引用 */
                                                                                                                                        goto L_7473;  /* 重复引用 */
                                                                                                                                        goto L_747c;  /* 重复引用 */
                                                                                                                                        goto L_7485;  /* 重复引用 */
                                                                                                                                        goto L_74f9;  /* 重复引用 */
                                                                                                                                        goto L_7510;  /* 重复引用 */
                                                                                                                                        goto L_7523;  /* 重复引用 */
                                                                                                                                        goto L_7537;  /* 重复引用 */
                                                                                                                                        goto L_753f;  /* 重复引用 */
                                                                                                                                        goto L_7547;  /* 重复引用 */
                                                                                                                                        goto L_754f;  /* 重复引用 */
                                                                                                                                        goto L_7557;  /* 重复引用 */
                                                                                                                                        goto L_7566;  /* 重复引用 */
                                                                                                                                        goto L_756a;  /* 重复引用 */
                                                                                                                                        goto L_757b;  /* 重复引用 */
                                                                                                                                        goto L_7617;  /* 重复引用 */
                                                                                                                                        goto L_7623;  /* 重复引用 */
                                                                                                                                        goto L_762d;  /* 重复引用 */
                                                                                                                                        goto L_7637;  /* 重复引用 */
                                                                                                                                        goto L_7643;  /* 重复引用 */
                                                                                                                                        goto L_764d;  /* 重复引用 */
                                                                                                                                        goto L_7665;  /* 重复引用 */
                                                                                                                                        goto L_76e1;  /* 重复引用 */
                                                                                                                                        goto L_76ef;  /* 重复引用 */
                                                                                                                                        goto L_770c;  /* 重复引用 */
                                                                                                                                        goto L_7728;  /* 重复引用 */
                                                                                                                                    }
                                                                                                                                    goto L_752b;  /* 重复引用 */
                                                                                                                                    goto L_75cb;  /* 重复引用 */
                                                                                                                                }
                                                                                                                                goto L_7738;  /* 重复引用 */
                                                                                                                            }
                                                                                                                            goto L_7732;  /* 重复引用 */
                                                                                                                            goto L_73a3;  /* 重复引用 */
                                                                                                                        }
                                                                                                                        goto L_73a7;  /* 重复引用 */
                                                                                                                        goto L_739c;  /* 重复引用 */
                                                                                                                        goto L_73a3;  /* 重复引用 */
                                                                                                                        goto L_73a7;  /* 重复引用 */
                                                                                                                        goto L_73ae;  /* 重复引用 */
                                                                                                                        goto L_75cb;  /* 重复引用 */
                                                                                                                    }
                                                                                                                    goto L_74c1;  /* 重复引用 */
                                                                                                                    goto L_75a5;  /* 重复引用 */
                                                                                                                }
                                                                                                                goto L_7732;  /* 重复引用 */
                                                                                                                goto L_738d;  /* 重复引用 */
                                                                                                                goto L_75a5;  /* 重复引用 */
                                                                                                            }
                                                                                                            goto L_7531;  /* 重复引用 */
                                                                                                            goto L_7388;  /* 重复引用 */
                                                                                                            goto L_738d;  /* 重复引用 */
                                                                                                            goto L_75a5;  /* 重复引用 */
                                                                                                        }
                                                                                                        goto L_7738;  /* 重复引用 */
                                                                                                        goto L_7383;  /* 重复引用 */
                                                                                                        goto L_7388;  /* 重复引用 */
                                                                                                        goto L_738d;  /* 重复引用 */
                                                                                                        goto L_75a5;  /* 重复引用 */
                                                                                                    }
                                                                                                    goto L_7599;  /* 重复引用 */
                                                                                                    goto L_737c;  /* 重复引用 */
                                                                                                    goto L_7383;  /* 重复引用 */
                                                                                                    goto L_7388;  /* 重复引用 */
                                                                                                    goto L_738d;  /* 重复引用 */
                                                                                                    goto L_7599;  /* 重复引用 */
                                                                                                    goto L_75a5;  /* 重复引用 */
                                                                                                }
                                                                                                goto L_7391;  /* 重复引用 */
                                                                                                goto L_7375;  /* 重复引用 */
                                                                                                goto L_737c;  /* 重复引用 */
                                                                                                goto L_7383;  /* 重复引用 */
                                                                                                goto L_7388;  /* 重复引用 */
                                                                                                goto L_738d;  /* 重复引用 */
                                                                                                goto L_7391;  /* 重复引用 */
                                                                                                goto L_7396;  /* 重复引用 */
                                                                                                goto L_739c;  /* 重复引用 */
                                                                                                goto L_73a3;  /* 重复引用 */
                                                                                                goto L_73a7;  /* 重复引用 */
                                                                                                goto L_73ae;  /* 重复引用 */
                                                                                                goto L_74c1;  /* 重复引用 */
                                                                                                goto L_7599;  /* 重复引用 */
                                                                                                goto L_75a5;  /* 重复引用 */
                                                                                                goto L_75cb;  /* 重复引用 */
                                                                                            }
                                                                                            goto L_760f;  /* 重复引用 */
                                                                                            goto L_75b9;  /* 重复引用 */
                                                                                        }
                                                                                        goto L_7732;  /* 重复引用 */
                                                                                        goto L_7366;  /* 重复引用 */
                                                                                        goto L_75b9;  /* 重复引用 */
                                                                                    }
                                                                                    goto L_75de;  /* 重复引用 */
                                                                                    goto L_7361;  /* 重复引用 */
                                                                                    goto L_7366;  /* 重复引用 */
                                                                                    goto L_75b9;  /* 重复引用 */
                                                                                    goto L_75de;  /* 重复引用 */
                                                                                }
                                                                                goto L_758f;  /* 重复引用 */
                                                                                goto L_75d6;  /* 重复引用 */
                                                                            }
                                                                            goto L_7732;  /* 重复引用 */
                                                                            goto L_7351;  /* 重复引用 */
                                                                            goto L_75d6;  /* 重复引用 */
                                                                        }
                                                                        goto L_75e6;  /* 重复引用 */
                                                                        goto L_734c;  /* 重复引用 */
                                                                        goto L_7351;  /* 重复引用 */
                                                                        goto L_75d6;  /* 重复引用 */
                                                                        goto L_75e6;  /* 重复引用 */
                                                                    }
                                                                    goto L_7355;  /* 重复引用 */
                                                                    goto L_7347;  /* 重复引用 */
                                                                    goto L_734c;  /* 重复引用 */
                                                                    goto L_7351;  /* 重复引用 */
                                                                    goto L_7355;  /* 重复引用 */
                                                                    goto L_735a;  /* 重复引用 */
                                                                    goto L_7361;  /* 重复引用 */
                                                                    goto L_7366;  /* 重复引用 */
                                                                    goto L_758f;  /* 重复引用 */
                                                                    goto L_75b9;  /* 重复引用 */
                                                                    goto L_75d6;  /* 重复引用 */
                                                                    goto L_75de;  /* 重复引用 */
                                                                    goto L_75e6;  /* 重复引用 */
                                                                }
                                                                goto L_75c3;  /* 重复引用 */
                                                                goto L_74f1;  /* 重复引用 */
                                                            }
                                                            goto L_7732;  /* 重复引用 */
                                                            goto L_7338;  /* 重复引用 */
                                                            goto L_74f1;  /* 重复引用 */
                                                        }
                                                        goto L_74a9;  /* 重复引用 */
                                                        goto L_7333;  /* 重复引用 */
                                                        goto L_7338;  /* 重复引用 */
                                                        goto L_74a9;  /* 重复引用 */
                                                        goto L_74f1;  /* 重复引用 */
                                                    }
                                                    goto L_7585;  /* 重复引用 */
                                                    goto L_7489;  /* 重复引用 */
                                                }
                                                goto L_7732;  /* 重复引用 */
                                                goto L_7325;  /* 重复引用 */
                                                goto L_7489;  /* 重复引用 */
                                            }
                                            goto L_7738;  /* 重复引用 */
                                            goto L_7320;  /* 重复引用 */
                                            goto L_7325;  /* 重复引用 */
                                            goto L_7489;  /* 重复引用 */
                                        }
                                        goto L_7329;  /* 重复引用 */
                                        goto L_731b;  /* 重复引用 */
                                        goto L_7320;  /* 重复引用 */
                                        goto L_7325;  /* 重复引用 */
                                        goto L_7329;  /* 重复引用 */
                                        goto L_732e;  /* 重复引用 */
                                        goto L_7333;  /* 重复引用 */
                                        goto L_7338;  /* 重复引用 */
                                        goto L_7489;  /* 重复引用 */
                                        goto L_74a9;  /* 重复引用 */
                                        goto L_74af;  /* 重复引用 */
                                        goto L_74f1;  /* 重复引用 */
                                        goto L_7585;  /* 重复引用 */
                                    }
                                    goto L_7493;  /* 重复引用 */
                                    goto L_7315;  /* 重复引用 */
                                    goto L_731b;  /* 重复引用 */
                                    goto L_7320;  /* 重复引用 */
                                    goto L_7325;  /* 重复引用 */
                                    goto L_7329;  /* 重复引用 */
                                    goto L_732e;  /* 重复引用 */
                                    goto L_7333;  /* 重复引用 */
                                    goto L_7338;  /* 重复引用 */
                                    goto L_7489;  /* 重复引用 */
                                    goto L_7493;  /* 重复引用 */
                                    goto L_74a9;  /* 重复引用 */
                                    goto L_74af;  /* 重复引用 */
                                    goto L_74f1;  /* 重复引用 */
                                    goto L_7585;  /* 重复引用 */
                                }
                                goto L_733c;  /* 重复引用 */
                                goto L_7310;  /* 重复引用 */
                                goto L_7315;  /* 重复引用 */
                                goto L_731b;  /* 重复引用 */
                                goto L_7320;  /* 重复引用 */
                                goto L_7325;  /* 重复引用 */
                                goto L_7329;  /* 重复引用 */
                                goto L_732e;  /* 重复引用 */
                                goto L_7333;  /* 重复引用 */
                                goto L_7338;  /* 重复引用 */
                                goto L_733c;  /* 重复引用 */
                                goto L_7341;  /* 重复引用 */
                                goto L_7347;  /* 重复引用 */
                                goto L_734c;  /* 重复引用 */
                                goto L_7351;  /* 重复引用 */
                                goto L_7355;  /* 重复引用 */
                                goto L_735a;  /* 重复引用 */
                                goto L_7361;  /* 重复引用 */
                                goto L_7366;  /* 重复引用 */
                                goto L_7489;  /* 重复引用 */
                                goto L_7493;  /* 重复引用 */
                                goto L_74a9;  /* 重复引用 */
                                goto L_74af;  /* 重复引用 */
                                goto L_74f1;  /* 重复引用 */
                                goto L_7585;  /* 重复引用 */
                                goto L_758f;  /* 重复引用 */
                                goto L_75b9;  /* 重复引用 */
                                goto L_75c3;  /* 重复引用 */
                                goto L_75d6;  /* 重复引用 */
                                goto L_75de;  /* 重复引用 */
                                goto L_75e6;  /* 重复引用 */
                            }
                            goto L_74d5;  /* 重复引用 */
                            goto L_730a;  /* 重复引用 */
                            goto L_7310;  /* 重复引用 */
                            goto L_7315;  /* 重复引用 */
                            goto L_731b;  /* 重复引用 */
                            goto L_7320;  /* 重复引用 */
                            goto L_7325;  /* 重复引用 */
                            goto L_7329;  /* 重复引用 */
                            goto L_732e;  /* 重复引用 */
                            goto L_7333;  /* 重复引用 */
                            goto L_7338;  /* 重复引用 */
                            goto L_733c;  /* 重复引用 */
                            goto L_7341;  /* 重复引用 */
                            goto L_7347;  /* 重复引用 */
                            goto L_734c;  /* 重复引用 */
                            goto L_7351;  /* 重复引用 */
                            goto L_7355;  /* 重复引用 */
                            goto L_735a;  /* 重复引用 */
                            goto L_7361;  /* 重复引用 */
                            goto L_7366;  /* 重复引用 */
                            goto L_7489;  /* 重复引用 */
                            goto L_7493;  /* 重复引用 */
                            goto L_74a9;  /* 重复引用 */
                            goto L_74af;  /* 重复引用 */
                            goto L_74d5;  /* 重复引用 */
                            goto L_74f1;  /* 重复引用 */
                            goto L_7585;  /* 重复引用 */
                            goto L_758f;  /* 重复引用 */
                            goto L_75b9;  /* 重复引用 */
                            goto L_75c3;  /* 重复引用 */
                            goto L_75d6;  /* 重复引用 */
                            goto L_75de;  /* 重复引用 */
                            goto L_75e6;  /* 重复引用 */
                        }
                        goto L_7738;  /* 重复引用 */
                        goto L_7305;  /* 重复引用 */
                        goto L_730a;  /* 重复引用 */
                        goto L_7310;  /* 重复引用 */
                        goto L_7315;  /* 重复引用 */
                        goto L_731b;  /* 重复引用 */
                        goto L_7320;  /* 重复引用 */
                        goto L_7325;  /* 重复引用 */
                        goto L_7329;  /* 重复引用 */
                        goto L_732e;  /* 重复引用 */
                        goto L_7333;  /* 重复引用 */
                        goto L_7338;  /* 重复引用 */
                        goto L_733c;  /* 重复引用 */
                        goto L_7341;  /* 重复引用 */
                        goto L_7347;  /* 重复引用 */
                        goto L_734c;  /* 重复引用 */
                        goto L_7351;  /* 重复引用 */
                        goto L_7355;  /* 重复引用 */
                        goto L_735a;  /* 重复引用 */
                        goto L_7361;  /* 重复引用 */
                        goto L_7366;  /* 重复引用 */
                        goto L_7489;  /* 重复引用 */
                        goto L_7493;  /* 重复引用 */
                        goto L_74a9;  /* 重复引用 */
                        goto L_74af;  /* 重复引用 */
                        goto L_74d5;  /* 重复引用 */
                        goto L_74f1;  /* 重复引用 */
                        goto L_7585;  /* 重复引用 */
                        goto L_758f;  /* 重复引用 */
                        goto L_75b9;  /* 重复引用 */
                        goto L_75c3;  /* 重复引用 */
                        goto L_75d6;  /* 重复引用 */
                        goto L_75de;  /* 重复引用 */
                        goto L_75e6;  /* 重复引用 */
                    }
                    goto L_736a;  /* 重复引用 */
                    goto L_72fe;  /* 重复引用 */
                    goto L_7305;  /* 重复引用 */
                    goto L_730a;  /* 重复引用 */
                    goto L_7310;  /* 重复引用 */
                    goto L_7315;  /* 重复引用 */
                    goto L_731b;  /* 重复引用 */
                    goto L_7320;  /* 重复引用 */
                    goto L_7325;  /* 重复引用 */
                    goto L_7329;  /* 重复引用 */
                    goto L_732e;  /* 重复引用 */
                    goto L_7333;  /* 重复引用 */
                    goto L_7338;  /* 重复引用 */
                    goto L_733c;  /* 重复引用 */
                    goto L_7341;  /* 重复引用 */
                    goto L_7347;  /* 重复引用 */
                    goto L_734c;  /* 重复引用 */
                    goto L_7351;  /* 重复引用 */
                    goto L_7355;  /* 重复引用 */
                    goto L_735a;  /* 重复引用 */
                    goto L_7361;  /* 重复引用 */
                    goto L_7366;  /* 重复引用 */
                    goto L_736a;  /* 重复引用 */
                    goto L_736f;  /* 重复引用 */
                    goto L_7375;  /* 重复引用 */
                    goto L_737c;  /* 重复引用 */
                    goto L_7383;  /* 重复引用 */
                    goto L_7388;  /* 重复引用 */
                    goto L_738d;  /* 重复引用 */
                    goto L_7391;  /* 重复引用 */
                    goto L_7396;  /* 重复引用 */
                    goto L_739c;  /* 重复引用 */
                    goto L_73a3;  /* 重复引用 */
                    goto L_73a7;  /* 重复引用 */
                    goto L_73ae;  /* 重复引用 */
                    goto L_7489;  /* 重复引用 */
                    goto L_7493;  /* 重复引用 */
                    goto L_74a9;  /* 重复引用 */
                    goto L_74af;  /* 重复引用 */
                    goto L_74c1;  /* 重复引用 */
                    goto L_74d5;  /* 重复引用 */
                    goto L_74f1;  /* 重复引用 */
                    goto L_7585;  /* 重复引用 */
                    goto L_758f;  /* 重复引用 */
                    goto L_7599;  /* 重复引用 */
                    goto L_75a5;  /* 重复引用 */
                    goto L_75b9;  /* 重复引用 */
                    goto L_75c3;  /* 重复引用 */
                    goto L_75cb;  /* 重复引用 */
                    goto L_75d6;  /* 重复引用 */
                    goto L_75de;  /* 重复引用 */
                    goto L_75e6;  /* 重复引用 */
                    goto L_760f;  /* 重复引用 */
                }
                goto L_73b2;  /* 重复引用 */
                goto L_72f8;  /* 重复引用 */
                goto L_72fe;  /* 重复引用 */
                goto L_7305;  /* 重复引用 */
                goto L_730a;  /* 重复引用 */
                goto L_7310;  /* 重复引用 */
                goto L_7315;  /* 重复引用 */
                goto L_731b;  /* 重复引用 */
                goto L_7320;  /* 重复引用 */
                goto L_7325;  /* 重复引用 */
                goto L_7329;  /* 重复引用 */
                goto L_732e;  /* 重复引用 */
                goto L_7333;  /* 重复引用 */
                goto L_7338;  /* 重复引用 */
                goto L_733c;  /* 重复引用 */
                goto L_7341;  /* 重复引用 */
                goto L_7347;  /* 重复引用 */
                goto L_734c;  /* 重复引用 */
                goto L_7351;  /* 重复引用 */
                goto L_7355;  /* 重复引用 */
                goto L_735a;  /* 重复引用 */
                goto L_7361;  /* 重复引用 */
                goto L_7366;  /* 重复引用 */
                goto L_736a;  /* 重复引用 */
                goto L_736f;  /* 重复引用 */
                goto L_7375;  /* 重复引用 */
                goto L_737c;  /* 重复引用 */
                goto L_7383;  /* 重复引用 */
                goto L_7388;  /* 重复引用 */
                goto L_738d;  /* 重复引用 */
                goto L_7391;  /* 重复引用 */
                goto L_7396;  /* 重复引用 */
                goto L_739c;  /* 重复引用 */
                goto L_73a3;  /* 重复引用 */
                goto L_73a7;  /* 重复引用 */
                goto L_73ae;  /* 重复引用 */
                goto L_73b2;  /* 重复引用 */
                goto L_73b7;  /* 重复引用 */
                goto L_73be;  /* 重复引用 */
                goto L_73c3;  /* 重复引用 */
                goto L_73c9;  /* 重复引用 */
                goto L_73ce;  /* 重复引用 */
                goto L_73d5;  /* 重复引用 */
                goto L_73da;  /* 重复引用 */
                goto L_73e1;  /* 重复引用 */
                goto L_73e6;  /* 重复引用 */
                goto L_73ea;  /* 重复引用 */
                goto L_73ef;  /* 重复引用 */
                goto L_73f5;  /* 重复引用 */
                goto L_73fa;  /* 重复引用 */
                goto L_73ff;  /* 重复引用 */
                goto L_7403;  /* 重复引用 */
                goto L_7408;  /* 重复引用 */
                goto L_740f;  /* 重复引用 */
                goto L_7414;  /* 重复引用 */
                goto L_7418;  /* 重复引用 */
                goto L_741f;  /* 重复引用 */
                goto L_7427;  /* 重复引用 */
                goto L_742c;  /* 重复引用 */
                goto L_7433;  /* 重复引用 */
                goto L_7438;  /* 重复引用 */
                goto L_743d;  /* 重复引用 */
                goto L_7441;  /* 重复引用 */
                goto L_7446;  /* 重复引用 */
                goto L_744b;  /* 重复引用 */
                goto L_744f;  /* 重复引用 */
                goto L_7454;  /* 重复引用 */
                goto L_745b;  /* 重复引用 */
                goto L_7460;  /* 重复引用 */
                goto L_7465;  /* 重复引用 */
                goto L_7469;  /* 重复引用 */
                goto L_7473;  /* 重复引用 */
                goto L_747c;  /* 重复引用 */
                goto L_7485;  /* 重复引用 */
                goto L_7489;  /* 重复引用 */
                goto L_7493;  /* 重复引用 */
                goto L_74a9;  /* 重复引用 */
                goto L_74af;  /* 重复引用 */
                goto L_74c1;  /* 重复引用 */
                goto L_74d5;  /* 重复引用 */
                goto L_74f1;  /* 重复引用 */
                goto L_74f9;  /* 重复引用 */
                goto L_74ff;  /* 重复引用 */
                goto L_7505;  /* 重复引用 */
                goto L_7509;  /* 重复引用 */
                goto L_7510;  /* 重复引用 */
                goto L_7523;  /* 重复引用 */
                goto L_752b;  /* 重复引用 */
                goto L_752f;  /* 重复引用 */
                goto L_7531;  /* 重复引用 */
                goto L_7537;  /* 重复引用 */
                goto L_753f;  /* 重复引用 */
                goto L_7547;  /* 重复引用 */
                goto L_754f;  /* 重复引用 */
                goto L_7557;  /* 重复引用 */
                goto L_7566;  /* 重复引用 */
                goto L_756a;  /* 重复引用 */
                goto L_757b;  /* 重复引用 */
                goto L_7585;  /* 重复引用 */
                goto L_758f;  /* 重复引用 */
                goto L_7599;  /* 重复引用 */
                goto L_75a5;  /* 重复引用 */
                goto L_75b9;  /* 重复引用 */
                goto L_75c3;  /* 重复引用 */
                goto L_75cb;  /* 重复引用 */
                goto L_75d6;  /* 重复引用 */
                goto L_75de;  /* 重复引用 */
                goto L_75e6;  /* 重复引用 */
                goto L_760f;  /* 重复引用 */
                goto L_7617;  /* 重复引用 */
                goto L_7623;  /* 重复引用 */
                goto L_762d;  /* 重复引用 */
                goto L_7637;  /* 重复引用 */
                goto L_7643;  /* 重复引用 */
                goto L_764d;  /* 重复引用 */
                goto L_7665;  /* 重复引用 */
                goto L_76e1;  /* 重复引用 */
                goto L_76ef;  /* 重复引用 */
                goto L_770c;  /* 重复引用 */
                goto L_7728;  /* 重复引用 */
                goto L_7732;  /* 重复引用 */
                goto L_7734;  /* 重复引用 */
            }
            goto L_75af;  /* 重复引用 */
        }
        goto L_72e5;  /* 重复引用 */
        goto L_72e3;  /* 重复引用 */
        goto L_72e5;  /* 重复引用 */
        goto L_72f1;  /* 重复引用 */
        goto L_72f8;  /* 重复引用 */
        goto L_72fe;  /* 重复引用 */
        goto L_7305;  /* 重复引用 */
        goto L_730a;  /* 重复引用 */
        goto L_7310;  /* 重复引用 */
        goto L_7315;  /* 重复引用 */
        goto L_731b;  /* 重复引用 */
        goto L_7320;  /* 重复引用 */
        goto L_7325;  /* 重复引用 */
        goto L_7329;  /* 重复引用 */
        goto L_732e;  /* 重复引用 */
        goto L_7333;  /* 重复引用 */
        goto L_7338;  /* 重复引用 */
        goto L_733c;  /* 重复引用 */
        goto L_7341;  /* 重复引用 */
        goto L_7347;  /* 重复引用 */
        goto L_734c;  /* 重复引用 */
        goto L_7351;  /* 重复引用 */
        goto L_7355;  /* 重复引用 */
        goto L_735a;  /* 重复引用 */
        goto L_7361;  /* 重复引用 */
        goto L_7366;  /* 重复引用 */
        goto L_736a;  /* 重复引用 */
        goto L_736f;  /* 重复引用 */
        goto L_7375;  /* 重复引用 */
        goto L_737c;  /* 重复引用 */
        goto L_7383;  /* 重复引用 */
        goto L_7388;  /* 重复引用 */
        goto L_738d;  /* 重复引用 */
        goto L_7391;  /* 重复引用 */
        goto L_7396;  /* 重复引用 */
        goto L_739c;  /* 重复引用 */
        goto L_73a3;  /* 重复引用 */
        goto L_73a7;  /* 重复引用 */
        goto L_73ae;  /* 重复引用 */
        goto L_73b2;  /* 重复引用 */
        goto L_73b7;  /* 重复引用 */
        goto L_73be;  /* 重复引用 */
        goto L_73c3;  /* 重复引用 */
        goto L_73c9;  /* 重复引用 */
        goto L_73ce;  /* 重复引用 */
        goto L_73d5;  /* 重复引用 */
        goto L_73da;  /* 重复引用 */
        goto L_73e1;  /* 重复引用 */
        goto L_73e6;  /* 重复引用 */
        goto L_73ea;  /* 重复引用 */
        goto L_73ef;  /* 重复引用 */
        goto L_73f5;  /* 重复引用 */
        goto L_73fa;  /* 重复引用 */
        goto L_73ff;  /* 重复引用 */
        goto L_7403;  /* 重复引用 */
        goto L_7408;  /* 重复引用 */
        goto L_740f;  /* 重复引用 */
        goto L_7414;  /* 重复引用 */
        goto L_7418;  /* 重复引用 */
        goto L_741f;  /* 重复引用 */
        goto L_7427;  /* 重复引用 */
        goto L_742c;  /* 重复引用 */
        goto L_7433;  /* 重复引用 */
        goto L_7438;  /* 重复引用 */
        goto L_743d;  /* 重复引用 */
        goto L_7441;  /* 重复引用 */
        goto L_7446;  /* 重复引用 */
        goto L_744b;  /* 重复引用 */
        goto L_744f;  /* 重复引用 */
        goto L_7454;  /* 重复引用 */
        goto L_745b;  /* 重复引用 */
        goto L_7460;  /* 重复引用 */
        goto L_7465;  /* 重复引用 */
        goto L_7469;  /* 重复引用 */
        goto L_7473;  /* 重复引用 */
        goto L_747c;  /* 重复引用 */
        goto L_7485;  /* 重复引用 */
        goto L_7489;  /* 重复引用 */
        goto L_7493;  /* 重复引用 */
        goto L_74a9;  /* 重复引用 */
        goto L_74af;  /* 重复引用 */
        goto L_74c1;  /* 重复引用 */
        goto L_74d5;  /* 重复引用 */
        goto L_74f1;  /* 重复引用 */
        goto L_74f9;  /* 重复引用 */
        goto L_74ff;  /* 重复引用 */
        goto L_7505;  /* 重复引用 */
        goto L_7509;  /* 重复引用 */
        goto L_7510;  /* 重复引用 */
        goto L_7523;  /* 重复引用 */
        goto L_752b;  /* 重复引用 */
        goto L_752f;  /* 重复引用 */
        goto L_7531;  /* 重复引用 */
        goto L_7537;  /* 重复引用 */
        goto L_753f;  /* 重复引用 */
        goto L_7547;  /* 重复引用 */
        goto L_754f;  /* 重复引用 */
        goto L_7557;  /* 重复引用 */
        goto L_7566;  /* 重复引用 */
        goto L_756a;  /* 重复引用 */
        goto L_757b;  /* 重复引用 */
        goto L_7585;  /* 重复引用 */
        goto L_758f;  /* 重复引用 */
        goto L_7599;  /* 重复引用 */
        goto L_75a5;  /* 重复引用 */
        goto L_75af;  /* 重复引用 */
        goto L_75b9;  /* 重复引用 */
        goto L_75c3;  /* 重复引用 */
        goto L_75cb;  /* 重复引用 */
        goto L_75d6;  /* 重复引用 */
        goto L_75de;  /* 重复引用 */
        goto L_75e6;  /* 重复引用 */
        goto L_760f;  /* 重复引用 */
        goto L_7617;  /* 重复引用 */
        goto L_7623;  /* 重复引用 */
        goto L_762d;  /* 重复引用 */
        goto L_7637;  /* 重复引用 */
        goto L_7643;  /* 重复引用 */
        goto L_764d;  /* 重复引用 */
        goto L_7665;  /* 重复引用 */
        goto L_76e1;  /* 重复引用 */
        goto L_76ef;  /* 重复引用 */
        goto L_770c;  /* 重复引用 */
        goto L_7728;  /* 重复引用 */
        goto L_7732;  /* 重复引用 */
        goto L_7734;  /* 重复引用 */
        goto L_7738;  /* 重复引用 */
    }
    goto L_773c;  /* 重复引用 */
}

/* ==== sub_7747  (被调用 1 次) ==== */
static void sub_7747(void) {
    L_7747:; /* 0x7747 */
    for (int i = 8; i >= 0; i--) push32(r[i]);
    r0 = 0x12c4u;
    CALL(sub_2ba3);
    r7 = 0x12d4u;
    r8 = 0x12d0u;
    r6 = 0x1370u;
    r5 = 0x136cu;
    r4 = 0x13b8u;
    r3 = 0x13b4u;
    r2 = 0x15fcu;
    r1 = 0x15f8u;
    goto L_77bb;
    L_7775:; /* 0x7775 */
    intr_sleep(&p[2]);
    r14 = 0x18700u;
    r15 = 0;
    r9 = iord(r14+r15*0x4);
    r15 = (r9 >> 16) & 0x1fu;
    s32(r8, r9);
    s32(r7, r15);
    CALL(sub_1fc9);
    r9 = d32(r0);
    if (!(r9 != 0x0u)) {
        L_7792:; /* 0x7792 */
        CALL(sub_4656);
        CALL(sub_7292);
        p[2] = 1;
        r15 = d32(r6);
        r9 = d32(r5);
        fc_cmp(r15, r9);
        if (!!FZ(falcon_flags)) {
            L_77a6:; /* 0x77a6 */
            r15 = d32(r4);
            r9 = d32(r3);
            fc_cmp(r15, r9);
            if (!!FZ(falcon_flags)) {
                L_77af:; /* 0x77af */
                r15 = d32(r2);
                r9 = d32(r1);
                fc_cmp(r15, r9);
                if (FZ(falcon_flags)) goto L_77bb;
                L_77b8:; /* 0x77b8 */
                p[2] = 0;
                L_77bb:; /* 0x77bb */
                r9 = d32(r0);
                if (!(r9 == 0x0u)) {
                    L_77c1:; /* 0x77c1 */
                    r15 = 0x1u;
                    r9 = 0x21800u;
                    iowr(r9, r15);
                    r10 = 0;
                    for (int i = 0; i <= 8; i++) r[i] = pop32();
                    return;
                }
                goto L_7775;  /* 重复引用 */
            }
            goto L_77b8;  /* 重复引用 */
            goto L_77af;  /* 重复引用 */
        }
        goto L_77b8;  /* 重复引用 */
        goto L_77a6;  /* 重复引用 */
        goto L_77af;  /* 重复引用 */
        goto L_77b8;  /* 重复引用 */
    }
    goto L_77bb;  /* 重复引用 */
}

/* ==== sub_77ce  (被调用 13 次) ==== */
static void sub_77ce(void) {
    L_77ce:; /* 0x77ce */
    r15 = r10 >> 0x10u;
    r9 = r11 >> 0x10u;
    r9 = falcon_muls(r10, r9);
    r10 = falcon_mulu(r11, r10);
    r11 = falcon_muls(r15, r11);
    r11 = r11 + r9;
    r11 <<= 0x10u;
    r10 = r11 + r10;
    return;
}

/* ==== sub_77e8  (被调用 2 次) ==== */
static void sub_77e8(void) {
    L_77e8:; /* 0x77e8 */
    if (!(r12 == 0x0u)) {
        L_77ec:; /* 0x77ec */
        r9 = 0;
        L_77ee:; /* 0x77ee */
        s32(r10+r9, r11);
        r9 = r9 + 0x1u;
        fc_cmp(r9, r12);
        if (!FZ(falcon_flags)) goto L_77ee;
        L_77f9:; /* 0x77f9 */
        return;
        goto L_77ee;  /* 重复引用 */
    }
    goto L_77f9;  /* 重复引用 */
}

/* 未归属任何函数的块(不可达/孤立): 0x131, 0x13c, 0x29f, 0x2da, 0x2e4, 0x2ef, 0x2f1, 0x304, 0x31d, 0x322, 0x327, 0x58f, 0x5f7, 0x74f, 0xa8c, 0xdfa, 0xfda, 0xfe8, 0xff8, 0xffa */

int main(void){ push32(0u); sub_0(); return 0; }  /* 入口 0x0 */